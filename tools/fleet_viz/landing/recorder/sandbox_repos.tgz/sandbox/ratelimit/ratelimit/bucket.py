import time


class TokenBucket:
    """Allow `rate` requests per second with bursts up to `capacity`."""

    def __init__(self, rate, capacity, clock=time.monotonic):
        self.rate = rate
        self.capacity = capacity
        self.clock = clock
        self.tokens = capacity
        self.last = clock()

    def _refill(self):
        now = self.clock()
        elapsed = now - self.last
        self.tokens = self.tokens + elapsed * self.rate
        self.last = now

    def allow(self, cost=1):
        self._refill()
        if self.tokens > cost:
            self.tokens -= cost
            return True
        return False

    def wait_time(self, cost=1):
        """Seconds until a request of this cost would be allowed."""
        self._refill()
        if self.tokens >= cost:
            return 0.0
        return (cost - self.tokens) * self.rate
