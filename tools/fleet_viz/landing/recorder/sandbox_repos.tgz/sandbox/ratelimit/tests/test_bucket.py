from ratelimit import TokenBucket


class FakeClock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t


def test_burst_up_to_capacity():
    clk = FakeClock()
    b = TokenBucket(rate=2, capacity=3, clock=clk)
    assert [b.allow() for _ in range(4)] == [True, True, True, False]


def test_refill_never_exceeds_capacity():
    clk = FakeClock()
    b = TokenBucket(rate=10, capacity=5, clock=clk)
    for _ in range(5):
        b.allow()
    clk.t = 100.0
    assert [b.allow() for _ in range(6)] == [True] * 5 + [False]


def test_wait_time():
    clk = FakeClock()
    b = TokenBucket(rate=4, capacity=1, clock=clk)
    assert b.allow()
    assert abs(b.wait_time() - 0.25) < 1e-9
