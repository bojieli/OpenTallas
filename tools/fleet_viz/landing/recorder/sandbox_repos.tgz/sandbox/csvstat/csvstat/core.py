import csv


def read_column(path, column):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    if rows and column not in rows[0]:
        raise KeyError(f"no column {column!r}; have {list(rows[0])}")
    return rows, [float(r[column]) for r in rows]


def summarize(values):
    if not values:
        return {"count": 0, "mean": None, "min": None, "max": None}
    return {
        "count": len(values),
        "mean": sum(values) / len(values),
        "min": min(values),
        "max": max(values),
    }
