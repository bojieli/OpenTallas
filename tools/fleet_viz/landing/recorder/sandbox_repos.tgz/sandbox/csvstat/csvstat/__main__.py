import argparse

from .core import read_column, summarize


def main(argv=None):
    ap = argparse.ArgumentParser(prog="csvstat")
    ap.add_argument("path")
    ap.add_argument("--column", required=True)
    args = ap.parse_args(argv)
    _, values = read_column(args.path, args.column)
    s = summarize(values)
    print(f"count={s['count']} mean={s['mean']:.2f} min={s['min']:.2f} max={s['max']:.2f}")


if __name__ == "__main__":
    main()
