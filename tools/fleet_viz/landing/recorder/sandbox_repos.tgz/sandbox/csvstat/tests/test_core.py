from csvstat.core import read_column, summarize


def test_summarize_basic():
    s = summarize([1.0, 2.0, 3.0])
    assert s == {"count": 3, "mean": 2.0, "min": 1.0, "max": 3.0}


def test_read_column():
    _, vals = read_column("data/sales.csv", "amount")
    assert len(vals) == 8
