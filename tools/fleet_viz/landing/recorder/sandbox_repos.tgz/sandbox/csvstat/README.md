# csvstat
Summary statistics for a numeric CSV column.

    python -m csvstat data/sales.csv --column amount

Prints count, mean, min, max.
