from splitwise import Ledger, split_evenly


def test_split_assigns_every_cent():
    shares = split_evenly(1000, ["ana", "ben", "cy"])
    assert sum(shares.values()) == 1000
    assert shares == {"ana": 334, "ben": 333, "cy": 333}


def test_split_even_amount():
    assert split_evenly(900, ["a", "b", "c"]) == {"a": 300, "b": 300, "c": 300}


def test_ledger_balances_sum_to_zero():
    led = Ledger()
    led.add_expense("ana", 1000, ["ana", "ben", "cy"])
    led.add_expense("ben", 2501, ["ana", "ben"])
    assert sum(led.balances.values()) == 0


def test_settle_up_zeroes_everything():
    led = Ledger()
    led.add_expense("ana", 1000, ["ana", "ben", "cy"])
    led.add_expense("cy", 4567, ["ana", "ben", "cy", "dee"])
    transfers = led.settle_up()
    net = dict(led.balances)
    for d, c, cents in transfers:
        net[d] += cents
        net[c] -= cents
    assert all(v == 0 for v in net.values())
