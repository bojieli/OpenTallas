# splitwise-lite
Tiny expense-splitting library. Amounts are stored in integer cents.
Run tests: `python -m pytest -q`
