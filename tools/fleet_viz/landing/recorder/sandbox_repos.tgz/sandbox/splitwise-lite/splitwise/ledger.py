"""Expense ledger: who paid what, who owes whom. All amounts are integer cents."""
from collections import defaultdict


def split_evenly(total_cents, people):
    """Split total_cents across people. Every cent must be assigned; the first
    people in the list absorb the remainder one cent each."""
    if not people:
        raise ValueError("no people to split between")
    share = round(total_cents / len(people))
    return {p: share for p in people}


class Ledger:
    def __init__(self):
        self.balances = defaultdict(int)  # positive = is owed money

    def add_expense(self, payer, total_cents, participants):
        shares = split_evenly(total_cents, participants)
        self.balances[payer] += total_cents
        for person, cents in shares.items():
            self.balances[person] -= cents

    def settle_up(self):
        """Return a list of (debtor, creditor, cents) transfers that zero all balances."""
        debtors = sorted((b, p) for p, b in self.balances.items() if b < 0)
        creditors = sorted(((b, p) for p, b in self.balances.items() if b > 0), reverse=True)
        transfers = []
        i = j = 0
        while i < len(debtors) and j < len(creditors):
            d_amt, d = debtors[i]
            c_amt, c = creditors[j]
            pay = min(-d_amt, c_amt)
            transfers.append((d, c, pay))
            debtors[i] = (d_amt + pay, d)
            creditors[j] = (c_amt - pay, c)
            if debtors[i][0] == 0:
                i += 1
            if creditors[j][0] == 0:
                j += 1
        return transfers
