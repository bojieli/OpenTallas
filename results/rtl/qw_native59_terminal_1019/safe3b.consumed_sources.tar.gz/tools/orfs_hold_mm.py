#!/usr/bin/env python3
"""FLOW-HOLD (2026-10-07): patch a DISPOSABLE ORFS flow container's load.tcl / util.tcl so that, when the ORFS config
exports OT_HOLD_MM=1, every stage loads a multi-mode session (scene WC = SS setup, scene BC = FF hold, each under its own
constraints) and repair_timing_helper repairs SS setup and FF hold together (tools/orfs_hold_mm.tcl).  Without
OT_HOLD_MM=1 the multi-mode changes are inert. Detailed placement always receives ordinary final legalization after
DPO/mirroring and before its unchanged placement check. Applied like tools/orfs_allcorner_spef.py: inside a new
--rm container only; images, work dirs and evidence are never modified.
   orfs_hold_mm.py <ORFS scripts dir> [<helper tcl, default /src/tools/orfs_hold_mm.tcl>]"""
import hashlib
import json
import os
import sys
from pathlib import Path

LIB = "  source $::env(SCRIPTS_DIR)/read_liberty.tcl"
SDC = "  log_cmd read_sdc $::env(RESULTS_DIR)/$sdc_file"
RTH = "  log_cmd repair_timing {*}$additional_args\n}"
# unstick 2026-10-08: the hold-stall guard (ot_repair_timing in orfs_hold_mm.tcl), when the helper defines it
GUARD_CALL = ("  if {[llength [info commands ot_repair_timing]]} {\n"
              "    set ot_rc [catch {ot_repair_timing $additional_args} ot_msg ot_opts]\n"
              "  } else {\n"
              "    set ot_rc [catch {log_cmd repair_timing {*}$additional_args} ot_msg ot_opts]\n"
              "  }\n")


def patch(scripts: Path, helper: str) -> dict:
    load, util = scripts / "load.tcl", scripts / "util.tcl"
    lt, ut = load.read_text(), util.read_text()
    out = {"helper": helper}
    if "ot_mm_on" in lt and "ot_repair_timing" in ut:
        return {**out, "status": "already patched"}
    old_catch = "  set ot_rc [catch {log_cmd repair_timing {*}$additional_args} ot_msg ot_opts]\n"
    if "ot_mm_on" in lt and "ot_mm_sync" in ut and ut.count(old_catch) == 1:   # earlier generation: add the hold guard
        util.write_text(ut.replace(old_catch, GUARD_CALL, 1))
        return {**out, "status": "upgraded (hold-stall guard)"}
    for name, text, anchor in (("load.tcl", lt, LIB), ("load.tcl", lt, SDC), ("util.tcl", ut, RTH)):
        if text.count(anchor) != 1:
            raise SystemExit(f"orfs_hold_mm: anchor {anchor!r} not found exactly once in {name}; refusing")
    lt = lt.replace(LIB, f"  source {helper}\n  if {{[ot_mm_on]}} {{ ot_mm_read_libs }} else {{\n{LIB}\n  }}", 1)
    lt = lt.replace(SDC, f"  if {{[ot_mm_on]}} {{ ot_mm_read_sdc $::env(RESULTS_DIR)/$sdc_file }} else {{\n{SDC}\n  }}", 1)
    # repair_timing_helper is the CTS / post-GRT (and placement) repair: refresh the FF mode before, restore after
    ut = ut.replace(RTH, "  if {[llength [info commands ot_mm_sync]]} { ot_mm_sync }\n"
                         "  if {[llength [info commands ot_repair_timing]]} {\n"
                         "    set ot_rc [catch {ot_repair_timing $additional_args} ot_msg ot_opts]\n"
                         "  } else {\n"
                         "    set ot_rc [catch {log_cmd repair_timing {*}$additional_args} ot_msg ot_opts]\n"
                         "  }\n"
                         "  if {[llength [info commands ot_mm_unsync]]} { ot_mm_unsync }\n"
                         # flow-triage 2026-10-08: an mm repair that exhausts repair_timing's buffer budget (RSZ-0060)
                         # throws AFTER inserting its buffers, killing the stage (no 4_1_cts.odb) although the design is
                         # whole; continue in mm mode only (tolerate_flow_errors then zeroes the count) so the sign-off
                         # STA, not a dead stage, reports the residual FF hold.
                         "  if {$ot_rc && [info exists ::ot_mm_active] && [regexp {RSZ-0060|Max buffer count} $ot_msg]} {\n"
                         "    puts \"OT_HOLD_MM: repair hit the buffer cap (RSZ-0060); continuing on the repaired design, sign-off decides\"\n"
                         "    return\n  }\n"
                         "  if {$ot_rc} { return -options $ot_opts $ot_msg }\n}", 1)
    sha = lambda s: hashlib.sha256(s.encode()).hexdigest()  # noqa: E731
    out.update(load_before=sha(load.read_text()), util_before=sha(util.read_text()))
    load.write_text(lt)
    util.write_text(ut)
    out.update(status="patched", load_after=sha(lt), util_after=sha(ut))
    return out


# The detailed optimizer can create off-site cells after ordinary legalization
# (Q-TILE45 r5: NK33/NL3 cells, almost all one DBU before a fence edge).
# Run ordinary legalization after the final optimizer/mirroring mutation, before
# the original mandatory placement check. No errors or checks are suppressed.
FINAL_DPL_ANCHOR = ('  log_cmd optimize_mirroring\n\n'
                    '  utl::info FLW 12 "Placement violations [check_placement -verbose]."')
FINAL_DPL_BLOCK = ('  log_cmd optimize_mirroring\n\n'
                   '  puts "OT_FINAL_DPL: ordinary legalization after final optimizer/mirroring"\n'
                   '  log_cmd detailed_placement {*}$dpl_args\n\n'
                   '  utl::info FLW 12 "Placement violations [check_placement -verbose]."')


def patch_final_dpl(scripts: Path) -> str:
    """Fail closed unless the final mutation/check sequence is exactly recognized."""
    target = scripts / "detail_place.tcl"
    text = target.read_text()
    if (text.count(FINAL_DPL_BLOCK) == 1 and text.count("OT_FINAL_DPL") == 1
            and FINAL_DPL_ANCHOR not in text):
        return "already patched"
    if "OT_FINAL_DPL" in text or text.count(FINAL_DPL_ANCHOR) != 1:
        raise SystemExit("orfs_hold_mm: final legalization anchor not found exactly once in detail_place.tcl; refusing")
    target.write_text(text.replace(FINAL_DPL_ANCHOR, FINAL_DPL_BLOCK, 1))
    return "patched"


STAGE_LOGS = {"cts": ["4_1_cts.log"], "globalroute": ["5_1_grt.log"]}


def tolerate_flow_errors(errors: dict, logs_dir) -> dict:
    """An mm repair that runs out of buffer budget (RSZ-0060) inside a recipe's own multi-pass wrapper
    (qwen_die_masters/repair_budget.tcl continues on the grown design) logs one [ERROR] although the stage then
    completes: such a count is zeroed ONLY when every [ERROR line of the stage log is RSZ-0060, their number equals the
    count, and an "OT_HOLD_MM after repair" line follows the last one.  Anything else stays an error."""
    out = dict(errors)
    for key, val in errors.items():
        stage = key.split("__", 1)[0]
        if not int(val) or stage not in STAGE_LOGS:
            continue
        lines = []
        for name in STAGE_LOGS[stage]:
            f = Path(logs_dir) / name
            if f.is_file():
                lines += f.read_text(errors="replace").splitlines()
        errs = [i for i, ln in enumerate(lines) if ln.startswith("[ERROR")]
        if (errs and len(errs) == int(val) and all("RSZ-0060" in lines[i] for i in errs)
                and any("OT_HOLD_MM after repair" in ln for ln in lines[errs[-1]:])):
            out[key] = 0
            print(f"orfs_hold_mm: {key}={val} tolerated (RSZ-0060 inside a completed multi-pass mm repair)")
    return out


# FP-LINT (owner 2026-10-08): the floorplan margin lint runs at the start of ORFS global placement (after the block's own
# PRE_GLOBAL_PLACE hook), on 3_2_place_iop.odb.  Inert unless the container env has OT_FP_LINT=1 (the closure loop's docker
# shim passes it); tools/fp_margin_lint.tcl stops the flow with FLOORPLAN_MARGIN on a failing floorplan.
FPL_ANCHOR = 'proc source_step_tcl { hook_type step_name } {\n  set env_var "${hook_type}_${step_name}_TCL"\n  source_env_var_if_exists $env_var\n'
FPL_CODE = ('  if {$hook_type eq "PRE" && $step_name eq "GLOBAL_PLACE" && [info exists ::env(OT_FP_LINT)] && '
            '$::env(OT_FP_LINT) ni {"" 0 false}} {\n'
            '    set ot_fpl [expr {[info exists ::env(OT_FP_LINT_TCL)] ? $::env(OT_FP_LINT_TCL) : "/src/tools/fp_margin_lint.tcl"}]\n'
            '    if {[file exists $ot_fpl]} { source $ot_fpl; ot_fp_lint_flow } else { puts "OT_FP_LINT: $ot_fpl missing: lint skipped" }\n'
            '  }\n')


def patch_fp_lint(scripts: Path) -> str:
    util = scripts / "util.tcl"
    ut = util.read_text()
    if "ot_fp_lint_flow" in ut:
        return "already patched"
    if ut.count(FPL_ANCHOR) != 1:
        return "anchor not found: fp lint unavailable in this image"
    util.write_text(ut.replace(FPL_ANCHOR, FPL_ANCHOR + FPL_CODE, 1))
    return "patched"


# SLIVER-BLOCK (LOOP-AUTO 2026-10-10, auto-react class d): with OT_SLIVER_BLOCK=1 in the container env, ORFS PRE
# GLOBAL_PLACE (after the block's own hook, BEFORE the floorplan lint) sources the common sliver hooks: a hard placement
# blockage over every macro-to-macro gap and every macro-to-core-edge gap narrower than 12 um (OT_EDGE_SLIVER_UM).
# Placement only; routing and constraints untouched.  Inserted right after the anchor, so it precedes the lint code.
SLV_CODE = ('  if {$hook_type eq "PRE" && $step_name eq "GLOBAL_PLACE" && [info exists ::env(OT_SLIVER_BLOCK)] && '
            '$::env(OT_SLIVER_BLOCK) ni {"" 0 false}} {\n'
            '    foreach ot_slv {/src/physical/common_flow/macro_sliver_block.tcl /src/physical/common_flow/edge_sliver_block.tcl} {\n'
            '      if {[file exists $ot_slv]} { source $ot_slv } else { puts "OT_SLIVER_BLOCK: $ot_slv missing" }\n'
            '    }\n'
            '  }\n')


def patch_sliver_block(scripts: Path) -> str:
    util = scripts / "util.tcl"
    ut = util.read_text()
    if "OT_SLIVER_BLOCK" in ut:
        return "already patched"
    if ut.count(FPL_ANCHOR) != 1:
        return "anchor not found: sliver block unavailable in this image"
    util.write_text(ut.replace(FPL_ANCHOR, FPL_ANCHOR + SLV_CODE, 1))
    return "patched"


# PREROUTE-GATE (owner 2026-10-08): the pre-route timing gate runs at the end of ORFS detailed placement (POST DETAIL_PLACE,
# after the block's own POST_DETAIL_PLACE hook: resizer + detailed placement done, placement parasitics estimated, timing
# already updated by report_metrics).  Inert unless the container env has OT_PREROUTE_GATE=1 (the closure loop's docker
# shim passes it only when the gate is enabled); tools/preroute_gate.tcl stops the flow with PREROUTE_MARGIN.
PRG_CODE = ('  if {$hook_type eq "POST" && $step_name eq "DETAIL_PLACE" && [info exists ::env(OT_PREROUTE_GATE)] && '
            '$::env(OT_PREROUTE_GATE) ni {"" 0 false}} {\n'
            '    set ot_prg [expr {[info exists ::env(OT_PREROUTE_GATE_TCL)] ? $::env(OT_PREROUTE_GATE_TCL) : "/src/tools/preroute_gate.tcl"}]\n'
            '    if {[file exists $ot_prg]} { source $ot_prg; ot_preroute_gate_flow } else { puts "OT_PREROUTE_GATE: $ot_prg missing: gate skipped" }\n'
            '  }\n')


def patch_preroute_gate(scripts: Path) -> str:
    util = scripts / "util.tcl"
    ut = util.read_text()
    if "ot_preroute_gate_flow" in ut:
        return "already patched"
    if ut.count(FPL_ANCHOR) != 1:
        return "anchor not found: pre-route gate unavailable in this image"
    util.write_text(ut.replace(FPL_ANCHOR, FPL_ANCHOR + PRG_CODE, 1))
    return "patched"


def patch_abc_no_dch(scripts: Path, env=None) -> str:
    """ABC-NODCH (drive-2155 2026-10-08): yosys-abc's &dch asserts on some netlists (aigDup.c:602 Aig_ManDupDfs,
    'ABC failed with status 86'; dsfd_wfc_vmx: 253k ANDs, &get -n; &st; &dch alone reproduces it, abc_area too).  With
    OT_ABC_NO_DCH=1 in the container env the disposable container's abc_speed / abc_area scripts run &synch2 (synthesis
    with structural choices, already in the script) in place of &dch.  Without the variable nothing changes."""
    env = os.environ if env is None else env
    if env.get("OT_ABC_NO_DCH") != "1":
        return "off"
    out = []
    for name in ("abc_speed.script", "abc_area.script"):
        f = scripts / name
        if not f.is_file():
            continue
        lines = f.read_text().splitlines()
        new = ["&synch2" if ln.strip() in ("&dch", "&dch -f") else ln for ln in lines]
        if new != lines:
            f.write_text("\n".join(new) + "\n")
            out.append(f"{name}: {sum(a != b for a, b in zip(lines, new))} x &dch -> &synch2")
    return "; ".join(out) or "no &dch found"


if __name__ == "__main__":
    print("orfs_hold_mm: final legalization", patch_final_dpl(Path(sys.argv[1])))
    print("orfs_hold_mm:", json.dumps(patch(Path(sys.argv[1]), sys.argv[2] if len(sys.argv) > 2 else "/src/tools/orfs_hold_mm.tcl")))
    try:
        print("orfs_hold_mm: abc no-dch", patch_abc_no_dch(Path(sys.argv[1])))
    except Exception as ex:  # noqa: BLE001
        print(f"orfs_hold_mm: abc no-dch not applied ({ex})")
    try:
        print("orfs_hold_mm: fp lint hook", patch_fp_lint(Path(sys.argv[1])))
    except Exception as ex:  # noqa: BLE001 - the lint hook must never break a flow
        print(f"orfs_hold_mm: fp lint hook not installed ({ex})")
    try:
        print("orfs_hold_mm: sliver block hook", patch_sliver_block(Path(sys.argv[1])))
    except Exception as ex:  # noqa: BLE001 - the sliver hook must never break a flow
        print(f"orfs_hold_mm: sliver block hook not installed ({ex})")
    try:
        print("orfs_hold_mm: pre-route gate hook", patch_preroute_gate(Path(sys.argv[1])))
    except Exception as ex:  # noqa: BLE001 - the gate hook must never break a flow
        print(f"orfs_hold_mm: pre-route gate hook not installed ({ex})")
