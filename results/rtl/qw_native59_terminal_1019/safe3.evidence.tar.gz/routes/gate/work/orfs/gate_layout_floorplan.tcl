read_db /work/results/asap7/opentallas_qfd_native59_dv_service_r1_asap7_ref_gate/base/3_2_place_iop.odb
source /src/tools/ref_tile/layout_dump.tcl
exit
