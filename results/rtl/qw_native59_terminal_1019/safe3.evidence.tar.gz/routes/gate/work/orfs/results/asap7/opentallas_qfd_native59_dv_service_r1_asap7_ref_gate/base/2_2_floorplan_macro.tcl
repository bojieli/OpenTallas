place_macro -macro_name {u_ot_pr_core.u_core.g_qread_safe.u_qseat.g_writer\[0\].u_mem} -location {43.2 129.6} -orientation R0
place_macro -macro_name {u_ot_pr_core.u_core.g_qread_safe.u_qseat.g_writer\[1\].u_mem} -location {259.2 129.6} -orientation R0
place_macro -macro_name {u_ot_pr_core.u_core.g_qread_safe.u_qseat.g_writer\[2\].u_mem} -location {43.2 259.2} -orientation R0
place_macro -macro_name {u_ot_pr_core.u_core.g_qread_safe.u_qseat.g_writer\[3\].u_mem} -location {259.2 259.2} -orientation R0
place_macro -macro_name {u_ot_pr_core.u_core.g_qread_safe.u_qseat.g_writer\[4\].u_mem} -location {43.2 388.8} -orientation R0
place_macro -macro_name {u_ot_pr_core.u_core.g_qread_safe.u_qseat.g_writer\[5\].u_mem} -location {259.2 388.8} -orientation R0
place_macro -macro_name {u_ot_pr_core.u_core.g_qread_safe.u_qseat.g_writer\[6\].u_mem} -location {43.2 518.4} -orientation R0
place_macro -macro_name {u_ot_pr_core.u_core.g_qread_safe.u_qseat.g_writer\[7\].u_mem} -location {259.2 518.4} -orientation R0

