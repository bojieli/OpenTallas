# Written by tools/run_abi3_physical.py --pin-region.
proc ot_pin_plain {name} { return [string map {\\\[ \[ \\\] \]} $name] }
proc ot_pin_base {name} { regsub {\[[0-9]+\]$} [ot_pin_plain $name] {} base; return $base }
proc ot_pin_matches {pattern name} {
  return [expr {[regexp -- $pattern $name] || [regexp -- $pattern [ot_pin_plain $name]] ||
                [regexp -- $pattern [ot_pin_base $name]]}]
}
proc ot_match_pins {pattern} {
  set names {}
  foreach bterm [[ord::get_db_block] getBTerms] {
    set name [$bterm getName]
    if {[ot_pin_matches $pattern $name]} { lappend names $name }
  }
  if {[llength $names] == 0} { error "--pin-region $pattern matches no port" }
  return [lsort -dictionary $names]
}
proc ot_check_bus_complete {patterns} {
  array set hit {}; array set all {}
  foreach bterm [[ord::get_db_block] getBTerms] {
    if {[lsearch -exact {POWER GROUND} [$bterm getSigType]] >= 0} { continue }
    set name [$bterm getName]
    set base [ot_pin_base $name]
    if {$base eq [ot_pin_plain $name]} { continue }
    incr all($base)
    foreach p $patterns { if {[ot_pin_matches $p $name]} { incr hit($base); break } }
  }
  set bad {}
  foreach base [array names hit] { if {$hit($base) != $all($base)} { lappend bad "$base:$hit($base)/$all($base)" } }
  if {[llength $bad] > 0} {
    error "--pin-region leaves bus bits unassigned (bus:assigned/bits): [lrange [lsort $bad] 0 23]"
  }
}
ot_check_bus_complete [list {^(native_rx_payload|rst_n|ck|x3_identity|x3_generation|x3|tx_slot_kind|tx_slot_beat|tx_slot|rx_slot_kind|rx_slot_beat|rx_slot|native_tx_v|native_tx_payload|native_rx_v|kv_x3_slot)(\[|$)} {^(dr_o|dd_i|native_token|native_position|layer_context_v|command_stage|native_ret|native_cmd)(\[|$)} {^(emb_code_addr|emb_code_q|emb_code_re|emb_scale_addr|emb_scale_q|emb_scale_re|completed|complete_slot|fault|host_epoch|host_epoch_valid|host_fused_capability|host_generation|host_tag|kv_word_index|kv_word_slot|q_slot|q_slot_beat|visibility_slot)(\[|$)}]
proc ot_check_pin_regions {patterns} {
  set bad {}
  foreach bterm [[ord::get_db_block] getBTerms] {
    if {[lsearch -exact {POWER GROUND} [$bterm getSigType]] >= 0} { continue }
    set name [$bterm getName]
    set n 0
    foreach p $patterns { if {[ot_pin_matches $p $name]} { incr n } }
    if {$n != 1} { lappend bad "$name:$n" }
  }
  if {[llength $bad] > 0} {
    error "--pin-regions-exhaustive: [llength $bad] ports match no region or more than one (port:matches): [lrange $bad 0 23]"
  }
}
ot_check_pin_regions [list {^(native_rx_payload|rst_n|ck|x3_identity|x3_generation|x3|tx_slot_kind|tx_slot_beat|tx_slot|rx_slot_kind|rx_slot_beat|rx_slot|native_tx_v|native_tx_payload|native_rx_v|kv_x3_slot)(\[|$)} {^(dr_o|dd_i|native_token|native_position|layer_context_v|command_stage|native_ret|native_cmd)(\[|$)} {^(emb_code_addr|emb_code_q|emb_code_re|emb_scale_addr|emb_scale_q|emb_scale_re|completed|complete_slot|fault|host_epoch|host_epoch_valid|host_fused_capability|host_generation|host_tag|kv_word_index|kv_word_slot|q_slot|q_slot_beat|visibility_slot)(\[|$)}]
set ot_region_pins [ot_match_pins {^(native_rx_payload|rst_n|ck|x3_identity|x3_generation|x3|tx_slot_kind|tx_slot_beat|tx_slot|rx_slot_kind|rx_slot_beat|rx_slot|native_tx_v|native_tx_payload|native_rx_v|kv_x3_slot)(\[|$)}]
set ot_count [llength $ot_region_pins]
set ot_first 0
foreach ot_pin $ot_region_pins {
  set ot_pos [expr {1 + (517.4 - 1) * ($ot_first + 0.5) / $ot_count}]
  set ot_layer [lindex {M3 M5} [expr {($ot_first / 1) % 2}]]
  place_pin -pin_name $ot_pin -layer $ot_layer -location [list $ot_pos 648] -force_to_die_boundary
  incr ot_first
}
set ot_region_pins [ot_match_pins {^(dr_o|dd_i|native_token|native_position|layer_context_v|command_stage|native_ret|native_cmd)(\[|$)}]
set ot_count [llength $ot_region_pins]
set ot_first 0
foreach ot_pin $ot_region_pins {
  set ot_pos [expr {1 + (517.4 - 1) * ($ot_first + 0.5) / $ot_count}]
  set ot_layer [lindex {M3 M5} [expr {($ot_first / 1) % 2}]]
  place_pin -pin_name $ot_pin -layer $ot_layer -location [list $ot_pos 0] -force_to_die_boundary
  incr ot_first
}
set ot_region_pins [ot_match_pins {^(emb_code_addr|emb_code_q|emb_code_re|emb_scale_addr|emb_scale_q|emb_scale_re|completed|complete_slot|fault|host_epoch|host_epoch_valid|host_fused_capability|host_generation|host_tag|kv_word_index|kv_word_slot|q_slot|q_slot_beat|visibility_slot)(\[|$)}]
set ot_count [llength $ot_region_pins]
set ot_first 0
foreach ot_pin $ot_region_pins {
  set ot_pos [expr {1 + (647 - 1) * ($ot_first + 0.5) / $ot_count}]
  set ot_layer [lindex {M4} [expr {($ot_first / 1) % 1}]]
  place_pin -pin_name $ot_pin -layer $ot_layer -location [list 0 $ot_pos] -force_to_die_boundary
  incr ot_first
}
