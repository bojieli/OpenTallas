`timescale 1ns/1ps
// =====================================================================================================================
// TOKEN-XDIE-QWEN 2026-10-18: Qwen compute die <-> KV/system die D2D EXCHANGE co-sim (per decode layer L1..L35).
//
// On-chip RTL (current die masters, no reference arithmetic):
//   compute die  qfd_d2d_static (PR=1, die master d2d_rom of dv2f14bn)          + C_REAL=1: qfd_native59_dv_service
//                (die master native59: Q seat bank, FP8 K/V formatter, KVN transport, static service, native548 codec)
//   KV die       qkd_d2d_static (PR=1, die master d2d_kv of kvs14c)             + K_REAL=1: the kvs_attn attention
//                control composition (qkd_native_attention_programme + qkd_attn_cal_gen STRETCH=1 + qkd_attn_service_root,
//                wired as in kvs14c qkd_kvs_attn) with its RESULT pins driven on the reserved ages (the result face
//                qkd_attn_result_face_s is NOT on the link path; K_REAL=2 instantiates the as-built qkd_kvs_attn incl.
//                the face and drives pvfin's beat stream into the face window: diagnostic, see the lane file;
//                QXF-FACE 10-18: K_REAL=3 = the as-built qkd_kvs_attn + the REAL stream final join qkd_pv_fin_s
//                (pvfin, fed from kvs_attn pvfst; fo -> fin; fault -> uff) with the PV pair streams on their compiled
//                slots P0 / P1 and the hub reciprocals on R (qkd_ahub_static_dw fr contract) as stimuli; POS_P sets
//                the context T = POS_P + 1; FIN_MUT = the pvfin MUT; RESULT golden = obeat with a normal exponent
//                (pairs x 2^h, reciprocal 2^-(h+1): (p0 + p1) * rz == obeat exactly))
//   Calendars: the compiler images of tools/qwen_split/xdie_exchange_cal.py (d2d_link_calendar layer law with the real
//   producer latencies), loaded through the cfg ports; one cal_start per layer, segment 0.
// Modelled (declared): the UCIe PHY pair ot_qkvd_ucie_x64_phy_model at LAT = PHY FDI cycles (3.5 ns measured
//   FDI-to-FDI, IEEE JSSC 2026 doi:10.1109/JSSC.2026.3651425 -> 5 cycles at 1.2 GHz; worst 9); the die seam relay /
//   landing stages as register chains of the netlisted / planned depth (xq_dly); the compute-local sys_face slots
//   (q_slot, kv_word_slot, visibility, complete), the HOST context / KV layer-programme authority and the slice D2D
//   words (Q / K / V at native59 dd_i) as compiled stimuli at those pins; the PV final join beat stream (attention
//   arithmetic is TOKEN-PASS-QWEN's KV single-die run).  C_REAL=0 / K_REAL=0: that end's producer / consumer is the
//   component-bench record codec (qkd_native_attention_record, real RTL) driven on the compiled slots.
// Checks (sticky; any one -> XQ_FAIL): every frame lands on its compiled cycle at both D2D ends (the ends' own RX
//   calendars fault otherwise) and at the producer / consumer pins (exact rel cycle, every layer); payloads bit-exact:
//   CMD position, 32 Q beats (golden element values), 32 RESULT beats (golden), STATUS, 4 KVN words (KV d2d word ==
//   the compute x3 word, identity + generation); no fault anywhere (ends, native59, programme, root, codecs) and no
//   ready/credit: request_ready / q_ready are checked high exactly when used (a miss is a fault, never a wait);
//   native59 completes every layer; static: every measured latency identical in all NL layers.
// Measured (per layer, edges of the 1.2 GHz core clock): XQ_MEAS lines; summary XQ_E lines.
// MUT: 1 KV programme run one edge late (calendar slot shift), 2 one PHY bit corrupted in a Q frame (CRC -> abort),
//      3 one RESULT word corrupted at the KV producer pins (golden mismatch at the compute consumer),
//      4 compute sys_face q_slot one edge late, 5 (K_REAL=0) KV STATUS word = 0 (the pre-F2 static_ctl encoding):
//      native59 needs the done bit rd[3]; 6 (C_REAL=1) native59 MUT 4 = the pre-F1 Q window (opens one edge after the
//      request: Q beat 0 one link slot late against the compiled calendar); 7 (K_REAL=1) static_ctl MUT 3 = the pre-F2
//      all-zero STATUS word from the real KV programme; 8 STATUS done bit (data bit 3) cleared at the KV producer pins
//      (layer 4; any K_REAL); 9 RESULT beat 7 data bit 0 flipped at the KV producer pins (layer 5; any K_REAL).
// K_TEAR (QXF-PAIR mutant, K_REAL != 0): one member of a KV seam bundle one stage short of its bundle's landed age
//      (1: att_rx_v of K.rx_record = KS_RXV - 1 vs rx_payload KS_RXP; 2: tx_v of K.tx_record = SK_TXV - 1 vs tx_payload).
// QXF-PAIR 10-18: C_REAL=1 + K_REAL=3 = the PAIRED co-sim (both die masters + native59 + as-built kvs_attn + real pvfin).
// QXF-LINK 2026-10-18: the die masters take TXDP from the compiler (xdie_params.svh P_TXDP_C / P_TXDP_K = the calendar's
//      TXD; F4), STATUS words come from qkd_native_status_word (F2), QGAP default 0 = the compiler's CMD->Q law (F1).
// =====================================================================================================================
module xq_dly #(parameter integer W = 1, parameter integer D = 0) (input wire ck, input wire [W-1:0] a, output wire [W-1:0] b);
    generate if (D == 0) begin : g0
        assign b = a;
    end else begin : gd
        reg [W-1:0] r [0:D-1];
        integer i;
        always @(posedge ck) begin r[0] <= a; for (i = 1; i < D; i = i + 1) r[i] <= r[i-1]; end
        assign b = r[D-1];
    end endgenerate
endmodule

module tb_xdie_qwen_exchange;
    `include "xdie_params.svh"
    parameter integer MUT = 0, C_REAL = 1, K_REAL = 1, NL = 35, QGAP = 0, POS_P = 255, FIN_MUT = 0, K_TEAR = 0;
    parameter integer K_NTX = 4;           // Q-XDIE-GEN 10-18: KV die binds qkd_d2d_static .NTX(3) (S-QTIES QC-12, kvs14p)
    parameter integer XQ_TXDP_UNSET = 0;   // F4 witness: build the masters without the compiled TXDP (must not elaborate)
    parameter CALDIR = "cal";
    localparam integer FW = 548, PW = 583, PR = 1, LEAD = 2 * PR;
    localparam [15:0] EP = 16'd9;
    localparam [17:0] TOK = 18'd50994;
    localparam [12:0] POS = 13'(POS_P);
    localparam [1:0] GEN = 2'd1;
    localparam [379:0] TEMPLATE = 380'h0000003000001000001000c5f0000000000000000000000000100358000000000000000000000000080100000080401;
    reg ck = 0; always #0.4167 ck = ~ck;
    reg por_n = 0, rst_n = 0;
    integer cyc = 0; always @(posedge ck) cyc <= cyc + 1;
    integer lay = -1, lstart = 0, rel;
    always @* rel = cyc - lstart;
    wire act = lay >= 1;
    wire [5:0] stage = 6'(lay + 1);
    wire [5:0] layer_id = 6'(lay);
    wire [58:0] op_tag = {EP, stage, TOK, POS, 6'd0};
    wire [58:0] host_tag = {EP, 6'd0, TOK, POS, 6'd0};

    // ------------------------------------------------------------------ golden payload functions
    function automatic [31:0] qval(input integer e, input integer l);
        qval = 32'(e) * 32'h9E3779B1 + 32'h3F800007 + 32'(l) * 32'h01000193; endfunction
    function automatic [511:0] qbeat(input integer b, input integer l);
        integer j; begin for (j = 0; j < 16; j = j + 1) qbeat[32*j +: 32] = qval(16 * b + j, l); end endfunction
    function automatic [511:0] obeat(input integer b, input integer l);
        integer j; begin for (j = 0; j < 16; j = j + 1) obeat[32*j +: 32] = 32'(b * 16 + j) * 32'h85EBCA6B + 32'h1234567 + 32'(l) * 32'h27D4EB2F;
            if (K_REAL == 3) for (j = 0; j < 16; j = j + 1) obeat[32*j+29 +: 2] = 2'b01; end endfunction   // normal exponent 64..127
    // K_REAL=3 pair partial: obeat with exponent + h (h = b / 8, the head of beat b); (p0 + p1) * 2^-(h+1) == obeat
    function automatic [511:0] pbeat(input integer b, input integer l);
        integer j; reg [511:0] o; begin o = obeat(b, l); pbeat = o;
            for (j = 0; j < 16; j = j + 1) pbeat[32*j+23 +: 8] = o[32*j+23 +: 8] + 8'(b / 8); end endfunction
    function automatic [7:0] code(input integer k, input integer h, input integer d);
        integer x; begin x = (k * 91 + h * 37 + d) % 254; if (x >= 127) x = x + 1; code = x[7:0]; end endfunction
    function automatic [31:0] decode(input [7:0] b);
        reg [3:0] e; reg [2:0] m; begin e = b[6:3]; m = b[2:0];
            if (e != 0) decode = {b[7], 8'(e + 120), m, 20'd0};
            else if (m[2]) decode = {b[7], 8'd120, m[1:0], 21'd0};
            else if (m[1]) decode = {b[7], 8'd119, m[0], 22'd0};
            else if (m[0]) decode = {b[7], 8'd118, 23'd0};
            else decode = {b[7], 31'd0};
        end endfunction
    function automatic [23:0] kvaddr(input integer k, input integer d);
        integer p; begin p = POS;
            if (k == 0) kvaddr = 24'(((p / 16) * 128 + d) * 16 + p % 16);
            else kvaddr = 24'(1048576 + p * 128 + d); end endfunction
    function automatic integer qperm(input integer n); qperm = (n * 37 + 11) % 512; endfunction

    // ------------------------------------------------------------------ calendars (compiler images)
    reg [31:0] img_ct [0:31], img_cr [0:31], img_kt [0:31], img_kr [0:31];
    reg cfg_c_tx = 0, cfg_c_rx = 0, cfg_k_tx = 0, cfg_k_rx = 0; reg [4:0] cfg_a = 0; reg [31:0] cfg_dc = 0, cfg_dk = 0;
    reg cstart = 0;

    // ------------------------------------------------------------------ PHY pair (behavioural, the only modelled block)
    wire c_ptx_v, k_ptx_v, c_prx_v, k_prx_v, c_up, k_up; wire [PW-1:0] c_ptx, k_ptx, c_prx, k_prx;
    wire c_lv, k_lv; wire [PW-1:0] c_lf, k_lf; wire c_phy_rst_n, k_phy_rst_n;
    reg corrupt = 0;
    ot_qkvd_ucie_x64_phy_model #(.LAT(P_PHY), .FW(PW)) u_cphy (.clk(ck), .rst_n(c_phy_rst_n), .tx_up(c_up),
        .tx_v(c_ptx_v), .tx_flit(c_ptx), .rx_v(c_prx_v), .rx_flit(c_prx), .link_v(c_lv), .link_flit(c_lf), .far_v(k_lv), .far_flit(k_lf));
    ot_qkvd_ucie_x64_phy_model #(.LAT(P_PHY), .FW(PW)) u_kphy (.clk(ck), .rst_n(k_phy_rst_n), .tx_up(k_up),
        .tx_v(k_ptx_v), .tx_flit(k_ptx), .rx_v(k_prx_v), .rx_flit(k_prx), .link_v(k_lv), .link_flit(k_lf),
        .far_v(c_lv), .far_flit(c_lf ^ (corrupt ? {{(PW-77){1'b0}}, 1'b1, 76'd0} : {PW{1'b0}})));
    reg corrupted_once = 0;
    always @(negedge ck) begin
        corrupt <= 1'b0;
        if (MUT == 2 && lay == 3 && c_lv && !corrupted_once && rel > P_QS) begin corrupt <= 1'b1; corrupted_once <= 1'b1; end
    end

    reg host_boot = 0;
    wire fwd_ep, fwd_lrst_n; reg [2:0] bump_ep = 0, bump_lr = 3'b111;
    always @(posedge ck) begin bump_ep <= {bump_ep, fwd_ep}; bump_lr <= {bump_lr, fwd_lrst_n}; end

    // ------------------------------------------------------------------ D2D ends (die masters)
    wire c_txs0, c_rxe0, c_rxs0, k_txs0, k_rxe0, k_rxs0; wire [3:0] c_tk, k_tk, c_rk, k_rk; wire [4:0] c_tb, k_tb, c_rb, k_rb;
    wire [FW-1:0] c_rxp, k_rxp; wire c_tv0, k_tv0; wire [FW-1:0] c_tp0, k_tp0;
    wire c_abort, k_abort, c_f, k_f; wire [7:0] c_tf, h_tf; wire [31:0] k_rcyc;
    wire [1:0] h_lu; wire h_ld, h_ls, h_rt; wire [3:0] h_ad;
    wire h_kvd, h_vmd, h_cod, h_hd, h_cb, h_kf, h_ar, h_cf, h_ea, h_wv, h_rxv; wire [1:0] h_sk; wire [547:0] h_rx;
    wire s_rv, s_rd, s_rf; wire [3:0] s_rc; wire [58:0] s_rt; wire [1:0] s_rg; wire [17:0] s_rtok; wire [31:0] s_rval, s_rcyc;
    wire kv_x3_slot; wire [523:0] x3; wire [58:0] x3_id; wire [1:0] x3_gen;
    wire kw_v, kw_slot; wire [10:0] kw_tag; wire [511:0] kw_data; wire [58:0] kw_id; wire [1:0] kw_gen, kw_idx;
    wire c_prog_rxv, c_prog_auth, c_prog_ctx, c_prog_wslot, c_emb_v, c_emb_s, k_emb_slot;
    wire st_res = act && rel == 20;
    qfd_d2d_static #(.MUT(0), .PR(PR), .TXDP(XQ_TXDP_UNSET ? 32'd0 : P_TXDP_C)) u_c (.ck(ck), .por_n(por_n), .rst_n(rst_n),
        .cfg_tx_we(cfg_c_tx), .cfg_rx_we(cfg_c_rx), .cfg_addr({1'b0, cfg_a}), .cfg_data(cfg_dc), .cal_start(cstart), .cal_seg(1'b0),
        .fwd_epoch(bump_ep[2]), .fwd_link_rst_n(bump_lr[2]),
        .native_tx_slot(c_txs0), .native_tx_slot_kind(c_tk), .native_tx_slot_beat(c_tb), .native_tx_v(c_tv0),
        .native_tx_payload(c_tp0), .rx_payload(c_rxp), .native_rx_v(c_rxe0), .native_rx_slot(c_rxs0),
        .native_rx_slot_kind(c_rk), .native_rx_slot_beat(c_rb),
        .prog_witness_slot(c_prog_wslot), .prog_auth_slot(c_prog_auth), .prog_context_slot(c_prog_ctx), .prog_tx_observed_v(1'b0),
        .prog_tx_record(548'd0), .prog_rx_v(c_prog_rxv), .emb_rx_v(c_emb_v), .emb_rx_slot(c_emb_s),
        .kv_x3_slot(kv_x3_slot), .x3(x3), .x3_identity(x3_id), .x3_generation(x3_gen),
        .status_epoch16(EP), .vm_drained(1'b1), .collective_drained(1'b1), .collective_busy(1'b0),
        .crom_fault(1'b0), .execution_active(1'b1), .admit_ready(1'b1),
        .result_v(st_res), .result_done(1'b1), .result_fault(1'b0), .result_cause(4'd0), .result_tag(op_tag),
        .result_gen(GEN), .result_token(TOK), .result_value(32'(lay * 77)), .result_cycles(32'(lay)),
        .fdi_tx_up(c_up), .fdi_tx_v(c_ptx_v), .fdi_tx_flit(c_ptx), .fdi_rx_v(c_prx_v), .fdi_rx_flit(c_prx),
        .phy_rst_n(c_phy_rst_n), .epoch_abort(c_abort), .transport_fault(c_tf), .fault(c_f));
    qkd_d2d_static #(.MUT(0), .NTX(K_NTX), .PR(PR), .TXDP(XQ_TXDP_UNSET ? 32'd0 : P_TXDP_K)) u_k (.ck(ck), .por_n(por_n), .rst_n(rst_n),
        .cfg_tx_we(cfg_k_tx), .cfg_rx_we(cfg_k_rx), .cfg_addr({1'b0, cfg_a}), .cfg_data(cfg_dk), .cal_start(cstart), .cal_seg(1'b0),
        .host_link_reset_req(1'b0), .host_recovery_clear(1'b0), .host_boot_begin(host_boot),
        .fwd_epoch(fwd_ep), .fwd_link_rst_n(fwd_lrst_n),
        .att_tx_slot(k_txs0), .att_tx_kind(k_tk), .att_tx_beat(k_tb), .att_tx_v(k_tv0), .att_tx_payload(k_tp0),
        .att_rx_v(k_rxe0), .att_rx_slot(k_rxs0), .att_rx_kind(k_rk), .att_rx_beat(k_rb), .rx_payload(k_rxp),
        .emb_tx_slot(k_emb_slot), .emb_tx_v(1'b0), .emb_tx_payload(548'd0),
        .record_tx_observed_v(1'b0), .record_tx(548'd0), .record_send_kind(h_sk), .record_witness_slot(h_wv),
        .record_rx_v(h_rxv), .record_rx(h_rx),
        .kvn_compiled_identity(op_tag), .kvn_compiled_generation(GEN),
        .kvn_word_valid(kw_v), .kvn_word_tag(kw_tag), .kvn_word_data(kw_data), .kvn_word_identity(kw_id),
        .kvn_word_generation(kw_gen), .kvn_word_slot(kw_slot), .kvn_word_index(kw_idx),
        .status_epoch16(EP), .serdes_up(1'b1), .kv_drained_local(1'b1), .kv_flush_local(1'b0),
        .host_drained_local(1'b1), .kv_active_local(1'b0),
        .link_up(h_lu), .transport_fault(h_tf), .native_links_drained(h_ld), .native_link_reset_seen(h_ls),
        .native_retrained(h_rt), .abort_drained(h_ad), .native_kv_drained(h_kvd), .native_vm_drained(h_vmd),
        .native_collective_drained(h_cod), .native_host_drained(h_hd), .native_collective_busy(h_cb),
        .native_kv_flush(h_kf), .native_admit_ready(h_ar), .crom_fault(h_cf), .execution_active(h_ea),
        .engine_result_v(s_rv), .engine_result_done(s_rd), .engine_result_fault(s_rf), .engine_result_cause(s_rc),
        .engine_result_tag(s_rt), .engine_result_gen(s_rg), .engine_result_token(s_rtok),
        .engine_result_value(s_rval), .engine_result_cycles(s_rcyc),
        .fdi_tx_up(k_up), .fdi_tx_v(k_ptx_v), .fdi_tx_flit(k_ptx), .fdi_rx_v(k_prx_v), .fdi_rx_flit(k_prx),
        .phy_rst_n(k_phy_rst_n), .epoch_abort(k_abort), .recovery_cycles(k_rcyc), .fault(k_f));
    wire c_eb = u_c.u_core.eb, k_eb = u_k.u_core.eb;

    // ------------------------------------------------------------------ measurement registers (per layer)
    integer m_cmd_iss, m_q0_iss, m_q31_iss, m_cmd_land, m_q0_land, m_q31_land;
    integer m_r0_iss, m_r31_iss, m_st_iss, m_r0_land, m_r31_land, m_st_land, m_k0_iss, m_k3_iss, m_k0_land, m_k3_land, m_done;
    integer nq_iss, nq_land, nr_iss, nr_land, nk_iss, nk_land, ns_res;
    integer errs = 0;
    task automatic err(input [8*96-1:0] what);
        begin errs = errs + 1; if (errs < 16) $display("XQ_ERR cyc %0d layer %0d rel %0d: %0s", cyc, lay, rel, what); end endtask
    // KVN words leaving the compute die (for the KV-side compare)
    reg [584:0] kvq [0:3];

    // ================================================================== COMPUTE end producer / consumer
    wire n_txs; wire [3:0] n_tk; wire [4:0] n_tb;
    wire n_rxv, n_rxs; wire [3:0] n_rk; wire [4:0] n_rb; wire [FW-1:0] n_rxp; wire n_x3s;
    wire p_tv; wire [FW-1:0] p_tp; wire [523:0] p_x3; wire [58:0] p_x3id; wire [1:0] p_x3g;
    wire [519:0] dr; wire n_done, n_fault;
    generate if (C_REAL != 0) begin : g_creal
        // die seam (d2d_rom <-> native59): register chains of the die's lane depth
        xq_dly #(10, CS_TXS) d_txs (.ck(ck), .a({c_txs0, c_tk, c_tb}), .b({n_txs, n_tk, n_tb}));
        xq_dly #(11, CS_RXV) d_rxv (.ck(ck), .a({c_rxe0, c_rxs0, c_rk, c_rb}), .b({n_rxv, n_rxs, n_rk, n_rb}));
        xq_dly #(FW, CS_RXP) d_rxp (.ck(ck), .a(c_rxp), .b(n_rxp));
        xq_dly #(1, CS_X3S) d_x3s (.ck(ck), .a(kv_x3_slot), .b(n_x3s));
        xq_dly #(1 + FW, SC_TX) d_tx (.ck(ck), .a({p_tv, p_tp}), .b({c_tv0, c_tp0}));
        xq_dly #(524 + 59 + 2, SC_X3) d_x3 (.ck(ck), .a({p_x3, p_x3id, p_x3g}), .b({x3, x3_id, x3_gen}));
        // compiled sys_face / HOST / slice stimuli at the native59 pins
        reg ctxv, kvs, qs, vis, cmp; reg [1:0] kvi; reg [4:0] qb; reg [379:0] cmd; reg [547:0] dd;
        integer kd, kq, g, j, ll, pp, w0, gk, gb;
        always @* begin
            ctxv = 0; kvs = 0; kvi = 0; qs = 0; qb = 0; vis = 0; cmp = 0; cmd = 0; dd = 0;
            if (act) begin
                ctxv = rel == P_N59_CTX;
                kd = rel - P_N59_CTX;
                for (g = 0; g < 4; g = g + 1) begin
                    w0 = (g == 0) ? 4 : (g == 1) ? 12 : (g == 2) ? 21 : 30;
                    gk = (g < 2) ? 1 : 0; gb = (g == 1 || g == 3) ? 64 : 0;
                    if (kd >= w0 && kd < w0 + 8) begin
                        j = kd - w0; dd[547] = 1; dd[546:545] = gk ? 2'd2 : 2'd1; dd[544:537] = 8'hff;
                        for (ll = 0; ll < 8; ll = ll + 1) begin pp = ((8 * j + ll) * 17) % 64;
                            dd[345 + 24*ll +: 24] = kvaddr(gk, gb + pp); dd[89 + 32*ll +: 32] = decode(code(gk, lay % 7, gb + pp)); end
                    end
                end
                kq = rel - (P_N59_CTX + 39);
                if (kq >= 0 && kq < 64) begin
                    dd[547] = 1; dd[546:545] = 2'd0; dd[544:537] = 8'hff;
                    for (ll = 0; ll < 8; ll = ll + 1) begin dd[345 + 24*ll +: 24] = 24'(qperm(8 * kq + ll)); dd[89 + 32*ll +: 32] = qval(qperm(8 * kq + ll), lay); end
                end
                if (rel == P_N59_CMD) cmd = TEMPLATE;
                if (rel - (P_N59_CMD + 1 + QGAP + (MUT == 4 ? 1 : 0)) >= 0 && rel - (P_N59_CMD + 1 + QGAP + (MUT == 4 ? 1 : 0)) < 32) begin
                    qs = 1; qb = 5'(rel - (P_N59_CMD + 1 + QGAP + (MUT == 4 ? 1 : 0))); end
                if (rel >= P_N59_KVW && rel < P_N59_KVW + 4) begin kvs = 1; kvi = 2'(rel - P_N59_KVW); end
                vis = rel == P_N59_VIS; cmp = rel == P_N59_CMP;
            end
        end
        wire[94:0] n_ret; wire e_cre, e_sre; wire [23:0] e_caddr; wire [17:0] e_saddr;
        qfd_native59_dv_service #(.MUT(MUT == 6 ? 4 : 0)) native59 (.ck(ck), .rst_n(rst_n),
            .host_epoch_valid(1'b1), .host_fused_capability(1'b1), .host_epoch(EP), .host_tag(host_tag), .host_generation(GEN),
            .layer_context_v(ctxv), .command_stage(stage), .native_token(TOK), .native_position(18'(POS)), .native_cmd(cmd),
            .dd_i(dd), .kv_word_slot(kvs), .kv_word_index(kvi), .kv_x3_slot(n_x3s),
            .x3(p_x3), .x3_identity(p_x3id), .x3_generation(p_x3g),
            .q_slot(qs), .q_slot_beat(qb), .tx_slot(n_txs), .tx_slot_kind(n_tk), .tx_slot_beat(n_tb),
            .native_tx_v(p_tv), .native_tx_payload(p_tp),
            .native_rx_v(n_rxv), .native_rx_payload(n_rxp), .rx_slot(n_rxs), .rx_slot_kind(n_rk), .rx_slot_beat(n_rb),
            .dr_o(dr), .emb_code_re(e_cre), .emb_code_addr(e_caddr), .emb_scale_re(e_sre), .emb_scale_addr(e_saddr),
            .emb_code_q(512'd0), .emb_scale_q(16'd0), .visibility_slot(vis), .complete_slot(cmp), .completed(n_done),
            .native_ret(n_ret), .fault(n_fault));
        reg sf = 0;
        always @(posedge ck) if (rst_n && n_fault && !sf) begin sf <= 1;
            $display("XQ_CAUSE native59 cyc %0d rel %0d: context %0d qtag %0d qexport %0d dv %0d formatter %0d x3 %0d record %0d (codec cause {rx_rec,tx_rec,rx_time,tx_time}=%b) land %0d visibility %0d vm_addr %0d service %0d",
                cyc, rel, native59.context_fault, native59.qtag_fault, native59.export_control_fault, native59.dv_fault, native59.formatter_fault,
                native59.x3_fault, native59.record_fault, native59.g_slot[0].u_record.fault_cause, native59.land_fault, native59.visibility_fault,
                native59.vm_address_fault, native59.svc_fault); end
    end else begin : g_cstub
        // component-bench producer: the record codec on the compiled slots (no die stages)
        wire q_ev = act && (rel == P_QS || (rel >= P_QS + 1 + QGAP && rel < P_QS + 33 + QGAP));
        wire [3:0] q_kind = rel == P_QS ? 4'd1 : 4'd2;
        wire [4:0] q_beat = rel == P_QS ? 5'd0 : 5'(rel - (P_QS + 1 + QGAP));
        wire [511:0] q_data = rel == P_QS ? {493'd0, 5'd0, POS, 1'b1} : qbeat(rel - (P_QS + 1 + QGAP), lay);
        wire ca_rv, ca_f; wire [3:0] ca_rk, ca_fc; wire [15:0] ca_re; wire [5:0] ca_rl; wire [4:0] ca_rb; wire [511:0] ca_rd;
        qkd_native_attention_record #(.KV_SIDE(0)) u_ca (.ck(ck), .rst_n(rst_n & ~c_eb),
            .tx_event(q_ev), .tx_expected(c_txs0), .tx_kind(q_kind), .tx_expected_kind(c_tk),
            .tx_epoch(EP), .tx_expected_epoch(EP), .tx_layer(layer_id), .tx_expected_layer(layer_id),
            .tx_beat(q_beat), .tx_expected_beat(c_tb), .tx_data(q_data), .tx_valid(c_tv0), .tx_payload(c_tp0),
            .rx_event(c_rxe0), .rx_expected(c_rxs0), .rx_payload(c_rxp), .rx_expected_kind(c_rk),
            .rx_expected_epoch(EP), .rx_expected_layer(layer_id), .rx_expected_beat(c_rb),
            .rx_valid(ca_rv), .rx_kind(ca_rk), .rx_epoch(ca_re), .rx_layer(ca_rl), .rx_beat(ca_rb), .rx_data(ca_rd),
            .fault(ca_f), .fault_cause(ca_fc));
        assign p_tv = c_tv0; assign p_tp = c_tp0;
        assign dr = (ca_rv && ca_rk == 4'd3) ? {1'b1, 1'b0, 1'b0, ca_rb, ca_rd} : 520'd0;
        assign n_fault = ca_f; assign n_done = ca_rv && ca_rk == 4'd4 && ca_rd[3];
        // the KV producer's STATUS word, bit-exact against the namespace (F2: the consumer completes on done)
        always @(posedge ck) if (rst_n && act && ca_rv && ca_rk == 4'd4 && ca_rd !== {507'd0, 5'b01001})
            err("STATUS word != namespace {q_ready 0, done 1, fault 0, busy 0, ready 1}");
        wire kvn_push = act && rel >= P_KS - 1 && rel < P_KS + 3;
        wire kvt_f;
        qfd_kvn_static_transport u_kvt (.ck(ck), .rst_n(rst_n & ~c_eb), .word_v(kvn_push), .word_tag({3'd2, 8'(rel - (P_KS - 1))}),
            .word_data(qbeat(rel - (P_KS - 1) + 40, lay)), .word_identity(op_tag), .word_generation(GEN), .slot_v(kv_x3_slot),
            .x3(x3), .x3_identity(x3_id), .x3_generation(x3_gen), .fault(kvt_f));
        assign p_x3 = x3; assign p_x3id = x3_id; assign p_x3g = x3_gen;
        reg sf = 0;
        always @(posedge ck) if (rst_n && ca_f && !sf) begin sf <= 1; $display("XQ_CAUSE compute stub codec cyc %0d rel %0d cause %b", cyc, rel, ca_fc); end
    end endgenerate

    // ================================================================== KV end producer / consumer
    wire a_rxe; wire [FW-1:0] a_rxp; wire a_txs; wire [3:0] a_tk; wire [4:0] a_tb; wire a_tv; wire [FW-1:0] a_tp;
    wire kq_v, kreq_v, k_pf; wire [4:0] kq_b; wire [511:0] kq_d;
    // MUT 8 / 9: corrupt the KV producer's record at its output pins (before the seam relays and the link CRC)
    wire [FW-1:0] a_tpx = a_tp ^ ((MUT == 8 && lay == 4 && a_tv && a_tp[542:539] == 4'd4) ? {{(FW-4){1'b0}}, 4'b1000} : {FW{1'b0}})
                               ^ ((MUT == 9 && lay == 5 && a_tv && a_tp[542:539] == 4'd3 && a_tp[516:512] == 5'd7) ? {{(FW-1){1'b0}}, 1'b1} : {FW{1'b0}});
    // authority / layer programme (compiled stimulus; kvs_ctl u_lprg in the die)
    wire kv_go = act && rel == P_KV_RUN - 30 + (MUT == 1 ? 1 : 0);
    wire kv_issue = act && rel == P_KV_RUN - 8 + (MUT == 1 ? 1 : 0);
    wire kv_run = act && rel == P_KV_RUN + (MUT == 1 ? 1 : 0);
    integer kage; always @* kage = rel - (P_KV_RUN + 1);     // programme age (age 0 = the cycle after the run edge)
    generate if (K_REAL != 0) begin : g_kreal
        xq_dly #(1, KS_RXV - (K_TEAR == 1 ? 1 : 0)) d_rxe (.ck(ck), .a(k_rxe0), .b(a_rxe));
        xq_dly #(FW, KS_RXP) d_rxp (.ck(ck), .a(k_rxp), .b(a_rxp));
        xq_dly #(1, KS_TXS) d_txs (.ck(ck), .a(k_txs0), .b(a_txs));
        xq_dly #(4, KS_TXK) d_txk (.ck(ck), .a(k_tk), .b(a_tk));
        xq_dly #(5, KS_TXB) d_txb (.ck(ck), .a(k_tb), .b(a_tb));
        xq_dly #(1, SK_TXV - (K_TEAR == 2 ? 1 : 0)) d_tv (.ck(ck), .a(a_tv), .b(k_tv0));
        xq_dly #(FW, SK_TXP) d_tp (.ck(ck), .a(a_tpx), .b(k_tp0));
    end else begin : g_kstub_w
        assign a_rxe = k_rxe0; assign a_rxp = k_rxp; assign a_txs = k_txs0; assign a_tk = k_tk; assign a_tb = k_tb;
        assign k_tv0 = a_tv; assign k_tp0 = a_tpx;
    end endgenerate
    generate if (K_REAL == 1) begin : g_kprog
        // the kvs_attn control composition (qkd_kvs_attn wiring of u_attn / u_attn_cal / u_attn_root; face bypassed)
        wire [175:0] cal; wire [15:0] rx_cmd, tx_first, end_age, cal_ep; wire cal_done, cal_valid, cal_f;
        qkd_attn_cal_gen #(.G3S2(1), .RX_CMD(2), .STRETCH(1), .D_QK(28), .D_RL(76), .SERVICE_END(1777), .MUT(0)) u_attn_cal (
            .ck(ck), .rst_n(rst_n), .go(kv_go), .ctx_t(14'(POS + 1)), .epoch(EP), .cal(cal), .rx_cmd(rx_cmd),
            .tx_first(tx_first), .end_age(end_age), .cal_epoch(cal_ep), .done(cal_done), .valid(cal_valid), .fault(cal_f));
        wire req_v, req_rdy, q_rdy, rsv, busy; wire [15:0] req_ep, age; wire [5:0] req_l; wire [17:0] req_pos; wire [175:0] req_cal;
        wire running, start_qk, start_pv, lf, iof; wire [15:0] r_age, r_ep; wire [5:0] r_l; wire [13:0] r_ctx; wire [175:0] r_cal; wire [31:0] r_cyc;
        // RESULT pins (the face's output contract): beat b on programme age TX_FIRST + b, result_done on TX_FIRST + 32
        wire res_v = act && kage >= P_TX_FIRST && kage < P_TX_FIRST + 32;
        wire [4:0] res_b = 5'(kage - P_TX_FIRST);
        wire [511:0] res_d = obeat(kage - P_TX_FIRST, lay) ^ ((MUT == 3 && lay == 5 && kage == P_TX_FIRST + 7) ? 512'd1 : 512'd0);
        wire res_done = act && kage == P_TX_FIRST + 32;
        qkd_native_attention_programme #(.MUT(MUT == 7 ? 3 : 0)) u_attn (.ck(ck), .rst_n(rst_n), .issue(kv_issue), .run(kv_run),
            .fused_program_capability(1'b1), .authority_valid(1'b1), .authority_epoch(EP), .authority_token(TOK),
            .authority_position(18'(POS)), .authority_stage(stage), .compiled_calendar(cal), .compiled_rx_cmd(rx_cmd),
            .compiled_tx_first(tx_first), .compiled_end(end_age), .rx_event(a_rxe), .rx_payload(a_rxp),
            .tx_slot(a_txs), .tx_slot_kind(a_tk), .tx_slot_beat(a_tb), .tx_valid(a_tv), .tx_payload(a_tp),
            .request_valid(req_v), .request_ready(req_rdy), .request_epoch(req_ep), .request_layer(req_l),
            .request_position(req_pos), .request_calendar(req_cal), .q_valid(kq_v), .q_beat(kq_b), .q_data(kq_d),
            .result_valid(res_v), .result_beat(res_b), .result_data(res_d), .result_epoch(EP), .result_layer(layer_id),
            .result_done(res_done), .service_fault(1'b0), .result_reserved(rsv), .busy(busy), .fault(k_pf), .age(age));
        qkd_attn_service_root #(.PV_LEAD(0), .MUT(0)) u_attn_root (.ck(ck), .rst_n(rst_n), .request_valid(req_v),
            .request_ready(req_rdy), .request_epoch(req_ep), .request_layer(req_l), .request_position(req_pos),
            .fused_program_capability(1'b1), .request_calendar(req_cal), .q_valid(kq_v), .q_beat(kq_b), .q_ready(q_rdy),
            .running(running), .start_qk(start_qk), .start_pv(start_pv), .age(r_age), .ep(r_ep), .layer(r_l), .ctx(r_ctx),
            .cal(r_cal), .cycles(r_cyc), .local_fault(lf), .io_fault(iof));
        assign kreq_v = req_v;
        reg sf = 0;
        always @(posedge ck) if (rst_n && (k_pf || lf || iof) && !sf) begin sf <= 1;
            $display("XQ_CAUSE KV programme cyc %0d rel %0d age %0d: ctl local %0d guard %0d record %0d (codec cause {rx_rec,tx_rec,rx_time,tx_time}=%b) slot %0d producer %0d | root lf %0d iof %0d",
                cyc, rel, age, u_attn.ctl.local_fault, u_attn.ctl.guard_fault, u_attn.ctl.record_fault, u_attn.ctl.g_cd.codec.fault_cause,
                u_attn.ctl.slot_fault, u_attn.producer_fault, lf, iof); end
        always @(posedge ck) if (rst_n && (lf || iof || cal_f)) err("KV attention root / calendar fault");
        always @(posedge ck) if (rst_n && kq_v && !q_rdy) err("q_valid without q_ready (no wait exists)");
        always @(posedge ck) if (rst_n && act && kage == 0 && age != 0) err("programme age 0 not on the compiled run edge");
    end else if (K_REAL == 2) begin : g_kattn
        // as-built kvs14c qkd_kvs_attn (vendored): the PV final join beat stream enters the face on its own window
        wire [30:0] pvst; wire [64:0] pvfst; wire [164:0] ahs; wire [536:0] prg; wire [47:0] ac0, ac1, ac2, ac3; wire [7:0] arh;
        wire [76:0] i_ctl = {TOK, kv_go, stage, 18'(POS), EP, 14'(POS + 1), kv_run, kv_issue, 1'b1, 1'b1};
        wire [521:0] srx = {512'd0, 5'd0, 4'd0, a_rxe};
        reg [533:0] fin;
        qkd_kvs_attn u_kattn (.ck(ck), .rst_n(rst_n), .ufs_WS(1'b0), .ufs_WN(1'b0), .ufs_ES(1'b0), .ufs_EN(1'b0), .ufh(1'b0),
            .ufp0(1'b0), .ufp1(1'b0), .uff(1'b0), .ufk_WS(1'b0), .ufk_WN(1'b0), .ufk_ES(1'b0), .ufk_EN(1'b0),
            .d2d__srx(srx), .d2d__rx_payload(a_rxp), .d2d__att_tx_slot(a_txs), .d2d__att_tx_kind(a_tk), .d2d__att_tx_beat(a_tb),
            .fin(fin), .attn__tx_valid(a_tv), .attn__tx_payload(a_tp), .pvst(pvst), .pvfst(pvfst), .ahs(ahs), .prg(prg),
            .acal_WS(ac0), .acal_WN(ac1), .acal_ES(ac2), .acal_EN(ac3), .arh(arh), .i_ctl(i_ctl));
        wire [175:0] fcal = u_kattn.w_attn_root__cal;
        wire [15:0] fpv = fcal[127:112], fp0 = fcal[143:128], fp1 = fcal[159:144];
        wire [15:0] fres = fpv + ((fp0 > fp1) ? fp0 : fp1) + 16'd17;     // face RESULT_AGE (F_DLY 1)
        wire [15:0] fage = u_kattn.w_attn_root__age;
        wire frun = u_kattn.w_attn_root__running && !u_kattn.w_attn_root__start_qk;
        wire [15:0] fb = fage - fres;
        always @* fin = (frun && fage >= fres && fb < 16'd32) ? {obeat(fb, lay), EP, 5'(fb), 1'b1} : 534'd0;
        assign kq_v = prg[19]; assign kq_b = prg[24:20]; assign kq_d = prg[536:25];   // prg = {q_data, q_beat, q_valid, position, request_valid}
        assign kreq_v = prg[0];
        assign k_pf = u_kattn.w_attn__fault;
        reg sf = 0;
        always @(posedge ck) if (rst_n && (k_pf || u_kattn.w_attn_face__result_fault) && !sf) begin sf <= 1;
            $display("XQ_CAUSE kvs_attn cyc %0d rel %0d: programme ctl local %0d guard %0d record %0d (codec cause %b) slot %0d | face result_fault %0d RESULT_AGE %0d (P0 %0d P1 %0d PV %0d R %0d) root age %0d | ctl tx_first %0d",
                cyc, rel, u_kattn.u_attn.ctl.local_fault, u_kattn.u_attn.ctl.guard_fault, u_kattn.u_attn.ctl.record_fault,
                u_kattn.u_attn.ctl.g_cd.codec.fault_cause, u_kattn.u_attn.ctl.slot_fault, u_kattn.w_attn_face__result_fault, fres, fp0, fp1, fpv,
                fcal[175:160], fage, u_kattn.w_attn_cal__tx_first); end
    end else if (K_REAL == 3) begin : g_kfin
        // QXF-FACE: as-built qkd_kvs_attn + real qkd_pv_fin_s (0 die relays on pvfst / fin: PV_LEAD 0, F_DLY 1 as built)
        wire [30:0] pvst; wire [64:0] pvfst; wire [164:0] ahs; wire [536:0] prg; wire [47:0] ac0, ac1, ac2, ac3; wire [7:0] arh;
        wire [76:0] i_ctl = {TOK, kv_go, stage, 18'(POS), EP, 14'(POS + 1), kv_run, kv_issue, 1'b1, 1'b1};
        wire [521:0] srx = {512'd0, 5'd0, 4'd0, a_rxe};
        wire [533:0] fin; wire uff;
        qkd_kvs_attn u_kattn (.ck(ck), .rst_n(rst_n), .ufs_WS(1'b0), .ufs_WN(1'b0), .ufs_ES(1'b0), .ufs_EN(1'b0), .ufh(1'b0),
            .ufp0(1'b0), .ufp1(1'b0), .uff(uff), .ufk_WS(1'b0), .ufk_WN(1'b0), .ufk_ES(1'b0), .ufk_EN(1'b0),
            .d2d__srx(srx), .d2d__rx_payload(a_rxp), .d2d__att_tx_slot(a_txs), .d2d__att_tx_kind(a_tk), .d2d__att_tx_beat(a_tb),
            .fin(fin), .attn__tx_valid(a_tv), .attn__tx_payload(a_tp), .pvst(pvst), .pvfst(pvfst), .ahs(ahs), .prg(prg),
            .acal_WS(ac0), .acal_WN(ac1), .acal_ES(ac2), .acal_EN(ac3), .arh(arh), .i_ctl(i_ctl));
        // pair / reciprocal stimuli on pvfin's compiled slots: input for edge k after the start edge (pvfst start sampled)
        integer fk = -1; reg [15:0] s_p0 = 0, s_p1 = 0, s_r = 0, s_ep = 0;
        always @(posedge ck) if (rst_n) begin
            if (pvfst[0]) begin fk <= 1; s_p0 <= pvfst[32:17]; s_p1 <= pvfst[48:33]; s_r <= pvfst[64:49]; s_ep <= pvfst[16:1]; end
            else if (fk >= 1 && fk < 20000) fk <= fk + 1;
        end
        wire f0v = fk >= 1 && fk >= s_p0 && fk < s_p0 + 32, f1v = fk >= 1 && fk >= s_p1 && fk < s_p1 + 32, frv = fk >= 1 && fk == s_r;
        wire [4:0] f0b = 5'(fk - s_p0), f1b = 5'(fk - s_p1);
        wire [127:0] rzw = {1'b0, 8'd123, 23'd0, 1'b0, 8'd124, 23'd0, 1'b0, 8'd125, 23'd0, 1'b0, 8'd126, 23'd0};   // head h: 2^-(h+1)
        wire fo_v; wire [4:0] fo_b; wire [15:0] fo_e; wire [511:0] fo_d;
        qkd_pv_fin_s #(.ADD_LAT(7), .MUL_LAT(6), .SKEW(1), .MUT(FIN_MUT)) u_fin (.ck(ck), .rst_n(rst_n),
            .start(pvfst[0]), .epoch(pvfst[16:1]), .cal(pvfst[64:17]),
            .p0_valid(f0v), .p0_beat(f0b), .p0_epoch(s_ep), .p0_data(f0v ? pbeat(f0b, lay) : 512'd0),
            .p1_valid(f1v), .p1_beat(f1b), .p1_epoch(s_ep), .p1_data(f1v ? pbeat(f1b, lay) : 512'd0),
            .rz_valid(frv), .rz_epoch(s_ep), .rz(rzw),
            .out_valid(fo_v), .out_beat(fo_b), .out_epoch(fo_e), .out_data(fo_d), .fault(uff));
        assign fin = {fo_d, fo_e, fo_b, fo_v};
        wire [175:0] fcal = u_kattn.w_attn_root__cal;
        wire [15:0] fpv = fcal[127:112], fp0 = fcal[143:128], fp1 = fcal[159:144], fr = fcal[175:160];
        assign kq_v = prg[19]; assign kq_b = prg[24:20]; assign kq_d = prg[536:25];
        assign kreq_v = prg[0];
        assign k_pf = u_kattn.w_attn__fault;
        reg sf = 0, fl = 0;
        always @(posedge ck) if (rst_n && act && fo_v && fo_b == 0 && !fl) begin fl <= 1;
            $display("XQ_FIN layer %0d T %0d: pvfin beat0 at root age %0d = PV %0d + max(P0 %0d, P1 %0d, R %0d) + 17 -> %0d | programme tx_first %0d",
                lay, POS + 1, u_kattn.w_attn_root__age, fpv, fp0, fp1, fr,
                fpv + ((fp0 > fp1) ? ((fp0 > fr) ? fp0 : fr) : ((fp1 > fr) ? fp1 : fr)) + 17, u_kattn.w_attn_cal__tx_first); end
        always @(posedge ck) if (rst_n && (k_pf || u_kattn.w_attn_face__result_fault || uff) && !sf) begin sf <= 1;
            $display("XQ_CAUSE kvs_attn+pvfin cyc %0d rel %0d: programme ctl local %0d record %0d (codec cause %b) | face result_fault %0d | pvfin fault %0d | cal P0 %0d P1 %0d PV %0d R %0d root age %0d | ctl tx_first %0d",
                cyc, rel, u_kattn.u_attn.ctl.local_fault, u_kattn.u_attn.ctl.record_fault, u_kattn.u_attn.ctl.g_cd.codec.fault_cause,
                u_kattn.w_attn_face__result_fault, uff, fp0, fp1, fpv, fr, u_kattn.w_attn_root__age, u_kattn.w_attn_cal__tx_first); end
        always @(posedge ck) if (rst_n && act && (uff || u_kattn.w_attn_face__result_fault || u_kattn.w_attn_cal__fault)) err("pvfin / result face / calendar fault");
    end else begin : g_kstub
        wire r_ev = act && (rel >= P_RS && rel < P_RS + 32 || rel == P_RE);
        wire [3:0] r_kind = rel == P_RE ? 4'd4 : 4'd3;
        wire [4:0] r_beat = rel == P_RE ? 5'd0 : 5'(rel - P_RS);
        wire [511:0] st_word;    // the producers' STATUS encoder (namespace {q_ready, done, fault, busy, ready})
        qkd_native_status_word u_st_word (.q_ready(1'b0), .done(1'b1), .fault(1'b0), .busy(1'b0), .ready(1'b1), .word(st_word));
        wire [511:0] r_data = rel == P_RE ? ((MUT == 5) ? 512'd0 : st_word) : obeat(rel - P_RS, lay) ^ ((MUT == 3 && lay == 5 && rel == P_RS + 7) ? 512'd1 : 512'd0);
        wire ka_rv; wire [3:0] ka_rk, ka_fc; wire [15:0] ka_re; wire [5:0] ka_rl; wire [4:0] ka_rb; wire [511:0] ka_rd;
        qkd_native_attention_record #(.KV_SIDE(1)) u_ka (.ck(ck), .rst_n(rst_n & ~k_eb),
            .tx_event(r_ev), .tx_expected(k_txs0), .tx_kind(r_kind), .tx_expected_kind(k_tk),
            .tx_epoch(EP), .tx_expected_epoch(EP), .tx_layer(layer_id), .tx_expected_layer(layer_id),
            .tx_beat(r_beat), .tx_expected_beat(k_tb), .tx_data(r_data), .tx_valid(a_tv), .tx_payload(a_tp),
            .rx_event(a_rxe), .rx_expected(k_rxs0), .rx_payload(a_rxp), .rx_expected_kind(k_rk),
            .rx_expected_epoch(EP), .rx_expected_layer(layer_id), .rx_expected_beat(k_rb),
            .rx_valid(ka_rv), .rx_kind(ka_rk), .rx_epoch(ka_re), .rx_layer(ka_rl), .rx_beat(ka_rb), .rx_data(ka_rd),
            .fault(k_pf), .fault_cause(ka_fc));
        assign kq_v = ka_rv && ka_rk == 4'd2; assign kq_b = ka_rb; assign kq_d = ka_rd;
        assign kreq_v = ka_rv && ka_rk == 4'd1;
        reg sf = 0;
        always @(posedge ck) if (rst_n && k_pf && !sf) begin sf <= 1; $display("XQ_CAUSE KV stub codec cyc %0d rel %0d cause %b", cyc, rel, ka_fc); end
    end endgenerate

    // ================================================================== checks + measurement
    reg seen_end = 0, seen_n = 0, seen_k = 0;
    always @(posedge ck) if (rst_n && act) begin
        // producer issue on the compute side (native59 / stub codec output pins)
        if (p_tv) begin
            if (p_tp[542:539] == 4'd1) begin
                m_cmd_iss = rel;
                if (p_tp[511:0] !== {493'd0, 5'd0, POS, 1'b1} || p_tp[538:533] != layer_id || p_tp[532:517] != EP) err("CMD record");
            end else if (p_tp[542:539] == 4'd2) begin
                if (p_tp[516:512] == 0) m_q0_iss = rel;
                if (p_tp[516:512] == 31) m_q31_iss = rel;
                if (p_tp[511:0] !== qbeat(p_tp[516:512], lay) || p_tp[538:533] != layer_id) err("Q beat != golden at the compute producer");
                nq_iss = nq_iss + 1;
            end else err("compute TX record kind");
        end
        // KV consumer land
        if (kreq_v) m_cmd_land = rel;
        if (kq_v) begin
            if (kq_b == 0) m_q0_land = rel;
            if (kq_b == 31) m_q31_land = rel;
            if (kq_d !== qbeat(kq_b, lay)) err("Q beat != golden at the KV consumer");
            nq_land = nq_land + 1;
        end
        // KV producer issue
        if (a_tv) begin
            if (a_tp[542:539] == 4'd3) begin
                if (a_tp[516:512] == 0) m_r0_iss = rel;
                if (a_tp[516:512] == 31) m_r31_iss = rel;
                nr_iss = nr_iss + 1;
            end else if (a_tp[542:539] == 4'd4) m_st_iss = rel;
            else err("KV TX record kind");
        end
        // compute consumer land (dr_o group 0 into the DV return chain)
        if (dr[519] && !dr[518]) begin
            if (dr[516:512] == 0) m_r0_land = rel;
            if (dr[516:512] == 31) m_r31_land = rel;
            if (dr[511:0] !== obeat(dr[516:512], lay)) err("RESULT beat != golden at the compute consumer");
            nr_land = nr_land + 1;
        end
        if (n_done) m_done = rel;
        // STATUS at the compute consumer pins: bit-exact against the namespace word {q_ready 0, done 1, fault 0, busy 0, ready 1}
        if (C_REAL != 0 && n_rxv && n_rxp[542:539] == 4'd4) begin
            m_st_land = rel;
            if (n_rxp[511:0] !== {507'd0, 5'b01001}) err("STATUS word at the compute consumer != namespace {0,1,0,0,1}");
        end
        // KVN: compute x3 out -> KV d2d word
        if (p_x3[523]) begin
            if (nk_iss < 4) kvq[nk_iss] = {p_x3g, p_x3id, p_x3};
            if (nk_iss == 0) m_k0_iss = rel;
            if (nk_iss == 3) m_k3_iss = rel;
            nk_iss = nk_iss + 1;
        end
        if (kw_v) begin
            if (nk_land >= nk_iss || kw_data !== kvq[nk_land][511:0] || kw_tag !== kvq[nk_land][522:512] ||
                kw_id !== kvq[nk_land][582:524] || kw_gen !== kvq[nk_land][584:583] || !kw_slot) err("KVN word at the KV end != the compute x3 word");
            if (nk_land == 0) m_k0_land = rel;
            if (nk_land == 3) m_k3_land = rel;
            nk_land = nk_land + 1;
        end
        if (s_rv) ns_res = ns_res + 1;
        // sticky faults: reported once each, with the first-fault cause (witness)
        if ((c_f || k_f || c_abort || k_abort) && !seen_end) begin seen_end = 1; err("D2D end fault / epoch abort in a normal layer");
            $display("XQ_CAUSE d2d: compute fault %0d abort %0d end_fault %0d cause %b | KV fault %0d abort %0d end_fault %0d cause %b",
                c_f, c_abort, u_c.u_core.u_end.end_fault, u_c.u_core.u_end.fault_cause, k_f, k_abort, u_k.u_core.u_end.end_fault, u_k.u_core.u_end.fault_cause); end
        if (n_fault && !seen_n) begin seen_n = 1; err("compute producer/consumer fault"); end
        if (k_pf && !seen_k) begin seen_k = 1; err("KV producer/consumer fault"); end
    end
    // static: the per-layer measurement must be identical every layer
    integer ref_v [0:16]; integer cur [0:16]; integer ml, k;
    task automatic layer_end(input integer L);
        begin
            cur[0] = m_cmd_iss; cur[1] = m_q0_iss; cur[2] = m_q31_iss; cur[3] = m_cmd_land; cur[4] = m_q0_land; cur[5] = m_q31_land;
            cur[6] = m_r0_iss; cur[7] = m_r31_iss; cur[8] = m_st_iss; cur[9] = m_r0_land; cur[10] = m_r31_land;
            cur[11] = m_k0_iss; cur[12] = m_k3_iss; cur[13] = m_k0_land; cur[14] = m_k3_land; cur[15] = m_done; cur[16] = (C_REAL != 0) ? m_st_land : 0;
            $display("XQ_MEAS layer=%0d cmd_issue=%0d q0_issue=%0d q31_issue=%0d cmd_land=%0d q0_land=%0d q31_land=%0d r0_issue=%0d r31_issue=%0d status_issue=%0d r0_land=%0d r31_land=%0d kvn0_issue=%0d kvn3_issue=%0d kvn0_land=%0d kvn3_land=%0d done=%0d status_land=%0d nq=%0d/%0d nr=%0d/%0d nk=%0d/%0d st=%0d",
                L, cur[0], cur[1], cur[2], cur[3], cur[4], cur[5], cur[6], cur[7], cur[8], cur[9], cur[10], cur[11], cur[12], cur[13], cur[14], cur[15], cur[16],
                nq_iss, nq_land, nr_iss, nr_land, nk_iss, nk_land, ns_res);
            if (nq_iss != 32 || nq_land != 32 || nr_iss != 32 || nr_land != 32 || nk_iss != 4 || nk_land != 4 || ns_res != 1 || m_done < 0)
                err("per-layer counts (32 Q, 32 RESULT, 4 KVN, 1 status, completion)");
            for (k = 0; k < 17; k = k + 1) begin
                if (cur[k] < 0) err("an exchange event never happened");
                if (L == 1) ref_v[k] = cur[k]; else if (cur[k] != ref_v[k]) err("latency differs between layers (not static)");
            end
        end
    endtask
    task automatic layer_clear;
        begin m_cmd_iss = -1; m_q0_iss = -1; m_q31_iss = -1; m_cmd_land = -1; m_q0_land = -1; m_q31_land = -1; m_r0_iss = -1;
            m_r31_iss = -1; m_st_iss = -1; m_r0_land = -1; m_r31_land = -1; m_st_land = -1; m_k0_iss = -1; m_k3_iss = -1;
            m_k0_land = -1; m_k3_land = -1; m_done = -1; nq_iss = 0; nq_land = 0; nr_iss = 0; nr_land = 0; nk_iss = 0; nk_land = 0; ns_res = 0; end
    endtask

    // ================================================================== sequence
    integer i, l;
    task tick(input integer n); repeat (n) @(negedge ck); endtask
    initial begin
        layer_clear;
        $readmemh({CALDIR, "/cal_C_tx.memh"}, img_ct); $readmemh({CALDIR, "/cal_C_rx.memh"}, img_cr);
        $readmemh({CALDIR, "/cal_K_tx.memh"}, img_kt); $readmemh({CALDIR, "/cal_K_rx.memh"}, img_kr);
        tick(3); por_n = 1; tick(3); rst_n = 1; tick(2);
        for (i = 0; i < 32; i = i + 1) begin
            cfg_a = 5'(i); cfg_dc = img_ct[i]; cfg_dk = img_kt[i]; cfg_c_tx = 1; cfg_k_tx = 1; tick(1);
            cfg_c_tx = 0; cfg_k_tx = 0; cfg_dc = img_cr[i]; cfg_dk = img_kr[i]; cfg_c_rx = 1; cfg_k_rx = 1; tick(1);
            cfg_c_rx = 0; cfg_k_rx = 0;
        end
        wait (k_up && c_up); tick(2);
        host_boot = 1; tick(1); host_boot = 0; wait (k_eb); tick(100);
        for (l = 1; l <= NL; l = l + 1) begin
            layer_clear;
            lay = l; lstart = cyc + 1 + LEAD; cstart = 1; tick(1); cstart = 0;
            tick(P_PERIOD - 1);
            layer_end(l);
        end
        lay = -1; tick(20);
        $display("XQ_E C2K_cmd_issue_to_land=%0d C2K_q31_issue_to_land=%0d C2K_q_first_issue_to_last_land=%0d K2C_r31_issue_to_land=%0d K2C_r0_issue_to_land=%0d K2C_r_first_issue_to_last_land=%0d KVN_k3_issue_to_land=%0d roundtrip_cmd_issue_to_r31_land=%0d kv_service_cmd_land_to_r31_issue=%0d compute_done_after_r31_land=%0d K2C_status_issue_to_land=%0d",
            ref_v[3] - ref_v[0], ref_v[5] - ref_v[2], ref_v[5] - ref_v[0], ref_v[10] - ref_v[7], ref_v[9] - ref_v[6], ref_v[10] - ref_v[6],
            ref_v[14] - ref_v[12], ref_v[10] - ref_v[0], ref_v[7] - ref_v[3], ref_v[15] - ref_v[10], ref_v[16] - ref_v[8]);
        $display("XQ_CFG C_REAL=%0d K_REAL=%0d QGAP=%0d PHY=%0d TXL=%0d X=%0d period=%0d stages C %0d,%0d,%0d,%0d,%0d,%0d K %0d,%0d,%0d,%0d,%0d,%0d,%0d MUT=%0d layers=%0d",
            C_REAL, K_REAL, QGAP, P_PHY, P_TXL, P_X, P_PERIOD, CS_TXS, CS_RXV, CS_RXP, CS_X3S, SC_TX, SC_X3,
            KS_RXV, KS_RXP, KS_TXS, KS_TXK, KS_TXB, SK_TXV, SK_TXP, MUT, NL);
        if (errs == 0) $display("XQ_PASS layers=%0d bit-exact Q/RESULT/KVN, every landing on its compiled cycle, no fault", NL);
        else $display("XQ_FAIL errors=%0d", errs);
        $finish;
    end
endmodule
