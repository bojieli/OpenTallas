// Full 36-layer compiler-image link composition. External payload stimuli only; not native compute qualification.
`timescale 1ns/1ps
// Q-LINK 2026-10-15 DIE-NAME bench (qfd_d2d_static + qkd_d2d_static, as bound in the die netlists). Derived from
// tb_qwen_d2d_static; adds the KVN path (real qfd_kvn_static_transport -> kind 5 -> KV writer face). Component bench: compute-die end + KV/system-die end of the static D2D link through a behavioural
// UCIe PHY pair (the only modelled part). Real RTL: both static ends (calendars, slot SRAM/CRC links), the typed
// native attention record codecs on both dies, the kind-15 status codec, the recovery controllers and the HOST
// link-service collector. Stimuli (Q / RESULT data, compute status levels, HOST reset / clear) are declared external
// inputs at this component boundary. Calendars are the compiler images of tools/qwen_split/d2d_link_calendar.py,
// loaded through the cfg port before boot.
//
// Checks: every frame arrives and is decoded at its compiled cycle (exact cycle, payload bit-exact), no fault in normal
// epochs; recovery scenario: one corrupted PHY bit -> KV CRC abort -> compute missing-frame abort -> drain -> HOST link
// reset -> retrain -> forwarded epoch -> exact replay of the layer; witnesses and typed faults checked.
// MUT: 1 compute write slot +1, 2 KV RX demux swap, 3 producer fires 1 cycle late, 4 calendar compiled with a wrong TXL
//      (run script), 5 kind-15 status record STALE from layer 7 on: the compute die stamps its status record with the
//      previous epoch (op_epoch-1) -> the KV ot_qwen_d2d_status_rx epoch16 header check must fault (LAYERBENCH 10-18).
module tb_qwen_d2d_program;
    `include "program_params.svh"
    `include "txdp.svh"   // QXF-LINK F4: the masters' TXDP from the same compile (d2d_link_calendar.py)
    wire integer qs = P_QS;
    wire integer rs = P_RS + (lay == 0 ? P_RDELTA : 0);
    wire integer re = P_RE + (lay == 0 ? P_RDELTA : 0);
    localparam integer ks = P_QS + 33, ss = P_SS;
    reg [31:0] layer_starts [0:35];
    parameter integer MUT = 0, DRV = 0, KV_PIN_SEQ = 0, PR = 1, TXL = 6, PHY = 5, P = 110, NLAY = 36, BAD_LAYER = -1;
    parameter CALDIR = "cal";
    localparam integer FW = 548, PW = 583;
    reg ck = 0; always #0.4167 ck = ~ck;
    reg por_n = 0, rst_n = 0;
    integer cyc = 0; always @(posedge ck) cyc <= cyc + 1;

    // ---------------- calendars (compiler images) ----------------
    reg [31:0] img_ct [0:31], img_cr [0:31], img_kt [0:31], img_kr [0:31];
    reg [31:0] s1_ct [0:0], s1_cr [0:0], s1_kt [0:0], s1_kr [0:0];   // segment-1 bases (compiler)
    reg cfg_c_tx = 0, cfg_c_rx = 0, cfg_k_tx = 0, cfg_k_rx = 0; reg [4:0] cfg_a = 0; reg cfg_hi = 0; reg [31:0] cfg_dc = 0, cfg_dk = 0;

    // ---------------- PHY pair (behavioural) ----------------
    wire c_ptx_v, k_ptx_v, c_prx_v, k_prx_v, c_up, k_up; wire [PW-1:0] c_ptx, k_ptx, c_prx, k_prx;
    wire c_lv, k_lv; wire [PW-1:0] c_lf, k_lf;
    reg corrupt = 0;
    integer bad_armed = 0;   // set by the sequence for the exceptional layer only
    wire c_phy_rst_n, k_phy_rst_n;
    ot_qkvd_ucie_x64_phy_model #(.LAT(PHY), .FW(PW)) u_cphy (.clk(ck), .rst_n(c_phy_rst_n), .tx_up(c_up),
        .tx_v(c_ptx_v), .tx_flit(c_ptx), .rx_v(c_prx_v), .rx_flit(c_prx), .link_v(c_lv), .link_flit(c_lf),
        .far_v(k_lv), .far_flit(k_lf));
    ot_qkvd_ucie_x64_phy_model #(.LAT(PHY), .FW(PW)) u_kphy (.clk(ck), .rst_n(k_phy_rst_n), .tx_up(k_up),
        .tx_v(k_ptx_v), .tx_flit(k_ptx), .rx_v(k_prx_v), .rx_flit(k_prx), .link_v(k_lv), .link_flit(k_lf),
        .far_v(c_lv), .far_flit(c_lf ^ (corrupt ? {{(PW-77){1'b0}}, 1'b1, 76'd0} : {PW{1'b0}})));

    reg host_reset_req = 0, host_clear = 0, host_boot = 0;
    wire fwd_ep, fwd_lrst_n; reg [2:0] bump_ep = 0, bump_lr = 3'b111;
    always @(posedge ck) begin bump_ep <= {bump_ep, fwd_ep}; bump_lr <= {bump_lr, fwd_lrst_n}; end
    integer lay = -1, lstart = 0;
    reg cstart = 0, cseg = 0;
    integer tok = 0, tstart = 0, trel = 0, emb_ok = 0, tok_res = 0, emb_hdr = 0, prec_c = 0, prec_auth = 0, prec_ctx = 0, prec_w = 0;
    wire c_prog_rxv, c_prog_auth, c_prog_ctx, c_prog_wslot;
    // program-record producers (declared external stimulus at this boundary: the KV HOST record port and the compute
    // qfd_sys_face): every reserved slot carries a record (observed = 1; an empty reserved slot is an ownership fault),
    // presented after the pin-registered slot strobe at the port-1 codec latency (KV TXD 4: two edges; compute TXD 3: one edge)
    reg [1:0] h_rec_d = 0, c_wit_d = 0; reg [1:0] h_sk_d1 = 0, h_sk_d2 = 0;
    always @(posedge ck) begin h_rec_d <= {h_rec_d[0], h_sk != 2'd0}; c_wit_d <= {c_wit_d[0], c_prog_wslot};
                               h_sk_d1 <= h_sk; h_sk_d2 <= h_sk_d1; end
    wire h_rec_v = h_rec_d[1]; wire [547:0] h_rec_p = h_rec_v ? {18'h2a5a5, 2'(h_sk_d2), 528'h5eed} : 548'd0;
    wire c_wit_v = c_wit_d[0]; wire [547:0] c_wit_p = c_wit_v ? {18'h2a5a5, 2'd3, 528'h717} : 548'd0;
    always @* trel = cyc - tstart;
    wire c_txs0, c_rxe0, c_rxs0, k_txs0, k_rxe0, k_rxs0; wire [3:0] c_tk, k_tk, c_rk, k_rk; wire [4:0] c_tb, k_tb, c_rb, k_rb;
    wire [FW-1:0] c_rxp, k_rxp; wire c_tv0, k_tv0; wire [FW-1:0] c_tp0, k_tp0;
    wire c_abort, k_abort, c_f, k_f; wire [7:0] c_tf, h_tf; wire [31:0] k_rcyc;
    wire [1:0] h_lu; wire h_ld, h_ls, h_rt; wire [3:0] h_ad;
    wire h_kvd, h_vmd, h_cod, h_hd, h_cb, h_kf, h_ar, h_cf, h_ea, h_wv, h_rxv; wire [1:0] h_sk; wire [547:0] h_rx;
    wire s_rv, s_rd, s_rf; wire [3:0] s_rc; wire [58:0] s_rt; wire [1:0] s_rg; wire [17:0] s_rtok; wire [31:0] s_rval, s_rcyc;
    wire kv_x3_slot; wire [523:0] x3; wire [58:0] x3_id; wire [1:0] x3_gen; wire kvt_f;
    wire kw_v, kw_slot; wire [10:0] kw_tag; wire [511:0] kw_data; wire [58:0] kw_id; wire [1:0] kw_gen, kw_idx;
    wire [15:0] op_epoch = 16'h0400;
    wire [5:0]  op_layer = 6'(lay % 36);
    wire [58:0] op_tag = {op_epoch, op_layer + 6'd1, 18'd4242, 13'd77, 6'd0};
    wire st_res;
    wire c_emb_v, c_emb_s, k_emb_slot;
    // KV die embedding provider face (declared external stimulus at this component boundary): the staged row word is
    // presented one edge after its compiled slot (codec latency 1)
    reg k_emb_v = 0; reg [547:0] k_emb_p = 0;
    function automatic [547:0] eword(input integer w);
        eword = {20'(32'hE0000 + w), 16'h3f80, word(77, 6, w)};
    endfunction
    // kind-8 row header (qfd_sys_face layout: {token18, 6'd0, 12'd0, DATA = epoch16 [47:32], scale16 [15:0]})
    localparam [547:0] EHDR = {18'h2a5a5, 6'd0, 12'd0, 464'd0, 16'h0400, 16'd0, 16'h3f80};
    always @(posedge ck) begin k_emb_v <= k_emb_slot;
        k_emb_p <= !k_emb_slot ? 548'd0 : k_tk == 4'd8 ? EHDR : eword(k_tk == 4'd7 ? 32 + k_tb : k_tb); end
    wire c_eb = u_c.u_core.eb, k_eb = u_k.u_core.eb; wire [7:0] c_ep = u_c.u_core.ep, k_ep = u_k.u_core.ep;
    // pin-registered masters (PR): producers see their slot 2 edges after cal_start (cal_start pin flop + slot pin
    // flop); a consumer sees a frame 4 edges later than the unregistered end (net TX +1, PHY pin flops +2, RX pin flop +1)
    // DRV = 1: the die-name calendar sequencers (qfd/qkd_d2d_cal_seq, compiler images as constants) drive cfg_* /
    // cal_start / cal_seg; the bench's own compiled sequence becomes the cycle-exact reference they must match.
    // MUT 6: sequencer start table one edge late at layer 7 (must FAIL). MUT 7: KV anchor skew one edge short (must FAIL).
    reg tok_go = 0;
    wire q_c_tx, q_c_rx, q_k_tx, q_k_rx, q_c_cs, q_c_sg, q_k_cs, q_k_sg, q_c_rdy, q_k_rdy, q_c_run, q_k_run, q_c_f, q_k_f;
    wire [5:0] q_c_a, q_k_a, q_c_l, q_k_l; wire [31:0] q_c_d, q_k_d;
    localparam [20*36-1:0] SADJ = (MUT == 6) ? (720'd1 << (20 * 7)) : 720'd0;
    // r2: both sequencers run the ADMISSION segment once per epoch at D2D_ADM_OFS after the forwarded epoch strobe; the
    // compute one sees the strobe at its fwd_epoch pin (after the package bump, bump_ep[2]), the KV one at its own
    // fwd_epoch output EP_SKEW = 3 edges earlier.  KV token starts are AUTO (D2D_FIRST_TOKEN, then D2D_TOKEN_PERIOD);
    // the compute token go is the face's (here: the bench issues it on the KV's internal token go, and checks the
    // anchor offset to the compute strobe separately).
    wire q_c_ad, q_k_ad, q_c_ts, q_k_ts;
    qfd_d2d_cal_seq #(.START_ADJ(SADJ)) u_cseq (.ck(ck), .rst_n(rst_n), .reload(1'b0), .tok_go(tok_go), .epoch_go(bump_ep[2]),
        .halt(c_abort), .cfg_tx_we(q_c_tx), .cfg_rx_we(q_c_rx), .cfg_addr(q_c_a), .cfg_data(q_c_d), .cal_start(q_c_cs), .cal_seg(q_c_sg),
        .cal_ready(q_c_rdy), .running(q_c_run), .layer(q_c_l), .adm_done(q_c_ad), .tok_start(q_c_ts), .fault(q_c_f));
    generate if(KV_PIN_SEQ) begin: pin_calendar
    qkd_d2d_cal_seq_pin #(.EP_SKEW(MUT == 7 ? 2 : 3)) u_kseq (.ck(ck), .rst_n(rst_n), .reload(1'b0), .epoch_go(fwd_ep), .halt(k_abort),
        .cfg_tx_we(q_k_tx), .cfg_rx_we(q_k_rx), .cfg_addr(q_k_a), .cfg_data(q_k_d), .cal_start(q_k_cs), .cal_seg(q_k_sg),
        .cal_ready(q_k_rdy), .running(q_k_run), .layer(q_k_l), .adm_done(q_k_ad), .tok_start(q_k_ts), .fault(q_k_f));
    end else begin: raw_calendar
    qkd_d2d_cal_seq #(.EP_SKEW(MUT == 7 ? 2 : 3)) u_kseq (.ck(ck), .rst_n(rst_n), .reload(1'b0), .tok_go(1'b0), .epoch_go(fwd_ep), .halt(k_abort),
        .cfg_tx_we(q_k_tx), .cfg_rx_we(q_k_rx), .cfg_addr(q_k_a), .cfg_data(q_k_d), .cal_start(q_k_cs), .cal_seg(q_k_sg),
        .cal_ready(q_k_rdy), .running(q_k_run), .layer(q_k_l), .adm_done(q_k_ad), .tok_start(q_k_ts), .fault(q_k_f));
    end endgenerate
    integer c_ep_rise = -1, adm_c = -1, adm_k = -1, adm_auth = 0, adm_w = 0, adm_ctx = 0; reg bep_q = 0;
    always @(posedge ck) begin
        bep_q <= bump_ep[2];
        if (bump_ep[2] && !bep_q) c_ep_rise = cyc;
        if (q_c_cs && q_c_l == 6'h3f) adm_c = cyc;
        if (q_k_cs && q_k_l == 6'h3f) adm_k = cyc;
        if (!tok && lay < 0) begin
            if (c_prog_auth) adm_auth = adm_auth + 1;
            if (c_prog_ctx) adm_ctx = adm_ctx + 1;
            if (h_wv) adm_w = adm_w + 1;
        end
    end
    localparam integer LEAD = 2 * PR, XL = TXL + PHY + 4 * PR,
                       XS = TXL + PHY + 2 * PR;   // compute STATUS codec is inside the master: no slot/payload pin flops
    qfd_d2d_static #(.MUT(MUT == 1 ? 1 : 0), .PR(PR), .TXDP(QFD_D2D_TXDP)) u_c (.ck(ck), .por_n(por_n), .rst_n(rst_n),
        .cfg_tx_we(DRV ? q_c_tx : cfg_c_tx), .cfg_rx_we(DRV ? q_c_rx : cfg_c_rx), .cfg_addr(DRV ? q_c_a : {cfg_hi, cfg_a}),
        .cfg_data(DRV ? q_c_d : cfg_dc), .cal_start(DRV ? q_c_cs : cstart), .cal_seg(DRV ? q_c_sg : cseg),
        .fwd_epoch(bump_ep[2]), .fwd_link_rst_n(bump_lr[2]),
        .native_tx_slot(c_txs0), .native_tx_slot_kind(c_tk), .native_tx_slot_beat(c_tb), .native_tx_v(c_tv0),
        .native_tx_payload(c_tp0), .rx_payload(c_rxp), .native_rx_v(c_rxe0), .native_rx_slot(c_rxs0),
        .native_rx_slot_kind(c_rk), .native_rx_slot_beat(c_rb),
        .prog_witness_slot(c_prog_wslot), .prog_auth_slot(c_prog_auth), .prog_context_slot(c_prog_ctx), .prog_tx_observed_v(c_wit_v), .prog_tx_record(c_wit_p),
        .prog_rx_v(c_prog_rxv), .emb_rx_v(c_emb_v), .emb_rx_slot(c_emb_s),
        .kv_x3_slot(kv_x3_slot), .x3(x3), .x3_identity(x3_id), .x3_generation(x3_gen),
        .status_epoch16((MUT == 5 && lay >= 7) ? op_epoch - 16'd1 : op_epoch), .vm_drained(lay[0]), .collective_drained(~lay[0]), .collective_busy(lay[1]),
        .crom_fault(1'b0), .execution_active(1'b1), .admit_ready(lay[0] ^ lay[1]),
        .result_v(st_res), .result_done(1'b1), .result_fault(1'b0), .result_cause(4'd0), .result_tag(59'(lay * 4093 + 11)),
        .result_gen(2'(lay)), .result_token(18'(lay * 1001)), .result_value(32'(lay * 77)), .result_cycles(32'(lay * 1052)),
        .fdi_tx_up(c_up), .fdi_tx_v(c_ptx_v), .fdi_tx_flit(c_ptx), .fdi_rx_v(c_prx_v), .fdi_rx_flit(c_prx),
        .phy_rst_n(c_phy_rst_n), .epoch_abort(c_abort), .transport_fault(c_tf), .fault(c_f));
    qkd_d2d_static #(.MUT(MUT == 2 ? 2 : 0), .PR(PR), .TXDP(QKD_D2D_TXDP)) u_k (.ck(ck), .por_n(por_n), .rst_n(rst_n),
        .cfg_tx_we(DRV ? q_k_tx : cfg_k_tx), .cfg_rx_we(DRV ? q_k_rx : cfg_k_rx), .cfg_addr(DRV ? q_k_a : {cfg_hi, cfg_a}),
        .cfg_data(DRV ? q_k_d : cfg_dk), .cal_start(DRV ? q_k_cs : cstart), .cal_seg(DRV ? q_k_sg : cseg),
        .host_link_reset_req(host_reset_req), .host_recovery_clear(host_clear), .host_boot_begin(host_boot),
        .fwd_epoch(fwd_ep), .fwd_link_rst_n(fwd_lrst_n),
        .att_tx_slot(k_txs0), .att_tx_kind(k_tk), .att_tx_beat(k_tb), .att_tx_v(k_tv0), .att_tx_payload(k_tp0),
        .att_rx_v(k_rxe0), .att_rx_slot(k_rxs0), .att_rx_kind(k_rk), .att_rx_beat(k_rb), .rx_payload(k_rxp),
        .emb_tx_slot(k_emb_slot), .emb_tx_v(k_emb_v), .emb_tx_payload(k_emb_p),
        .record_tx_observed_v(h_rec_v), .record_tx(h_rec_p), .record_send_kind(h_sk), .record_witness_slot(h_wv),
        .record_rx_v(h_rxv), .record_rx(h_rx),
        .kvn_compiled_identity(op_tag), .kvn_compiled_generation(2'(lay)),
        .kvn_word_valid(kw_v), .kvn_word_tag(kw_tag), .kvn_word_data(kw_data), .kvn_word_identity(kw_id),
        .kvn_word_generation(kw_gen), .kvn_word_slot(kw_slot), .kvn_word_index(kw_idx),
        .status_epoch16(op_epoch), .serdes_up(1'b1), .kv_drained_local(1'b1), .kv_flush_local(1'b0),
        .host_drained_local(1'b1), .kv_active_local(1'b0),
        .link_up(h_lu), .transport_fault(h_tf), .native_links_drained(h_ld), .native_link_reset_seen(h_ls),
        .native_retrained(h_rt), .abort_drained(h_ad), .native_kv_drained(h_kvd), .native_vm_drained(h_vmd),
        .native_collective_drained(h_cod), .native_host_drained(h_hd), .native_collective_busy(h_cb),
        .native_kv_flush(h_kf), .native_admit_ready(h_ar), .crom_fault(h_cf), .execution_active(h_ea),
        .engine_result_v(s_rv), .engine_result_done(s_rd), .engine_result_fault(s_rf), .engine_result_cause(s_rc),
        .engine_result_tag(s_rt), .engine_result_gen(s_rg), .engine_result_token(s_rtok),
        .engine_result_value(s_rval), .engine_result_cycles(s_rcyc),
        .fdi_tx_up(k_up), .fdi_tx_v(k_ptx_v), .fdi_tx_flit(k_ptx), .fdi_rx_v(k_prx_v), .fdi_rx_flit(k_prx),
        .phy_rst_n(k_phy_rst_n), .epoch_abort(k_abort), .recovery_cycles(k_rcyc), .fault(k_f));
    // real KVN producer: the compute die's fixed-slot KVN transport (2 seats), words pushed 1 cycle before their slot
    wire kvn_push = lay >= 0 && rel >= ks-1 && rel < ks+3;
    qfd_kvn_static_transport u_kvt (.ck(ck), .rst_n(rst_n & ~c_eb), .word_v(kvn_push), .word_tag({3'd2, 8'(rel - (ks-1))}),
        .word_data(word(lay, 5, rel - (ks-1))), .word_identity(op_tag), .word_generation(2'(lay)), .slot_v(kv_x3_slot),
        .x3(x3), .x3_identity(x3_id), .x3_generation(x3_gen), .fault(kvt_f));
    integer kvn_ok = 0;
    // ---------------- producers (stimulus schedule = the compiled send cycles of the bench layer profile) ----------
    function automatic [511:0] word(input integer l, input integer k, input integer b);
        integer i; begin for (i = 0; i < 16; i = i + 1) word[i*32 +: 32] = 32'h9e3779b9 * (l * 997 + k * 131 + b * 17 + i + 1); end
    endfunction
    integer rel; always @* rel = cyc - lstart;
    wire shift = (MUT == 3);
    wire [31:0] crel = rel - (shift ? 1 : 0);
    wire c_q_ev = lay >= 0 && (crel == qs || (crel >= qs+1 && crel < qs+33));
    wire [3:0] c_q_kind = crel == qs ? 4'd1 : 4'd2;
    wire [4:0] c_q_beat = crel == qs ? 5'd0 : 5'(crel - (qs+1));
    wire [511:0] c_q_data = crel == qs ? {493'd0, 5'd0, 13'(lay * 7 + 5), 1'b1} : word(lay, 2, crel - (qs+1));
    // KV STATUS word from the producers' encoder (qkd_native_status_word, the one qkd_native_attention_static_ctl uses;
    // QXF-LINK F2: the literal 5'b01001 here hid that the real producer sent 0): done 1, ready 1
    wire [511:0] st_word;
    qkd_native_status_word u_st_word (.q_ready(1'b0), .done(1'b1), .fault(1'b0), .busy(1'b0), .ready(1'b1), .word(st_word));
    wire k_r_ev = lay >= 0 && (rel >= rs && rel < rs+32 || rel == re);
    wire [3:0] k_r_kind = rel == re ? 4'd4 : 4'd3;
    wire [4:0] k_r_beat = rel == re ? 5'd0 : 5'(rel - rs);
    wire [511:0] k_r_data = rel == re ? st_word : word(lay, 3, rel - rs);
    wire ca_rv, ka_rv, ca_f, ka_f; wire [3:0] ca_rk, ka_rk, ca_fc, ka_fc; wire [15:0] ca_re, ka_re; wire [5:0] ca_rl, ka_rl;
    wire [4:0] ca_rb, ka_rb; wire [511:0] ca_rd, ka_rd;
    qkd_native_attention_record #(.KV_SIDE(0)) u_ca (.ck(ck), .rst_n(rst_n & ~c_eb),
        .tx_event(c_q_ev), .tx_expected(c_txs0), .tx_kind(c_q_kind), .tx_expected_kind(c_tk),
        .tx_epoch(op_epoch), .tx_expected_epoch(op_epoch), .tx_layer(op_layer), .tx_expected_layer(op_layer),
        .tx_beat(c_q_beat), .tx_expected_beat(c_tb), .tx_data(c_q_data), .tx_valid(c_tv0), .tx_payload(c_tp0),
        .rx_event(c_rxe0), .rx_expected(c_rxs0), .rx_payload(c_rxp), .rx_expected_kind(c_rk),
        .rx_expected_epoch(op_epoch), .rx_expected_layer(op_layer), .rx_expected_beat(c_rb),
        .rx_valid(ca_rv), .rx_kind(ca_rk), .rx_epoch(ca_re), .rx_layer(ca_rl), .rx_beat(ca_rb), .rx_data(ca_rd),
        .fault(ca_f), .fault_cause(ca_fc));
    qkd_native_attention_record #(.KV_SIDE(1)) u_ka (.ck(ck), .rst_n(rst_n & ~k_eb),
        .tx_event(k_r_ev), .tx_expected(k_txs0), .tx_kind(k_r_kind), .tx_expected_kind(k_tk),
        .tx_epoch(op_epoch), .tx_expected_epoch(op_epoch), .tx_layer(op_layer), .tx_expected_layer(op_layer),
        .tx_beat(k_r_beat), .tx_expected_beat(k_tb), .tx_data(k_r_data), .tx_valid(k_tv0), .tx_payload(k_tp0),
        .rx_event(k_rxe0), .rx_expected(k_rxs0), .rx_payload(k_rxp), .rx_expected_kind(k_rk),
        .rx_expected_epoch(op_epoch), .rx_expected_layer(op_layer), .rx_expected_beat(k_rb),
        .rx_valid(ka_rv), .rx_kind(ka_rk), .rx_epoch(ka_re), .rx_layer(ka_rl), .rx_beat(ka_rb), .rx_data(ka_rd),
        .fault(ka_f), .fault_cause(ka_fc));
    assign st_res = (lay >= 0 && rel == 20) || (tok && trel == 0);
    wire c_endf = c_f, k_endf = k_f, cs_f = 1'b0, ks_f = 1'b0;
    always @(negedge ck) corrupt <= bad_armed && lay >= 0 && rel == 3 + 7 + TXL + 2 * PR;
    // ---------------- exact-cycle checks ----------------
    integer errs = 0, frames_ck = 0, frames_kc = 0, statuses = 0, results = 0, normal_aborts = 0;
    integer seq_starts = 0;
    always @(posedge ck) if (DRV && rst_n) begin
        if (q_c_cs && q_c_l == 6'h3f || q_k_cs && q_k_l == 6'h3f) begin
            if (!(q_c_cs && q_k_cs && q_c_sg && q_k_sg && q_c_l == q_k_l)) begin errs = errs + 1; $display("ERR admission starts differ cyc %0d", cyc); $fatal(1,"D2D_PROGRAM_FAIL admission anchor mismatch"); end
        end else if ({q_c_cs, q_k_cs} !== {2{cstart}} || (cstart && {q_c_sg, q_k_sg} !== {2{cseg}})) begin
            errs = errs + 1; $display("ERR sequencer start cyc %0d expected %0d/%0d got C %0d/%0d K %0d/%0d", cyc, cstart, cseg, q_c_cs, q_c_sg, q_k_cs, q_k_sg);
        end
        if (q_c_cs && q_c_l != 6'h3f) seq_starts = seq_starts + 1;
        if (q_c_f || q_k_f) begin errs = errs + 1; $display("ERR sequencer fault cyc %0d", cyc); end
    end
    integer aborted_layer = -1;
    reg first_after_eb = 0;
    // token run (segment 1): terminal RESULT C->S at token cycle 2, embedding row S->C words 0..63 from cycle 20
    always @(posedge ck) if (tok && rst_n) begin
        if (c_emb_v && c_rk == 4'd8) begin
            if (!c_emb_s || trel - 2 - XL != P_EH || c_rxp !== EHDR) begin
                errs = errs + 1; $display("ERR embedding header trel %0d", trel); end
            else emb_hdr = emb_hdr + 1;
        end else if (c_emb_v) begin
            if (!c_emb_s || trel - 2 - XL - P_ES < 0 || trel - 2 - XL - P_ES > 63 ||
                (c_rk == 4'd7 ? 32 + c_rb : c_rb) != trel - 2 - XL - P_ES || c_rxp !== eword(trel - 2 - XL - P_ES)) begin
                errs = errs + 1; $display("ERR embedding word trel %0d kind %0d beat %0d", trel, c_rk, c_rb); end
            else emb_ok = emb_ok + 1;
        end
        // program-record slots: 3 S->C frames (BEGIN/AUTH kind 13, CONTEXT kind 12) reach the compute face, 1 C->S
        // WITNESS (kind 14) reaches the KV HOST record port; empty slots (observed 0) in this component bench
        if (c_prog_rxv) prec_c = prec_c + 1;
        if (c_prog_auth) prec_auth = prec_auth + 1;
        if (c_prog_ctx) prec_ctx = prec_ctx + 1;
        if (h_wv) prec_w = prec_w + 1;
        if (s_rv) begin
            if (trel != 2 + XS + 3 || s_rtok !== 18'(lay * 1001) || s_rval !== 32'(lay * 77) || !s_rd) begin
                errs = errs + 1; $display("ERR token result trel %0d", trel); end
            else tok_res = tok_res + 1;
        end
        if (ca_rv || ka_rv || kw_v) begin errs = errs + 1; $display("ERR layer-port frame in the token run trel %0d", trel); end
        if (ca_f || ka_f || c_abort || k_abort || c_f || k_f || kvt_f) begin
            normal_aborts = normal_aborts + 1; $display("ERR fault in token run trel %0d c%0d/%h k%0d/%h endf %0d%0d", trel, c_abort, c_tf, k_abort, h_tf, c_f, k_f); end
    end
    always @(posedge ck) if (lay >= 0 && rst_n) begin
        // compute codec output at arrival + 3 (end rx at +2, codec register +1): RESULT beats + STATUS
        if (ca_rv) begin
            if (!((rel - 3 - XL >= rs && rel - 3 - XL < rs+32) || rel - 3 - XL == re)) begin
                errs = errs + 1; $display("ERR compute rx at unplanned rel %0d", rel); end
            else if (ca_rd !== (rel - 3 - XL == re ? st_word : word(lay, 3, rel - 3 - XL - rs))) begin
                errs = errs + 1; $display("ERR compute rx data rel %0d", rel); end
            else if (aborted_layer != lay) frames_kc = frames_kc + 1;
        end
        if (ka_rv) begin
            if (!(rel - 3 - XL >= qs && rel - 3 - XL < qs+33)) begin errs = errs + 1; $display("ERR kv rx unplanned rel %0d", rel); end
            else if (ka_rd !== (rel - 3 - XL == qs ? {493'd0, 5'd0, 13'(lay * 7 + 5), 1'b1} : word(lay, 2, rel - 3 - XL - (qs+1)))) begin
                errs = errs + 1; $display("ERR kv rx data rel %0d", rel); end
            else if (aborted_layer != lay) frames_ck = frames_ck + 1;
        end
        if (s_rv) begin
            if (rel != ss + XS + 3 || s_rtok !== 18'(lay * 1001) || s_rval !== 32'(lay * 77) ||
                s_rcyc !== 32'(lay * 1052) || s_rt !== 59'(lay * 4093 + 11) || s_rg !== 2'(lay) || !s_rd) begin
                errs = errs + 1; $display("ERR status result rel %0d tok %0d", rel, s_rtok); end
            else if (aborted_layer != lay) results = results + 1;
        end
        if (kw_v) begin
            if (rel != ks + (kw_idx) + 2 - 1 + XL + 3 || kw_tag !== {3'd2, 8'(kw_idx)} || kw_data !== word(lay, 5, kw_idx) ||
                kw_id !== op_tag || kw_gen !== 2'(lay) || !kw_slot) begin
                errs = errs + 1; $display("ERR kvn word rel %0d idx %0d", rel, kw_idx); end
            else if (aborted_layer != lay) kvn_ok = kvn_ok + 1;
        end
        if (rel == re + XL + 20 && aborted_layer != lay) begin
            if (h_vmd !== lay[0] || h_cod !== ~lay[0] || h_cb !== lay[1] || h_ar !== (lay[0] ^ lay[1]) || !h_ea ||
                h_ad !== {1'b1, ~lay[0], lay[0], 1'b1} || h_lu !== 2'b11 || h_tf !== 0) begin
                errs = errs + 1; $display("ERR host services lay %0d vm%b co%b cb%b ar%b ad%b lu%b", lay, h_vmd, h_cod, h_cb, h_ar, h_ad, h_lu); end
            else statuses = statuses + 1;
        end
        // right after an epoch begin, the collector must not report stale compute drains as drained
        if (rel == 5 && first_after_eb && (h_vmd || h_cod || h_ar)) begin errs = errs + 1; $display("ERR stale status reported drained lay %0d", lay); end
        if (aborted_layer != lay && (ca_f || ka_f || c_abort || k_abort || c_f || k_f || kvt_f)) begin
            normal_aborts = normal_aborts + 1;
            if (normal_aborts < 4) $display("ERR fault in normal epoch lay %0d rel %0d ca%0d ka%0d cs%0d ks%0d cab%0d/%h kab%0d/%h endf %0d%0d",
                lay, rel, ca_f, ka_f, kvt_f, 1'b0, c_abort, c_tf, k_abort, h_tf, c_f, k_f);
        end
    end

    // ---------------- sequence ----------------
    integer l, i, t0, rec_kv = 0, rec_c = 0, tbad = -1;
    task tick(input integer n); repeat (n) @(negedge ck); endtask
    task run_layer(input integer L);
        begin
            $display("layer %0d start cyc %0d epoch %0d/%0d", L, cyc + 1, c_ep, k_ep);
            lay = L; lstart = cyc + 1 + LEAD; cstart = 1; first_after_eb = (aborted_layer == 99 && L == BAD_LAYER); tick(1); cstart = 0; tick(P - 1);   // L0 follows the token run (fresh status)
        end
    endtask
    initial begin
        $readmemh({CALDIR, "/cal_C_tx.memh"}, img_ct); $readmemh({CALDIR, "/cal_C_rx.memh"}, img_cr);
        $readmemh({CALDIR, "/cal_K_tx.memh"}, img_kt); $readmemh({CALDIR, "/cal_K_rx.memh"}, img_kr);
        $readmemh({CALDIR, "/cal_C_tx_seg1.memh"}, s1_ct); $readmemh({CALDIR, "/cal_C_rx_seg1.memh"}, s1_cr);
        $readmemh({CALDIR, "/cal_K_tx_seg1.memh"}, s1_kt); $readmemh({CALDIR, "/cal_K_rx_seg1.memh"}, s1_kr);
        tick(3); por_n = 1; tick(3); rst_n = 1; tick(2);
        // init mode: calendar images through the cfg port (both dies' control-image loaders)
        if (DRV) wait (q_c_rdy && q_k_rdy);
        else for (i = 0; i < 32; i = i + 1) begin
            cfg_a = i; cfg_dc = img_ct[i]; cfg_dk = img_kt[i]; cfg_c_tx = 1; cfg_k_tx = 1; tick(1);
            cfg_c_tx = 0; cfg_k_tx = 0; cfg_dc = img_cr[i]; cfg_dk = img_kr[i]; cfg_c_rx = 1; cfg_k_rx = 1; tick(1);
            cfg_c_rx = 0; cfg_k_rx = 0;
        end
        if (!DRV) begin cfg_hi = 1; cfg_a = 0; cfg_dc = s1_ct[0]; cfg_dk = s1_kt[0]; cfg_c_tx = 1; cfg_k_tx = 1; tick(1);
        cfg_c_tx = 0; cfg_k_tx = 0; cfg_dc = s1_cr[0]; cfg_dk = s1_kr[0]; cfg_c_rx = 1; cfg_k_rx = 1; tick(1);
        cfg_c_rx = 0; cfg_k_rx = 0; cfg_hi = 0; end
        wait (k_up && c_up); tick(2);
        host_boot = 1; tick(1); host_boot = 0; wait (k_eb); tick(10);
        if (!(c_ep == k_ep && c_ep == 1)) begin errs = errs + 1; $display("ERR boot epochs %0d %0d", c_ep, k_ep); end
        // Exact compiler cal_starts for the full 36-layer link composition.
        // The token segment already includes L0: do not issue a second L0 start.
        $readmemh({CALDIR, "/layer_starts.memh"}, layer_starts);
        if (DRV) begin
            wait (q_k_ts); @(negedge ck);           // the KV AUTO token go; the face issues the compute go on the same edge
            if (adm_c < 0 || adm_c != adm_k || adm_c - c_ep_rise != D2D_ADM_OFS + 1 ||   // cal_start is sampled the edge after the e == ADM_OFS decision
                !q_c_ad || !q_k_ad) begin
                errs = errs + 1; $display("ERR admission start C %0d K %0d (compute strobe %0d) done %0d%0d", adm_c, adm_k, c_ep_rise, q_c_ad, q_k_ad); end
            $display("ADMISSION start %0d edges after the compute epoch strobe; records BEGIN/AUTH %0d witness %0d", adm_c - c_ep_rise, adm_auth, adm_w);
        end
        tok_go = DRV; tick(DRV); tok_go = 0;     // the sequencer registers tok_go: its cal_start meets the reference edge
        if (DRV && cyc - c_ep_rise != D2D_FIRST_TOKEN) begin errs = errs + 1; $display("ERR first token %0d edges after the strobe", cyc - c_ep_rise); end
        tok = 1; tstart = cyc + 1 + LEAD; cstart = 1; cseg = 1;
        tick(1); cstart = 0; cseg = 0;
        while (cyc < tstart + P_L0 + 5) tick(1);
        tok = 0; lay = 0; lstart = tstart + P_L0;
        $display("PROGRAM_LAYER_START layer=0 compiled_cycle=%0d actual_cycle=%0d", P_L0, cyc-tstart);
        for (l = 1; l < NLAY; l = l + 1) begin
            while (cyc < tstart + layer_starts[l] - LEAD - 1) tick(1);
            lay = l; lstart = tstart + layer_starts[l]; cstart = 1;
            $display("PROGRAM_LAYER_START layer=%0d compiled_cycle=%0d actual_start_pin_cycle=%0d", l, layer_starts[l], cyc+1-tstart);
            tick(1); cstart = 0;
        end
        while (cyc < tstart + P_FINISH) tick(1);
        if (statuses != 36) begin errs = errs + 1; $display("ERR HOST status checks %0d", statuses); end
        lay = -1; tick(20);
        $display("token run: embedding words %0d header %0d program records S->C %0d (auth %0d context %0d) witness %0d; admission BEGIN/AUTH %0d witness %0d", emb_ok, emb_hdr, prec_c, prec_auth, prec_ctx, prec_w, adm_auth, adm_w);
        $display("frames C->S %0d S->C %0d kvn %0d results %0d host-checks %0d normal-epoch faults %0d errors %0d",
            frames_ck, frames_kc, kvn_ok, results, statuses, normal_aborts, errs);
        if (errs == 0 && normal_aborts == 0 && frames_ck == 33 * NLAY && frames_kc == 33 * NLAY && kvn_ok == 4 * NLAY && results == NLAY &&
            emb_ok == 64 && emb_hdr == 1 && prec_c == 1 && prec_auth == 0 && prec_ctx == 1 && prec_w == 1 && tok_res == 1 &&
            adm_auth == (DRV ? 2 : 0) && adm_ctx == 0 && adm_w == (DRV ? 1 : 0) && (!DRV || seq_starts == NLAY))
            $display("D2D_PROGRAM_PASS");
        else $display("D2D_PROGRAM_FAIL");
        $finish;
    end
    initial begin #300000; $display("D2D_PROGRAM_FAIL timeout"); $finish; end
endmodule
