`timescale 1ns/1ps
// Opt-in actual HOST root with reserved native admission at RX.
module qkd_host_rank_services_admission #(
 parameter T_LINK=200000,T_HBM=200000,WDOG=1<<22,
 parameter ENABLE_SERVICE=0,ENABLE_NATIVE=0,ENABLE_TOKEN=0,
 parameter PHY_MUT=0,QM_MUT=0,ORDER_MUT=0,BRIDGE_MUT=0,HC_MUT=0,PROMPT_MUT=0,
 parameter NL=6
)(
 output wire[5:0]host_upstream_quiet,
 input wire static_setup_ready,
 output wire[142:0]boot_pr,output wire[3:0]boot_image_target,
 output wire boot_image_ready,boot_image_fault,output wire[15:0]boot_image_epoch,output wire[63:0]boot_image_digest,
 input wire native_reserved,ownership_valid,
 output wire host_admission_open,host_launch_quiet,host_deferred,
 input wire[7:0]ck_phy,input wire ck_pad,ck_phy_rx_w,ck_phy_rx_r,ck_phy_tx_w,ck_phy_tx_r,
 input wire peer_reset_request,native_recovery_clear,input wire ck_peer,input wire peer_tx_valid,input wire[511:0]peer_tx_data,output wire peer_tx_ready,
 output wire peer_rx_valid,output wire[511:0]peer_rx_data,input wire peer_rx_ready,output wire peer_link_drained,
 input wire ck_program_rx,ck_program_loader,
 input wire ck_host,ck_csr,ck_rst,ck_ctl,ck_prompt,ck_rx,ck_tx,ck_axi,ck_ctrl,ck_hc,
 input wire ck_qm_queue,ck_qm_ing_w,ck_qm_ing_r,ck_qm_credit,ck_qm_done_w,ck_qm_done_r,
 input wire ck_qm_core,ck_qm_host,ck_qm_ingest,input wire[1:0]ck_qm_bank,input wire ck_qm_out,
 input wire ck_map,ck_sum,ck_order,ck_dispatch,ck_retire,ck_bootbarrier,
 input wire ck_fence_core,ck_fence_host,ck_guard,ck_native,
 input wire token_allocator_fault,
 input wire token_wrap_fence_valid,token_wrap_drained,token_wrap_link_reset_seen,token_wrap_retraining_done,
 output wire package_abort,input wire[3:0]abort_drained,
 output wire token_request_valid,input wire token_request_ready,
 output wire[17:0]token_request_token,token_request_position,output wire[1:0]token_request_generation,
 input wire cancel_release_v,input wire[58:0]cancel_release_tag,input wire[1:0]cancel_release_gen,output wire cancel_released,native_context_owned,
 input wire token_grant_valid,output wire token_grant_ready,
 input wire[15:0]token_grant_epoch,input wire[17:0]token_grant_token,token_grant_position,
 input wire[1:0]token_grant_generation,input wire[58:0]token_grant_tag,
 input wire allocated_valid,allocated_delivered,input wire[15:0]allocated_epoch,
 input wire[17:0]allocated_token,allocated_position,input wire[1:0]allocated_generation,
 output wire token_epoch_valid,output wire[15:0]token_epoch,
 output wire cancel_valid,output wire[58:0]cancel_tag,output wire[1:0]cancel_generation,
 output wire cancel_done,cancel_fault,output wire[3:0]cancel_drained,input wire token_cancel_accepted,
 output wire native_request_v,output wire[58:0]native_request_tag,output wire[31:0]native_request_trace,
 output wire[1:0]native_request_gen,output wire[17:0]native_request_token,native_request_pos,
 input wire native_request_cr,output wire[142:0]native_pr,
 input wire native_result_v,input wire[58:0]native_result_tag,input wire[1:0]native_result_gen,
 input wire native_result_done,native_result_fault,input wire[3:0]native_result_cause,
 input wire[17:0]native_result_token,input wire[31:0]native_result_value,native_result_cycles,
 output wire native_result_cr,input wire native_kv_drained,native_vm_drained,native_collective_drained,native_host_drained,
 input wire native_collective_busy,native_kv_flush,
 output wire service_ready,service_abort,ingest_permission,output wire[15:0]local_service_epoch,
 output wire[25:0]service_diag_raw,output wire[31:0]service_status,
 input wire[2:0]die_id,input wire por_n,pll_locked,phy_up,phy_rx_v,input wire[1042:0]phy_rx_flit,
 output wire phy_tx_v,output wire[1042:0]phy_tx_flit,
 input wire[NL-1:0]link_up,input wire[7:0]transport_fault,physical_fault,input wire crom_fault,
 input wire[92:0]local_tk,input wire[9:0]local_kst,
 input wire program_installed_valid,input wire execution_active,program_commit_v,input wire[15:0]program_commit_epoch,input wire[63:0]program_commit_digest,
 output wire program_ready,output wire[15:0]program_epoch,output wire[63:0]program_digest,
 output wire program_authorized_footer_v,output wire[63:0]program_authorized_footer64,
 output wire[15:0]program_begin_epoch,output wire program_begin_v,program_auth_v,output wire[10:0]program_expected_pw,output wire[3:0]program_expected_dw,output wire[15:0]program_auth_epoch,output wire[63:0]program_auth_digest,
 output wire[181:0]hc,output wire[7:0]seen,output wire irq,
 output wire host_rst_n,link_rst_n,hbm_rst_n,boot_go,die_rst_n,sys_ready,
 output wire[31:0]fault_src,output wire source_cr,available,
 output wire[282:0]hb,input wire hb_cr,input wire[12:0]est,
 output wire[1163:0]chain_f,input wire[127:0]chain_c,chain_a,input wire[3:0]chain_fault_i,input wire[127:0]slice_ack,slice_boot_done,slice_boot_ok,slice_boot_fault,
 input wire ctrl_completion_fault,   // KVJ-G2b 10-17: the registered OR of the 128 pc_path completion faults (qkd_kv_cfault_tree root); only its OR was used
 output wire marker_v,output wire[65:0]marker,
 output wire certificate_v,output wire[65:0]certificate,output wire[31:0]certificate_prefix,
 output wire[31:0]issued,landed,output wire[7:0]physical_ack_n,
 output wire[24:0]service_faults,
 output wire cq_commit_v,output wire[15:0]cq_client_tag,output wire[7:0]cq_slot,
 output wire[17:0]cq_pos,cq_token,output wire[1:0]cq_kind,output wire[3:0]cq_status,
 output wire step_issue_v,output wire[15:0]step_client_tag,output wire[7:0]step_slot,output wire[17:0]step_pos,output wire step_retire_v,step_retire_cq,output wire[15:0]step_retire_client_tag,output wire[7:0]step_retire_slot,output wire[17:0]step_retire_pos,step_retire_token,
 output wire host_idle,host_observer_fault
);
 wire[142:0]pr,raw_pr;
 wire[3:0]image_target,auth_target,replay_target;
 assign pr=(replay_target==0)?raw_pr:143'b0;
 assign boot_pr=raw_pr;assign boot_image_target=replay_target;assign boot_image_ready=replay_done&&!program_fault&&!ingress_fault&&!begin_image;assign boot_image_fault=program_fault|ingress_fault;assign boot_image_epoch=program_epoch;assign boot_image_digest=program_digest;wire[1:0]local_boot;
 wire[127:0]boot_done_pc=slice_boot_done,boot_ok_pc=slice_boot_ok,boot_fault_pc=slice_boot_fault;
 assign local_boot={&boot_ok_pc,&boot_done_pc};
 // g_boot: per-PC qkd_hbm_boot_static_completion in qkd_host_pc_slice (die-placed)
 wire ingress_fault,program_fault;wire begin_image,word_v,word_desc,seal,auth_v;
 wire[15:0]image_epoch,auth_epoch;wire[10:0]pw_count;wire[3:0]dw_count;
 wire[9:0]word_addr;wire[63:0]word_data,auth_digest;wire replay_done;
 assign program_begin_epoch=image_epoch;assign program_begin_v=begin_image&&image_target==0;assign program_auth_v=auth_v&&auth_target==0;assign program_expected_pw=pw_count;assign program_expected_dw=dw_count;assign program_auth_epoch=auth_epoch;assign program_auth_digest=auth_digest;
 reg committed,commit_fault;
 always @(posedge ck_program_loader or negedge host_rst_n)begin
  if(!host_rst_n)begin committed<=0;commit_fault<=0;end
  else begin
   if(begin_image||!program_installed_valid)committed<=0;
   else if(program_commit_v&&replay_target==0)begin
    if(!replay_done||program_commit_epoch!=program_epoch||program_commit_digest!=program_digest)commit_fault<=1;
    else committed<=1;
   end
  end
 end
 assign program_ready=static_setup_ready&&replay_target==0&&program_installed_valid&&replay_done&&committed&&!program_fault&&!ingress_fault&&!commit_fault&&!begin_image;
 qkd_host_program_loader_target u_program(.ck(ck_program_loader),.rst_n(host_rst_n),.begin_image(begin_image),.image_epoch(image_epoch),.pw_count(pw_count),.dw_count(dw_count),
 .word_v(word_v),.word_desc(word_desc),.word_addr(word_addr),.word_data(word_data),.seal(seal),.auth_v(auth_v),.auth_epoch(auth_epoch),.auth_digest(auth_digest),
 .image_target(image_target),.auth_target(auth_target),.replay_target(replay_target),.execution_active(execution_active),.pr(raw_pr),.program_ready(replay_done),.fault(program_fault),.digest(program_digest),.program_epoch(program_epoch),.authorized_footer_valid(program_authorized_footer_v),.authorized_footer(program_authorized_footer64));
 wire[7:0]observed_physical_faults=physical_fault|((8'((|boot_fault_pc)||(|ctrl_completion_fault)||ingress_fault||program_fault||commit_fault||host_observer_fault||peer_link_fault))<<die_id);
 wire d_rv,d_rcr,d_cv,d_ccr;wire[1023:0]d_rd,d_cd;wire adapter_fault;
 wire raw_rx_v,raw_rx_cr,program_rx_v,program_rx_cr;wire[527:0]raw_rx_d,program_rx_d;
 wire physical_tx_v,physical_tx_cr,peer_link_fault;wire[527:0]physical_tx_d;
 qkd_host_peer_link u_peer(.ck(ck_peer),.rst_n(host_rst_n),.rx_v(raw_rx_v),.rx_d(raw_rx_d),.rx_cr(raw_rx_cr),.normal_rx_v(program_rx_v),.normal_rx_d(program_rx_d),.normal_rx_cr(program_rx_cr),
 .peer_rx_valid(peer_rx_valid),.peer_rx_data(peer_rx_data),.peer_rx_ready(peer_rx_ready),.normal_tx_v(tx_v),.normal_tx_d(tx_d),.normal_tx_cr(tx_cr),.peer_tx_valid(peer_tx_valid),.peer_tx_data(peer_tx_data),.peer_tx_ready(peer_tx_ready),.tx_v(physical_tx_v),.tx_d(physical_tx_d),.tx_cr(physical_tx_cr),.drained(peer_link_drained),.fault(peer_link_fault));
 wire rx_v,rx_cr,tx_v,tx_cr;wire[527:0]rx_d,tx_d;wire[4:0]phy_faults;
 qfd_link_adp512_split #(.MUT(PHY_MUT))u_adapter(.ck(ck_phy),.rst_n(host_rst_n),
 .c_v(d_cv),.c_d(d_cd),.c_cr(d_ccr),.r_v(d_rv),.r_d(d_rd),.r_cr(d_rcr),
 .tx_up(phy_up),.tx_v(phy_tx_v),.tx_flit(phy_tx_flit),.rx_v(phy_rx_v),.rx_flit(phy_rx_flit),.fault(adapter_fault));
 qkd_host_phy_cdc5 u_phy(.ck_pad(ck_pad),.rx_wck(ck_phy_rx_w),.rx_rck(ck_phy_rx_r),.tx_wck(ck_phy_tx_w),.tx_rck(ck_phy_tx_r),.rst_n(host_rst_n),
 .phy_rx_v(d_rv),.phy_rx_d(d_rd),.phy_rx_cr(d_rcr),.phy_tx_v(d_cv),.phy_tx_d(d_cd),.phy_tx_cr(d_ccr),
 .core_rx_v(raw_rx_v),.core_rx_d(raw_rx_d),.core_rx_cr(raw_rx_cr),.core_tx_v(physical_tx_v),.core_tx_d(physical_tx_d),.core_tx_cr(physical_tx_cr),.faults(phy_faults));
 qkd_host_program_rx_target u_program_rx(.ck(ck_program_rx),.rst_n(host_rst_n),.rx_v(program_rx_v),.rx_d(program_rx_d),.rx_cr(program_rx_cr),
 .normal_v(rx_v),.normal_d(rx_d),.normal_cr(rx_cr),.begin_image(begin_image),.image_epoch(image_epoch),.image_target(image_target),.auth_target(auth_target),.pw_count(pw_count),.dw_count(dw_count),
 .word_v(word_v),.word_desc(word_desc),.word_addr(word_addr),.word_data(word_data),.seal(seal),.auth_v(auth_v),.auth_epoch(auth_epoch),.auth_digest(auth_digest),.fault(ingress_fault));
 wire ing_v,done_v,done_cr;wire[1:0]ing_cls;wire[511:0]ing_d;wire[4:0]ing_crn;wire[63:0]done_d;
 wire source_fault;wire[3:0]packet_faults;
 wire[92:0]native_tk,guarded_tk;wire native_protocol_fault;
 wire[7:0]guarded_physical,guarded_transport,peer_service_ready,peer_pending_ack;wire[127:0]peer_service_epoch;
 wire service_begin_v,pending_advertised,begin_fault;wire[15:0]service_begin_epoch,pending_epoch;
 qkd_host_control_packet_admission #(.NL(NL),.ENABLE_TOKEN(ENABLE_TOKEN),.ENABLE_SERVICE(ENABLE_SERVICE),.T_LINK(T_LINK),.T_HBM(T_HBM),.WDOG(WDOG),.HC_MUT(HC_MUT),.PROMPT_MUT(PROMPT_MUT))u_control(.native_reserved(native_reserved),.ownership_valid(ownership_valid),.host_admission_open(host_admission_open),.host_launch_quiet(host_launch_quiet),.host_deferred(host_deferred),.peer_reset_request(peer_reset_request),.cq_commit_v(cq_commit_v),.cq_client_tag(cq_client_tag),.cq_slot(cq_slot),.cq_pos(cq_pos),.cq_token(cq_token),.cq_kind(cq_kind),.cq_status(cq_status),.step_issue_v(step_issue_v),.step_client_tag(step_client_tag),.step_slot(step_slot),.step_pos(step_pos),.host_idle(host_idle),.host_observer_fault(host_observer_fault),.step_retire_v(step_retire_v),.step_retire_cq(step_retire_cq),.step_retire_client_tag(step_retire_client_tag),.step_retire_slot(step_retire_slot),.step_retire_pos(step_retire_pos),.step_retire_token(step_retire_token),
 .token_allocator_fault(token_allocator_fault),
 .token_wrap_fence_valid(token_wrap_fence_valid),.token_wrap_drained(token_wrap_drained),.token_wrap_link_reset_seen(token_wrap_link_reset_seen),.token_wrap_retraining_done(token_wrap_retraining_done),
 .package_abort(package_abort),.abort_drained(abort_drained),
 .token_request_valid(token_request_valid),.token_request_ready(token_request_ready),.token_request_token(token_request_token),.token_request_position(token_request_position),.token_request_generation(token_request_generation),
 .token_grant_valid(token_grant_valid),.token_grant_ready(token_grant_ready),.token_grant_epoch(token_grant_epoch),.token_grant_token(token_grant_token),.token_grant_position(token_grant_position),.token_grant_generation(token_grant_generation),.token_grant_tag(token_grant_tag),
 .allocated_valid(allocated_valid),.allocated_delivered(allocated_delivered),.allocated_epoch(allocated_epoch),.allocated_token(allocated_token),.allocated_position(allocated_position),.allocated_generation(allocated_generation),
 .token_epoch_valid(token_epoch_valid),.token_epoch(token_epoch),
 .cancel_valid(cancel_valid),.cancel_tag(cancel_tag),.cancel_generation(cancel_generation),.cancel_done(cancel_done),.cancel_fault(cancel_fault),.cancel_drained(cancel_drained),.terminal_accepted(token_cancel_accepted),
 .ck_host(ck_host),.ck_csr(ck_csr),.ck_rst(ck_rst),.ck_ctl(ck_ctl),.ck_prompt(ck_prompt),
 .ck_rx(ck_rx),.ck_tx(ck_tx),.ck_axi(ck_axi),.ck_ctrl(ck_ctrl),.ck_hc(ck_hc),
 .die_id(die_id),.por_n(por_n&&pll_locked),.link_up(link_up),.transport_fault(ENABLE_SERVICE?guarded_transport:transport_fault),.physical_fault(ENABLE_SERVICE?guarded_physical:observed_physical_faults),.crom_fault(crom_fault),.pr(pr),
 .irq(irq),.host_rst_n(host_rst_n),.link_rst_n(link_rst_n),.hbm_rst_n(hbm_rst_n),.boot_go(boot_go),.die_rst_n(die_rst_n),.sys_ready(sys_ready),.fault_src(fault_src),
 .rx_v(rx_v),.rx_d(rx_d),.rx_cr(rx_cr),.tx_v(tx_v),.tx_d(tx_d),.tx_cr(tx_cr),
 .local_tk(ENABLE_SERVICE?guarded_tk:(ENABLE_NATIVE?native_tk:local_tk)),.local_kst(local_kst),.local_boot(local_boot),.hc(hc),.seen(seen),
 .source_cr(source_cr),.available(available),.source_fault(source_fault),.packet_faults(packet_faults),
 .ing_v(ing_v),.ing_cls(ing_cls),.ing_d(ing_d),.ing_crn(ing_crn),.ing_t_v(done_v),.ing_t_d(done_d),.ing_t_cr(done_cr),
 .service_abort(service_abort),.service_ready(service_ready&&program_ready),.local_service_epoch(local_service_epoch),
 .service_diag_raw(service_diag_raw),.service_status(service_status),
 .service_begin_v(service_begin_v),.service_begin_epoch(service_begin_epoch),
 .pending_advertised(pending_advertised),.pending_epoch(pending_epoch),
 .service_ready8(peer_service_ready),.pending_ack8(peer_pending_ack),.service_epoch8(peer_service_epoch),
 .ingest_permission(ingest_permission),.begin_fault(begin_fault));
 wire marker_cr,marker_consumer_fault;
 qkd_host_marker_consumer u_marker_consumer(.ck(ck_bootbarrier),.rst_n(host_rst_n),.marker_v(marker_v),.marker(marker),.issued(issued),.landed(landed),.est(est),.source_fault(source_fault),.marker_cr(marker_cr),.certificate_v(certificate_v),.certificate(certificate),.certificate_prefix(certificate_prefix),.fault(marker_consumer_fault));
 wire qm_v,qm_t_v,qm_t_cr,fenced_v,fenced_cr;wire[1:0]qm_cls;wire[511:0]qm_d;wire[4:0]qm_crn;wire[63:0]qm_t_d,fenced_d;wire[5:0]bridge_faults;
 qkd_host_qm_clock_bridge_service_debt #(.ENABLE_SERVICE(ENABLE_SERVICE),.MUT(BRIDGE_MUT))u_bridge(.cq(ck_qm_queue),.qw(ck_qm_ing_w),.qr(ck_qm_ing_r),.qp(ck_qm_credit),.ccw(ck_qm_done_w),.ccr(ck_qm_done_r),.rst_n(host_rst_n),
 .ingest_permission(ingest_permission),.ing_v(ing_v),.ing_cls(ing_cls),.ing_d(ing_d),.ing_crn(ing_crn),.qm_v(qm_v),.qm_cls(qm_cls),.qm_d(qm_d),.qm_crn(qm_crn),
 .done_v(fenced_v),.done_d(fenced_d),.done_cr(fenced_cr),.packet_done_v(done_v),.packet_done_d(done_d),.packet_done_cr(done_cr),.faults(bridge_faults),.queue_quiet(host_upstream_quiet[0]));
 wire ov,owe,ocr,qm_fault;wire[31:0]oa;wire[255:0]od;
 qkd_host_native_qm_debt #(.AW(32),.HDMAX(128),.KVHMAX(2),.RMW_EN(0),.QPIPE(2),.NATIVE_ROWS(1),.MUT(QM_MUT))u_qm(
 .rst_n(host_rst_n),.clk_h(ck_qm_host),.h_v(qm_v),.h_cls(qm_cls),.h_d(qm_d),.h_crn(qm_crn),.t_v(qm_t_v),.t_d(qm_t_d),.t_cr(qm_t_cr),
 .clk_i(ck_qm_ingest),.clk_i_bank(ck_qm_bank),.clk_i_out(ck_qm_out),.ck(ck_qm_core),
 .o_v(ov),.o_we(owe),.o_addr(oa),.o_d(od),.o_cr(ocr),.i_rv(1'b0),.i_rd(256'd0),.fault(qm_fault),.quiet_h(host_upstream_quiet[1]),.quiet_i(host_upstream_quiet[2]),.quiet_c(host_upstream_quiet[3]));
 wire[289:0]kv_ing;wire kv_ing_cr;wire[127:0]all_acks;wire global_prefix_v,dispatch_fault;
 wire[31:0]kv_issued,kv_landed;wire local_marker_v,local_marker_cr,bootbarrier_fault,image_check;wire[65:0]local_marker;
 qkd_host_emb_boot_barrier u_bootbarrier(.ck(ck_bootbarrier),.rst_n(host_rst_n),.in_v(local_marker_v),.in_d(local_marker),.in_cr(local_marker_cr),.est(est),.require_fresh(image_check),.out_v(marker_v),.out_d(marker),.out_cr(marker_cr),.fault(bootbarrier_fault));
 qkd_host_boot_dispatch_debt u_dispatch(.ck(ck_dispatch),.ck_order(ck_retire),.rst_n(host_rst_n),.boot_release(local_marker_cr),
 .ing({od,oa,owe,ov}),.ing_cr(ocr),.kv(kv_ing),.kv_cr(kv_ing_cr),.hb(hb),.hb_cr(hb_cr),.image_check(image_check),
 .acks(all_acks),.prefix_v(global_prefix_v),.issued(issued),.landed(landed),.fault(dispatch_fault),.dispatch_quiet(host_upstream_quiet[4]),.order_quiet(host_upstream_quiet[5]));
 wire map_fault,order_fault,fence_fault;wire[3:0]chain_fault;wire[7:0]prefix_ack_n;wire[31:0]fence_landed;
 qkd_host_ingest_chain_pt #(.ORDER_MUT(ORDER_MUT))u_chain(.ck_map(ck_map),.ck_sum(ck_sum),.ck_order(ck_order),.rst_n(host_rst_n),
 .ing(kv_ing),.ing_cr(kv_ing_cr),.all_acks(all_acks),.chain_f(chain_f),.chain_c(chain_c),.chain_a(chain_a),.chain_fault_i(chain_fault_i),.slice_ack(slice_ack),
 .marker_v(local_marker_v),.marker(local_marker),.marker_cr(local_marker_cr),.issued(kv_issued),.landed(kv_landed),.map_fault(map_fault),.chain_fault(chain_fault),.ack_n(prefix_ack_n),.physical_ack_n(physical_ack_n),.order_fault(order_fault));
 qkd_host_visibility_fence u_fence(.rst_n(host_rst_n),.ck(ck_fence_core),.clk_h(ck_fence_host),.ack_n({7'd0,global_prefix_v}),
 .in_v(qm_t_v),.in_d(qm_t_d),.in_cr(qm_t_cr),.out_v(fenced_v),.out_d(fenced_d),.out_cr(fenced_cr),.fault(fence_fault),.landed_debug(fence_landed));
 qkd_host_native_token_endpoint_cancel #(.ENABLE_NATIVE(ENABLE_NATIVE))u_native(
 .ck(ck_native),.por_n(por_n&&pll_locked),.rst_n(host_rst_n),.hc(hc),.legacy_tk(local_tk),
 .recovery_clear(native_recovery_clear),.cancel_release_v(cancel_release_v),.cancel_release_tag(cancel_release_tag),.cancel_release_gen(cancel_release_gen),.cancel_released(cancel_released),.context_owned(native_context_owned),
 .image_ready(program_ready),.shared_epoch_valid(token_epoch_valid),.shared_epoch(token_epoch),
 .request_v(native_request_v),.request_tag(native_request_tag),.request_trace(native_request_trace),.request_gen(native_request_gen),
 .request_token(native_request_token),.request_pos(native_request_pos),.request_cr(native_request_cr),.native_pr(native_pr),
 .result_v(native_result_v),.result_tag(native_result_tag),.result_gen(native_result_gen),
 .result_done(native_result_done),.result_fault(native_result_fault),.result_cause(native_result_cause),
 .result_token(native_result_token),.result_value(native_result_value),.result_cycles(native_result_cycles),.result_cr(native_result_cr),
 .kv_drained(native_kv_drained),.vm_drained(native_vm_drained),.collective_drained(native_collective_drained),.host_drained(native_host_drained),
 .collective_busy(native_collective_busy),.kv_flush(native_kv_flush),.local_tk(native_tk),.protocol_fault(native_protocol_fault));
 qkd_host_service_guard u_guard(.ck_guard(ck_guard),.rst_n(host_rst_n),.raw_faults(service_faults),
 .die_id(die_id),.physical_faults(observed_physical_faults),.transport_faults(transport_fault),
 .accepted_ing_v(ing_v),.accepted_ing_cls(ing_cls),.accepted_ing_header(ing_d[15:0]),
 .done_v(done_v),.done_d(done_d),.boot_barrier_v(certificate_v),.boot_barrier_target(certificate_prefix),
 .begin_v(service_begin_v),.begin_epoch(service_begin_epoch),.pending_advertised(pending_advertised),.pending_epoch(pending_epoch),
 .local_tk(ENABLE_NATIVE?native_tk:local_tk),.guarded_tk(guarded_tk),.abort(service_abort),.service_ready(service_ready),
 .service_epoch(local_service_epoch),.diag_raw(service_diag_raw),.status(service_status),
 .physical_diag(guarded_physical),.transport_diag(guarded_transport),.service_protocol_fault(begin_fault));
 initial if(ENABLE_NATIVE&&(!ENABLE_SERVICE||!ENABLE_TOKEN))$fatal(1,"native HOST requires transported token identity and real service guard");
 assign service_faults={source_fault|dispatch_fault|bootbarrier_fault|marker_consumer_fault|est[1]|(ENABLE_NATIVE&&native_protocol_fault),packet_faults,chain_fault,fence_fault,order_fault,map_fault,qm_fault,bridge_faults,phy_faults,adapter_fault};
endmodule




module qkd_host_root_admission #(
 parameter T_LINK=200000,T_HBM=200000,WDOG=1<<22,
 parameter ENABLE_SERVICE=0,ENABLE_NATIVE=0,ENABLE_TOKEN=0,
 parameter PHY_MUT=0,QM_MUT=0,ORDER_MUT=0,BRIDGE_MUT=0,HC_MUT=0,PROMPT_MUT=0,
 parameter NL=6
)(
 output wire[5:0]host_upstream_quiet,
 input wire static_setup_ready,
 output wire[142:0]boot_pr,output wire[3:0]boot_image_target,
 output wire boot_image_ready,boot_image_fault,output wire[15:0]boot_image_epoch,output wire[63:0]boot_image_digest,
 input wire native_reserved,ownership_valid,
 output wire host_admission_open,host_launch_quiet,host_deferred,
 input wire[7:0] ck_phy,
 input wire ck_pad,
 input wire ck_phy_rx_w,
 input wire ck_phy_rx_r,
 input wire ck_phy_tx_w,
 input wire ck_phy_tx_r,
 input wire ck_peer,
 input wire ck_program_rx,
 input wire ck_program_loader,
 input wire ck_host,
 input wire ck_csr,
 input wire ck_rst,
 input wire ck_ctl,
 input wire ck_prompt,
 input wire ck_rx,
 input wire ck_tx,
 input wire ck_axi,
 input wire ck_ctrl,
 input wire ck_hc,
 input wire ck_qm_queue,
 input wire ck_qm_ing_w,
 input wire ck_qm_ing_r,
 input wire ck_qm_credit,
 input wire ck_qm_done_w,
 input wire ck_qm_done_r,
 input wire ck_qm_core,
 input wire ck_qm_host,
 input wire ck_qm_ingest,
 input wire[1:0] ck_qm_bank,
 input wire ck_qm_out,
 input wire ck_map,
 input wire ck_sum,
 input wire ck_order,
 input wire ck_dispatch,
 input wire ck_retire,
 input wire ck_bootbarrier,
 input wire ck_fence_core,
 input wire ck_fence_host,
 input wire ck_guard,
 input wire ck_native,
 output wire package_abort,
 input wire[3:0] abort_drained,
 output wire token_epoch_valid,
 output wire[15:0] token_epoch,
 output wire[142:0] native_pr,
 input wire native_kv_drained,
 input wire native_vm_drained,
 input wire native_collective_drained,
 input wire native_host_drained,
 input wire native_collective_busy,
 input wire native_kv_flush,
 output wire service_ready,
 output wire service_abort,
 output wire ingest_permission,
 output wire[15:0] local_service_epoch,
 output wire[25:0] service_diag_raw,
 output wire[31:0] service_status,
 input wire[2:0] die_id,
 input wire por_n,
 input wire pll_locked,
 input wire phy_up,
 input wire phy_rx_v,
 input wire[1042:0] phy_rx_flit,
 output wire phy_tx_v,
 output wire[1042:0] phy_tx_flit,
 input wire[NL-1:0] link_up,
 input wire[7:0] transport_fault,
 // kvsys v1.4.2 HOST owner = KV die lead 2026-10-15: the typed die-local PHYSICAL fault source is the static D2D link
 // end sticky fault qkd_d2d_static.fault = link end + KVN + service faults, placed on this die bit die_id.  HBM
 // controller faults reach the root through the landing fault chain to the embedding gateway est, host SerDes PHY and
 // adapter faults are root-internal phy_faults + adapter_fault, and peer die bits arrive through the peer service guard.
 input wire link_physical_fault,
 input wire crom_fault,
 input wire[92:0] local_tk,
 input wire[9:0] local_kst,
 // Compiler-assigned native link record face; no fabricated commit inputs.
 input wire ck_records,
 input wire[1:0] record_send_kind,
 input wire record_witness_slot,record_rx_v,
 input wire[547:0] record_rx,
 output wire record_tx_v,record_tx_observed_v,
 output wire[547:0] record_tx,
 output wire record_fault,
 input wire execution_active,

 output wire program_ready,
 output wire[15:0] program_epoch,
 output wire[63:0] program_digest,
 output wire program_authorized_footer_v,
 output wire[63:0] program_authorized_footer64,
 output wire program_begin_v,
 output wire program_auth_v,
 output wire[10:0] program_expected_pw,
 output wire[3:0] program_expected_dw,
 output wire[15:0] program_auth_epoch,
 output wire[63:0] program_auth_digest,
 output wire[181:0] hc,
 output wire[7:0] seen,
 output wire irq,
 output wire host_rst_n,
 output wire link_rst_n,
 output wire hbm_rst_n,
 output wire boot_go,
 output wire die_rst_n,
 output wire sys_ready,
 output wire[31:0] fault_src,
 output wire source_cr,
 output wire available,
 output wire[282:0] hb,
 input wire hb_cr,
 input wire[12:0] est,
 output wire[1163:0]chain_f,input wire[127:0]chain_c,chain_a,input wire[3:0]chain_fault_i,input wire[127:0]slice_ack,slice_boot_done,slice_boot_ok,slice_boot_fault,
 input wire ctrl_completion_fault,   // KVJ-G2b 10-17: 1 b = qkd_kv_cfault_tree root (the 128-b per-PC vector was only ORed)
 output wire marker_v,
 output wire[65:0] marker,
 output wire[31:0] issued,
 output wire[31:0] landed,
 output wire[7:0] physical_ack_n,
 output wire[24:0] service_faults,
 input wire native_admit_ready,
 input wire native_links_drained,
 input wire native_link_reset_seen,
 input wire native_retrained,
 output wire peer_protocol_fault,
 input wire ck_root_mux,ck_coordinator_codec,ck_coordinator_lifecycle,ck_coordinator_post,
 output wire dispatch_valid,dispatched,output wire[58:0]cohort_tag,output wire[1:0]cohort_gen,
 output wire[7:0]accepted_ranks,output wire[255:0]participant_trace,output wire[143:0]participant_token,participant_pos,
 input wire engine_result_v,input wire[58:0]engine_result_tag,input wire[1:0]engine_result_gen,input wire engine_result_done,engine_result_fault,
 input wire[3:0]engine_result_cause,input wire[17:0]engine_result_token,input wire[31:0]engine_result_value,engine_result_cycles,output wire engine_result_cr,
 output wire program_consensus,output wire coordinator_fault,output wire recovery_complete,
 // kvsys v1.4 (2026-10-15, HOST owner = KV die lead; Q-LINK request): the peer protocol's exceptional link-recovery
 // controls leave the root for the static D2D end qkd_d2d_static (host_link_reset_req / host_recovery_clear)
 output wire host_link_reset_req,output wire host_recovery_clear,
 // kvsys v1.4.1 (HOST owner = KV die lead, Q-LINK request): the local HOST interface drained level for the D2D end's
 // native_host_drained (= the observed host interface idle: no inflight request, both FSMs idle, no events, AXI quiet)
 output wire host_interface_idle
);
 localparam[2:0]RANK=0;
 wire[7:0] physical_fault=8'(link_physical_fault)<<die_id;
 // kvsys v1.4.2: this rank's engine is the compute die across the static D2D link; its admission is that link's
 // native_admit_ready (compute admit_ready & status fresh), the same level the control packet reports as native_ready
 wire engine_admit_ready=native_admit_ready;
 wire token_allocator_fault;
 wire token_wrap_fence_valid;
 wire token_wrap_drained;
 wire token_wrap_link_reset_seen;
 wire token_wrap_retraining_done;
 wire token_request_valid;
 wire token_request_ready;
 wire[17:0] token_request_token;
 wire[17:0] token_request_position;
 wire[1:0] token_request_generation;
 wire token_grant_valid;
 wire token_grant_ready;
 wire[15:0] token_grant_epoch;
 wire[17:0] token_grant_token;
 wire[17:0] token_grant_position;
 wire[1:0] token_grant_generation;
 wire[58:0] token_grant_tag;
 wire allocated_valid;
 wire allocated_delivered;
 wire[15:0] allocated_epoch;
 wire[17:0] allocated_token;
 wire[17:0] allocated_position;
 wire[1:0] allocated_generation;
 wire program_installed_valid,program_commit_v,installed_fusedcap;
 wire[15:0]program_commit_epoch,program_begin_epoch;wire[63:0]program_commit_digest;
 qkd_host_record_port u_records(.ck(ck_records),.rst_n(host_rst_n),.send_kind(record_send_kind),
 .request_v(native_request_v),.request_tag(native_request_tag),.request_gen(native_request_gen),
 .request_token(native_request_token),.request_position(native_request_pos),
 .token_epoch_valid(token_epoch_valid),.token_epoch(token_epoch),
 .begin_v(program_begin_v),.begin_epoch(program_begin_epoch),.expected_pw(program_expected_pw),.expected_dw(program_expected_dw),
 .auth_v(program_auth_v),.auth_epoch(program_auth_epoch),.auth_digest(program_auth_digest),
 .program_ready(program_ready),.program_epoch(program_epoch),.program_digest(program_digest),
 .authorized_footer_valid(program_authorized_footer_v),.authorized_footer(program_authorized_footer64),
 .witness_slot(record_witness_slot),.rx_v(record_rx_v),.rx_record(record_rx),
 .commit_v(program_commit_v),.installed_valid(program_installed_valid),.installed_fusedcap(installed_fusedcap),
 .commit_epoch(program_commit_epoch),.commit_digest(program_commit_digest),
 .tx_v(record_tx_v),.tx_observed_v(record_tx_observed_v),.tx_record(record_tx),.fault(record_fault));
 wire peer_reset_request;
 wire native_recovery_clear;
 assign host_link_reset_req=peer_reset_request;
 assign host_recovery_clear=native_recovery_clear;
 wire peer_tx_valid;
 wire[511:0] peer_tx_data;
 wire peer_tx_ready;
 wire peer_rx_valid;
 wire[511:0] peer_rx_data;
 wire peer_rx_ready;
 wire peer_link_drained;
 wire cancel_release_v;
 wire[58:0] cancel_release_tag;
 wire[1:0] cancel_release_gen;
 wire cancel_released;
 wire native_context_owned;
 wire cancel_valid;
 wire[58:0] cancel_tag;
 wire[1:0] cancel_generation;
 wire cancel_done;
 wire cancel_fault;
 wire[3:0] cancel_drained;
 wire token_cancel_accepted;
 wire native_request_v;
 wire[58:0] native_request_tag;
 wire[31:0] native_request_trace;
 wire[1:0] native_request_gen;
 wire[17:0] native_request_token;
 wire[17:0] native_request_pos;
 wire native_request_cr;
 wire native_result_v;
 wire[58:0] native_result_tag;
 wire[1:0] native_result_gen;
 wire native_result_done;
 wire native_result_fault;
 wire[3:0] native_result_cause;
 wire[17:0] native_result_token;
 wire[31:0] native_result_value;
 wire[31:0] native_result_cycles;
 wire native_result_cr;
 wire certificate_v;
 wire[65:0] certificate;
 wire[31:0] certificate_prefix;
 wire cq_commit_v;
 wire[15:0] cq_client_tag;
 wire[7:0] cq_slot;
 wire[17:0] cq_pos;
 wire[17:0] cq_token;
 wire[1:0] cq_kind;
 wire[3:0] cq_status;
 wire step_issue_v;
 wire[15:0] step_client_tag;
 wire[7:0] step_slot;
 wire[17:0] step_pos;
 wire step_retire_v;
 wire step_retire_cq;
 wire[15:0] step_retire_client_tag;
 wire[7:0] step_retire_slot;
 wire[17:0] step_retire_pos;
 wire[17:0] step_retire_token;
 wire host_idle;
 assign host_interface_idle=host_idle;
 wire host_observer_fault;
 wire peer_retrain_request,request_aborted;
 wire codec_allocated_valid,codec_allocated_delivered;wire[15:0]codec_allocated_epoch;wire[17:0]codec_allocated_token,codec_allocated_position;wire[1:0]codec_allocated_gen;
 qkd_host_rank_services_admission #(.NL(NL),.T_LINK(T_LINK),.T_HBM(T_HBM),.WDOG(WDOG),.ENABLE_SERVICE(ENABLE_SERVICE),.ENABLE_NATIVE(ENABLE_NATIVE),.ENABLE_TOKEN(ENABLE_TOKEN),.PHY_MUT(PHY_MUT),.QM_MUT(QM_MUT),.ORDER_MUT(ORDER_MUT),.BRIDGE_MUT(BRIDGE_MUT),.HC_MUT(HC_MUT),.PROMPT_MUT(PROMPT_MUT))u_rank(
 .static_setup_ready(static_setup_ready),.boot_pr(boot_pr),.boot_image_target(boot_image_target),.boot_image_ready(boot_image_ready),.boot_image_fault(boot_image_fault),.boot_image_epoch(boot_image_epoch),.boot_image_digest(boot_image_digest),
 .host_upstream_quiet(host_upstream_quiet),
 .native_reserved(native_reserved),.ownership_valid(ownership_valid),.host_admission_open(host_admission_open),.host_launch_quiet(host_launch_quiet),.host_deferred(host_deferred),
 .ck_phy(ck_phy),
 .ck_pad(ck_pad),
 .ck_phy_rx_w(ck_phy_rx_w),
 .ck_phy_rx_r(ck_phy_rx_r),
 .ck_phy_tx_w(ck_phy_tx_w),
 .ck_phy_tx_r(ck_phy_tx_r),
 .peer_reset_request(peer_reset_request),
 .native_recovery_clear(native_recovery_clear),
 .ck_peer(ck_peer),
 .peer_tx_valid(peer_tx_valid),
 .peer_tx_data(peer_tx_data),
 .peer_tx_ready(peer_tx_ready),
 .peer_rx_valid(peer_rx_valid),
 .peer_rx_data(peer_rx_data),
 .peer_rx_ready(peer_rx_ready),
 .peer_link_drained(peer_link_drained),
 .ck_program_rx(ck_program_rx),
 .ck_program_loader(ck_program_loader),
 .ck_host(ck_host),
 .ck_csr(ck_csr),
 .ck_rst(ck_rst),
 .ck_ctl(ck_ctl),
 .ck_prompt(ck_prompt),
 .ck_rx(ck_rx),
 .ck_tx(ck_tx),
 .ck_axi(ck_axi),
 .ck_ctrl(ck_ctrl),
 .ck_hc(ck_hc),
 .ck_qm_queue(ck_qm_queue),
 .ck_qm_ing_w(ck_qm_ing_w),
 .ck_qm_ing_r(ck_qm_ing_r),
 .ck_qm_credit(ck_qm_credit),
 .ck_qm_done_w(ck_qm_done_w),
 .ck_qm_done_r(ck_qm_done_r),
 .ck_qm_core(ck_qm_core),
 .ck_qm_host(ck_qm_host),
 .ck_qm_ingest(ck_qm_ingest),
 .ck_qm_bank(ck_qm_bank),
 .ck_qm_out(ck_qm_out),
 .ck_map(ck_map),
 .ck_sum(ck_sum),
 .ck_order(ck_order),
 .ck_dispatch(ck_dispatch),
 .ck_retire(ck_retire),
 .ck_bootbarrier(ck_bootbarrier),
 .ck_fence_core(ck_fence_core),
 .ck_fence_host(ck_fence_host),
 .ck_guard(ck_guard),
 .ck_native(ck_native),
 .token_allocator_fault(token_allocator_fault),
 .token_wrap_fence_valid(token_wrap_fence_valid),
 .token_wrap_drained(token_wrap_drained),
 .token_wrap_link_reset_seen(token_wrap_link_reset_seen),
 .token_wrap_retraining_done(token_wrap_retraining_done),
 .package_abort(package_abort),
 .abort_drained(abort_drained),
 .token_request_valid(token_request_valid),
 .token_request_ready((RANK==0)?token_request_ready:codec_allocated_valid),
 .token_request_token(token_request_token),
 .token_request_position(token_request_position),
 .token_request_generation(token_request_generation),
 .cancel_release_v(cancel_release_v),
 .cancel_release_tag(cancel_release_tag),
 .cancel_release_gen(cancel_release_gen),
 .cancel_released(cancel_released),
 .native_context_owned(native_context_owned),
 .token_grant_valid((RANK==0)?token_grant_valid:(codec_allocated_valid&&!codec_allocated_delivered)),
 .token_grant_ready(token_grant_ready),
 .token_grant_epoch((RANK==0)?token_grant_epoch:codec_allocated_epoch),
 .token_grant_token((RANK==0)?token_grant_token:codec_allocated_token),
 .token_grant_position((RANK==0)?token_grant_position:codec_allocated_position),
 .token_grant_generation((RANK==0)?token_grant_generation:codec_allocated_gen),
 .token_grant_tag((RANK==0)?token_grant_tag:{codec_allocated_epoch,6'd0,codec_allocated_token,codec_allocated_position[12:0],6'd0}),
 .allocated_valid((RANK==0)?allocated_valid:codec_allocated_valid),
 .allocated_delivered((RANK==0)?allocated_delivered:codec_allocated_delivered),
 .allocated_epoch((RANK==0)?allocated_epoch:codec_allocated_epoch),
 .allocated_token((RANK==0)?allocated_token:codec_allocated_token),
 .allocated_position((RANK==0)?allocated_position:codec_allocated_position),
 .allocated_generation((RANK==0)?allocated_generation:codec_allocated_gen),
 .token_epoch_valid(token_epoch_valid),
 .token_epoch(token_epoch),
 .cancel_valid(cancel_valid),
 .cancel_tag(cancel_tag),
 .cancel_generation(cancel_generation),
 .cancel_done(cancel_done),
 .cancel_fault(cancel_fault),
 .cancel_drained(cancel_drained),
 .token_cancel_accepted(token_cancel_accepted),
 .native_request_v(native_request_v),
 .native_request_tag(native_request_tag),
 .native_request_trace(native_request_trace),
 .native_request_gen(native_request_gen),
 .native_request_token(native_request_token),
 .native_request_pos(native_request_pos),
 .native_request_cr(native_request_cr),
 .native_pr(native_pr),
 .native_result_v(native_result_v),
 .native_result_tag(native_result_tag),
 .native_result_gen(native_result_gen),
 .native_result_done(native_result_done),
 .native_result_fault(native_result_fault),
 .native_result_cause(native_result_cause),
 .native_result_token(native_result_token),
 .native_result_value(native_result_value),
 .native_result_cycles(native_result_cycles),
 .native_result_cr(native_result_cr),
 .native_kv_drained(native_kv_drained),
 .native_vm_drained(native_vm_drained),
 .native_collective_drained(native_collective_drained),
 .native_host_drained(native_host_drained),
 .native_collective_busy(native_collective_busy),
 .native_kv_flush(native_kv_flush),
 .service_ready(service_ready),
 .service_abort(service_abort),
 .ingest_permission(ingest_permission),
 .local_service_epoch(local_service_epoch),
 .service_diag_raw(service_diag_raw),
 .service_status(service_status),
 .die_id(die_id),
 .por_n(por_n),
 .pll_locked(pll_locked),
 .phy_up(phy_up),
 .phy_rx_v(phy_rx_v),
 .phy_rx_flit(phy_rx_flit),
 .phy_tx_v(phy_tx_v),
 .phy_tx_flit(phy_tx_flit),
 .link_up(link_up),
 .transport_fault(transport_fault),
 .physical_fault(physical_fault| (8'(record_fault)<<die_id) |(8'(peer_protocol_fault||coordinator_fault||root_mux_fault)<<die_id)),
 .crom_fault(crom_fault),
 .local_tk(local_tk),
 .local_kst(local_kst),
 .program_installed_valid(program_installed_valid),
 .execution_active(execution_active||allocated_valid||native_context_owned),
 .program_commit_v(program_commit_v),
 .program_commit_epoch(program_commit_epoch),
 .program_commit_digest(program_commit_digest),
 .program_ready(program_ready),
 .program_epoch(program_epoch),
 .program_digest(program_digest),
 .program_authorized_footer_v(program_authorized_footer_v),.program_authorized_footer64(program_authorized_footer64),
 .program_begin_epoch(program_begin_epoch),.program_begin_v(program_begin_v),
 .program_auth_v(program_auth_v),
 .program_expected_pw(program_expected_pw),
 .program_expected_dw(program_expected_dw),
 .program_auth_epoch(program_auth_epoch),
 .program_auth_digest(program_auth_digest),
 .hc(hc),
 .seen(seen),
 .irq(irq),
 .host_rst_n(host_rst_n),
 .link_rst_n(link_rst_n),
 .hbm_rst_n(hbm_rst_n),
 .boot_go(boot_go),
 .die_rst_n(die_rst_n),
 .sys_ready(sys_ready),
 .fault_src(fault_src),
 .source_cr(source_cr),
 .available(available),
 .hb(hb),
 .hb_cr(hb_cr),
 .est(est),
 .chain_f(chain_f),.chain_c(chain_c),.chain_a(chain_a),.chain_fault_i(chain_fault_i),.slice_ack(slice_ack),.slice_boot_done(slice_boot_done),.slice_boot_ok(slice_boot_ok),.slice_boot_fault(slice_boot_fault),
 .ctrl_completion_fault(ctrl_completion_fault),
 .marker_v(marker_v),
 .marker(marker),
 .certificate_v(certificate_v),
 .certificate(certificate),
 .certificate_prefix(certificate_prefix),
 .issued(issued),
 .landed(landed),
 .physical_ack_n(physical_ack_n),
 .service_faults(service_faults),
 .cq_commit_v(cq_commit_v),
 .cq_client_tag(cq_client_tag),
 .cq_slot(cq_slot),
 .cq_pos(cq_pos),
 .cq_token(cq_token),
 .cq_kind(cq_kind),
 .cq_status(cq_status),
 .step_issue_v(step_issue_v),
 .step_client_tag(step_client_tag),
 .step_slot(step_slot),
 .step_pos(step_pos),
 .step_retire_v(step_retire_v),
 .step_retire_cq(step_retire_cq),
 .step_retire_client_tag(step_retire_client_tag),
 .step_retire_slot(step_retire_slot),
 .step_retire_pos(step_retire_pos),
 .step_retire_token(step_retire_token),
 .host_idle(host_idle),
 .host_observer_fault(host_observer_fault));
 qkd_host_peer_rank_codec #(.RANK(RANK))u_peer_codec(
 .ck(ck_peer),
 .por_n(por_n&&pll_locked),
 .tx_valid(local_tx_valid),
 .tx_data(local_tx_data),
 .tx_ready(local_tx_ready),
 .rx_valid(local_rx_valid),
 .rx_data(local_rx_data),
 .rx_ready(local_rx_ready),
 .request_v(native_request_v),
 .request_tag(native_request_tag),
 .request_gen(native_request_gen),
 .request_trace(native_request_trace),
 .request_token(native_request_token),
 .request_pos(native_request_pos),
 .request_cr(native_request_cr),
 .request_aborted(request_aborted),
 .cancel_valid(cancel_valid),
 .cancel_tag(cancel_tag),
 .cancel_gen(cancel_generation),
 .cancel_done(cancel_done),
 .cancel_fault(cancel_fault),
 .cancel_drained(cancel_drained),
 .cancel_accepted(token_cancel_accepted),
 .cancel_release_v(cancel_release_v),
 .cancel_release_tag(cancel_release_tag),
 .cancel_release_gen(cancel_release_gen),
 .cancel_released(cancel_released),
 .result_v(native_result_v),
 .result_tag(native_result_tag),
 .result_gen(native_result_gen),
 .result_done(native_result_done),
 .result_fault(native_result_fault),
 .result_cause(native_result_cause),
 .result_token(native_result_token),
 .result_value(native_result_value),
 .result_cycles(native_result_cycles),
 .result_cr(native_result_cr),
 .service_ready(service_ready),.service_epoch(local_service_epoch),
 .native_ready(native_admit_ready),
 .drained({native_host_drained,native_collective_drained,native_vm_drained,native_kv_drained}),
 .context_owned(native_context_owned),
 .links_drained(native_links_drained),
 .link_reset_seen(native_link_reset_seen),
 .retrained(native_retrained),
 .program_ready(program_ready),
 .program_epoch(program_epoch),
 .program_digest(program_digest),
 .allocated_valid(codec_allocated_valid),
 .allocated_delivered(codec_allocated_delivered),
 .allocated_epoch(codec_allocated_epoch),
 .allocated_token(codec_allocated_token),
 .allocated_position(codec_allocated_position),
 .allocated_gen(codec_allocated_gen),
 .reset_request(peer_reset_request),
 .retrain_request(peer_retrain_request),
 .recovery_clear(native_recovery_clear),
 .fault(peer_protocol_fault),
 .step_issue_v(step_issue_v),
 .step_client_tag(step_client_tag),
 .step_slot(step_slot),
 .step_pos(step_pos),
 .step_retire_v(step_retire_v),
 .step_retire_cq(step_retire_cq),
 .step_retire_client_tag(step_retire_client_tag),
 .step_retire_slot(step_retire_slot),
 .step_retire_pos(step_retire_pos),
 .step_retire_token(step_retire_token),
 .cq_commit_v(cq_commit_v),
 .cq_client_tag(cq_client_tag),
 .cq_slot(cq_slot),
 .cq_pos(cq_pos),
 .cq_token(cq_token),
 .certificate_v(certificate_v),
 .certificate(certificate),
 .certificate_prefix(certificate_prefix));
 wire local_tx_valid,local_tx_ready,local_rx_valid,local_rx_ready;wire[511:0]local_tx_data,local_rx_data;
 wire[7:0]coordinator_rx_valid,coordinator_rx_ready,coordinator_tx_valid,coordinator_tx_ready;wire[4095:0]coordinator_rx_data,coordinator_tx_data;
 wire root_mux_fault,coordinator_wrap_locked,coordinator_identity_fault,coordinator_post_pending;
 wire[15:0]coordinator_program_epoch;wire[63:0]coordinator_program_digest;
 wire[7:0]coordinator_certificate_valid;wire[527:0]coordinator_certificate;wire[255:0]coordinator_certificate_prefix;
 assign allocated_epoch=token_grant_epoch;assign allocated_token=token_grant_token;assign allocated_position=token_grant_position;assign allocated_generation=token_grant_generation;
 assign token_allocator_fault=coordinator_identity_fault;
 // Each legacy fact input carries the actual same completed global fence
 // certificate: all native drains, resets and retraining were proved upstream.
 assign token_wrap_fence_valid=recovery_complete;assign token_wrap_drained=recovery_complete;assign token_wrap_link_reset_seen=recovery_complete;assign token_wrap_retraining_done=recovery_complete;
 qkd_host_peer_root_mux u_root_mux(.ck(ck_root_mux),.por_n(por_n),.physical_rx_valid(peer_rx_valid),.physical_rx_data(peer_rx_data),.physical_rx_ready(peer_rx_ready),.physical_tx_valid(peer_tx_valid),.physical_tx_data(peer_tx_data),.physical_tx_ready(peer_tx_ready),
 .local_tx_valid(local_tx_valid),.local_tx_data(local_tx_data),.local_tx_ready(local_tx_ready),.local_rx_valid(local_rx_valid),.local_rx_data(local_rx_data),.local_rx_ready(local_rx_ready),
 .coordinator_rx_valid(coordinator_rx_valid),.coordinator_rx_data(coordinator_rx_data),.coordinator_rx_ready(coordinator_rx_ready),.coordinator_tx_valid(coordinator_tx_valid),.coordinator_tx_data(coordinator_tx_data),.coordinator_tx_ready(coordinator_tx_ready),.fault(root_mux_fault));
 qkd_host_tp8_coordinator u_coordinator(.ck_codec(ck_coordinator_codec),.ck_lifecycle(ck_coordinator_lifecycle),.ck_post(ck_coordinator_post),.por_n(por_n),
 .peer_rx_valid(coordinator_rx_valid),.peer_rx_data(coordinator_rx_data),.peer_rx_ready(coordinator_rx_ready),.peer_tx_valid(coordinator_tx_valid),.peer_tx_data(coordinator_tx_data),.peer_tx_ready(coordinator_tx_ready),
 .token_request_valid(token_request_valid),.token_request_token(token_request_token),.token_request_position(token_request_position),.token_request_gen(token_request_generation),.token_request_ready(token_request_ready),
 .token_grant_valid(token_grant_valid),.token_grant_ready(token_grant_ready),.token_grant_epoch(token_grant_epoch),.token_grant_token(token_grant_token),.token_grant_position(token_grant_position),.token_grant_gen(token_grant_generation),.token_grant_tag(token_grant_tag),.allocated_valid(allocated_valid),.allocated_delivered(allocated_delivered),
 .engine_admit_ready(engine_admit_ready),.dispatch_valid(dispatch_valid),.dispatched(dispatched),.cohort_tag(cohort_tag),.cohort_gen(cohort_gen),.accepted_ranks(accepted_ranks),.participant_trace(participant_trace),.participant_token(participant_token),.participant_pos(participant_pos),
 .engine_result_v(engine_result_v),.engine_result_tag(engine_result_tag),.engine_result_gen(engine_result_gen),.engine_result_done(engine_result_done),.engine_result_fault(engine_result_fault),.engine_result_cause(engine_result_cause),.engine_result_token(engine_result_token),.engine_result_value(engine_result_value),.engine_result_cycles(engine_result_cycles),.engine_result_cr(engine_result_cr),
 .program_consensus(program_consensus),.program_epoch(coordinator_program_epoch),.program_digest(coordinator_program_digest),.certificate_valid(coordinator_certificate_valid),.certificate(coordinator_certificate),.certificate_prefix(coordinator_certificate_prefix),
 .wrap_locked(coordinator_wrap_locked),.identity_fault(coordinator_identity_fault),.recovery_complete(recovery_complete),.post_pending(coordinator_post_pending),.fault(coordinator_fault));
endmodule
