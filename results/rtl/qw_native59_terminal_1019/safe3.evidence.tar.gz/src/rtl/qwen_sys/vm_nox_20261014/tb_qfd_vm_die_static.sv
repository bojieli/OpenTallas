`timescale 1ns/1ps
module tb_qfd_vm_die_static;
parameter integer OBS_MUT=0,PACK_MUT=0,MEM=0,CONFLICT_MUT=0,NATIVE_BANKS=0;
parameter integer RETURN_RO=1,PARTITIONED=0,EXPECTED_RO=RETURN_RO,RETURN_PIN_INPUT=0;
parameter integer WRITE_LEAVES=0;
parameter integer EXPECTED_SU_VL=13+RETURN_RO+RETURN_PIN_INPUT;
localparam integer NCK=8*(22+14*RETURN_RO)+(6*(10+RETURN_RO)+255)/256;
localparam integer DELTA=EXPECTED_RO-1;
integer COMMIT_MUT=0;
initial void'($value$plusargs("COMMIT_MUT=%d",COMMIT_MUT));
integer epoch=0;
wire [38:0] cv;wire [311:0] cl;wire [623:0] cm;
integer awcycle[0:31];integer commits=0,fence_commits=0;
wire fv,ff,fc;wire [4:0] fb;wire [58:0] ft;
reg [38:0] delayed_v;reg [311:0] delayed_l;reg [623:0] delayed_m;
always @(posedge clk)begin delayed_v<=cv;delayed_l<=cl;delayed_m<=cm;end
wire [38:0] checked_v=(COMMIT_MUT==1) ? (cv & ~(39'd1<<38)) :
    (COMMIT_MUT==3) ? delayed_v : (COMMIT_MUT==6) ? (cv | (cv[38] ? (39'd1<<37) : 39'd0)) : cv;
wire [311:0] checked_l=(COMMIT_MUT==6 && cv[38]) ? ((cl & ~(312'hff<<(37*8))) | (312'd49<<(37*8))) : (COMMIT_MUT==2) ? (cl ^ (312'd1<<(38*8))) : (COMMIT_MUT==3) ? delayed_l : cl;
wire [623:0] checked_m=(COMMIT_MUT==6 && cv[38]) ? (cm | (624'hffff<<(37*16))) : (COMMIT_MUT==4) ? (cm & ~(624'd1<<(38*16))) : (COMMIT_MUT==3) ? delayed_m : cm;
qfd_vm_attention_commit_fence #(.COMMIT_EDGES(8)) u_fence(
 .ck(clk),.rst_n(rst_n),.request_slot((qe && epoch==0) || (COMMIT_MUT==8 && ar[519] && ar[516:512]==0)),.request_tag59(59'h12345678),
 .write_v(ar[519]),.write_beat(ar[516:512]),.write_tag59(59'h12345678 ^ ((COMMIT_MUT==5)?59'd1:59'd0)),
 .visibility_slot(qs && epoch==0),.write_commit_v(checked_v),.write_commit_line(checked_l),.write_commit_mask(checked_m),
 .vm_commit_v(fv),.vm_commit_beat(fb),.vm_commit_tag59(ft),.complete(fc),.fault(ff));
genvar rg,bg;
generate for(rg=0;rg<8;rg=rg+1)begin : g_check_r
 for(bg=0;bg<8;bg=bg+1)begin : g_check_b
  // Compare actual SRAM-consumed pins independently of the observer.
  if(NATIVE_BANKS==0)begin : g_leg
  always @(posedge clk)if(rst_n && dut.u_vm.g_tile.g_t[rg].u_t.g_b[bg].g_lbt.u_bt.p_we &&
     dut.u_vm.g_tile.g_t[rg].u_t.g_b[bg].g_lbt.u_bt.p_wl==49)begin
   if(dut.u_vm.g_tile.g_t[rg].u_t.g_b[bg].g_lbt.u_bt.p_wd!==image(49*64+rg*8+bg) ||
      dut.u_vm.g_tile.g_t[rg].u_t.g_b[bg].g_lbt.u_bt.p_wm!==16'hffff)
       $fatal(1,"FAIL actual SRAM consumed data/mask r%0d b%0d",rg,bg);
  end
  end else begin : g_nat   // native successor: the macro write pins after the ctrl / data256 input leaves
  always @(posedge clk)if(rst_n && dut.u_vm.g_tile.g_t[rg].u_t.g_b[bg].g_nbt.u_bt.pwe &&
     dut.u_vm.g_tile.g_t[rg].u_t.g_b[bg].g_nbt.u_bt.pwl==49)begin
   if(dut.u_vm.g_tile.g_t[rg].u_t.g_b[bg].g_nbt.u_bt.pwd!==image(49*64+rg*8+bg) ||
      dut.u_vm.g_tile.g_t[rg].u_t.g_b[bg].g_nbt.u_bt.pwm!==16'hffff)
       $fatal(1,"FAIL actual SRAM consumed data/mask r%0d b%0d",rg,bg);
  end
  end
 end
end endgenerate
reg [63:0] swmask=0;reg [23:0] swa0=0,swa1=0;reg [2047:0] swdata=0;
wire [2366:0] sa;
reg[2:0] su_re=0;reg[71:0]su_a0=0,su_a1=0;wire[6143:0]su_q;
reg[EXPECTED_SU_VL:0] su_expected_v=0;
reg[6143:0] su_expected_q[0:EXPECTED_SU_VL];
integer su_replies=0;
always @(posedge clk)begin
 if(!rst_n)su_expected_v<=0;
 else begin
  su_expected_v<={su_expected_v,su_re[0]};
  for(integer age=EXPECTED_SU_VL;age>0;age=age-1)su_expected_q[age]<=su_expected_q[age-1];
  for(integer copy=0;copy<3;copy=copy+1)
   for(integer lane=0;lane<64;lane=lane+1)su_expected_q[0][(copy*64+lane)*32+:32]<=32'h3f800000+su_a0[copy*24+:24]+lane+32768;
 end
end
qfd_su_vm_pack u_pack(.s_re0(su_re),.s_re1(su_re),.s_a0(su_a0),.s_a1(su_a1),.sw_mask(swmask),.sw_a0(swa0),.sw_a1(swa1+PACK_MUT),.sw_data(swdata),.red_we(1'b0),.red_addr(24'd0),.red_data(32'd0),.va(sa));
reg clk=0,rst_n=0; always #1 clk=~clk;
reg [532:0] svw=0; reg [20:0] svr=0; reg [519:0] ar=0;
reg qe=0,qs=0;wire qsr,qd,fault,svq_v;wire [511:0] svq;wire [523:0] q;
integer beats=0,errors=0,cycles=0,start_cycle=0,requests=0,responses=0,req_start=0;

qfd_sp_vector_memory #(.USE_MACRO(MEM),.USE_LEAF_CLOCKS(1),.OBS_MUT(OBS_MUT),.NATIVE_BANKS(NATIVE_BANKS),.RETURN_RO(RETURN_RO),.RETURN_PIN_INPUT(RETURN_PIN_INPUT),.WRITE_LEAVES(WRITE_LEAVES),.WRITE_CLOCKS(WRITE_LEAVES),.PAR_RB(PARTITIONED),
 .USE_NATIVE_CLOCKS(PARTITIONED),.RETURN_LEAVES(PARTITIONED),.READ_CONTROL_LEAVES(PARTITIONED),.RETURN_CLOCKS(PARTITIONED),.RELAY_TILES(PARTITIONED)) dut(
.ck(clk),.rst_n(rst_n),
`ifdef OT_QFD_VM_PARTITIONED_CLOCKS
.native_ck({1008{clk}}),.return_ck({96{clk}}),.read_control_ck({3{clk}}),.write_ck({240{clk}}),.relay_ck({NCK{clk}}),
`endif
.ck_r0_0(clk),
.ck_r0_1(clk),
.ck_r0_2(clk),
.ck_r0_3(clk),
.ck_r0_4(clk),
.ck_r0_5(clk),
.ck_r0_6(clk),
.ck_r0_7(clk),
.ck_r0_8(clk),
.ck_r0_9(clk),
.ck_r0_10(clk),
.ck_r0_11(clk),
.ck_r0_12(clk),
.ck_r0_13(clk),
.ck_r0_14(clk),
.ck_r0_15(clk),
.ck_r0_16(clk),
.ck_r0_17(clk),
.ck_r0_18(clk),
.ck_r0_19(clk),
.ck_r0_20(clk),
.ck_r0_21(clk),
.ck_r0_22(clk),
.ck_r0_23(clk),
.ck_r0_24(clk),
.ck_r0_25(clk),
.ck_r0_26(clk),
.ck_r0_27(clk),
.ck_r0_28(clk),
.ck_r0_29(clk),
.ck_r0_30(clk),
.ck_r0_31(clk),
.ck_r0_32(clk),
.ck_r0_33(clk),
.ck_r0_34(clk),
.ck_r0_35(clk),
.ck_r0_36(clk),
.ck_r0_37(clk),
.ck_r0_38(clk),
.ck_r0_39(clk),
.ck_r0_40(clk),
.ck_r0_41(clk),
.ck_r0_42(clk),
.ck_r0_43(clk),
.ck_r0_44(clk),
.ck_r0_45(clk),
.ck_r0_46(clk),
.ck_r0_47(clk),
.ck_r0_48(clk),
.ck_r0_49(clk),
.ck_r0_50(clk),
.ck_r0_51(clk),
.ck_r0_52(clk),
.ck_r0_53(clk),
.ck_r0_54(clk),
.ck_r0_55(clk),
.ck_r1_0(clk),
.ck_r1_1(clk),
.ck_r1_2(clk),
.ck_r1_3(clk),
.ck_r1_4(clk),
.ck_r1_5(clk),
.ck_r1_6(clk),
.ck_r1_7(clk),
.ck_r1_8(clk),
.ck_r1_9(clk),
.ck_r1_10(clk),
.ck_r1_11(clk),
.ck_r1_12(clk),
.ck_r1_13(clk),
.ck_r1_14(clk),
.ck_r1_15(clk),
.ck_r1_16(clk),
.ck_r1_17(clk),
.ck_r1_18(clk),
.ck_r1_19(clk),
.ck_r1_20(clk),
.ck_r1_21(clk),
.ck_r1_22(clk),
.ck_r1_23(clk),
.ck_r1_24(clk),
.ck_r1_25(clk),
.ck_r1_26(clk),
.ck_r1_27(clk),
.ck_r1_28(clk),
.ck_r1_29(clk),
.ck_r1_30(clk),
.ck_r1_31(clk),
.ck_r1_32(clk),
.ck_r1_33(clk),
.ck_r1_34(clk),
.ck_r1_35(clk),
.ck_r1_36(clk),
.ck_r1_37(clk),
.ck_r1_38(clk),
.ck_r1_39(clk),
.ck_r1_40(clk),
.ck_r1_41(clk),
.ck_r1_42(clk),
.ck_r1_43(clk),
.ck_r1_44(clk),
.ck_r1_45(clk),
.ck_r1_46(clk),
.ck_r1_47(clk),
.ck_r1_48(clk),
.ck_r1_49(clk),
.ck_r1_50(clk),
.ck_r1_51(clk),
.ck_r1_52(clk),
.ck_r1_53(clk),
.ck_r1_54(clk),
.ck_r1_55(clk),
.ck_r2_0(clk),
.ck_r2_1(clk),
.ck_r2_2(clk),
.ck_r2_3(clk),
.ck_r2_4(clk),
.ck_r2_5(clk),
.ck_r2_6(clk),
.ck_r2_7(clk),
.ck_r2_8(clk),
.ck_r2_9(clk),
.ck_r2_10(clk),
.ck_r2_11(clk),
.ck_r2_12(clk),
.ck_r2_13(clk),
.ck_r2_14(clk),
.ck_r2_15(clk),
.ck_r2_16(clk),
.ck_r2_17(clk),
.ck_r2_18(clk),
.ck_r2_19(clk),
.ck_r2_20(clk),
.ck_r2_21(clk),
.ck_r2_22(clk),
.ck_r2_23(clk),
.ck_r2_24(clk),
.ck_r2_25(clk),
.ck_r2_26(clk),
.ck_r2_27(clk),
.ck_r2_28(clk),
.ck_r2_29(clk),
.ck_r2_30(clk),
.ck_r2_31(clk),
.ck_r2_32(clk),
.ck_r2_33(clk),
.ck_r2_34(clk),
.ck_r2_35(clk),
.ck_r2_36(clk),
.ck_r2_37(clk),
.ck_r2_38(clk),
.ck_r2_39(clk),
.ck_r2_40(clk),
.ck_r2_41(clk),
.ck_r2_42(clk),
.ck_r2_43(clk),
.ck_r2_44(clk),
.ck_r2_45(clk),
.ck_r2_46(clk),
.ck_r2_47(clk),
.ck_r2_48(clk),
.ck_r2_49(clk),
.ck_r2_50(clk),
.ck_r2_51(clk),
.ck_r2_52(clk),
.ck_r2_53(clk),
.ck_r2_54(clk),
.ck_r2_55(clk),
.ck_r3_0(clk),
.ck_r3_1(clk),
.ck_r3_2(clk),
.ck_r3_3(clk),
.ck_r3_4(clk),
.ck_r3_5(clk),
.ck_r3_6(clk),
.ck_r3_7(clk),
.ck_r3_8(clk),
.ck_r3_9(clk),
.ck_r3_10(clk),
.ck_r3_11(clk),
.ck_r3_12(clk),
.ck_r3_13(clk),
.ck_r3_14(clk),
.ck_r3_15(clk),
.ck_r3_16(clk),
.ck_r3_17(clk),
.ck_r3_18(clk),
.ck_r3_19(clk),
.ck_r3_20(clk),
.ck_r3_21(clk),
.ck_r3_22(clk),
.ck_r3_23(clk),
.ck_r3_24(clk),
.ck_r3_25(clk),
.ck_r3_26(clk),
.ck_r3_27(clk),
.ck_r3_28(clk),
.ck_r3_29(clk),
.ck_r3_30(clk),
.ck_r3_31(clk),
.ck_r3_32(clk),
.ck_r3_33(clk),
.ck_r3_34(clk),
.ck_r3_35(clk),
.ck_r3_36(clk),
.ck_r3_37(clk),
.ck_r3_38(clk),
.ck_r3_39(clk),
.ck_r3_40(clk),
.ck_r3_41(clk),
.ck_r3_42(clk),
.ck_r3_43(clk),
.ck_r3_44(clk),
.ck_r3_45(clk),
.ck_r3_46(clk),
.ck_r3_47(clk),
.ck_r3_48(clk),
.ck_r3_49(clk),
.ck_r3_50(clk),
.ck_r3_51(clk),
.ck_r3_52(clk),
.ck_r3_53(clk),
.ck_r3_54(clk),
.ck_r3_55(clk),
.ck_r4_0(clk),
.ck_r4_1(clk),
.ck_r4_2(clk),
.ck_r4_3(clk),
.ck_r4_4(clk),
.ck_r4_5(clk),
.ck_r4_6(clk),
.ck_r4_7(clk),
.ck_r4_8(clk),
.ck_r4_9(clk),
.ck_r4_10(clk),
.ck_r4_11(clk),
.ck_r4_12(clk),
.ck_r4_13(clk),
.ck_r4_14(clk),
.ck_r4_15(clk),
.ck_r4_16(clk),
.ck_r4_17(clk),
.ck_r4_18(clk),
.ck_r4_19(clk),
.ck_r4_20(clk),
.ck_r4_21(clk),
.ck_r4_22(clk),
.ck_r4_23(clk),
.ck_r4_24(clk),
.ck_r4_25(clk),
.ck_r4_26(clk),
.ck_r4_27(clk),
.ck_r4_28(clk),
.ck_r4_29(clk),
.ck_r4_30(clk),
.ck_r4_31(clk),
.ck_r4_32(clk),
.ck_r4_33(clk),
.ck_r4_34(clk),
.ck_r4_35(clk),
.ck_r4_36(clk),
.ck_r4_37(clk),
.ck_r4_38(clk),
.ck_r4_39(clk),
.ck_r4_40(clk),
.ck_r4_41(clk),
.ck_r4_42(clk),
.ck_r4_43(clk),
.ck_r4_44(clk),
.ck_r4_45(clk),
.ck_r4_46(clk),
.ck_r4_47(clk),
.ck_r4_48(clk),
.ck_r4_49(clk),
.ck_r4_50(clk),
.ck_r4_51(clk),
.ck_r4_52(clk),
.ck_r4_53(clk),
.ck_r4_54(clk),
.ck_r4_55(clk),
.ck_r5_0(clk),
.ck_r5_1(clk),
.ck_r5_2(clk),
.ck_r5_3(clk),
.ck_r5_4(clk),
.ck_r5_5(clk),
.ck_r5_6(clk),
.ck_r5_7(clk),
.ck_r5_8(clk),
.ck_r5_9(clk),
.ck_r5_10(clk),
.ck_r5_11(clk),
.ck_r5_12(clk),
.ck_r5_13(clk),
.ck_r5_14(clk),
.ck_r5_15(clk),
.ck_r5_16(clk),
.ck_r5_17(clk),
.ck_r5_18(clk),
.ck_r5_19(clk),
.ck_r5_20(clk),
.ck_r5_21(clk),
.ck_r5_22(clk),
.ck_r5_23(clk),
.ck_r5_24(clk),
.ck_r5_25(clk),
.ck_r5_26(clk),
.ck_r5_27(clk),
.ck_r5_28(clk),
.ck_r5_29(clk),
.ck_r5_30(clk),
.ck_r5_31(clk),
.ck_r5_32(clk),
.ck_r5_33(clk),
.ck_r5_34(clk),
.ck_r5_35(clk),
.ck_r5_36(clk),
.ck_r5_37(clk),
.ck_r5_38(clk),
.ck_r5_39(clk),
.ck_r5_40(clk),
.ck_r5_41(clk),
.ck_r5_42(clk),
.ck_r5_43(clk),
.ck_r5_44(clk),
.ck_r5_45(clk),
.ck_r5_46(clk),
.ck_r5_47(clk),
.ck_r5_48(clk),
.ck_r5_49(clk),
.ck_r5_50(clk),
.ck_r5_51(clk),
.ck_r5_52(clk),
.ck_r5_53(clk),
.ck_r5_54(clk),
.ck_r5_55(clk),
.ck_r6_0(clk),
.ck_r6_1(clk),
.ck_r6_2(clk),
.ck_r6_3(clk),
.ck_r6_4(clk),
.ck_r6_5(clk),
.ck_r6_6(clk),
.ck_r6_7(clk),
.ck_r6_8(clk),
.ck_r6_9(clk),
.ck_r6_10(clk),
.ck_r6_11(clk),
.ck_r6_12(clk),
.ck_r6_13(clk),
.ck_r6_14(clk),
.ck_r6_15(clk),
.ck_r6_16(clk),
.ck_r6_17(clk),
.ck_r6_18(clk),
.ck_r6_19(clk),
.ck_r6_20(clk),
.ck_r6_21(clk),
.ck_r6_22(clk),
.ck_r6_23(clk),
.ck_r6_24(clk),
.ck_r6_25(clk),
.ck_r6_26(clk),
.ck_r6_27(clk),
.ck_r6_28(clk),
.ck_r6_29(clk),
.ck_r6_30(clk),
.ck_r6_31(clk),
.ck_r6_32(clk),
.ck_r6_33(clk),
.ck_r6_34(clk),
.ck_r6_35(clk),
.ck_r6_36(clk),
.ck_r6_37(clk),
.ck_r6_38(clk),
.ck_r6_39(clk),
.ck_r6_40(clk),
.ck_r6_41(clk),
.ck_r6_42(clk),
.ck_r6_43(clk),
.ck_r6_44(clk),
.ck_r6_45(clk),
.ck_r6_46(clk),
.ck_r6_47(clk),
.ck_r6_48(clk),
.ck_r6_49(clk),
.ck_r6_50(clk),
.ck_r6_51(clk),
.ck_r6_52(clk),
.ck_r6_53(clk),
.ck_r6_54(clk),
.ck_r6_55(clk),
.ck_r7_0(clk),
.ck_r7_1(clk),
.ck_r7_2(clk),
.ck_r7_3(clk),
.ck_r7_4(clk),
.ck_r7_5(clk),
.ck_r7_6(clk),
.ck_r7_7(clk),
.ck_r7_8(clk),
.ck_r7_9(clk),
.ck_r7_10(clk),
.ck_r7_11(clk),
.ck_r7_12(clk),
.ck_r7_13(clk),
.ck_r7_14(clk),
.ck_r7_15(clk),
.ck_r7_16(clk),
.ck_r7_17(clk),
.ck_r7_18(clk),
.ck_r7_19(clk),
.ck_r7_20(clk),
.ck_r7_21(clk),
.ck_r7_22(clk),
.ck_r7_23(clk),
.ck_r7_24(clk),
.ck_r7_25(clk),
.ck_r7_26(clk),
.ck_r7_27(clk),
.ck_r7_28(clk),
.ck_r7_29(clk),
.ck_r7_30(clk),
.ck_r7_31(clk),
.ck_r7_32(clk),
.ck_r7_33(clk),
.ck_r7_34(clk),
.ck_r7_35(clk),
.ck_r7_36(clk),
.ck_r7_37(clk),
.ck_r7_38(clk),
.ck_r7_39(clk),
.ck_r7_40(clk),
.ck_r7_41(clk),
.ck_r7_42(clk),
.ck_r7_43(clk),
.ck_r7_44(clk),
.ck_r7_45(clk),
.ck_r7_46(clk),
.ck_r7_47(clk),
.ck_r7_48(clk),
.ck_r7_49(clk),
.ck_r7_50(clk),
.ck_r7_51(clk),
.ck_r7_52(clk),
.ck_r7_53(clk),
.ck_r7_54(clk),
.ck_r7_55(clk),
.ck_r7_56(clk),
.ck_r7_57(clk),
.ck_r7_58(clk),
.ck_r7_59(clk),
.ck_r7_60(clk),
.ck_r7_61(clk),
.ck_r7_62(clk),

.ck_r3_56(clk),
.ck_r3_57(clk),
.ck_r3_58(clk),
.ck_r3_59(clk),
.ck_r3_60(clk),
.ck_r3_61(clk),
.ck_r3_62(clk),
.ck_r3_63(clk),
.ck_r4_56(clk),
.ck_r4_57(clk),
.ck_r4_58(clk),
.ck_r4_59(clk),
.ck_r4_60(clk),
.ck_r4_61(clk),
.ck_r4_62(clk),
.ck_r4_63(clk),
.ck_r5_56(clk),
.ck_r5_57(clk),
.ck_r5_58(clk),
.ck_r5_59(clk),
.ck_r5_60(clk),
.ck_r5_61(clk),
.ck_r5_62(clk),
.ck_r5_63(clk),
.ck_r6_56(clk),
.ck_r6_57(clk),
.ck_r6_58(clk),
.ck_r6_59(clk),
.ck_r6_60(clk),
.ck_r6_61(clk),
.ck_r6_62(clk),
.ck_r6_63(clk),
.sa(sa),.sq(su_q),.mx(553'd0),.rb0(551'd0),.rb1(551'd0),.rb2(551'd0),
.ld(),.mo(),.mee(1'b1),
.svr(svr),.svr_rdy(),.svq(svq),.svq_v(svq_v),.svw(svw),.ar(ar),.xaw(),
.write_commit_v(cv),.write_commit_line(cl),.write_commit_mask(cm),
.q_epoch(qe),.q_start(qs),.q_committed(qsr),.q(q),.q_done(qd),.fault(fault));
function automatic [511:0] image(input integer row);
integer l;begin for(l=0;l<16;l=l+1)image[32*l+:32]=32'h3f800000+16*row+l+epoch*32768;end
endfunction
always @(negedge clk) if(rst_n)begin
cycles=cycles+1;
if(su_expected_v[EXPECTED_SU_VL])begin
 su_replies=su_replies+3;
 if(su_q!==su_expected_q[EXPECTED_SU_VL])begin errors=errors+1;$display("FAIL static SU reply cycle=%0d VL=%0d",cycles,EXPECTED_SU_VL);end
end
if(fv)begin
 if(fb!==5'(fence_commits) || ft!==59'h12345678)$fatal(1,"FAIL fence beat/tag");
 if(cycles-awcycle[fb]!=9)$fatal(1,"FAIL fence output latency");
 fence_commits=fence_commits+1;
end
for(integer b=7;b<39;b=b+1)if(cv[b] && cl[8*b+:8]==49)begin
 if(cm[16*b+:16]!==16'hffff)begin errors=errors+1;$display("FAIL commitmask bank%0d",b+24);end
 if(cycles-awcycle[b-7]!=8)$fatal(1,"FAIL actual commit latency");
 commits=commits+1;
end
if(q[523])begin
 if(q[516:512]!==beats[4:0] || q[511:0]!==image(856+beats))begin errors=errors+1;$display("FAIL beat=%0d tag=%0d",beats,q[516:512]);end
 if(cycles!=start_cycle+15+DELTA+beats)begin errors=errors+1;$display("FAIL Q cadence cycle%0d expected%0d",cycles,start_cycle+15+DELTA+beats);end
 beats=beats+1;
end
if(svq_v)begin
 if(responses>=requests || svq!==image(3167+responses%32) || cycles!=req_start+13+DELTA+responses)begin
  errors=errors+1;$display("FAIL seq response%0d cycle=%0d expected=%0d",responses,cycles,req_start+13+DELTA+responses);
 end
 responses=responses+1;
end
end
always @(posedge clk)if(rst_n)begin
 if(ar[519])awcycle[ar[516:512]]=cycles;
 if(qs)start_cycle=cycles;
 if(svr[20])begin if(requests==0)req_start=cycles;requests=requests+1;end
end
integer i,t;
initial begin
repeat(5)@(negedge clk);rst_n=1;
repeat(8)@(negedge clk);qe=1;@(negedge clk);qe=0;
// Both row sources active: attention writes must not replace sequencer Q writes or lose credits.
for(i=0;i<32;i=i+1)begin
 svw={1'b1,20'(856+i),image(856+i)};
 ar={1'b1,1'b0,6'((i+(CONFLICT_MUT?9:0))%32),image(3167+i) ^ ((COMMIT_MUT==7 && i==31)?512'd1:512'd0)};
 @(negedge clk);
end
svw=0;ar=0;
// Compiler reserves16 drain/visibility edges; commit coverage is checked,never used to move this start.
repeat(16)@(negedge clk);
qs=1;@(negedge clk);qs=0;
repeat(46+DELTA)@(negedge clk);
if(fence_commits!=32 || ff || !fc)$fatal(1,"FAIL fence commits=%0d fault=%0d complete=%0d",fence_commits,ff,fc);
if(commits!=32)begin errors=errors+1;$display("FAIL commits=%0d",commits);end
if(beats!=32 || fault)begin errors=errors+1;$display("FAIL beats=%0d fault=%0d",beats,fault);end
// Fixed interval1 row service:256 requests in256 consecutive cycles,exact13-edge responses.
for(i=0;i<256;i=i+1)begin svr={1'b1,20'(3167+i%32)};@(negedge clk);end
svr=0;repeat(16+DELTA)@(negedge clk);
if(responses!=256)begin errors=errors+1;$display("FAIL responsecount%0d",responses);end
// Repeat via the REAL shared native SU producer pack; fresh coverage cannot inherit the prior epoch.
repeat(3)@(negedge clk);epoch=1;beats=0;qe=1;@(negedge clk);qe=0;
for(i=0;i<8;i=i+1)begin
 swa0=24'(13696+64*i);swa1=swa0+1;swmask=64'hffffffffffffffff;
 swdata={image(859+4*i),image(858+4*i),image(857+4*i),image(856+4*i)};
 @(negedge clk);
end
swmask=0;
repeat(16)@(negedge clk);
qs=1;@(negedge clk);qs=0;
repeat(46+DELTA)@(negedge clk);
if(beats!=32 || fault)begin errors=errors+1;$display("FAIL SU beats=%0d fault=%0d",beats,fault);end
// Compiler-reserved SU read burst after the real epoch1 SU write producer.
// Actual three mapped operand copies return64rawFP32words each, every edge.
for(i=0;i<256;i=i+1)begin
 su_re=3'b111;
 for(integer copy=0;copy<3;copy=copy+1)begin
  su_a0[copy*24+:24]=24'((856+(i+copy*5)%28)*16);
  su_a1[copy*24+:24]=su_a0[copy*24+:24]+1;
 end
 @(negedge clk);
end
su_re=0;repeat(EXPECTED_SU_VL+4)@(negedge clk);
if(su_replies!=768)begin errors=errors+1;$display("FAIL static SU count=%0d",su_replies);end
if(errors==0)$display("PASS vm_die_static real_Q_rows=64 words=1024 attention_rows=32 actual_commit_edges=8 fenced_commit_edges=9 TAG59=checked seq_requests=%0d fixed_RL=%0d Q_cadence=1 RO=%0d real_relay_tiles=%0d SU_replies=%0d SU_VL=%0d",requests,12+EXPECTED_RO,RETURN_RO,PARTITIONED?NCK:0,su_replies,EXPECTED_SU_VL);
else $display("FAIL vm_die_static errors=%0d",errors);
$finish;
end
endmodule
