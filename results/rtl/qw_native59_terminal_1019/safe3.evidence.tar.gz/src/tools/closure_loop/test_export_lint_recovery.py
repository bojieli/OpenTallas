import base64
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import export_lint_recovery as E


class ExportLintRecovery(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.run = Path(self.tmp.name)
        self.base = self.run / 'routes/L/work/orfs/results/asap7/block/base'
        self.base.mkdir(parents=True)
        for ext in ('odb', 'sdc', 'spef'):
            (self.base / ('6_final.' + ext)).write_text('retained original ' + ext)
        (self.run / 'cl').mkdir()
        (self.run / 'cl/child_lint.py').write_text('original frozen lint')
        (self.run / 'cl/routed_ioref.a1_meas').mkdir()
        (self.run / 'cl/routed_ioref.a1_meas/app0.sdc').write_text('actual measured private SDC')
        (self.run / 'record').mkdir()
        (self.run / 'record/child_lint.json').write_text('{"verdict":"FAIL"}')
        self.j = dict(name='station', run=str(self.run), status='NEEDS_HUMAN', stage_key='collect',
                      commit_full='a' * 40, spec=dict(ref_tile=True), freeze_helper_overlay=True,
                      events=['route done (rc=0)', 'verdict -> CLOSED'],
                      crashes=[dict(tail='child_lint FAIL (b) pg: VDD: 0 full-length stripes')],
                      metrics=dict(drc=0, ss_ps=333.72, ff_ps=29.9, orfs_dir=str(self.base.parents[3])),
                      route_overlay_plan=dict(files=[dict(path='tools/hier_contract/child_lint.py',
                          sha256=E.digest(self.run / 'cl/child_lint.py'))]))
        (self.run / 'cl/helper_overlay_plan.json').write_text(json.dumps(self.j['route_overlay_plan']))
        data = b'new source-pinned lint'
        self.request = dict(job=self.j, helper_commit='b' * 40, helper_sha256=hashlib.sha256(data).hexdigest(),
                            helper_b64=base64.b64encode(data).decode())

    def test_preserves_originals_and_uses_only_explicit_lint(self):
        rec = E.prepare(self.request)
        self.assertEqual((self.run / 'cl/child_lint.py').read_text(), 'original frozen lint')
        d = Path(rec['directory'])
        self.assertEqual((d / 'original_record/child_lint.json').read_text(), '{"verdict":"FAIL"}')
        self.assertEqual(json.loads((d / 'original_job.json').read_text()), self.j)
        src = self.run / 'src'
        (src / 'tools/hier_contract').mkdir(parents=True)
        before, after = E.stage_script(rec, str(src))
        p = subprocess.run(['bash', '-c', before + after], capture_output=True, text=True)
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual((src / 'tools/hier_contract/child_lint.py').read_text(), 'new source-pinned lint')
        with self.assertRaises(FileExistsError):
            E.prepare(self.request)

    def test_guard_rejects_modified_physical_input_or_frozen_helper(self):
        rec = E.prepare(self.request)
        manifest = json.loads((Path(rec['directory']) / 'inputs.json').read_text())
        for path in (self.base / '6_final.odb', self.base / '6_final.sdc', self.base / '6_final.spef',
                     self.run / 'cl/child_lint.py', self.run / 'cl/helper_overlay_plan.json',
                     self.run / 'cl/routed_ioref.a1_meas/app0.sdc',
                     Path(rec['directory']) / 'child_lint.py'):
            old = path.read_bytes()
            path.write_bytes(old + b'changed')
            with self.assertRaisesRegex(ValueError, 'immutable input changed'):
                E.verify(manifest)
            path.write_bytes(old)
        E.verify(manifest)

    def structured_receipt(self, fails):
        self.j['crashes'] = [dict(tail='REF_TILE export station: child_lint FAIL child_lint FAIL')]
        p = self.run / 'record/views/station/provenance/abstract_pin_stub.json'
        p.parent.mkdir(parents=True, exist_ok=True)
        lint = dict(verdict='FAIL', fails=fails)
        p.write_text(json.dumps(dict(child_lint=lint)))
        evidence = dict(path=str(p), sha256=E.digest(p), child_lint=lint)
        self.request['pg_lint_evidence'] = evidence
        return p, evidence

    def test_generic_error_recovers_only_retained_pg_receipt(self):
        p, evidence = self.structured_receipt(['(b) pg: VDD: stripes span only 50%'])
        E.eligible(self.j, evidence)
        rec = E.prepare(self.request)
        d = Path(rec['directory'])
        preserved = d / 'original_record/views/station/provenance/abstract_pin_stub.json'
        self.assertEqual(preserved.read_bytes(), p.read_bytes())
        # The fresh export may replace record/, but preserved evidence is immutable.
        p.write_text('new export receipt')
        E.verify(json.loads((d / 'inputs.json').read_text()))
        preserved.write_text('changed historical evidence')
        with self.assertRaisesRegex(ValueError, 'immutable input changed'):
            E.verify(json.loads((d / 'inputs.json').read_text()))

    def test_structured_receipt_rejects_other_lint_or_changed_receipt(self):
        p, evidence = self.structured_receipt(['(b) pg: missing stripe', '(f) blocked pin'])
        with self.assertRaisesRegex(ValueError, 'no recorded PG'):
            E.prepare(self.request)
        p, evidence = self.structured_receipt(['(b) pg: missing stripe'])
        p.write_text('{}')
        with self.assertRaisesRegex(ValueError, 'differs from retained export'):
            E.prepare(self.request)

    def test_guard_rejects_tampered_manifest_and_verifier_before_execution(self):
        rec = E.prepare(self.request)
        for name in ('inputs.json', 'verify.py'):
            path = Path(rec['directory']) / name
            old = path.read_bytes()
            path.write_bytes(old + b'changed')
            before, _ = E.stage_script(rec, str(self.run / 'src'))
            p = subprocess.run(['bash', '-c', before], capture_output=True, text=True)
            self.assertEqual(p.returncode, 91)
            path.write_bytes(old)

    def test_admission_refuses_non_collect_or_physical_failure_or_repeat(self):
        for patch in (dict(status='CLOSED'), dict(stage_key='route'), dict(freeze_helper_overlay=False),
                      dict(export_lint_recovery={'old': True}), dict(events=[]), dict(failed_checks=['drc']),
                      dict(metrics=dict(drc=1)), dict(metrics=dict(drc=0, ss_ps=-1, ff_ps=2)),
                      dict(crashes=[dict(tail='timing failed')])):
            with self.subTest(patch=patch), self.assertRaises(ValueError):
                E.eligible(dict(self.j, **patch))

    def test_missing_or_changed_inputs_refused_before_snapshot(self):
        (self.base / '6_final.spef').unlink()
        with self.assertRaisesRegex(ValueError, 'missing routed spef'):
            E.prepare(self.request)
        self.assertFalse((self.run / 'cl/export-lint-recovery').exists())

    def test_actual_publish_keeps_original_overlay_and_adds_separate_recovery_receipt(self):
        import closure_loop as C
        recovery = E.prepare(self.request)
        original = copy.deepcopy(self.j['route_overlay_plan'])
        j = dict(self.j, export_lint_recovery=recovery, host='ot-epyc1tb')
        j['spec'] = dict(source=dict(branch='codex/test'), block='station', owner='test',
                         dry_run_git=True, record=[])
        state = self.run / 'state'
        response = SimpleNamespace(stdout='a' * 40, returncode=0)
        with patch.object(C, 'STATE', state), patch.object(C, 'claude_owns_main', return_value=False), \
             patch.object(C, 'gfetch'), patch.object(C, 'wt_add', side_effect=lambda p,*a: p.mkdir(parents=True,exist_ok=True)), \
             patch.object(C, 'wt_rm'), patch.object(C, 'git', return_value=response), \
             patch.object(C, 'sh', return_value=SimpleNamespace(stdout='',returncode=0)):
            C.publish(j, self.j['metrics'])
            target = state / 'git/station-commit/results/closure_loop/station/verdict.json'
            published = json.loads(target.read_text())
            self.assertEqual(published['route_overlay_plan'], original)
            self.assertEqual(published['export_lint_recovery'], recovery)
            self.assertEqual(published['export_lint_recovery']['helper_commit'], 'b' * 40)
            self.assertEqual(published['export_lint_recovery']['manifest_sha256'], recovery['manifest_sha256'])
            j.pop('export_lint_recovery')
            C.publish(j, self.j['metrics'])
            self.assertNotIn('export_lint_recovery',json.loads(target.read_text()))
        self.assertEqual(self.j['route_overlay_plan'], original)


if __name__ == '__main__':
    unittest.main()
