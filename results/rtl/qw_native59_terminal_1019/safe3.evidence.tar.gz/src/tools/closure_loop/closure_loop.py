#!/usr/bin/env python3
"""OpenTallas scripted closure loop (owner-approved 2026-10-06): block closure that keeps running with no AI in the loop.

A job is ONE JSON file (tools/closure_loop/jobs/<name>.json on origin/main, or the drop dir
/tmp/claude-review-20261003/closure_jobs/<name>.json, or this checkout's jobs/ dir; see README.md).  The daemon
(systemd --user unit closure-loop.service on localhost; it only dispatches over ssh) takes each job through

    sync source (git archive of the pinned commit -> <host base>/<name>/src)
    -> bench stages (each: expect pass | fail; an exact bench must PASS, a negative control must FAIL)
    -> calibrate (default ON): synth -> floorplan -> place -> CTS only, measure the real SS/FF clock insertion at
       the boundary registers (ck_insertion.py), regenerate the IO SDC from it (job's sdc_cmd, env CK_*), so the
       route's IO budgets match the block's own tree (no 10^5 hold buffers from a guessed insertion)
    -> route -> signoff -> VERDICT (SS >= +15 ps, FF >= +15 ps at 833.333, DRC 0, extra checks)
    -> collect -> export -> commit the record + view on the job's branch (explicit-path staging),
       trial-merge the branch into its merge target in a scratch worktree, push, ledger line
    or -> failure summary (worst 10 path classes per failing check) -> NEEDS_RTL
    or (stage crash) -> retry ONCE (another host if resource-related) -> NEEDS_HUMAN

Rules it enforces: load cap (load1 + pending + threads <= host cap = 1.2 x cores; MemAvailable >= peak + 32 GB),
NVMe run roots (hosts.json), one route per (block, source commit), it never kills a process it did not start
(cancel only stops its own stage process group and containers mounting its own run dir), every run registered in
/home/ubuntu/opentallas-monitor/experiment.py (owner Claude:closure-loop).

    closure_loop.py daemon [--interval 60]     # the service
    closure_loop.py tick                       # one pass (debug)
    closure_loop.py status                     # table of jobs
    closure_loop.py validate <job.json>        # check a spec before dropping it
    closure_loop.py submit-recheck --since ISO [--requeue] [--log F]   # re-judge FLOORPLAN_MARGIN jobs at submit
    closure_loop.py retry <name>               # human: re-queue a NEEDS_HUMAN job from its failed stage
                                               #   FLOORPLAN_MARGIN: re-lints with the current tools first; requeued if it passes
    closure_loop.py retry-eco <name> [--why]   # human: re-run the hold ECO (current rev) on a hold-only NEEDS_RTL job
    closure_loop.py ioref-rejudge <name>       # human: re-judge a NEEDS_RTL job at its ROUTED clock insertion (no re-route)
    closure_loop.py rebudget-rejudge <name> --rb budget_rbN --sdc F [--dry]   # re-judge under a re-derived die-link IO budget
    closure_loop.py cancel <name>              # stop this loop's own stage for <name>; status CANCELLED
"""
from __future__ import annotations

import argparse
import datetime as dt
import fcntl
import glob
import json
import hashlib
import os
import re
import shlex
import math
from contextlib import contextmanager, ExitStack, nullcontext
from functools import wraps
import shutil
import threading
from concurrent.futures import ThreadPoolExecutor
import subprocess
import tempfile
import sys
import time
import traceback
from pathlib import Path

from ssh_transport import command as transport_command, direct_command, session_open_refused
from source_archive import build_archive, repo_path
import git_mirror
from postroute_recovery import remote_command as postroute_probe_command
import submit_lint
import bench_count
import macro_clk
import retired_hosts
import helper_overlay as HO
import status_report

HERE = Path(__file__).resolve().parent
REPO = Path(os.environ.get("CL_REPO", "/home/ubuntu/OpenTallas"))          # git object store for archive/commit/merge
STATE = Path(os.environ.get("CL_STATE", str(Path.home() / ".local/state/closure_loop")))
HELPER_STORE = STATE / "frozen_helpers"   # content-addressed frozen helper bytes (sha256); no cleanup touches STATE
REVIEW = Path(os.environ.get("CL_REVIEW", "/tmp/claude-review-20261003"))
DROP = REVIEW / "closure_jobs"
LEDGER = REVIEW / "CLOSURE_LOOP_LEDGER.md"
STATUS_MD = REVIEW / "CLOSURE_LOOP_STATUS.md"
EXPERIMENT = Path("/home/ubuntu/opentallas-monitor/experiment.py")
OWNER = "Claude:closure-loop"
SS_MIN, FF_MIN = 0.0, 0.0             # OWNER DECISION 2026-10-07 20:1x: ACCEPT at SS >= 0 / FF >= 0 / DRC 0 at 833.333 sign-off (+15 is the DESIGN target: route 770, repair hold margin 50; was +15/+15 since 10-06 18:15)
RAM_HEADROOM_GB = 32
LIGHT_STAGE_RAM_GB = 8      # drive-0849: bench / collect / export stages
SYNC_DISK_GB = 16           # SYNC-ROOM: disk one source sync may write (src/ + bench_src*/ beyond the view store)
LIGHT_DISK_FLOOR_GB = 30    # their run-root / disk-root floor (full floor for route / calibrate / ECO)
ADMIT_SAFETY_GB = 16          # fixed safety over a job's own RAM request (owner: no reservation for future growth)
PENDING_WINDOW_S = 600
PENDING_RAM_WINDOW_S = 180    # RAM reservation of a launch (threads keep the 10-min ramp allowance)
# EARLY_FAIL_* (stuckscan 2026-10-08): a route stopped by an early-fail gate (stuckscan.py hopeless()): redesign work
EARLY_FAIL = ("EARLY_FAIL_SETUP", "EARLY_FAIL_HOLD", "EARLY_FAIL_CONGESTION", "EARLY_FAIL_DRC", "EARLY_FAIL_STALL")
TERMINAL = {"SMOKE_OK", "CLOSED", "LOST_CLOSED", "NEEDS_RTL", "NEEDS_HUMAN", "NEEDS_BUDGET", "REFUSED", "CANCELLED", "INVALID",
            "FLOORPLAN_MARGIN", "PREROUTE_MARGIN", *EARLY_FAIL}
RESOURCE_RE = re.compile(r"OT_FLOW_MISSING|Cannot allocate memory|[Oo]ut of memory|\bOOM\b|oom-kill|No space left|ENOSPC|std::bad_alloc|"
                         r"Resource temporarily unavailable|Killed\b|signal 9|exit code 137|MemoryError|"
                         r"admission (?:timed out|refused)|[Bb]us error|SIGBUS|Segmentation fault|internal compiler error|"
                         r"g\+\+: fatal error|cc1plus: .*(?:killed|error)|"
                         # EARLYOOM-SIGTERM 2026-10-16: earlyoom (-m 3 --prefer python3) SIGTERMs the stage wrapper
                         # (oom_score_adj 500), not the hog; bash prints 'Terminated <cmd>', status flow_rc=143.
                         # hgi_sm_xl2_bfqg-local1 / s81engm_lkp_static14-st6 / s81hc_retcol_c2 went NEEDS_HUMAN
                         # 'resource=False' after a same-host retry into the same pressure (an 80-91 GB die GRT).
                         r"^\s*Terminated\s|flow_rc=143|exit code 143", re.M)
# DETERMINISTIC-NO-RETRY 2026-10-15: route first errors that never passed on a same-input retry (see crash())
DETERMINISTIC_ROUTE_ERR_RE = re.compile(r"\b(?:DPL-0033|GPL-0305|PPL-0093|PPL-0111|ANT-0008|PDN-0233|MPL-0020|STA-0340)\b")
# a bench whose TOOLS crashed (compiler bus error, segfault, OOM) is not a verdict on the RTL (hbm_su_red_slice_6f2d14e36:
# g++ bus error on EPYC2 -> NEEDS_RTL although the bench never ran): crash -> retry once on another host -> NEEDS_HUMAN
BENCH_CRASH_RC = (124, 126, 127, 134, 135, 137, 139, 143)   # 126/127: cannot execute / not found (a truncated
# binary left by a stage killed in a host reset: s81fill_hstnv_1029-f8 'Vtb: Permission denied' was judged a mutant that
# failed to fail -> NEEDS_RTL); a crash is retried once with the bench's own output directories cleared
BENCH_KEEP_DIRS = {"src", "cl", "routes", "record", "eco", "orfs", "work"}


def bench_scratch_dirs(cmd):
    """the per-bench output directories a bench command names under the run dir ({RUN}/<dir>...), never the source
    snapshots, the loop's cl/ or route trees"""
    out = []
    for d in re.findall(r"\{RUN\}/([A-Za-z0-9_.-]+)", cmd or ""):
        if d not in BENCH_KEEP_DIRS and not d.startswith(("bench_src", "src")) and d not in out and d not in (".", ".."):
            out.append(d)
    return out


def bench_crashed(st, rc, tail):
    if rc in BENCH_CRASH_RC or RESOURCE_RE.search(tail):
        return st["expect"] == "fail" or not WORK_RE.search(tail)
    return False


# BENCH-TOOL-RACE (ROOT-INF2 2026-10-18): Verilator 5.050 --hierarchical writes a two-target rule (<blk>.sv <blk>.mk) into
# <top>_hier.mk; `make -j` runs that hier verilation twice in parallel, one copy rewrites the block's precompiled header
# while the other compiles against it -> "one or more PCH files were found, but they were invalid" / "__pch.h.fast: No such
# file".  The build exits 2 and the bench never ran: hcoll_v7_tkm_tile_e86 (HBM-TKM3 2/2 builds) would have been
# NEEDS_RTL on a race.  A failing bench whose logs (stage log, spec logs, or any *.log written under the run's bench
# tree during the stage) carry that signature is a tool crash: retried once, then NEEDS_HUMAN -- never an RTL verdict.
TOOL_RACE_RE = re.compile(r"one or more PCH files were found, but they were invalid|"
                          r"fatal error: \S*__pch\.h\.(?:fast|slow)\S*: No such file", re.M)


def bench_tool_race(v, tail):
    """the PCH-race line of a failed bench (tail first, then *.log under {run}/bench newer than the stage start), or ''"""
    m = TOOL_RACE_RE.search(tail or "")
    if m:
        return m.group(0)
    t, run = v.get("stage_tag"), v.get("run")
    if not t or not run or not v.get("host"):
        return ""
    pat = TOOL_RACE_RE.pattern.replace("\\S", "[^[:space:]]").replace("(?:", "(")
    r = ssh(v["host"], f"[ -f {run}/cl/{t}.start ] || exit 0; find {run}/bench -maxdepth 5 -name '*.log' -newer {run}/cl/{t}.start "
                       f"-size -200M -print0 2>/dev/null | xargs -0 -r grep -hoE -m1 {shlex.quote(pat)} 2>/dev/null | head -1; true",
            timeout=120)
    return (r.stdout or "").strip()[:300] if not r.returncode else ""
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$")
DEFAULT_SRC_PATHS = ["tools", "rtl", "physical", "Makefile", "configs", "src"]   # drive-1010: + configs (5 MB) / src (1 MB): benches importing tools/* need both
FLEET_LOCK = threading.RLock()     # host choice / capacity check / launch are atomic across job threads
GIT_LOCK = threading.Lock()        # fetches into the shared object store
PUBLISH_LOCK = threading.Lock()    # one commit/merge at a time
WORKERS = 192
SYNC_SLOTS = 64          # workers QUEUED/SYNC jobs may hold at once (the rest keep READY / RUNNING / ECO moving)
# declared threads of own running stages count at 0.6 against the cap: full declared threads blocked EPYC2 at load1 40
# (7 calibrates in synth/place, ~1 core each), load1 alone let EPYC3 reach 342 (27 routes ramping into DRT together)
OWN_RUNNING_WEIGHT = 0.6
HM_DEFAULT_SINCE = "2026-10-06T20:40"
HM_LOW_SINCE = "2026-10-07T04:17"      # new jobs from here: route hold margin 10 ps, hold closed by the post-route ECO
# FLOW-HOLD (2026-10-07): jobs created from here route with multi-mode hold repair (OT_ROUTE_HOLD_CORNERS=mm: SS setup +
# FF hold under the FF sign-off constraints at CTS / global route) and HM_MM route hold margin (applies at FF only)
MM_SINCE = "2026-10-07T21:00"
# OWNER OPTION B (2026-10-07 20:45): closure = setup at TT + hold at FF + DRC 0.  Every calibrate / route launched from
# here routes with CORNER=TC (setup repair at TT; with mm, hold at FF) unless spec "route_corner" names another corner;
# hold ECOs time the setup scene at TT.  SS setup is recorded as a sensitivity (ss_sensitivity_ps).
OPTB_SINCE = "2026-10-07T20:20"
# CALIB-CORNER (2026-10-08, orphans-2 finding): jobs created from here calibrate at the ROUTE corner and reference the
# route-time IO SDC to the route-corner insertion.  Every recipe builds its route IO SDC from CK_SS_* (io_vclk_m_$CK_SS_MEAN,
# make_sdc.py --l-ss-*, budget SDCs); a TC route signs off at the routed TT reference, so with CK_SS_* at the SS insertion
# the router saw ~190 ps of output setup credit that sign-off removed (hfd_router h1c: route TT -71.83, routed reference
# -152.67).  For a TC/TT route: calibrate runs with OT_ORFS_CORNER=<corner> (CTS at TT), ck_insertion.py --route-corner
# puts the TT insertion in CK_SS_* (SS values in CK_SSLIB_*), the parallel-calibrate assumption is the block's TT
# (routed grade, else calibrate TT) from measured_insertion.json, and a TC job with no TT value calibrates sequentially
# (CTS-only, minutes).  SS-corner routes keep the SS reference.  Earlier jobs keep their behaviour.
ROUTE_REF_SINCE = "2026-10-08T19:05"
SETUP_LIB = "TT"
# VT-SWAP ECO (merge-eco 2026-10-09, from eco-sweep e494ff8ac): a route whose only miss is a THIN TT setup miss
# (TT in [VTSWAP_TT_FLOOR, 0), FF >= 0, DRC 0, checks/benches clean) runs vtswap_eco.sh (RVT->LVT master swaps on the
# TT paths, prospective <= VTSWAP_CAP_PCT % LVT, FF hold guard, no re-route) as its ECO stage before it is judged
# NEEDS_RTL.  Targets are tried in order (a miss at 10 ps re-runs once at 5 ps: fewer swaps, under the cap -- eco-sweep
# wfc_lnk / topk closed on the 5 ps rerun).  spec hold_eco.vtswap: false turns it off; vtswap_targets / vtswap_cap_pct override.
VTSWAP_TT_FLOOR = -45.0
VTSWAP_TARGETS = (10.0, 5.0)
VTSWAP_CAP_PCT = 2.0
# COMBO ECO (drive-0849 2026-10-09, coordinator-approved): a route that misses BOTH thinly -- TT in [COMBO_TT_FLOOR, 0) AND FF
# in [COMBO_FF_FLOOR, 0), DRC 0, checks/benches clean -- gets neither the VT-swap ECO (needs FF >= 0) nor the hold ECO (needs
# TT >= 0).  It runs vtswap_eco.sh (RVT->LVT on TT paths, <= VTSWAP_CAP_PCT % LVT) and then hold_eco.sh stacked on the
# VT-swap result (ECO_RB_DB=6_final.odb) as ONE ECO stage; the hold-ECO completion path judges / installs / re-verdicts it.
# (The manual /tmp/sc/combo_eco.py launches, made automatic.)  spec hold_eco.combo: false turns it off.
COMBO_TT_FLOOR = -45.0
COMBO_FF_FLOOR = -30.0
HM_MM = 0.050
DEFAULT_NEEDS = {"bench": ["verilator", "iverilog", "yosys"], "calibrate": ["orfs"], "route": ["orfs"],
                 "signoff": ["orfs"], "collect": [], "export": [], "summary": ["orfs"]}
STAGE_DEFAULTS = {"bench": (4, 16), "route": None, "signoff": (4, 16), "collect": (1, 1), "export": (1, 1),
                  "summary": (2, 16)}


# ----------------------------------------------------------------------------------------------------- utilities
def now_iso():
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def log(msg):
    print(f"{now_iso()} {msg}", flush=True)


def sh(cmd, timeout=600, check=False, input=None, cwd=None):
    r = subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True, timeout=timeout,
                       input=input, cwd=cwd)
    if check and r.returncode:
        raise RuntimeError(f"command failed rc={r.returncode}: {cmd if isinstance(cmd, str) else ' '.join(cmd)}\n"
                           f"{r.stdout[-1500:]}\n{r.stderr[-1500:]}")
    return r


def ssh(host, script, timeout=120, check=False, input=None):
    """Run a shell script on host.  Without input the script goes in on stdin (bash -s); with input, the script is
    the remote command line and input is piped to it."""
    if is_local(host):          # localhost runs loop jobs directly (OWNER 2026-10-07 05:00), no ssh to itself
        if input is None:
            return sh(["bash", "-s"], timeout=timeout, check=check, input=script)
        return sh(["bash", "-c", script], timeout=timeout, check=check, input=input)
    try:
        # The lease wait counts against the caller's timeout: a host whose channels are all held
        # (slow transfers, a wedged master) fails this call as a TimeoutExpired instead of parking
        # the caller -- the main thread in write_status() waited 20+ min on 2026-10-10.
        with transport_command(host, wait_s=timeout) as base:
            remote = "bash -s" if input is None else script
            payload = script if input is None else input
            # Inspect only a completed SSH result.  Timeouts/disconnects may have executed
            # the command and must never be replayed.  Keep this same channel lease and
            # caller admission while bypassing only an explicit unopened mux session.
            r = sh(base + [remote], timeout=timeout, check=False, input=payload)
            if session_open_refused(r):
                r = sh(direct_command(host) + [remote], timeout=timeout, check=False, input=payload)
            if check and r.returncode:
                raise RuntimeError(f"ssh command failed rc={r.returncode} on {host}\n"
                                   f"{r.stdout[-1500:]}\n{r.stderr[-1500:]}")
            return r
    except RuntimeError as e:
        # an unreachable host (ssh master refused, e.g. PVE1 kex reset 2026-10-08 00:50) is an rc=255 ssh failure that
        # every caller already handles, not a daemon crash (the daemon crash-looped on the toolchain probe for ~45 min)
        if check or not str(e).startswith("ssh: master connection failed"):
            raise
        return subprocess.CompletedProcess(args=[host], returncode=255, stdout="", stderr=str(e))


def is_local(host):
    return host in ("localhost", "local")


def rpath(host, path):
    """rsync source spec of a path on host"""
    return path if is_local(host) else f"{host}:{path}"


def gfetch(*refs, timeout=600, tries=3):
    """Fetch refs into origin/<ref>.  The object store is the shared checkout, where another git process can hold a
    ref lock; an unchecked failed fetch left origin/main stale and sent pq_r128_expanded_b1528203c to NEEDS_HUMAN
    "not on origin/main" for a commit already on main (10-07 11:43).  Retry, update the tracking refs explicitly,
    and log a fetch that still fails."""
    spec = [f"+refs/heads/{r}:refs/remotes/origin/{r}" for r in refs]
    r = None
    for attempt in range(tries):
        with GIT_LOCK:
            r = sh(["git", "-C", str(REPO), "fetch", "-q", "origin", *spec], timeout=timeout)
        if r.returncode == 0:
            return r
        if attempt + 1 < tries:
            time.sleep(5 * (attempt + 1))
    log(f"git fetch {' '.join(refs)} failed after {tries} tries (rc={r.returncode}): {r.stderr.strip()[-300:]}")
    return r


def git(*args, timeout=900, check=True, cwd=None):
    return sh(["git", "-C", str(cwd or REPO), *args], timeout=timeout, check=check)


def append_locked(path: Path, text: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a") as f:
        fcntl.flock(f, fcntl.LOCK_EX)
        f.write(text)


def hosts_table():
    return json.loads((HERE / "hosts.json").read_text())["hosts"]


def disk_roots(cfg):
    """{path: min free GB} for every filesystem a host's jobs write besides the run root (hosts.json disk_roots;
    fleet disk guard 2026-10-07: the run-root floor alone let / fill on AGIdock and localhost)"""
    return dict(cfg.get("disk_roots", {}))


def host_bases(cfg):
    """run roots a host may place NEW job dirs in (FLEET-NEW2 2026-10-19, coordinator: EPYC4/5 have two 2.9 TB scratch
    NVMe volumes and only one was used): hosts.json base + alt_bases.  A job keeps the run dir it was given."""
    return [cfg["base"]] + [b for b in cfg.get("alt_bases", []) if b != cfg["base"]]


FLEET_REF = None      # the daemon's Fleet (set in main) -- run_base reads its cached probe


def run_base(name):
    """the run root (of host_bases) with the most free disk in the latest probe; the base when unknown"""
    cfg = host_cfg(name)
    bases = host_bases(cfg)
    if len(bases) == 1 or FLEET_REF is None:
        return bases[0]
    cached = FLEET_REF.probe_cache.get(name)
    info = cached[1] if isinstance(cached, tuple) and len(cached) > 1 else None
    free = (info or {}).get("bases_gb") or {}
    return max(bases, key=lambda b: (free.get(b, -1), b == bases[0]))


def drop_retired_hosts(spec):
    """RETIRED-HOST (HOSTFIX 2026-10-17): (spec', warnings) with retired fleet hosts removed from hosts / host_require
    (retired_hosts.py; an emptied list falls back to admission) instead of an INVALID 'unknown host' verdict."""
    doc = json.loads((HERE / "hosts.json").read_text())
    return retired_hosts.drop_retired_hosts(spec, {h["name"] for h in doc["hosts"]}, retired_hosts.retired_names(doc))


def host_cfg(name):
    return next(h for h in hosts_table() if h["name"] == name)


def host_label(name):
    """Display label; a host retired from hosts.json (EPYC2/3, 10-12) shows its name instead of crashing status."""
    return next((h["label"] for h in hosts_table() if h["name"] == name), name) if name else "-"


# ------------------------------------------------------------------------------------------------- job specs
def validate(spec: dict) -> list[str]:
    e = []
    for k in ("name", "block", "owner", "source", "stages"):
        if k not in spec:
            e.append(f"missing '{k}'")
    if e:
        return e
    if not NAME_RE.match(spec["name"]):
        e.append("name must match " + NAME_RE.pattern)
    required = spec.get("host_require")
    if required is not None and (not isinstance(required, list) or not required
                                or any(not isinstance(x, str) for x in required)):
        e.append("host_require must be a nonempty list of host names, not a boolean")
    elif required and any(x not in {h["name"] for h in hosts_table()} for x in required):
        e.append("host_require contains an unknown host")
    src = spec["source"]
    if not isinstance(src, dict) or not src.get("branch") or not re.match(r"^[0-9a-f]{7,40}$", str(src.get("commit", ""))):
        e.append("source needs branch and a hex commit")
    if isinstance(src, dict) and "required_files" in src:
        files = src["required_files"]
        if not isinstance(files, list) or not files:
            e.append("source.required_files must be a nonempty list of literal repository paths")
        else:
            try:
                for value in files:
                    repo_path(value)
            except ValueError as ex:
                e.append(str(ex))
    st = spec["stages"]
    if not isinstance(st, dict) or not st.get("route", {}).get("cmd"):
        e.append("stages.route.cmd is required")
    for b in st.get("bench", []) if isinstance(st, dict) else []:
        if b.get("expect") not in ("pass", "fail") or not b.get("cmd") or not b.get("name"):
            e.append(f"bench entry needs name, cmd and expect pass|fail: {b}")
        # bench_work counts the ONE captured group: none or several read every pass as vacuous (suctlw r2 10-11, b2/xcal 10-16)
        e.extend(bench_count.count_regex_errors([b]))
        # BENCH-LINT (ROOT 2026-10-16): git in the command itself / regexes that do not compile (scripts: at intake)
        e.extend(bench_count.bench_lint([b])[0])
    benches = st.get("bench", []) if isinstance(st, dict) else []
    if spec.get("benched_by") is not None:
        bspec, berr = expand_benched_by(spec)
        if berr:
            e.append(berr)
        else:
            benches = bspec["stages"].get("bench", [])
    if not spec.get("no_bench_reason") and not (any(b.get("expect") == "pass" for b in benches)
                                                and any(b.get("expect") == "fail" for b in benches)):
        e.append("need >= 1 bench expect=pass and >= 1 expect=fail (or benched_by: a composition gate; or "
                 "no_bench_reason for a job that never merges -- a ref_tile closure candidate is REFUSED without a "
                 "behavioural bench + mutant, see BENCH-REQUIRED)")
    cal = st.get("calibrate") if isinstance(st, dict) else None
    if cal is None or (cal.get("enabled", True) and not (cal.get("cmd") and cal.get("base"))):
        if not (cal and cal.get("enabled") is False and cal.get("reason")):
            e.append("stages.calibrate is on by default: give cmd (the CTS-only run; route_view.sh jobs: the route "
                     "command with ${CL_LABEL_SUFFIX} on the label and $CL_STOP_AFTER appended) + base (glob of its "
                     "ORFS results/.../base) [+ clock, sdc_cmd], or {\"enabled\": false, \"reason\": \"...\"}")
    for sk in ("calibrate", "route", "signoff"):
        cmd = (st.get(sk) or {}).get("cmd", "") if isinstance(st, dict) else ""
        dummy = {k: "x" for k in ("RUN", "SRC", "CL", "HOST", "BLOCK", "COMMIT", "THREADS", "RAW_NAME")}
        dummy.update(NAME=label(spec["name"]), LABEL=label(spec["name"]))
        for k, val in dummy.items():
            cmd = cmd.replace("{" + k + "}", val)
        cmd = cmd.replace("${CL_LABEL_SUFFIX}", "_cal").replace("$CL_LABEL_SUFFIX", "_cal")
        for m in re.finditer(r"(?:route_view\.sh|stn_route\.sh\s+\S+\s+\S+)\s+(\S+)|--nickname-tag[ =](\S+)", cmd):
            lab = (m.group(1) or m.group(2) or "").strip("'\"")
            if lab and not re.fullmatch(r"[A-Za-z0-9_]*(\$\{?[A-Za-z_][A-Za-z0-9_]*\}?[A-Za-z0-9_]*)*", lab):
                e.append(f"stages.{sk}: route label '{lab}' is not [A-Za-z0-9_]+ (run_abi3_physical --nickname-tag "
                         f"rejects it): use {{LABEL}}${{CL_LABEL_SUFFIX}}")
    allcaps = set().union(*(set(x.get("caps", [])) for x in hosts_table()))
    if isinstance(st, dict):
        for x in list(st.get("bench", [])) + [st.get(k) or {} for k in ("calibrate", "route", "signoff", "collect", "export")]:
            if "needs" in x and not (isinstance(x["needs"], list) and set(x["needs"]) <= allcaps):
                e.append(f"needs must be a list from {sorted(allcaps)}: {x.get('needs')}")
        if not any(job_needs(spec) <= set(x.get("caps", [])) for x in hosts_table()
                   if not spec.get("hosts") or x["name"] in spec["hosts"] or spec.get("peak_ram_gb", 32) <= SMALL_JOB_GB):
            e.append(f"no allowed host has every capability this job needs ({sorted(job_needs(spec))})")
    snippets = []
    if isinstance(st, dict):
        for b in st.get("bench", []):
            snippets += [(f"bench {b.get('name')}", b.get("cmd")), (f"bench {b.get('name')} ok", b.get("ok"))]
        for k in ("calibrate", "route", "signoff", "collect", "export"):
            x = st.get(k) or {}
            snippets += [(k, x.get("cmd")), (f"{k} ok", x.get("ok")), (f"{k} sdc_cmd", x.get("sdc_cmd"))]
    vv = spec.get("verdict", {})
    snippets += [("verdict metrics_cmd", vv.get("metrics_cmd"))] + [(f"check {c.get('name')}", c.get("cmd")) for c in vv.get("checks", [])]
    for where, cmd in snippets:
        if not cmd:
            continue
        r = sh(["bash", "-n"], input=cmd, timeout=30)
        if r.returncode:
            e.append(f"{where}: bash -n syntax error: {(r.stderr or r.stdout).strip()[-300:]}")
    v = spec.get("verdict", {})
    if not v.get("corner_sta") and not v.get("metrics_cmd"):
        e.append("verdict.corner_sta (glob of a tools/w18/corner_sta.py JSON) or verdict.metrics_cmd is required")
    if not v.get("drc_metrics") and not v.get("metrics_cmd") and v.get("drc") != "skip":
        e.append("verdict.drc_metrics (glob of ORFS 5_2_route.json) is required")
    bud = spec.get("budget")
    if bud is None and has_sheet(spec.get("block", "")):
        e.append(f"block {spec['block']} has a budget sheet ({BUDGET_SHEETS}/{spec['block']}.json on origin/main): budget is "
                 f"the default -- add \"budget\": {{\"master\": \"{spec['block']}\"}} and take the IO SDCs from "
                 f"$BUDGET_SDC (route) / $BUDGET_SDC_SIGNOFF / $BUDGET_SDC_FF, or opt out with "
                 f"\"budget\": {{\"enabled\": false, \"reason\": \"...\"}}")
    if isinstance(bud, dict) and bud.get("enabled") is False:
        if not bud.get("reason"):
            e.append("budget.enabled false needs a reason")
        bud = None
    elif isinstance(bud, dict) and isinstance(st, dict) and "BUDGET_SDC" not in json.dumps(st):
        e.append("budget is set but no stage command uses $BUDGET_SDC / $BUDGET_SDC_SIGNOFF / $BUDGET_SDC_FF")
    if bud is not None:
        if not isinstance(bud, dict) or not bud.get("master"):
            e.append("budget needs {master[, clock, domain_clock[], on_deviation flag|continue, sheets_ref]}")
        elif bud.get("on_deviation", "flag") not in ("flag", "continue"):
            e.append("budget.on_deviation must be flag or continue")
        else:
            try:
                budget_files(bud, check_only=True)
            except Exception as ex:  # noqa: BLE001
                e.append(f"budget: {str(ex)[:300]}")
    for h in spec.get("hosts", []):
        if h not in [x["name"] for x in hosts_table()]:
            e.append(f"unknown host {h}")
    for r in spec.get("record", []):
        if not r.get("from") or not r.get("to") or r["to"].startswith("/") or ".." in r["to"]:
            e.append(f"record entry needs from (remote, may use {{RUN}}) and a repo-relative to: {r}")
    if spec.get("merge_target") is not None and not isinstance(spec.get("merge_target"), str):
        e.append("merge_target must be a branch name or null")
    for k in ("threads", "peak_ram_gb"):
        if not isinstance(spec.get(k, 1), (int, float)) or spec.get(k, 1) <= 0:
            e.append(f"{k} must be a positive number")
    return e


# MEASURED RAM (el1013-loop-sizing, OWNER 2026-10-13: admission is by memory only -- pack more routes per host): spec
# peak_ram_gb values are agent guesses, 4-7x above the measured ORFS process peaks on 479 of 642 blocks with a finished
# route (2026-10-13 fleet survey).  measured_peaks.json holds the largest measured peak per block; a calibrate / route
# estimate at least 2x that peak is admitted at ceil(max(1.25 x peak, peak + 4 GB)).  An unlisted block, or an estimate
# under 2x its measurement, keeps the spec value (never lowered without a measurement).  Spec opt-out: measured_ram false.
_MEASURED_PEAKS = [None, None]


def measured_block(name):
    return re.sub(r"_[0-9a-f]{7,10}(_.*)?$", "", str(name).split("-")[0])


def claim_ram(spec):
    """RAM a host choice / move claims for a job before its stage launches: the size its route will be admitted at
    (el1013-fleet3: claims counted the raw spec guess, 4-7x the measured peak, against every other launch)"""
    return sized_ram(spec, spec.get("peak_ram_gb", 32))


def measured_peak_gb(spec):
    """Largest recorded actual process peak for this block class, or zero if unknown."""
    p = Path(__file__).resolve().parent / "measured_peaks.json"
    try:
        mt = p.stat().st_mtime
        if _MEASURED_PEAKS[0] != mt:
            _MEASURED_PEAKS[:] = [mt, json.loads(p.read_text()).get("blocks", {})]
        m = _MEASURED_PEAKS[1].get(measured_block(spec.get("name", "")))
        peak = float(m["peak_gb"]) if m else 0
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return 0
    return peak if math.isfinite(peak) and peak > 0 else 0


def sized_ram(spec, ram):
    peak = measured_peak_gb(spec)
    if spec.get("measured_ram", True) is False or peak <= 0 or not isinstance(ram, (int, float)) or ram < 2 * peak:
        return ram
    return math.ceil(max(1.25 * peak, peak + 4))


def stage_list(spec):
    st = spec["stages"]
    out = []
    for b in st.get("bench", []):
        t, r = STAGE_DEFAULTS["bench"]
        out.append(dict(key=bench_key(b["name"]), kind="bench", cmd=b["cmd"],
                        expect=b["expect"], ok=b.get("ok"), fail_regex=b.get("fail_regex"), pass_regex=b.get("pass_regex"),
                        min_count_regex=b.get("min_count_regex"), timeout_s=b.get("timeout_s"),
                        threads=b.get("threads", t), ram=b.get("peak_ram_gb", r)))
    cal = st.get("calibrate") or {}
    # OWNER 2026-10-08: a recipe that references IO in-run to its own propagated clock (io_ref_skew.sdc) needs no
    # calibrate at all
    in_run_ref = "io_ref_skew" in str((st.get("route") or {}).get("cmd", ""))
    if cal.get("enabled", True) and cal.get("cmd") and not in_run_ref:
        base = cal["base"]
        tail = (f"\nB=$(ls -d {base} 2>/dev/null | tail -1); [ -n \"$B\" ] || {{ echo 'calibrate: no ORFS base {base}'; "
                f"bash {{CL}}/cal_classify.sh '{base}'; exit 3; }}"
                f"\n[ -f \"$B/4_1_cts.odb\" ] || {{ echo \"calibrate: no 4_1_cts.odb under $B\"; bash {{CL}}/cal_classify.sh '{base}'; exit 4; }}"
                f"\npython3 {{CL}}/ck_insertion.py --base \"$B\" --clock {cal.get('clock', 'ck')} --output {{CL}}/calib.json"
                f" --route-corner \"${{OT_CAL_ROUTE_CORNER:-}}\""
                f" > {{CL}}/calib.env || exit 4\ncat {{CL}}/calib.env\nset -a; . {{CL}}/calib.env; set +a")
        if cal.get("sdc_cmd"):
            tail += "\n" + cal["sdc_cmd"]
        out.append(dict(key="calibrate", kind="calibrate", cmd=cal["cmd"] + tail, ok=cal.get("ok"), sdc_cmd=cal.get("sdc_cmd"),
                        threads=cal.get("threads", spec.get("threads", 16)), ram=sized_ram(spec, cal.get("peak_ram_gb", spec.get("peak_ram_gb", 32))),
                        logs=cal.get("logs", []), out_dir=cal.get("out_dir"), requires_artifacts=cal.get("requires_artifacts", False)))
    for k in ("route", "signoff"):
        if st.get(k, {}).get("cmd"):
            t, r = STAGE_DEFAULTS[k] or (spec.get("threads", 16), spec.get("peak_ram_gb", 32))
            r = st[k].get("peak_ram_gb", r)
            out.append(dict(key=k, kind=k, cmd=st[k]["cmd"], ok=st[k].get("ok"),
                            threads=st[k].get("threads", t), ram=sized_ram(spec, r) if k == "route" else r,
                            logs=st[k].get("logs", []), out_dir=st[k].get("out_dir")))
    out.append(dict(key="verdict", kind="verdict"))
    for k in ("collect", "export"):
        if st.get(k, {}).get("cmd"):
            t, r = STAGE_DEFAULTS[k]
            out.append(dict(key=k, kind=k, cmd=st[k]["cmd"], ok=st[k].get("ok"),
                            threads=st[k].get("threads", t), ram=st[k].get("peak_ram_gb", r), logs=st[k].get("logs", [])))
    out.append(dict(key="commit", kind="commit"))
    for x in out:
        if x.get("ram"):
            x["declared_ram"] = x["ram"]
            x["ram"] = learned_ram(spec.get("block"), x["key"], x["ram"])
    return out


def load_sources():
    """(origin, spec) for every job file the loop can see."""
    found = []
    for p in sorted(glob.glob(str(DROP / "*.json"))) + sorted(glob.glob(str(HERE / "jobs" / "*.json"))):
        if p.endswith(".example.json"):
            continue
        try:
            found.append((p, json.loads(Path(p).read_text())))
        except Exception as ex:  # noqa: BLE001
            found.append((p, {"_parse_error": str(ex)}))
    r = sh(["git", "-C", str(REPO), "ls-tree", "--name-only", "origin/main", "tools/closure_loop/jobs/"], timeout=60)
    for p in r.stdout.split():
        if not p.endswith(".json") or p.endswith(".example.json"):
            continue
        s = sh(["git", "-C", str(REPO), "show", f"origin/main:{p}"], timeout=60)
        try:
            found.append((f"origin/main:{p}", json.loads(s.stdout)))
        except Exception as ex:  # noqa: BLE001
            found.append((f"origin/main:{p}", {"_parse_error": str(ex)}))
    return found


# ------------------------------------------------------------------------------------------------ job state
def jpath(name):
    return STATE / "jobs" / f"{name}.json"


# Hold this across read/transition/remote launch/save, not just os.replace.  A cancellation
# must see the stage actually launched by an in-flight worker, including a host move.
_JOB_LOCKS = threading.local()


@contextmanager
def job_lock(name):
    if not NAME_RE.fullmatch(name):
        raise ValueError(f"invalid job name: {name}")
    held = getattr(_JOB_LOCKS, "held", None)
    if held is None:
        held = _JOB_LOCKS.held = set()
    if name in held:
        yield
        return
    directory = STATE / "job_locks"
    directory.mkdir(parents=True, exist_ok=True)
    with open(directory / f"{name}.lock", "a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        held.add(name)
        try:
            yield
        finally:
            held.remove(name)


def locked_job_command(fn):
    @wraps(fn)
    def command(a):
        with job_lock(a.name):
            return fn(a)
    return command


class JobState(dict):
    """A job dict that remembers the file version it was read from (raw text + mtime_ns; never serialised).

    STALE-SAVE 2026-10-09 (flow-fix-0410): a worker that loaded a job, ran a long step (bench relaunch, verdict) and
    then saved it overwrote a hand edit made meanwhile: pi-ta15prod hm10/hm25 went back to a ~45-min-old snapshot
    twice (03:00:51 and earlier; drive-0212.log).  Hand edits do not take the job flock, so the lock alone cannot
    prevent it.  save_job now does read-modify-write against the version this dict was read from."""
    __slots__ = ("cl_mtime", "cl_raw")


def _stamp(j, mtime, raw):
    if not isinstance(j, JobState):
        return j
    j.cl_mtime, j.cl_raw = mtime, raw
    return j


def _read_state(p):
    """(mtime_ns, raw) with the stat taken BEFORE the read: a change racing the read looks newer, never older."""
    st = p.stat()
    return st.st_mtime_ns, p.read_text()


def load_job(name):
    mtime, raw = _read_state(jpath(name))
    return _stamp(JobState(json.loads(raw)), mtime, raw)


STALE_SAVE_LOG = "stale_save.log"


def _stale_log(name, line):
    try:
        with open(STATE / STALE_SAVE_LOG, "a") as f:
            f.write(f"{now_iso()} {name} {line}\n")
    except OSError:
        pass
    log(f"STALE-SAVE {name}: {line}")


def _merge_newer(j, current, cur_mtime):
    """The file changed since j was read.  Returns the dict to write, or None to refuse (j then becomes the file).

    Three-way merge on top-level keys against the version j was read from: the keys this writer changed are applied
    over the newer file when the external writer changed none of them; any overlap (or no known base) refuses."""
    base = None
    raw = getattr(j, "cl_raw", None)
    if raw is not None:
        try:
            base = json.loads(raw)
        except ValueError:
            base = None
    ignore = {"updated"}
    if base is None:
        _stale_log(j["name"], f"REFUSED: file changed (mtime {cur_mtime}) and this copy has no base version; kept the file")
        return None
    mine = {k for k in set(base) | set(j) if k not in ignore and base.get(k) != j.get(k)}
    theirs = {k for k in set(base) | set(current) if k not in ignore and base.get(k) != current.get(k)}
    if mine & theirs:
        _stale_log(j["name"], f"REFUSED: newer file (mtime {cur_mtime}) changed {sorted(theirs)}; this writer changed "
                              f"{sorted(mine)} from an older version; kept the file, dropped this save")
        return None
    merged = dict(current)
    for k in mine:
        if k in j:
            merged[k] = j[k]
        else:
            merged.pop(k, None)
    if mine:
        _stale_log(j["name"], f"MERGED: newer file changed {sorted(theirs)}; applied this writer's {sorted(mine)} on top")
    return merged


def save_job(j):
    with job_lock(j["name"]):
        p = jpath(j["name"])
        if p.exists():
            cur_mtime, cur_raw = _read_state(p)
            current = json.loads(cur_raw)
            # Auto-requeue/ingest may have taken their snapshot before cancel.  CANCELLED
            # is absorbing: another attempt needs a new job name, never a stale save.
            if current["status"] == "CANCELLED" and j["status"] != "CANCELLED":
                j.clear()
                j.update(current)
                _stamp(j, cur_mtime, cur_raw)
                return
            # version check on the exact text read (every save rewrites "updated"); mtime_ns alone is not enough:
            # ext4 stamps with the coarse kernel clock, so two writes a few ms apart can share one mtime
            known = getattr(j, "cl_raw", None)
            if isinstance(j, JobState) and known is not None and known != cur_raw:
                merged = _merge_newer(j, current, cur_mtime)
                if merged is None:
                    j.clear()
                    j.update(current)
                    _stamp(j, cur_mtime, cur_raw)
                    return
                j.clear()
                j.update(merged)
        j["updated"] = now_iso()
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".tmp")
        raw = json.dumps(j, indent=1) + "\n"
        tmp.write_text(raw)
        os.replace(tmp, p)
        _stamp(j, p.stat().st_mtime_ns, raw)


_STATE_READ_WARNINGS = set()


def all_jobs():
    """Keep unrelated fleet work running if an externally written state is malformed.

    Leave the offending file untouched for owner recovery; never infer a fresh
    status or resubmit it, since it could have a live producer outside the loop.
    """
    jobs = []
    for p in sorted((STATE / "jobs").glob("*.json")):
        raw = None
        try:
            mtime, raw = _read_state(p)
            j = _stamp(JobState(json.loads(raw)), mtime, raw) if raw.lstrip().startswith("{") else json.loads(raw)
            if not isinstance(j, dict) or not isinstance(j.get("spec"), dict) or \
                    j.get("name") != p.stem or not isinstance(j.get("status"), str) or not j["status"]:
                raise ValueError("job state requires matching name, nonempty status and object spec")
        except (OSError, ValueError) as exc:
            # One warning per distinct bad content; a persistent malformed file
            # must not flood the daemon log on every status query and tick.
            key = (str(p), str(exc), hashlib.sha256((raw or "").encode()).hexdigest())
            if key not in _STATE_READ_WARNINGS:
                _STATE_READ_WARNINGS.add(key)
                log(f"MALFORMED job state {p}: {exc}; preserved, excluded from scheduling")
            continue
        jobs.append(j)
    return jobs



def keys_path():
    return STATE / "route_keys.json"


MAX_ROUTES_PER_KEY = 3     # OWNER 2026-10-07 05:00: small + aggressive + half-rate variants of one design in parallel


def route_keys():
    """{block@commit: [job names]} (older files hold one name per key)"""
    k = json.loads(keys_path().read_text()) if keys_path().exists() else {}
    return {key: (v if isinstance(v, list) else [v]) for key, v in k.items()}


def route_key_full(keys, key, name):
    """None if name may route under key, else the holders that fill it"""
    held = keys.get(key, [])
    return None if name in held or len(held) < MAX_ROUTES_PER_KEY else held


def event(j, msg):
    j.setdefault("events", []).append(f"{now_iso()} {msg}")
    j["events"] = j["events"][-60:]
    log(f"[{j['name']}] {msg}")


def experiment(j, status, register=False):
    if not EXPERIMENT.exists() or os.environ.get("CL_NO_EXPERIMENT"):
        return
    rid = f"closure-loop:{j['name']}"
    host = host_cfg(j["host"])["label"] if j.get("host") else "pending"
    args = ["--name", rid, "--host", host, "--owner", OWNER, "--worktree", f"{j.get('host', '-')}:{j.get('run', '-')}",
            "--purpose", f"{j['spec']['block']} @ {j['spec']['source']['commit'][:9]} bench/route/signoff/merge "
                         f"(job owner {j['spec']['owner']})", "--status", status]
    r = sh([sys.executable, str(EXPERIMENT), "update", *args], timeout=60)
    if r.returncode and "Unknown experiment" in (r.stderr + r.stdout):
        sh([sys.executable, str(EXPERIMENT), "register", *args], timeout=60)


# LINT-AT-SUBMIT (stream lint-at-submit 2026-10-09): pin density (and utilisation where a measurement of the same
# synthesis input exists) estimated from the job's pin plan + outline at intake (submit_lint.py), before a queue slot or
# synthesis is spent.  Fails on one layer but passes with the approved two-layer spread -> the spread (PIN_H 'M4 M6' /
# PIN_V 'M5 M7') is added to the route_master stage commands and recorded in spec.submit_lint (the submitted spec is
# kept in spec_submitted); fails even spread -> REFUSED "SUBMIT_LINT FLOORPLAN_MARGIN: ..." with no compute spent.
# Spec "submit_lint": false (or "fp_lint": false) opts out; fp_lint {"set": {...}} / warn_only apply as in the flow lint.
def util_db_path():
    return STATE / "submit_lint_util.json"


def util_db():
    try:
        return json.loads(util_db_path().read_text())
    except (OSError, ValueError):
        return {}


def util_db_add(key, rec):
    p = util_db_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(str(p) + ".lock", "w") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        db = util_db()
        db[key] = rec
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps(db, indent=1, sort_keys=True) + "\n")
        os.replace(tmp, p)


def submit_check(spec, force=False):
    git_ = submit_lint.Git(REPO)
    commit = str((spec.get("source") or {}).get("commit", ""))
    if commit and git_.blob(commit, "") is None and (spec.get("source") or {}).get("branch"):
        gfetch(spec["source"]["branch"], timeout=300)
    return submit_lint.check(spec, git_, util_db(), force=force)


BENCH_PATH_RE = re.compile(r"(?<![\w./$}{-])((?:[A-Za-z0-9_.-]+/)+[A-Za-z0-9_.-]+\.[A-Za-z0-9]+)\b")
BENCH_SCRIPT_RE = re.compile(r"[\w./-]+\.(?:sh|py|tcl)\b")


def bench_missing_paths(spec, git_=None):
    """drive-0212 2026-10-09: repo files a bench needs that the job's source sync would not carry (it syncs
    source.paths, default tools rtl physical Makefile, + extra_paths).  pi-ta15prod-c7c53c4c2-*: bench.sh read
    tests/rtl/tb_hbm_production_clock_control.sv -> rc=2 'No such file' after a full route.  Scans the bench commands
    and the scripts they call (one level, at the source commit) for literal relative paths that exist at the commit.
    Returns the sorted parent directories to add to source.extra_paths."""
    src = spec.get("source") or {}
    commit = str(src.get("commit", ""))
    benches = ((spec.get("stages") or {}).get("bench") or [])
    if not commit or not (benches or any(isinstance((spec.get("stages") or {}).get(k), dict)
                                         for k in ("calibrate", "route"))):
        return []
    git_ = git_ or submit_lint.Git(REPO)
    synced = [str(x).rstrip("/") for x in list(src.get("paths", DEFAULT_SRC_PATHS)) + list(src.get("extra_paths", []))]

    def covered(path):
        return any(path == x or path.startswith(x + "/") for x in synced)

    texts = []
    for b in benches:
        cmd = b.get("cmd") or ""
        texts.append(cmd)
        for sc in sorted(set(BENCH_SCRIPT_RE.findall(cmd))):
            body = git_.show(commit, sc.lstrip("./"))
            if body:
                texts.append(body)
    # drive-0849 2026-10-09: the calibrate / route commands too (their own text, not the scripts they call) --
    # hbm_smh_{tile,be}_{w,e}g_cg-44351241f: --geom {SRC}/results/uarch/.../geom_362p88.json was not synced, the
    # calibrate died 'No such file' (synth_or_place).  {SRC}/ and $SRC/ prefixes name the snapshot itself.
    for k in ("calibrate", "route"):
        st = (spec.get("stages") or {}).get(k) or {}
        cmd = st.get("cmd") if isinstance(st, dict) else None
        if cmd:
            texts.append(re.sub(r"(\{SRC\}|\$\{?SRC\}?)/", " ", cmd))
    need = set()
    for t in texts:
        for path in BENCH_PATH_RE.findall(t):
            path = path.lstrip("./") if path.startswith("./") else path
            if path.startswith("/") or covered(path) or ".." in path.split("/"):
                continue
            if git_.blob(commit, path) is not None:
                need.add(path.rsplit("/", 1)[0])
    return sorted(need)


def bench_paths_at_submit(j):
    """intake: add the directories the benches need to source.extra_paths (recorded in an event)"""
    try:
        need = bench_missing_paths(j["spec"])
    except Exception as ex:  # noqa: BLE001  (never block intake on the scan itself)
        event(j, f"bench path scan skipped: {type(ex).__name__}: {str(ex)[:200]}")
        return
    if need:
        j.setdefault("spec_submitted", json.loads(json.dumps(j["spec"])))
        src = j["spec"]["source"]
        src["extra_paths"] = list(src.get("extra_paths", [])) + need
        event(j, f"bench needs repo paths outside the source sync: added {need} to source.extra_paths")


def bench_lint_at_submit(j):
    """BENCH-LINT (ROOT 2026-10-16, bench_count.bench_lint): scan the bench commands and the scripts they call at the
    source commit.  git with no fallback (benches run in a non-git export) / an unmatched declared witness REFUSE the
    job before any compute (STATE/bench_lint.json {"mode": "warn"} demotes to an event); warnings are one event."""
    spec = j["spec"]
    commit = str((spec.get("source") or {}).get("commit", ""))
    try:
        git_ = submit_lint.Git(REPO)
        errs, warns = bench_count.bench_lint((spec.get("stages") or {}).get("bench") or [],
                                             (lambda p: git_.show(commit, p)) if commit else None)
    except Exception as ex:  # noqa: BLE001  (never block intake on the scan itself)
        event(j, f"bench lint skipped: {type(ex).__name__}: {str(ex)[:200]}")
        return
    j.setdefault("submit_checks", {})["bench_lint"] = {"errors": errs, "warnings": warns[:20]}
    if warns:
        event(j, f"bench lint WARN ({len(warns)}): " + " | ".join(warns[:4])[:900])
    if not errs:
        return
    if _state_mode("bench_lint.json", "refuse") != "refuse":
        event(j, "bench lint ERROR (mode warn): " + " | ".join(errs)[:1200])
        return
    j["status"] = "REFUSED"
    j["reason"] = ("SUBMIT_LINT BENCH_LINT: " + " | ".join(errs))[:1500]
    event(j, j["reason"])
    ledger(j, f"REFUSED at submit (no compute spent): {j['reason'][:400]}")


def lint_at_submit(j):
    """run the submit lint on a freshly ingested QUEUED job: may add the pin spread or REFUSE it"""
    try:
        res = submit_check(j["spec"])
    except Exception as ex:  # noqa: BLE001  (never block intake on the estimate itself)
        event(j, f"submit lint skipped: {type(ex).__name__}: {str(ex)[:200]}")
        return
    v = res["verdict"]
    if res.get("rtl_boundary"):
        j["rtl_boundary_verdict"] = res["rtl_boundary"].get("verdict")    # LOOP-AUTO class c reads it
    if v == "SKIP":
        return
    if v == "PASS":
        event(j, f"submit lint PASS (estimate {res.get('est')} b/um, limit {res.get('limit')}"
                 + (f", util {res['util_est']['util']:.1%}" if res.get("util_est") else "") + ")"
                 + (f"; {res['rtl_boundary']['verdict']} {res['rtl_boundary']['message'][:400]}" if res.get("rtl_boundary") else ""))
    elif v == "FIX":
        j.setdefault("spec_submitted", j["spec"])
        j["spec"] = submit_lint.apply_fix(j["spec"], res, now_iso())
        event(j, f"submit lint FIX {res['fix']}: {res['message'][:500]}; settings added to the route_master stage "
                 f"commands (spec.submit_lint)")
        ledger(j, f"SUBMIT_LINT {res['fix']} applied: {res['message'][:300]}")
    elif v == "REFUSE":
        j["status"] = "REFUSED"
        kind = "RTL_BOUNDARY" if (res.get("rtl_boundary") or {}).get("verdict") == "REFUSE" else (
            "PIN_TRACK" if (res.get("pin_track") or {}).get("verdict") == "REFUSE" else "FLOORPLAN_MARGIN")
        j["reason"] = f"SUBMIT_LINT {kind}: {res['message']}"[:1500]
        j["submit_lint"] = res
        event(j, j["reason"])
        ledger(j, f"REFUSED at submit (no compute spent): {j['reason'][:400]}")


# HIER-LINT + MACRO-GRID (owner 2026-10-11, TOP-DOWN HIERARCHY CONTRACT; tools/hier_contract/):
#  * hier lint: every hard-child view (LEF + libs) a parent job names must pass tools/hier_contract/child_lint.py
#    (bloat / full-length PG stripes / strap layer clear / TT-FF-SS libs / face-pin access / clock insertion).  Mode
#    from STATE/hier_lint.json {"mode": "warn"|"refuse"} (default warn: event + daemon log + j["submit_checks"]["hier_lint"],
#    which the verdict carries), spec "hier_lint": false | {"mode", "skip"} per job; main flips it without a restart.
#  * macro grid: macro placement scripts are executed against a mock OpenDB and every placed macro's signal pins must
#    sit on the asap7 tracks (DRT-0419 -> DRT-0255: hcoll-port g4, hbm_sfu_lane r4mpa/b).  REFUSE by default
#    (STATE/macro_grid_lint.json {"mode": "warn"|"refuse"}; spec "macro_grid_lint": false opts out).
def _state_mode(fname, default):
    try:
        return str(json.loads((STATE / fname).read_text()).get("mode", default))
    except (OSError, ValueError, AttributeError):
        return default


def hier_lint_at_submit(j):
    """run the hierarchy-contract child lint and the macro-grid lint on a freshly ingested QUEUED job"""
    try:
        sys.path.insert(0, str(HERE.parent / "hier_contract"))
        import hier_submit  # noqa: E402
        import macro_grid_lint  # noqa: E402
    except Exception as ex:  # noqa: BLE001  (never block intake on the hook's own failure)
        event(j, f"hier lint skipped: {type(ex).__name__}: {str(ex)[:200]}")
        return
    g = hier_submit.Git(REPO)
    for key, fn, mode in (("macro_grid", macro_grid_lint.check, _state_mode("macro_grid_lint.json", "refuse")),
                          ("hier_lint", hier_submit.check, _state_mode("hier_lint.json", "warn"))):
        if j["status"] != "QUEUED" or mode == "off":
            continue
        try:
            res = fn(j["spec"], g) if key == "macro_grid" else fn(j["spec"], g, mode)
        except Exception as ex:  # noqa: BLE001
            event(j, f"{key} lint skipped: {type(ex).__name__}: {str(ex)[:200]}")
            continue
        v = res.get("verdict")
        if v == "SKIP":
            continue
        if v == "REFUSE" and key == "macro_grid" and mode != "refuse":
            v = "WARN"
        j.setdefault("submit_checks", {})[key] = {"verdict": v, "mode": mode, "message": res.get("message", "")[:1500]}
        if v == "REFUSE":
            j["status"] = "REFUSED"
            j["reason"] = f"SUBMIT_LINT {'MACRO_GRID' if key == 'macro_grid' else 'HIER_LINT'}: {res['message']}"[:1500]
            event(j, j["reason"])
            ledger(j, f"REFUSED at submit (no compute spent): {j['reason'][:400]}")
        elif v == "WARN":
            event(j, f"{key.upper()} WARN ({mode}): {res['message'][:1200]}")
            log(f"[{j['name']}] {key} WARN: {res['message'][:300]}")
        else:
            event(j, f"{key} PASS: {res.get('message', '')[:300]}")


# REF-TILE GATE (owner 2026-10-11, agent ref-flow-1011; tools/ref_tile/pre_route_gate.py submit_check): the LOCAL part of
# the pre-route gate at intake, on the job's source commit.  A spec with "ref_tile": true (generated by
# tools/ref_tile/ref_tile.py) gets the full kit check (floorplan / layer contract / pin plan vs RTL ports / RTL lint /
# child_lint on hard children / every referenced file inside the synced source paths); every other job gets the
# source-sync check only (the hbm-no3 "No rule to make target /src/physical/redesign_ds/..." class).  Modes from
# STATE/ref_gate.json {"mode": "refuse"|"warn"|"off" (ref_tile jobs, default refuse), "other": ... (default warn)};
# spec "ref_gate": false opts out.  Never blocks intake on the gate's own error (verdict SKIP).
def known_clock_sinks(block_jobs):
    """sinks on the largest clock root of the block's LATEST synthesized design, from the in-flow textbook lint lines the
    loop keeps on each job (None: no job of the block has lint data)."""
    best = None
    for x in block_jobs:
        lines = (x.get("textbook_lint") or {}).get("lines") or []
        if not lines:
            continue
        n = 0
        for l in lines:
            m = re.search(r"clock_roots max_root_sinks=(\d+)", l)
            if m:
                n = max(n, int(m.group(1)))
                continue
            m = re.search(r"clock_domain: clock root .*?: ([\d,]+) flops > .*?(?:, (\d+) macro clock pins)?[;)]", l)
            if m:
                n = max(n, int(m.group(1).replace(",", "")) + int(m.group(2) or 0))
        t = _job_time(x)
        if best is None or t > best[0]:
            best = (t, n)
    return (best[1] or None) if best else None      # lint lines without a clock count (older lint, small root): unknown


def _job_time(j):
    return str(j.get("finished_at") or j.get("updated") or j.get("created") or "")


# STRUCTURE-REPEAT LIMIT (owner 2026-10-13, el1013-rule-enforcement; the Qwen die tile was routed four times as one flat
# block).  An element (spec "block") with >= STRUCTURE_REPEAT_MAX terminal failed routes since its last CLOSED --
# NEEDS_RTL, EARLY_FAIL_*, or a NEEDS_HUMAN route crash -- takes a new submission only when the spec says what changed
# in the structure: "structural_change": "<one sentence>".  Hold-overlay re-runs (name suffix -hs) are exempt.  Mode
# from STATE/ref_gate.json "structure_repeat": "refuse" (default) | "warn" | "off".
STRUCTURE_REPEAT_MAX = 2
HOLD_RERUN_RE = re.compile(r"-hs(-[a-z0-9]{1,4})?$")


def _only_serial_bench_failed(j):
    """Require retained launch evidence that no physical stage was attempted.

    Missing/truncated history, retries, parallel tracks and mixed physical/bench
    failures remain counted. A bench failure can abort a route already in flight.
    """
    spec = j.get("spec") or {}
    if (spec.get("bench_first") is not True or j.get("bench_par") is not False
            or j.get("attempt") != 1 or j.get("retries_used") != 0):
        return False
    events = j.get("events")
    if (not isinstance(events, list) or not events
            or " ingested from " not in str(events[0])):
        return False  # event() retains only the last 60: absence is not evidence
    if any(j.get(k) for k in ("btrack", "ctrack", "crashes", "metrics", "eco", "eco_history")):
        return False
    idx = j.get("stage_idx")
    benches = (spec.get("stages") or {}).get("bench")
    if not isinstance(benches, list) or type(idx) is not int or not 0 <= idx < len(benches):
        return False
    key = bench_key(benches[idx].get("name", ""))
    receipt = (j.get("benches") or {}).get(key) or {}
    if (j.get("stage_key") != key or j.get("stage_tag") != f"{key}.a1"
            or receipt.get("ok") is not False or receipt.get("track") is not None
            or "rc" not in receipt
            or not _bench_reason_is(j.get("reason"), key, receipt)):
        return False
    launches = [str(e).split(" launched ", 1)[1] for e in events if " launched " in str(e)]
    if not launches or not any(e.startswith(f"{key} (attempt 1) on ") for e in launches):
        return False
    allowed = {bench_key(b.get("name", "")) for b in benches[:idx + 1]}
    return (all(e.split(" ", 1)[0] in allowed and " (attempt 1) on " in e for e in launches)
            and not any(re.search(r"\b(?:route|calibrate|signoff|eco)[.-]a?\d|launched (?:route|calibrate|signoff)\b",
                                  str(e)) for e in events))



def _bench_reason_is(reason, key, receipt):
    """The bench verdict reason, with or without the bench_why() cause suffix."""
    base = f"{key} expected {str(receipt.get('expect')).upper()} but rc={receipt['rc']}"
    reason = str(reason or "")
    return reason == base or reason.startswith(base + " (")


def _bench_cancelled_physical_track(j):
    """Only a witnessed bench-caused cancellation, with no physical failure record.

    This does not erase route attempts or release route-key accounting. In-flight
    work stopped by a wrong bench verdict is distinct from a failed physical run.
    """
    if (j.get("bench_par") is not True or j.get("attempt") != 1
            or j.get("retries_used") != 0 or j.get("stage_key") != "route"
            or j.get("stage_tag") != "route.a1" or j.get("textbook_seen") != {}):
        return False
    if any(j.get(k) for k in ("metrics", "early_fail", "crashes", "eco", "eco_history", "ctrack")):
        return False
    events = j.get("events")
    if (not isinstance(events, list) or not events
            or " ingested from " not in str(events[0])):
        return False
    why = str(j.get("reason") or "")
    failed = []
    for key, receipt in (j.get("benches") or {}).items():
        if (receipt.get("ok") is False and receipt.get("track") == "parallel" and "rc" in receipt
                and _bench_reason_is(why, key, receipt)):
            failed.append(key)
    if len(failed) != 1:
        return False
    key = failed[0]
    entry = (j.get("btrack") or {}).get(key) or {}
    declared = {bench_key(b.get("name", "")) for b in (j.get("spec", {}).get("stages", {}).get("bench") or [])}
    if key not in declared or entry.get("state") != "done" or entry.get("tag") != f"{key}.a1b1":
        return False
    # Full retained history must show launch -> successful orchestrator stop ->
    # this bench verdict, without any failed/completed physical-track event.
    launch = [i for i, e in enumerate(events) if " launched route (attempt 1) on " in str(e)]
    stop = [i for i, e in enumerate(events) if str(e).endswith(" bench failed: stopped route (route.a1)")]
    terminal = [i for i, e in enumerate(events) if str(e).endswith(f" NEEDS_RTL: {why}")]
    if len(launch) != 1 or len(stop) != 1 or len(terminal) != 1 or not launch[0] < stop[0] < terminal[0]:
        return False
    bad = re.compile(r"EARLY_FAIL|route crashed|route failed|route done|route rc=|could not stop|HOLD-STOP|"
                     r"launched (?:calibrate|signoff)|(?:route|calibrate) \(attempt [2-9]")
    return not any(bad.search(str(e)) for e in events)


def terminal_route_failure(j):
    st, why = j.get("status"), str(j.get("reason") or "")
    if st == "NEEDS_RTL":
        return not (_only_serial_bench_failed(j) or _bench_cancelled_physical_track(j))
    if st in EARLY_FAIL:
        return True
    return st == "NEEDS_HUMAN" and why.startswith("route crashed") and "LOST:" not in why[:80]


def failed_routes_since_closed(block, jobs, exclude=None):
    mine = [x for x in jobs if x["spec"].get("block") == block and x["name"] != exclude]
    last = max((str(x.get("finished_at") or _closed_at(x)) for x in mine if x["status"] == "CLOSED"), default="")
    return sorted(x["name"] for x in mine if terminal_route_failure(x) and _job_time(x)[:16] > last[:16])


NEAR_MISS_EXEMPT = "near_miss_finishing"
AR_NM_VARIANTS = 2          # MAX_ROUTES_PER_KEY - 1: the near-miss parent holds one route of its block@commit


def near_miss_variant_of(j):
    """the near-miss parent's name when j is one of the variants the loop itself dropped for it (the parent's record
    auto_react["g"] lists j), else None: a spec cannot claim the exemption by its own fields"""
    spec = j["spec"]
    parent = spec.get("auto_react_parent")
    if spec.get("auto_react_class") not in tuple(f"g{i + 1}" for i in range(AR_NM_VARIANTS)) or not parent:
        return None
    try:
        if not jpath(parent).exists():
            return None
        pj = load_job(parent)
    except Exception:  # noqa: BLE001
        return None
    listed = (pj.get("auto_react") or {}).get("g")
    same = (pj["spec"].get("block") == spec.get("block")
            and str((pj["spec"].get("source") or {}).get("commit"))[:12] == str((spec.get("source") or {}).get("commit"))[:12])
    return parent if same and isinstance(listed, list) and j["name"] in listed[:AR_NM_VARIANTS] else None


def structure_repeat_at_submit(j, jobs=None):
    spec = j["spec"]
    if j["status"] != "QUEUED" or "route" not in (spec.get("stages") or {}) or HOLD_RERUN_RE.search(j["name"]):
        return
    try:
        cfg = json.loads((STATE / "ref_gate.json").read_text())
    except (OSError, ValueError):
        cfg = {}
    mode = str(cfg.get("structure_repeat", "refuse"))
    if mode == "off":
        return
    fails = failed_routes_since_closed(spec.get("block"), jobs if jobs is not None else all_jobs(), j["name"])
    if len(fails) < STRUCTURE_REPEAT_MAX:
        return
    nm = near_miss_variant_of(j)
    if nm:      # NEAR-MISS VARIANT exemption: finishing (PD / HM) of a near miss, not a structure; the loop's own 2 only
        txt = (f"exemption class {NEAR_MISS_EXEMPT}: loop-submitted finishing variant {spec.get('auto_react_class')} "
               f"of near miss {nm} (place density / hold margin only, same structure; at most {AR_NM_VARIANTS} per "
               f"near miss)")
        j["structure_exempt"] = txt
        j.setdefault("submit_checks", {})["structure_repeat"] = {"verdict": "EXEMPT", "class": NEAR_MISS_EXEMPT,
                                                                 "parent": nm, "failed_routes": len(fails)}
        event(j, f"STRUCTURE-REPEAT: {len(fails)} failed routes of {spec.get('block')} since its last CLOSED; {txt}")
        log(f"[{j['name']}] structure-repeat: {txt}")
        return
    sc = spec.get("structural_change")
    if isinstance(sc, str) and len(sc.strip()) >= 12:
        j.setdefault("submit_checks", {})["structure_repeat"] = {"verdict": "PASS", "failed_routes": len(fails),
                                                                 "structural_change": sc.strip()[:400]}
        event(j, f"STRUCTURE-REPEAT: {len(fails)} failed routes of {spec.get('block')} since its last CLOSED; "
                 f"structural_change: {sc.strip()[:300]}")
        log(f"[{j['name']}] structure-repeat: {len(fails)} failed routes; structural_change: {sc.strip()[:200]}")
        return
    msg = (f"{spec.get('block')} has {len(fails)} terminal failed routes since its last CLOSED "
           f"({', '.join(fails[-4:])}): a new route needs a changed structure (fix: add \"structural_change\": "
           f"\"<one sentence: what is structurally different from the failed routes>\" to the spec; a re-route of the "
           f"same structure is not accepted; hold-overlay re-runs (-hs) are exempt)")
    j.setdefault("submit_checks", {})["structure_repeat"] = {"verdict": "REFUSE" if mode == "refuse" else "WARN",
                                                             "mode": mode, "failed_routes": len(fails), "message": msg}
    if mode == "refuse":
        j["status"] = "REFUSED"
        j["reason"] = f"SUBMIT_LINT STRUCTURE_REPEAT: {msg}"[:1500]
        event(j, j["reason"])
        ledger(j, f"REFUSED at submit (no compute spent): {j['reason'][:400]}")
    else:
        event(j, f"STRUCTURE_REPEAT WARN ({mode}): {msg}")
        log(f"[{j['name']}] structure-repeat WARN: {len(fails)} failed routes, no structural_change")


# CLOSED STANDS (owner 2026-10-12 19:00 "M5 cap narrowed"; submit gate 2026-10-13, el1013-rule-enforcement).  128 failed
# jobs in 24 h ran on 81 blocks that had already closed, 74 of them M5 re-routes of closed tiles.  A block (top module +
# parameter set) with a counting CLOSED job whose view is published takes a new ROUTE only with spec "reroute_reason"
# {"kind": die_window | slot_change | param_change | rtl_change | evidence_gap | pin_register, ...}; the gate verifies what it can
# (cut > 0.6 / GRT overflow + source file, kit outline / pin faces, parameter set, RTL blobs against the closed commit,
# the closed job's bench + mutant and routed verdict).  Logic: closed_stands.py; rule text + constants:
# tools/textbook_lint.py.  Loop successors of a job that is not CLOSED are exempt.  Mode from STATE/ref_gate.json
# "closed_stands": "refuse" (default) | "warn" | "off".
TAKEOVER_DIR = Path(os.environ.get("CL_TAKEOVER", str(Path.home() / "claude-takeover-20261007")))


def closed_stands_mode():
    try:
        return str(json.loads((STATE / "ref_gate.json").read_text()).get("closed_stands", "refuse"))
    except (OSError, ValueError):
        return "refuse"


def closed_stands_check(spec, name, jobs=None):
    """closed_stands.check on the loop's history and object store; never raises ({"verdict": "SKIP"} on a gate error)"""
    try:
        import closed_stands
        git_ = submit_lint.Git(REPO)
        commit = str((spec.get("source") or {}).get("commit") or "")
        rv = revoked_closures()

        def exists(path):
            q = Path(path)
            if q.is_absolute():
                return q.exists()
            return ((REPO / path).exists() or (TAKEOVER_DIR / path).exists()
                    or any(git_.blob(c, path) for c in (commit, "origin/main") if c))
        return closed_stands.check(spec, name, jobs if jobs is not None else all_jobs(), git_.show, git_.blob,
                                   closure_counts=lambda x: closure_counts(x, rv), bench_gap=bench_evidence_gap,
                                   exists=exists)
    except Exception as ex:  # noqa: BLE001
        return {"verdict": "SKIP", "message": f"gate error {type(ex).__name__}: {str(ex)[:200]}", "closed": [], "kind": None}


def closed_stands_at_submit(j, jobs=None):
    spec = j["spec"]
    if j["status"] != "QUEUED" or "route" not in (spec.get("stages") or {}):
        return
    mode = closed_stands_mode()
    if mode == "off":
        return
    res = closed_stands_check(j.get("spec_submitted") or spec, j["name"], jobs)
    v, msg = res["verdict"], res.get("message", "")
    if v == "NA":
        return
    if v == "SKIP":
        event(j, f"closed-stands gate skipped: {msg[:300]}")
        return
    if v == "REFUSE" and mode != "refuse":
        v = "WARN"
    j.setdefault("submit_checks", {})["closed_stands"] = {
        "verdict": v, "mode": mode, "kind": res.get("kind"), "closed": res.get("closed", [])[-4:],
        "facts": res.get("facts") or {}, "message": msg[:1500]}
    if v == "REFUSE":
        j["status"] = "REFUSED"
        j["reason"] = f"SUBMIT_LINT CLOSED_STANDS: {msg}"[:1800]
        event(j, j["reason"])
        ledger(j, f"REFUSED at submit (no compute spent): {j['reason'][:400]}")
    elif v == "WARN":
        event(j, f"CLOSED_STANDS WARN ({mode}): {msg[:1200]}")
        log(f"[{j['name']}] closed-stands WARN: {msg[:300]}")
    else:
        event(j, f"CLOSED-STANDS {v}: {msg[:600]}")


def ref_gate_at_submit(j, jobs=None):
    if j["status"] != "QUEUED" or j["spec"].get("ref_gate") is False:
        return
    try:
        cfg = json.loads((STATE / "ref_gate.json").read_text())
    except (OSError, ValueError):
        cfg = {}
    mode = str(cfg.get("mode", "refuse") if j["spec"].get("ref_tile") else cfg.get("other", "warn"))
    if mode == "off":
        return
    try:
        pre_route_gate = ref_gate_modules()
        kw = {}
        if j["spec"].get("ref_tile"):
            # MEASURED CLOCK RULE (owner 2026-10-13; constants + rule text in tools/textbook_lint.py).  ref_gate.json
            # "clock": "refuse" (default) | "warn" | "off".
            blk, c9 = j["spec"].get("block"), str((j["spec"].get("source") or {}).get("commit", ""))[:9]
            mine = [x for x in (jobs if jobs is not None else all_jobs()) if x["spec"].get("block") == blk]
            kw = dict(known_sinks=known_clock_sinks(mine), clock_mode=str(cfg.get("clock", "refuse")),
                      closed_stands=any(x["status"] == "CLOSED" and
                                        str((x["spec"].get("source") or {}).get("commit", ""))[:9] == c9 for x in mine))
        res = pre_route_gate.submit_check(j["spec"], str(REPO), **kw)
    except Exception as ex:  # noqa: BLE001
        event(j, f"ref gate skipped: {type(ex).__name__}: {str(ex)[:200]}")
        return
    if isinstance(res.get("route_overlay_plan"), dict) and j.get("freeze_helper_overlay"):
        j["route_overlay_plan"] = res["route_overlay_plan"]
    if isinstance(res.get("relaxing_rule_allowlist"), dict):
        # RELAXING-RULE ALLOWLIST (ROOT-0040 2026-10-18): the gate stood across relaxing-only rule commits; record it
        j["relaxing_rule_allowlist"] = dict(res["relaxing_rule_allowlist"], at=now_iso())
        event(j, "RELAXING-RULE ALLOWLIST: gate kept across " + ", ".join(
            c[:9] for c in res["relaxing_rule_allowlist"].get("commits") or []) + "; " + "; ".join(
            x.get("text", "") for x in res["relaxing_rule_allowlist"].get("requirements") or [])[:300])
    if isinstance(res.get("clock"), dict):
        j["clock_rule"] = dict(res["clock"], mode=kw.get("clock_mode"))      # textbook_cfg() hands it to the in-flow lint
        event(j, f"CLOCK-RULE at submit: {res['clock'].get('text', '')[:300]}"
                 + (" (CLOSED tile: stands)" if res["clock"].get("closed_stands") else ""))
    v = res.get("verdict")
    if v == "SKIP":
        event(j, f"ref gate: {res.get('message', '')[:300]}")
        return
    if v == "REFUSE" and mode != "refuse":
        v = "WARN"
    j.setdefault("submit_checks", {})["ref_gate"] = {"verdict": v, "mode": mode, "message": res.get("message", "")[:1500]}
    if v == "REFUSE":
        j["status"] = "REFUSED"
        j["reason"] = f"SUBMIT_LINT REF_GATE: {res['message']}"[:1500]
        event(j, j["reason"])
        ledger(j, f"REFUSED at submit (no compute spent): {j['reason'][:400]}")
    elif v == "WARN":
        event(j, f"REF_GATE WARN ({mode}): {res['message'][:1200]}")
        log(f"[{j['name']}] ref gate WARN: {res['message'][:300]}")
    else:
        event(j, f"ref gate PASS: {res.get('message', '')[:200]}")

# BENCH-REQUIRED (owner 2026-10-13, el1013-bench-required): lint-only ref_tile jobs routed for hours, CLOSED on timing and
# were then refused by the guarded auto-merge ("no behavioral positive + negative mutant": s81su_qnt_cb32,
# s81su_swe_gfix, s81hc_ctnl_l0/l1/l2, smn FS r1, HC crooty Y v4) -- validate() let them in on a no_bench_reason.
# ONE definition of the bench evidence, used by the merge guard (auto_merge_guard, on the bench RESULTS) and by the
# submit gate (bench_gate_at_submit, on the bench stages the spec DECLARES), so the two cannot disagree:
#   a positive bench (expect pass) whose key is not a lint (LINT_BENCH_RE) + a negative bench (expect fail).
# Submit: a closure candidate without it is REFUSED before any compute.  Closure candidate = a job whose CLOSED would be
# offered to main: not spec "auto_merge": false / "hold_merge" (those never merge: physical probes).  "ref_tile": true
# jobs REFUSE, every other job WARNs (STATE/ref_gate.json {"bench": ..., "bench_other": ...: refuse|warn|off}).
# A no_bench_reason alone no longer admits a candidate; the only bench-less route is the one the guard itself takes
# (no bench at all + no_bench_reason + an owner auto_merge_external_bench_prefixes name).
# benched_by: a sub-tile with no golden of its own names a COMPOSITION gate from tools/ref_tile/composition_gates.json
# (read from the daemon's main tree, never from the job's branch); the gate's positive bench and mutant are appended to
# the job as <gate>_<name> and run in the job's own source snapshot, i.e. the composition built from the sub-tile's RTL
# at its source commit.  The merge guard then sees real behavioural results (and requires every gate bench to be there).
# Not retroactive: jobs ingested before the gate are untouched, and an auto-react successor of such a job only WARNs.
LINT_BENCH_RE = re.compile(r"(?:bench_)?lint(?:_.*)?", re.I)
COMPOSITION_GATES = HERE.parent / "ref_tile" / "composition_gates.json"


def bench_key(name):
    return "bench_" + re.sub(r"[^A-Za-z0-9_-]", "_", str(name))


def bench_evidence_gap(expects):
    """{bench key: expect} -> None when it holds a behavioural positive and a mutant, else the reason it does not"""
    if not any(x == "pass" for x in expects.values()):
        return "no positive bench"
    if not any(x == "pass" and not LINT_BENCH_RE.fullmatch(k) for k, x in expects.items()):
        return "no behavioral positive bench (lint alone is not exactness)"
    if not any(x == "fail" for x in expects.values()):
        return "no negative bench (mutant evidence required)"
    return None


def spec_bench_expects(spec):
    st = spec.get("stages") if isinstance(spec.get("stages"), dict) else {}
    return {bench_key(b.get("name")): b.get("expect") for b in st.get("bench") or [] if isinstance(b, dict)}


def composition_gates():
    try:
        return json.loads(COMPOSITION_GATES.read_text()).get("gates") or {}
    except (OSError, ValueError):
        return {}


def gate_bench_names(gate):
    return [f"{gate}_{b['name']}" for b in (composition_gates().get(gate) or {}).get("benches") or []]


def expand_benched_by(spec):
    """(spec with the composition gate's benches appended, error | None); the input spec is not modified"""
    gate = spec.get("benched_by")
    if gate is None:
        return spec, None
    gates = composition_gates()
    g = gates.get(gate) if isinstance(gate, str) else None
    if not isinstance(g, dict):
        return spec, (f"benched_by {gate!r} is not a composition gate of tools/ref_tile/composition_gates.json on main "
                      f"(known: {', '.join(sorted(gates)) or 'none'}); add the gate there first")
    gb = [b for b in g.get("benches") or [] if isinstance(b, dict)]
    if bench_evidence_gap({bench_key(f"{gate}_{b.get('name')}"): b.get("expect") for b in gb}):
        return spec, f"composition gate {gate} lacks a behavioural positive bench or a mutant in composition_gates.json"
    out = json.loads(json.dumps(spec))
    st = out.get("stages")
    if not isinstance(st, dict):
        return spec, None
    have = {b.get("name") for b in st.get("bench") or [] if isinstance(b, dict)}
    st["bench"] = list(st.get("bench") or []) + [dict(b, name=f"{gate}_{b['name']}") for b in gb
                                                 if f"{gate}_{b['name']}" not in have]
    extra = [x for x in g.get("extra_paths") or [] if x not in (out.get("source") or {}).get("extra_paths", [])]
    if extra and isinstance(out.get("source"), dict):
        out["source"]["extra_paths"] = list(out["source"].get("extra_paths", [])) + extra
    return out, None


def bench_gate_check(spec, name=None):
    """the submit-side bench rule on a (benched_by-expanded) spec: None, or the reason the merge guard would give"""
    if spec.get("auto_merge") is False or spec.get("hold_merge"):
        return None                                     # not a closure candidate: its CLOSED is never offered to main
    expects = spec_bench_expects(spec)
    if not expects and spec.get("no_bench_reason"):
        try:
            waive = json.loads((STATE / "main_publish_owner.json").read_text()).get("auto_merge_external_bench_prefixes") or []
        except (OSError, ValueError):
            waive = []
        if any(str(name or spec.get("name", "")).startswith(w) for w in waive):
            return None                                 # owner-approved external bench, as in auto_merge_guard
    if not expects:
        return "no loop benches"
    return bench_evidence_gap(expects)


BENCH_GATE_FIX = ("add to stages.bench a behavioural bench (expect pass, bit-exact against a golden) and its mutant "
                  "(expect fail), or name a composition gate with \"benched_by\" (tools/ref_tile/README.md); a job that "
                  "must never merge says so with \"hold_merge\": \"<reason>\"")


def bench_gate_at_submit(j):
    if j["status"] != "QUEUED":
        return
    spec = j["spec"]
    try:
        cfg = json.loads((STATE / "ref_gate.json").read_text())
    except (OSError, ValueError):
        cfg = {}
    mode = str(cfg.get("bench", "refuse") if spec.get("ref_tile") else cfg.get("bench_other", "warn"))
    if mode == "off":
        return
    why = bench_gate_check(spec, j["name"])
    if not why:
        if spec.get("benched_by"):
            event(j, f"bench gate PASS: benched_by {spec['benched_by']} ({', '.join(gate_bench_names(spec['benched_by']))})")
        return
    parent = spec.get("auto_react_parent")
    if mode == "refuse" and parent and jpath(parent).exists():
        try:
            pj = load_job(parent)
            if not (pj.get("submit_checks") or {}).get("bench_gate") or pj.get("bench_gate_grandfathered"):
                j["bench_gate_grandfathered"] = True    # successor of a job ingested before the gate: not retroactive
                mode = "warn"
        except Exception:  # noqa: BLE001
            pass
    msg = f"{why}: the guarded auto-merge would skip this job's CLOSED (fix: {BENCH_GATE_FIX})"
    j.setdefault("submit_checks", {})["bench_gate"] = {"verdict": "REFUSE" if mode == "refuse" else "WARN", "mode": mode,
                                                       "message": msg}
    if mode == "refuse":
        j["status"] = "REFUSED"
        j["reason"] = f"SUBMIT_LINT BENCH_REQUIRED: {msg}"[:1500]
        event(j, j["reason"])
        ledger(j, f"REFUSED at submit (no compute spent): {j['reason'][:400]}")
    else:
        event(j, f"BENCH_REQUIRED WARN ({mode}): {msg}")
        log(f"[{j['name']}] bench gate WARN: {why}")


def ingest():
    try:
        gfetch("main", timeout=300)
    except subprocess.TimeoutExpired:
        pass
    keys = route_keys()
    hist = None
    for origin, spec in load_sources():
        name = spec.get("name") or Path(origin.split(":")[-1]).stem
        policy_path = STATE / 'main_publish_owner.json'
        policy = json.loads(policy_path.read_text()) if policy_path.exists() else {}
        if any(str(name).startswith(prefix) for prefix in policy.get('retired_job_prefixes', [])):
            archive = STATE / 'retired_sources'
            archive.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256(json.dumps(spec, sort_keys=True).encode()).hexdigest()
            retired = archive / (str(name) + '-' + digest[:12] + '.json')
            if not retired.exists():
                retired.write_text(json.dumps(dict(at=now_iso(), origin=origin, spec=spec,
                    reason=policy.get('retired_scope_reason', 'Owner retired scope')), indent=1) + '\n')
            continue
        if spec.get("enabled") is False:
            continue
        p = jpath(name) if NAME_RE.match(str(name)) else None
        if p is not None and p.exists():
            j = load_job(name)
            frozen = {k: v for k, v in j.get("spec_submitted", j["spec"]).items()}
            if json.dumps(frozen, sort_keys=True) != json.dumps(spec, sort_keys=True) and not j.get("spec_change_noted"):
                j["spec_change_noted"] = True
                event(j, f"NOTE spec in {origin} changed after ingest: ignored (frozen at first sight; a new source "
                         f"commit needs a new job name)")
                save_job(j)
            continue
        if "_parse_error" in spec:
            bad = STATE / "invalid" / (re.sub(r"[^A-Za-z0-9._-]", "_", origin) + ".txt")
            if not bad.exists():
                bad.parent.mkdir(parents=True, exist_ok=True)
                bad.write_text(spec["_parse_error"])
                log(f"INVALID job file {origin}: {spec['_parse_error']}")
            continue
        submitted = spec
        spec, host_warns = drop_retired_hosts(spec)
        errs = validate(spec)
        if not errs and spec.get("benched_by") is not None:
            spec, _ = expand_benched_by(spec)
        j = dict(name=name, spec=spec, origin=origin, created=now_iso(), status="QUEUED", stage_idx=0, attempt=1,
                 retries_used=0, benches={}, hosts_tried=[], events=[], freeze_helper_overlay=True)
        if spec is not submitted:
            j["spec_submitted"] = submitted          # the frozen-spec comparison and successors use the file as written
        for w in host_warns:
            event(j, w)
        if errs:
            j["status"] = "INVALID"
            j["reason"] = "; ".join(errs)
            event(j, f"INVALID: {j['reason']}")
            ledger(j, f"INVALID spec ({origin}): {j['reason']}")
        else:
            key = f"{spec['block']}@{spec['source']['commit'][:12]}"
            if route_key_full(keys, key, name):
                j["status"] = "REFUSED"
                j["reason"] = f"{MAX_ROUTES_PER_KEY} routes per source commit: {key} already routed by jobs {keys[key]}"
                event(j, j["reason"])
                ledger(j, f"REFUSED: {j['reason']}")
            else:
                event(j, f"ingested from {origin}")
                if hist is None:
                    hist = all_jobs()                # one read per ingest pass that sees a new job
                structure_repeat_at_submit(j, hist)  # no compute: job history only
                if j["status"] == "QUEUED":
                    closed_stands_at_submit(j, hist)  # history + a few blob ids: a CLOSED tile stands
                if j["status"] == "QUEUED":
                    bench_gate_at_submit(j)          # seconds, before the commit-reading lints
                if j["status"] == "QUEUED":
                    bench_lint_at_submit(j)          # bench commands + called scripts at the commit (seconds)
                if j["status"] == "QUEUED":
                    j.setdefault("submit_checks", {}).setdefault("bench_gate", {"verdict": "PASS"})
                    lint_at_submit(j)
                if j["status"] == "QUEUED":
                    hier_lint_at_submit(j)
                if j["status"] == "QUEUED":
                    ref_gate_at_submit(j, hist)
                if j["status"] == "QUEUED":
                    bench_paths_at_submit(j)
        save_job(j)


# --------------------------------------------------------------------------------------------- host capacity
# ADMIT-PAUSE (drive-resume 2026-10-09): a host's own admission gate (/srv/opentallas-scratch/admit.sh, used inside many
# route recipes) refuses every new job while admit.pause_new.json exists (owner, EPYC2 00:25 memory pressure).  The loop
# did not read it: it kept launching onto EPYC2, the recipe's admit.sh waited forever with 0 CPU and no writes, and
# stuckscan killed the "hung" stage 51 min later (hbm_sfu_lane_rstr x2).  The loop now treats the file as "host paused".
ADMIT_PAUSE = "/srv/opentallas-scratch/admit.pause_new.json"
# STOPPED-WAITERS (drive-resume 2026-10-09): an admission waiter SIGSTOPped by a paused_waiters file (EPYC2 pid 430473,
# state T from 00:26 to 07:00) never resumes on its own; every probe lists stopped (state T) admit.sh / admit_core.py
# processes, logs them once per pid and keeps STATE/stopped_waiters.json current (one row per host).
STOPPED_PROBE = ("ps -eo pid=,stat=,etimes=,args= | awk '$2 ~ /^T/ && /admit(_core)?\\.(sh|py)/ "
                 "{printf \"OT_STOPPED_WAITER %s %s %ss \", $1, $2, $3; for (i = 4; i <= NF && i < 12; i++) printf \"%s \", $i; print \"\"}'")
STOPPED_JSON = STATE / "stopped_waiters.json"
_stopped_seen = set()


def report_stopped_waiters(host, rows):
    """log each stopped admission waiter once (per host/pid) and record the host's current list"""
    for r in rows:
        k = (host, r.split()[0])
        if k not in _stopped_seen:
            _stopped_seen.add(k)
            log(f"STOPPED ADMISSION WAITER on {host}: {r[:240]} (state T: SIGSTOPped, it will never admit; "
                f"resume with kill -CONT or remove it)")
    try:
        cur = json.loads(STOPPED_JSON.read_text()) if STOPPED_JSON.exists() else {}
        cur[host] = dict(at=now_iso(), waiters=rows)
        STOPPED_JSON.write_text(json.dumps(cur, indent=1))
    except Exception:  # noqa: BLE001
        pass


# DIE-OOM GUARD (drive-0849 2026-10-09, coordinator URGENT): the full-die Qwen r22k GRTs were killed by the HOST
# (global) OOM killer as the largest process -- EPYC3 18:54:23 PDT openroad 122.5 GB, EPYC1 21:49:01 PDT openroad
# 123.5 GB (dmesg 'Out of memory: Killed process'), not by stuckscan (its KILL_STAGE / EARLY_FAIL at those minutes hit
# other hosts' or other jobs' own run dirs).  Memory-only admission does not reserve for a die run's growth, so every
# host probe marks die-level containers (names / run mounts below) oom_score_adj -900: the kernel then picks a block
# route instead.  Die containers are also never stopped by a loop kill (DIE_CONTAINER_SKIP in every kill loop).
DIE_CONTAINER_RE = r"^/?(qfd_dietop_|qfd_die_|qfd_gw_|dieev_|de2_|die_|dsrom_s81|s81_l1|s81_grt_|r25gp|hbm_r25gp|qwen_r22k)"
DIE_MOUNT_RE = r"/(die-evidence[^/ ]*|kv-die)/"
DIE_OOM_PROBE = ("(for c in $(docker ps -q 2>/dev/null); do i=$(docker inspect --format '{{.Name}} {{range .Mounts}}{{.Source}} {{end}}' $c 2>/dev/null); "
                 f"echo \"$i\" | grep -qE '{DIE_CONTAINER_RE}|{DIE_MOUNT_RE}' || continue; "
                 "for p in $(docker top $c -eo pid 2>/dev/null | tail -n +2); do [ \"$(cat /proc/$p/oom_score_adj 2>/dev/null)\" = -900 ] || "
                 "echo -900 | sudo -n tee /proc/$p/oom_score_adj; done; done; "
                 # native die processes (synth / STA outside docker) under die-evidence*/ or kv-die/
                 f"for p in $(pgrep -f '{DIE_MOUNT_RE}' 2>/dev/null); do [ \"$(cat /proc/$p/oom_score_adj 2>/dev/null)\" = -900 ] || "
                 "echo -900 | sudo -n tee /proc/$p/oom_score_adj; done) >/dev/null 2>&1; true")
# HOST-EMERGENCY (drive-1010 2026-10-10): EPYC2 (6 GB), EPYC4 (7 GB) and EPYC3 (2 GB, 13:26) hung -- the biggest
# consumers were agent benches OUTSIDE the loop (verilator 75-120 GB at oom_score_adj 0) that MEM-GUARD cannot stop, and
# the kernel OOM killer acted too late (sshd stalls first).  Every host probe now runs this early-OOM step: below
# EMERGENCY_FREE_GB available it SIGKILLs the single largest process (>= 8 GB RSS) whose oom_score_adj is >= 0 (never a
# -900 die process, never sshd / systemd / dockerd / containerd) and logs it to /tmp/ot_emergency_kill.log on the host.
EMERGENCY_FREE_GB = 12
EMERGENCY_PROBE = ("(a=$(awk '/MemAvailable/{print int($2/1048576)}' /proc/meminfo); "
                   f"if [ \"$a\" -lt {EMERGENCY_FREE_GB} ]; then "
                   "v=$(ps -eo pid=,rss=,comm= --sort=-rss | while read p r c; do [ \"$r\" -ge 8388608 ] || break; "
                   "case $c in sshd|systemd|dockerd|containerd|containerd-shim*) continue;; esac; "
                   "[ \"$(cat /proc/$p/oom_score_adj 2>/dev/null)\" -ge 0 ] 2>/dev/null && { echo $p; break; }; done); "
                   "[ -n \"$v\" ] && { echo \"$(date -Is) MemAvailable ${a}G: kill -9 $v $(tr '\\0' ' ' < /proc/$v/cmdline | cut -c1-200)\" "
                   ">> /tmp/ot_emergency_kill.log; kill -9 $v; echo OT_EMERGENCY_KILL $v; }; fi) 2>/dev/null; true")
DIE_CONTAINER_SKIP = (f"docker inspect --format '{{{{{{{{.Name}}}}}}}} {{{{{{{{range .Mounts}}}}}}}}{{{{{{{{.Source}}}}}}}} {{{{{{{{end}}}}}}}}' $c "
                      f"| grep -qE '{DIE_CONTAINER_RE}|{DIE_MOUNT_RE}' && continue; ")
PAUSE_PROBE = f"[ -f {ADMIT_PAUSE} ] && echo OT_ADMIT_PAUSED $(head -c 200 {ADMIT_PAUSE} | tr '\\n' ' '); true"


# FLEET-NEW 2026-10-19: die-level jobs (die STA / GEN / GRT / chain, as ot-run's DIE_RE) avoid "throughput" hosts
DIE_SPEC_RE = re.compile(r"(?i)(die[_-]?(sta|gen\d*|grt\d*|chain|trial|place|bind)|(sta|gen\d*|grt\d*)[_-]die\b)")


class Fleet:
    def __init__(self):
        self.pending = {}      # host -> [(t, threads, ram)]
        self.inflight_launches = {}  # actual stage reservations newer than the measured host snapshot
        self.probe_cache = {}
        self.tool_cache = {}
        self.own_running = {}    # host -> declared threads of this loop's running stages
        self.syncing = {}        # host -> jobs placed there and still syncing their source (SYNC-ROOM)
        self.last_good = {}      # host -> (t, last successful probe): used for PROBE_LAST_GOOD_S when a probe fails
        self.tool_good = {}      # host -> (t, last successful toolchain probe)

    def probe(self, host):
        c = self.probe_cache.get(host)
        if c and time.time() - c[0] < 45:
            return c[1]
        # NO SSH UNDER FLEET_LOCK (drive-0849 2026-10-10, fleet STARVED: 91 waiting, EPYC2 520 GB free / load 40): every
        # launch_ready / cal_track / hold-ECO capacity check ran fleet.fits under FLEET_LOCK, and an expired cache made it
        # probe the host by ssh INSIDE the lock -- 2-3 s per host per 45 s, and up to ~130 s (40 s timeout x 3 + 7 s of
        # retry sleeps) when a probe failed -- so every other job thread queued on the lock (py-spy: 19 threads idle at
        # step/launch_ready, the holder in _probe_once).  Under the lock a probe now answers from the last good probe
        # (<= PROBE_LAST_GOOD_S old); the refresh happens outside the lock (fits(), step()).
        if FLEET_LOCK._is_owned():
            good = self.last_good.get(host)
            if good and time.time() - good[0] < PROBE_LAST_GOOD_S:
                return dict(good[1], stale_s=round(time.time() - good[0])) if time.time() - good[0] >= 45 else good[1]
            if c:
                return c[1]
        measured_at = time.time()
        info = self._probe_once(host)
        for delay in (2, 5):            # a busy / just-expired ssh master is not an unreachable host (20:33)
            if info is not None:
                break
            time.sleep(delay)
            measured_at = time.time()
            info = self._probe_once(host)
        note_host(host, info is not None)
        if info is None:
            good = self.last_good.get(host)
            if good and time.time() - good[0] < PROBE_LAST_GOOD_S:
                info = dict(good[1], stale_s=round(time.time() - good[0]))
        else:
            info = dict(info, admission_measured_at=measured_at)
            self.last_good[host] = (time.time(), info)
        self.probe_cache[host] = (time.time(), info)
        return info

    def _probe_once(self, host):
        cfg = host_cfg(host)
        roots = disk_roots(cfg)
        external = cfg.get("external_jobs", [])
        reservation_probe = ""
        if external:
            probe = """import json, pathlib
jobs = json.loads(__JOBS__)
rows = []
for j in jobs:
    p = pathlib.Path('/proc') / str(j['pid'])
    try:
        cmd = (p / 'cmdline').read_bytes().replace(b'\\0', b' ').decode(errors='replace')
        if j['command_match'] not in cmd:
            continue
        rss = next(int(x.split()[1]) for x in (p / 'status').read_text().splitlines() if x.startswith('VmRSS:')) / 1048576
        rows.append(dict(name=j['name'], pid=j['pid'], rss_gb=rss, peak_ram_gb=j['peak_ram_gb'], remaining_gb=max(0, j['peak_ram_gb']-rss)))
    except (OSError, StopIteration, ValueError):
        continue
print('OT_EXTERNAL_JOBS ' + json.dumps(rows))
""".replace("__JOBS__", repr(json.dumps(external)))
            reservation_probe = "; python3 -c " + shlex.quote(probe)
        dfs = "".join(f"; df -P -BG {shlex.quote(p)} | awk 'NR==2{{gsub(\"G\",\"\",$4);print $4}}'" for p in roots)
        alts = host_bases(cfg)[1:]
        dfs += "".join(f"; mkdir -p {shlex.quote(p)} && df -P -BG {shlex.quote(p)} | awk 'NR==2{{gsub(\"G\",\"\",$4);print $4}}'" for p in alts)
        r = ssh(host, f"""cat /proc/loadavg; awk '/MemAvailable/{{print int($2/1048576)}}' /proc/meminfo
mkdir -p {cfg['base']} && df -P -BG {cfg['base']} | awk 'NR==2{{gsub("G","",$4);print $4}}'{dfs}{reservation_probe}
{PAUSE_PROBE}; {STOPPED_PROBE}; {DIE_OOM_PROBE}; {EMERGENCY_PROBE}""", timeout=40)
        if r.returncode:
            info = None
        else:
            v = r.stdout.split()
            info = dict(load1=float(v[0]), mem_gb=int(v[5]), disk_gb=int(v[6]),
                        roots_gb=dict(zip(roots, (int(x) for x in v[7:7 + len(roots)]))))
            # FLEET-NEW2: free GB per run root; admission's run-root disk = the best root (new dirs go there, run_base)
            info["bases_gb"] = dict(zip(host_bases(cfg), [info["disk_gb"]] + [int(x) for x in v[7 + len(roots):7 + len(roots) + len(alts)]]))
            info["disk_gb"] = max(info["bases_gb"].values())
            external_line = next((x[len("OT_EXTERNAL_JOBS "):] for x in r.stdout.splitlines() if x.startswith("OT_EXTERNAL_JOBS ")), None)
            if external and external_line is None:
                return None  # cannot admit without measuring the declared live reservations
            info["external_jobs"] = json.loads(external_line) if external_line else []
            info["external_remaining_gb"] = sum(x["remaining_gb"] for x in info["external_jobs"])
            paused = next((x[len("OT_ADMIT_PAUSED"):].strip() for x in r.stdout.splitlines() if x.startswith("OT_ADMIT_PAUSED")), None)
            if paused is not None:
                info["admit_paused"] = paused[:200] or "admit.pause_new.json"
            stopped = [x[len("OT_STOPPED_WAITER "):].strip() for x in r.stdout.splitlines() if x.startswith("OT_STOPPED_WAITER ")]
            if stopped:
                info["stopped_waiters"] = stopped
                report_stopped_waiters(host, stopped)
        return info

    def own_pending(self, host, job=None):
        t0 = time.time() - PENDING_WINDOW_S
        self.pending[host] = [p for p in self.pending.get(host, []) if p[0] >= t0]
        # RAM of a launch is held back 3 min (a route reaches its memory over hours).  2026-10-08: a job's own claim
        # (taken when it was chosen/moved) must not count against its own launch -- it made every moved job miss the
        # host it was moved to, move again and re-claim, which held 368 GB of EPYC2 idle while 30 jobs waited
        tr = time.time() - PENDING_RAM_WINDOW_S
        other = [p for p in self.pending[host] if job is None or len(p) < 4 or p[3] != job]
        return sum(p[1] for p in other), sum(p[2] for p in other if p[0] >= tr)

    def fits(self, host, threads, ram, job=None):
        if not FLEET_LOCK._is_owned():
            self.probe(host)                   # refresh (cached 45 s) OUTSIDE the lock
        with FLEET_LOCK:
            return self._fits(host, threads, ram, job)

    def _fits(self, host, threads, ram, job=None):
        cfg = host_cfg(host)
        if threads > cfg["max_job_threads"] or ram > cfg["max_job_ram_gb"]:
            return False, f"job {threads} thr / {ram} GB exceeds {cfg['label']} per-job limit"
        info = self.probe(host)
        if info is None:
            return False, f"{cfg['label']} unreachable"
        if info.get("admit_paused"):
            return False, f"{cfg['label']} admission paused ({ADMIT_PAUSE}: {info['admit_paused']})"
        pt, pr = self.own_pending(host, job)
        # OWNER DECISION (2026-10-07 20:10, supersedes the 19:31 1.1 x nproc cap): MEMORY is the only admission limit on
        # the remote hosts -- CPU oversubscription is allowed (jobs wait on reads / run serial phases).  localhost keeps
        # its own guard below (max_loop_threads, min_free_ram_gb) so it stays responsive.
        # OWNER 2026-10-09: NEVER reserve memory for future growth (no reserve_ram_gb, no external-job remaining-peak
        # reservations) -- admit on measured MemAvailable minus own launches of the last few minutes only.
        # drive-resume 2026-10-09 (coordinator, owner rule): admit iff measured MemAvailable >= the job's own request + a
        # fixed safety of ADMIT_SAFETY_GB (16).  The earlier check subtracted the declared peaks of every launch AND every
        # host claim of the last 3 min (waiting jobs re-claim each tick, so it never expired: "EPYC4 MemAvailable 316-224
        # < 40+57") and added 5 % of host RAM -- both reservations for future growth.  Neither is subtracted any more.
        head = min(ADMIT_SAFETY_GB, cfg.get("min_free_ram_gb", ADMIT_SAFETY_GB))
        if cfg.get("max_loop_threads") is not None:      # localhost: loop jobs in total, so ssh stays responsive
            used = self.own_running.get(host, 0) + pt
            if used + threads > cfg["max_loop_threads"]:
                return False, f"{cfg['label']} loop threads {used}+{threads} > {cfg['max_loop_threads']}"
        if ram <= 2:          # 2026-10-08: collect/export copy files; host-local, so they cannot move -- a 16 GB headroom
            head = min(head, 2)   # left PVE1 jobs stuck at collect for 20 min with 13 GB free
        # Actual launches reserved after this measurement must not spend the same free bytes twice.
        # Waiting/migration claims and historical peaks never enter this ledger. A successful fresh
        # snapshot observes the live host directly and clears older launch charges (no growth reserve).
        measured_at = info.get("admission_measured_at", 0)
        recent = [p for p in self.inflight_launches.get(host, []) if p[3] is None or p[3] >= measured_at]
        self.inflight_launches[host] = recent
        launch_ram = sum(p[1] for p in recent if job is None or p[2] != job)
        if info["mem_gb"] - launch_ram < ram + head:
            return False, f"{cfg['label']} MemAvailable {info['mem_gb']} GB - snapshot launches {launch_ram} GB < {ram}+{head:.0f}"
        # drive-0849 2026-10-09 (coordinator): a light stage (bench / collect / export: ram <= LIGHT_STAGE_RAM_GB) writes a few
        # GB at most; the 200 GB run-root floor held EPYC4's benches + collects for > 1 h at 192-197 GB free while 250 GB
        # of RAM sat idle.  Light stages keep only LIGHT_DISK_FLOOR_GB; routes / calibrates / ECOs keep the full floor.
        dfloor = cfg["min_free_disk_gb"] if ram > LIGHT_STAGE_RAM_GB else min(cfg["min_free_disk_gb"], LIGHT_DISK_FLOOR_GB)
        if info["disk_gb"] < dfloor:
            return False, f"{cfg['label']} run root has {info['disk_gb']} GB free < {dfloor}"
        for path, floor in disk_roots(cfg).items():   # every other root the host's jobs write (docker /, /tmp, ...)
            if ram <= LIGHT_STAGE_RAM_GB:
                floor = min(floor, LIGHT_DISK_FLOOR_GB)
            free = info.get("roots_gb", {}).get(path)
            if free is not None and free < floor:
                return False, f"{cfg['label']} {path} has {free} GB free < {floor}"
        return True, "ok"

    def launched(self, host, threads, ram, job=None, *, actual=False):
        with FLEET_LOCK:
            token = self._launched(host, threads, ram, job, actual=actual)
            if actual:  # this public notification follows launch_stage
                self.launch_complete(host, token)

    def _launched(self, host, threads, ram, job=None, *, actual=False):
        token = time.time()
        if actual:
            self.inflight_launches.setdefault(host, []).append((token, ram, job, None))
        if job is not None:   # one claim per job: a launch or a new host choice replaces its earlier claims
            for hh in self.pending:
                self.pending[hh] = [p for p in self.pending[hh] if len(p) < 4 or p[3] != job]
        self.pending.setdefault(host, []).append((time.time(), threads, ram, job))
        self.probe_cache.pop(host, None)
        return token

    def reserve_launch(self, host, threads, ram, job=None):
        with FLEET_LOCK:
            return self._launched(host, threads, ram, job, actual=True)

    def launch_complete(self, host, token):
        # The pre-launch invalidation can be refreshed while SSH starts a child; refresh again after it.
        with FLEET_LOCK:
            self.inflight_launches[host] = [(*p[:3], time.time()) if p[0] == token else p
                                           for p in self.inflight_launches.get(host, [])]
            self.probe_cache.pop(host, None)

    def sync_room(self, h):
        """SYNC-ROOM (ROOT 2026-10-15): placing a job writes its source snapshot (src/ + bench_src*/, up to ~28 GB before
        the view-store fix) before any stage runs, but the disk floor was judged on the first stage's RAM only: a light
        first stage kept just LIGHT_DISK_FLOOR_GB, and AGIdock took 14 syncs at 60 GB free and hit 0 (17:40 10-15).
        A placement now also needs room for every sync already in flight on the host plus its own."""
        info = self.probe(h)
        if info is None or info.get("disk_gb") is None:
            return True, "ok"
        n = self.syncing.get(h, 0) + 1
        if info["disk_gb"] - SYNC_DISK_GB * n < LIGHT_DISK_FLOOR_GB:
            return False, (f"{host_cfg(h)['label']} run root {info['disk_gb']} GB free - {n} source sync(s) x {SYNC_DISK_GB} GB "
                           f"< {LIGHT_DISK_FLOOR_GB}")
        return True, "ok"

    def choose(self, spec, exclude=()):
        with FLEET_LOCK:
            return self._choose(spec, exclude)

    def toolchain(self, host):
        """ORFS image digests + bench tool versions of a host (cached 1 h)."""
        c = self.tool_cache.get(host)
        if c and time.time() - c[0] < (3600 if c[1] else 15):
            return c[1]
        info = None
        for delay in (0, 5, 15):
            if delay:
                time.sleep(delay)
            try:
                r = ssh(host, TOOLPROBE, timeout=90)
            except subprocess.TimeoutExpired:
                # gaps-design 2026-10-08: an unreachable host (PVE1 'No route to host' 02:1x PT) raised out of tick()
                # and crash-looped the daemon; a timed-out probe is a failed probe (last-good toolchain applies)
                break
            if r.returncode == 0:
                info = dict(l.split("=", 1) for l in r.stdout.splitlines() if "=" in l)
                break
        if info is None:   # a failed probe keeps the last good toolchain (6 h) instead of "no compatible host"
            good = self.tool_good.get(host)
            if good and time.time() - good[0] < TOOL_LAST_GOOD_S:
                info = good[1]
        else:
            self.tool_good[host] = (time.time(), info)
        self.tool_cache[host] = (time.time(), info)
        return info

    def compatible(self, host, spec):
        """host capability table (hosts.json caps) covers every stage's needs, and the ORFS image digest matches the
        reference host's (plus asap7lock when the job names it)"""
        cfg = host_cfg(host)
        # bench_offload (OWNER 2026-10-07: use localhost for ORFS-only route/calibrate): the job's benches run on another
        # host with the bench tools (bench_track -> offload_bench_location), so only the main track's needs count here
        if not job_needs(spec, benches=not cfg.get("bench_offload")) <= set(cfg.get("caps", [])):
            return False
        ref, mine = self.toolchain(TOOL_REF_HOST), self.toolchain(host)
        if not ref or not mine:
            return False
        if not all(mine.get(k) == ref.get(k) for k in job_tools(spec) if k.startswith("img_")):
            return False
        if is_local(host) and bare_image_ids(spec):
            return False     # a docker reference by bare image ID does not exist in the localhost store (see LOCAL_ORFS_REF)
        return True

    def _choose(self, spec, exclude=()):
        threads, ram = spec.get("threads", 16), claim_ram(spec)
        allh = [h["name"] for h in hosts_table()]
        pref = set(spec.get("hosts") or [])
        # the job's hosts list is a PREFERENCE (coordinator 2026-10-06 21:15); caps/toolchain/per-job limits still apply
        if spec.get("host_require"):          # smoke tests / pinned runs: only these hosts
            allh = [h for h in allh if h in spec["host_require"]]
        # a host marked smoke_only (hosts.json) admits only smoke-test jobs (spec "smoke": true) until it is re-enabled
        allh = [h for h in allh if not host_cfg(h).get("smoke_only") or spec.get("smoke")]
        allh = [h for h in allh if not host_down(h)]       # HOST-DOWN: smoke_only-equivalent while it is down
        order = [h for h in allh if h not in exclude and self.compatible(h, spec)]

        def cpu_ratio(h):
            """projected CPU load of h with this job on it, in units of its cores (None: no probe)"""
            info, cfg = self.probe(h), host_cfg(h)
            if info is None:
                return None
            return (info["load1"] + self.own_pending(h)[0] + threads) / host_cores(cfg)

        # OWNER 2026-10-13 17:55 (EPYC1 at load 259 on 128 cores while EPYC4 ran at 39): a job goes to the host with the
        # lowest projected load1 / cores among those that can admit it, so the big hosts fill evenly before either
        # passes 1.0 x cores; a host with fewer than SMALL_HOST_CORES cores (PVE1, localhost) never gets a job of more
        # than SMALL_HOST_THREADS threads while a larger host still has cores.  Memory alone decides ADMISSION (fits).
        ratios = {h: cpu_ratio(h) for h in order}
        big_has_cores = any(r is not None and r <= 1.0 and host_cores(host_cfg(h)) >= SMALL_HOST_CORES
                            and not host_cfg(h).get("spillover_only") for h, r in ratios.items())

        die_job = spec.get("priority") == "die" or bool(DIE_SPEC_RE.search(spec.get("name", "")))

        def score(h):
            """higher = better: lowest projected CPU load first (free RAM only breaks near-ties); spillover-only hosts
            rank after every other host; listed hosts get a small preference.  HOST ROLE (FLEET-NEW 2026-10-19):
            a hosts.json role "throughput" host (ot-epyc7, Zen 3) takes tile gates / routes / benches FIRST while its
            projected load <= 1.0 x cores; a die-level job ranks it after every other (non-spillover) host."""
            info, cfg = self.probe(h), host_cfg(h)
            if info is None or ratios.get(h) is None:
                return -9e9
            pt, pr = self.own_pending(h)
            fr = (info["mem_gb"] - pr - ram) / cfg.get("ram_gb", 1133)
            small = host_cores(cfg) < SMALL_HOST_CORES and threads > SMALL_HOST_THREADS and big_has_cores
            tput = cfg.get("role") == "throughput"
            role = (-3 if die_job else (1 if ratios[h] <= 1.0 else 0)) if tput else 0
            if cfg.get("role") == "smalldisk" and die_job:   # FLEET-NEW2: ot-epyc8 (~820 GB disk) -- no die-chain scratch
                role = -3
            return -ratios[h] + 0.05 * fr + (0.02 if h in pref else 0) - (10 if cfg.get("spillover_only") else 0) \
                - (5 if small else 0) + role
        order.sort(key=score, reverse=True)
        why = []
        for h in order:
            if die_job:     # v10 DISK ADMISSION (FLEET-PLACE 2026-10-19): replaces the max_die_jobs count cap
                dk = (self.probe(h) or {}).get("disk_gb")
                n = (die_jobs_on(h) or 0) if dk is not None and dk < DIE_DISK_RESERVE_BELOW_GB else 0
                if dk is not None and dk - n * DIE_DISK_GB < DIE_DISK_GB:
                    why.append(f"{host_cfg(h)['label']} DISK {dk} GB - {n} die job(s) x {DIE_DISK_GB} GB < {DIE_DISK_GB} GB")
                    continue
            ok, msg = self.fits(h, threads, ram)
            if ok:
                ok, msg = self.sync_room(h)
            if ok:
                self.syncing[h] = self.syncing.get(h, 0) + 1
                return h, None
            why.append(msg)
        return None, "; ".join(why) or "no compatible host (capabilities/image probe unavailable or mismatched)"


SMALL_HOST_CORES, SMALL_HOST_THREADS = 48, 8   # see Fleet._choose
DIE_DISK_GB, DIE_DISK_RESERVE_BELOW_GB = 60, 2000   # v10 FLEET-PLACE: same rule as ~/bin/ot-run drop_low_disk

# DIE CAP (FLEET-NEW2 2026-10-19): hosts.json max_die_jobs bounds the die-level jobs on a host = this daemon's die jobs
# placed there (DIE_SPEC_RE names; only those state files are read) + ot-run die units / die waiters on the host
# (OT_HEAVY_PRIO=die; same count as ~/bin/ot-run HOST_MAX_DIE).  Cached 60 s; None = unknown (the host is skipped).
DIE_PLACED = {"SYNC", "RUNNING", "ECO", "SUMMARY", "ECO_INSTALL", "MIGRATING"}
DIE_UNITS_SH = ("n=0; for u in $(systemctl --user list-units --type=scope --state=active --no-legend --plain 'oth-*' "
                "2>/dev/null | awk '{print $1}'); do cg=$(systemctl --user show -p ControlGroup --value $u); "
                "for p in $(head -3 /sys/fs/cgroup$cg/cgroup.procs 2>/dev/null); do "
                "tr '\\0' '\\n' </proc/$p/environ 2>/dev/null | grep -qx OT_HEAVY_PRIO=die && { n=$((n+1)); break; }; done; "
                "done; for p in $(pgrep -f '^(/bin/)?bash /usr/local/bin/ot-heavy '); do "
                "tr '\\0' '\\n' </proc/$p/environ 2>/dev/null | grep -qx OT_HEAVY_PRIO=die && n=$((n+1)); done; "
                "echo DIEUNITS $n")
_DIE_CACHE = {}


def die_jobs_on(host):
    c = _DIE_CACHE.get(host)
    if c and time.time() - c[0] < 60:
        return c[1]
    n = 0
    try:
        for f in os.listdir(STATE / "jobs"):
            if f.endswith(".json") and DIE_SPEC_RE.search(f[:-5]):
                try:
                    j = json.loads((STATE / "jobs" / f).read_text())
                except (OSError, ValueError):
                    continue
                n += j.get("host") == host and j.get("status") in DIE_PLACED
        r = ssh(host, DIE_UNITS_SH, timeout=40)
        n += int(r.stdout.split("DIEUNITS")[-1].split()[0])
    except (OSError, ValueError, IndexError, subprocess.SubprocessError):
        n = None
    _DIE_CACHE[host] = (time.time(), n)
    return n


def host_cores(cfg):
    return max(1, cfg.get("cores") or cfg.get("cap") or 1)


TOOL_REF_HOST = "ot-epyc4"  # 10-16: EPYC1 being released (owner); 10-12: EPYC3 retired; all hosts share orfs image 16470cea1d34
PROBE_LAST_GOOD_S = 300     # memory/disk/load: a failed probe reuses a good one at most 5 min old
TOOL_LAST_GOOD_S = 6 * 3600  # image digests / tool versions change only on a deliberate host update
# LOCALHOST IMAGE (2026-10-07): the fleet image loaded into localhost's overlay2 docker store has another image ID
# (af971398) than in the fleet's containerd stores (16470cea), so a recipe pinning the BARE ID sha256:16470cea... fails
# there with exit 125 (dsrom_softmax_safe_exprc2_09d4d345e).  The registry-digest reference resolves on every host:
# localhost stages export it as OPENTALLAS_ORFS_IMAGE, and jobs whose recipes hard-code a bare ID stay on the fleet.
LOCAL_ORFS_REF = "openroad/orfs@sha256:16470cea1d346bfa245e402108995a4f04a1e54fe7c7bb7441774d7f6a2ece29"
_BARE_ID_CACHE = {}


def bare_image_ids(spec):
    """bare docker image IDs (sha256:<64 hex> not preceded by name@) in the job's stage commands or the scripts they
    name at the job's commit, except an overridable ${OPENTALLAS_ORFS_IMAGE:-...} default"""
    commit = (spec.get("source") or {}).get("commit", "")
    text = json.dumps(spec.get("stages", {}))
    key = (commit, text)
    if key in _BARE_ID_CACHE:
        return _BARE_ID_CACHE[key]
    blobs = [text]
    for path in sorted(set(re.findall(r"((?:physical|tools)/[\w./-]+\.(?:sh|py|tcl))", text))):
        r = sh(["git", "-C", str(REPO), "show", f"{commit}:{path}"], timeout=60)
        if r.returncode == 0:
            blobs.append(r.stdout)
    found = set()
    for b in blobs:
        b = re.sub(r"OPENTALLAS_ORFS_IMAGE:-sha256:[0-9a-f]{64}", "", b)
        found |= set(re.findall(r"(?<![@\w])sha256:[0-9a-f]{64}", b))
    _BARE_ID_CACHE[key] = sorted(found)
    return _BARE_ID_CACHE[key]
SMALL_JOB_GB = 40
# image identity = its registry digest when it has one: the same image loaded into a different docker store reports a
# different .Id (localhost overlay2 af971398 vs fleet containerd 16470cea, both openroad/orfs@sha256:16470cea)
TOOLPROBE = r"""
echo img_latest=$(docker image inspect openroad/orfs:latest --format '{{if .RepoDigests}}{{index .RepoDigests 0}}{{else}}{{.Id}}{{end}}' 2>/dev/null)
echo img_asap7lock=$(docker image inspect openroad/orfs:asap7lock --format '{{if .RepoDigests}}{{index .RepoDigests 0}}{{else}}{{.Id}}{{end}}' 2>/dev/null)
echo iverilog=$(iverilog -V 2>/dev/null | head -1)
echo verilator=$(verilator --version 2>/dev/null | head -1)
echo yosys=$(yosys -V 2>/dev/null | head -1)
"""


def bench_needs(spec):
    return set().union(*(set(b.get("needs", DEFAULT_NEEDS["bench"])) for b in spec.get("stages", {}).get("bench", [])))


def job_needs(spec, benches=True):
    """union of the stage needs of a job (all its stages run on one host); a stage may set "needs": [...].
    benches=False: the main track only (a bench_offload host runs the benches on another host)"""
    st = spec.get("stages", {})
    need = set()
    for b in st.get("bench", []) if benches else ():
        need |= set(b.get("needs", DEFAULT_NEEDS["bench"]))
    for k in ("calibrate", "route", "signoff", "collect", "export"):
        x = st.get(k) or {}
        if x.get("cmd") and x.get("enabled", True) is not False:
            need |= set(x.get("needs", DEFAULT_NEEDS[k]))
    return need | set(DEFAULT_NEEDS["summary"])


def job_tools(spec):
    t = json.dumps(spec.get("stages", {})) + json.dumps(spec.get("verdict", {}))
    need = {"img_latest"}
    for key, rx in (("img_asap7lock", r"asap7lock"), ("iverilog", r"\b(iverilog|vvp)\b"), ("verilator", r"\bverilator\b"),
                    ("yosys", r"\byosys\b")):
        if re.search(rx, t):
            need.add(key)
    return need


# ------------------------------------------------------------------------------------------------ remote ops
# FLEET-OOM (2026-10-18): the runner also (a) samples the stage's process-group RSS every 15 s -> <tag>.peak_kb (the
# stage's measured peak; stage_peaks.json re-admits repeats of the same block + stage at it, learned_ram()), (b) when
# that RSS passes the stage's declared GB (<tag>.decl) raises the build processes in it (cc1plus / verilator_bin /
# yosys / ld ...) to oom_score_adj 900, so earlyoom takes the over-declared build, not a 9 MiB vvp of another job, and
# (c) after the stage exits writes every earlyoom / kernel OOM kill of one of its pids (sampled into <tag>.pids) or of a
# process whose command line names this run dir into <tag>.oomkill -- the daemon then retries the stage as a FLOW
# failure (crash(), never NEEDS_RTL).  Before, earlyoom SIGTERMed tiny oom_score_adj-500 benches first and the bench
# verdict read the truncated log as an RTL result (34 kills on 10-18, lanes/FLEET-OOM.md).
RUNNER = r"""#!/bin/bash
# closure-loop stage runner: <stage tag>.  pid/start/log/rc (+ peak_kb/pids/oomkill) files next to this script.
st=$1; d=$(cd "$(dirname "$0")" && pwd)
echo $$ > $d/$st.pid; date +%s > $d/$st.start
rm -f $d/$st.oomkill $d/$st.peak_kb $d/$st.pids $d/$st.oomprefer
cd "$(cat $d/SRC_DIR)"
( decl=$(cat $d/$st.decl 2>/dev/null); case "$decl" in ''|*[!0-9]*) decl=0;; esac; pk=0; g=$(ps -o pgid= -p $$ | tr -d ' ')
  while kill -0 $$ 2>/dev/null; do
    snap=$(ps -eo pid=,pgid=,rss=,comm= 2>/dev/null | awk -v g=$g '$2==g')
    s=$(echo "$snap" | awk '{s+=$3} END{print s+0}')
    [ "$s" -gt "$pk" ] && { pk=$s; echo $pk > $d/$st.peak_kb; }
    echo "$snap" | awk '{print $1}' >> $d/$st.pids; sort -u -o $d/$st.pids $d/$st.pids 2>/dev/null
    if [ "$decl" -gt 0 ] && [ "$s" -gt $((decl * 1048576)) ]; then
      for p in $(echo "$snap" | awk '$4 ~ /^(cc1plus|cc1|verilator_bin|verilator_bin_dbg|yosys|yosys-abc|ld|g\+\+|c\+\+|clang\+\+|openroad)$/ {print $1}'); do
        [ "$(cat /proc/$p/oom_score_adj 2>/dev/null)" = 900 ] && continue
        echo 900 > /proc/$p/oom_score_adj 2>/dev/null && echo "$(date -Is) stage RSS $((s / 1048576)) GB > declared $decl GB: pid $p oom_score_adj 900" >> $d/$st.oomprefer
      done
    fi
    sleep 15
  done ) > /dev/null 2>&1 &
bash $d/$st.sh > $d/$st.log 2>&1
rc=$?
t0=$(cat $d/$st.start); run=$(dirname "$d")
{ sudo -n journalctl -u earlyoom --since @$t0 --no-pager -q 2>/dev/null | grep -E 'sending SIG(TERM|KILL) to process'
  sudo -n journalctl -k --since @$t0 --no-pager -q 2>/dev/null | grep -E 'Killed process [0-9]+'; } | while IFS= read -r ln; do
  p=$(echo "$ln" | sed -nE 's/.*(to process|Killed process) ([0-9]+).*/\2/p')
  { [ -n "$p" ] && grep -qx "$p" $d/$st.pids 2>/dev/null; } || case "$ln" in *"$run/"*) ;; *) continue;; esac
  echo "$ln"
done > $d/$st.oomkill.tmp 2>/dev/null
[ -s $d/$st.oomkill.tmp ] && mv $d/$st.oomkill.tmp $d/$st.oomkill || rm -f $d/$st.oomkill.tmp
echo $rc > $d/$st.rc.tmp && mv $d/$st.rc.tmp $d/$st.rc
"""


def label(name):
    """Route label of a job: run_abi3_physical --nickname-tag (and ORFS design nicknames) accept [A-Za-z0-9_]+ only, so
    {NAME} and {LABEL} in commands both expand to the job name with every other character as '_' ({RAW_NAME} = raw)."""
    return re.sub(r"[^A-Za-z0-9_]", "_", name)


TT_OVERLAY_REL = "python3 tools/closure_loop/tt_overlay.py "
TT_OVERLAY_FLEET = ("/srv/opentallas-scratch/claude/ttbatch/26f14af32/tools/closure_loop/tt_overlay.py",
                    "/home/ubuntu/closure-loop-local/ttbatch/26f14af32/tools/closure_loop/tt_overlay.py")


def tt_overlay_fallback(cmd):
    """2026-10-08: specs that call the snapshot's own tools/closure_loop/tt_overlay.py on a commit predating it (26f14af32;
    qfd_io_emb_tap-4b111850att, qfd_sp_*-e0370c82ctt: 'can't open file ... tt_overlay.py') run the fleet's tt-batch
    overlay copy (kept at main on every host) instead.
    FLEET-FIRST 2026-10-15 23:2x: the fleet copy (kept at main) wins over the snapshot's own -- a snapshot's buggy
    overlay (65529c027..3c31fb285 deleted GRT183_HOOK from run_abi3_physical.py) cannot be fixed by its pinned commit.
    PATHPICK 2026-10-18 (ROOT-2130): the fleet copy is REQUIRED (ot_pick + the stage precheck), never a silent fallback."""
    if TT_OVERLAY_REL not in cmd:
        return cmd
    return cmd.replace(TT_OVERLAY_REL, f"python3 \"$(ot_pick {' '.join(TT_OVERLAY_FLEET)})\" ")


# PATHPICK 2026-10-18 (ROOT-2130, QK-LAND600C): stage scripts run under `set -o pipefail`.  The fleet-path picks the
# daemon and 2,000+ specs use -- `X=$(ls -d A B 2>/dev/null | head -1) && ...` and `$(ls -d A B | head -1 | grep . ||
# echo rel)` -- break on a host that has only ONE of the candidates (ot-epyc5: no /home/ubuntu/closure-loop-local): ls
# exits 2, so the assignment fails and the `&&`-chained TT overlay + OT_CTS_FIX_HOOKS are skipped while the route still
# runs after `;` (or the `|| echo` also prints and the picked path is two lines).  qfwd_landh0_600_en, s81lk_kp4_dec-p1,
# hcoll_ring_ag_ctln_1018-r5c, qkd_hr_core_guard-r4, qkd_kvs_emb-e1, hv16_dbk_cpl-q1 routed without the overlay.  Every
# literal multi-path pick is rewritten to ot_pick (test -e each path in order; rc 0 when one exists), and the stage
# script first checks that each pick resolves: none -> OT_FLOW_MISSING, exit 97, a FLOW failure (retried on another
# host via RESOURCE_RE, then NEEDS_HUMAN) -- never a route without its overlay / hooks.
OT_PICK_FN = ('ot_pick() { local p; for p in "$@"; do [ -e "$p" ] && { printf \'%s\\n\' "$p"; return 0; }; done; '
              'echo "OT_FLOW_MISSING: none of $* exists on $(hostname)" >&2; return 1; }\n')
PATH_PICK_RE = re.compile(r"\$\(ls -d((?:\s+/[^\s()$|;&*?\[{}'\"]+)+)\s*(?:2>/dev/null\s*)?\|\s*head -1"
                          r"(?:\s*\|\s*grep \.\s*\|\|\s*echo\s+([^\s()$|;&]+))?\s*\)")
OT_FLOW_MISSING_RC = 97


def path_picks_safe(cmd):
    """(cmd with every literal `$(ls -d P1 P2 .. | head -1 [| grep . || echo F])` -> `$(ot_pick P1 P2 ..)`,
    [the candidate tuples]).  The `|| echo F` fallback is dropped: a required fleet path is checked, not guessed."""
    groups = []

    def rep(m):
        paths = tuple(m.group(1).split())
        if paths not in groups:
            groups.append(paths)
        return f"$(ot_pick {' '.join(paths)})"
    cmd = PATH_PICK_RE.sub(rep, cmd)
    for m in re.finditer(r"\$\(ot_pick ([^)]*)\)", cmd):
        paths = tuple(m.group(1).split())
        if paths not in groups:
            groups.append(paths)
    return cmd, groups


def path_pick_precheck(groups):
    """shell: fail the stage loudly (OT_FLOW_MISSING, rc 97) when a fleet path the command needs is absent on this host"""
    return "".join(f"ot_pick {' '.join(shlex.quote(p) for p in g)} >/dev/null || {{ echo 'OT_FLOW_MISSING: stage needs one "
                   f"of {' '.join(g)} (flow failure, reroute_reason flow_failure)'; exit {OT_FLOW_MISSING_RC}; }}\n"
                   for g in groups)


def subst(text, j):
    m = dict(RUN=j["run"], SRC=j.get("stage_source", f"{j['run']}/src"), CL=f"{j['run']}/cl", HOST=j["host"], NAME=label(j["name"]),
             LABEL=label(j["name"]), RAW_NAME=j["name"],
             BLOCK=j["spec"]["block"], COMMIT=j["spec"]["source"]["commit"], THREADS=str(j["spec"].get("threads", 16)))
    for k, v in m.items():
        text = text.replace("{" + k + "}", v)
    return text


# ------------------------------------------------------------------------------------------------ budget sheets
BUDGET_SHEETS = "results/rtl/budgets_20261006/sheets"
SDC_GEN_REF = os.environ.get("CL_SDC_GEN_REF", "origin/main")   # make_block_sdc.py always from main (stale-sheets 10-08)
# sign-off post-SDC must carry the sheet latency on vclk ONLY: latency on {<clk> vclk} re-idealises the real clock
IDEAL_SIGNOFF_RE = re.compile(r"set_clock_latency\s+[-0-9.]+\s+\[get_clocks\s+\{\s*(?!vclk\b)\S+\s+vclk\s*\}\]")


def budget_files(bud, check_only=False, insertion_override=None):
    """budget SDCs of the job's master from its sheet at sheets_ref (default origin/main; tools/budgets/make_block_sdc.py
    of the same ref): {name: text} + the sheet.  The SDC is generated HERE (localhost, from the published sheet), so
    every job uses the same sheet whatever its own branch carries."""
    ref = bud.get("sheets_ref", "origin/main")
    with tempfile.TemporaryDirectory() as td:
        # the SHEET is pinned at sheets_ref; the GENERATOR is always SDC_GEN_REF (main).  A job pinned to a ref older
        # than the 2026-10-07 make_block_sdc fix otherwise put the sheet latency on the real clock in budget_signoff.sdc,
        # read after set_propagated_clock: an IDEAL core clock at sign-off (drive-1613: swiglu FF -147.68 fake I2R hold).
        arch = sh(["bash", "-c", f"git -C {REPO} archive {ref} {BUDGET_SHEETS}/{bud['master']}.json | tar -x -C {td} && "
                   f"git -C {REPO} archive {SDC_GEN_REF} tools/budgets | tar -x -C {td}"], timeout=300)
        sheet = Path(td) / BUDGET_SHEETS / f"{bud['master']}.json"
        if arch.returncode or not sheet.exists():
            raise ValueError(f"no budget sheet {bud['master']} at {ref} ({arch.stderr[-300:]})")
        if check_only:
            return {}
        if insertion_override:   # measured insertion below the sheet target: SDC from it + the sheet's per-edge budgets
            sj = json.loads(sheet.read_text())
            sj["clock"]["internal_insertion"].update(insertion_override)
            sheet.write_text(json.dumps(sj, indent=1))
        tool = Path(td) / "tools/budgets/make_block_sdc.py"
        clk = bud.get("clock", "core_clk")
        dc = sum((["--domain-clock", x] for x in bud.get("domain_clock", [])), [])
        out = {}
        for name, args in (("budget_route.sdc", ["sdc", "--route-mode", "route"] + dc),
                           ("budget_signoff.sdc", ["sdc", "--route-mode", "signoff"] + dc), ("budget_ff.sdc", ["ff"])):
            r = sh(["python3", str(tool), args[0], bud["master"], "--sheets", str(sheet.parent), "--clock", clk] + args[1:],
                   timeout=120)
            if r.returncode:
                raise ValueError(f"make_block_sdc {name}: {r.stderr[-300:]}")
            out[name] = r.stdout
        bad = IDEAL_SIGNOFF_RE.search(out["budget_signoff.sdc"])
        if bad:
            raise ValueError(f"budget_signoff.sdc puts the sheet latency on the real clock ({bad.group(0)}): ideal-clock "
                             f"sign-off; generator {SDC_GEN_REF} is older than the 2026-10-07 make_block_sdc fix")
        out["budget_sheet.json"] = sheet.read_text()
        out["_ref"] = git("rev-parse", ref).stdout.strip()
        return out


def active_budget(spec):
    b = spec.get("budget")
    return b if isinstance(b, dict) and b.get("enabled", True) is not False and b.get("master") else None


def has_sheet(block):
    if not block:
        return False
    return sh(["git", "-C", str(REPO), "cat-file", "-e", f"origin/main:{BUDGET_SHEETS}/{block}.json"], timeout=60).returncode == 0


def budget_check(j):
    """calibrate CHECK against the sheet (never a re-calibration): None if within tolerance, else the reason"""
    bud = active_budget(j["spec"])
    if not bud or not j.get("budget") or not j.get("calibration"):
        return None
    ins = j["budget"]["insertion"]
    env = j["calibration"]["env"]
    m = float(env["CK_SS_MEAN"])
    why = []
    # coordinator 2026-10-06: only an insertion ABOVE the block's target stops the job; one at or below the target is
    # accepted and the budget SDCs are regenerated from the MEASURED insertion (+ the sheet's per-edge budgets)
    preserve_sheet = bud.get("preserve_full_sheet", False)
    if preserve_sheet:
        for corner in ("SS", "FF"):
            if env[f"CK_{corner}_MAX"] > ins[f"target_{corner.lower()}"]:
                why.append(f"audited full-sheet {corner} boundary maximum {env[f'CK_{corner}_MAX']} "
                           f"exceeds approved {ins[f'target_{corner.lower()}']}; re-plan required")
    if m > ins["target_ss"]:
        why.append(f"measured SS insertion {m:g} exceeds the block insertion TARGET {ins['target_ss']:g} by "
                   f"{m - ins['target_ss']:+.0f} ps (sheet {ins['ss']:g}, {ins['grade']})")
    if why:
        j["budget"]["check"] = dict(measured_ss=m, ok=False, reasons=why)
        return "; ".join(why)
    ov = dict(ss=round(m), ff=round(float(env["CK_FF_MEAN"])), ss_min=round(float(env["CK_SS_MIN"])),
              ss_max=round(float(env["CK_SS_MAX"])), ff_min=round(float(env["CK_FF_MIN"])), ff_max=round(float(env["CK_FF_MAX"])),
              grade="measured", source=f"closure-loop calibrate {j['name']} ({j['host']}:{j['run']})", over_target=False)
    files = budget_files(active_budget(j["spec"]), insertion_override=None if preserve_sheet else ov)
    if preserve_sheet:
        import hashlib
        if hashlib.sha256(files["budget_sheet.json"].encode()).hexdigest() != bud["sheet_sha256"]:
            raise ValueError("audited full budget sheet digest changed")
    for fn, text in files.items():
        if not fn.startswith("_"):
            ssh(j["host"], f"cat > {j['run']}/cl/{fn}", input=text, timeout=60, check=True)
    acc = dict(accepted=("audited complete sheet retained; boundary maxima within approved SS/FF targets"
                         if preserve_sheet else "measured insertion <= sheet target: budget SDCs regenerated from it"), sheet_ss=ins["ss"],
               sheet_grade=ins["grade"], target_ss=ins["target_ss"], measured=ov, sheets_ref=files["_ref"])
    py = ("import json,sys; p=sys.argv[1]; d=json.load(open(p)); d['budget_accepted']=json.loads(sys.argv[2]); "
          "json.dump(d,open(p,'w'),indent=1)")
    ssh(j["host"], f"python3 -c {shlex.quote(py)} {j['run']}/cl/calib.json {shlex.quote(json.dumps(acc))}", timeout=60)
    j["budget"]["insertion_used"] = ins if preserve_sheet else ov
    j["budget"]["check"] = dict(measured_ss=m, ok=True, reasons=[], accepted=acc["accepted"])
    return None


# ---- variant-keyed insertion (bf-insertion 2026-10-08): measured_insertion.json was keyed per BLOCK, and variants of one
# block differ wildly (bfh_halfphl_a730 routed on bfh_recutcgl50's SS 1169 / FF 714; the half-rate tree measured
# 1546 / 875).  A route may start on an ASSUMED insertion only when it was measured on the SAME variant: same block,
# same recipe script and the same insertion-relevant build options in the stage cmd (VAR=value assignments such as
# BF_VAR / OT_CGL_FRAC / OT_MULTI_VT / OT_CTS_FIX_HOOKS / corner overrides, --param K=V, other --flags).  Hold-repair
# knobs, run paths and labels are not part of the key.  No same-variant value -> sequential CTS-only calibrate.
VKEY_IGNORE_VARS = {"OUT", "SRC", "TTB", "OT_TTB_CORNER_MARK", "OT_MM_FF_SDC", "CL_LABEL_SUFFIX", "CL_STOP_AFTER"}
VKEY_IGNORE_FLAGS = {"--hold-margin-ns", "--pnr-stop-after", "--hold-corners", "--hm-guard"}


def variant_key(spec):
    """block + recipe + insertion-relevant options of the route (else calibrate) stage cmd (see above)"""
    stages = spec.get("stages") if isinstance(spec.get("stages"), dict) else {}
    cmd = ""
    for k in ("route", "calibrate"):
        st = stages.get(k)
        if isinstance(st, dict) and st.get("cmd"):
            cmd = st["cmd"]
            break
    toks = []
    for m in re.finditer(r"(?<![\w$])([A-Z][A-Z0-9_]*)=('[^']*'|\"[^\"]*\"|\S*)", cmd):
        if m.group(1) not in VKEY_IGNORE_VARS and not m.group(2).startswith("$("):
            if not re.search(r"--param\s+$", cmd[:m.start()]):
                toks.append(f"{m.group(1)}={m.group(2).rstrip(';&|').strip(chr(39) + chr(34))}")
    words = re.findall(r"\S+", cmd)
    skip = False
    for i, w in enumerate(words):
        if skip:
            skip = False
            continue
        if not w.startswith("--"):
            continue
        nxt = words[i + 1] if i + 1 < len(words) else ""
        has_val = "=" not in w and bool(re.match(r"^[\w.:,+=-]+$", nxt)) and not nxt.startswith("-")
        skip = has_val
        if w.split("=")[0] in VKEY_IGNORE_FLAGS:
            continue
        toks.append(f"{w} {nxt}" if has_val else w)
    scripts = sorted(x for x in set(re.findall(r"[\w./-]+\.(?:sh|py)\b", cmd)) if not x.endswith("tt_overlay.py"))
    return f"{spec.get('block')}|{','.join(scripts)}|{' '.join(sorted(set(toks)))}"


def _entry_variant(m):
    """the variant key of a measured_insertion.json entry: stored, else derived from the measuring job's JSON"""
    if not m:
        return None
    if m.get("variant"):
        return m["variant"]
    try:
        return variant_key(load_job(m["job"])["spec"])
    except Exception:  # noqa: BLE001
        return None


def same_variant_insertion(j):
    """(entry, why_not): the measured_insertion.json entry measured on THIS job's variant, else (None, reason)"""
    vk = variant_key(j["spec"])
    try:
        d = json.loads((STATE / "measured_insertion.json").read_text())
    except (OSError, ValueError):
        return None, "no measured_insertion.json"
    m = (d.get("variants") or {}).get(vk)
    if m:
        return m, None
    b = (d.get("blocks") or {}).get(j["spec"].get("block"))
    if b and _entry_variant(b) == vk:
        return b, None
    return None, (f"block value from another variant ({b.get('job')})" if b else "block never measured")


def _store_variant(d, j, e):
    vk = variant_key(j["spec"])
    e["variant"] = vk
    d.setdefault("variants", {})[vk] = dict(e, block=j["spec"].get("block"))


def _cal_entry(j, measured_at):
    c = j.get("calibration") or {}
    e = c.get("env") or {}
    p_ss = "CK_SSLIB_" if "CK_SSLIB_MEAN" in e else "CK_SS_"     # CK_SS_* is the route-corner value under CALIB-CORNER
    if not all(k in e for k in (p_ss + "MEAN", p_ss + "MIN", p_ss + "MAX", "CK_FF_MEAN", "CK_FF_MIN", "CK_FF_MAX")):
        return None
    return dict(
        job=j["name"], source_commit=j.get("commit_full"), host=j.get("host"), run=j.get("run"), clock=c.get("clock"),
        parasitics=c.get("parasitics"), measured_at=measured_at,
        ss=dict(mean=e[p_ss + "MEAN"], min=e[p_ss + "MIN"], max=e[p_ss + "MAX"]),
        ff=dict(mean=e["CK_FF_MEAN"], min=e["CK_FF_MIN"], max=e["CK_FF_MAX"]),
        **({"tt": dict(mean=e["CK_TT_MEAN"], min=e["CK_TT_MIN"], max=e["CK_TT_MAX"])} if "CK_TT_MEAN" in e else {}),
        route_ref=e.get("CK_ROUTE_REF", "SS"),
        boundary_n=(c.get("ss") or {}).get("boundary", {}) and c["ss"]["boundary"].get("n"),
        budget=(j.get("budget") or {}).get("check"))


_CAL_DONE = re.compile(r"^(\S+) (calibrate done \(rc=0\)|parallel calibrate: measured )")


def backfill_variants():
    """bf-insertion 2026-10-08: measurements taken before the variant table existed (only blocks{} kept the LAST one per
    block) are added to variants{} from every job's calibration, newest measurement per variant; existing variant
    entries are never replaced.  Without it a re-route of e.g. bfh2_recut_lvt (measured SS 951 / FF 556) could not
    find its own variant's value and would calibrate again.  Returns the number of variants added."""
    best = {}
    for j in all_jobs():
        try:
            t = max((m.group(1) for m in map(_CAL_DONE.match, j.get("events") or []) if m), default=None)
            if not t or not j.get("calibration") or not j.get("spec", {}).get("block"):
                continue
            ent = _cal_entry(j, t)
            vk = variant_key(j["spec"])
        except Exception:  # noqa: BLE001
            continue
        if ent and (vk not in best or t > best[vk]["measured_at"]):
            best[vk] = dict(ent, variant=vk, block=j["spec"]["block"], backfilled=True)
    p = STATE / "measured_insertion.json"
    with open(STATE / "measured.lock", "w") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        d = json.loads(p.read_text()) if p.exists() else {"schema": "opentallas.closure_loop.measured_insertion.v1",
                                                          "blocks": {}}
        v = d.setdefault("variants", {})
        new = {k: e for k, e in best.items() if k not in v}
        if new:
            v.update(new)
            d["updated"] = now_iso()
            p.write_text(json.dumps(d, indent=1) + "\n")
            (STATE / "measured.dirty").write_text(now_iso())
    return len(new)


def record_measured(j):
    """every calibrated block's measured insertion -> STATE/measured_insertion.json (published to main by the daemon
    as results/rtl/budgets_20261006/measured_insertion.json for the die clock plan)"""
    c = j.get("calibration") or {}
    if not c.get("env") or not _cal_entry(j, ""):
        return
    p = STATE / "measured_insertion.json"
    with open(STATE / "measured.lock", "w") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        d = json.loads(p.read_text()) if p.exists() else {"schema": "opentallas.closure_loop.measured_insertion.v1",
                                                          "blocks": {}}
        d["blocks"][j["spec"]["block"]] = ent = _cal_entry(j, now_iso())
        _store_variant(d, j, ent)
        d["updated"] = now_iso()
        p.write_text(json.dumps(d, indent=1) + "\n")
        (STATE / "measured.dirty").write_text(now_iso())


def claude_owns_main():
    policy = STATE / 'main_publish_owner.json'
    if not policy.exists():
        return False
    try:
        return json.loads(policy.read_text()).get('automatic_main_publish') is False
    except (OSError, ValueError):
        return True  # malformed ownership policy never authorizes a main push


def notify_claude_record(name, branch, commit):
    line = f"{now_iso()} READY {name}: {branch} {commit}; Claude owns main merge.\n"
    root = Path('/home/ubuntu/claude-takeover-20261007')
    root.mkdir(parents=True, exist_ok=True)
    append_locked(root / 'fleet_closure.log', line)
    append_locked(root / 'READY_TO_MERGE.md', '\n- ' + line)


MEASURED_REPO_PATH = "results/rtl/budgets_20261006/measured_insertion.json"


def publish_measured():
    """commit STATE/measured_insertion.json to main (explicit path, sparse scratch worktree); at most every 10 min"""
    dirty = STATE / "measured.dirty"
    if not dirty.exists():
        return
    stamp = STATE / "measured.published"
    if stamp.exists() and time.time() - stamp.stat().st_mtime < 600:
        return
    # el1013-fleet3 2026-10-13: the daemon's MAIN thread waited here behind 7 queued record commits and an auto-merge
    # (PUBLISH_LOCK, minutes each): no tick and no heartbeat for 30 min, 29 READY jobs unlaunched on 448 GB of idle
    # memory.  Never wait: a busy lock means "next tick".
    if not PUBLISH_LOCK.acquire(blocking=False):
        return
    try:
        if claude_owns_main():
            return  # owner consumes durable measured.dirty / measured_insertion.json; no main push
        if (STATE / "main_integration_hold.json").exists():
            return  # central coordinator is integrating; keep all unpublished measurements
        wt = STATE / "git" / "measured-main"
        for attempt in range(3):
            gfetch("main", timeout=600)
            wt_add(wt, "origin/main", ["/" + MEASURED_REPO_PATH])
            (wt / MEASURED_REPO_PATH).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(STATE / "measured_insertion.json", wt / MEASURED_REPO_PATH)
            git("add", "--sparse", "--", MEASURED_REPO_PATH, cwd=wt)
            if not sh(["git", "-C", str(wt), "diff", "--cached", "--name-only"], timeout=60).stdout.strip():
                break
            n = len(json.loads((wt / MEASURED_REPO_PATH).read_text())["blocks"])
            git("-c", "user.name=OpenTallas closure-loop", "-c", "user.email=boj@01.me", "commit", "-q", "-m",
                f"closure-loop: measured block clock insertion ({n} blocks; calibrate CTS-only runs) for the die clock plan\n\n"
                f"Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>\n", cwd=wt)
            if sh(["git", "-C", str(wt), "push", "-q", "origin", "HEAD:refs/heads/main"], timeout=900).returncode == 0:
                break
        wt_rm(wt)
    finally:
        PUBLISH_LOCK.release()
    dirty.unlink(missing_ok=True)
    stamp.write_text(now_iso())


def checkpoint_location(j):
    """Bind resume work to its actual checkpoint, never merely to synced source."""
    if not j.get("resume"):
        return None
    if j.get("checkpoint_affinity"):
        return j["checkpoint_affinity"]
    resume = j["resume"] if isinstance(j["resume"], dict) else {}
    proof = resume.get("next_stage_dryrun") or {}
    location = dict(host=resume.get("to_host") or proof.get("host") or j.get("host"),
                    run=resume.get("run") or proof.get("run") or j.get("run"))
    if not location["host"] or not location["run"]:
        raise ValueError("checkpoint resume lacks a host/run binding")
    j["checkpoint_affinity"] = location
    return location


def require_checkpoint_location(j):
    location = checkpoint_location(j)
    if location and (j.get("host"), j.get("run")) != (location["host"], location["run"]):
        raise ValueError("checkpoint resume host/run changed without a verified full checkpoint transfer: "
                         f"expected {location['host']}:{location['run']}")
    return location


@contextmanager
def prepared_source_archive(source, commit):
    """Check declared dependencies before remote mutation; yield the exact checked tar."""
    if "required_files" not in source:
        yield None, None
        return
    with tempfile.TemporaryDirectory(prefix="closure-source-") as scratch:
        archive = Path(scratch) / "source.tar"
        receipt = build_archive(REPO, commit, source, archive)
        receipt.pop("archive", None)  # retain hash/inventory, not a transient local path
        yield archive, receipt


# Directories a stage cmd names (OT_CTS_FIX_HOOKS=physical/common_flow/...) that a narrow source.paths list omits:
# the hooks are read from {SRC}, so a spec with paths [tools, rtl, physical/<view>] failed calibrate with
# "OT_CTS_FIX_HOOKS: no such file .../cg_pushdown.tcl" (flow-triage 2026-10-08).
IMPLIED_SRC_DIRS = ["physical/common_flow"]


def implied_src_paths(spec, paths, commit):
    stages = json.dumps(spec.get("stages", {}))
    out = []
    for d in IMPLIED_SRC_DIRS:
        if d not in stages or any(d == p or d.startswith(p.rstrip("/") + "/") for p in paths):
            continue
        if sh(["git", "-C", str(REPO), "cat-file", "-e", f"{commit}:{d}"], timeout=60).returncode == 0:
            out.append(d)
    return out


def sync_source(j):
    require_checkpoint_location(j)
    j["source_synced"] = False
    spec, host = j["spec"], j["host"]
    src = spec["source"]
    gfetch(src["branch"], timeout=600)
    full = git("rev-parse", "--verify", f"{src['commit']}^{{commit}}").stdout.strip()
    anc = sh(["git", "-C", str(REPO), "merge-base", "--is-ancestor", full, f"origin/{src['branch']}"], timeout=120)
    if anc.returncode:   # confirm against a fresh fetch before calling a human: the tracking ref may be stale
        gfetch(src["branch"], timeout=600)
        anc = sh(["git", "-C", str(REPO), "merge-base", "--is-ancestor", full, f"origin/{src['branch']}"],
                 timeout=120)
    if anc.returncode:
        raise ValueError(f"source commit {full[:12]} is not on origin/{src['branch']}")
    j["commit_full"] = full
    # SYNC-PATHS (drive-1010 2026-10-10): an extra path missing at the pinned commit made every sync fail 10 times with
    # an empty message (hbm_hc_quarter_hcq_r25gq-7eea45363: results/uarch/hbm_hc_group_root_icg_20261010/model.json) ->
    # fail once, terminally, naming the path.
    missing = [x for x in src.get("extra_paths", [])
               if sh(["git", "-C", str(REPO), "cat-file", "-e", f"{full}:{x}"], timeout=60).returncode]
    if missing:
        raise ValueError(f"source.extra_paths not in commit {full[:12]}: {', '.join(missing[:6])} -- fix the spec "
                         f"(the file must be committed at the pinned commit) and re-drop")
    base_paths = list(src.get("paths", DEFAULT_SRC_PATHS))
    if "paths" not in src:   # defaults absent at an old commit (configs/, src/) are skipped, never a pathspec error
        base_paths = [x for x in base_paths
                      if sh(["git", "-C", str(REPO), "cat-file", "-e", f"{full}:{x}"], timeout=60).returncode == 0]
    paths = base_paths + list(src.get("extra_paths", []))
    paths += implied_src_paths(spec, paths, full)
    run = j["run"]
    with prepared_source_archive(src, full) as (verified_tar, archive_receipt):
        ssh(host, f"set -e; mkdir -p {run}/src {run}/cl; test ! -e {run}/src/SOURCE_COMMIT || "
                  f"grep -q {full} {run}/src/SOURCE_COMMIT", timeout=60, check=True)
        mirrored = mirror_sync(j, host, run, full, paths, archive_receipt)
        with nullcontext() if mirrored else transport_command(host, bulk=True, wait_s=600) as base:
            if mirrored:
                pass
            elif verified_tar is not None:
                # Transfer this exact validated tar, not a second git archive.
                with verified_tar.open("rb") as stream:
                    put = subprocess.run(base + [f"tar -xf - -C {run}/src"], stdin=stream,
                                         capture_output=True, text=True, timeout=1800)
                if put.returncode:
                    raise RuntimeError(f"source sync failed: {put.stderr[-800:]}")
            else:
                arch = subprocess.Popen(["git", "-C", str(REPO), "archive", "--format=tar", full, "--", *paths],
                                        stdout=subprocess.PIPE)
                gz = subprocess.Popen(["gzip", "-1"], stdin=arch.stdout, stdout=subprocess.PIPE)
                arch.stdout.close()
                try:
                    put = subprocess.run(base + [f"tar -xzf - -C {run}/src"], stdin=gz.stdout,
                                         capture_output=True, text=True, timeout=1800)
                finally:
                    gz.stdout.close()
                    gz.wait()
                    arch.wait()
                if put.returncode or arch.returncode or gz.returncode:
                    raise RuntimeError(f"source sync failed: {put.stderr[-800:]}")
    if archive_receipt is not None:
        j["source_archive"] = archive_receipt
        ssh(host, f"cat > {run}/cl/source_archive.json", input=json.dumps(archive_receipt, indent=1), timeout=60, check=True)
    ship_helpers(host, run, j)
    corner_sta_compat(j, host, run, full)
    ssh(host, f"echo {full} > {run}/src/SOURCE_COMMIT && echo {run}/src > {run}/cl/SRC_DIR", timeout=60, check=True)
    ssh(host, f"cat > {run}/cl/run.sh.tmp && chmod +x {run}/cl/run.sh.tmp && mv {run}/cl/run.sh.tmp {run}/cl/run.sh",
        input=RUNNER, timeout=60, check=True)
    ssh(host, f"cat > {run}/cl/job.json", input=json.dumps(spec, indent=1), timeout=60, check=True)
    if active_budget(spec):
        files = budget_files(spec["budget"])
        for fn, text in files.items():
            if not fn.startswith("_"):
                ssh(host, f"cat > {run}/cl/{fn}", input=text, timeout=60, check=True)
        sheet = json.loads(files["budget_sheet.json"])
        j["budget"] = dict(master=spec["budget"]["master"], sheets_ref=files["_ref"],
                           insertion=sheet["clock"]["internal_insertion"],
                           entry_target_ss=sheet["clock"].get("entry_target_ss_ps"))

    j["source_synced"] = True

def mirror_sync(j, host, run, full, paths, receipt):
    """GITMIRROR (drive-1010 2026-10-10, tools/closure_loop/git_mirror.py): put the archive of full into {run}/src
    through the host's bare git mirror, moving only the objects it lacks.  True when done; False (event logged) when
    the host has no ready mirror or any step failed -- the caller then ships the tar exactly as before (receipt jobs:
    the same verified tar), re-extracting over anything a failed merge left, so a mirror fault costs time only."""
    if is_local(host):
        return False
    try:
        mc = git_mirror.config(host_cfg(host))
    except StopIteration:
        mc = None
    if mc is None:
        return False
    mirror, upstream = mc
    t0 = time.time()
    try:
        branch = j["spec"]["source"].get("branch")
        pr = ssh(host, git_mirror.probe_script(mirror, full, branch, upstream), timeout=UPSTREAM_PROBE_S)
        if pr.returncode or "MIRROR_READY" not in pr.stdout:
            event(j, f"git-mirror {mirror} not ready (rc={pr.returncode}): tar sync")
            return False
        how = "upstream"
        if "MIRROR_HAVE" not in pr.stdout:
            with transport_command(host, bulk=True, wait_s=600) as base:
                argv, env = git_mirror.push_command(REPO, host, mirror, full, base)
                push = subprocess.run(argv, env={**os.environ, **env}, capture_output=True, text=True,
                                      timeout=MIRROR_PUSH_S)
            if push.returncode:
                raise RuntimeError(f"push rc={push.returncode}: {push.stderr.strip()[-400:]}")
            how = f"push {git_mirror.pushed_objects(push.stderr)} objects"
        t1 = time.time()
        # view store (git_mirror.view_store_script): closed .lib/.lef views once per run root, hard-linked into src;
        # spec source.view_store false opts a job out (it then gets its own full copy, as before)
        vs = j["spec"]["source"].get("view_store", True) is not False
        ex = ssh(host, git_mirror.extract_script(mirror, full, paths, run, receipt, view_store=vs), timeout=1800)
        if ex.returncode or "GIT_MIRROR_EXTRACTED" not in ex.stdout:
            raise RuntimeError(f"extract rc={ex.returncode}: {ex.stderr.strip()[-400:]}")
        views = re.search(r"GIT_MIRROR_VIEWS (\d+) (\d+) MB", ex.stdout)
    except Exception as e:  # noqa: BLE001 -- any mirror fault falls back to the tar transfer
        event(j, f"git-mirror sync failed ({type(e).__name__}: {str(e)[:500]}): tar sync")
        return False
    event(j, f"git-mirror sync {full[:12]} via {how} in {t1 - t0:.0f}s + extract {time.time() - t1:.0f}s"
             + (f"; {views.group(1)} views / {int(views.group(2)) / 1024:.1f} GB hard-linked from the host view store" if views else "")
             + (" (receipt archive + required_files sha256 verified on host)" if receipt is not None else ""))
    try:
        ssh(host, git_mirror.detached(git_mirror.housekeep_script(mirror)), timeout=60)
    except Exception as e:  # noqa: BLE001 -- housekeeping is best effort
        log(f"git-mirror housekeeping {host}: {e}")
    return True


UPSTREAM_PROBE_S = git_mirror.UPSTREAM_FETCH_S + 60
MIRROR_PUSH_S = 1800


# Commits whose route generator passes `corner_sta.py --sdc-name 6_signoff.sdc` but whose own tools/w18/corner_sta.py
# predates that flag (main 80a11cea9, edd8613d6): the route completes and corner STA dies with "unrecognized arguments:
# --sdc-name" (flow-triage 2026-10-08 03:15, hbm_smh_front_s_ne_prot). Ship the corner_sta.py that honours an explicit
# sign-off SDC (089608310 semantics) into {SRC}; the original is kept as corner_sta.py.orig_<commit>.
CORNER_STA_GENERATORS = ("tools/hbm_accel_smh_physical.py",)
CORNER_STA_COMPAT_REF = "089608310"


def corner_sta_compat(j, host, run, full):
    show = lambda rev, path: sh(["git", "-C", str(REPO), "show", f"{rev}:{path}"], timeout=60)
    sta = show(full, "tools/w18/corner_sta.py")
    if sta.returncode or "--sdc-name" in sta.stdout:
        return
    if not any(g in json.dumps(j["spec"].get("stages", {})) and "--sdc-name" in show(full, g).stdout
               for g in CORNER_STA_GENERATORS):
        return
    new = show(CORNER_STA_COMPAT_REF, "tools/w18/corner_sta.py")
    if new.returncode or "--sdc-name" not in new.stdout:
        raise RuntimeError(f"corner_sta compat source {CORNER_STA_COMPAT_REF} lacks --sdc-name")
    f = f"{run}/src/tools/w18/corner_sta.py"
    ssh(host, f"cp {f} {f}.orig_{full[:9]} && cat > {f}", input=new.stdout, timeout=60, check=True)
    event(j, f"corner_sta.py replaced by {CORNER_STA_COMPAT_REF}'s (generator passes --sdc-name)")


HELPERS = HO.HELPERS

# deterministic calibrate (CTS-only) failures: a retry reproduces them, so the job stops at once with an owner action
CAL_OWNER_ACTION = {
    "cts_segv_macro_reg_sinks": "TritonCTS segfaults in separateMacroRegSinks (an inverter/forwarded-clock load on the root "
                                "clock net): add PRECTS=physical/hbm_accel_die_views/common/pre_cts_fclk_root_buf.tcl "
                                "(or your flow's equivalent root-buffer PRE_CTS hook) to calibrate+route, re-drop as a new job",
    "cts_segv": "OpenROAD segfault in CTS: reproduce on 3_place.odb, add a PRE_CTS workaround hook, re-drop",
    "rsz_max_buffer": "CTS timing repair hit the buffer cap (RSZ-0060): the IO SDC insertion/budget is off for this block or "
                      "a net has extreme fanout -- check the IO SDC (budget/calibrated), duplicate high-fanout drivers, re-drop",
    "odb_dont_touch": "CTS must rewire a dont_touch instance (ODB-0370): do not dont_touch cells on clock/repair nets "
                      "(or release them in PRE_CTS), re-drop",
    "est_parasitics": "EST-0104 inconsistent parasitics state in CTS: a step hook (PRE_CTS/POST_PLACE tcl) leaves "
                      "estimate_parasitics in a mixed state -- fix the hook, re-drop",
    "nickname": "route label not [A-Za-z0-9_]: use {LABEL} (the loop now sanitises {NAME} too); re-drop",
    "synth_or_place": "the CTS-only run failed before placement finished (synth/floorplan/place error): see the cal run.log, fix, re-drop",
    "flow_error": "ORFS error before CTS completed: see the CALIBRATE_FAIL detail, fix, re-drop",
}


def verdict_macros(j):
    """verdict.macros as src-relative view dirs (macro_views.py).  MACRO-VIEW (el1011-ds-misc 2026-10-11): a bare SRAM
    master there made every hold ECO / path summary / re-export die ORD-0001 on /src/<name>/<name>.lef.  Resolved
    against the job's pinned commit (git ls-tree, cached per commit); on failure the raw list is returned with an event
    and the remote helpers (hold_eco.sh / vtswap_eco.sh / path_summary.py) re-resolve against the snapshot or fail loudly."""
    raw = list(((j.get("spec") or {}).get("verdict") or {}).get("macros") or [])
    if not raw:
        return []
    commit = str(((j.get("spec") or {}).get("source") or {}).get("commit", ""))
    c = j.get("macro_views") or {}
    if c.get("commit") == commit and c.get("in") == raw and c.get("out"):
        return list(c["out"])
    if str(HERE) not in sys.path:
        sys.path.insert(0, str(HERE))
    import macro_views
    try:
        r = sh(["git", "-C", str(REPO), "ls-tree", "-r", "--name-only", commit], timeout=120)
        if r.returncode:
            raise macro_views.MacroViewError(f"git ls-tree {commit[:12]} failed rc={r.returncode}")
        out, rw = macro_views.resolve(raw, r.stdout.splitlines())
    except Exception as ex:   # noqa: BLE001 -- never block the stage on resolution; the helpers re-check remotely
        if c.get("error") != str(ex):
            event(j, f"MACRO-VIEW: verdict.macros {raw} not resolved at the daemon ({ex}); remote helpers re-resolve")
        j["macro_views"] = dict(commit=commit, error=str(ex))
        return raw
    if rw:
        event(j, "MACRO-VIEW: verdict.macros resolved " + ", ".join(f"{a} -> {b}" for a, b in rw))
    j["macro_views"] = dict(commit=commit, **{"in": raw, "out": out})
    return list(out)


# OVERLAY-TRACKS-MAIN (el1012-daemon-overlay 2026-10-12): ship_helpers tars HELPERS from the DAEMON's tree (HERE) into every
# job's {CL}, and stages copy them over the job's synced src (orfs_hold_mm.tcl, io_ref_routed.sdc, link_budget_consistent.sdc,
# cg_pushdown.tcl, ...).  The daemon tree is a worktree pinned at an old commit, so flow fixes on main (de53a3b7c, e409d530a,
# 3fd51709d, 1bfd5f1d2) never reached loop routes.  Each helper is now resolved against origin/main (fetched by the loop):
#   local == main tip                    -> local
#   local == an OLDER main version       -> main's tip blob (stale daemon copy; logged once per main tip)
#   local not any main version (daemon-only edit) -> local, with an OVERLAY-DRIFT alert (shared-tool rule: land it on main)
# overlay_drift_check() logs every differing helper (and the in-process imports) at startup and hourly.
OVERLAY_CHECK_EXTRA = ("tools/textbook_lint.py", "tools/fp_margin_lint.py", "tools/ref_tile/pre_route_gate.py",
                       "tools/pin_fit.py", "tools/ref_tile/ref_tile.py",
                       "tools/closure_loop/submit_lint.py", "tools/closure_loop/macro_views.py")
_OVL = {"head": None, "head_at": 0.0, "hist": {}, "said": set(), "check_at": 0.0}


def _ovl_head():
    if time.time() - _OVL["head_at"] > 60 or not _OVL["head"]:
        r = sh(["git", "-C", str(REPO), "rev-parse", "refs/remotes/origin/main"], timeout=60)
        _OVL["head"] = r.stdout.strip() if r.returncode == 0 else None
        _OVL["head_at"] = time.time()
    return _OVL["head"]


def _ovl_blob_id(data):
    import hashlib
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()


def _ovl_resolve(rel):
    """Shared effective resolver; preserve daemon logging and cached origin selection."""
    head = _ovl_head()
    data, state = HO.resolve_bytes(HERE.parents[1], REPO, rel, head, _OVL["hist"])
    if state in ("stale", "daemon_only") and (state, rel, head) not in _OVL["said"]:
        _OVL["said"].add((state, rel, head))
        log(f"OVERLAY-TRACKS-MAIN: {rel}: {state}; effective origin {str(head)[:9]}")
    return data, state


def overlay_helper_bytes(helper):
    rel = os.path.normpath(f"tools/closure_loop/{helper}")
    try:
        return _ovl_resolve(rel)[0]
    except Exception as ex:  # noqa: BLE001 -- never block a launch on the resolver: ship the daemon's copy
        log(f"OVERLAY-TRACKS-MAIN: {rel} unresolved ({type(ex).__name__}: {ex}); shipping the daemon's copy")
        return (HERE / helper).read_bytes()


def overlay_drift_check(force=False):
    """startup + hourly: log every overlay / in-process file whose daemon copy differs from origin/main"""
    if not force and time.time() - _OVL["check_at"] < 3600:
        return
    _OVL["check_at"] = time.time()
    try:
        gfetch("main", timeout=300)
        _OVL["head_at"] = 0.0
        rows = []
        for rel in [os.path.normpath(f"tools/closure_loop/{h}") for h in HELPERS] + list(OVERLAY_CHECK_EXTRA):
            if not (HERE.parents[1] / rel).is_file():
                rows.append(f"{rel}: missing in daemon tree"); continue
            st = _ovl_resolve(rel)[1]
            if st != "same":
                rows.append(f"{rel}: {st}")
        hd = (_OVL["head"] or "?")[:9]
        try:
            inprocess_stale_sync(_OVL["head"])
        except Exception:  # noqa: BLE001
            log("inprocess_stale_sync error:\n" + traceback.format_exc())
        if rows:
            log(f"OVERLAY-DRIFT CHECK vs origin/main {hd}: {len(rows)} file(s) differ (stale = main's copy is shipped; "
                f"daemon_only = commit to main; in-process imports need a restart): " + "; ".join(rows))
        else:
            log(f"OVERLAY-DRIFT CHECK vs origin/main {hd}: all overlay files equal main")
    except Exception:  # noqa: BLE001
        log("overlay_drift_check error:\n" + traceback.format_exc())


# INPROCESS-SYNC (ROOT 2026-10-15): the daemon imports tools/ref_tile (pre_route_gate -> ref_tile ->
# clock_entry_constraints, source_binding) and tools/hier_contract IN PROCESS at submit.  Those files are not overlays, so
# a main fix never reached the pinned daemon tree: twice on 10-15 (13:04, 17:15) the daemon judged kits generated by
# main's clock_entry_constraints with its OLDER generator and refused them (native_cts_sdc diff).  Hourly (with the drift
# check) every file of these trees whose daemon copy is an OLDER main version, or missing, is replaced by main's blob;
# daemon-only edits are kept and reported.  When a replaced file is already imported, the daemon exits at the next tick
# start with no housekeeping/recovery work in flight and systemd (Restart=always, KillMode=process) restarts it.
INPROCESS_SYNC_DIRS = ("tools/ref_tile", "tools/hier_contract")
_RESTART = {"why": None}


def inprocess_stale_sync(head=None):
    head = head or _ovl_head()
    root = HERE.parents[1]
    if not head:
        return []
    r = sh(["git", "-C", str(REPO), "ls-tree", "-r", head, "--", *INPROCESS_SYNC_DIRS], timeout=120)
    if r.returncode:
        return []
    synced = []
    for ln in r.stdout.splitlines():
        meta, rel = ln.split("\t", 1)
        mode, typ, blob = meta.split()
        if typ != "blob" or "__pycache__" in rel:
            continue
        f = root / rel
        if f.is_file():
            if HO.blob_id(f.read_bytes()) == blob:
                continue
            data, state = HO.resolve_bytes(root, REPO, rel, head, _OVL["hist"])
            if state != "stale":
                continue
        else:
            p = subprocess.run(["git", "-C", str(REPO), "cat-file", "blob", blob], capture_output=True, timeout=60)
            if p.returncode:
                continue
            data = p.stdout
        f.parent.mkdir(parents=True, exist_ok=True)
        tmp = f.with_name(f".{f.name}.inprocess-sync")
        tmp.write_bytes(data)
        os.chmod(tmp, 0o755 if mode == "100755" else 0o644)
        os.replace(tmp, f)
        synced.append(rel)
    if synced:
        loaded = sorted(rel for rel in synced for m in list(sys.modules.values())
                        if getattr(m, "__file__", None) and Path(m.__file__).resolve() == (root / rel).resolve())
        log(f"INPROCESS-SYNC vs origin/main {head[:9]}: {len(synced)} stale/missing file(s) replaced by main's copy: "
            + ", ".join(synced[:20]) + (f" (+{len(synced) - 20} more)" if len(synced) > 20 else "")
            + (f"; already imported {loaded}: re-imported before the next submit check" if loaded else ""))
        if loaded:
            _INPROC["gen"] += 1             # ref_gate_modules re-imports them before the next submit check
    return synced


_INPROC = {"head": None, "gen": 0, "loaded_gen": 0, "lock": threading.Lock()}


def inprocess_sync_on_main_move():
    """every tick: when origin/main moved since the last INPROCESS-SYNC, re-sync the daemon's tools/ref_tile and
    tools/hier_contract at once (not hourly): the submit check judges kits with these generators, and a kit generated on
    a newer main was refused 'native_cts_sdc' while the daemon still held the older generator (hgi_sm_xl2_ctl-cl2b 20:51
    10-15).  Changed in-process modules are re-imported before the next submit check (ref_gate_modules)."""
    head = _ovl_head()
    if not head or head == _INPROC["head"]:
        return
    synced = inprocess_stale_sync(head)
    _INPROC["head"] = head
    if synced:
        _INPROC["gen"] += 1


def ref_gate_modules():
    """the pre_route_gate module for the submit check, re-imported (with every tools/ref_tile / hier_contract module it
    loaded) after an INPROCESS-SYNC changed those files"""
    with _INPROC["lock"]:
        if _INPROC["loaded_gen"] != _INPROC["gen"]:
            root = (HERE.parents[1]).resolve()
            for name, m in list(sys.modules.items()):
                f = getattr(m, "__file__", None)
                if f and any(str(Path(f).resolve()).startswith(str(root / d) + "/") for d in INPROCESS_SYNC_DIRS):
                    del sys.modules[name]
            _INPROC["loaded_gen"] = _INPROC["gen"]
            import importlib
            importlib.invalidate_caches()
            log(f"INPROCESS-SYNC: ref_tile / hier_contract modules re-imported (generation {_INPROC['gen']})")
        sys.path.insert(0, str(HERE.parent / "ref_tile"))
        import pre_route_gate  # noqa: E402
        return pre_route_gate


def restart_if_requested():
    """exit (systemd restarts the daemon; KillMode=process keeps every job) only between ticks with no background
    housekeeping / recovery running"""
    if not _RESTART["why"] or any(f is not None and not f.done() for f in (_HOUSE_FUTURE, _RECOVERY_FUTURE)):
        return False
    log(f"INPROCESS-SYNC restart: {_RESTART['why']}")
    _STOP.set()                     # cmd_daemon drains the in-flight steps (each saves its job), then exits
    return True


# LOOP-PIN-STUB: stdin script patching a stale ref_tile.py export (pre-ba4d5d136) to run abstract_pin_stub.py before the lint
PINSTUB_PATCH = r"""import sys
p = sys.argv[1]
t = open(p).read()
a = '    res = child_lint.lint(str(lef), str(o)) if lef.exists() else'
if "abstract_pin_stub" not in t and t.count(a) == 1:
    t = t.replace(a, '    if lef.exists():  # LOOP-PIN-STUB (closure loop, = ba4d5d136)\n'
                     '        subprocess.run([sys.executable, str(ROOT / "tools/hier_contract/abstract_pin_stub.py"), str(lef), str(lef)])\n' + a)
    open(p, "w").write(t)
    print("LOOP-PIN-STUB: patched", p)
"""


def installed_helper_receipt(host, run, frozen, allow_publish=False):
    """Inspect the executed helper directory without changing a running snapshot.  allow_publish: an installed sidecar
    that differs from `frozen` only in PUBLISH_ONLY rows verifies on its own rows (receipt["installed_plan"])."""
    fn = "installed_plan_receipt" if allow_publish else "verify_installed_plan"
    if is_local(host):
        return getattr(HO, fn)(Path(run) / "cl", frozen)
    code = ("exec(" + repr(Path(HO.__file__).read_text()) + ")\n"
            "print(json.dumps(" + fn + "(" + repr(run + "/cl") + ","
            + repr(frozen) + ")))\n")
    result = ssh(host, "python3 -", input=code, timeout=120)
    if result.returncode:
        raise ValueError("original remote helper verification failed: " + result.stderr[-1500:])
    try:
        return json.loads(result.stdout)
    except (ValueError, TypeError) as ex:
        raise ValueError("original remote helper verification receipt unreadable") from ex


def _publish_refresh(frozen):
    """(refreshed plan, payloads, modes, sanctioned rows) when a PUBLISH_ONLY helper of the frozen plan drifted to exactly
    origin/main (compare_plans_sanctioned rules); else None.

    Only the publish rows are refreshed: every other helper keeps its frozen (already executed) bytes, whatever main did
    to it since.  TW5-BANKLATSU 2026-10-19: the refresh used to compare the WHOLE current helper set, so any unrelated
    route-helper drift on main (meas_resta.py, w18/corner_sta.py since the route froze) refused it silently and
    resume-postroute of hbm_sfu_lg_pair_tap_leaf_rt24_1019-b1-72af5d8b1 re-ran the frozen exporter (6-pin OBS spacing
    child_lint FAIL) although the exact-window exporter fix ff7aa2deb was on main.  Refreshed rows carry resolution
    "publish_refresh": their bytes come from the content store on a later reinstall (not the plan's origin tree)."""
    try:
        current, cur_payloads = HO.capture_plan(HERE.parents[1], REPO, head=_ovl_head(), cache=_OVL["hist"])
        if HO.compare_plans(frozen, current)[0]:
            return None
        frows = {f["path"]: f for f in frozen["files"]}
        crows = {f["path"]: f for f in current["files"]}
        pub = [p for p in HO.PUBLISH_ONLY if p in frows and p in crows
               and HO.content_rows([frows[p]]) != HO.content_rows([crows[p]])]
        if not pub:
            return None
        files = [dict(crows[f["path"]], resolution="publish_refresh") if f["path"] in pub else f for f in frozen["files"]]
        refreshed = dict(frozen, files=files, content_sha256=HO.digest(files))
        ok, _why, sanctioned = HO.compare_plans_sanctioned(frozen, refreshed, REPO, head=current.get("origin_main"))
        if not ok or not sanctioned or any(r.get("kind") != "publish" for r in sanctioned):
            return None
        payloads, _src = HO.recover_frozen_payloads(REPO, HELPER_STORE, frozen)
        payloads.update({p: cur_payloads[p] for p in pub})
    except (ValueError, OSError, subprocess.SubprocessError, KeyError, TypeError):
        return None
    return refreshed, payloads, {f["path"]: f["mode"] for f in files}, sanctioned


def _adopt_installed_publish_plan(job, frozen, installed, host, run):
    """INTERRUPTED PUBLISH REFRESH (QXPQ-UNSTICK 2026-10-19): the run's verified cl/ holds a plan that differs from the
    job's only in PUBLISH_ONLY rows (a publish refresh shipped to the host, then the daemon restarted before the job state
    was saved -- or the reverse).  Adopt the installed plan when every differing row is a main revision of that publish
    helper and its bytes are recoverable, so the job follows what its run dir really holds; _publish_refresh then brings
    the exporter to origin/main again if needed.  Anything else still refuses (sidecar differs)."""
    head = _ovl_head() or HO.main_head(REPO)
    fr = {r["path"]: r for r in HO.frozen_rows(frozen)}
    ir = {r["path"]: r for r in HO.frozen_rows(installed)}
    for rel in (p for p in ir if ir[p] != fr.get(p)):
        hist = HO._main_blobs(REPO, head, rel)
        if rel not in HO.PUBLISH_ONLY or ir[rel]["git_blob"] not in hist or fr[rel]["git_blob"] not in hist:
            raise ValueError(f"original helper sidecar differs from job frozen plan ({rel} is not a main revision of a "
                             f"publish helper)")
    payloads, _src = HO.recover_frozen_payloads(REPO, HELPER_STORE, installed)
    HO.store_payloads(HELPER_STORE, installed, payloads)
    job.setdefault("route_overlay_plan_gate", frozen)
    job.setdefault("helper_overlay_publish_adoptions", []).append(dict(
        at=now_iso(), host=host, run=run, job_plan=frozen.get("content_sha256"), installed=installed.get("content_sha256")))
    event(job, f"PUBLISH-ADOPT: run cl/ holds plan {str(installed.get('content_sha256'))[:12]} (publish rows only differ "
               f"from job plan {str(frozen.get('content_sha256'))[:12]}; interrupted publish refresh) -> adopted")
    job["route_overlay_plan"] = installed
    return installed


# RESTART-SAFE SHIP (DAEMON-FIX2 2026-10-19): the helper tar is unpacked into a staging dir first and only a complete
# set is moved into cl/, the sidecar helper_overlay_plan.json last, so an interrupted transfer never leaves cl/ half
# old / half new; and the job state is checkpointed (saved) BEFORE cl/ changes, so a daemon restart between the ship
# and the end-of-step save can no longer strand a job on a plan its run dir does not hold (QXPQ-UNSTICK).  Either order
# of a remaining mismatch (job new / run old after a failed ship) is a publish-only difference _adopt_installed_publish_plan
# reconciles.
SHIP_HELPERS_SH = ("mkdir -p {cl} && S=$(mktemp -d {cl}/.ship.XXXXXX) || exit 1; "
                   "tar -xf - -C \"$S\" || {{ rm -rf \"$S\"; exit 1; }}; "
                   "for f in \"$S\"/*; do [ \"${{f##*/}}\" = helper_overlay_plan.json ] || mv -f \"$f\" {cl}/ || exit 1; done && "
                   "{{ [ ! -e \"$S/helper_overlay_plan.json\" ] || mv -f \"$S/helper_overlay_plan.json\" {cl}/; }} && rmdir \"$S\"")


def checkpoint(j, why=""):
    """WRITE-AHEAD SAVE (DAEMON-FIX2 2026-10-19): persist a daemon job's in-memory state before a step changes files on a
    remote host, so a restart (tool sync: systemctl restart several times a day; KillMode=process) between that change
    and the end-of-step save_job cannot lose what the step decided.  Jobs without a state file (tests, CLI dry runs)
    are left alone."""
    try:
        name = j.get("name") if isinstance(j, dict) else None
        if not name or not NAME_RE.fullmatch(name) or not jpath(name).exists():
            return False
    except Exception:  # noqa: BLE001
        return False
    save_job(j)
    return True


def frozen_helper_transport_rows(plan, payloads, modes):
    """Transport precisely the recorded helper membership, including old sets.

    A newer daemon can add or remove helper names. An existing route keeps its
    verified bytes and modes; only the already-sanctioned publish rows may differ.
    """
    rows = HO.frozen_rows(plan)
    expected = {row['path'] for row in rows}
    if set(payloads) != expected or modes is None or set(modes) != expected:
        raise ValueError('FROZEN_HELPER_OVERLAY: transport membership differs from frozen plan')
    result = []
    for row in rows:
        rel = row['path']; data = payloads[rel]
        if (hashlib.sha256(data).hexdigest() != row['sha256'] or HO.blob_id(data) != row['git_blob']
                or modes[rel] != row['mode']):
            raise ValueError('FROZEN_HELPER_OVERLAY: transport bytes/mode differ from frozen plan: ' + rel)
        result.append((Path(rel).name, data, row['mode']))
    return result


def ship_helpers(host, run, job=None):
    """Install new helpers, or verify and reuse an already executed frozen set."""
    # one ssh carrying a tar of all helpers (was one ssh per helper, 13 per launch, made while holding FLEET_LOCK)
    import io, tarfile
    payloads = None
    modes = None
    frozen = None
    if job is not None and job.get("freeze_helper_overlay"):
        frozen = job.get("route_overlay_plan")
        if frozen is None and (job.get("source_synced") or job.get("helper_overlay_installed")
                               or job.get("helper_overlay_verification")):
            raise ValueError("FROZEN_HELPER_OVERLAY: original job helper plan is missing; preserve original execution")
        if frozen is not None:
            try:
                receipt = installed_helper_receipt(host, run, frozen, allow_publish=True)
                installed = receipt.pop("installed_plan", None)
                if installed is not None and receipt["status"] == "verified_original":
                    frozen = _adopt_installed_publish_plan(job, frozen, installed, host, run)
                if receipt["status"] == "verified_original":
                    HO.recover_frozen_payloads(REPO, HELPER_STORE, frozen)
                    job["helper_overlay_verification"] = dict(receipt, verified_at=now_iso(),
                                                               host=host, run=run, mutation=False)
                    pub = _publish_refresh(frozen)
                    if pub is None:
                        return
                    # PUBLISH REFRESH (RLYH0-FIN 2026-10-19): an installed, verified run dir is re-entered (resume-postroute
                    # / re-collect) and ONLY publish helpers (view_export.py) drifted to exactly origin/main: ship the
                    # current publish bytes into cl/ (the route's own helpers are byte-identical, nothing else changes).
                    # Without this the PUBLISH_ONLY sanction never reached a preserved closed route: resume-postroute
                    # of qfwd_rlyh0_128_ne_65x30-f1-fc2236d82 re-ran the frozen exporter and lost the CLOSED result again.
                    current, payloads, modes, sanctioned = pub
                    job.setdefault("route_overlay_plan_gate", frozen)
                    job.setdefault("helper_overlay_sanctioned", []).extend(dict(r, at=now_iso(), host=host, run=run)
                                                                           for r in sanctioned)
                    for r in sanctioned:
                        event(job, f"PUBLISH SANCTION (installed run): {r['path']} frozen {r['frozen_git_blob'][:9]} -> "
                                   f"fleet/main {r['current_git_blob'][:9]} (origin/main {str(r['origin_main'])[:9]}); "
                                   f"cl/ refreshed, route helpers unchanged")
                    job["route_overlay_plan"] = frozen = current
                    job["helper_overlay_verification"]["mutation"] = True
                    HO.store_payloads(HELPER_STORE, frozen, payloads)
                origin = job.get("bench_helper_origin")
                if payloads is not None:
                    pass                                                   # publish refresh above
                elif origin:
                    if origin == dict(host=host, run=run):
                        raise ValueError("bench helper origin must be a different execution location")
                    original = installed_helper_receipt(origin["host"], origin["run"], frozen)
                    if original.get("status") != "verified_original":
                        raise ValueError("bench helper origin has no verified original execution")
                    payloads = HO.committed_frozen_payloads(REPO, frozen)
                    modes = {f["path"]: f["mode"] for f in HO.frozen_rows(frozen)}
                    job["bench_helper_origin_verification"] = dict(original, **origin, verified_at=now_iso())
                elif job.get("source_synced") or job.get("helper_overlay_installed") or job.get("helper_overlay_verification"):
                    # FROZEN-HELPER-REINSTALL (el1014-root-frozen-helper, 2026-10-14): an installed job whose run
                    # directory has NO helpers is a fresh location -- move_to_other_host (AGIdock run root < 200 GB
                    # -> EPYC1/EPYC4) or a cleaned run root.  Six jobs stopped NEEDS_HUMAN here.  Re-install the
                    # exact frozen bytes (committed origin tree, else the content-addressed store), each verified
                    # against the plan; a partially present or changed directory still refuses (verify above).
                    try:
                        payloads, source = HO.recover_frozen_payloads(REPO, HELPER_STORE, frozen)
                    except ValueError as ex:
                        raise ValueError(f"previously installed frozen helper directory is missing and its exact "
                                         f"bytes are not recoverable ({ex})") from ex
                    modes = {f["path"]: f["mode"] for f in HO.frozen_rows(frozen)}
                    job.setdefault("helper_overlay_reinstalls", []).append(dict(
                        host=host, run=run, source=source, content_sha256=frozen.get("content_sha256"),
                        origin_main=frozen.get("origin_main"), verified_at=now_iso()))
            except (ValueError, OSError, subprocess.SubprocessError) as ex:
                raise ValueError(f"FROZEN_HELPER_OVERLAY: {ex}; preserve original execution") from ex
        if payloads is None and frozen is not None and job.get("replay_frozen_helpers"):
            # FROZEN-REPLAY (ROOT 2026-10-16, coordinator: recover drift-blocked jobs from their ORIGINAL state): a human
            # `retry --replay-frozen-helpers` runs the job with exactly the helper bytes its gate froze (committed origin
            # tree / content store, every byte verified against the plan) instead of today's helpers.  Never automatic.
            try:
                payloads, src_ = HO.recover_frozen_payloads(REPO, HELPER_STORE, frozen)
            except ValueError as ex:
                raise ValueError(f"FROZEN_HELPER_OVERLAY: replay requested but the frozen bytes are not recoverable "
                                 f"({ex})") from ex
            modes = {f["path"]: f["mode"] for f in HO.frozen_rows(frozen)}
            event(job, f"FROZEN-REPLAY: shipping the gate-frozen helper set {str(frozen.get('content_sha256'))[:12]} "
                       f"(origin {str(frozen.get('origin_main'))[:9]}, {src_}) by human request")
        if payloads is None:
            current, payloads = HO.capture_plan(HERE.parents[1], REPO, head=_ovl_head(), cache=_OVL["hist"])
            modes = {f["path"]: f["mode"] for f in current["files"]}
            frozen = job.setdefault("route_overlay_plan", current)
            ok, why, sanctioned = HO.compare_plans_sanctioned(frozen, current, REPO, head=current.get("origin_main"))
            if not ok and not why.startswith(("missing", "frozen helper plan digest", "malformed")):
                # AUTO FROZEN-REPLAY (ROOT 2026-10-16, coordinator: fix helper drift generally): the gate validated the job
                # with ONE consistent frozen helper set; main moved on (tools/textbook_lint.py 2c5779073, then
                # tools/tt_views/view_export.py cdaf10fcb/a0de5e9ba under 8 queued jobs).  Run the job with exactly
                # that frozen set (every byte verified against the plan) instead of stopping NEEDS_HUMAN; only an
                # unrecoverable set still refuses.  A fresh gate is the way to adopt newer helpers.
                try:
                    payloads, src_ = HO.recover_frozen_payloads(REPO, HELPER_STORE, frozen)
                except ValueError as ex:
                    raise ValueError(f"FROZEN_HELPER_OVERLAY: {why}; frozen bytes not recoverable ({ex}); preserve "
                                     f"original job and submit a fresh source-bound gate") from ex
                modes = {f["path"]: f["mode"] for f in HO.frozen_rows(frozen)}
                job.setdefault("helper_overlay_replays", []).append(dict(at=now_iso(), host=host, run=run, drift=why[:300],
                                                                         content_sha256=frozen.get("content_sha256")))
                event(job, f"FROZEN-REPLAY (auto): {why[:160]} -> shipping the gate-frozen helper set "
                           f"{str(frozen.get('content_sha256'))[:12]} ({src_})")
                HO.store_payloads(HELPER_STORE, frozen, payloads)
                ok, sanctioned = True, []
                current = frozen
            if not ok:
                raise ValueError(f"FROZEN_HELPER_OVERLAY: {why}; preserve original job and submit a fresh source-bound gate")
            lint = [r for r in sanctioned if r.get("kind") == "lint_frozen"]
            if lint:
                # LINT-ONLY SANCTION (ROOT 2026-10-16): ship the FROZEN bytes of lint-only helpers (exact, from the plan's
                # committed origin tree / store) so the route executes its original helper set; the plan rows stay frozen.
                fpay, _src = HO.recover_frozen_payloads(REPO, HELPER_STORE, frozen)
                frows = {f["path"]: f for f in frozen["files"]}
                for r in lint:
                    payloads[r["path"]] = fpay[r["path"]]
                    modes[r["path"]] = frows[r["path"]]["mode"]
                    event(job, f"LINT-ONLY SANCTION: {r['path']} frozen {r['frozen_git_blob'][:9]} kept (main now "
                               f"{r['current_git_blob'][:9]}); lint constants only, route runs its frozen bytes")
                job.setdefault("helper_overlay_sanctioned", []).extend(dict(r, at=now_iso(), host=host, run=run) for r in lint)
                cur_files = [frows[f["path"]] if f["path"] in {r["path"] for r in lint} else f for f in current["files"]]
                current = dict(current, files=cur_files, content_sha256=HO.digest(cur_files))
                sanctioned = [r for r in sanctioned if r.get("kind") != "lint_frozen"]
                if not sanctioned:
                    current = frozen if HO.digest(frozen["files"]) == current["content_sha256"] else current
            if sanctioned:
                # FLEET-RUN SANCTION (ROOT 2026-10-16): only fleet-run helpers (tt_overlay.py: the route executes the
                # fleet copy kept at main, fleet-first since 00cbddaea) drifted, to exactly origin/main's blob.  Keep the
                # gate's plan, record both shas, and freeze the executed bytes so a later verify/reinstall matches cl/.
                job.setdefault("route_overlay_plan_gate", frozen)
                job.setdefault("helper_overlay_sanctioned", []).extend(dict(r, at=now_iso(), host=host, run=run)
                                                                       for r in sanctioned)
                for r in sanctioned:
                    event(job, f"{'PUBLISH' if r.get('kind') == 'publish' else 'FLEET-RUN'} SANCTION: {r['path']} frozen {r['frozen_git_blob'][:9]} -> fleet/main "
                               f"{r['current_git_blob'][:9]} (sha256 {r['current_sha256'][:16]}, origin/main "
                               f"{str(r['origin_main'])[:9]}); the route runs the fleet copy")
                job["route_overlay_plan"] = frozen = current
            HO.store_payloads(HELPER_STORE, frozen, payloads)
    # Frozen recovery/publish refresh may contain fewer (or older) helpers than
    # today's HELPERS. Never append a new dependency to an already executed set.
    outgoing = (frozen_helper_transport_rows(frozen, payloads, modes) if payloads is not None else
                [(Path(h).name, overlay_helper_bytes(h), (HERE / h).stat().st_mode & 0o777) for h in HELPERS])
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w") as tf:
        for name, data, mode in outgoing:
            ti = tarfile.TarInfo(name); ti.size = len(data); ti.mode = mode
            ti.mtime = int(time.time()); tf.addfile(ti, io.BytesIO(data))
        if frozen is not None:
            data = (json.dumps(frozen, indent=1) + "\n").encode()
            ti = tarfile.TarInfo("helper_overlay_plan.json")
            ti.size = len(data); ti.mode = 0o644
            tf.addfile(ti, io.BytesIO(data))
    if job is not None:
        checkpoint(job, "ship_helpers")
    if is_local(host):
        os.makedirs(f"{run}/cl", exist_ok=True)
        stage = tempfile.mkdtemp(prefix=".ship.", dir=f"{run}/cl")
        with tarfile.open(fileobj=io.BytesIO(buf.getvalue())) as tf:
            tf.extractall(stage)
        names = sorted(os.listdir(stage), key=lambda n: n == "helper_overlay_plan.json")   # sidecar last
        for n in names:
            os.replace(os.path.join(stage, n), f"{run}/cl/{n}")
        os.rmdir(stage)
        if frozen is not None:
            job["helper_overlay_installed"] = True
        return
    with transport_command(host) as base:
        r = subprocess.run(base + [SHIP_HELPERS_SH.format(cl=shlex.quote(f"{run}/cl"))],
                           input=buf.getvalue(), capture_output=True, timeout=120)
    if r.returncode:
        raise RuntimeError(f"command failed rc={r.returncode}: ship_helpers {host}:{run}/cl {r.stderr[-300:]!r}")
    if frozen is not None:
        job["helper_overlay_installed"] = True


def route_cfg_of(rb):
    """the ORFS config.mk of the route whose base dir is rb (results/asap7/<d>/base -> <orfs>/config.mk): a stacked ECO
    (hold on a VT-swap / combo base) passes it as ROUTE_CFG so hold_eco.sh keeps the route's layer cap + face keepout"""
    ps = Path(str(rb)).parents
    return str((ps[3] if len(ps) > 3 else Path(str(rb))) / "config.mk")


def tag(st, j):
    return f"{st['key']}.a{j['attempt']}"


# LEC OFF EVERYWHERE (drive-1043 2026-10-08): ORFS settings.mk defaults LEC_CHECK to 1 whenever the image carries
# kepler-formal, and kepler-formal is built for AVX-512: on a host without it (PVE1 Xeon E5-2680 v4) CTS dies with SIGILL
# ("child killed: illegal instruction", ha2_relay_tx_internal, drive-1013).  Most generators write LEC_CHECK = 0 into
# their config.mk; a flow that does not inherited the default.  Every non-bench stage now runs with {CL}/bin first on
# PATH, where a docker shim adds -e LEC_CHECK=0 to every `docker run` (settings.mk uses ?=, so the container env wins;
# no flow sets LEC_CHECK = 1).  LEC is not part of block sign-off (benches + STA + DRC are).
DOCKER_SHIM = r"""#!/bin/bash
# closure-loop shim: every container gets LEC_CHECK=0 (kepler-formal needs AVX-512); then the real docker
for e in ${PATH//:/ }; do
  if [ -x "$e/docker" ] && ! [ "$e/docker" -ef "$0" ]; then
    if [ "${1:-}" = run ] && [ -n "${OT_FP_LINT_DIR:-}" ]; then
      # FP-LINT: the floorplan margin lint (ORFS PRE GLOBAL_PLACE) sees OT_FP_LINT and writes its verdict to /ot_fplint
      mkdir -p "$OT_FP_LINT_DIR"; shift
      # PREROUTE-GATE: the pre-route timing gate (ORFS POST DETAIL_PLACE) sees OT_PREROUTE_GATE, writes PREROUTE_FAIL there
      exec "$e/docker" run ${OT_MEM_CAP_GB:+--memory ${OT_MEM_CAP_GB}g --memory-swap ${OT_MEM_CAP_GB}g} --oom-score-adj ${OT_OOM_SCORE_ADJ:-500} -e LEC_CHECK=0 -e OT_IOREF_INPUT_PF -e OT_FP_LINT -e OT_FP_LINT_ARGS -e OT_PREROUTE_GATE -e OT_PREROUTE_GATE_ARGS \
        -e OT_ABC_NO_DCH -e OT_HOLD_STOP -e OT_SLIVER_BLOCK -e OT_EDGE_SLIVER_UM -e OT_CTS_MACRO_CLUSTER -e OT_CTS_MACRO_SIZE -e OT_CTS_MACRO_DIAM -v "$OT_FP_LINT_DIR:/ot_fplint" "$@"
    fi
    # MACRO-CLK (macro-clk-1010): OT_CTS_MACRO_CLUSTER / _SIZE / _DIAM reach physical/common_flow/macro_cts_cluster.tcl
    # ABC-NODCH (drive-2155): a recipe exporting OT_ABC_NO_DCH=1 gets &synch2 for &dch (tools/orfs_hold_mm.py)
    # MEM-CAP (drive-0849 2026-10-09): OT_MEM_CAP_GB bounds the flow container's cgroup (see stage_mem_cap)
    # OOM-IN-CONTAINER (drive-1010 2026-10-10): the container's own processes (openroad / yosys) get the loop stage's +500
    # too; at 0 the kernel killed ~20 tiny +500 wrappers first (AGIdock 05:17-05:21) before reaching the 17 GB openroad.
    # The host probe still lowers die containers to -900 after start.
    if [ "${1:-}" = run ]; then shift; exec "$e/docker" run ${OT_MEM_CAP_GB:+--memory ${OT_MEM_CAP_GB}g --memory-swap ${OT_MEM_CAP_GB}g} --oom-score-adj ${OT_OOM_SCORE_ADJ:-500} -e LEC_CHECK=0 -e OT_IOREF_INPUT_PF -e OT_ABC_NO_DCH -e OT_HOLD_STOP -e OT_SLIVER_BLOCK -e OT_EDGE_SLIVER_UM -e OT_CTS_MACRO_CLUSTER -e OT_CTS_MACRO_SIZE -e OT_CTS_MACRO_DIAM "$@"; fi
    exec "$e/docker" "$@"
  fi
done
echo "closure-loop docker shim: no docker on PATH" >&2; exit 127
"""


def docker_lec_off(cl):
    return (f"mkdir -p {cl}/bin && cat > {cl}/bin/docker <<'OT_DOCKER_SHIM'\n{DOCKER_SHIM}OT_DOCKER_SHIM\n"
            f"chmod +x {cl}/bin/docker\nexport PATH={cl}/bin:$PATH\n")


def route_corner(j):
    """the corner a job's route stage repairs setup at: spec route_corner (default TC after option B), or for a "keep"
    recipe its own OT_ORFS_CORNER(_OVERRIDE)=... in the route command, else WC (SS)"""
    rc = j["spec"].get("route_corner", "TC") if (j.get("created") or now_iso()) >= OPTB_SINCE else "keep"
    if rc != "keep":
        return str(rc).upper()
    stages = j["spec"].get("stages")
    cmd = str(((stages or {}).get("route") or {}).get("cmd", "")) if isinstance(stages, dict) else ""
    m = re.search(r"OT_ORFS_CORNER(?:_OVERRIDE)?=['\"]?(\w+)", cmd)
    return m.group(1).upper() if m else "WC"


def route_ref(j):
    """'TT' when the job's route-time IO SDC references the TT (route-corner) insertion (CALIB-CORNER), else None"""
    if (j.get("created") or "") < ROUTE_REF_SINCE or j["spec"].get("route_ref") == "SS":
        return None
    return "TT" if route_corner(j) in ("TC", "TT") else None


# REBUDGET 2026-10-08 (tools/budgets/rebudget.py): new routes use the LATEST re-derived die-link IO budget of their block.
# rebudget.py derive publishes STATE/rebudget/current.json {blocks: {block: {rb, sdc}}}; a calibrate / route stage
# installs that SDC as {SRC}/physical/common_flow/rebudget_block.sdc and makes sure the snapshot's
# link_budget_consistent.sdc sources it last (older snapshots predate the hook).  Spec "rebudget": false opts out.
REBUDGET_CURRENT = STATE / "rebudget" / "current.json"
REBUDGET_HOOK = ("\n# REBUDGET hook (closure loop): the block's re-derived per-port die-link budget, installed beside this file\n"
                 "set ot_rb_hook [file join [file dirname [info script]] rebudget_block.sdc]\n"
                 "if {[file exists $ot_rb_hook]} { puts \"OT_REBUDGET hook $ot_rb_hook\"; source $ot_rb_hook }\n")


def install_rebudget(j):
    if j["spec"].get("rebudget") is False or not REBUDGET_CURRENT.exists():
        return
    try:
        cur = json.loads(REBUDGET_CURRENT.read_text())["blocks"].get(j["spec"].get("block"))
    except (OSError, ValueError, KeyError):
        return
    if not cur or not Path(cur.get("sdc", "")).is_file():
        return
    d = f"{j['run']}/src/physical/common_flow"
    r = ssh(j["host"], f"mkdir -p {d} && cat > {d}/rebudget_block.sdc", input=Path(cur["sdc"]).read_text(), timeout=60)
    if r.returncode:
        return
    ssh(j["host"], f"f={d}/link_budget_consistent.sdc; [ -f $f ] && ! grep -q 'REBUDGET hook' $f && cat >> $f", input=REBUDGET_HOOK,
        timeout=60)
    if j.get("rebudget_route") != cur["rb"]:
        j["rebudget_route"] = cur["rb"]
        event(j, f"route IO budget: {cur['rb']} (re-derived die-link budget of {j['spec'].get('block')}) installed as "
                 f"rebudget_block.sdc, sourced by link_budget_consistent.sdc")


# FP-LINT (owner 2026-10-08): floorplan margin lint before global placement, on by default for calibrate and route.
# tools/orfs_hold_mm.py (run in every run_abi3_physical flow container) hooks ORFS PRE GLOBAL_PLACE; the docker shim
# passes OT_FP_LINT and mounts {CL}/fplint/<tag> at /ot_fplint; a failing floorplan writes FAIL there and stops the
# flow, and crash() / cal_track() finish the job with verdict FLOORPLAN_MARGIN (no retry, no route spent).
# Spec "fp_lint": false opts out; {"set": {"util_max": 0.62, ...}} overrides thresholds (tools/fp_margin_lint.py
# THRESHOLDS); {"warn_only": true} reports without failing.
def gate_args(cfg):
    cfg = cfg if isinstance(cfg, dict) else {}
    args = " ".join(f"--set {k}={v}" for k, v in (cfg.get("set") or {}).items())
    if cfg.get("warn_only"):
        args += " --warn-only"
    return args.strip()


# PREROUTE-GATE (owner 2026-10-08): the pre-route timing gate (tools/preroute_gate.tcl/.py) runs at ORFS POST
# DETAIL_PLACE of a ROUTE stage (never a calibrate) and stops a variant whose placed design is far from closing before
# CTS / GRT / DRT are spent.  The owner allows it only because it is fast: measured 2026-10-08 on the fleet's finished
# routes (preroute-gate.log), the in-flow cost is the path dump alone (timing is already updated by report_metrics), a
# few seconds against routes of hours.  On by default; spec "preroute_gate": false opts out; {"set": {"ws_ps": ...,
# "count": ...}} overrides thresholds (tools/preroute_gate.py THRESHOLDS, calibrated to never reject an eventual closure).
def preroute_gate_on(j, kind):
    return kind == "route" and j["spec"].get("preroute_gate", True) is not False


# drive-2155 2026-10-08: recipes that run the FLOW-HOLD snapshot's hold_corners_patch.py ({FH}/tools/closure_loop, 164
# jobs: every hbm view / vm8 recipe) re-copy {FH}/tools/orfs_hold_mm.{py,tcl} over the helpers shipped here ("always
# refresh").  The FH copy of orfs_hold_mm.py was the pre-guard generation, so those routes ran without the hold-stall
# guard, the HM guard and MET-FIRST.  The FH h1_patch.py / hold_corners_patch.py those recipes run were stale too (no
# h1-audit families: fh_quad / head ioreg / BF / hbglue / attn_tile_r kept the receiver hold term; no TC / CTS-only
# calibrate code).  ship_fpl refreshes the FH snapshots on the launch host (tmp + mv: atomic for a concurrent reader).
FH_DIRS = ("/srv/opentallas-scratch/claude/flowhold/src", "/home/ubuntu/closure-loop-local/flowhold/src")
FH_FILES = (("orfs_hold_mm.py", "tools"), ("orfs_hold_mm.tcl", "tools"), ("h1_patch.py", "tools/closure_loop"),
            ("hold_corners_patch.py", "tools/closure_loop"))
# drive-2155 2026-10-09: the TT-batch overlay snapshot (26f14af32, 635 jobs) has the same failure: tt_overlay.py force-copies
# its physical/common_flow files over the job's source, so even new-commit routes got link_budget_consistent.sdc WITHOUT
# the rebudget hook (budget_rb never applied) and cg_pushdown.tcl without the BF HALF_PHL exclusion, plus a pre-audit
# h1_patch.py.  Every main-vs-snapshot difference is an additive flow fix already on main, so the same refresh applies.
TTB_DIRS = ("/srv/opentallas-scratch/claude/ttbatch/26f14af32", "/home/ubuntu/closure-loop-local/ttbatch/26f14af32")
TTB_FILES = (("tt_overlay.py", "tools/closure_loop"), ("h1_patch.py", "tools/closure_loop"),
             *((n, "physical/common_flow") for n in ("cg_pushdown.tcl", "clk_net_protect.tcl", "link_budget_hook.tcl",
                                                    "link_budget_consistent.sdc", "nbr_clk_measured_ttb.sdc")))
SNAPSHOT_REFRESH = ((FH_DIRS, FH_FILES), (TTB_DIRS, TTB_FILES))


def _snapshot_main_sha(name):
    """sha256 of the bytes the daemon ships for helper basename `name` now (origin/main resolution), or None"""
    helper = next((h for h in HELPERS if Path(h).name == name), None)
    if helper is None:
        return None
    try:
        return hashlib.sha256(overlay_helper_bytes(helper)).hexdigest()
    except Exception:  # noqa: BLE001
        return None


def snapshot_refresh_sh(run):
    """shell: refresh every frozen flow snapshot's copies from the helpers just shipped to {run}/cl (tmp + mv).
    SNAPSHOT-MAIN-ONLY (ROOT 2026-10-16): a copy is refreshed only when {run}/cl/<f> has the sha256 of the bytes the
    daemon ships from origin/main NOW.  A frozen job (verified original / reinstalled / bench relocation) carries its
    gate-time helpers in cl/, and the old unconditional copy would have pushed e.g. tt_overlay ba24e51 (deletes
    GRT183_HOOK) back over the fleet snapshot every route runs (tt_overlay_fallback is fleet-first)."""
    out = ""
    for dirs, files in SNAPSHOT_REFRESH:
        for f, d in files:
            sha = _snapshot_main_sha(f)
            if not sha:
                continue
            out += (f"for fh in {' '.join(dirs)}; do t=$fh/{d}; [ -f {run}/cl/{f} ] && [ -d $t ] && "
                    f"[ \"$(sha256sum < {run}/cl/{f} | cut -c1-64)\" = {sha} ] && ! cmp -s {run}/cl/{f} $t/{f} && "
                    f"cp -f {run}/cl/{f} $t/.{f}.$$ && mv -f $t/.{f}.$$ $t/{f}; done; ")
    return out


def fp_lint_env(j, t, lint=True, prg=False):
    run, d = j["run"], f"{j['run']}/cl/fplint/{t}"
    env = (f"ship_fpl() {{ for f in fp_margin_lint.py fp_margin_lint.tcl orfs_hold_mm.py orfs_hold_mm.tcl "
           f"preroute_gate.py preroute_gate.tcl textbook_lint.py; do "
           f"[ -f {run}/cl/$f ] && [ -d {run}/src/tools ] && cp -f {run}/cl/$f {run}/src/tools/$f; done; "
           f"{snapshot_refresh_sh(run)}true; }}\nship_fpl\n"
           f"rm -rf {d} && mkdir -p {d} && chmod a+rwx {d}\nexport OT_FP_LINT_DIR={d}\n"
           f"printf '%s\\n' {shlex.quote(json.dumps(textbook_cfg(j)))} > {d}/textbook_cfg.json\n")
    if lint:
        env += (f"export OT_FP_LINT=1 OT_FP_LINT_DIR={d} "
                f"OT_FP_LINT_ARGS={shlex.quote(gate_args(j['spec'].get('fp_lint', True)))}\n")
    if prg:
        env += (f"export OT_PREROUTE_GATE=1 "
                f"OT_PREROUTE_GATE_ARGS={shlex.quote(gate_args(j['spec'].get('preroute_gate', True)))}\n")
    return env


# TEXTBOOK-LINT (owner 2026-10-11, tools/textbook_lint.py): classic unclosable structures (clock root size, high fanout,
# unregistered boundaries, logic depth, wire reach, util / channels) checked on the synthesis netlist + floorplan inside
# the floorplan-lint hook (fp_margin_lint.tcl ot_textbook_lint, ORFS PRE GLOBAL_PLACE).  Config per stage in
# {CL}/fplint/<tag>/textbook_cfg.json (mounted /ot_fplint): mode from spec "textbook_lint" (false = off, {"mode",
# "set", "waive"}), else STATE/textbook_lint.json {"mode": "warn"|"refuse", "refuse_checks": [...]} (main flips it to
# refuse without a restart), else WARN.  WARN: the lines are logged to the job events + daemon log (textbook_note);
# REFUSE: the hook writes FAIL "FLOORPLAN_MARGIN: textbook_lint: ..." and the job finishes FLOORPLAN_MARGIN as for the
# floorplan lint (no placement / route spent).
TEXTBOOK_NOTE_S = 600


def textbook_cfg(j):
    try:
        cfg = json.loads((STATE / "textbook_lint.json").read_text())
    except (OSError, ValueError):
        cfg = {}
    cfg = {"mode": cfg.get("mode", "warn"), **({"refuse_checks": cfg["refuse_checks"]} if cfg.get("refuse_checks") else {})}
    sp = j["spec"].get("textbook_lint", True)
    if sp is False:
        cfg["mode"] = "off"
    elif isinstance(sp, dict):
        cfg.update({k: sp[k] for k in ("mode", "set", "waive", "refuse_checks") if k in sp})
    cr = j.get("clock_rule")
    if isinstance(cr, dict):     # measured clock rule: only jobs ingested under it (never an older in-flight job)
        cfg["clock"] = {"enforce": cr.get("mode") == "refuse" and bool(j["spec"].get("ref_tile")),
                        "evidence": cr.get("evidence"), "closed_stands": bool(cr.get("closed_stands"))}
        if isinstance(j["spec"].get("clock_rule_waiver"), dict):   # HANDOFF 0ga: the gate's recorded per-pair waiver
            cfg["clock"]["waiver"] = j["spec"]["clock_rule_waiver"]
    # GATE-FRICTION 2026-10-18: the kit's declared reset_ports are resets for the in-flow lint too (por_n on KV core_peer)
    rsts = j.get("kit_reset_ports")
    if rsts is None and j["spec"].get("ref_tile") and j.get("commit_full"):
        m = PORT_LATENCY_RE.search(((j["spec"].get("stages") or {}).get("route") or {}).get("cmd") or "")
        rsts = []
        if m:
            try:
                ks = json.loads(git("show", f"{j['commit_full']}:{m.group(1)}/spec.json", check=False).stdout or "{}")
                rsts = [x for x in ks.get("reset_ports") or [] if isinstance(x, str)]
            except (ValueError, AttributeError):
                rsts = []
        j["kit_reset_ports"] = rsts
    if rsts and not (cfg.get("set") or {}).get("reset_ports"):
        cfg["set"] = dict(cfg.get("set") or {}, reset_ports=",".join(rsts))
    return cfg


def textbook_note(j, force=False):
    """log the in-flow textbook lint's result for the current stage once (job event + daemon log)"""
    tag_ = j.get("stage_tag")
    if not tag_ or not j.get("host") or not j.get("run"):
        return
    seen = j.setdefault("textbook_seen", {})
    if tag_ in seen or (not force and time.time() - j.get("textbook_checked", 0) < TEXTBOOK_NOTE_S):
        return
    j["textbook_checked"] = time.time()
    try:
        r = ssh(j["host"], f"cat {j['run']}/cl/fplint/{tag_}/TEXTBOOK 2>/dev/null", timeout=60)
    except Exception:  # noqa: BLE001
        return
    lines = [l for l in (r.stdout or "").splitlines() if l.startswith(("textbook_lint:", "TEXTBOOK_LINT:"))]
    if r.returncode or not lines:
        return
    seen[tag_] = lines[0][len("textbook_lint: "):][:120]
    j["textbook_lint"] = {"tag": tag_, "lines": lines[:12]}
    head = lines[0]
    if len(lines) > 1:
        event(j, f"TEXTBOOK-LINT {tag_}: {head[15:200]} || " + " || ".join(l[15:400] for l in lines[1:8])[:1800])
    else:
        event(j, f"TEXTBOOK-LINT {tag_}: {head[15:300]}")


def fp_lint_failed(host, run, tag):
    """the lint's FAIL text for stage tag (None: no lint failure, or the host could not be read)"""
    try:
        r = ssh(host, f"cat {run}/cl/fplint/{tag}/FAIL 2>/dev/null", timeout=60)
    except Exception:  # noqa: BLE001
        return None
    return r.stdout.strip() if r.returncode == 0 and "FLOORPLAN_MARGIN" in (r.stdout or "") else None


def preroute_failed(host, run, tag):
    """the pre-route gate's FAIL text for stage tag (None: no gate failure, or the host could not be read)"""
    try:
        r = ssh(host, f"cat {run}/cl/fplint/{tag}/PREROUTE_FAIL 2>/dev/null", timeout=60)
    except Exception:  # noqa: BLE001
        return None
    return r.stdout.strip() if r.returncode == 0 and "PREROUTE_MARGIN" in (r.stdout or "") else None


def preroute_finish(j, tag, text):
    reasons = next((l[len("PREROUTE_MARGIN: "):] for l in text.splitlines() if l.startswith("PREROUTE_MARGIN: ")), text)
    kill_own_stage(j)
    finish(j, "PREROUTE_MARGIN", reasons[:600],
           f"PREROUTE_MARGIN ({tag}): the placed design failed the pre-route timing gate (no CTS/route spent; report "
           f"{j['run']}/cl/fplint/{tag}/preroute_gate.json)\n" +
           "\n".join(l for l in text.splitlines() if l.startswith("preroute_gate:"))[:1500] +
           "\nFIX: the placed slack is far beyond what routing has ever recovered: pipeline / restructure the worst "
           "paths (REDESIGN_RULES); spec preroute_gate:false opts out, {\"set\": {\"ws_ps\": ...}} overrides")


def fp_lint_finish(j, tag, text):
    reasons = next((l[len("FLOORPLAN_MARGIN: "):] for l in text.splitlines() if l.startswith("FLOORPLAN_MARGIN: ")), text)
    try:                       # lint-at-submit: the measured area predicts the next job of the same synthesis input
        rec = submit_lint.util_record(j.get("spec_submitted", j["spec"]), reasons, submit_lint.Git(REPO), j["name"])
        if rec:
            util_db_add(*rec)
    except Exception:  # noqa: BLE001
        pass
    kill_own_stage(j)          # a parallel calibrate / route of the same floorplan stops too
    finish(j, "FLOORPLAN_MARGIN", reasons[:600],
           f"FLOORPLAN_MARGIN ({tag}): the floorplan failed the margin lint before global placement (no route spent; "
           f"report {j['run']}/cl/fplint/{tag}/fp_margin_lint.json)\n" +
           "\n".join(l for l in text.splitlines() if l.startswith("fp_margin_lint:"))[:1500] +
           "\nFIX (REDESIGN_RULES 'floorplan margin targets'): <= 55-60% util, <= 6 bits/um/layer, PDN-clear pin "
           "columns, channels sized to the crossing nets; spec fp_lint:false opts out" +
           ("\nTEXTBOOK: the textbook lint refused a classic unclosable structure (report "
            f"{j['run']}/cl/fplint/{tag}/textbook_lint.json; tools/closure_loop/README.md 'Textbook lint'): restructure "
            "it; spec textbook_lint: {\"waive\": [\"<check>\"]} waives one check" if "textbook_lint" in reasons else ""))


# MEM-CAP (drive-0849 2026-10-09, coordinator URGENT "die routes SIGKILLed"): both full-die Qwen r22k GRTs (EPYC3
# 18:54, EPYC1 21:49 PDT, openroad ~123 GB) were killed by the HOST OOM killer, not by stuckscan: a loop route declaring
# peak_ram_gb 40 (hbm_svc_SE_s3_ps_79af6ba23_tc_hm0-cl) ran yosys to 154 then 208 GB on EPYC1, and admission had
# reserved 40.  A global OOM then kills the LARGEST process -- the die run.  Every loop flow container now runs in a
# memory cgroup of max(MEM_CAP_FACTOR x declared, declared + MEM_CAP_SLACK_GB): an overrun kills only its own stage
# (the loop sees a flow error / crash retry), never a neighbour.  Spec "mem_cap_gb" overrides (0 = no cap).
MEM_CAP_FACTOR = 4
STAGE_OOM_SCORE_ADJ = 500
# FLEET-OOM (2026-10-18): bench and route stages run at oom_score_adj 0.  At 500 (plus earlyoom's --prefer vvp|python3)
# a 9 MiB bench vvp or a route's python3 scored 1300 against 1024 for a 112 GB cc1plus at 3 % free, so earlyoom killed
# 34 small loop stages on 10-18 and the over-declared build kept growing.  Over-declared builds are raised by the runner
# instead (RUNNER (b)); the other stage kinds keep 500.
# ROOT-1130: the post-route stages of a CLOSED route (collect / export / ECO install) too -- earlyoom SIGTERMed the 31-MB
# collect export of dsdv_sh_lk-ef442ffba at adj 500 (rc 143) while a ~93 GB agent cc1plus kept running.
STAGE_OOM_SCORE_ADJ_KIND = {"bench": 0, "route": 0, "collect": 0, "export": 0, "eco_install": 0}


def stage_oom_score_adj(kind):
    return STAGE_OOM_SCORE_ADJ_KIND.get(kind, STAGE_OOM_SCORE_ADJ)
MEM_CAP_SLACK_GB = 96


def stage_mem_cap(j, st):
    if "mem_cap_gb" in j["spec"]:
        return int(j["spec"]["mem_cap_gb"] or 0)
    ram = int(st.get("ram") or j["spec"].get("peak_ram_gb", 32))
    return max(MEM_CAP_FACTOR * ram, ram + MEM_CAP_SLACK_GB)


# Bench source copy (el1013-fleet3 2026-10-13): 'cp -a --reflink=auto' of {run}/src was a FULL second copy on the ext4
# run roots (no reflink): 4.9 GB and ~25 s per job at main, 4.0 GB of it closed .lib/.lef views.  Files that mirror_sync
# hard-linked from the host view store (0444, link count > 1) are hard-linked into the private copy as well; everything
# else is copied as before.  Benches build inside the private tree and never rewrite a closed view; one that tries gets
# EACCES instead of silently changing every other job's view.  A src without store links is copied whole, as before.
_VIEW_FIND = r"-type f -links +1 -perm 444 \( -name '*.lib' -o -name '*.lef' \)"


def bench_copy_script(original, private):
    """shell lines making {private} from {original} under a lock (both already shell-quoted)"""
    return (f"exec 9>{private}.lock || exit $?\nflock 9 || exit $?\n"
            f"if [ ! -d {private} ]; then\n"
            f"  rm -rf {private}.tmp\n"
            f"  if [ -n \"$(cd {original} && find . {_VIEW_FIND} -print -quit)\" ]; then\n"
            f"    mkdir {private}.tmp || exit $?\n"
            f"    ( cd {original} && find . ! \\( {_VIEW_FIND} \\) -print0 | tar --null --no-recursion -T - -cf - ) | "
            f"tar -xf - -C {private}.tmp || exit $?\n"
            f"    ( cd {original} && find . {_VIEW_FIND} -print0 | xargs -0 -r sh -c "
            f"'cp -al --parents -t \"$0\" \"$@\" 2>/dev/null || cp -a --parents -t \"$0\" \"$@\"' {private}.tmp ) || exit $?\n"
            f"  else\n"
            f"    cp -a --reflink=auto {original} {private}.tmp || exit $?\n"
            f"  fi\n"
            f"  mv {private}.tmp {private} || exit $?\nfi\n"
            f"flock -u 9; exec 9>&-\n"
            f"cd {private} || exit $?\n")


def launch_stage(j, st, cmd):
    if st["kind"] == "route" and (j.get("eco") or j.get("eco_history") or j.get("eco_stack")):
        retire_eco_for_reroute(j)       # LOST-CLOSED (ROOT-1130): a new route is never judged by the old route's ECO
    if st["kind"] in ("route", "calibrate"):
        j["route_attempt"] = j["attempt"]
    t = tag(st, j)
    rebound = None
    if st["kind"] == "bench":
        # Mutation benches must never write the route's source tree. One private
        # tree per job attempt retains generated inputs shared by bench stages.
        j["stage_source"] = f"{j['run']}/bench_src_a{str(j['attempt']).split('b')[0]}"
        if j.get("bench_rebind"):
            from bench_rebind import source_for_stage
            rebound = source_for_stage(j, st["key"])
            if rebound:
                j["stage_source"] = rebound["source_path"]
    else:
        j.pop("stage_source", None)
    env = "".join(f"export {k}={shlex.quote(v)}\n" for k, v in dict(
        RUN=j["run"], SRC=j.get("stage_source", f"{j['run']}/src"), CL=f"{j['run']}/cl", HOST=j["host"], NAME=label(j["name"]),
        LABEL=label(j["name"]), RAW_NAME=j["name"],
        BLOCK=j["spec"]["block"], COMMIT=rebound["source_commit"] if rebound else j["commit_full"], THREADS=str(st.get("threads", 4)),
        CL_PHASE=st["kind"], CL_LABEL_SUFFIX="_cal" if st["kind"] == "calibrate" else "",
        CL_STOP_AFTER="--pnr-stop-after cts" if st["kind"] == "calibrate" else "").items())
    # OOM-FIRST (drive-0849 2026-10-09): synth runs NATIVELY (host yosys, outside any container cgroup) -- the 208 GB
    # yosys that took the EPYC1 die GRT was one.  Every loop stage raises its own oom_score_adj (inherited by its
    # children; non-root may raise it) so a host OOM picks a loop stage, never a die run (-900) or an interactive job.
    env += f"echo {stage_oom_score_adj(st['kind'])} > /proc/self/oom_score_adj 2>/dev/null || true\n"
    if st["kind"] == "bench":
        # Benches use the fleet's pinned tools (Verilator 5.050, yosys 0.68), the same ones every agent gate runs
        # under. The non-login ssh PATH picked Debian /usr/bin/verilator 5.032, so loop benches disagreed with the
        # gates (s81vm-*-e66305b64: gold_s1 PASS under 5.050, FAIL under 5.032 on identical sources).
        env += ('for _d in "$HOME/.local/opentallas-tools/verilator-5.050/bin" "$HOME/.local/opentallas-tools/yosys-0.68/bin"; '
                'do [ -d "$_d" ] && export PATH="$_d:$PATH"; done\n')
    if st["kind"] != "bench" and j["spec"].get("ref_tile"):
        # LOOP-CHILD-LINT (2026-10-12): ref_tile.py export (collect / hold-ECO re-export) imports child_lint from the job's
        # synced src, so a job synced before a child_lint fix (888b49460 EDGE_INSET_UM: thin tiles' edge-inset PG stripes)
        # kept failing export on a lint bug, and every retry re-synced the old commit.  The lint is the loop's gate, not
        # the design: run the loop's own child_lint (CHILD_LINT_DIR, shipped to {CL}); the job's views stay the input.
        ship_helpers(j["host"], j["run"], j)
        _src = j.get("stage_source", f"{j['run']}/src")
        env += (f"[ -f {_src}/tools/hier_contract/child_lint.py ] && ! [ -f {_src}/tools/hier_contract/child_lint.py.job ] && "
                f"cp {_src}/tools/hier_contract/child_lint.py {_src}/tools/hier_contract/child_lint.py.job; "
                f"cp -f {j['run']}/cl/child_lint.py {_src}/tools/hier_contract/child_lint.py; "
                f"cp -f {j['run']}/cl/m6_pin_grant.py {_src}/tools/hier_contract/m6_pin_grant.py\n")
        # LOOP-PIN-STUB (2026-10-12): the loop's child_lint (ba4d5d136) refuses a pin's own same-layer route stub written as
        # OBS; ref_tile export runs abstract_pin_stub.py on the view before the lint, but only from ba4d5d136 on.  A job
        # synced earlier got the new lint WITHOUT the view fix (smh_fcbc_ref_p40-r1-9214bae8b: 10 stub pins, collect
        # crashed twice on a route that closed).  The fix and the lint travel together: ship abstract_pin_stub.py (it also
        # writes atomically now: the exported LEF is root-owned) and add the pre-lint call to a stale ref_tile.py export.
        env += (f"cp -f {j['run']}/cl/abstract_pin_stub.py {_src}/tools/hier_contract/abstract_pin_stub.py; "
                f"python3 - {_src}/tools/ref_tile/ref_tile.py <<'OT_PINSTUB_PATCH' || true\n{PINSTUB_PATCH}OT_PINSTUB_PATCH\n")
        # LOOP-SCALAR-LINT (AHUB-COLLECT 2026-10-18): ref_tile.py export runs scalar_pin_lint from the job's synced
        # tools/ref_tile/scalar_pin_view.py.  Its port parser is the loop's publish gate, not the design: a job synced
        # before 9ac83ae74 ((* keep *) attribute hid a port's range) kept refusing bus bits as RTL-scalar at every collect
        # (qkd_ahub_core-hd4-ed40aa340: TT +219.7 / FF +20.2 route, collect crashed 4x on pb_ra[0]/pl_rz[0]/pl_v[0]).
        # Every ref_tile collect / re-export runs the loop's copy (resolved against origin/main, as the helper overlay).
        _spv_rel = "tools/ref_tile/scalar_pin_view.py"
        try:
            _spv, _ = HO.resolve_bytes(HERE.parents[1], REPO, _spv_rel, _ovl_head(), cache=_OVL["hist"])
        except (OSError, subprocess.SubprocessError):
            _spv = None
        if _spv:
            import base64 as _b64
            env += (f"if [ -f {_src}/{_spv_rel} ]; then [ -f {_src}/{_spv_rel}.job ] || cp {_src}/{_spv_rel} "
                    f"{_src}/{_spv_rel}.job; base64 -d > {_src}/{_spv_rel}.loop <<'OT_SPV_B64' && "
                    f"mv -f {_src}/{_spv_rel}.loop {_src}/{_spv_rel}\n{_b64.b64encode(_spv).decode()}\nOT_SPV_B64\nfi\n")
        # EXPORT-SDC (2026-10-13): the view export replays the VERDICT's constraint sequence (routed 6_final.sdc, SPEF,
        # post-SDCs, io_ref_routed.sdc) and fails on a slack that differs from the verdict; a job's synced view_export.py
        # read the kit signoff.sdc INSTEAD of the routed SDC (s81su SMT: FF -19.69 exported vs +3.66 verdict).  The
        # export is the loop's publish step, not the design: every ref_tile collect / re-export runs the loop's copy.
        env += (f"[ -d {_src}/tools/tt_views ] && cp -f {j['run']}/cl/view_export.py {_src}/tools/tt_views/view_export.py; true\n")
        # GRT-TOP-RESTORE (2026-10-12): grt_macro_top_layer.tcl (d36d0b234) left the block's max routing layer at MAX+1 in
        # 5_1_grt.odb, so DRT routed M6 under the M5 cap (hgi_topk_heap_rt_m5-h3m5-6d8d554ba: 190 um M6, child_lint (c)
        # FAIL at collect).  Jobs synced before the fix get the fixed hook + its POST_GLOBAL_ROUTE restore.
        env += (f"[ -f {_src}/physical/common_flow/grt_macro_top_layer.tcl ] && for f in grt_macro_top_layer.tcl "
                f"grt_macro_top_layer_post.tcl; do cp -f {j['run']}/cl/$f {_src}/physical/common_flow/$f; done; true\n")
    if st["kind"] != "bench":
        env += docker_lec_off(f"{j['run']}/cl")
        cap = stage_mem_cap(j, st)
        if cap:
            env += f"export OT_MEM_CAP_GB={cap}\n"
    fpl = st["kind"] in ("calibrate", "route") and j["spec"].get("fp_lint", True) is not False
    prg = preroute_gate_on(j, st["kind"])
    if fpl or prg:
        ship_helpers(j["host"], j["run"], j)
        env += fp_lint_env(j, t, lint=fpl, prg=prg)
    if st["kind"] == "calibrate":
        # UNSTICK (owner 2026-10-08): calibrate measures clock insertion only.  No CTS timing/hold repair
        # (SKIP_CTS_REPAIR_TIMING=1 through hold_corners_patch.py OT_CAL_CTS_ONLY): 40 calibrates sat 4-25 h in CTS hold
        # repair (mm, HM 50) measuring nothing.  Applied to every calibrate, whatever its route_hold_corners.
        ship_helpers(j["host"], j["run"], j)
        env += f"export OT_CAL_CTS_ONLY=1\npython3 {j['run']}/cl/hold_corners_patch.py {j['run']}/src\n"
        if route_ref(j):
            # CALIB-CORNER: CTS at the route corner, insertion referenced to it (ck_insertion.py --route-corner)
            env += f"export OT_ORFS_CORNER={shlex.quote(route_corner(j))}\nexport OT_CAL_ROUTE_CORNER={shlex.quote(route_corner(j))}\n"
    if st["kind"] in ("calibrate", "route"):
        install_rebudget(j)
        if j["spec"].get("pinflop_ref", True) is not False:
            # PINFLOP-REF (drive-0849 2026-10-10): route-time IO reference = median input pin flop when no / an unmatched
            # REFGLOB names one (main 6cd79a9f8); overlaid on the snapshot so requeues of older commits get it too
            ship_helpers(j["host"], j["run"], j)
            env += (f"python3 {j['run']}/cl/pinflop_overlay.py {j.get('stage_source', j['run'] + '/src')} "
                    f"{j['run']}/cl/pinflop_ref.tcl || true\n")
            # PINFLOP-INPUT (drive-0849 2026-10-10): the route-time FF hold scene's io_ref_routed.sdc re-references the
            # INPUT delays to the input pin flops' mean arrival (route_mtp / hbm_accel_smh / dsrom qs / markov-driver
            # recipes); the verdict re-STA and ECO sessions never see this variable
            env += "export OT_IOREF_INPUT_PF=1\n"
            j["pinflop_ref_applied"] = True       # LOOP-AUTO class c: this job's route used the pin-flop reference
        if j["spec"].get("macro_cts") is False:
            # MACRO-CLK (macro-clk-1010 2026-10-10): the macro clock clustering default (physical/common_flow/
            # macro_cts_cluster.tcl via tools/orfs_hold_mm.tcl) is on for every block with 2+ clocked macros; spec
            # "macro_cts": false keeps TritonCTS's own macro clustering
            env += "export OT_CTS_MACRO_CLUSTER=0\n"
        if j["spec"].get("sliver_block"):
            # LOOP-AUTO class d (auto-react successor of a sliver-only FLOORPLAN_MARGIN): the macro-to-macro and
            # macro-to-core-edge sliver hard placement blockages run at ORFS PRE GLOBAL_PLACE, before the floorplan lint
            # (tools/orfs_hold_mm.py SLV_CODE); main's hook scripts are shipped into snapshots that predate them
            ship_helpers(j["host"], j["run"], j)
            sdir = f"{j.get('stage_source', j['run'] + '/src')}/physical/common_flow"
            env += (f"mkdir -p {sdir} && for f in macro_sliver_block.tcl edge_sliver_block.tcl; do "
                    f"[ -f {sdir}/$f ] || cp {j['run']}/cl/$f {sdir}/$f; done\nexport OT_SLIVER_BLOCK=1\n")
    if st["kind"] in ("calibrate", "route") and j.get("created", "") >= HM_DEFAULT_SINCE:
        # default route hold margin (coordinator 2026-10-06: hold-only misses dominate; ctrl_ctr closed at HM 35 ps);
        # route_view.sh reads HM in ns; an inline HM=... in the command, or spec route_hold_margin_ns, overrides it
        # coordinator 2026-10-07: jobs created from HM_LOW_SINCE default to 10 ps -- 35 ps + the 50 ps FF IO hold
        # uncertainty overloaded CTS/GRT hold repair (RSZ-0060 buffer-cap deaths, hours-long GRT hold); the post-route
        # hold ECO (rev 2: setup-preserving) carries hold to +18.  Earlier jobs keep 35 ps (same flow on a retry).
        hm_default = 0.010 if j.get("created", "") >= HM_LOW_SINCE else 0.035
        if j.get("created", "") >= MM_SINCE and j["spec"].get("route_hold_corners", "mm") == "mm":
            hm_default = HM_MM
        env += f"export HM={j['spec'].get('route_hold_margin_ns', hm_default)}\n"
    if is_local(j["host"]):
        env += f"export OPENTALLAS_ORFS_IMAGE={LOCAL_ORFS_REF}\n"
    # bench-track views carry a string attempt ("1b2"): their outputs are not the stage dir, never move them aside
    if isinstance(j["attempt"], int) and j["attempt"] > 1 and not j.get("resume"):
        env += retry_aside(j, st)
    if st["kind"] == "route" and route_ref(j):
        fixed = sorted(set(re.findall(r"io_vclk_m_\d+\.sdc", cmd)))
        if fixed:
            log(f"{j['name']}: CALIB-CORNER WARNING route cmd names fixed IO SDC(s) {', '.join(fixed)}: not referenced to "
                f"the TT insertion (generate them from $CK_SS_MEAN in sdc_cmd)")
    if st["kind"] == "route" and now_iso() >= OPTB_SINCE and j["spec"].get("route_corner", "TC") != "keep":
        env += f"export OT_ORFS_CORNER={shlex.quote(str(j['spec'].get('route_corner', 'TC')))}\n"
    if st["kind"] in ("calibrate", "route"):
        # (calibrate too, 2026-10-07: its CTS-only run repairs hold at CTS and died on RSZ-0060, hbm_stn_r38 / _ck80)
        # ROUTE HOLD CORNERS (2026-10-07, hold_corners_patch.py): place-and-route repairs hold at the primary corner only
        # -- the route SDC's virtual IO clock sits at the SS insertion, so BC showed fake IO hold violations of about the
        # SS-FF insertion difference (thousands of flow hold buffers); FF hold goes to the post-route hold ECO.  Spec
        # "route_hold_corners": "keep" leaves the recipe's own --hold-corners; any other value is passed through.
        # FLOW-HOLD (2026-10-07): jobs created from MM_SINCE default to "mm" -- route-time repair in a multi-mode session,
        # scene WC (SS libs, the route SDC: setup) + scene BC (FF libs, the route SDC refreshed + the FF sign-off SDCs:
        # hold), tools/orfs_hold_mm.tcl.  The FF SDCs are spec "route_ff_sdc" (list), else verdict.post_sdc; a file outside
        # the snapshot is copied into {SRC}/.ot_mm/ (the flow container mounts only the snapshot).
        rhc = j["spec"].get("route_hold_corners", "mm" if j.get("created", "") >= MM_SINCE else "primary")
        if rhc != "keep":
            ship_helpers(j["host"], j["run"], j)
            env += f"export OT_ROUTE_HOLD_CORNERS={shlex.quote(str(rhc))}\n" \
                   f"python3 {j['run']}/cl/hold_corners_patch.py {j['run']}/src\n"
        if rhc == "mm":
            ff = j["spec"].get("route_ff_sdc")
            if ff is None:
                ff = (j["spec"].get("verdict") or {}).get("post_sdc") or []
            # {NAME}/{LABEL} name the recipe's generated sign-off SDC (route_cl.sh <label>); the calibrate stage runs the
            # recipe on {LABEL}${CL_LABEL_SUFFIX}, so its SDC carries _cal.  Before 2026-10-08 any path with "{" was
            # DROPPED, so the FF scene silently timed the route SDC (vclk at the SS insertion: ~-200 ps output hold,
            # RSZ-0060; tt-fix.log F2).  Paths still holding an unknown placeholder after substitution are dropped loudly.
            sfx = "_cal" if st["kind"] == "calibrate" and "CL_LABEL_SUFFIX" in cmd else ""
            ff_sub = []
            for f in ([ff] if isinstance(ff, str) else ff):
                if not f:
                    continue
                f = subst(f.replace("{NAME}", label(j["name"]) + sfx).replace("{LABEL}", label(j["name"]) + sfx), j)
                if "{" in f:
                    log(f"{j['name']}: route FF SDC {f} has an unknown placeholder: dropped")
                    continue
                ff_sub.append(f)
            ff = ff_sub
            # VM8-TIMING 2026-10-08: the FF hold scene also reads io_ref_routed.sdc LAST (the shipped helper copy in {CL}),
            # so route-time FF hold repair targets the MEAN boundary insertion of the tree being built -- the reference
            # the verdict's routed re-STA uses (routed_ioref).  Without it the scene timed vclk at the MIN insertion
            # (vclk_corner_true.sdc) and every route passed FF at route time, then failed the verdict on output-pin
            # flops by (mean - min) + 50 (hbm_vm8_nws_sp_hm10: 6,906 outputs at -45..-64).  Spec "route_ff_ioref": false
            # opts out; a spec that already lists an io_ref_routed.sdc keeps its own.
            if j["spec"].get("route_ff_ioref", True) and not any(f.rsplit("/", 1)[-1] == "io_ref_routed.sdc" for f in ff):
                ff = ff + [f"{j['run']}/cl/io_ref_routed.sdc"]
            # MMFF-IOREF 2026-10-08: a route cmd that inlines its own `export OT_MM_FF_SDC=...` (43 live jobs: setup_triage
            # requeue, make_lvt_job, mk_jobs) overrode the export above, so the FF scene lost io_ref_routed.sdc and timed
            # the assumed vclk (hbm_quant_ts0spl_tt: fake 4_1_cts hold -334).  The appended reference now travels as a
            # FILE the FF scene reads last whatever the final env says (orfs_hold_mm.tcl ot_mm_sync,
            # {SRC}/.ot_mm/ff_ioref_last.sdc; skipped when the list already holds an io_ref_routed.sdc); the opt-out
            # removes it so an earlier attempt's copy cannot leak in.
            if j["spec"].get("route_ff_ioref", True):
                env += f"mkdir -p {j['run']}/src/.ot_mm && cp {j['run']}/cl/io_ref_routed.sdc {j['run']}/src/.ot_mm/ff_ioref_last.sdc\n"
            else:
                env += f"rm -f {j['run']}/src/.ot_mm/ff_ioref_last.sdc\n"
            if ff:
                env += f"mkdir -p {j['run']}/src/.ot_mm\n"
                rel = []
                for f in ff:
                    if f.startswith("/"):
                        env += f"cp {shlex.quote(f)} {j['run']}/src/.ot_mm/\n"
                        rel.append(".ot_mm/" + f.rsplit("/", 1)[-1])
                    else:
                        rel.append(f)
                env += f"export OT_MM_FF_SDC={shlex.quote(' '.join(rel))}\n"
    if j.get("resume") and st["kind"] in ("route", "calibrate"):
        env += "export OT_CL_RESUME=1\n"
    if st["kind"] == "route" and j.get("hold_stop"):    # HOLD-STOP (drive-resume): see hold_stop_resume
        env += f"export OT_HOLD_STOP={shlex.quote(' '.join(f'{k}:{int(v)}' for k, v in sorted(j['hold_stop'].items())))}\n"    # patched run_abi3_physical in the moved snapshot: resume from the checkpoint
    if j.get("budget"):          # budget SDCs (tools/budgets/make_block_sdc.py from the published sheet)
        env += "".join(f"export {k}={j['run']}/cl/{v}\n" for k, v in (
            ("BUDGET_SDC", "budget_route.sdc"), ("BUDGET_SDC_SIGNOFF", "budget_signoff.sdc"), ("BUDGET_SDC_FF", "budget_ff.sdc"),
            ("BUDGET_SHEET", "budget_sheet.json")))
        env += f"export BUDGET_LINT_SS={j['budget']['insertion']['ss']}\nexport BUDGET_LINT_FF={j['budget']['insertion']['ff']}\n"
    # a job without calibrate still gets a {CL}/calib.json (records copy it)
    if st["kind"] != "calibrate":
        env += f"[ -f {j['run']}/cl/calib.json ] || echo '{{\"calibrate\": \"disabled\"}}' > {j['run']}/cl/calib.json\n"
    # every stage after calibrate sees the measured insertion (CK_SS_MEAN/MIN/MAX, CK_FF_*; *_ALL_* = all registers)
    env += f"[ -f {j['run']}/cl/calib.env ] && {{ set -a; . {j['run']}/cl/calib.env; set +a; }}\n" \
        if st["kind"] != "calibrate" else ""
    if st["kind"] == "bench":
        private = shlex.quote(j["stage_source"])
        original = shlex.quote(f"{j['run']}/src")
        # Parallel bench stages of one attempt share the private copy: serialise the copy with a lock instead of
        # refusing on an existing .tmp.  A copy that died (ENOSPC on AGIdock, hfd_lk_ep-b46a972cd-cc 10-11) left a
        # stale .tmp that made every retry exit 9 (NEEDS_RTL with no bench run); under the lock a leftover .tmp is
        # always stale, so it is removed and the copy redone.
        if rebound:
            from bench_rebind import launch_guard
            env += launch_guard(rebound)
        env += bench_copy_script(original, private)
        # A few legacy recipes spell {RUN}/src instead of using {SRC}.
        cmd = cmd.replace("{RUN}/src", "{SRC}")
    if st["kind"] == "route" and (j.get("ctrack") or {}).get("sdc_cmd"):
        # calibrate runs in parallel: the IO SDC the calibrate stage would have generated is made here from the
        # assumed (or, on a re-route, measured) insertion in calib.env
        cmd = f"( {j['ctrack']['sdc_cmd']} ) || exit 5\n" + cmd
    if j.get("export_lint_recovery") and st["key"] == "collect":
        from export_lint_recovery import stage_script
        before, after = stage_script(j["export_lint_recovery"], j.get("stage_source", j["run"] + "/src"))
        env += before
        cmd = f"( {cmd} )\n_ot_export_rc=$?\n{after}exit $_ot_export_rc\n"
    cmd, picks = path_picks_safe(tt_overlay_fallback(cmd))
    body = (f"#!/bin/bash\n# closure-loop {j['name']} stage {st['key']} attempt {j['attempt']}\nset -o pipefail\n"
            f"{OT_PICK_FN}{path_pick_precheck(picks)}{env}{subst(cmd, j)}\n")
    run = j["run"]
    # idempotent launch (2026-10-07): a daemon restart between a launch and the job-state save re-launched the same tag;
    # the second copy overwrote the script and rc (dsrom_softmax_safe_div2b: hold ECO 'rc=10 output exists' while the
    # first ECO was running).  A tag whose process is alive is adopted, never launched twice.
    alive = ssh(j["host"], f"p=$(cat {run}/cl/{t}.pid 2>/dev/null); [ -n \"$p\" ] && kill -0 $p 2>/dev/null && "
                           f"[ ! -f {run}/cl/{t}.rc ] && echo ALIVE; true", timeout=60)
    if "ALIVE" in alive.stdout:
        log(f"[{j['name']}] {t} already running on {j['host']}: adopted, not relaunched")
    else:
        ssh(j["host"], f"cat > {run}/cl/{t}.sh && rm -f {run}/cl/{t}.rc && echo {int(st.get('ram') or 0)} > {run}/cl/{t}.decl",
            input=body, timeout=60, check=True)
        # FLEET-OOM: every launch ships the current runner (atomic: a running stage keeps its old inode), so a retry in
        # an existing run dir gets the RSS sampler and the OOM-kill check
        ssh(j["host"], f"cat > {run}/cl/run.sh.tmp && chmod +x {run}/cl/run.sh.tmp && mv {run}/cl/run.sh.tmp {run}/cl/run.sh",
            input=RUNNER, timeout=60, check=True)
        ssh(j["host"], f"nohup setsid bash {run}/cl/run.sh {t} > /dev/null 2>&1 < /dev/null & echo launched", timeout=60,
            check=True)
    j["stage_tag"] = t
    j["stage_started"] = now_iso()


STAGE_PEAKS = STATE / "stage_peaks.json"
PEAK_MARGIN = 1.15
_peaks_cache = [None, {}]


def stage_peaks():
    """FLEET-OOM (2026-10-18): block|stage key -> measured stage peak (process-group RSS, RUNNER (a)), all hosts"""
    try:
        m = STAGE_PEAKS.stat().st_mtime
    except OSError:
        return {}
    if _peaks_cache[0] != m:
        try:
            _peaks_cache[:] = [m, json.loads(STAGE_PEAKS.read_text())]
        except (OSError, ValueError):
            return _peaks_cache[1]
    return _peaks_cache[1]


def learned_ram(block, key, ram):
    """FLEET-OOM (4): a repeat of the same block + stage is admitted at max(declared, PEAK_MARGIN x its measured peak)
    (hcoll_v7_tkm_tile_e86 declared 160 GB, its Verilator build reached 298 GB and earlyoom took the host's benches)"""
    e = stage_peaks().get(f"{block}|{key}") if block else None
    if e and e.get("peak_gb", 0) * PEAK_MARGIN > (ram or 0):
        return int(math.ceil(e["peak_gb"] * PEAK_MARGIN))
    return ram


def record_stage_peak(j, st, kb):
    gb = round(kb / 1048576, 1)
    if gb < 1:
        return
    k = f"{j['spec'].get('block')}|{st['key']}"
    t = dict(stage_peaks())
    e = dict(t.get(k) or dict(peak_gb=0.0, n=0))
    e.update(n=e.get("n", 0) + 1, last_gb=gb, last_job=j["name"], last_host=j.get("host"), declared_gb=st.get("ram"),
             peak_gb=max(e.get("peak_gb", 0.0), gb), at=now_iso())
    t[k] = e
    tmp = STAGE_PEAKS.with_suffix(".tmp")
    tmp.write_text(json.dumps(t, indent=0, sort_keys=True))
    os.replace(tmp, STAGE_PEAKS)
    if st.get("ram") and gb > st["ram"]:
        event(j, f"{st['key']} measured peak {gb} GB > declared {st['ram']} GB: repeats of {k} admit at "
                 f"{learned_ram(j['spec'].get('block'), st['key'], st['ram'])} GB")


def stage_oom_kills(j, st):
    """FLEET-OOM (2): the runner's <tag>.oomkill (earlyoom / kernel OOM kills of the stage's pids); records the peak"""
    t, run = j.get("stage_tag"), j.get("run")
    if not t or not run or not j.get("host"):
        return ""
    r = ssh(j["host"], f"head -c 1500 {run}/cl/{t}.oomkill 2>/dev/null; echo; echo OT_PEAK_KB $(cat {run}/cl/{t}.peak_kb "
                       f"2>/dev/null)", timeout=40)
    out = r.stdout if not r.returncode else ""
    m = re.search(r"OT_PEAK_KB (\d+)", out)
    if m:
        try:
            record_stage_peak(j, st, int(m.group(1)))
        except (OSError, ValueError) as ex:
            log(f"[{j['name']}] stage peak not recorded: {ex}")
    return out.split("OT_PEAK_KB")[0].strip()


def oom_retry(j, st, fleet, kills):
    """an earlyoom / kernel OOM kill of a stage process is a FLOW failure: retry the stage once, never NEEDS_RTL"""
    first = kills.splitlines()[0][:300]
    why = f"OOM-KILL: {len(kills.splitlines())} kill(s) of this stage's processes (flow failure, reroute_reason flow_failure): {first}"
    if j["retries_used"] >= 1:
        return crash(j, st, fleet, why)
    j.setdefault("crashes", []).append(dict(stage=st["key"], host=j["host"], attempt=j["attempt"], why=why, resource=True,
                                            cls="oom_kill", tail=kills[-1500:]))
    j["retries_used"] = 1
    j["attempt"] += 1
    j["status"] = "READY"
    event(j, f"{st['key']} {why[:400]} -> retry once (flow failure)")


def poll_stage(j):
    t, run = j["stage_tag"], j["run"]
    r = ssh(j["host"], f"""if [ -f {run}/cl/{t}.rc ]; then echo RC $(cat {run}/cl/{t}.rc)
elif [ -f {run}/cl/{t}.pid ] && kill -0 $(cat {run}/cl/{t}.pid) 2>/dev/null; then echo RUNNING
elif [ -f {run}/cl/{t}.pid ]; then echo LOST; else echo STARTING; fi""", timeout=40)
    w = r.stdout.split() if not r.returncode else []
    note_host(j.get("host"), bool(w))
    if not w:
        return "UNREACHABLE", None
    if w[0] == "RC":
        # an EMPTY / non-numeric rc file (the host reset while the wrapper wrote it: AGIdock 10-15, s81fill_hstnv_560-f8
        # bench_payload_bit_mutant -> 'RC' alone, IndexError x10 -> NEEDS_HUMAN) is a stage that died without an exit
        # status: LOST, handled like a vanished wrapper
        return ("RC", int(w[1])) if len(w) > 1 and re.fullmatch(r"-?\d+", w[1]) else ("LOST", None)
    return w[0], None


def remote_ok(j, cmd, timeout=300):
    if not cmd:
        return True, ""
    source = j.get("stage_source", f"{j['run']}/src")
    r = ssh(j["host"], f"cd {shlex.quote(source)} && {subst(cmd, j)}", timeout=timeout)
    return r.returncode == 0, (r.stdout + r.stderr)[-400:]


def bench_input_error(full):
    """A simulator may warn about missing memory images and still exit zero.

    HBM PC proof 2026-10-15 falsely compared zero-filled actual/expected arrays
    after '$readmem file not found'. Missing stimuli prove neither a positive
    nor a detected mutant. Ignore ordinary readmem messages and short images
    that a bench may intentionally load into a larger memory.
    """
    for line in full.splitlines():
        if re.search(r"\b(?:FATAL|ERROR)\b.*(?:required image unavailable|incomplete (?:records|backing) image|duplicate backing sector address)", line, re.I):
            return line.strip()[:500]
        if re.search(r"\breadmem(?:[hb]|\s+file)?\b", line, re.I) and re.search(
                r"file\s+not\s+found|(?:unable|cannot|could\s+not|can't)\s+(?:to\s+)?open|no\s+such\s+file", line, re.I):
            return line.strip()[:500]
    return ""


def bench_outcome(j, st, rc, ok_extra=True):
    """pass: rc 0 (+ ok, + pass_regex); fail: rc != 0 (+ fail_regex).  Regexes are MULTILINE over the whole stage log
    (last 20000 lines), so ^FAIL matches any line."""
    full = ""
    for _ in range(4):  # an ssh hiccup returns an empty log and mis-judged benches (code-pair 10-07); fetch until it reads
        # drive-resume 2026-10-09: a bench that prints nothing (qkd_d2d *_record: a python -c exit-code check) left an
        # EMPTY log, read as an ssh hiccup 10x -> NEEDS_HUMAN.  A marker line proves the file was read: empty is valid.
        # Initialization warnings may precede more than 20,000 comparison
        # lines. Scan the whole log for missing readmem inputs before its tail.
        errors = r"readmem.*(file[[:space:]]+not[[:space:]]+found|unable.*open|cannot.*open|could[[:space:]]+not.*open|no[[:space:]]+such[[:space:]]+file)|((FATAL|ERROR).*(required image unavailable|incomplete (records|backing) image|duplicate backing sector address))"
        r = ssh(j["host"], f"f={j['run']}/cl/{j['stage_tag']}.log; [ -f $f ] && {{ echo OT_BENCH_LOG_READ; "
                f"LC_ALL=C grep -i -m 3 -E {shlex.quote(errors)} \"$f\" || true; tail -n 20000 \"$f\"; }}",
                timeout=180)
        if r.returncode == 0 and r.stdout.startswith("OT_BENCH_LOG_READ"):
            full = r.stdout.split("\n", 1)[1] if "\n" in r.stdout else ""
            break
        time.sleep(15)
    else:
        raise RuntimeError(f"bench log unreadable on {j['host']}: {j['run']}/cl/{j['stage_tag']}.log")
    input_error = bench_input_error(full)
    if input_error:
        j.setdefault("bench_work", {})[st["key"]] = "input error: " + input_error
        return False
    if st["expect"] == "pass":
        ok = rc == 0 and ok_extra and (not st.get("pass_regex") or re.search(st["pass_regex"], full, re.M) is not None)
        if ok:
            work, note = bench_work(full, st.get("min_count_regex"))
            j.setdefault("bench_work", {})[st["key"]] = note
            if work is False:
                return False
        return ok
    seen = expected_fail_seen(st, rc, full)
    if seen and st.get("fail_regex"):
        try:
            capture_fail_witness(j, st, full)
        except Exception:  # noqa: BLE001 -- the verdict stands; a lost witness is only a missing archive
            log(f"[{j.get('name')}] fail-witness capture error:\n{traceback.format_exc()}")
    return seen


# FAIL-WITNESS AUTO-CAPTURE (GATE-FRICTION 2026-10-18, owner 0eg: checks must never delay closure).  submit_exact WARNs
# (no longer refuses) when an expect=fail bench has no committed fail_witness log; the loop captures the REAL mutant
# output here instead: when the mutant failed as expected and its fail_regex matched, the matching part of the stage log
# is archived under STATE/fail_witnesses/<job>/<bench>.log (verified to match the regex again) and recorded in
# j["fail_witnesses"]; publish() commits it with the CLOSED record (results/closure_loop/<job>/fail_witness/).  A mutant
# that does not fail is still NEEDS_RTL (bench_outcome above), witness or not.
WITNESS_DIR = STATE / "fail_witnesses"
WITNESS_CONTEXT = 40           # lines kept around each fail_regex match
WITNESS_TAIL = 200             # last lines of the log kept as well
WITNESS_MAX_BYTES = 256 << 10


def witness_text(full, rx):
    """the part of a mutant log that proves the verdict: every fail_regex match with context, plus the tail.  Returns
    None when the regex does not match the kept text (the caller then keeps nothing)."""
    lines = full.splitlines()
    keep = set(range(max(0, len(lines) - WITNESS_TAIL), len(lines)))
    starts, pos = [], 0
    for n, ln in enumerate(lines):
        starts.append(pos)
        pos += len(ln) + 1
    for m in list(re.finditer(rx, full, re.M))[:8]:
        n = max(0, sum(1 for s in starts if s <= m.start()) - 1)
        last = n + m.group(0).count("\n")
        keep.update(range(max(0, n - WITNESS_CONTEXT), min(len(lines), last + WITNESS_CONTEXT + 1)))
    out, prev = [], -1
    for n in sorted(keep):
        if n != prev + 1:
            out.append(f"... [{n - prev - 1} line(s) omitted by the fail-witness capture] ...")
        out.append(lines[n])
        prev = n
    text = "\n".join(out) + "\n"
    if len(text.encode()) > WITNESS_MAX_BYTES:
        text = text.encode()[-WITNESS_MAX_BYTES:].decode(errors="ignore")
    return text if re.search(rx, text, re.M) else None


def capture_fail_witness(j, st, full):
    rx, key = st["fail_regex"], st["key"]
    body = witness_text(full, rx)
    if body is None:
        event(j, f"fail-witness: {key} fail_regex matched the log but not the kept excerpt; nothing archived")
        return None
    head = (f"# fail witness captured by the closure loop (GATE-FRICTION auto-capture)\n# job {j.get('name')} bench {key} "
            f"host {j.get('host')} run {j.get('run')} log cl/{j.get('stage_tag')}.log captured {now_iso()}\n"
            f"# fail_regex {rx!r}\n")
    data = (head + body).encode()
    d = WITNESS_DIR / label(j.get("name") or "job")
    d.mkdir(parents=True, exist_ok=True)
    f = d / f"{label(key)}.log"
    tmp = f.with_suffix(f".{os.getpid()}.{threading.get_ident()}.tmp")
    tmp.write_bytes(data)
    os.replace(tmp, f)
    m = re.search(rx, body, re.M)
    rec = dict(path=str(f), sha256=hashlib.sha256(data).hexdigest(), fail_regex=rx, matched=m.group(0)[:200],
               captured_at=now_iso(), declared=st.get("fail_witness"))
    j.setdefault("fail_witnesses", {})[key] = rec
    event(j, f"fail-witness: {key} captured ({len(data)} B, matched {rec['matched'][:80]!r}) -> {f}")
    return rec


def bench_why(j, st, rc, ok_extra=True):
    """Why a bench with expect PASS was judged not passed, for the verdict reason.  rc=0 alone read as 'expected PASS
    but rc=0' (5 jobs 2026-10-15: pass_regex not matching the bench's actual verdict line, or a min_count_regex the
    bench never prints) and was triaged as a flow bug."""
    note = (j.get("bench_work") or {}).get(st["key"], "")
    if note.startswith("input error:"):
        return f" ({note})"
    if st.get("expect") != "pass" or rc != 0:
        return ""
    if not ok_extra:
        return " (ok check failed)"
    if note.startswith("vacuous"):
        return f" ({note})"
    if st.get("pass_regex"):
        return f" (pass_regex {st['pass_regex']!r} not matched in the bench log)"
    return ""


def expected_fail_seen(st, rc, full):
    """expect FAIL (negative control): the log's own verdict decides, regardless of rc -- a mutant bench that prints
    FAIL but exits 0 was read as "expected FAIL but rc=0" (LOOP-GAPS 2026-10-08).  With fail_regex: it must match (a
    crash with rc != 0 and no FAIL verdict is not a detected mutant).  Without: rc != 0 or a conventional ^FAIL line."""
    if bench_input_error(full):
        return False
    if st.get("fail_regex"):
        return re.search(st["fail_regex"], full, re.M) is not None
    return rc != 0 or re.search(r"^FAIL\b", full, re.M) is not None


WORK_RE = re.compile(r"\b(compared|comparisons|checks?|checked|vectors|cases|tokens|results|matches|transactions|"
                     r"samples|tests|passed|beats|ops)\s*[=:]\s*(\d+)", re.I)


def bench_work(log, min_count_regex=None):
    """VACUOUS-PASS GUARD (2026-10-07: distro Verilator 5.032 ran the SU reducer benches with ZERO reducer results).
    spec min_count_regex (one capture group): a pass needs a match and every captured count > 0.  Without it, generic
    count lines (compared=N, checks: N, ...) all equal to 0 fail the pass; a pass log with no count line passes with a
    warning.  Returns (False | True | None, note)."""
    if min_count_regex:
        m = [int(x) for x in re.findall(min_count_regex, log, re.M) if str(x).isdigit()]
        if not m or min(m) <= 0:
            return False, f"vacuous: min_count_regex {min_count_regex!r} counts {m[:8]}"
        return True, f"work: {m[:8]}"
    m = [(k, int(v)) for k, v in WORK_RE.findall(log)]
    if m and all(v == 0 for _, v in m):
        return False, f"vacuous: every count line is 0 ({m[:6]})"
    if not m:
        return None, "WARN: pass log has no count line (set min_count_regex)"
    return True, f"work: {m[:6]}"


# A stage cmd that sends its tool output to its own file ('... > {RUN}/record/route/export.log 2>&1', every ref_tile
# collect) leaves cl/<tag>.log empty: 14 S81 fill collects went NEEDS_HUMAN 'collect crashed twice (rc=1)' on 2026-10-15
# with an empty tail and no first error, while export.log held the child_lint FAIL.  Tail those redirect targets too.
REDIRECT_LOG_RE = re.compile(r"(?<![<>&0-9])>\s*([^\s;&|<>]+)\s+2>&1")


def stage_logs(j, st):
    logs = list(st.get("logs", [])) + [m for m in REDIRECT_LOG_RE.findall(st.get("cmd") or "") if m not in st.get("logs", [])]
    return [subst(x, j) for x in logs]


def stage_tail(j, st, n=40):
    extra = " ".join(stage_logs(j, st))
    r = ssh(j["host"], f"tail -n {n} {j['run']}/cl/{j['stage_tag']}.log 2>/dev/null; for f in {extra}; do "
                       f"[ -f \"$f\" ] && tail -n {n} \"$f\"; done; true", timeout=60)
    return r.stdout


TT_STA_SLOTS = threading.BoundedSemaphore(3)   # each holds one of a host's 8 ssh channels for minutes


def get_metrics(j, tt_resta=True):
    v = j["spec"].get("verdict", {})
    if v.get("metrics_cmd"):
        r = ssh(j["host"], f"cd {j['run']}/src && {subst(v['metrics_cmd'], j)}", timeout=600)
        last = [x for x in r.stdout.splitlines() if x.strip().startswith("{")]
        if not last and r.returncode:
            # no JSON and a failed command: an ssh drop (w2-rb-safe-no3 went NEEDS_HUMAN "verdict inputs missing" with
            # raw {} while the same command printed the metrics a minute later) or a real error. Raise: transient ssh
            # errors back off, anything else counts toward the 10-consecutive-errors NEEDS_HUMAN.
            raise RuntimeError(f"verdict metrics_cmd produced no JSON (command failed rc={r.returncode}): "
                               f"{(r.stderr or r.stdout).strip()[-300:]}")
        m = json.loads(last[-1]) if last else {}
        out = dict(ss_ps=m.get("ss_ps"), ff_ps=m.get("ff_ps"), drc=m.get("drc"), orfs_dir=m.get("orfs_dir"),
                   setup_corner=m.get("setup_corner"), clock_periods_ps=m.get("clock_periods_ps"),
                   ss_sensitivity_ps=m.get("ss_sensitivity_ps"), raw=m)
        # The post-route hold ECO / re-STA paths read these from the metrics; a custom metrics_cmd that reports them
        # must not lose them here (W2 station jobs went NEEDS_RTL with no hold ECO ever attempted, el1011-hbm-no3 10-11).
        for k in ("drc_metrics", "corner_sta", "post_sdc"):
            if m.get(k) is not None:
                out[k] = m[k]
        return out
    py = r"""
import glob,json,sys,re
cs=sorted(glob.glob(sys.argv[1])); dm=sorted(glob.glob(sys.argv[2])) if sys.argv[2] else []
o={'corner_sta':cs,'drc_metrics':dm}
if cs:
  d=json.load(open(cs[-1])); o['ff_ps']=d['hold_ff']['worst_slack_ps']
  o['clock_periods_ps']={name:float(period) for name,period in re.findall(r'create_clock\s+-name\s+(\S+)\s+-period\s+([0-9.]+)', d.get('extra_sdc',''))}
  o['orfs_dir']=d.get('orfs_dir'); o['post_sdc']=list(d.get('post_sdc',{}))
  o['sdc_name']=d.get('sdc_name') or d['hold_ff'].get('sdc_name') or '6_final.sdc'; o['setup_post_sdc']=list(d.get('setup_post_sdc') or [])
  o['ss_sensitivity_ps']=d['setup_ss']['worst_slack_ps']; o['ss_sensitivity_tns_ps']=d['setup_ss'].get('tns_ps')
  # OWNER OPTION B: setup closes at TT; ss_ps keeps its key for the loop's line checks but now holds the TT setup slack
  tt=d.get('setup_tt')
  if tt is None:
    try: tt=json.load(open(cs[-1]+'.tt.json')).get('setup_tt')
    except Exception: tt=None
  o['setup_corner']='tt'; o['corner_sta_tt']=cs[-1]+'.tt.json' if 'setup_tt' not in d else cs[-1]
  if tt is None:
    o['need_tt']=True; o['ss_ps']=None; o['errors']=d['hold_ff'].get('errors',[])
  else:
    o['ss_ps']=tt.get('worst_slack_ps'); o['ss_tns_ps']=tt.get('tns_ps')
    o['errors']=(tt.get('errors') or [])+d['hold_ff'].get('errors',[])+([tt['error']] if tt.get('error') else [])
if dm:
  m=json.load(open(dm[-1])); o['drc']=m.get('detailedroute__route__drc_errors')
print(json.dumps(o))
"""
    r = ssh(j["host"], f"cd {j['run']}/src && python3 - {shlex.quote(subst(v['corner_sta'], j))} "
                       f"{shlex.quote(subst(v.get('drc_metrics', ''), j))}", input=py, timeout=120)
    try:
        m = json.loads(r.stdout.strip().splitlines()[-1])
    except Exception:  # noqa: BLE001
        m = {"error": (r.stdout + r.stderr)[-400:]}
    if m.get("need_tt") and tt_resta and m.get("orfs_dir") and not m.get("error"):
        with TT_STA_SLOTS:          # TT re-STA of an existing route (option B), at most a few at once fleet-wide
            ship_helpers(j["host"], j["run"], j)
            ssh(j["host"], f"bash {j['run']}/cl/tt_resta.sh {shlex.quote(m['orfs_dir'])} {j['run']}/src "
                           f"{shlex.quote(m['corner_sta_tt'])}", timeout=6000)
        event(j, "option B: TT setup re-STA of the existing route")
        return get_metrics(j, tt_resta=False)
    if v.get("drc") == "skip":
        m["drc"] = 0
        m["drc_skipped"] = True
    return m


# ------------------------------------------------------------------------------------------------ git publish
def wt_add(path, ref, sparse):
    if path.exists():
        git("worktree", "remove", "--force", str(path), check=False)
        shutil.rmtree(path, ignore_errors=True)
    git("worktree", "prune", check=False)
    git("worktree", "add", "--no-checkout", "--detach", str(path), ref)
    git("sparse-checkout", "set", "--no-cone", *sparse, cwd=path)
    git("checkout", "-q", cwd=path, timeout=1800)


def wt_rm(path):
    git("worktree", "remove", "--force", str(path), check=False)
    shutil.rmtree(path, ignore_errors=True)


def setup_corner_label(metrics):
    """Label the measured setup scene; ss_ps is a historical compatibility key."""
    corner = str(metrics.get("setup_corner") or "unknown").lower()
    return {"tt": "TT", "tc": "TT", "ss": "SS", "wc": "SS"}.get(corner, corner.upper())


def measured_clock_text(metrics):
    periods = metrics.get("clock_periods_ps") or {}
    if not periods:
        return "under measured clock constraints"
    return "at " + ", ".join(f"{name} {period:g} ps" for name, period in sorted(periods.items()))


def setup_sensitivity_text(metrics):
    value = metrics.get("ss_sensitivity_ps")
    return f"; SS sensitivity {value:+.2f} ps" if isinstance(value, (int, float)) else ""


def defer_record_merge(j, out, sparse, dry=False):
    """Keep the source-branch record durable while the owner's main window is held."""
    if dry or j['spec'].get('merge_target') != 'main' or not (claude_owns_main() or (STATE / 'main_integration_hold.json').exists()):
        return False
    pending = STATE / 'deferred_record_merges'
    pending.mkdir(parents=True, exist_ok=True)
    record = dict(job=dict(name=j['name'], spec=dict(block=j['spec']['block'],
                  source=dict(branch=j['spec']['source']['branch']), merge_target='main')),
                  out=dict(out), sparse=sparse, queued_at=now_iso())
    path = pending / (j['name'] + '.json')
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(record, indent=1) + '\n')
    was_pending = path.exists()
    tmp.replace(path)
    if claude_owns_main() and not was_pending:
        notify_claude_record(j['name'], out.get('record_branch', j['spec']['source']['branch']), out['branch_commit'])
    out['merge'] = ('DEFERRED main merge: Claude owns integration; record committed on source branch' if claude_owns_main() else 'DEFERRED main merge: owner integration window; record committed on source branch')
    return True


# AUTO-MERGE (owner 2026-10-10, drive-1010): closures keep reaching main while no agent is alive.  With
# STATE/main_publish_owner.json {"auto_merge_guarded": true}, a CLOSED job is merged into main by the loop when
#   - its source branch is claude/* or codex/* (other namespaces stay with a coordinator),
#   - its loop benches all ended as expected (every positive PASS, every negative FAIL; behavioral positive and mutant required),
#   - its spec does not opt out ("auto_merge": false, or "hold_merge": "<reason>"),
#   - the merge of the VERIFIED source commit (commit_full, not the branch tip) into origin/main is clean, and the
#     record files (verdict + recorded views) come from the record commit on top.
# Anything else (conflict, push race x4, failed guard) is appended to <takeover>/AUTO_MERGE_PENDING.md for a human /
# agent, never forced.
AUTO_MERGE_PENDING = Path(os.environ.get("CL_TAKEOVER", "/home/ubuntu/claude-takeover-20261007")) / "AUTO_MERGE_PENDING.md"


def auto_merge_policy():
    try:
        return bool(json.loads((STATE / 'main_publish_owner.json').read_text()).get('auto_merge_guarded'))
    except (OSError, ValueError):
        return False


def auto_merge_guard(j):
    """None when the closure may be auto-merged, else the reason it may not"""
    spec = j['spec']
    if not auto_merge_policy():
        return "auto-merge policy off"
    if spec.get('auto_merge') is False or spec.get('hold_merge'):
        return f"spec opts out ({spec.get('hold_merge') or 'auto_merge false'})"
    try:
        holds = json.loads((STATE / 'main_publish_owner.json').read_text()).get('auto_merge_hold_prefixes') or []
    except (OSError, ValueError):
        holds = []
    hit = next((h for h in holds if str(spec.get('block', '')).startswith(h) or j['name'].startswith(h)), None)
    if hit:
        return f"held by policy prefix {hit} (gate outside the loop benches)"
    if not str(spec['source'].get('branch', '')).startswith(('claude/', 'codex/')):
        return f"source branch {spec['source'].get('branch')} is not claude/* or codex/*"
    benches = j.get('benches') or {}
    try:
        waive = json.loads((STATE / 'main_publish_owner.json').read_text()).get('auto_merge_external_bench_prefixes') or []
    except (OSError, ValueError):
        waive = []
    if not benches and spec.get('no_bench_reason') and any(j['name'].startswith(w) for w in waive):
        return None if j.get('commit_full') else "no verified source commit"   # owner-approved external bench (BF of record)
    if not benches:
        return "no loop benches ran"
    bad = [k for k, v in benches.items() if not (isinstance(v, dict) and v.get('ok') is True)]
    if bad:
        return f"benches not as expected: {', '.join(bad[:4])}"
    gap = bench_evidence_gap({k: v.get('expect') for k, v in benches.items()})    # the submit gate's own definition
    if gap:
        return gap
    if spec.get('benched_by'):
        want = [bench_key(n) for n in gate_bench_names(spec['benched_by'])]
        lost = [k for k in want if k not in benches]
        if not want or lost:
            return f"benched_by {spec['benched_by']}: composition gate benches did not run ({', '.join(lost[:4]) or 'unknown gate'})"
    if not j.get('commit_full'):
        return "no verified source commit"
    return None


def auto_merge_closure(j, out, record_paths, dry=False):
    """merge commit_full + the record files into main (clean merges only); returns a status string"""
    why = auto_merge_guard(j)
    attribution = ("Coordinated by: Codex" if str(j["spec"]["source"].get("branch", "")).startswith("codex/")
                   else "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>")
    if why:
        if why != "auto-merge policy off":
            append_locked(AUTO_MERGE_PENDING, f"- {now_iso()} {j['name']} ({j['spec'].get('block')}): AUTO-MERGE skipped: {why}; "
                                              f"record {out.get('record_branch')} {str(out.get('branch_commit'))[:9]}\n")
        return f"AUTO-MERGE skipped: {why}"
    mwt = STATE / 'git' / (j['name'] + '-automerge')
    sparse = ["/" + t.rstrip("/") for t in record_paths] + ["/tools/closure_loop/"]
    status = None
    for attempt in range(4):
        gfetch('main', timeout=600)
        wt_add(mwt, "origin/main", sparse)
        if sh(["git", "-C", str(mwt), "merge-base", "--is-ancestor", j['commit_full'], "HEAD"], timeout=120).returncode == 0:
            pass  # source already on main: only the record goes in
        else:
            m = sh(["git", "-C", str(mwt), "-c", "user.name=OpenTallas closure-loop", "-c", "user.email=boj@01.me",
                    "merge", "--no-ff", "--no-edit", "-m",
                    f"Merge {j['spec']['source']['branch']} @ {j['commit_full'][:9]} (closure-loop AUTO-MERGE {j['name']}: "
                    f"{j['spec']['block']} CLOSED, benches as expected)\n\n{attribution}",
                    j['commit_full']], timeout=1800)
            if m.returncode:
                conf = sh(["git", "-C", str(mwt), "diff", "--name-only", "--diff-filter=U"], timeout=120).stdout.split()
                sh(["git", "-C", str(mwt), "merge", "--abort"], timeout=300)
                status = f"AUTO-MERGE CONFLICT ({len(conf)} files: {', '.join(conf[:6])})"
                break
        co = sh(["git", "-C", str(mwt), "checkout", out["branch_commit"], "--", *record_paths], timeout=600)
        if co.returncode:
            status = f"AUTO-MERGE record checkout failed: {co.stderr[-200:]}"
            break
        sh(["git", "-C", str(mwt), "add", "--sparse", "--", *record_paths], timeout=300)
        if sh(["git", "-C", str(mwt), "diff", "--cached", "--quiet"], timeout=120).returncode:
            git("-c", "user.name=OpenTallas closure-loop", "-c", "user.email=boj@01.me", "commit", "-q", "-m",
                f"closure-loop AUTO-MERGE record {j['name']} ({j['spec']['block']} CLOSED)\n\n"
                f"{attribution}", cwd=mwt)
        head = git("rev-parse", "HEAD", cwd=mwt).stdout.strip()
        if dry:
            status = f"AUTO-MERGE dry-run {head[:9]} (not pushed)"
            break
        p = sh(["git", "-C", str(mwt), "push", "-q", "origin", "HEAD:refs/heads/main"], timeout=900)
        if p.returncode == 0:
            status = f"AUTO-MERGED into main {head[:9]}"
            break
        log(f"[{j['name']}] auto-merge push rejected (attempt {attempt}): {p.stderr[-300:]}")
    else:
        status = "AUTO-MERGE PUSH-RACE: could not push after 4 attempts"
    wt_rm(mwt)
    if not status.startswith("AUTO-MERGED") and not status.startswith("AUTO-MERGE dry-run"):
        append_locked(AUTO_MERGE_PENDING, f"- {now_iso()} {j['name']} ({j['spec']['block']}): {status}; source "
                                          f"{j['spec']['source']['branch']} @ {j['commit_full'][:9]}, record {out.get('record_branch')} "
                                          f"{str(out.get('branch_commit'))[:9]}\n")
    return status


def merge_record(j, out, sparse, dry=False):
    spec = j['spec']
    branch, target = out.get('record_branch', j['spec']['source']['branch']), j['spec'].get('merge_target')
    mwt = STATE / 'git' / (j['name'] + '-merge')
    for attempt in range(4):
        if defer_record_merge(j, out, sparse, dry):
            return out
        gfetch(target, timeout=600)
        wt_add(mwt, f"origin/{target}", sparse)
        mref = out["branch_commit"]
        if not dry:
            gfetch(branch, timeout=600)
        m = sh(["git", "-C", str(mwt), "-c", "user.name=OpenTallas closure-loop", "-c", "user.email=boj@01.me",
                "merge", "--no-ff", "--no-edit", "-m",
                f"Merge {branch} into {target} (closure-loop {j['name']}: {spec['block']} CLOSED)\n\n"
                f"Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>", mref], timeout=1800)
        if m.returncode:
            conf = sh(["git", "-C", str(mwt), "diff", "--name-only", "--diff-filter=U"], timeout=120).stdout.split()
            sh(["git", "-C", str(mwt), "merge", "--abort"], timeout=300)
            wt_rm(mwt)
            out["merge"] = f"CONFLICT ({len(conf)} files: {', '.join(conf[:6])})"
            return out
        out["merge_commit"] = git("rev-parse", "HEAD", cwd=mwt).stdout.strip()
        if dry:
            out["merge"] = f"dry-run merged locally {out['merge_commit'][:9]} (not pushed)"
            break
        if defer_record_merge(j, out, sparse, dry):
            wt_rm(mwt)
            return out
        p = sh(["git", "-C", str(mwt), "push", "-q", "origin", f"HEAD:refs/heads/{target}"], timeout=900)
        if p.returncode == 0:
            out["merge"] = f"merged into {target} {out['merge_commit'][:9]}"
            break
        log(f"[{j['name']}] push to {target} rejected (attempt {attempt}): {p.stderr[-300:]}")
        wt_rm(mwt)
    else:
        out["merge"] = f"PUSH-RACE: could not push the merge into {target}"
    wt_rm(mwt)
    return out


def retry_deferred_record_merges():
    if claude_owns_main() or (STATE / 'main_integration_hold.json').exists():
        return
    for path in sorted((STATE / 'deferred_record_merges').glob('*.json')):
        if (STATE / 'main_integration_hold.json').exists():
            break
        try:
            record = json.loads(path.read_text())
            with PUBLISH_LOCK:
                out = merge_record(record['job'], record['out'], record['sparse'])
            if out.get('merge', '').startswith('merged into '):
                with job_lock(record['job']['name']):
                    j = load_job(record['job']['name'])
                    j['publish'] = out
                    event(j, 'Deferred record ' + out['merge'])
                    save_job(j)
                path.unlink()
        except Exception:
            log('deferred record merge retry error:\n' + traceback.format_exc())


_DEFERRED_MERGE_FUTURE = None
_DEFERRED_MERGE_POOL = ThreadPoolExecutor(max_workers=1)


def schedule_deferred_record_merges():
    global _DEFERRED_MERGE_FUTURE
    if _DEFERRED_MERGE_FUTURE is None or _DEFERRED_MERGE_FUTURE.done():
        _DEFERRED_MERGE_FUTURE = _DEFERRED_MERGE_POOL.submit(retry_deferred_record_merges)


RECORD_MAX_FILE_BYTES = 90 << 20


# PORT-LATENCY (ROOT 2215, owner rule 19:50 PT 10-15): the exact elaborated pin-register stages of a recipe-3 tile reach the
# static compilers from the CLOSED record, never from a typed constant.  publish() exports the route synthesis's own
# $RESULTS_DIR/ot_pin_regs.tsv + ot_pin_regs_wrapper.v (physical/common_flow/ot_pin_regs.tcl) with
# tools/ref_tile/port_latency.py, bound to the job's full source SHA, into <kit>/views/port_latency.json (beside the
# closed view the compilers bind) and the job's results/closure_loop record.  A kit whose kit.env inserts pin registers
# (OT_PIN_REGS=1) but whose route left no table fails closed (publish error -> NEEDS_HUMAN, never a silent 0).
PORT_LATENCY_RE = re.compile(r"(physical/ref_tile/[^/\s'\"]+)/kit\.env")


def port_latency_record(j):
    """(kit dir, report dict) for a ref_tile route with pin registers; None when the kit inserts none."""
    spec = j["spec"]
    m = PORT_LATENCY_RE.search(((spec.get("stages") or {}).get("route") or {}).get("cmd") or "")
    if not m:
        return None
    kit = m.group(1)
    env = git("show", f"{j['commit_full']}:{kit}/kit.env", check=False).stdout
    if str(HERE.parent / "ref_tile") not in sys.path:
        sys.path.insert(0, str(HERE.parent / "ref_tile"))
    from kit_orfs_vars import parse
    enabled = parse(env).get("OT_PIN_REGS") == "1"
    top = None
    tile_spec = {}
    try:
        tile_spec = json.loads(git("show", f"{j['commit_full']}:{kit}/spec.json", check=False).stdout or "{}")
        top = tile_spec.get("top")
    except ValueError as ex:
        raise RuntimeError("PORT-LATENCY: invalid source-pinned tile specification") from ex
    if not enabled:
        declared = tile_spec.get("pin_regs")
        if isinstance(declared, dict) and declared.get("enable") is not False:
            raise RuntimeError("PORT-LATENCY: spec enables pin registers but kit lacks a literal OT_PIN_REGS=1 option")
        return None
    if not top:
        raise RuntimeError("PORT-LATENCY: missing source-pinned tile top; control roles cannot be verified")
    base = f"{j['run']}/routes/{label(j['name'])}/work/orfs/results/asap7/*/base"
    with tempfile.TemporaryDirectory() as td:
        got = {}
        for f in ("ot_pin_regs.tsv", "ot_pin_regs_wrapper.v"):
            r = ssh(j["host"], f"cat $(ls -d {base} | head -1)/{f}", timeout=120)
            if r.returncode != 0 or not r.stdout:
                raise RuntimeError(f"PORT-LATENCY: {kit}/kit.env inserts pin registers (OT_PIN_REGS=1) but the route left no "
                                   f"{f} under {base} (fail closed: the compilers need the elaborated per-port stages)")
            (Path(td) / f).write_text(r.stdout)
            got[f] = Path(td) / f
        if str(HERE.parent / "ref_tile") not in sys.path:
            sys.path.insert(0, str(HERE.parent / "ref_tile"))
        import port_latency
        rep = port_latency.export(got["ot_pin_regs.tsv"], got["ot_pin_regs_wrapper.v"], top, j["commit_full"])
        def role_source(path):
            result = git("show", f"{j['commit_full']}:{path}", check=False)
            return result.stdout if result.returncode == 0 else None
        rep["control_roles"] = port_latency.validate_roles(rep, got["ot_pin_regs_wrapper.v"], tile_spec, role_source)
    rep["job"] = j["name"]
    return kit, rep


def publish(j, metrics):
    """Commit record + view on the job branch (explicit paths), trial-merge into merge_target, push."""
    spec = j["spec"]
    plat = port_latency_record(j)       # PORT-LATENCY: before any git work; a missing table raises (fail closed)
    source_branch, target = spec["source"]["branch"], spec.get("merge_target")
    branch = f"codex/closure-record-{j['name']}" if claude_owns_main() else source_branch
    rec_dir = f"results/closure_loop/{j['name']}"
    tos = [r["to"] for r in spec.get("record", [])] + [rec_dir]
    sparse = ["/" + t.rstrip("/") for t in tos] + ["/tools/closure_loop/"]
    gdir = STATE / "git"
    gdir.mkdir(parents=True, exist_ok=True)
    cwt, mwt = gdir / f"{j['name']}-commit", gdir / f"{j['name']}-merge"
    dry = spec.get("dry_run_git", False)
    out = {}
    for attempt in range(4):
        base = branch
        if branch != source_branch:
            exists = git('ls-remote', '--heads', 'origin', branch).stdout.strip()
            if not exists:
                base = source_branch
        gfetch(base, timeout=600)
        wt_add(cwt, f"origin/{base}", sparse)
        big_remote = []
        for r in spec.get("record", []):
            src = subst(r["from"], j)
            dst = cwt / r["to"]
            isdir = ssh(j["host"], f"test -d {shlex.quote(src)}", timeout=30).returncode == 0
            dst.parent.mkdir(parents=True, exist_ok=True)
            excl = sum((["--exclude", x] for x in r.get("exclude", [])), [])
            with transport_command(j['host'], bulk=True) as base:
                remote_shell = [] if is_local(j['host']) else ["-e", shlex.join(base[:-1])]
                if isdir:
                    dst.mkdir(parents=True, exist_ok=True)
                    # never pull files git cannot take: a 3.9 GB record (hbm_vm8bfq_nwe lvt, 10-11) held the single-threaded
                    # daemon in one rsync at ~0.25 MB/s and stopped all intake; oversized files stay on the run host
                    sh(["rsync", "-a", f"--max-size={RECORD_MAX_FILE_BYTES}", *remote_shell, *excl,
                        rpath(j['host'], src.rstrip('/') + '/'), f"{dst}/"], timeout=1800, check=True)
                    r_big = ssh(j["host"], f"find {shlex.quote(src.rstrip('/'))} -type f -size +{RECORD_MAX_FILE_BYTES // 1024}k "
                                           f"-printf '%P %s\\n' 2>/dev/null | head -200", timeout=60)
                    for ln in (r_big.stdout or "").splitlines():
                        if ln.strip():
                            big_remote.append(f"{r['to']}/{ln.split()[0]} {ln.split()[-1]} B (kept on {j['host']}:{src})")
                else:
                    sh(["rsync", "-a", *remote_shell, rpath(j['host'], src), str(dst)], timeout=1800, check=True)
        # GitHub rejects files > 100 MB (pre-receive hook): drop oversized record files (they stay on the run host) and
        # list them, so one huge route artefact can never wedge the publish loop.
        big = list(big_remote)
        for r in spec.get("record", []):
            d = cwt / r["to"]
            for f in ([d] if d.is_file() else (d.rglob("*") if d.is_dir() else [])):
                if f.is_file() and f.stat().st_size > RECORD_MAX_FILE_BYTES:
                    big.append(f"{f.relative_to(cwt)} {f.stat().st_size} B (kept on {j['host']}:{j['run']})")
                    f.unlink()
        (cwt / rec_dir).mkdir(parents=True, exist_ok=True)
        plat_paths = []
        if plat:
            kit, rep = plat
            txt = json.dumps(rep, indent=2, sort_keys=True) + "\n"
            for r in spec.get("record", []):
                vd = cwt / r["to"].rstrip("/") / rep["top"]
                if r["to"].rstrip("/") == f"{kit}/views" and vd.is_dir():
                    (vd / "port_latency.json").write_text(txt)
                    plat_paths.append(str((vd / "port_latency.json").relative_to(cwt)))
            (cwt / rec_dir / "port_latency.json").write_text(txt)
            plat_paths.append(f"{rec_dir}/port_latency.json")
        for wk, w in sorted((j.get("fail_witnesses") or {}).items()):
            try:
                data = Path(w["path"]).read_bytes()
            except OSError:
                continue
            if hashlib.sha256(data).hexdigest() == w.get("sha256"):
                (cwt / rec_dir / "fail_witness").mkdir(parents=True, exist_ok=True)
                (cwt / rec_dir / "fail_witness" / f"{label(wk)}.log").write_bytes(data)
        if big:
            (cwt / rec_dir / "LARGE_FILES_EXCLUDED.txt").write_text("\n".join(big) + "\n")
            log(f"[{j['name']}] record: {len(big)} file(s) > {RECORD_MAX_FILE_BYTES >> 20} MB left out of git")
        verdict = dict(schema="opentallas.closure_loop.verdict.v1", job=j["name"], block=spec["block"],
                       owner=spec["owner"], source_branch=source_branch, record_branch=branch, source_commit=j["commit_full"],
                       host=j["host"], run_dir=j["run"], acceptance=dict(setup_corner=setup_corner_label(metrics), setup_min_ps=SS_MIN, ff_min_ps=FF_MIN, drc=0, clock_periods_ps=metrics.get("clock_periods_ps"),
                       rule="OWNER 2026-10-08: TT setup >= 0 / FF hold >= 0; SS sensitivity (60/25 uncertainties; +15 design target), "
                            "agreed die-clock IO budgets, DRC 0"),
                       metrics={k: metrics.get(k) for k in ("ss_ps", "ff_ps", "drc", "ss_tns_ps", "clock_periods_ps", "setup_corner", "ss_sensitivity_ps", "ss_sensitivity_tns_ps", "corner_sta_tt", "post_sdc", "corner_sta",
                                                            "drc_metrics", "drc_skipped")},
                       benches=j.get("benches", {}), fail_witnesses={k: dict(w, path=f"{rec_dir}/fail_witness/{label(k)}.log")
                                                                     for k, w in (j.get("fail_witnesses") or {}).items()},
                       no_bench_reason=spec.get("no_bench_reason"),
                       checks=j.get("checks", {}), submit_checks=j.get("submit_checks"), calibration=j.get("calibration"), route_overlay_plan=j.get("route_overlay_plan"), cycles_added=spec.get("cycles_added"), status="CLOSED",
                       closed_at=now_iso(), job_spec=spec, io_budget=(j.get("rebudget") or {}).get("rb") or "link_budget_consistent (fixed split)",
                       rebudget=j.get("rebudget"))
        if plat:
            verdict["port_latency"] = dict(paths=plat_paths, sha256=hashlib.sha256(
                (cwt / plat_paths[0]).read_bytes()).hexdigest(), schema=plat[1]["schema"])
        if j.get("export_lint_recovery"):
            verdict["export_lint_recovery"] = j["export_lint_recovery"]
        (cwt / rec_dir / "verdict.json").write_text(json.dumps(verdict, indent=1) + "\n")
        git("add", "--sparse", "--", *tos, cwd=cwt)
        staged = sh(["git", "-C", str(cwt), "diff", "--cached", "--name-only"], timeout=120).stdout.split()
        msg = (f"closure-loop: {spec['block']} CLOSED {setup_corner_label(metrics)} {metrics['ss_ps']:+.2f} / FF {metrics['ff_ps']:+.2f} ps DRC "
               f"{metrics['drc']}{setup_sensitivity_text(metrics)} {measured_clock_text(metrics)} (source {j['commit_full'][:9]}, {host_cfg(j['host'])['label']} "
               f"{j['run']}); job {j['name']}, owner {spec['owner']}\n\nCo-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>\n")
        if staged:
            git("-c", "user.name=OpenTallas closure-loop", "-c", "user.email=boj@01.me", "commit", "-q", "-m", msg,
                cwd=cwt)
        out["record_branch"] = branch
        out["branch_commit"] = git("rev-parse", "HEAD", cwd=cwt).stdout.strip()
        out["files"] = len(staged)
        if dry:
            break
        p = sh(["git", "-C", str(cwt), "push", "-q", "origin", f"HEAD:refs/heads/{branch}"], timeout=900)
        if p.returncode == 0:
            break
        log(f"[{j['name']}] push to {branch} rejected (attempt {attempt}); refetch: {p.stderr[-300:]}")
    else:
        raise RuntimeError(f"could not push the record to {branch}")
    wt_rm(cwt)
    if claude_owns_main() and auto_merge_policy():
        try:
            out["merge"] = auto_merge_closure(j, out, tos, dry)
        except Exception as ex:  # noqa: BLE001
            out["merge"] = f"AUTO-MERGE error: {type(ex).__name__}: {str(ex)[:200]}"
            append_locked(AUTO_MERGE_PENDING, f"- {now_iso()} {j['name']}: {out['merge']}\n")
        if out["merge"].startswith("AUTO-MERGED"):
            return out
        notify_claude_record(j["name"], branch, out["branch_commit"])
        return out
    if target:
        return merge_record(j, out, sparse, dry)
    out["merge"] = "no merge target"
    if claude_owns_main():
        notify_claude_record(j["name"], branch, out["branch_commit"])
    return out


# ------------------------------------------------------------------------------------------------ ledger/status
def ledger(j, text):
    spec = j["spec"]
    c = str(spec.get("source", {}).get("commit", "?"))[:9]
    where = f"{host_cfg(j['host'])['label']}:{j['run']}" if j.get("host") else "-"
    if not LEDGER.exists():
        append_locked(LEDGER, "# CLOSURE LOOP LEDGER (tools/closure_loop; one line per verdict, newest last)\n"
                              "Format: time | job | block @ source commit | verdict | host:run dir | detail\n\n")
    first, *rest = text.split("\n")
    append_locked(LEDGER, f"- {now_iso()} | {j['name']} | {spec.get('block', '?')} @ {c} | {first} | {where}\n"
                  + "".join(f"    {x}\n" for x in rest if x))


def write_status(fleet_note="", fleet=None):
    rows = all_jobs()
    act = [r for r in rows if r["status"] not in TERMINAL]
    done = [r for r in rows if r["status"] in TERMINAL][-25:]
    L = [f"# CLOSURE LOOP STATUS (auto, {now_iso()}; daemon tools/closure_loop/closure_loop.py, unit closure-loop.service)",
         f"Active {len(act)} | terminal {len(rows) - len(act)} | ledger {LEDGER} | how-to {REVIEW}/CLOSURE_LOOP_HOWTO.md",
         fleet_note, "", "## Active"]
    for r in act:
        h = host_label(r.get("host"))
        stage = r.get("stage_key", "-")
        if r["status"] == "READY":
            stages = stage_list(r["spec"])
            stage = stages[min(r.get("stage_idx", 0), len(stages) - 1)]["key"]
        L.append(f"- {r['name']} [{r['spec']['block']}] {r['status']} stage={stage} host={h} "
                 f"run={r.get('run', '-')} since={r.get('stage_started', r['created'])} "
                 f"{('| ' + r['wait']) if r.get('wait') else ''}")
    L += ["", "## Recent terminal"]
    for r in done:
        L.append(f"- {r['name']} [{r['spec'].get('block', '?')}] {r['status']} {r.get('reason', '')[:200]}")
    fl = ["", "## Fleet (measured load1, MemAvailable; admission: load1 + own launches of last 10 min <= 3 x cores, "
          "free RAM >= peak + max(5% RAM, 32 GB))"]
    for h in hosts_table():
        # Status reporting reads the admission probe the job threads already took; the main thread
        # never opens ssh (it blocked tick() on an exhausted EPYC3 lease pool 2026-10-10 06:03-06:2x).
        good = getattr(fleet, "last_good", {}).get(h["name"]) if fleet is not None else None
        try:
            if good is not None and time.time() - good[0] < PROBE_LAST_GOOD_S:
                v, ld = ["", str(good[1]["mem_gb"])], float(good[1]["load1"])
            else:   # no fresh probe: a bounded read (lease wait included), never an unbounded park
                r = ssh(h["name"], "cut -d' ' -f1 /proc/loadavg; awk '/MemAvailable/{print int($2/1048576)}' /proc/meminfo", timeout=30)
                v = r.stdout.split() if r.returncode == 0 else []
                ld = float(v[0]) if len(v) == 2 else None
        except (subprocess.TimeoutExpired, OSError, ValueError):
            # Fleet reporting must never terminate the coordinator or prevent
            # the next intake tick because one SSH peer is unavailable.
            v, ld = [], None
        if ld is not None:
            running = sum(1 for x in act if x.get("host") == h["name"] and
                          x["status"] in ("RUNNING", "ECO", "SUMMARY", "ECO_INSTALL"))
            benches = sum(1 for x in act for b in (x.get("btrack") or {}).values()
                          if b.get("host") == h["name"] and b.get("state") == "running")
            fl.append(f"- {h['label']}: load1 {ld:.0f}/{h['cores']} threads (idle {max(0, 100 * (1 - ld / h['cores'])):.0f}%), "
                      f"{v[1]} GB free of {h.get('ram_gb', '?')}, own active stages {running}, parallel benches {benches}")
        else:
            fl.append(f"- {h['label']}: unreachable")
    L[3:3] = fl
    tmp = STATUS_MD.with_suffix(".tmp")
    tmp.write_text("\n".join(L) + "\n")
    os.replace(tmp, STATUS_MD)


# ------------------------------------------------------------------------------------------------ state machine
def finish(j, status, reason, ledger_text):
    status, reason, ledger_text = lost_closed_finish(j, status, reason, ledger_text)
    j["status"], j["reason"] = status, reason
    j["finished_at"] = now_iso()       # LOOP-AUTO: the auto-react / READY_NEXT pass judges each finish once
    event(j, f"{status}: {reason}")
    if j.get("structure_exempt") and status not in ("CANCELLED", "REFUSED", "INVALID"):
        ledger_text = f"{ledger_text}\n[structure-repeat {j['structure_exempt']}]"    # the exemption is in the verdict
        event(j, f"verdict note: structure-repeat {j['structure_exempt']}")
    ledger(j, ledger_text)
    term = {"CLOSED": "completed: CLOSED", "NEEDS_RTL": "failed: NEEDS_RTL", "NEEDS_HUMAN": "failed: NEEDS_HUMAN",
            "NEEDS_BUDGET": "failed: NEEDS_BUDGET", "CANCELLED": "cancelled"}.get(status, "stopped: " + status)
    experiment(j, f"{term} {reason[:120]}")
    if status == "CLOSED":
        try:
            cancel_queued_siblings(j)
        except Exception:  # noqa: BLE001
            log(f"[{j['name']}] sibling cancel error:\n{traceback.format_exc()}")
        viz_elem_export(j)
        os.environ.get("CL_CLOSED_ARCHIVE", "1") != "0" and os.path.exists(CLOSED_ARCHIVE_HOOK) and os.system(f"setsid -f {CLOSED_ARCHIVE_HOOK} {shlex.quote(j['name'])} >/dev/null 2>&1 </dev/null")  # closed-archive-1011


# SIBLING CANCEL (2026-10-13 finishing recipe: route up to 3 variants in parallel, take the first that closes).  When a
# job CLOSES, every other job of the same block@commit that has not launched its route (QUEUED / SYNC / READY, no route
# key taken; a bench track still running ends on its own) is CANCELLED with reason "sibling <name> CLOSED".  Running siblings are
# left to finish; their data goes as superseded (release_bulk / release_deep: the block is closed).
def cancel_queued_siblings(j):
    spec = j["spec"]
    block, commit = spec.get("block"), str((spec.get("source") or {}).get("commit") or "")[:12]
    if not block or not commit:
        return []
    held = route_keys().get(f"{block}@{commit}", [])
    out = []
    for x in all_jobs():
        xs = x["spec"]
        if (x["name"] == j["name"] or x["status"] not in ("QUEUED", "SYNC", "READY") or xs.get("block") != block
                or str((xs.get("source") or {}).get("commit") or "")[:12] != commit or x["name"] in held):
            continue
        with job_lock(x["name"]):
            y = load_job(x["name"])
            if y["status"] not in ("QUEUED", "SYNC", "READY"):      # RUNNING is the only status with a live stage
                continue
            y.update(status="CANCELLED", reason=f"sibling {j['name']} CLOSED", cancelled_at=now_iso())
            y["finished_at"] = y["cancelled_at"]
            event(y, f"CANCELLED: sibling {j['name']} CLOSED ({block}@{commit}); route never launched")
            ledger(y, f"CANCELLED (loop): sibling {j['name']} CLOSED the block at the same commit; no route spent")
            save_job(y)
            out.append(y["name"])
    if out:
        event(j, f"queued siblings cancelled: {', '.join(out)}")
    return out


# VIZ-ELEM (owner 2026-10-10, viz-elem-1010): every CLOSED job gets its Chip Explorer element page.  finish() starts
# tools/explorer_elem_export.py auto --job <name> detached (own session, nice 19; the heavy OpenROAD export runs on the
# job's host under ot-heavy), so a closure never waits on it and an exporter failure only lands in its marker
# ~/.local/state/viz-elem/<job>.json and VIZ_ELEM_LOG.  Deep release keeps the run dir while the marker says running.
# CL_VIZ_ELEM=0 disables.  Backlog / retries: explorer_elem_export.py batch.
VIZ_ELEM_MARKS = Path.home() / ".local/state/viz-elem"
CLOSED_ARCHIVE_HOOK = "/home/ubuntu/closed_archive/_tools/hook.sh"   # closed-archive-1011: archives every CLOSED job's final files
VIZ_ELEM_LOG = STATE / "viz_elem.log"


def viz_elem_export(j):
    if os.environ.get("CL_VIZ_ELEM", "1") == "0" or not j.get("host") or not j.get("run"):
        return
    tool = HERE.parent / "explorer_elem_export.py"
    if not tool.exists():
        return
    try:
        VIZ_ELEM_MARKS.mkdir(parents=True, exist_ok=True)
        (VIZ_ELEM_MARKS / (j["name"] + ".json")).write_text(json.dumps(dict(state="running", queued_by="closure_loop",
                                                                            updated=now_iso())))
        with open(VIZ_ELEM_LOG, "a") as lg:
            lg.write(f"{now_iso()} {j['name']}: export started\n")
            lg.flush()
            subprocess.Popen(["nice", "-n", "19", sys.executable, str(tool), "auto", "--job", j["name"]],
                             stdout=lg, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True,
                             env=dict(os.environ, CL_REPO=str(REPO)))
        event(j, "viz-elem: element page export started (explorer_elem_export.py auto)")
        if (lvh := Path.home() / ".local/share/fleet-viz/layout_viewer/lv_post_record.sh").exists(): subprocess.Popen([str(lvh), j["name"]], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)  # layout viewer static export (layout-viewer-1011)
    except Exception as e:      # never into the caller
        event(j, f"viz-elem: export not started ({type(e).__name__}: {str(e)[:120]})")


def viz_elem_running(j):
    try:
        m = json.loads((VIZ_ELEM_MARKS / (j["name"] + ".json")).read_text())
    except (OSError, ValueError):
        return False
    if m.get("state") != "running":
        return False
    try:                        # a marker older than 12 h is a dead exporter, not a live one
        return (dt.datetime.now(dt.timezone.utc) - dt.datetime.fromisoformat(m.get("updated"))).total_seconds() < 12 * 3600
    except (TypeError, ValueError):
        return False


def preserve_completed_route(j, st, why):
    """Stop infrastructure repair at the existing route; never turn it into a reroute."""
    if st["kind"] != "route":
        return False
    v = j["spec"].get("verdict", {})
    if not v.get("corner_sta") or not v.get("drc_metrics"):
        return False
    root = str(Path(subst(v["corner_sta"], j)).parent)
    metrics = subst(v["drc_metrics"], j)
    if "/logs/" not in metrics:
        return False
    base = str(Path(metrics.replace("/logs/", "/results/", 1)).parent)
    config = dict(route_root=root, odb_patterns=[base + "/6_final.odb", base + "/5_2_route.odb"])
    r = ssh(j["host"], postroute_probe_command(config), timeout=60)
    try:
        if r.returncode:
            raise ValueError(f"probe exited {r.returncode}")
        evidence = json.loads(r.stdout)
    except (ValueError, TypeError):
        j["wait"] = "completed-route evidence unavailable; retry read before crash recovery"
        return True
    if evidence is None:
        return False
    j["postroute_repair"] = dict(host=j["host"], run=j["run"], stage=j["stage_tag"],
                                source_commit=j.get("commit_full"), evidence=evidence, failure=why)
    j["wait"] = None
    finish(j, "NEEDS_HUMAN", "post-route helper failed; completed physical artifacts preserved",
           "NEEDS_HUMAN: repair post-route helper and resume diagnostics against existing route; "
           "no automatic reroute or migration\n" + ", ".join(x["path"] for x in evidence["helper_errors"]))
    return True


def stage_output_dirs(j, st):
    """the directories a stage writes: spec "out_dir" (str or list, placeholders allowed), else for calibrate / route the
    loop's {RUN}/routes/{LABEL}[_cal] convention"""
    out = st.get("out_dir")
    if out:
        return [subst(d, j) for d in ([out] if isinstance(out, str) else out)]
    if st["kind"] in ("calibrate", "route"):
        return [f"{j['run']}/routes/{label(j['name'])}{'_cal' if st['kind'] == 'calibrate' else ''}"]
    # EXPORT-ASIDE (ROOT 2026-10-16, qkd_rlys_1-v1-838dc5048): a retried ref_tile collect re-exported into the same
    # views dir and export_provenance refused it ('existing provenance: use a fresh export directory'), so EVERY
    # failed first collect became NEEDS_HUMAN on the retry.  The export --out dir is the stage's output.
    m = re.search(r"ref_tile\.py export\b[^&;|>]*?--out\s+(\S+)", st.get("cmd") or "")
    if m:
        return [subst(m.group(1), j)]
    return []


def retry_aside(j, st):
    """LOOP-GAPS 2026-10-08: a re-run of a killed / crashed stage (same-host retry, restart) moves the previous attempt's
    output aside as <dir>.attempt<N> (kept as evidence) so the relaunch starts clean: a leftover prep/ masked core_p's
    real error with FileExistsError (flow-triage 10-07), s81 route_view.sh refused existing evidence (rc=73)."""
    prev = j["attempt"] - 1
    return "".join(f"if [ -e {shlex.quote(d)} ]; then a={shlex.quote(f'{d}.attempt{prev}')}; [ -e \"$a\" ] && "
                   f"a=\"$a.$(date +%s)\"; mv {shlex.quote(d)} \"$a\"; fi\n" for d in stage_output_dirs(j, st))


# CRASH-TRIAGE 2026-10-08: twelve routes went NEEDS_HUMAN as "crashed twice (rc=1 ok-check failed: ; ...)" while the
# real errors (yosys Assert, syntax error, [ERROR ODB-0239], a hook's "no room on S", a FileNotFoundError) sat in
# routes/<label>/flow.log, run.log, sta.log, prep/yosys.log or the ORFS step logs.  first_error() reads them on the
# host and returns the first real error line (plus the failing make step) for the crash events and the verdict.
FIRST_ERROR_PY = r"""
import glob, os, re, sys
dirs = sys.argv[1:]
STRONG = re.compile(r"(ERROR: .*|Assert `.*|\[ERROR [A-Z]+-\d+\].*|^Error: .*|.*syntax error.*|^FAILED: .*|"
                    r"^[A-Za-z_.]*(Error|Exception): .*|.*refus(es|ed) .*|.*Killed.*|.*Segmentation fault.*|.*core dumped.*)")
GENERIC = re.compile(r"FlowError: .*(failed with exit|failed)\s*\d*:?\s*$")
MAKE = re.compile(r"\*\*\* \[[^\]]*: (do-[\w.]+)\] Error")
def files(d, late):
    if late:
        return [p for p in (os.path.join(d, n) for n in ("sta.log", "corner.log", "STATUS")) if os.path.isfile(p)]
    pri = [os.path.join(d, n) for n in ("flow.log", "run.log", "prep/yosys.log")]
    orfs = sorted(glob.glob(os.path.join(d, "work/orfs/logs/*/*/*/*.log")) + glob.glob(os.path.join(d, "work/*.log")),
                  key=lambda p: os.path.getmtime(p), reverse=True)[:3]
    return [p for p in pri + orfs if os.path.isfile(p)]
found, step, generic = [], "", ""
def scan(late):
  global step, generic
  for d in dirs:
    for p in files(d, late):
        try:
            lines = open(p, errors="replace").read().splitlines()[-20000:]
        except OSError:
            continue
        for i, ln in enumerate(lines):
            m = MAKE.search(ln)
            if m and not step:
                step = m.group(1)
            t = ln.strip()
            if not t or "WARNING" in t[:12] or t.startswith("Warning"):
                continue
            if t.startswith("Traceback (most recent call last)"):
                tb = next((x.strip() for x in lines[i + 1:i + 200] if re.match(r"^[A-Za-z_.]*(Error|Exception|Exit)\b", x)), "")
                if tb:
                    found.append((p, tb))
                continue
            if GENERIC.search(t):
                generic = generic or t
                continue
            if STRONG.search(t):
                found.append((p, t))
        if found:
            return
scan(False)
if not found:
    # no error-shaped line: a failed flow's own last word (run_abi3_physical refusals print a bare sentence, e.g.
    # "--memory-macro is a place-and-route option ... run --stages pnr"), unless the status says the flow passed
    for d in dirs:
        st = os.path.join(d, "status")
        if os.path.isfile(st) and re.search(r"^flow_rc=0$", open(st, errors="replace").read(), re.M):
            continue
        for n in ("flow.log", "run.log"):
            p = os.path.join(d, n)
            if os.path.isfile(p):
                last = [x.strip() for x in open(p, errors="replace").read().splitlines()[-50:] if x.strip()]
                if last:
                    found.append((p, last[-1]))
                    break
        if found:
            break
if not found:
    scan(True)
if found:
    p, t = found[0]
    print(f"{os.path.relpath(p, os.path.dirname(dirs[0]))}: {t[:240]}" + (f" [step {step}]" if step else ""))
elif generic or step:
    print((generic[:240] + " " if generic else "") + (f"[step {step}]" if step else ""))
"""


def first_error(j, st):
    """The first real error line of a crashed stage, read on its host ('' when none is found or the host is down)."""
    dirs = stage_output_dirs(j, st)
    if not dirs:
        return ""
    try:
        r = ssh(j["host"], "python3 - " + " ".join(shlex.quote(d) for d in dirs), timeout=120, input=FIRST_ERROR_PY)
    except Exception:  # noqa: BLE001 - diagnostics must never turn a crash into a daemon error
        return ""
    return r.stdout.strip().splitlines()[-1][:400] if r.returncode == 0 and r.stdout.strip() else ""


def crash(j, st, fleet, why):
    if st["kind"] in POST_ROUTE_KINDS:     # LOST-CLOSED (ROOT-1130): retry only that stage on the routed state
        postroute_crash(j, st, fleet, why)
        return
    if st["kind"] in ("route", "calibrate"):
        try:
            textbook_note(j, force=True)
        except Exception:  # noqa: BLE001
            pass
    if preserve_completed_route(j, st, why):
        return
    if st["kind"] in ("calibrate", "route") and j.get("stage_tag") and j.get("host"):
        txt = fp_lint_failed(j["host"], j["run"], j["stage_tag"])
        if txt:
            fp_lint_finish(j, j["stage_tag"], txt)
            return
    if st["kind"] == "route" and j.get("stage_tag") and j.get("host"):
        txt = preroute_failed(j["host"], j["run"], j["stage_tag"])
        if txt:
            preroute_finish(j, j["stage_tag"], txt)
            return
    tail = stage_tail(j, st) if j.get("stage_tag") else ""
    m = re.search(r"CALIBRATE_FAIL class=(\S+) detail=(.*)", tail)
    if st["kind"] == "calibrate" and m and m.group(1) in CAL_OWNER_ACTION:
        j.setdefault("crashes", []).append(dict(stage=st["key"], host=j["host"], attempt=j["attempt"], why=why,
                                                resource=False, cls=m.group(1), tail=tail[-1500:]))
        act = CAL_OWNER_ACTION[m.group(1)]
        finish(j, "NEEDS_HUMAN", f"calibrate {m.group(1)}: {act}"[:300],
               f"NEEDS_HUMAN: calibrate failed, class {m.group(1)} (deterministic, not retried)\n"
               f"detail: {m.group(2).strip()[:200]}\nOWNER ACTION ({j['spec'].get('owner')}): {act}")
        return
    err = first_error(j, st) if st["kind"] != "bench" else ""
    if err:
        why = re.sub(r"ok-check failed: *(;|$)", "ok-check failed;", why)
        why = f"{why}; first error: {err}"
    if st["kind"] == "route" and re.search(r"GRT-0116|GRT-0232", err + tail) and not why.startswith("LOST"):
        # stuckscan 2026-10-08: GRT gave up with congestion -- deterministic for this floorplan; a retry re-spends the
        # whole route (hbm_coll_port_big/rows, s81b-vm_bgh-grid: 'retry once on the same host')
        finish(j, "EARLY_FAIL_CONGESTION", f"global route finished with congestion (GRT-0116): {err[:200]}",
               f"EARLY_FAIL_CONGESTION: GRT-0116, not retried (deterministic). Fix the floorplan (util/channels/pins); "
               f"congestion reports in the route's reports dir.\n{err[:300]}")
        return
    resource = bool(RESOURCE_RE.search(tail + " " + err)) or why.startswith(("LOST", "bench tool crash"))
    j.setdefault("crashes", []).append(dict(stage=st["key"], host=j["host"], attempt=j["attempt"], why=why,
                                            resource=resource, tail=tail[-1500:], first_error=err))
    det = DETERMINISTIC_ROUTE_ERR_RE.search(err) if st["kind"] == "route" and not resource else None
    if det:
        # DETERMINISTIC-NO-RETRY 2026-10-15 (ROOT): daemon.log 10-06..10-15, every same-input retry of these first
        # errors failed again with the same error (DPL-0033 30/30+, GPL-0305 15/15, PPL-0093 14/14, ANT-0008 11/11,
        # PDN-0233 9/9, MPL-0020 7/7, PPL-0111 6/6, STA-0340 5/5): a retry re-spent the whole route for nothing.
        finish(j, "NEEDS_HUMAN", f"{st['key']} failed deterministically ({det.group(0)}), not retried: {err[:300]}",
               f"NEEDS_HUMAN: {st['key']} first error {det.group(0)} is deterministic for these inputs (measured: every "
               f"same-input retry failed again); fix the kit/floorplan and resubmit.\n{err[:300]}")
        return
    if j["retries_used"] >= 1:
        finish(j, "NEEDS_HUMAN", f"{st['key']} crashed twice ({why}; resource={resource})"[:600],
               f"NEEDS_HUMAN: {st['key']} crashed twice ({why}); last log tail:\n" +
               "\n".join(tail.strip().splitlines()[-6:]))
        return
    j["retries_used"] = 1
    j["attempt"] += 1
    if resource and not checkpoint_location(j):
        h, _ = fleet.choose(j["spec"], exclude=j["hosts_tried"])
        if h:
            event(j, f"{st['key']} crashed ({why}); resource-related -> retry once on {host_cfg(h)['label']}")
            j["hosts_tried"].append(h)
            j["host"], j["run"] = h, f"{run_base(h)}/{j['name']}"
            j["status"] = "SYNC"
            # Keep existing bench receipts; the bench chain retains its producer host/run.
            # Resume the migrated physical track at its first non-bench stage.
            stl = stage_list(j["spec"])
            j["stage_idx"] = next(i for i, s in enumerate(stl) if s["kind"] != "bench")
            return
        event(j, f"{st['key']} crashed ({why}); resource-related but no other host fits now -> retry on the same host")
    else:
        event(j, f"{st['key']} crashed ({why}) -> retry once on the same host")
    j["status"] = "READY"


# LOST-CLOSED (ROOT-1130 2026-10-18, PL-SEQ / S81-SHLK): dsdv_sh_lk-dsdv_sh_lk-ef442ffba CLOSED its route after the
# VT-swap ECO (TT +11.04 / FF +8.14, 0.074 % LVT) on ot-epyc5; earlyoom then SIGTERMed the 31-MB collect export
# (rc 143, host at 3 % free memory from an agent's ~90-GB Verilator builds).  crash() treated it like a route crash:
# "resource-related -> retry once on AGIdock" re-ROUTED from scratch there, the stale installed-ECO record made the
# VT-swap ineligible, and the job ended NEEDS_RTL at TT -36.2 -- a closed result lost.  Now:
#   1. a crash of a post-route stage (collect / export) retries ONLY that stage, on the host that holds the routed /
#      ECO'd state (POSTROUTE_RETRY_MAX times, then a human stop that names the preserved state); never a re-route, and
#      host moves (capacity, transient ssh, load rebalance) never take a job past its verdict off its host;
#   2. when the routed state is truly gone the re-route retires the old ECO record and re-applies the recorded ECO
#      (the exact VT-swap cell list, copied to STATE/eco_lists at closure time) before judging;
#   3. any non-CLOSED finish of a job that had a CLOSED verdict is reported as LOST_CLOSED ("lost closed result ..."),
#      never NEEDS_RTL; `resume-postroute NAME` re-judges it on its preserved routed state (copying it when the host
#      changes) and `lost-closed-scan` lists / resumes such jobs.
POST_ROUTE_KINDS = ("collect", "export")
POSTROUTE_RETRY_MAX = 3
LOST_CLOSED = "LOST_CLOSED"
LEGACY_CLOSED_RE = re.compile(r"launched (collect|export) \(attempt (\d+)\) on (\S+)")


def at_post_route(j, stl=None):
    """the job is past a CLOSED verdict (collect / export / commit): its evidence is the routed state on its host"""
    stl = stl or stage_list(j["spec"])
    idx = j.get("stage_idx", 0)
    if not 0 <= idx < len(stl):
        return False
    ver = next((i for i, s in enumerate(stl) if s["kind"] == "verdict"), None)
    return stl[idx]["kind"] in (*POST_ROUTE_KINDS, "commit") or (ver is not None and idx > ver)


def earlier_closed(j):
    """the job's CLOSED verdicts: recorded closed_attempts, else (records before ROOT-1130) the post-verdict stage
    launches in its events (collect / export launch only after a CLOSED verdict)"""
    if j.get("closed_attempts"):
        return list(j["closed_attempts"])
    out, seen = [], set()
    for e in j.get("events") or []:
        m = LEGACY_CLOSED_RE.search(e)
        if m and m.group(2) not in seen:
            seen.add(m.group(2))
            out.append(dict(attempt=int(m.group(2)), host=m.group(3), at=e.split(" ", 1)[0], legacy=True))
    return out


def route_bases_glob(j, run):
    v = (j["spec"].get("verdict") or {}).get("drc_metrics") or ""
    if "/logs/" not in v:
        return None
    jj = dict(j, run=run)
    return str(Path(subst(v, jj).replace("/logs/", "/results/", 1)).parent)


def routed_state(j, host=None, run=None):
    """probe the routed (and ECO-installed) state of a job: dict(present, base, eco_installed) or None (unreachable)"""
    host, run = host or j.get("host"), run or j.get("run")
    if not host or not run:
        return dict(present=False, base=None, eco_installed=False)
    g = route_bases_glob(j, run)
    if g:
        script = (f"for b in $(ls -d {g} 2>/dev/null); do [ -s $b/6_final.odb ] && echo \"ODB $b\" && "
                  f"{{ [ -e $b/6_final.odb.pre_eco ] && echo PRE_ECO; }}; done; echo PROBE_OK")
    else:
        script = f"[ -n \"$(ls -A {shlex.quote(run)}/routes 2>/dev/null)\" ] && echo \"ODB {run}/routes\"; echo PROBE_OK"
    try:
        r = ssh(host, script, timeout=60)
    except Exception:  # noqa: BLE001 - an unreachable host is not a lost state
        return None
    if r.returncode or "PROBE_OK" not in r.stdout:
        return None
    m = re.search(r"^ODB (\S+)", r.stdout, re.M)
    return dict(present=bool(m), base=m.group(1) if m else None, eco_installed="PRE_ECO" in r.stdout)


def eco_list_dir(j):
    return STATE / "eco_lists" / re.sub(r"[^A-Za-z0-9_.-]", "_", j["name"])


def save_eco_list(j):
    """copy the installed VT-swap ECO's cell list (inst master per line) to local state: it must outlive the host"""
    e = j.get("eco") or {}
    if e.get("kind") != "vtswap" or not e.get("out"):
        return None
    try:
        r = ssh(j["host"], f"cat $(ls {shlex.quote(e['out'])}/pass1/orfs/results/asap7/*/base/vtswap_cells.txt "
                           f"2>/dev/null | tail -1) 2>/dev/null", timeout=60)
    except Exception:  # noqa: BLE001
        return None
    txt = r.stdout if r.returncode == 0 else ""
    if not re.search(r"^\S+ \S+_ASAP7_75t_L$", txt, re.M):
        return None
    d = eco_list_dir(j)
    d.mkdir(parents=True, exist_ok=True)
    p = d / f"vtswap_a{j['attempt']}.txt"
    p.write_text(txt)
    e["swap_list"] = str(p)
    return str(p)


def note_closed(j, m):
    """record a CLOSED verdict (attempt, host/run, numbers, the installed ECO and its saved cell list)"""
    e = j.get("eco") or {}
    rec = dict(attempt=j["attempt"], route_attempt=j.get("route_attempt"), host=j["host"], run=j["run"], at=now_iso(),
               tt=m.get("ss_ps"), ff=m.get("ff_ps"), drc=m.get("drc"))
    if e.get("installed"):
        lst = e.get("swap_list") or save_eco_list(j)
        rec["eco"] = dict(kind=e.get("kind"), out=e.get("out"), target_ps=e.get("target_ps"),
                          lvt_cap_pct=e.get("lvt_cap_pct"), swap_list=lst,
                          lvt_swapped=(e.get("result") or {}).get("lvt_swapped"))
        rec["eco_record"] = json.loads(json.dumps(e))
    j.setdefault("closed_attempts", []).append(rec)
    return rec


def retire_eco_for_reroute(j):
    """a new route replaces the routed db: the previous route's ECO records must not judge it (the stale installed
    VT-swap blocked the VT-swap on ef442ffba's re-route).  Keep them as eco_prior_routes; when an earlier attempt CLOSED
    with an ECO, re-apply that recorded ECO on the new route (reapply_eco)."""
    old = [x for x in [*(j.get("eco_history") or []), j.get("eco")] if x]
    if not old and not j.get("eco_stack"):
        return False
    j.setdefault("eco_prior_routes", []).append(dict(attempt=j["attempt"], at=now_iso(), ecos=old,
                                                     eco_stack=j.get("eco_stack")))
    for k in ("eco", "eco_history", "eco_stack"):
        j.pop(k, None)
    closed = [c for c in earlier_closed(j) if c.get("eco")]
    if closed and not j.get("reapply_eco"):
        j["reapply_eco"] = dict(closed[-1]["eco"], from_attempt=closed[-1]["attempt"])
    elif earlier_closed(j) and not j.get("reapply_eco"):
        # a record from before ROOT-1130: the closing ECO is the installed one among the retired records
        inst = [x for x in old if x.get("installed") and eco_passes(x.get("result"), x.get("rc", 0))]
        if inst:
            x = inst[-1]
            j["reapply_eco"] = dict(kind=x.get("kind"), out=x.get("out"), target_ps=x.get("target_ps"),
                                    lvt_cap_pct=x.get("lvt_cap_pct"), swap_list=x.get("swap_list"),
                                    lvt_swapped=(x.get("result") or {}).get("lvt_swapped"),
                                    from_attempt=earlier_closed(j)[-1]["attempt"])
    event(j, f"re-route: retired {len(old)} ECO record(s) of the replaced route"
             + (f"; will re-apply the closed attempt {j['reapply_eco']['from_attempt']}'s {j['reapply_eco']['kind']} ECO"
                if j.get("reapply_eco") else ""))
    return True


def copy_routed_state(j, src_host, src_run, dst_host, dst_run, timeout=7200):
    """stream the routed state (routes/ cl/ record/) from one host to another (tar over two ssh pipes)"""
    def argv(h, cmd):
        return ["bash", "-c", cmd] if is_local(h) else \
            ["ssh", "-o", "BatchMode=yes", "-o", "ControlPath=none", "-o", "ConnectTimeout=15", h, cmd]
    src = subprocess.Popen(argv(src_host, f"cd {shlex.quote(src_run)} && tar -cf - $(ls -d routes cl record 2>/dev/null)"),
                           stdout=subprocess.PIPE)
    dst = subprocess.run(argv(dst_host, f"mkdir -p {shlex.quote(dst_run)} && tar -C {shlex.quote(dst_run)} -xf -"),
                         stdin=src.stdout, timeout=timeout)
    src.stdout.close()
    src.wait(timeout=600)
    if src.returncode or dst.returncode:
        raise RuntimeError(f"routed-state copy {src_host}:{src_run} -> {dst_host}:{dst_run} failed "
                           f"(rc {src.returncode}/{dst.returncode})")


def postroute_crash(j, st, fleet, why):
    """(1) a post-route stage crashed: retry ONLY that stage on the routed state's host; never re-route"""
    tail = stage_tail(j, st) if j.get("stage_tag") else ""
    j.setdefault("crashes", []).append(dict(stage=st["key"], host=j["host"], attempt=j["attempt"], why=why,
                                            resource=bool(RESOURCE_RE.search(tail)) or "143" in why, postroute=True,
                                            tail=tail[-1500:]))
    state = routed_state(j)
    n = j.get("postroute_retries", 0)
    where = f"{j['host']}:{j['run']}"
    if state is not None and not state["present"]:
        event(j, f"post-route {st['key']} crashed ({why}) and the routed state is GONE from {where}: re-route with the "
                 f"recorded ECO re-applied before judging")
        retire_eco_for_reroute(j)
        stl = stage_list(j["spec"])
        j["stage_idx"] = next(i for i, s in enumerate(stl) if s["kind"] in ("calibrate", "route"))
        j["attempt"] += 1
        j["status"] = "SYNC"
        return
    # EXPORT-LINT REPEAT (RLYH0-NE 2026-10-19): a collect whose export fails child_lint is not a crash; the same lint
    # FAIL on the same frozen helpers repeats on every retry (qfwd_rlyh0_128_ne_65x30-f1-fc2236d82: 4 identical
    # '(i) pin access' collects).  Stop at the first repeat and name the lint.
    lint = re.search(r"child_lint FAIL[^\n]{0,400}", tail or "")
    prev = [x for x in j["crashes"][:-1] if x.get("postroute") and x.get("stage") == st["key"]]
    if lint and prev and lint.group(0)[:200] in (prev[-1].get("tail") or ""):
        why = f"export {lint.group(0)[:300]} (identical on retry: deterministic, not a crash)"
        n = POSTROUTE_RETRY_MAX
    if n >= POSTROUTE_RETRY_MAX:
        c = (earlier_closed(j) or [{}])[-1]
        j["lost_closed"] = dict(closed=c, later_status="NEEDS_HUMAN", later_reason=why, at=now_iso(), preserved=where)
        finish(j, LOST_CLOSED, f"lost closed result: post-route {st['key']} crashed {n + 1}x ({why}); routed state "
                               f"preserved at {where}"[:600],
               f"LOST_CLOSED: post-route {st['key']} crashed {n + 1} times ({why}); the routed/ECO'd state is kept at "
               f"{where}; fix the stage and run `closure_loop.py resume-postroute {j['name']}`.\n"
               + "\n".join(tail.strip().splitlines()[-6:]))
        return
    j["postroute_retries"] = n + 1
    j["attempt"] += 1
    j["status"] = "READY"
    event(j, f"post-route {st['key']} crashed ({why}): routed state "
             f"{'intact' if state else 'on an unreachable host'} at {where} -> retry ONLY {st['key']} there "
             f"({n + 1}/{POSTROUTE_RETRY_MAX}; no re-route, no host move)")


def closure_lost(j):
    """the last CLOSED verdict when the job has since replaced that route (re-route / re-calibrate), else None.  A
    judgement on the closed route itself (CHILD-LINT of its exported view) is not a lost closure."""
    closed = earlier_closed(j)
    if not closed:
        return None
    c = closed[-1]
    if c.get("route_attempt") is not None:
        return c if j.get("route_attempt") not in (None, c["route_attempt"]) else None
    ev = j.get("events") or []
    last = max((i for i, e in enumerate(ev) if LEGACY_CLOSED_RE.search(e)), default=None)
    if last is None:
        return None
    return c if any(re.search(r"launched (route|calibrate) \(attempt", e) for e in ev[last + 1:]) else None


def lost_closed_finish(j, status, reason, ledger_text):
    """(3) a non-CLOSED finish after a CLOSED verdict whose route was since replaced is a LOST closed result, never
    NEEDS_RTL"""
    if status in ("CLOSED", "CANCELLED", "SMOKE_OK", LOST_CLOSED):
        return status, reason, ledger_text
    c = closure_lost(j)
    if not c:
        return status, reason, ledger_text
    nums = f" TT {c['tt']:+.2f} / FF {c['ff']:+.2f}" if isinstance(c.get("tt"), (int, float)) and \
        isinstance(c.get("ff"), (int, float)) else ""
    eco = f" after {c['eco']['kind']} ECO" if c.get("eco") else ""
    head = f"lost closed result: attempt {c['attempt']} on {c['host']} CLOSED{nums}{eco}; later {status}: {reason}"
    j["lost_closed"] = dict(closed=c, later_status=status, later_reason=reason, at=now_iso())
    return LOST_CLOSED, head[:600], (f"LOST_CLOSED: {head}\nresume on the preserved routed state: "
                                     f"closure_loop.py resume-postroute {j['name']}\n" + ledger_text)


def summarize_failure(j, fleet, metrics):
    """Launch the path-summary stage (remote, detached); the next ticks poll it."""
    v = j["spec"].get("verdict", {})
    base = subst(v["summary_base"], j) if v.get("summary_base") else None
    orfs = metrics.get("orfs_dir")
    fail_corners = [c for c, k, lim in (("ss", "ss_ps", SS_MIN), ("ff", "ff_ps", FF_MIN))
                    if metrics.get(k) is None or metrics[k] < lim]
    if not fail_corners or (not base and not orfs):
        return False
    basearg = f"--base $(ls -d {base} | tail -1)" if base else f"--orfs-dir {orfs}"
    extra = "".join(f" --macro {m}" for m in verdict_macros(j)) + \
        "".join(f" --post-sdc {p}" for p in v.get("post_sdc", []))
    cmd = (f"python3 {j['run']}/cl/path_summary.py {basearg} --src {j['run']}/src{extra} --corners "
           f"{','.join(fail_corners)} --output {j['run']}/cl/path_summary.json")
    st = dict(key="summary", kind="summary", threads=2, ram=16)
    launch_token = fleet.reserve_launch(j["host"], 2, 16)
    try:
        launch_stage(j, st, cmd)
    finally:
        fleet.launch_complete(j["host"], launch_token)
    j["status"], j["stage_key"] = "SUMMARY", "summary"
    return True


def failure_text(j):
    m = j.get("metrics", {})
    head = (f"NEEDS_RTL: {setup_corner_label(m)} {m.get('ss_ps')} / FF {m.get('ff_ps')} ps / DRC {m.get('drc')} "
            f"(line {setup_corner_label(m)} >= +{SS_MIN:g} / FF >= +{FF_MIN:g} / DRC 0){'; checks failed: ' + ', '.join(j['failed_checks']) if j.get('failed_checks') else ''}")
    note = eco_miss_note(j)
    if note:
        head += "; " + note
    lines = [head]
    r = ssh(j["host"], f"cat {j['run']}/cl/path_summary.json 2>/dev/null", timeout=60)
    try:
        s = json.loads(r.stdout)
        for key in ("setup_ss", "hold_ff"):
            if key in s:
                lines.append(f"{key} worst {s[key]['worst_slack_ps']} ps over {s[key]['paths_seen']} endpoints; worst classes:")
                for e in s[key]["classes"][:10]:
                    lines.append(f"  {e['worst_slack_ps']:+.1f} ps n={e['paths']} lv={e['max_levels']} "
                                 f"{e['start_class']} -> {e['end_class']}")
    except Exception:  # noqa: BLE001
        lines.append("(no path summary: timing passed or the summary failed; see the run dir)")
    return "\n".join(lines)


# ECO-MISS IN THE VERDICT (2026-10-13 finishing recipe, item 4).  (i) a hold ECO whose passes all finished unclean
# (hold_eco.sh rc=9, result.json = its least-bad pass) puts that pass's TT / FF / DRC into the NEEDS_RTL verdict instead
# of "no result (rc=9)".  (ii) a layer-cap-leak refusal (rc=11: route wire above MAX_ROUTING_LAYER, the kit's GRT macro
# hook left the top layer raised) says what happens next: one automatic re-route (auto-react class h), also for a kit
# that predates dc5594311 (the loop copies the fixed grt_macro_top_layer*.tcl into every job snapshot; coordinator
# 2026-10-13); a successor that leaks again says "regenerate the kit" and gets no further automatic route.
GRT_CAP_FIX = "dc5594311"
ECO_RC_LAYER_CAP = 11


def kit_has_grt_cap_fix(j):
    c = j.get("commit_full") or (j["spec"].get("source") or {}).get("commit")
    if not c:
        return False
    try:
        return sh(["git", "-C", str(REPO), "merge-base", "--is-ancestor", GRT_CAP_FIX, c], timeout=120).returncode == 0
    except Exception:  # noqa: BLE001
        return False


def eco_layer_cap_refused(j):
    return any((e or {}).get("rc") == ECO_RC_LAYER_CAP for e in [j.get("eco"), *(j.get("eco_history") or [])])


def eco_miss_note(j):
    e = j.get("eco") or {}
    if e.get("rc") == ECO_RC_LAYER_CAP:
        if j["spec"].get("auto_react_parent"):
            nxt = ("second refusal after the automatic re-route: regenerate the kit (ref_tile.py env/job on current "
                   "main); no further automatic route")
        elif kit_has_grt_cap_fix(j):
            nxt = "one automatic re-route with the current kit recipe follows (auto-react h)"
        else:
            nxt = (f"the kit predates {GRT_CAP_FIX}; one automatic re-route follows (auto-react h: the loop ships the "
                   f"fixed grt_macro_top_layer*.tcl into the job snapshot)")
        return f"hold ECO refused, route wire above its layer cap (rc=11); {nxt}"
    res = e.get("result")
    if isinstance(res, dict) and e.get("rc") not in (None, 0):
        return (f"hold ECO missed (rc={e['rc']}): {'least-bad' if res.get('chosen') == 'least_bad' else 'best'} pass "
                f"{res.get('pass')} TT {res.get('tt_ps', res.get('ss_ps'))} / FF {res.get('ff_ps')} ps / DRC {res.get('drc')}")
    return None


def job_held(j):
    """STATE/held.json {job name: reason}: a QUEUED job listed there is not admitted (owner option B pause of SS-wall
    work).  Remove the entry to release it."""
    try:
        return json.loads((STATE / "held.json").read_text()).get(j["name"])
    except (FileNotFoundError, ValueError):
        return None


def job_priority(j):
    """STATE/priority.json {job name: int} (coordinator steering; default 0) or spec "priority" """
    return 0    # OWNER 2026-10-08 02:30: priority mechanism REMOVED (377 entries idled EPYC1/2/4); every job equal
    try:
        table = json.loads((STATE / "priority.json").read_text())
    except (FileNotFoundError, ValueError):
        table = {}
    return int(table.get(j["name"], j["spec"].get("priority", 0)) or 0)


def yield_to_priority(j, fleet, host=None):
    """a job below a priority job still waiting for capacity does not take a host THAT JOB CAN USE (host-scoped:
    20:05 a fleet-wide yield idled every host).  host None (QUEUED, no host yet): yield only if every host this job
    could take is wanted by a waiting priority job."""
    return False    # OWNER 2026-10-08 02:30: never yield; fill the fleet
    waits = getattr(fleet, "prio_hosts", {})      # host -> highest waiting priority that can use it
    mine = job_priority(j)
    if host is not None:
        return waits.get(host, 0) > mine
    return bool(waits) and all(waits.get(h["name"], 0) > mine for h in hosts_table()
                               if fleet.compatible(h["name"], j["spec"]))


def move_to_other_host(j, fleet, spec, stl, reason):
    """move a job with nothing in flight to another allowed host (fleet.choose excluding the current one): claim the
    target, re-sync there and restart from the calibrate stage.  Shared by launch_ready's capacity move and
    handle_transient's ssh-failure move.  Returns True when moved."""
    if at_post_route(j, stl):          # LOST-CLOSED (ROOT-1130): the routed state lives on this host
        return False
    h, _ = fleet.choose(spec, exclude=[j["host"]])
    if not h:
        return False
    fleet.launched(h, spec.get("threads", 16), claim_ram(spec), j["name"])  # 2026-10-08: claim, no herd moves
    event(j, f"{reason}; moving to {host_cfg(h)['label']}")
    j["hosts_tried"].append(h)
    j["host"], j["run"], j["status"], j["wait"] = h, f"{run_base(h)}/{j['name']}", "SYNC", None
    j.pop("wait_since", None)
    cal = next((i for i, x in enumerate(stl) if x["kind"] == "calibrate"), None)
    if cal is not None and j.get("stage_idx", 0) > cal:
        j["stage_idx"] = cal
    experiment(j, f"running: moved to {host_cfg(h)['label']}")
    return True


def launch_ready(j, fleet, spec, stl, st):
    """READY at a remote stage: capacity check + reservation (caller holds FLEET_LOCK); returns the stage to launch
    OUTSIDE the lock (launch_now) or None."""
    require_checkpoint_location(j)
    if True:
        if st["kind"] in ("calibrate", "route") and yield_to_priority(j, fleet, j["host"]):
            why = f"yielding {host_cfg(j['host'])['label']} to a waiting priority job"
            if j.get("wait") != why:
                j["wait"] = why
                event(j, f"{st['key']} {why}")
            return          # neither launches nor moves hosts while it yields
        ok, why = fleet.fits(j["host"], st["threads"], st["ram"], j["name"])
        if not ok:
            j.setdefault("wait_since", time.time())
        if not ok and not checkpoint_location(j) and st["kind"] in ("calibrate", "route") and time.time() - j["wait_since"] >= 120:
            # nothing of this job is in flight: move it to another allowed host that fits now (re-sync, re-calibrate)
            if move_to_other_host(j, fleet, spec, stl, f"{st['key']} cannot start on {host_cfg(j['host'])['label']} ({why})"):
                return
        if not ok:
            if j.get("wait") != why:
                j["wait"] = why
                event(j, f"{st['key']} waiting for capacity: {why}")
            return
        j["wait"] = None
        j.pop("wait_since", None)
        if st["kind"] == "route":   # one route per (block, source commit): the key is taken when the route launches
            keys, key = route_keys(), f"{spec['block']}@{spec['source']['commit'][:12]}"
            if route_key_full(keys, key, j["name"]):
                finish(j, "REFUSED", f"{MAX_ROUTES_PER_KEY} routes per source commit: {key} already routed by jobs {keys[key]}",
                       f"REFUSED: {key} already routed by jobs {keys[key]}")
                return
            if j["name"] not in keys.setdefault(key, []):
                keys[key].append(j["name"])
            # atomic (el1013-fleet4): write_text truncates first, and a reader in another job thread got an empty file
            # (auto_react JSONDecodeError 10-13 04:21)
            tmp = keys_path().with_suffix(f".tmp.{threading.get_ident()}")
            tmp.write_text(json.dumps(keys, indent=1) + "\n")
            os.replace(tmp, keys_path())
        st["admission_launch_token"] = fleet._launched(j["host"], st["threads"], st["ram"], j["name"], actual=True)  # reservation (replaces the job's claim)
        return st


def launch_now(j, fleet, st):
    """launch a reserved stage (no FLEET_LOCK held: the ssh calls of one launch no longer stall every other job)"""
    try:
        launch_stage(j, st, st["cmd"])
    finally:
        fleet.launch_complete(j["host"], st["admission_launch_token"])
    j["status"] = "RUNNING"
    event(j, f"launched {st['key']} (attempt {j['attempt']}) on {j['host']}")
    experiment(j, f"running: {st['key']} on {host_cfg(j['host'])['label']}")


# ---- parallel bench track (OWNER 2026-10-07 05:00 "LAUNCH IMMEDIATELY"): exactness benches run beside
# calibrate -> route independently; one bench at a time stays beside its first producer artifacts.
# Benches gate ADOPTION, not launch.  A bench with the wrong
# verdict stops the route and ends the job NEEDS_RTL; the verdict waits until every bench has its expected verdict.
# Opt out per job with spec "bench_first": true (benches before the route, as before).


def bench_stages(stl):
    return [x for x in stl if x["kind"] == "bench"]


def bench_par_decide(j, stl):
    """decide once, when the job first leaves QUEUED / its first stage: parallel unless bench_first or no benches"""
    if "bench_par" in j:
        return
    started = bool(j.get("stage_tag")) or j.get("stage_idx", 0) > 0
    j["bench_par"] = bool(bench_stages(stl)) and j["spec"].get("bench_first") is not True and not started
    if j["bench_par"]:
        j["btrack"] = {}
        j["stage_idx"] = next(i for i, x in enumerate(stl) if x["kind"] != "bench")
        event(j, f"benches run in parallel with calibrate/route ({len(bench_stages(stl))} benches; spec bench_first opts out)")


def _bview(j, e):
    """a job view addressing one bench-track stage (its own host / run / tag)"""
    v = dict(j)
    v.update(host=e["host"], run=e["run"], stage_tag=e["tag"])
    if e.get("stage_source"):
        v["stage_source"] = e["stage_source"]
    return v


def benches_done(j, stl):
    return all(k["key"] in j.get("benches", {}) for k in bench_stages(stl))


def bench_location(j, stl):
    """A serial bench chain shares artifacts even if the physical track moves hosts.

    Recover older state from the first launched bench; completed receipts stay
    untouched. Never copy or rerun a producer merely because its route migrated.
    """
    if j.get("bench_location"):
        return j["bench_location"]
    for st in bench_stages(stl):
        entry = (j.get("btrack") or {}).get(st["key"])
        if entry and entry.get("host") and entry.get("run"):
            match = re.search(r"\.a([0-9]+)b[0-9]+$", entry.get("tag", ""))
            location = dict(host=entry["host"], run=entry["run"],
                            attempt=int(match.group(1)) if match else j["attempt"])
            j["bench_location"] = location
            return location
    return dict(host=j["host"], run=j["run"], attempt=j["attempt"])


def vanished_bench_location(j, location):
    """drive-1013 2026-10-08: a bench chain pinned to another host's run (an offload, or the run before a migration)
    outlives that run when a disk purge deletes it.  Every launch then failed 'cat > .../cl/<bench>.sh: No such file'
    until 10 loop errors (qfd_embed_scale_bank_retained-24bd6a53b-tt), and a human retry did not help: it popped
    bench_location, but bench_location() re-derived it from the DONE btrack receipts on the same deleted run.  If the
    run's src is gone (an explicit MISSING, never an ssh failure), forget the location and every receipt made there:
    their artifacts went with it, so the chain re-runs on the job's own run (or a fresh offload)."""
    r = ssh(location["host"], f"test -d {shlex.quote(location['run'])}/src && echo PRESENT || echo MISSING", timeout=60)
    if r.returncode != 0 or "MISSING" not in r.stdout:
        return False
    gone = location["run"]
    tr = j.get("btrack") or {}
    lost = [k for k, e in tr.items() if e.get("run") == gone]
    for k in lost:
        tr.pop(k, None)
        (j.get("benches") or {}).pop(k, None)
    j.pop("bench_location", None)
    event(j, f"bench track: artifact run {location['host']}:{gone} no longer exists (purged); dropped it and the "
             f"receipts made there ({', '.join(lost) or 'none'}): the bench chain restarts")
    return True


def offload_bench_location(j, fleet, st):
    """a host with the job's bench tools and room for one bench; the source is synced there to <base>/<name>-bench"""
    need = bench_needs(j["spec"])
    for cfg in hosts_table():
        h = cfg["name"]
        if h == j["host"] or cfg.get("smoke_only") or host_down(h) or not need <= set(cfg.get("caps", [])):
            continue
        if not fleet.compatible(h, dict(j["spec"], stages={"bench": j["spec"].get("stages", {}).get("bench", [])})):
            continue
        with FLEET_LOCK:
            ok, _ = fleet.fits(h, st["threads"], st["ram"])
        if not ok:
            continue
        v = dict(j, host=h, run=f"{run_base(h)}/{j['name']}-bench", resume=None, checkpoint_affinity=None)
        # A new bench directory is not the route's executed helper directory.
        # Relocate only after read-only verification at the original location;
        # ship_helpers then installs the original committed payload, never main's
        # newer bytes, and leaves the original execution untouched.
        if j.get("freeze_helper_overlay") and j.get("route_overlay_plan"):
            v["bench_helper_origin"] = dict(host=j["host"], run=j["run"])
        try:
            sync_source(v)
        except Exception as ex:  # noqa: BLE001
            event(j, f"bench offload: source sync to {h} failed: {str(ex)[:200]}")
            continue
        if v.get("bench_helper_origin_verification"):
            verification = installed_helper_receipt(h, v["run"], v["route_overlay_plan"])
            if verification.get("status") != "verified_original":
                raise ValueError("bench destination helper installation was not verified")
            j.setdefault("bench_helper_relocations", []).append(dict(
                origin=v["bench_helper_origin_verification"], destination=dict(host=h, run=v["run"]),
                verification=verification, verified_at=now_iso()))
        with FLEET_LOCK:
            fleet._launched(h, 0, 0)
        return dict(host=h, run=v["run"], attempt=j["attempt"])
    return None


BENCH_MEM_OFFLOAD_WAIT_S = 30 * 60


def memory_offload_bench(j, fleet, st, stl, location, why):
    """HBM group A 2026-10-14 (hgi_xp_bfm-recover1 / hgi_xp_rdc-recover2margin sat READY for hours): a bench whose spec
    peak_ram_gb does not fit the ARTIFACT host (AGIdock 128 GB, MemAvailable 70-93 GB, bench 96 GB) waited forever --
    offload_bench_location() only offloaded for missing tools.  After BENCH_MEM_OFFLOAD_WAIT_S of waiting, move the
    bench chain to a host that fits it now, through the same offload path (source synced to <base>/<name>-bench).
    Benches that read route products ({RUN}/routes, physical_artifacts) stay on the artifact host.  The chain restarts
    on the new host: receipts made at the old location are dropped (their build products are not there), as in
    vanished_bench_location().  Returns the new location or None."""
    if any("routes/" in (b.get("cmd") or "") or "physical_artifacts" in (b.get("cmd") or "")
           for b in bench_stages(stl)):
        return None
    since = j.get("bwait_since")
    if not since:
        return None
    try:
        waited = time.time() - dt.datetime.fromisoformat(since).timestamp()
    except ValueError:
        return None
    if waited < BENCH_MEM_OFFLOAD_WAIT_S:
        return None
    off = offload_bench_location(j, fleet, st)
    if off is None:
        return None
    tr = j.get("btrack") or {}
    old = location.get("run")
    lost = [k for k, e in tr.items() if e.get("run") == old and e.get("state") != "running"]
    for k in lost:
        tr.pop(k, None)
        (j.get("benches") or {}).pop(k, None)
    j["bench_location"] = off
    event(j, f"bench track: offloaded to {off['host']}:{off['run']} after {int(waited // 60)} min waiting on "
             f"{location.get('host')} ({why}); chain restarts there (dropped receipts: {', '.join(lost) or 'none'})")
    return off


def _bench_source_fields(j, key):
    row = (j.get("bench_rebind") or {}).get(key)
    return dict(source_commit=row["source_commit"], bench_rebind_id=row["id"]) if row else {}


def bench_track(j, fleet, stl):
    """advance the bench track; returns False if the job ended (bench failure)"""
    if not j.get("bench_par") or j["status"] in TERMINAL or j["status"] in ("QUEUED", "SYNC", "MIGRATING"):
        return True
    tr = j.setdefault("btrack", {})
    # A relocation can invalidate an earlier artifact receipt while a later
    # bench is already running. Poll that bench before a pending predecessor;
    # otherwise the one-at-a-time guard prevents its completion being collected.
    ordered = sorted(bench_stages(stl),
                     key=lambda st: tr.get(st["key"], {}).get("state") != "running")
    for st in ordered:
        k = st["key"]
        if k in j["benches"]:
            continue
        e = tr.get(k)
        if e is None or e.get("state") == "retry":
            if any(x.get("state") == "running" for x in tr.values()):
                return True                  # one bench at a time
            recovery = (j.get("bench_rebind") or {}).get(k)
            location = (dict(host=j["host"], run=j["run"], attempt=j.get("route_attempt", j["attempt"]))
                        if recovery else bench_location(j, stl))
            if location["run"] != j.get("run") and vanished_bench_location(j, location):
                location = bench_location(j, stl)
            caps = next((x.get("caps", []) for x in hosts_table() if x["name"] == location["host"]), None)
            if not j.get("bench_location") and caps is not None and not bench_needs(j["spec"]) <= set(caps):
                off = offload_bench_location(j, fleet, st)
                if off is None:
                    why = f"no host with {sorted(bench_needs(j['spec']))} fits the bench now"
                    if j.get("bwait") != why:
                        j["bwait"] = why
                        event(j, f"bench track: {k} waiting: {why}")
                    return True
                location = off
                j["bench_location"] = location
                event(j, f"bench track: offloaded to {location['host']}:{location['run']} (job host {j['host']} lacks bench tools)")
            host = location["host"]
            fleet.probe(host)
            launch_token = None
            with FLEET_LOCK:
                ok, why = fleet.fits(host, st["threads"], st["ram"])
                if ok:
                    launch_token = fleet._launched(host, st["threads"], st["ram"], actual=True)
            if not ok:
                off = None if recovery else memory_offload_bench(j, fleet, st, stl, location, why)
                if off is None:
                    if j.get("bwait") != why:
                        j["bwait"] = why
                        j.setdefault("bwait_since", now_iso())
                        event(j, f"bench track: {k} waiting for capacity on artifact host {host}: {why}")
                    return True
                location, host = off, off["host"]
                with FLEET_LOCK:
                    ok, why = fleet.fits(host, st["threads"], st["ram"])
                    if not ok:
                        return True
                    launch_token = fleet._launched(host, st["threads"], st["ram"], actual=True)
            n = (e or {}).get("n", 0) + 1
            v = dict(j, host=host, run=location["run"], attempt=f"{location['attempt']}b{n}")
            if e is not None and e.get("state") == "retry":
                stale = bench_scratch_dirs(st["cmd"])
                if stale:       # a crashed attempt's partial outputs (half-built simulator) must not be reused
                    ssh(host, "rm -rf " + " ".join(shlex.quote(f"{location['run'].rstrip('/')}/{d}") for d in stale),
                        timeout=300)
                    event(j, f"bench track: {k} retry clears its outputs {stale}")
            try:
                launch_stage(v, st, st["cmd"])
            finally:
                fleet.launch_complete(host, launch_token)
            j["bench_location"] = location
            tr[k] = dict(state="running", tag=v["stage_tag"], host=host, run=location["run"], n=n, started=now_iso(), stage_source=v.get("stage_source"),
                         **_bench_source_fields(j, k))
            j["bwait"] = None
            j.pop("bwait_since", None)
            event(j, f"bench track: launched {k} ({v['stage_tag']}) beside {j.get('stage_key')}")
            return True
        v = _bview(j, e)
        state, rc = poll_stage(v)
        if state == "RUNNING":
            for field in ("wd_checked", "quiet_output_reported"):
                if field in e:
                    v[field] = e[field]
                else:
                    v.pop(field, None)
            bench_timed_out(v, st, e.get("started"))
            for field in ("wd_checked", "quiet_output_reported"):
                if field in v:
                    e[field] = v[field]
        if state in ("RUNNING", "STARTING", "UNREACHABLE"):
            return True
        ok_extra, _ = remote_ok(v, st.get("ok"))
        tail = stage_tail(v, st, 40)
        kills = stage_oom_kills(v, st) if state == "RC" else ""
        crashed = state == "LOST" or bool(kills) or bench_crashed(st, rc, tail)
        if crashed:
            if e["n"] < 2:
                e["state"] = "retry"
                event(j, f"bench track: {k} crashed (state {state}, rc={rc}"
                         + (f"; OOM-KILL flow failure: {kills.splitlines()[0][:300]}" if kills else "") + "); retry once")
                return True
            stop_main_for_bench(j)
            finish(j, "NEEDS_HUMAN", f"{k} crashed twice in the bench track (rc={rc})",
                   f"NEEDS_HUMAN: bench {k} crashed twice (rc={rc}); route stopped\n" + "\n".join(tail.strip().splitlines()[-5:]))
            return False
        passed = bench_outcome(v, st, rc, ok_extra)
        j.setdefault("bench_work", {}).update(v.get("bench_work") or {})
        if v.get("fail_witnesses") is not j.get("fail_witnesses"):
            j.setdefault("fail_witnesses", {}).update(v.get("fail_witnesses") or {})
        e["state"] = "done"
        race = "" if passed else bench_tool_race(v, tail)
        if race:
            if e["n"] < 2:
                e["state"] = "retry"
                event(j, f"bench track: {k} tool race (rc={rc}; BENCH-TOOL-RACE: {race[:200]}); retry once")
                return True
            stop_main_for_bench(j)
            finish(j, "NEEDS_HUMAN", f"{k} tool race twice in the bench track (rc={rc})",
                   f"NEEDS_HUMAN: bench {k} hit a build tool race twice (rc={rc}): {race}; route stopped")
            return False
        j["benches"][k] = dict(expect=st["expect"], rc=rc, ok=passed, tail=tail[-600:], track="parallel",
                               **_bench_source_fields(j, k))
        if not passed:
            stop_main_for_bench(j)
            finish(j, "NEEDS_RTL", f"{k} expected {st['expect'].upper()} but rc={rc}{bench_why(j, st, rc, ok_extra)}",
                   f"NEEDS_RTL: bench {k} expected {st['expect'].upper()}, got rc={rc} (parallel track; route stopped)\n" +
                   "\n".join(tail.strip().splitlines()[-5:]))
            return False
        event(j, f"bench track: {k} {('PASS' if st['expect'] == 'pass' else 'FAIL as expected')} (rc={rc}) "
                 f"{(j.get('bench_work') or {}).get(k, '')}")
    return True


def bench_timed_out(v, st, started):
    """Legacy entry point: observe quiet output, never enforce elapsed-time verdicts.

    Preserve historical timeout_s values as source evidence.  Measured host
    admission protects resources; even a silent compile can be progressing.
    Positive and mutant results are judged only after their real completion.
    """
    if started:
        v["stage_started"] = started
    stuck_watchdog(v, st)
    return None


def stop_main_for_bench(j):
    """a bench failed: stop the job's own main-track stage (route / calibrate / ECO) -- its result cannot be adopted"""
    if j["status"] in ("RUNNING", "ECO", "ECO_INSTALL", "SUMMARY"):
        try:
            kill_own_stage(j)
            event(j, f"bench failed: stopped {j.get('stage_key')} ({j.get('stage_tag')})")
        except Exception as ex:  # noqa: BLE001
            event(j, f"bench failed: could not stop {j.get('stage_key')}: {ex}")


STUCK_S = 3 * 3600          # quiet-output observation threshold, never a kill deadline
STUCK_CHECK_S = 1800


def stuck_watchdog(j, st):
    """Report quiet output without imposing a runtime deadline or restarting work."""
    now = time.time()
    if now - j.get("wd_checked", 0) < STUCK_CHECK_S:
        return
    j["wd_checked"] = now
    try:
        started = dt.datetime.fromisoformat(j.get("stage_started")).timestamp()
    except Exception:  # noqa: BLE001
        return
    if now - started < STUCK_S:
        return
    mins = STUCK_S // 60
    r = ssh(j["host"], f"find {j['run']}/cl {j['run']}/routes {j['run']}/bench -newermt '-{mins} minutes' -type f "
                       f"-print -quit 2>/dev/null; echo END", timeout=300)
    if r.returncode or "END" not in r.stdout:
        return                          # unreachable / slow: no verdict this time
    if r.stdout.replace("END", "").strip():
        return
    # Quiet tool output is not proof that synthesis or routing stopped making progress.
    # Keep the process and all completed objects; the owner can inspect actual CPU/
    # process state. Capacity guards, not elapsed time, protect the host.
    if not j.get("quiet_output_reported"):
        j["quiet_output_reported"] = now_iso()
        event(j, f"observation: {st['key']} wrote no file for {mins // 60} h; process preserved")


EARLY_CHECK_S = 900
STARTING_TIMEOUT_S = 3600


def early_fail_gate(j, st):
    """EARLY-FAIL GATES (OWNER 2026-10-08, stream stuckscan): every 15 min a RUNNING route's ORFS run is probed
    (stuckscan.probe: post-placement / post-CTS TT setup metrics, the live hold repair, GRT congestion reports, DRT
    violation series) and a hopeless run stops at once with EARLY_FAIL_SETUP / _HOLD / _CONGESTION / _DRC plus its
    worst-path summary, instead of spending hours in repair/route.  Thresholds: stuckscan.GATES (calibrated on the
    loop's finished TT routes; README "Early-fail gates").  Spec "early_fail": false opts out."""
    now = time.time()
    if j["spec"].get("early_fail") is False or now - j.get("ef_checked", 0) < EARLY_CHECK_S:
        return
    import stuckscan
    if stuckscan.protected(j):     # CRITICAL_PATH 1 (BF): stuckscan reports it, never auto-stopped
        return
    j["ef_checked"] = now
    try:
        import stuckscan
        stuckscan.cl = sys.modules[__name__]
        res, err = stuckscan.probe(j["host"], [dict(name=j["name"], run=j["run"], tag=j.get("stage_tag"), live=True)],
                                   cpu=False, timeout=300)
        if not res:
            return
        o = res["jobs"].get(j["name"]) or {}
        bs = [b for b in o.get("bases") or [] if not b["design"].endswith("_cal")]
        if not bs:
            return
        b = max(bs, key=lambda x: max([lg[1] for lg in x["logs"]] or [0]))
        hp = stuckscan.hopeless(b, j, res.get("now", now))
    except Exception:  # noqa: BLE001
        log(f"[{j['name']}] early-fail gate error:\n{traceback.format_exc()}")
        return
    if not hp:
        return
    verdict, why = hp[0][0], "; ".join(w for _, w in hp)
    if verdict == "HOLD_STOP":
        plan = stuckscan.hold_stop_plan(b)
        try:
            hold_stop_resume(j, plan["stage"], plan["buffers"], why)
            return
        except Exception as ex:  # noqa: BLE001  (already stopped once / no checkpoint: early-fail as before)
            event(j, f"HOLD-STOP not possible ({ex}); early-fail instead")
            verdict = "EARLY_FAIL_HOLD"
    detail = dict(name=j["name"], verdict=verdict, why=[w for _, w in hp], orfs=b["root"], corner=b.get("corner"),
                  step=(b.get("current") or "")[:-8], setup=stuckscan.gate_metrics(b), hold=b.get("hold"),
                  congestion=b.get("congestion"), drt=(b.get("drt") or [])[-12:], paths=stuckscan.path_classes(b),
                  block=j["spec"].get("block"), owner=j["spec"].get("owner"), gates=stuckscan.GATES)
    (STATE / "early_fail").mkdir(parents=True, exist_ok=True)
    (STATE / "early_fail" / f"{j['name']}.json").write_text(json.dumps(detail, indent=1))
    early_fail_finish(j, verdict, why, detail)
    try:
        stuckscan.failtrig_item(dict(detail, action="early_fail", kind="hopeless"))
    except Exception:  # noqa: BLE001
        pass


# ---- parallel calibrate (OWNER 2026-10-08 "calibration must not gate the route"): the route starts at once on the
# block's previous-measured insertion (STATE/measured_insertion.json), else its budget sheet insertion; the no-repair
# CTS-only calibrate runs beside it (j["ctrack"]).  The verdict waits for it; when the measured insertion differs from
# the route's assumption by more than CAL_REROUTE_PS, the route is redone ONCE on the measured numbers (calib.env now
# holds them).  The loop has no generic measured-clock re-STA, so a CLOSED verdict on an assumption that moved by more
# than the threshold is re-routed as well (conservative: it was never timed at the measured insertion).
# Without an assumption (no measurement, no sheet) calibrate stays sequential (minutes now: no repair).
# SYNTH-RESTA 2026-10-08: the measured-clock re-STA exists now (measured_resta / meas_resta.py): before re-routing, the
# finished route is re-timed at sign-off (TT setup + FF hold) with its IO SDCs regenerated from the MEASURED insertion;
# the route is redone only if that re-STA fails, or if no measured SDC can be derived for the recipe (route scripts
# that write the IO SDC internally: 'echo ...' sdc_cmd).
CAL_REROUTE_PS = 50.0


def measured_sdc_args(j):
    """meas_resta.py arguments that give a finished route its IO model at the MEASURED insertion: (args, None) or
    (None, why).  Budget jobs: the sign-off budget SDCs the loop regenerated from the measurement (budget_check) replace
    the route's copies; sdc_cmd jobs: the recipe's sdc_cmd re-run on the measured env, inserted after the base SDC."""
    env = (j.get("calibration") or {}).get("env")
    if not env:
        return None, "no measured env"
    stages = j["spec"].get("stages")
    rc = (stages.get("route") or {}).get("cmd", "") if isinstance(stages, dict) else ""
    run = j["run"]
    if j.get("budget"):
        if not (j["budget"].get("check") or {}).get("ok") or (j["budget"].get("insertion_used") or {}).get("grade") != "measured":
            return None, "budget SDCs were not regenerated from the measurement (flagged or audited sheet)"
        m1 = re.search(r"cp \$BUDGET_SDC_SIGNOFF (\S+)", rc)
        m2 = re.search(r"cat \$BUDGET_SDC_FF; echo '\}'; \} > (\S+)", rc)
        if not m1:
            return None, "route cmd does not install $BUDGET_SDC_SIGNOFF as a sign-off post-SDC"
        args = ["--replace", f"{m1.group(1)}={run}/cl/budget_signoff.sdc"]
        if m2:
            r = ssh(j["host"], f"{{ echo 'if {{[llength [get_libs -quiet *_FF_*]]}} {{'; cat {run}/cl/budget_ff.sdc; echo '}}'; }} "
                               f"> {run}/cl/meas_budget_ff_guarded.sdc", timeout=60)
            if r.returncode:
                return None, "measured budget_ff.sdc unreadable"
            args += ["--replace", f"{m2.group(1)}={run}/cl/meas_budget_ff_guarded.sdc"]
        return args, None
    sdc_cmd = (j.get("ctrack") or {}).get("sdc_cmd")
    if not sdc_cmd:
        return None, "no sdc_cmd"
    out = re.search(r"--out\s+(\S+)", sdc_cmd)
    cmd = sdc_cmd.replace(out.group(0), f"--out {run}/cl/meas_io.sdc") if out else sdc_cmd
    text = "".join(f"{k}={v}\n" for k, v in env.items())
    r = ssh(j["host"], f"cat > {run}/cl/calib.measured.env", input=text, timeout=60)
    if r.returncode:
        return None, "cannot write calib.measured.env"
    r = ssh(j["host"], f"cd {run}/src && set -a && . {run}/cl/calib.measured.env && set +a && ( {subst(cmd, j)} )", timeout=600)
    if r.returncode:
        return None, f"sdc_cmd failed on the measured env (rc={r.returncode})"
    if out:
        path = f"{run}/cl/meas_io.sdc"
    else:
        last = (r.stdout.strip().splitlines() or [""])[-1].strip()
        if not last.endswith(".sdc"):
            return None, "sdc_cmd names no SDC file (the route script writes its IO SDC internally)"
        path = last if last.startswith("/") else f"{run}/src/{last}"
    if ssh(j["host"], f"test -s {shlex.quote(path)}", timeout=60).returncode:
        return None, f"measured SDC {path} missing"
    return ["--insert", path], None


def measured_resta(j, m):
    """the measured-clock re-STA of the finished route (once per route attempt): None when not needed, else the record
    {available, tt, ff, ...}"""
    c = j.get("ctrack") or {}
    if c.get("state") != "done" or c.get("delta_ps", 0) <= CAL_REROUTE_PS or j.get("cal_rerouted"):
        return None
    mr = j.get("meas_resta")
    if mr and mr.get("attempt") == j["attempt"]:
        return mr
    mr = dict(attempt=j["attempt"], at=now_iso(), delta_ps=c.get("delta_ps"), available=False)
    orfs = m.get("orfs_dir") or (m.get("raw") or {}).get("orfs_dir")
    args, why = (None, "no orfs_dir in the verdict metrics") if not orfs else measured_sdc_args(j)
    if not args:
        mr["why"] = why
    else:
        with TT_STA_SLOTS:
            ship_helpers(j["host"], j["run"], j)
            r = ssh(j["host"], f"python3 {j['run']}/cl/meas_resta.py --orfs {shlex.quote(orfs)} --src {j['run']}/src "
                               f"--out {j['run']}/cl/meas_resta.a{j['attempt']}.json " + " ".join(shlex.quote(x) for x in args),
                    timeout=12000)
        try:
            res = json.loads([x for x in r.stdout.splitlines() if x.startswith("{")][-1])
            tt, ff = res["setup_tt"].get("worst_slack_ps"), res["hold_ff"].get("worst_slack_ps")
            errs = (res["setup_tt"].get("errors") or []) + (res["hold_ff"].get("errors") or []) + \
                [res[k]["error"] for k in ("setup_tt", "hold_ff") if res[k].get("error")]
            mr.update(available=tt is not None and ff is not None and not errs, tt=tt, ff=ff, errors=errs[:5],
                      args=args, json=f"{j['run']}/cl/meas_resta.a{j['attempt']}.json")
            if not mr["available"]:
                mr["why"] = f"re-STA incomplete (TT {tt} / FF {ff}; {errs[:2]})"
        except (IndexError, ValueError, KeyError, TypeError) as ex:
            mr["why"] = f"re-STA output unreadable ({ex}; rc={r.returncode})"
    j["meas_resta"] = mr
    event(j, f"measured-clock re-STA (insertion moved {c.get('delta_ps', 0):.0f} ps): " +
             (f"TT setup {mr['tt']:+.2f} / FF hold {mr['ff']:+.2f}" if mr["available"] else f"unavailable: {mr['why']}"))
    return mr


# FLOW-IOREF 2026-10-08: every finished route is SIGNED OFF against its OWN routed clock tree.  The IO SDCs carry a
# virtual-clock latency from the calibrate run's CTS (or an assumed / sheet insertion); the routed tree differs (hbm_pkt
# ii1r/ii1rb: FF vclk 363/402 from calibrate vs routed FF mean ~307/314 -> output-port-only hold -43/-45; pre-DRT repair
# reached +50 against the same wrong reference).  The die clock plan aligns every block's NOMINAL insertion, so the
# routed mean is the truth: meas_resta.py re-times the route (TT setup, FF hold; no re-route) with
# physical/common_flow/io_ref_routed.sdc read LAST, which moves every insertion-reference virtual clock (vclk*, ot_lb_v_*,
# nbr_clk) to the mean boundary-register clock arrival of THAT corner (H1 uncertainties unchanged).  Its numbers are the
# verdict; the routed insertion goes to measured_insertion.json as the block's die-plan value; the post-route hold ECO
# gets the same SDC as its last post-SDC.  Spec "routed_ioref": false opts out.
IOREF_SDC = "physical/common_flow/io_ref_routed.sdc"
# FLOW-FIX-0410 2026-10-09: io_ref_routed.sdc reads the ACTIVE-edge insertion (sinks behind an odd clock inversion were
# T/2 late).  The version is part of the routed_ioref cache key, so ioref-rejudge / a verdict re-STA under the new rule
# instead of returning a re-STA cached under the old one.
# PF-HARDCHILD-VERDICT (ROOT-CORNER 2026-10-19): meas_resta names the hard-child ETM libs (OT_PF_MACRO_LIBS) in replayed
# pre-fix w18 Tcl, so a re-STA cached under the raw-child-clock-pin reference is not returned as the re-judge.
IOREF_VERSION = "ae0410-cecorner-1015-pfhc1019"


def routed_ioref(j, m):
    """re-STA of the finished route at its own routed insertion (cached per route attempt / installed ECO): None when
    not applicable, else {available, tt, ff, ioref{tt, ff}, ...}"""
    if j["spec"].get("routed_ioref") is False:
        return None
    orfs = m.get("orfs_dir") or (m.get("raw") or {}).get("orfs_dir")
    if not orfs:
        return None
    key = f"{j['attempt']}|{orfs}|{int(bool((j.get('eco') or {}).get('installed')))}|{IOREF_VERSION}"
    rbj = j.get("rebudget") or {}
    if rbj.get("sdc"):
        key += f"|{rbj['rb']}"
    rr = j.get("routed_ioref")
    if rr and rr.get("key") == key:
        return rr
    rr = dict(key=key, at=now_iso(), available=False)
    out = f"{j['run']}/cl/routed_ioref.a{j['attempt']}" + (f".{rbj['rb']}" if rbj.get("sdc") else "") + ".json"
    with TT_STA_SLOTS:
        ship_helpers(j["host"], j["run"], j)
        ssh(j["host"], f"mkdir -p {j['run']}/src/physical/common_flow && cp {j['run']}/cl/io_ref_routed.sdc "
                       f"{j['run']}/src/{IOREF_SDC}", timeout=60)
        app = f"--append {j['run']}/cl/io_ref_routed.sdc"
        if rbj.get("sdc"):
            # REBUDGET (tools/budgets/rebudget.py): the block's re-derived IO budget (budget_rb<N>) read after the routed
            # reference, so the verdict is the IO paths against the CURRENT die-link budget
            rp = f"{j['run']}/cl/{rbj['rb']}.sdc"
            ssh(j["host"], f"cat > {rp}", input=Path(rbj["sdc"]).read_text(), timeout=60)
            app += f" --append {rp}"
        # IOREF-VERDICT-TOOL (ROOT-CORNER 2026-10-19): the routed re-STA is the VERDICT of a finished route, never part of
        # its execution, so it runs the loop's CURRENT meas_resta.py (= origin/main, as io_ref_routed.sdc above) from
        # cl_ioref/, not the job's frozen cl/ copy: a frozen-overlay job (freeze_helper_overlay) otherwise re-judged with
        # the bug it was re-judged for (s81sl_capc d8836674d: frozen pre-fix meas_resta, no OT_PF_MACRO_LIBS -> STILL
        # FF -158).  cl/ stays byte-identical to the frozen plan; the shipped bytes are recorded in the result.
        mr_body = (HERE / "meas_resta.py").read_bytes()
        ssh(j["host"], f"mkdir -p {j['run']}/cl_ioref && cat > {j['run']}/cl_ioref/meas_resta.py",
            input=mr_body.decode(), timeout=60, check=True)
        rr["meas_resta_sha256"] = hashlib.sha256(mr_body).hexdigest()
        r = ssh(j["host"], f"python3 {j['run']}/cl_ioref/meas_resta.py --orfs {shlex.quote(orfs)} --src {j['run']}/src "
                           f"--out {out} {app}", timeout=12000)
    try:
        res = json.loads([x for x in r.stdout.splitlines() if x.startswith("{")][-1])
        tt, ff = res["setup_tt"].get("worst_slack_ps"), res["hold_ff"].get("worst_slack_ps")
        errs = (res["setup_tt"].get("errors") or []) + (res["hold_ff"].get("errors") or []) + \
            [res[k]["error"] for k in ("setup_tt", "hold_ff") if res[k].get("error")]
        io = dict(tt=res["setup_tt"].get("ioref") or {}, ff=res["hold_ff"].get("ioref") or {})
        rr["ioref_edge"] = dict(tt=res["setup_tt"].get("ioref_edge") or {}, ff=res["hold_ff"].get("ioref_edge") or {})
        rr.update(available=tt is not None and ff is not None and not errs, tt=tt, ff=ff, errors=errs[:5], ioref=io,
                  tt_i2r=res["setup_tt"].get("worst_input_to_reg_slack_ps"), tt_out=res["setup_tt"].get("worst_output_port_slack_ps"),
                  ff_i2r=res["hold_ff"].get("worst_input_to_reg_slack_ps"), ff_out=res["hold_ff"].get("worst_output_port_slack_ps"),
                  ff_r2r=res["hold_ff"].get("worst_reg_to_reg_slack_ps"), json=out,
                  registers=res["setup_tt"].get("registers"), registers_clocked=res["setup_tt"].get("registers_clocked"))
        if not rr["available"]:
            rr["why"] = f"re-STA incomplete (TT {tt} / FF {ff}; {errs[:2]})"
        # a corner whose SDC has no insertion-reference virtual clock is unchanged by the re-STA: keep the route's own
        # sign-off number there (the bare re-STA does not reproduce every recipe's sign-off: dshead-elemB-safe TT
        # -201 route vs +121 re-STA with no clock moved)
        for c, k in (("tt", "ss_ps"), ("ff", "ff_ps")):
            if rr["available"] and not io[c] and not rbj.get("sdc"):
                rr[c + "_resta_raw"], rr[c] = rr[c], m.get(k)
        if rr["available"] and (rr["tt"] is None or rr["ff"] is None):
            rr.update(available=False, why="route sign-off number missing for an unchanged corner")
    except (IndexError, ValueError, KeyError, TypeError) as ex:
        rr["why"] = f"re-STA output unreadable ({ex}; rc={r.returncode})"
    j["routed_ioref"] = rr
    ref = lambda c: ", ".join(f"{v} {d['mean']:.0f}" for v, d in sorted(rr.get("ioref", {}).get(c, {}).items())) or "none"
    if rbj.get("sdc"):
        rr["rebudget"] = rbj["rb"]
    event(j, "routed-insertion IO re-STA" + (f" under {rbj['rb']}" if rbj.get("sdc") else "") + ": " + (f"TT setup {rr['tt']:+.2f} / FF hold {rr['ff']:+.2f} (route SDC "
             f"{m.get('ss_ps')} / {m.get('ff_ps')}); routed reference TT [{ref('tt')}] FF [{ref('ff')}]"
             if rr["available"] else f"unavailable: {rr['why']}"))
    if rr["available"]:
        record_routed(j, rr)
    return rr


def record_routed(j, rr):
    """the routed insertion (mean boundary-register clock arrival per corner, from the sign-off re-STA) replaces the
    calibrate value in STATE/measured_insertion.json: the die clock plan's per-block nominal insertion"""
    pick = {}
    for c in ("tt", "ff"):
        vs = list((rr.get("ioref") or {}).get(c, {}).values())
        if vs:
            v = max(vs, key=lambda d: d["n"])
            pick[c] = dict(mean=round(v["mean"]), min=round(v["min"]), max=round(v["max"]), n=v["n"], kind=v["kind"],
                           clock=v["clock"])
    if "ff" not in pick:
        return
    p = STATE / "measured_insertion.json"
    with open(STATE / "measured.lock", "w") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        d = json.loads(p.read_text()) if p.exists() else {"schema": "opentallas.closure_loop.measured_insertion.v1",
                                                          "blocks": {}}
        old = (d.get("variants") or {}).get(variant_key(j["spec"])) or d["blocks"].get(j["spec"]["block"]) or {}
        e = dict(old, job=j["name"], source_commit=j.get("commit_full"), host=j["host"], run=j["run"],
                 parasitics="routed (6_final.spef)", grade="routed", measured_at=now_iso(), ff=pick["ff"],
                 calibrate=old.get("calibrate") or ({k: old.get(k) for k in ("ss", "ff", "parasitics", "job")} if old else None))
        if "tt" in pick:
            e["tt"] = pick["tt"]
        e.pop("block", None)
        d["blocks"][j["spec"]["block"]] = e
        _store_variant(d, j, e)
        d["updated"] = now_iso()
        p.write_text(json.dumps(d, indent=1) + "\n")
        (STATE / "measured.dirty").write_text(now_iso())


def assumed_insertion(j):
    # bf-insertion 2026-10-08: only a SAME-VARIANT measurement is an assumption (see variant_key); the budget-sheet
    # fallback below stays (a sheet is per master/pin contract, not per variant)
    m, why = same_variant_insertion(j)
    if m is None and why and "another variant" in why:
        j["ins_assume_skip"] = why
    if route_ref(j):
        # CALIB-CORNER: a TC/TT route references its IO to the TT insertion: the block's routed TT (grade routed), else
        # a calibrate's TT; none -> no assumption (sequential CTS-only calibrate, minutes)
        if not (m and m.get("tt") and m.get("ff")):
            return None, None
        t = m["tt"]
        env = {}
        for k, key in (("MEAN", "mean"), ("MIN", "min"), ("MAX", "max")):
            env[f"CK_SS_{k}"] = env[f"CK_SS_ALL_{k}"] = env[f"CK_TT_{k}"] = env[f"CK_TT_ALL_{k}"] = round(float(t[key]))
            env[f"CK_FF_{k}"] = env[f"CK_FF_ALL_{k}"] = round(float(m["ff"][key]))
            if m.get("ss"):
                env[f"CK_SSLIB_{k}"] = round(float(m["ss"][key]))
        env["CK_ROUTE_REF"] = "TT"
        return env, (f"measured_insertion.json TT ({m.get('grade') or 'calibrate'}, {m.get('job')}, "
                     f"{m.get('measured_at')})")
    if m and m.get("ss") and m.get("ff"):
        v = dict(ss=m["ss"]["mean"], ss_min=m["ss"]["min"], ss_max=m["ss"]["max"],
                 ff=m["ff"]["mean"], ff_min=m["ff"]["min"], ff_max=m["ff"]["max"])
        src = f"measured_insertion.json ({m.get('job')}, {m.get('measured_at')})"
    else:
        ins = (j.get("budget") or {}).get("insertion") or {}
        if not all(k in ins for k in ("ss", "ff")):
            return None, None
        v = dict(ss=ins["ss"], ss_min=ins.get("ss_min", ins["ss"]), ss_max=ins.get("ss_max", ins["ss"]),
                 ff=ins["ff"], ff_min=ins.get("ff_min", ins["ff"]), ff_max=ins.get("ff_max", ins["ff"]))
        src = f"budget sheet ({ins.get('grade')})"
    env = {}
    for c in ("ss", "ff"):
        for k, key in (("MEAN", c), ("MIN", c + "_min"), ("MAX", c + "_max")):
            env[f"CK_{c.upper()}_{k}"] = env[f"CK_{c.upper()}_ALL_{k}"] = round(float(v[key]))
    return env, src


def start_parallel_calibrate(j, stl, st):
    if j["spec"].get("calibrate_parallel") is False:
        return False
    # Scalar insertion history cannot replace this run's own CTS database.
    # Explicit artifact consumers and existing per-tap recipes must finish
    # calibration before the route derives its source latencies.
    route_cmd = (j["spec"].get("stages", {}).get("route") or {}).get("cmd", "")
    if st.get("requires_artifacts") or "tap_latency.py" in route_cmd:
        event(j, "calibrate first: route requires completed calibration artifacts")
        return False
    c0 = j.get("ctrack")
    if c0 and c0.get("state") == "done" and c0.get("measured"):
        # moved back to calibrate (pre-CTS host move): the measurement exists, route on it
        env, src = {**c0["assumed"], **{k: v for k, v in c0["measured"].items() if v is not None}}, "measured (parallel calibrate)"
    else:
        # a pending / running / failed track of an earlier placement (host move) is replaced
        env, src = assumed_insertion(j)
    if not env:
        why = j.pop("ins_assume_skip", None)
        if why:
            event(j, f"no same-variant measured insertion ({why}): calibrate first (CTS-only), route after")
        return False
    if c0 and c0.get("state") == "running":
        try:
            ssh(c0["host"], f"p=$(cat {c0['run']}/cl/{c0['tag']}.pid 2>/dev/null); [ -n \"$p\" ] && kill -TERM -- -$p 2>/dev/null; true",
                timeout=60)
        except Exception:  # noqa: BLE001
            pass
    text = "".join(f"{k}={v}\n" for k, v in env.items())
    r = ssh(j["host"], f"mkdir -p {j['run']}/cl && cat > {j['run']}/cl/calib.env && cp {j['run']}/cl/calib.env "
                       f"{j['run']}/cl/calib.assumed.env", input=text, timeout=60)
    if r.returncode:
        return False
    bud = active_budget(j["spec"])
    if route_ref(j) and bud and j.get("budget") and not bud.get("preserve_full_sheet"):
        # CALIB-CORNER: budget route/sign-off SDCs on the assumed route-corner (TT) insertion, not the sheet's SS one
        try:
            ov = dict(ss=env["CK_SS_MEAN"], ss_min=env["CK_SS_MIN"], ss_max=env["CK_SS_MAX"], ff=env["CK_FF_MEAN"],
                      ff_min=env["CK_FF_MIN"], ff_max=env["CK_FF_MAX"], grade="assumed-tt", source=src, over_target=False)
            for fn, text in budget_files(bud, insertion_override=ov).items():
                if not fn.startswith("_"):
                    ssh(j["host"], f"cat > {j['run']}/cl/{fn}", input=text, timeout=60, check=True)
        except Exception as ex:  # noqa: BLE001
            event(j, f"CALIB-CORNER: budget SDCs at the TT assumption failed ({ex}): sequential calibrate")
            return False
    if c0 and c0.get("state") == "done":
        j["stage_idx"] += 1
        event(j, f"calibrate already measured in parallel: route on {src}")
        return True
    j["ctrack"] = dict(state="pending", assumed=env, source=src, sdc_cmd=st.get("sdc_cmd"), n=0,
                       stage_idx=j["stage_idx"])
    j["stage_idx"] += 1
    event(j, f"calibrate in PARALLEL: route starts now on the assumed insertion ({src}: SS {env['CK_SS_MEAN']} / "
             f"FF {env['CK_FF_MEAN']}); the measurement is checked at the verdict")
    return True


def cal_track(j, fleet, stl):
    c = j.get("ctrack")
    if not c or c.get("state") in ("done", "failed") or j["status"] in TERMINAL or \
            j["status"] in ("QUEUED", "SYNC", "MIGRATING") or not j.get("host"):
        return
    st = stl[c["stage_idx"]] if c["stage_idx"] < len(stl) and stl[c["stage_idx"]]["kind"] == "calibrate" else \
        next((x for x in stl if x["kind"] == "calibrate"), None)
    if st is None:
        c["state"] = "failed"
        return
    if c["state"] == "pending":
        fleet.probe(j["host"])
        with FLEET_LOCK:
            ok, why = fleet.fits(j["host"], st["threads"], st["ram"])
            if not ok:
                return
            launch_token = fleet._launched(j["host"], st["threads"], st["ram"], actual=True)
        c["n"] += 1
        v = dict(j, attempt=f"{j['attempt']}c{c['n']}")
        try:
            launch_stage(v, st, retry_aside(dict(j, attempt=2), st) + st["cmd"])   # an old _cal dir is moved aside
        finally:
            fleet.launch_complete(j["host"], launch_token)
        c.update(state="running", tag=v["stage_tag"], host=j["host"], run=j["run"], started=now_iso())
        event(j, f"parallel calibrate launched ({c['tag']}) beside {j.get('stage_key')}")
        return
    v = dict(j, host=c["host"], run=c["run"], stage_tag=c["tag"])
    state, rc = poll_stage(v)
    if state in ("RUNNING", "STARTING", "UNREACHABLE"):
        return
    if state == "LOST" or rc != 0:
        c["state"] = "failed"
        txt = fp_lint_failed(c["host"], c["run"], c["tag"]) if state != "LOST" else None
        if txt:
            fp_lint_finish(j, c["tag"], txt)
            return
        event(j, f"parallel calibrate failed ({state}, rc={rc}): the route keeps its assumed insertion")
        return
    r = ssh(c["host"], f"cat {c['run']}/cl/calib.json", timeout=60)
    try:
        cj = json.loads(r.stdout)
        j["calibration"] = {k: cj[k] for k in ("ss", "ff", "env", "db", "clock", "parasitics")}
        macro_clk_flag(j, cj)
    except (ValueError, KeyError, TypeError) as ex:
        if r.returncode == 255:
            return
        c["state"] = "failed"
        event(j, f"parallel calibrate: calib.json unreadable ({ex}); the route keeps its assumed insertion")
        return
    menv = j["calibration"]["env"]
    c["measured"] = {k: menv.get(k) for k in c["assumed"] if "ALL" not in k}
    c["delta_ps"] = max(abs(float(menv[k]) - float(c["assumed"][k])) for k in ("CK_SS_MEAN", "CK_FF_MEAN") if k in menv)
    c["state"] = "done"
    event(j, f"parallel calibrate: measured SS {menv.get('CK_SS_MEAN')} / FF {menv.get('CK_FF_MEAN')} vs assumed "
             f"{c['assumed']['CK_SS_MEAN']} / {c['assumed']['CK_FF_MEAN']} (max delta {c['delta_ps']:.0f} ps)")
    record_measured(j)
    try:
        dev = budget_check(j)
    except Exception as ex:  # noqa: BLE001
        dev = f"budget check error {ex}"
    if dev:
        c["budget_dev"] = dev
        event(j, f"BUDGET FLAG (parallel calibrate): {dev}")


def cal_reroute(j, stl, closed):
    c = j.get("ctrack") or {}
    if c.get("state") != "done" or c.get("delta_ps", 0) <= CAL_REROUTE_PS or j.get("cal_rerouted"):
        return False
    ri = next((i for i, x in enumerate(stl) if x["kind"] == "route"), None)
    if ri is None:
        return False
    j["cal_rerouted"] = now_iso()
    j["stage_idx"], j["stage_key"] = ri, "route"
    j["attempt"] = (j["attempt"] if isinstance(j["attempt"], int) else 1) + 1
    j["status"] = "READY"
    mr = j.get("meas_resta") or {}
    how = (f"measured-clock re-STA FAILED: TT {mr.get('tt')} / FF {mr.get('ff')}" if mr.get("available")
           else f"no measured-clock re-STA: {mr.get('why', 'not run')}")
    event(j, f"measured insertion moved {c['delta_ps']:.0f} ps > {CAL_REROUTE_PS:.0f} from the route's assumption "
             f"({'CLOSED' if closed else 'NOT CLOSED'} on the assumption; {how}): re-route on the measured insertion")
    return True


def step(j, fleet):
    spec = j["spec"]
    stl = stage_list(spec)
    s = j["status"]
    if s == "READY" and (not j.get("commit_full") or j.get("source_synced") is False):
        j["status"] = "SYNC" if j.get("host") else "QUEUED"
        event(j, "source synchronization incomplete; preserve stage position and synchronize before launch")
        return
    if s in ("QUEUED", "READY", "SYNC") and "bench_par" not in j:
        bench_par_decide(j, stl)
    if not bench_track(j, fleet, stl):
        return
    cal_track(j, fleet, stl)
    if s == "QUEUED" and checkpoint_location(j):
        require_checkpoint_location(j)
        j["status"] = s = "SYNC"  # stay with preserved stage_idx and checkpoint host
    if s == "QUEUED":
        held = job_held(j)
        if held:            # OWNER OPTION B (2026-10-07): SS-wall jobs paused until re-evaluated at TT
            why = f"HELD ({held})"
            if j.get("wait") != why:
                j["wait"] = why
                event(j, why)
            return
        with FLEET_LOCK:
            h, why = (None, "every usable host is wanted by a waiting priority job") \
                if yield_to_priority(j, fleet) else fleet.choose(spec, exclude=[
                    x for x, p in getattr(fleet, "prio_hosts", {}).items() if p > job_priority(j)])
            if h:   # claim capacity now so parallel job threads do not pick the same headroom
                fleet.launched(h, spec.get("threads", 16), claim_ram(spec), j["name"])  # 2026-10-08: claim real size
        if not h:
            if j.get("wait") != why:
                j["wait"] = why
                event(j, f"waiting for capacity: {why}")
            return
        j["wait"] = None
        j["host"], j["run"] = h, f"{run_base(h)}/{j['name']}"
        j["hosts_tried"].append(h)
        j["status"] = "SYNC"
        experiment(j, "running: sync source", register=True)
        s = "SYNC"
    if s == "SYNC":
        try:
            sync_source(j)
        except ValueError as ex:
            finish(j, "NEEDS_HUMAN", str(ex), f"NEEDS_HUMAN: {ex}")
            return
        event(j, f"source {j['commit_full'][:12]} synced to {j['host']}:{j['run']}/src")
        j["status"], j["reason"] = "READY", None   # drop a stale failure reason (e.g. an earlier "not on origin")
        return
    if s == "READY":
        st = stl[j["stage_idx"]]
        j["stage_key"] = st["key"]
        if st["kind"] == "calibrate" and start_parallel_calibrate(j, stl, st):
            return
        if st["kind"] in ("verdict", "collect", "export", "commit") and adoption_held(j):
            return
        if st["kind"] == "verdict":
            if (j.get("ctrack") or {}).get("state") in ("pending", "running"):
                if j.get("wait") != "calibrate":
                    j["wait"] = "calibrate"
                    event(j, "verdict waits for the parallel calibrate")
                return
            if j.get("bench_par") and not benches_done(j, stl):
                if j.get("wait") != "benches":
                    j["wait"] = "benches"
                    event(j, "verdict waits for the parallel bench track")
                return
            return do_verdict(j, fleet, stl)
        if st["kind"] == "commit":
            if j["spec"].get("smoke"):      # host smoke test: timing verdict passed; nothing is recorded or merged
                m = j.get("metrics", {})
                finish(j, "SMOKE_OK", f"smoke test on {j['host']}: {setup_corner_label(m)} {m.get('ss_ps')} / FF {m.get('ff_ps')} / DRC {m.get('drc')}",
                       f"SMOKE_OK on {j['host']}: {setup_corner_label(m)} {m.get('ss_ps')} / FF {m.get('ff_ps')} / DRC {m.get('drc')} (not published)")
                return
            return do_commit(j)
        fleet.probe(j["host"])                 # (cached 45 s) probe outside the lock
        with FLEET_LOCK:
            go = launch_ready(j, fleet, spec, stl, st)
        if go:
            launch_now(j, fleet, go)
        return
    if s == "RUNNING":
        st = stl[j["stage_idx"]]
        state, rc = poll_stage(j)
        if state == "RUNNING" and st["kind"] == "bench":
            bench_timed_out(j, st, j.get("stage_started"))
        if state == "STARTING" and st["kind"] != "bench":
            # stuckscan 2026-10-08: a stage with no pid file long after its launch never started (hbm_pkt_ii3ref route.a3:
            # run dir emptied by a disk sweep, polled STARTING for 16 h) -> the crash path (LOST: retry once elsewhere)
            try:
                age = time.time() - dt.datetime.fromisoformat(j.get("stage_started")).timestamp()
            except Exception:  # noqa: BLE001
                age = 0
            if age > STARTING_TIMEOUT_S:
                return crash(j, st, fleet, f"LOST: stage {j.get('stage_tag')} never started (no pid file {age / 60:.0f} min "
                                           f"after launch)")
        if state in ("RUNNING", "STARTING"):
            if j.get("unreachable"):     # 2026-10-08: clear a stale "unreachable" as the latest event once polling works
                event(j, f"{j['host']} reachable again; {st['key']} still running")
                j["unreachable"] = 0
            stuck_watchdog(j, st)
            if st["kind"] in ("route", "calibrate") and state == "RUNNING" and j["spec"].get("fp_lint", True) is not False:
                textbook_note(j)
            if st["kind"] == "route" and state == "RUNNING":
                early_fail_gate(j, st)
            return
        if state == "UNREACHABLE":
            if host_down_requeue(j, st["kind"]):
                return
            j["unreachable"] = j.get("unreachable", 0) + 1
            if j["unreachable"] in (1, 30):
                event(j, f"{j['host']} unreachable while polling {st['key']} (will keep polling)")
            return
        j["unreachable"] = 0
        if state == "LOST":
            return crash(j, st, fleet, "LOST: stage wrapper gone without an rc file")
        kills = stage_oom_kills(j, st)
        if kills:
            return oom_retry(j, st, fleet, kills)
        ok_extra, okout = remote_ok(j, st.get("ok"))
        if st["kind"] == "bench":
            tail = stage_tail(j, st, 40)
            if bench_crashed(st, rc, tail):
                return crash(j, st, fleet, f"bench tool crash: rc={rc} ({'negative control' if st['expect'] == 'fail' else 'positive bench'}"
                                           f" with no verdict evidence)")
            passed = bench_outcome(j, st, rc, ok_extra)
            race = "" if passed else bench_tool_race(j, tail)
            if race:
                return crash(j, st, fleet, f"bench tool race: rc={rc} (BENCH-TOOL-RACE: {race[:200]})")
            j["benches"][st["key"]] = dict(expect=st["expect"], rc=rc, ok=passed, tail=tail[-600:])
            if not passed:
                finish(j, "NEEDS_RTL", f"{st['key']} expected {st['expect'].upper()} but rc={rc}{bench_why(j, st, rc, ok_extra)}",
                       f"NEEDS_RTL: bench {st['key']} expected {st['expect'].upper()}, got rc={rc}\n" +
                       "\n".join(tail.strip().splitlines()[-5:]))
                return
            event(j, f"{st['key']} {('PASS' if st['expect'] == 'pass' else 'FAIL as expected')} (rc={rc}) "
                     f"{(j.get('bench_work') or {}).get(st['key'], '')}")
        else:
            if st["kind"] in ("route", "calibrate"):
                hm_auto_events(j)
            if rc != 0 and ok_extra and st["kind"] == "signoff" and st.get("ok"):
                # a sign-off script that exits non-zero for "not closed" but wrote its evidence (the job's ok check
                # passes) is a verdict, not a crash: w2-rb-safe-no2/no3 exited 1 on SS -18.9 and the retry then refused
                # to overwrite the evidence -> false NEEDS_HUMAN. The verdict stage judges the numbers.
                event(j, f"{st['key']} rc={rc} with its evidence present (ok check passed): judged at the verdict")
            elif rc != 0 or not ok_extra:
                return crash(j, st, fleet, f"rc={rc}{'' if ok_extra else ' ok-check failed: ' + okout.strip()[-200:]}")
            event(j, f"{st['key']} done (rc={rc})")
            if st["kind"] == "route":
                # LAYOUT IMAGES (owner rule 20:45 10-15): ref_route.sh renders floorplan / density / congestion PNGs
                # beside the route; the paths go into the job record so the owner LOOKS at them with the verdict
                r = ssh(j["host"], f"ls {j['run']}/routes/*/layout/*.png 2>/dev/null", timeout=60)
                pngs = [x for x in (r.stdout or "").split() if x.endswith(".png")]
                if pngs:
                    j["layout_images"] = {"host": j["host"], "paths": pngs}
                    event(j, f"LAYOUT images ({j['host']}): " + " ".join(pngs))
            if st["kind"] == "calibrate":
                r = ssh(j["host"], f"cat {j['run']}/cl/calib.json", timeout=60)
                if r.returncode == 255:
                    j["wait"] = "completed calibration: artifact transport unavailable"
                    return  # Retry the read, never the completed physical stage.
                try:
                    if r.returncode:
                        raise ValueError(f"artifact read exited {r.returncode}")
                    c = json.loads(r.stdout)
                    j["calibration"] = {k: c[k] for k in ("ss", "ff", "env", "db", "clock", "parasitics")}
                    macro_clk_flag(j, c)
                    if not isinstance(c["env"], dict):
                        raise ValueError("calibration env must be an object")
                except (ValueError, KeyError, TypeError) as ex:
                    finish(j, "NEEDS_HUMAN", f"completed calibration artifact invalid: {ex}",
                           "NEEDS_HUMAN: inspect/recover calib.json; completed physical stage preserved")
                    return
                j["wait"] = None
                event(j, "calibrated insertion " + " ".join(f"{k}={v}" for k, v in c["env"].items() if "ALL" not in k))
                record_measured(j)
                dev = budget_check(j)
                if dev:
                    if j["spec"]["budget"].get("on_deviation", "flag") == "flag":
                        finish(j, "NEEDS_BUDGET", dev[:200],
                               f"NEEDS_BUDGET: {j['budget']['master']} block clock insertion off its budget sheet ({dev}). "
                               "Re-plan the die entry target (tools/budgets) or fix the block tree, then retry; the IO SDC "
                               "is NOT re-calibrated silently.")
                        return
                    event(j, f"BUDGET FLAG (continuing on the sheet SDC): {dev}")
                    ledger(j, f"BUDGET FLAG {j['budget']['master']}: {dev} (on_deviation=continue)")
                elif j.get("budget"):
                    event(j, f"budget check OK: measured insertion {j['budget']['check']['measured_ss']:g} <= target "
                             f"{j['budget']['insertion']['target_ss']:g} (sheet {j['budget']['insertion']['ss']:g}); budget SDCs "
                             f"regenerated from the measured insertion")
                    record_measured(j)
        j["stage_idx"] += 1
        j["status"] = "READY"
        return
    if s in ("ECO", "ECO_RESULT", "ECO_INSTALL"):
        state, rc = ("DONE", j["eco"]["rc"]) if s == "ECO_RESULT" else poll_stage(j)
        if state == "UNREACHABLE" and host_down_requeue(j, s):
            return
        if state in ("RUNNING", "STARTING", "UNREACHABLE"):
            return
        if s in ("ECO", "ECO_RESULT"):
            if s == "ECO":
                r = ssh(j["host"], f"cat {eco_output(j)}/result.json 2>/dev/null", timeout=60)
                try:
                    res = json.loads(r.stdout)
                except Exception:  # noqa: BLE001
                    res = None
                j["eco"]["result"], j["eco"]["rc"] = res, rc
                j["eco"]["completed_at"] = now_iso()
                # Consume the terminal receipt before downstream helper validation/launch.
                # A failed summary launch must never poll or log this completed ECO again.
                j["status"] = "ECO_RESULT"
                ok = eco_passes(res, rc)
                vt = j["eco"].get("kind") == "vtswap"
                event(j, f"{'VT-swap' if vt else 'hold'} ECO {'PASS' if ok else 'MISS'}: {res if res else 'no result (rc=' + str(rc) + ')'}")
                save_job(j)
            else:
                res = j["eco"].get("result")
                ok = eco_passes(res, rc)
                vt = j["eco"].get("kind") == "vtswap"
            if not ok:
                if s == "ECO":
                    ledger(j, f"{'VT-SWAP' if vt else 'HOLD'}-ECO missed: before SS {j['eco']['pre']['ss_ps']:+.2f} / FF {j['eco']['pre']['ff_ps']:+.2f}, "
                          f"after {res}")
                m = j.get("metrics", {})
                prev = j["eco"]
                if (prev.get("kind") == "combo" and res and combo_hold_retry_eligible(res)
                        and start_combo_hold_retry(j, fleet, m, prev)):
                    return             # drive-0849: one stacked hold pass on the combo result
                if vt and vtswap_eligible(j, m, j.get("failed_checks") or []) and start_vtswap_eco(j, fleet, m):
                    if j["eco"] is prev:   # no capacity yet: re-judged at the verdict stage next tick, which relaunches
                        j["status"] = "READY"
                    return             # next VT-swap target launched
                if not summarize_failure(j, fleet, m):
                    text = failure_text(j)
                    finish(j, "NEEDS_RTL", text.split("\n")[0][11:], text)
                return
            st = dict(key="eco_install", kind="eco_install", threads=1, ram=4)
            launch_stage(j, st, eco_install_cmd(j))
            j["status"], j["stage_key"] = "ECO_INSTALL", "eco_install"
            return
        if rc != 0:
            finish(j, "NEEDS_HUMAN", f"hold ECO passed but install/re-export failed (rc={rc})",
                   f"NEEDS_HUMAN: hold ECO passed ({j['eco']['result']}) but install/re-export failed rc={rc}; see {j['run']}/cl")
            return
        j["eco"]["installed"] = now_iso()
        ledger(j, f"HOLD-ECO installed: SS {j['eco']['pre']['ss_ps']:+.2f}/FF {j['eco']['pre']['ff_ps']:+.2f} -> "
                  f"SS {j['eco']['result']['ss_ps']:+.2f}/FF {j['eco']['result']['ff_ps']:+.2f}, DRC {j['eco']['result']['drc']}, "
                  f"{j['eco']['result'].get('cells_added')} cells; re-verdict")
        j["status"] = "READY"          # stage_idx still points at the verdict: re-judged on the ECO sign-off
        return
    if s == "SUMMARY":
        state, rc = poll_stage(j)
        if state == "UNREACHABLE" and host_down_requeue(j, s):
            return
        if state in ("RUNNING", "STARTING", "UNREACHABLE"):
            return
        text = failure_text(j)
        finish(j, "NEEDS_RTL", text.split("\n")[0][11:], text)


def adoption_held(j):
    """A live owner hold prevents adoption while physical evidence can finish."""
    path = STATE / "adoption_holds" / f"{j['name']}.json"
    if not path.exists():
        return False
    reason = json.loads(path.read_text())["reason"]
    note = f"adoption hold: {reason}"
    if j.get("wait") != note:
        j["wait"] = note
        event(j, note)
    return True


def hm_auto_lines(text):
    """OT_HM_AUTO report lines (tools/orfs_hold_mm.tcl ot_hm_guard) -> event texts"""
    return [ln.split("OT_HM_AUTO", 1)[1].strip() for ln in text.splitlines() if ln.startswith("OT_HM_AUTO")]


def hm_auto_events(j):
    """HM-GUARD (2026-10-08): a route-time hold repair that auto-reduced its margin (too many endpoints inside HM / too
    much projected buffer area) leaves REPORTS_DIR/ot_hm_auto_<stage>.rpt: one job event per report and attempt"""
    try:
        r = ssh(j["host"], f"cat $(find {j['run']}/routes -name 'ot_hm_auto_*.rpt' 2>/dev/null | head -4) "
                           f"</dev/null 2>/dev/null", timeout=60)
    except Exception as ex:  # an event is informative only: never fail a stage on it
        log(f"[{j['name']}] hm_auto_events: {ex}")
        return
    seen = j.setdefault("hm_auto_seen", [])
    for ln in hm_auto_lines(r.stdout or ""):
        key = f"{j.get('attempt')}|{ln}"
        if key not in seen:
            seen.append(key)
            event(j, ln)
    j["hm_auto_seen"] = seen[-20:]


RECORD_DIR = "{RUN}/record"


def precollect_cmd(spec):
    """drive-0212 2026-10-09: the collect stage runs AFTER the verdict, but a verdict check may read what collect writes
    (s81-dsfd-hstnh-515-pe-4a12f4d5d-tc-cl: lef_check_MATCH on {RUN}/record/check.json, written only by collect's
    s81_die_view_ports check), so the check could never pass (TT +84.94 / FF +8.01 / DRC 0 -> NEEDS_RTL).  When a check
    reads {RUN}/record and the collect command writes it, the verdict runs the collect command first (collect is an
    idempotent export: it runs again after the verdict as before)."""
    col = ((spec.get("stages") or {}).get("collect") or {}).get("cmd") or ""
    checks = (spec.get("verdict") or {}).get("checks") or []
    if RECORD_DIR in col and any(RECORD_DIR in (c.get("cmd") or "") for c in checks):
        return col
    return None


ROUTE_CORNER_CHECK = "ttb_routed_at_TC"


def overlay_skipped(j):
    """PATHPICK: True when the job's command runs the TT overlay but {CL}/ttb_corner.txt (its mark) was never written"""
    cmds = " ".join(str((st or {}).get("cmd") or "") for st in ((j["spec"].get("stages") or {}).values())
                    if isinstance(st, dict))
    if "OT_TTB_CORNER_MARK={CL}/ttb_corner.txt" not in cmds or not j.get("host") or not j.get("run"):
        return False
    try:
        # the mark can come from another overlay call in the same command (s81dvbk_sq-q1 route.a2: the resumed route's
        # overlay failed "can't open file .../tt_overlay.py\ntools/..." while an earlier call had written TC): the
        # newest route log naming a failed overlay / missing fleet path counts as skipped too
        r = ssh(j["host"], f"L=$(ls {j['run']}/cl/route.a*.log 2>/dev/null | sort -V | tail -1); "
                           f"if [ -n \"$L\" ] && grep -q -E \"can.t open file .*tt_overlay|OT_FLOW_MISSING\" \"$L\"; "
                           f"then echo NOMARK; elif test -s {j['run']}/cl/ttb_corner.txt; then echo MARK; else echo NOMARK; fi",
                timeout=60)
    except Exception:  # noqa: BLE001
        return False
    return "NOMARK" in (r.stdout or "")


def route_corner_check_cmd(c):
    """LOOP-CORNER 2026-10-10: the ttb_routed_at_TC check only grepped {CL}/ttb_corner.txt, where tt_overlay also writes
    'TC ...' for unrelated patches (direct config.mk); SM piece routes that loaded SS liberties passed it (and closed at
    the wrong corner).  The check now also proves the corner from the route logs: every setup corner's read_liberty
    lines in the place / CTS / GRT logs under {RUN} name TT views (route_corner_check.py, sent inline so a job launched
    before the helper existed is judged the same way).  Other checks: unchanged."""
    cmd = c.get("cmd") or ""
    if c.get("name") != ROUTE_CORNER_CHECK or "route_corner_check" in cmd:
        return cmd
    src = (HERE / "route_corner_check.py").read_text()
    return f"( {cmd} ) && python3 -c {shlex.quote(src)} {{RUN}} --want TT"


def do_verdict(j, fleet, stl):
    if adoption_held(j):
        return
    v = j["spec"].get("verdict", {})
    m = get_metrics(j)
    if re.search(r"kex_exchange|Connection (reset|refused|closed|timed out)|ssh:", str(m.get("error", ""))):
        j["verdict_ssh_fail"] = j.get("verdict_ssh_fail", 0) + 1
        if j["verdict_ssh_fail"] < 20:
            event(j, f"verdict: ssh to {j['host']} failed, retrying next tick")
            return
    j["metrics"] = m
    checks, failed = {}, []
    pre = precollect_cmd(j["spec"])
    if pre:
        ok, out = remote_ok(j, pre, timeout=3600)
        if not ok and TRANSIENT_RE.search(out):
            raise RuntimeError(f"verdict pre-collect: ssh/network failure: {out.strip()[-200:]}")
        event(j, f"verdict: ran the collect stage first (a check reads {{RUN}}/record): rc {'0' if ok else 'nonzero'}"
                 + ("" if ok else f": {out.strip()[-200:]}"))
    for c in v.get("checks", []):
        # verdict checks may run real tools (stn_pa_check.sh routes a pin-access probe: > 300 s on AGIdock, which put
        # hbm_stn_mcast_r5/r6 into NEEDS_HUMAN as "loop errors"); spec checks[].timeout_s, default 1800
        ok, out = remote_ok(j, route_corner_check_cmd(c), timeout=c.get("timeout_s", 1800))
        if not ok and TRANSIENT_RE.search(out):
            # an ssh failure is not a failed check (hbm_stn_mcast_r6b: 'Connection reset by peer' failed lef_check_MATCH
            # while check.json said MATCH): raise, so the verdict backs off and is re-taken
            raise RuntimeError(f"verdict check {c['name']}: ssh/network failure: {out.strip()[-200:]}")
        checks[c["name"]] = dict(ok=ok, out=out[-300:])
        if not ok and restates_line(c):
            checks[c["name"]]["restates_line"] = True     # judged by the line itself, below (drive-0212)
        elif not ok:
            failed.append(c["name"])
    j["checks"], j["failed_checks"] = checks, failed
    if ROUTE_CORNER_CHECK in failed and overlay_skipped(j):
        # PATHPICK 2026-10-18: the route ran WITHOUT the TT overlay / CTS fix hooks (a fleet-path pick failed): its
        # slacks are not a measurement of this design -- a FLOW failure, never NEEDS_RTL and never CLOSED
        finish(j, "NEEDS_HUMAN", "FLOW_FAILURE: TT overlay did not run (no {CL}/ttb_corner.txt): resubmit with "
                                 "reroute_reason flow_failure",
               "NEEDS_HUMAN: FLOW_FAILURE: the route ran without the TT overlay / OT_CTS_FIX_HOOKS ({CL}/ttb_corner.txt "
               "never written; see the route log for OT_FLOW_MISSING / can't open file); the slacks are not valid. "
               "Resubmit with reroute_reason flow_failure.")
        return
    if (j.get("eco") or {}).get("installed"):     # the post-route hold ECO replaced the route: its DRC counts
        m["drc"], m["eco"] = j["eco"]["result"]["drc"], j["eco"]["result"]
    ss, ff, drc = m.get("ss_ps"), m.get("ff_ps"), m.get("drc")
    if ss is None or ff is None or drc is None:
        finish(j, "NEEDS_HUMAN", f"verdict inputs missing ({json.dumps(m)[:300]})",
               f"NEEDS_HUMAN: verdict inputs missing: {json.dumps(m)[:400]}")
        return
    benches_ok = all(b["ok"] for b in j["benches"].values()) and benches_done(j, stl)
    closed = real_slack(ss) and real_slack(ff) and ss >= SS_MIN and ff >= FF_MIN and drc == 0 and not failed and benches_ok and not m.get("errors")
    if not (real_slack(ss) and real_slack(ff)):
        event(j, f"SENTINEL-SLACK: TT {ss} / FF {ff} = no constrained path (constraints not applied or clock not found): "
                 f"never CLOSED")
    event(j, f"verdict {setup_corner_label(m)} {ss:+.2f} / FF {ff:+.2f} / DRC {drc} / checks failed {failed} -> "
             f"{'CLOSED' if closed else 'NOT CLOSED'}")
    rr = routed_ioref(j, m)
    if rr and rr.get("available"):
        # FLOW-IOREF: the sign-off IS the routed-insertion re-STA (either direction); the route-SDC numbers are kept
        m.update(setup_corner="tt", ss_ps=rr["tt"], ff_ps=rr["ff"], routed_ioref=rr, route_sdc_clock=dict(ss_ps=ss, ff_ps=ff),
                 post_sdc=list(m.get("post_sdc") or []) + ([IOREF_SDC] if IOREF_SDC not in (m.get("post_sdc") or []) else []))
        if m.get("setup_post_sdc") and IOREF_SDC not in m["setup_post_sdc"]:
            # setup-only post-SDCs (nbr_clk_measured: -source latency) are read after the post-SDCs: re-read it last
            m["setup_post_sdc"] = list(m["setup_post_sdc"]) + [IOREF_SDC]
        ss, ff = rr["tt"], rr["ff"]
        closed = real_slack(ss) and real_slack(ff) and ss >= SS_MIN and ff >= FF_MIN and drc == 0 and not failed and benches_ok and not m.get("errors")
        j["metrics"] = m
        event(j, f"verdict at the ROUTED insertion: TT {ss:+.2f} / FF {ff:+.2f} -> {'CLOSED' if closed else 'NOT CLOSED'}")
    uc = under_constrained(rr)
    if uc:
        failed.append("UNDER-CONSTRAINED")
        j["failed_checks"] = failed
        closed = False
        event(j, f"UNDER-CONSTRAINED: {uc}: constraints did not apply; never CLOSED")
    # the calibrate-insertion re-STA / re-route is moot once the route is timed on its own tree
    mr = None if (rr and rr.get("available")) else measured_resta(j, m)
    if mr and mr.get("available"):
        mclosed = not uc and real_slack(mr["tt"]) and real_slack(mr["ff"]) and mr["tt"] >= SS_MIN and mr["ff"] >= FF_MIN and drc == 0 and not failed and benches_ok
        if mclosed:
            # the finished route signs off on the MEASURED clock: no re-route; its verdict numbers are the measured ones
            m.update(setup_corner="tt", ss_ps=mr["tt"], ff_ps=mr["ff"], measured_resta=mr, assumed_clock=dict(ss_ps=ss, ff_ps=ff))
            j["metrics"], ss, ff, closed = m, mr["tt"], mr["ff"], True
            event(j, f"measured-clock re-STA CLOSES the route (TT {ss:+.2f} / FF {ff:+.2f}): no re-route")
    if not (rr and rr.get("available")) and not (mr and mr.get("available") and closed) and cal_reroute(j, stl, closed):
        return
    if closed:
        try:
            note_closed(j, m)          # LOST-CLOSED (ROOT-1130): the closure and its ECO outlive any later attempt
        except Exception:  # noqa: BLE001 - bookkeeping never blocks a closure
            log(f"[{j['name']}] note_closed error:\n{traceback.format_exc()}")
        j["stage_idx"] += 1
        j["status"] = "READY"
        experiment(j, f"running: collect/export/merge ({setup_corner_label(m)} {ss:+.1f} / FF {ff:+.1f})")
        return
    if ff < FF_MIN:
        # UNSTICK 2026-10-08: route-time hold repair stopped by the hold-stall guard (orfs_hold_mm.tcl): the window is
        # structural (pin registers / input-min / H1 SDC), a hold ECO would crawl the same way -> NEEDS_RTL with it
        r = ssh(j["host"], f"for f in $(find {j['run']}/routes -name 'ot_hold_stall_*.rpt' -not -path '*_cal/*' 2>/dev/null "
                           f"| head -2); do echo \"== $f\"; head -45 $f; done", timeout=120)
        # drive-0828: the guard only holds when the STALLED window explains the sign-off miss.  A repair that stalled at
        # a residue far shallower than the final FF number (h1hm80: CTS stall I2O=2@-0.2, sign-off FF -8.2 on reg->out
        # at the routed reference) left the miss to post-route degradation: that is the post-route hold ECO's job.
        wins = re.findall(r"^([IR]2[OR])\s+(\d+)\s+(-?[\d.]+)", r.stdout, re.M)
        stall_worst = min((float(c) for _, _, c in wins), default=None)
        if "OT_HOLD_STALL" in r.stdout and stall_worst is not None and stall_worst > ff + 2.0:
            event(j, f"hold-stall window worst {stall_worst:+.1f} is shallower than sign-off FF {ff:+.1f}: "
                     f"the miss grew after the stalled repair -> post-route hold ECO, not NEEDS_RTL")
        elif "OT_HOLD_STALL" in r.stdout and combo_eligible(j, m, failed, benches_ok) and start_combo_eco(j, fleet, m):
            # drive-0849 2026-10-09: a thin TT AND FF miss behind a stalled route hold repair (hgi_cp-9cfc3b131: TT -44.29 /
            # FF -0.71, window I2R=20@-7.1) gets the combo ECO before the guard ends it as NEEDS_RTL
            return
        elif "OT_HOLD_STALL" in r.stdout:
            j["hold_window"] = r.stdout[-6000:]
            cls = " ".join(f"{a}={b}@{c}" for a, b, c in wins)
            i2o = feedthrough_window(j)
            finish(j, "NEEDS_RTL", (f"FF hold {ff:+.1f}: route hold repair stalled; window {cls}"
                                    + (f"; {PIN_REG_MISSING}" if i2o else ""))[:300],
                   f"NEEDS_RTL: FF hold {ff:+.1f} ps after a STALLED route-time hold repair (hold-stall guard). Window by "
                   f"path class: {cls}. Structural fix per REDESIGN_RULES (pin registers / input-min, H1 SDC); no ECO.\n"
                   + (f"{PIN_REG_MISSING}: {i2o}; no hold-margin / density variant is routed.\n" if i2o else "")
                   + r.stdout[-2500:])
            return
    if hold_only(j, m, failed, benches_ok) and start_hold_eco(j, fleet, m):
        return
    if vtswap_eligible(j, m, failed, benches_ok) and start_vtswap_eco(j, fleet, m):
        return
    if combo_eligible(j, m, failed, benches_ok) and start_combo_eco(j, fleet, m):
        return
    if not summarize_failure(j, fleet, m):
        text = failure_text(j)
        finish(j, "NEEDS_RTL", text.split("\n")[0][11:], text)


# SENTINEL-SLACK (drive-1010 2026-10-10): STA reports +1e16-ish slack when NO path is constrained (constraints not
# applied / clock not found).  hgi_idx_t4_join-sram-ff4827405-tc-cl-f9a2 was CLOSED at TT +1e16.  A slack that is not
# finite or has |slack| >= SENTINEL_PS is never a pass anywhere (route verdict, routed / measured re-STA, ECO results).
SENTINEL_PS = 1e6


def real_slack(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and abs(v) < SENTINEL_PS


# UNDER-CONSTRAINED (drive-1010 2026-10-10): a verdict needs real constrained endpoints.  The routed re-STA counts the
# registers and those clocked by a defined clock; fewer clocked registers than max(UC_MIN_REGS, UC_FRAC x registers)
# means the constraints did not apply (clock not found / wrong name) -- never CLOSED.  Blocks with no registers at all
# (pure wiring) are judged by their port paths (SENTINEL-SLACK catches 'no path').
UC_MIN_REGS = 10
UC_FRAC = 0.01


def under_constrained(rr):
    """reason string when the routed re-STA census shows too few clocked registers, else None"""
    n, c = (rr or {}).get("registers"), (rr or {}).get("registers_clocked")
    if not isinstance(n, int) or not isinstance(c, int) or n <= 0:
        return None
    floor = min(n, max(UC_MIN_REGS, UC_FRAC * n))
    return None if c >= floor else f"only {c} of {n} registers are clocked by a defined clock (< {floor:g})"


def eco_passes(res, rc):
    if rc != 0 or not isinstance(res, dict) or res.get("errors"):
        return False
    # option B: setup is judged at TT (tt_ps; older results carry it in ss_ps)
    for key, minimum in (("tt_ps" if "tt_ps" in res else "ss_ps", SS_MIN), ("ff_ps", FF_MIN)):
        value = res.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not real_slack(value) or value < minimum:
            return False
    return type(res.get("drc")) in (int, float) and res["drc"] == 0


LINE_COND_RE = re.compile(r"""\b[A-Za-z_]\w*\[["'](setup_tt|hold_ff)["']\]\s*\[["']worst_slack_ps["']\]\s*>=\s*(-?[\d.]+)""")


def restates_line(c):
    """drive-0212 (coordinator APPROVED 2026-10-09): a verdict check that only restates the TT/FF acceptance line
    (owner_TT_FF_nonnegative: corner_sta.json setup_tt / hold_ff worst_slack_ps >= 0, 18 specs) is not an independent
    condition.  Counted as a failed check it blocked the one fix that applies: qfd_emb_pc_00-0ebf67a31-tc, TT +15.99 /
    FF -59.47 / DRC 0, never got its post-route hold ECO.  Such a check is recorded but never counts as failed: the
    line itself is judged on the metrics (route, routed insertion, or the installed ECO).  A check is a restatement
    iff spec says "restates_line": true, or its command only reads corner_sta.json and asserts setup_tt >= SS_MIN /
    hold_ff >= FF_MIN (nothing stricter: owner_SS_FF_15ps keeps counting)."""
    if c.get("restates_line") is True:
        return True
    cmd = c.get("cmd") or ""
    if "corner_sta.json" not in cmd:
        return False
    conds = LINE_COND_RE.findall(cmd)
    if not conds:
        return False
    for key, val in conds:
        if float(val) != (SS_MIN if key == "setup_tt" else FF_MIN):
            return False
    m = re.search(r"\bassert\b(.*?)(?:['\"]\s*$|;|$)", cmd, re.S)
    if not m or not re.fullmatch(r"\s*C(\s+and\s+C)*\s*", LINE_COND_RE.sub("C", m.group(1))):
        return False
    files = set(re.findall(r"[\w{}./-]+\.(?:json|rpt|log|txt|csv)", cmd))
    return bool(files) and all(x.endswith("corner_sta.json") for x in files)


def blocking_checks(j):
    """the job's recorded failed checks minus restatements of the line (records written before drive-0212)"""
    rest = {c.get("name") for c in (j["spec"].get("verdict") or {}).get("checks", []) if restates_line(c)}
    return [x for x in (j.get("failed_checks") or []) if x not in rest]


def hold_only(j, m, failed=(), benches_ok=True):
    return (m.get("ss_ps") is not None and m["ss_ps"] >= SS_MIN and m.get("drc") == 0 and m.get("ff_ps") is not None
            and m["ff_ps"] < FF_MIN and not failed and benches_ok and not (j.get("eco") or {}).get("tried")
            and (j["spec"].get("hold_eco") or {}).get("enabled", True) is not False)


def vtswap_targets(j):
    he = j["spec"].get("hold_eco") or {}
    return [float(t) for t in he.get("vtswap_targets", VTSWAP_TARGETS)]


def vtswap_eligible(j, m, failed=(), benches_ok=True):
    """a thin TT setup miss the VT-swap ECO may close: TT in [VTSWAP_TT_FLOOR, 0), FF >= 0, DRC 0, no failed check /
    bench / metric error, no installed ECO, VT-swap targets left, not turned off by the spec"""
    he = j["spec"].get("hold_eco") or {}
    e = j.get("eco") or {}
    tt, ff = m.get("ss_ps"), m.get("ff_ps")
    if he.get("enabled", True) is False or he.get("vtswap", True) is False:
        return False
    if tt is None or ff is None or isinstance(tt, bool) or isinstance(ff, bool):
        return False
    # LOST-CLOSED (ROOT-1130): a re-route of a route that CLOSED with a VT-swap re-applies that recorded cell list
    # (the window floor does not apply: the same list closed the same netlist before)
    reapply = (j.get("reapply_eco") or {}).get("kind") == "vtswap" and not e.get("tried")
    if not ((VTSWAP_TT_FLOOR <= tt or reapply) and tt < SS_MIN and ff >= FF_MIN and m.get("drc") == 0):
        return False
    if failed or not benches_ok or m.get("errors") or e.get("installed") or j.get("eco_stack"):
        return False
    if e.get("tried") and e.get("kind") != "vtswap":
        return False
    done = sum(1 for x in [*(j.get("eco_history") or []), e] if (x or {}).get("kind") == "vtswap")
    return done < len(vtswap_targets(j))


def start_vtswap_eco(j, fleet, m):
    """launch vtswap_eco.sh as the job's ECO stage (tag hold_eco.aN, status ECO): the hold-ECO completion path installs /
    re-verdicts / records it unchanged (result.json -> eco_passes -> eco_install_cmd -> verdict)"""
    rb, ob = eco_paths(j, m)
    if not rb:
        return False
    ok, why = fleet.fits(j["host"], 8, 16)
    if not ok:
        event(j, f"VT-swap ECO waiting for capacity: {why}")
        return True            # stays at the verdict stage; the next tick retries
    he, v = j["spec"].get("hold_eco") or {}, j["spec"].get("verdict", {})
    e = j.get("eco") or {}
    hist = [x for x in (j.get("eco_history") or []) if x.get("kind") == "vtswap"]
    n = len(hist) + (1 if e.get("kind") == "vtswap" else 0)
    target = vtswap_targets(j)[n]
    cap = float(he.get("vtswap_cap_pct", VTSWAP_CAP_PCT))
    if e:
        j.setdefault("eco_history", []).append(e)
        j["attempt"] += 1          # a fresh stage tag: hold_eco.a<attempt>.rc of the previous ECO stays as evidence
    post_sdcs = eco_post_sdcs(j, m, "VT-swap ECO")
    tt = m["ss_ps"]
    out = f"{j['run']}/cl/eco-vtswap-t{target:g}" + (f"-r{len(j.get('eco_history') or []) + 1}" if j.get("eco_history") else "")
    env = (f"TARGET={target:g} CAP_PCT={cap:g} DRC0={int(m['drc'])} ACC_SS={SS_MIN:g} ACC_FF={FF_MIN:g} SETUP_LIB={SETUP_LIB} "
           f"SDC_NAME={shlex.quote(m.get('sdc_name') or '6_final.sdc')} THREADS=8 "
           f"MACROS={shlex.quote(' '.join(verdict_macros(j)))} ORFS_W18={shlex.quote(m.get('orfs_dir') or '')}")
    if m.get("setup_post_sdc"):
        env += f" SETUP_POST_SDC={shlex.quote(' '.join(m['setup_post_sdc']))}"
    reapply = j.get("reapply_eco") if (j.get("reapply_eco") or {}).get("kind") == "vtswap" and not e else None
    if reapply and reapply.get("swap_list") and Path(reapply["swap_list"]).is_file():
        # LOST-CLOSED (ROOT-1130): the exact cells of the closed attempt's VT-swap go LVT first
        lst = f"{j['run']}/cl/reapply_vtswap_a{reapply.get('from_attempt')}.txt"
        r = ssh(j["host"], f"mkdir -p {shlex.quote(j['run'])}/cl && cat > {shlex.quote(lst)}", timeout=120,
                input=Path(reapply["swap_list"]).read_text())
        if r.returncode == 0:
            env += f" VTSWAP_LIST={shlex.quote(lst)}"
            reapply = dict(reapply, shipped=lst)
    cmd = f"{env} bash {{CL}}/vtswap_eco.sh {rb} {ob} {out} {j['spec']['block']} " + " ".join(shlex.quote(p) for p in post_sdcs)
    ship_helpers(j["host"], j["run"], j)
    j["eco"] = dict(tried=True, kind="vtswap", rb=rb, ob=ob, out=out, post_sdc=post_sdcs, sdc_name=m.get("sdc_name") or "6_final.sdc",
                    setup_post_sdc=list(m.get("setup_post_sdc") or []), pre=dict(ss_ps=tt, ff_ps=m["ff_ps"]),
                    started=now_iso(), target_ps=target, lvt_cap_pct=cap, auto=True)
    if reapply:
        j["eco"]["reapplied_from"] = reapply
        event(j, f"re-applying the VT-swap ECO of closed attempt {reapply.get('from_attempt')} "
                 f"({reapply.get('lvt_swapped')} cells{', list ' + reapply['shipped'] if reapply.get('shipped') else ', list lost: re-derived'})")
    st = dict(key="hold_eco", kind="hold_eco", threads=8, ram=16)
    launch_token = fleet.reserve_launch(j["host"], 8, 16)
    try:
        launch_stage(j, st, cmd)
    finally:
        fleet.launch_complete(j["host"], launch_token)
    j["status"], j["stage_key"] = "ECO", "hold_eco"
    event(j, f"thin TT setup miss ({setup_corner_label(m)} {tt:+.2f} / FF {m['ff_ps']:+.2f} / DRC 0): post-route VT-swap setup ECO "
             f"(RVT->LVT on TT paths, target {target:g} ps, cap {cap:g} % LVT, FF hold guard, no re-route) on {rb}/6_final.odb")
    ledger(j, f"VT-SWAP ECO launched (loop): TT {tt:+.2f} / FF {m['ff_ps']:+.2f}, target {target:g}, LVT cap {cap:g} %")
    experiment(j, "running: post-route VT-swap setup ECO")
    return True


COMBO_HOLD_RETRY_FF = -5.0      # drive-0849: a combo result with TT >= 0 and FF in [-5, 0) gets one stacked hold pass


def combo_hold_retry_eligible(res):
    tt, ff = res.get("ss_ps"), res.get("ff_ps")
    if tt is None or ff is None or isinstance(tt, bool) or isinstance(ff, bool):
        return False
    return tt >= SS_MIN and COMBO_HOLD_RETRY_FF <= ff < FF_MIN and res.get("drc") == 0 and not res.get("errors")


def start_combo_hold_retry(j, fleet, m, prev):
    """hold_eco.sh stacked on the combo ECO's own result (ECO_RB_DB=6_final.odb of {combo out}): HM 0 + ALLOW 4 (the
    manual COMBO_MODE=hold launch of hgi_cp-8a62bf98b, TT +4.89 / FF -0.13).  Once per combo."""
    if prev.get("hold_retry"):
        return False
    ok, why = fleet.fits(j["host"], 8, 16)
    if not ok:
        event(j, f"combo hold retry waiting for capacity: {why}")
        j["status"] = "READY"
        return True
    v = j["spec"].get("verdict", {})
    post = list(prev.get("post_sdc") or [])
    pq = " ".join(shlex.quote(p) for p in post)
    sdcn = shlex.quote(prev.get("sdc_name") or "6_final.sdc")
    mac = shlex.quote(" ".join(verdict_macros(j)))
    blk = j["spec"]["block"]
    out = prev["out"] + "-h"
    henv = (f"ECO_SESSION=mm ALLOW_FRESH_GRT=0 HM=0 ALLOW=4 SM=40 FILT=40 PASSES=1 RESAWARE=1 HOLDCELLS=1 ACC_SS={SS_MIN:g} "
            f"ACC_FF={FF_MIN:g} SETUP_LIB={SETUP_LIB} KEEPCLK=0 BUF=30 MACROS={mac} THREADS=8 SDC_NAME={sdcn} ECO_RB_DB=6_final.odb")
    cmd = (f"VB=$(ls -d {prev['out']}/orfs/results/asap7/*/base | head -1); test -f $VB/6_final.odb || {{ echo no combo base; exit 3; }}; "
           f"[ -f $VB/{sdcn} ] || cp {prev['ob']}/{sdcn} $VB/; {henv} ROUTE_CFG={shlex.quote(route_cfg_of(prev['rb']))} "
           f"bash {{CL}}/hold_eco.sh $VB $VB {out} {blk} {pq}")
    ship_helpers(j["host"], j["run"], j)
    prev["hold_retry"] = True
    j.setdefault("eco_history", []).append(prev)
    j["attempt"] += 1
    j["eco"] = dict(tried=True, kind="combo_hold", rb=prev["rb"], ob=prev["ob"], combo_vtswap=prev.get("combo_vtswap"),
                    out=out, post_sdc=post, sdc_name=prev.get("sdc_name") or "6_final.sdc",
                    setup_post_sdc=list(prev.get("setup_post_sdc") or []), pre=prev.get("pre"), started=now_iso(),
                    hold_retry=True, auto=True)
    launch_token = fleet.reserve_launch(j["host"], 8, 16)
    try:
        launch_stage(j, dict(key="hold_eco", kind="hold_eco", threads=8, ram=16), cmd)
    finally:
        fleet.launch_complete(j["host"], launch_token)
    j["status"], j["stage_key"] = "ECO", "hold_eco"
    event(j, f"combo ECO result {prev.get('result', {}).get('ss_ps')} / FF {prev.get('result', {}).get('ff_ps')} misses hold by "
             f"< {-COMBO_HOLD_RETRY_FF:g} ps: one stacked hold pass (HM 0, ALLOW 4) on the combo db; out {out}")
    return True


def combo_eligible(j, m, failed=(), benches_ok=True):
    """a thin TT AND thin FF miss: TT in [COMBO_TT_FLOOR, 0), FF in [COMBO_FF_FLOOR, 0), DRC 0, no failed check / bench /
    metric error, no installed ECO, no combo ECO tried yet, not turned off by the spec (hold_eco.enabled / combo false)"""
    he = j["spec"].get("hold_eco") or {}
    e = j.get("eco") or {}
    tt, ff = m.get("ss_ps"), m.get("ff_ps")
    if he.get("enabled", True) is False or he.get("combo", True) is False:
        return False
    if tt is None or ff is None or isinstance(tt, bool) or isinstance(ff, bool):
        return False
    if not (COMBO_TT_FLOOR <= tt < SS_MIN and COMBO_FF_FLOOR <= ff < FF_MIN and m.get("drc") == 0):
        return False
    if failed or not benches_ok or m.get("errors") or e.get("installed") or j.get("eco_stack"):
        return False
    return not any((x or {}).get("kind") == "combo" for x in [*(j.get("eco_history") or []), e])


def start_combo_eco(j, fleet, m):
    """launch vtswap_eco.sh then hold_eco.sh stacked on its result as the job's ECO stage (tag hold_eco.aN, status ECO);
    the hold-ECO completion path reads {out}/result.json, installs and re-verdicts it unchanged"""
    rb, ob = eco_paths(j, m)
    if not rb:
        return False
    ok, why = fleet.fits(j["host"], 8, 16)
    if not ok:
        event(j, f"combo ECO waiting for capacity: {why}")
        return True            # stays at the verdict stage; the next tick retries
    he, v = j["spec"].get("hold_eco") or {}, j["spec"].get("verdict", {})
    e = j.get("eco") or {}
    if e:
        j.setdefault("eco_history", []).append(e)
        j["attempt"] += 1
    post = eco_post_sdcs(j, m, "combo ECO")
    pq = " ".join(shlex.quote(p) for p in post)
    n = len(j.get("eco_history") or []) + 1
    outv, out = f"{j['run']}/cl/eco-combo{n}-vt", f"{j['run']}/cl/eco-combo{n}"
    sdcn = shlex.quote(m.get("sdc_name") or "6_final.sdc")
    mac = shlex.quote(" ".join(verdict_macros(j)))
    cap = float(he.get("vtswap_cap_pct", VTSWAP_CAP_PCT))
    blk = j["spec"]["block"]
    venv = (f"TARGET=10 CAP_PCT={cap:g} DRC0=1 ACC_SS={SS_MIN:g} ACC_FF={COMBO_FF_FLOOR:g} SETUP_LIB={SETUP_LIB} SDC_NAME={sdcn} "
            f"THREADS=8 MACROS={mac} ORFS_W18=")
    if m.get("setup_post_sdc"):
        venv += f" SETUP_POST_SDC={shlex.quote(' '.join(m['setup_post_sdc']))}"
    henv = (f"ECO_SESSION=mm ALLOW_FRESH_GRT=0 HM=12 SM=40 FILT=40 PASSES=1 RESAWARE=1 HOLDCELLS=1 ACC_SS={SS_MIN:g} "
            f"ACC_FF={FF_MIN:g} SETUP_LIB={SETUP_LIB} KEEPCLK=0 BUF=30 MACROS={mac} THREADS=8 SDC_NAME={sdcn} ECO_RB_DB=6_final.odb")
    cmd = (f"{venv} bash {{CL}}/vtswap_eco.sh {rb} {ob} {outv} {blk} {pq}; "
           f"VB=$(ls -d {outv}/orfs/results/asap7/*/base | head -1); test -f $VB/6_final.odb || {{ echo COMBO: no vtswap base; exit 3; }}; "
           f"[ -f $VB/{sdcn} ] || cp {ob}/{sdcn} $VB/; "
           f"{henv} ROUTE_CFG={shlex.quote(route_cfg_of(rb))} bash {{CL}}/hold_eco.sh $VB $VB {out} {blk} {pq}")
    ship_helpers(j["host"], j["run"], j)
    tt, ff = m["ss_ps"], m["ff_ps"]
    j["eco"] = dict(tried=True, kind="combo", rb=rb, ob=ob, combo_vtswap=outv, out=out, post_sdc=post,
                    sdc_name=m.get("sdc_name") or "6_final.sdc", setup_post_sdc=list(m.get("setup_post_sdc") or []),
                    pre=dict(ss_ps=tt, ff_ps=ff), started=now_iso(), lvt_cap_pct=cap, auto=True)
    launch_token = fleet.reserve_launch(j["host"], 8, 16)
    try:
        launch_stage(j, dict(key="hold_eco", kind="hold_eco", threads=8, ram=16), cmd)
    finally:
        fleet.launch_complete(j["host"], launch_token)
    j["status"], j["stage_key"] = "ECO", "hold_eco"
    event(j, f"thin TT AND FF miss ({setup_corner_label(m)} {tt:+.2f} / FF {ff:+.2f} / DRC 0): post-route COMBO ECO "
             f"(VT-swap <= {cap:g} % LVT, then hold ECO HM 12 stacked on it, no re-route) on {rb}/6_final.odb; out {out}")
    ledger(j, f"COMBO ECO launched (loop): TT {tt:+.2f} / FF {ff:+.2f}, LVT cap {cap:g} %")
    experiment(j, "running: post-route combo (VT-swap + hold) ECO")
    return True


def eco_output(j):
    return (j.get("eco") or {}).get("out", f"{j['run']}/cl/eco")


def eco_paths(j, m):
    """(routed pre-fill base holding 5_2_route.odb, sign-off ORFS base holding 6_final.sdc)"""
    v = j["spec"].get("verdict", {})
    dm = (m.get("drc_metrics") or [None])[-1]
    rb = dm.replace("/logs/", "/results/").rsplit("/", 1)[0] if dm else None
    ob = None
    if m.get("orfs_dir"):
        r = ssh(j["host"], f"ls -d {m['orfs_dir']}/results/asap7/*/base | tail -1", timeout=60)
        ob = r.stdout.strip() or None
    return rb, ob or rb


def baked_post_sdcs(j, m, cands):
    """spec verdict post-SDCs that the route's own in-run corner STA already read as {orfs}/w18_extra.sdc (byte-equal)"""
    orfs = m.get("orfs_dir") or (m.get("raw") or {}).get("orfs_dir")
    if not cands or not orfs or not j.get("host") or not j.get("run"):
        return []
    r = ssh(j["host"], "; ".join(f"cmp -s {shlex.quote(orfs)}/w18_extra.sdc {shlex.quote(j['run'] + '/src/' + p)} && echo {shlex.quote(p)}"
                                 for p in cands) + "; true", timeout=60)
    hit = set((r.stdout or "").split())
    return [p for p in cands if p in hit]


def eco_post_sdcs(j, m, what="ECO"):
    """the post-SDC list an ECO must be timed with = the route verdict's reference.  COREKV-ECO 2026-10-08 (hold ECO): a
    route whose in-run corner STA read a spec verdict post-SDC as w18_extra.sdc (route_master Qwen-die masters: the block
    signoff SDC) records post_sdc [] -> the routed-ioref step made it [io_ref_routed.sdc] and an ECO without it is timed at
    the 770 ps route SDC with plain IO.  drive-0849 2026-10-09: the VT-swap and COMBO ECOs skipped this (EHASH -11 vs
    ECO pre -229, core18 -31 vs -94, link_rx128 -29 vs -93: false fails); every launcher now uses this one helper."""
    v = j["spec"].get("verdict", {})
    post_sdcs = list(m["post_sdc"] if "post_sdc" in m else v.get("post_sdc", []))
    baked = baked_post_sdcs(j, m, [p for p in v.get("post_sdc", []) if p not in post_sdcs])
    if not baked and not any(p for p in post_sdcs if p != IOREF_SDC):
        # a route whose in-run STA read a w18_extra.sdc that the spec does not name (route_master --extra-sdc from the
        # cfg, hgi_mtp_core18 specf2: spec post_sdc None): copy it into the job's src and pass that copy
        orfs = m.get("orfs_dir") or (m.get("raw") or {}).get("orfs_dir")
        rel = ".cl_eco/w18_extra.sdc"
        if orfs and j.get("host") and j.get("run"):
            r = ssh(j["host"], f"test -f {shlex.quote(orfs)}/w18_extra.sdc && mkdir -p {shlex.quote(j['run'])}/src/.cl_eco && "
                               f"cp {shlex.quote(orfs)}/w18_extra.sdc {shlex.quote(j['run'])}/src/{rel} && echo COPIED; true", timeout=60)
            if "COPIED" in (r.stdout or ""):
                baked = [rel]
    if baked:
        post_sdcs = baked + [p for p in post_sdcs if p != IOREF_SDC] + ([IOREF_SDC] if IOREF_SDC in post_sdcs else [])
        event(j, f"{what}: verdict post-SDC(s) {baked} were applied in-run (w18_extra.sdc): passed to the ECO")
    return post_sdcs


def hold_eco_resources(j):
    """Size from the completed route and recorded block class, with an 8 GB ECO floor.

    Small retained routes need not claim the old universal 32 GB (and 200 GB
    disk floor). Larger or unknown routes keep at least that legacy request;
    no ECO may underclaim its effective route request or a known class peak.
    """
    route = next((st for st in stage_list(j["spec"]) if st["kind"] == "route"), None)
    route_ram = route["ram"] if route else claim_ram(j["spec"])
    peak = measured_peak_gb(j["spec"])
    measured = math.ceil(max(1.25 * peak, peak + 4)) if peak else 0
    ram = math.ceil(max(8, route_ram, measured))
    return 8, max(32, ram) if ram > LIGHT_STAGE_RAM_GB else ram


def start_hold_eco(j, fleet, m):
    rb, ob = eco_paths(j, m)
    if not rb:
        return False
    threads, ram = hold_eco_resources(j)
    ok, why = fleet.fits(j["host"], threads, ram)
    if not ok:
        event(j, f"hold ECO waiting for capacity ({threads} threads / {ram} GB): {why}")
        return True            # stays at the verdict stage; the next tick retries
    v, he = j["spec"].get("verdict", {}), j["spec"].get("hold_eco") or {}
    # rev 2 (2026-10-07): post-route hold goal +18 (coordinator: die-context margin over the +15 line), endpoint filter, sign-off-exact constraints per corner,
    # resistance-aware re-route, up to 2 ECO -> re-route -> sign-off passes (hold_eco.sh header)
    env = f"ECO_SESSION={shlex.quote(he.get('session', 'mm'))} " \
          f"ALLOW_FRESH_GRT={int(he.get('allow_fresh_grt', False))} " \
          f"HM={he.get('hold_margin_ps', 18)} SM={he.get('setup_margin_ps', 40)} FILT={he.get('setup_filter_ps', 40)} " \
          f"PASSES={he.get('passes', 2)} RESAWARE={int(he.get('resistance_aware', True))} HOLDCELLS={int(he.get('hold_cells', True))} " \
          f"ACC_SS={SS_MIN} ACC_FF={FF_MIN} SETUP_LIB={SETUP_LIB} KEEPCLK={he.get('keep_clock', 0)} BUF={he.get('max_buffer_percent', 30)} " \
          f"MACROS={shlex.quote(' '.join(verdict_macros(j)))} THREADS={threads}"
    keepwires = bool(he.get("keep_wires") or j.get("auto_react_keepwires"))
    if keepwires:
        # LOOP-AUTO class a: narrow re-route -- every net the ECO did not touch keeps its detailed wires (hold_eco.sh
        # KEEPWIRES -> OT_KEEP_UNTOUCHED); same HM / SM / acceptance as the default ECO
        env += " KEEPWIRES=1"
    if he.get("repair_drv"):
        # mtp-lead 2026-10-09: opt-in DRV repair inside the ECO (hold_eco.tcl OT_REPAIR_DRV); default off
        env += f" REPAIR_DRV=1 DRV_SLEW_MARGIN={float(he.get('drv_slew_margin', 30)):g} " \
               f"DRV_CAP_MARGIN={float(he.get('drv_cap_margin', 20)):g} DRV_MAX_WIRE={float(he.get('drv_max_wire_um', 0)):g}"
    post_sdcs = eco_post_sdcs(j, m, "hold ECO")
    post = " ".join(shlex.quote(p) for p in post_sdcs)
    # LOOP-GAPS 2026-10-08: the ECO is timed (TT setup, option B) and judged with the route's OWN sign-off SDC set: its
    # sign-off SDC (corner_sta sdc_name, e.g. 6_signoff.sdc) and its setup-only post-SDCs (setup_post_sdc, e.g. the
    # measured neighbour clock nbr_clk_measured.sdc) -- not 6_final.sdc's planning neighbour clock (redesign-0315 m3f/m3g)
    env += f" SDC_NAME={shlex.quote(m.get('sdc_name') or '6_final.sdc')}"
    if m.get("setup_post_sdc"):
        env += f" SETUP_POST_SDC={shlex.quote(' '.join(m['setup_post_sdc']))}"
    if j.get("eco_stack"):
        # DRIVE-1243: stacked ECO (retry-eco --stack): the installed ECO's db lives in the route base as 6_final.*
        # (5_2_route.odb there is the PRE-ECO route): ECO that db, sign off from the same base
        rb = ob = j["eco_stack"]["base"]
        env += " ECO_RB_DB=6_final.odb"
    recovery = j.get("eco_overlay_recovery") or {}
    hist = len(j.get("eco_history") or [])
    out = recovery.get("out", f"{j['run']}/cl/eco" + (f"-r{hist + 1}" if hist else ""))   # earlier ECOs stay as evidence
    if recovery:
        env += f" ECO_GUARD={shlex.quote(recovery['guard'])}"
    cmd = f"{env} bash {{CL}}/hold_eco.sh {rb} {ob} {out} {j['spec']['block']} {post}"
    ship_helpers(j["host"], j["run"], j)
    j["eco"] = dict(tried=True, rb=rb, ob=ob, out=out, post_sdc=post_sdcs, sdc_name=m.get("sdc_name") or "6_final.sdc",
                    setup_post_sdc=list(m.get("setup_post_sdc") or []), pre=dict(ss_ps=m["ss_ps"], ff_ps=m["ff_ps"]), started=now_iso(),
                    keepwires=keepwires, resources=dict(threads=threads, ram=ram))
    st = dict(key="hold_eco", kind="hold_eco", threads=threads, ram=ram)
    launch_token = fleet.reserve_launch(j["host"], threads, ram)
    try:
        launch_stage(j, st, cmd)
    finally:
        fleet.launch_complete(j["host"], launch_token)
    j["status"], j["stage_key"] = "ECO", "hold_eco"
    event(j, f"hold-only miss ({setup_corner_label(m)} {m['ss_ps']:+.2f} / FF {m['ff_ps']:+.2f}, DRC 0): post-route hold ECO "
             f"{'(KEEPWIRES) ' if keepwires else ''}launched on {rb}/5_2_route.odb")
    experiment(j, "running: post-route hold ECO")
    return True


def eco_install_cmd(j):
    """install the ECO result in place of the route (originals kept as *.pre_eco), point the verdict's corner_sta at
    the ECO sign-off, and re-export the view (hold_eco.reexport, else hbm_fmax_attn_abstract when the route has view/)"""
    e, rb, ob, blk = j["eco"], j["eco"]["rb"], j["eco"]["ob"], j["spec"]["block"]
    cs = subst(j["spec"]["verdict"]["corner_sta"], j)
    he = j["spec"].get("hold_eco") or {}
    out = eco_output(j)
    lines = ["set -e"]
    if j.get("eco_overlay_recovery"):
        lines.append(f"python3 {{CL}}/eco_recovery.py verify {shlex.quote(j['eco_overlay_recovery']['guard'])}")
    lines.append(f"EB=$(ls -d {out}/orfs/results/asap7/*/base)")
    # ECO-DEF (ROOT 2026-10-16, qkd_static_kv_landing_seg ls5 / qkd_ctrl_pc_core s4): f181bfa99 made install copy
    # 6_final.def, but a job whose FROZEN hold_eco.tcl predates it writes no DEF -> 'cp: cannot stat 6_final.def', rc=1
    # after a PASSING ECO.  Write the DEF from the ECO's own 6_final.odb (same database, so the same geometry) first.
    lines.append(f'[ -f $EB/6_final.def ] || docker run --rm -v $EB:/eb ${{ORFS_IMAGE:-openroad/orfs:asap7lock}} bash -lc '
                 f'"printf \'read_db /eb/6_final.odb\\nwrite_def /eb/6_final.def\\n\' > /tmp/ot_wdef.tcl && '
                 f'/OpenROAD-flow-scripts/tools/install/OpenROAD/bin/openroad -no_init -exit /tmp/ot_wdef.tcl" '
                 f'> $EB/install_write_def.log 2>&1')
    for b in sorted({rb, ob}):
        for f in ("6_final.odb", "6_final.spef", "6_final.v", "6_final.def"):
            lines.append(f"[ -f {b}/{f} ] && [ ! -f {b}/{f}.pre_eco ] && mv {b}/{f} {b}/{f}.pre_eco; cp $EB/{f} {b}/{f}")
    lines.append(f"for c in {cs}; do [ -f $c.pre_eco ] || cp $c $c.pre_eco; cp {out}/corner_sta.json $c; done")
    if e.get("kind") in ("combo", "combo_hold") or e.get("combo_vtswap"):
        # drive-0849 2026-10-09: a combo db carries LVT masters, but its VT-swap stage alone never scored >= 0, so
        # vtswap_eco.sh did not add the LVT libraries to the route's w18_sta_{ss,ff}.tcl: the routed-insertion re-STA of
        # the installed db would leave the swapped cells without liberty (paths through them untimed).  Add them here.
        W0 = "/".join(rb.split("/")[:-6])
        lines.append(f"for t in {W0}/work/orfs/w18_sta_ss.tcl {W0}/work/orfs/w18_sta_ff.tcl; do [ -f $t ] || continue; "
                     f"[ -f $t.pre_vtswap ] || cp $t $t.pre_vtswap; grep -q '_LVT_' $t || "
                     "sed -i -E 's#^(read_liberty (/OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_[A-Za-z0-9]+)_RVT_(SS|FF|TT)_(.*))$#\\1\\nread_liberty \\2_LVT_\\3_\\4#; "
                     "s#^(read_lef (.*)_28_R_1x(.*))$#\\1\\nread_lef \\2_28_L_1x\\3#' $t; done")
    if isinstance(he.get("reexport"), str) and he["reexport"].strip():   # drive-0849: a spec with reexport: true (bool)
        lines.append(he["reexport"])                                      # crashed join(); non-str -> the default re-export
    else:
        W = "/".join(rb.split("/")[:-6])     # <route>/work/orfs/results/asap7/<d>/base -> <route>
        macs = " ".join(f"--macro-view {x}" for x in verdict_macros(j))
        isdc = f" --interface-sdc {ob}/6_final.sdc" if ob != rb else ""
        lines.append(f"if [ -f {W}/view/{blk}.lef ]; then mv {W}/view {W}/view.pre_eco; python3 tools/hbm_fmax_attn_abstract.py "
                     f"--orfs-dir {W}/work/orfs --name {blk} --out {W}/view {macs}{isdc} --tmp-dir {W}/abs_eco > {W}/export_eco.log 2>&1; "
                     # drive-0849: the pre-ECO view (w18 export) carried export.json, which collect recipes copy; the
                     # abstract writes abstract.json -> keep both names (mtp-seedproj a/b collect crashed twice on it)
                     f"[ -f {W}/view/export.json ] || [ ! -f {W}/view/abstract.json ] || cp {W}/view/abstract.json {W}/view/export.json; fi")
    return "\n".join(lines)


# CHILD-LINT GATE (preamble HOLD ECO KEEPOUT, 2026-10-12): a tile / leaf counts as CLOSED only with child_lint (c) strap
# layer and (f) face-pin access clean on its EXPORTED view.  blocked_pin_sweep.json: the 4 closed tiles with (f) blocked
# face pins were exactly the 4 hold-ECO'd ones (ECO DRT re-routed over the face pins after the keepout was removed,
# fixed a804fc09b); nothing checked the exported view before publish.  Applies to every job whose collected record holds
# a view LEF of its block (a hard child some parent will place); a job without one is not a tile view and passes.
# spec "hier_lint": {"skip": "f", "why": "..."} skips a check only with a written reason; {"gate": false, "why": ...} all.
CHILD_LINT_DIR = Path(__file__).resolve().parents[1] / "hier_contract"
CHILD_LINT_CHECKS = ("c", "f")


def child_lint_gate_checks(spec):
    hl = spec.get("hier_lint") or {}
    if not str(hl.get("why") or "").strip():
        return set(CHILD_LINT_CHECKS)
    if hl.get("gate") is False:
        return set()
    return set(CHILD_LINT_CHECKS) - {x.strip() for x in str(hl.get("skip") or "").split(",")}


def pick_view_lef(paths, block):
    """the block's own view among the record's LEFs (not bloat / macro copies of its children)"""
    cand = [p for p in paths if p.endswith(".lef") and "_bloat" not in p
            and not {"macros", "provenance"}.intersection(Path(p).parts) and Path(p).stem == block]
    # Collect retries retain <block>.attemptN beside the active view. Prefer the
    # canonical bundle; provenance/raw is immutable evidence, never an active view.
    return next((p for p in cand if Path(p).parent.name == block), next(iter(cand), None))


def child_lint_view(lef_text, checks, pin_grant=None, def_text=None, tech_text=None):
    """child_lint on a view LEF text: (fails restricted to checks, summary)"""
    if str(CHILD_LINT_DIR) not in sys.path:
        sys.path.insert(0, str(CHILD_LINT_DIR))
    import child_lint  # noqa: E402
    with tempfile.NamedTemporaryFile("w", suffix=".lef", delete=False) as fh:
        fh.write(lef_text)
        tmp = fh.name
    def_path, tech_path = None, None
    try:
        if def_text is not None:
            with tempfile.NamedTemporaryFile("w", suffix=".def", delete=False) as df:
                df.write(def_text)
                def_path = df.name
        if tech_text is not None:
            with tempfile.NamedTemporaryFile("w", suffix=".lef", delete=False) as tf:
                tf.write(tech_text)
                tech_path = tf.name
        res = child_lint.lint(tmp, skip=set("abcdefg") - set(checks), pin_grant=pin_grant,
                              cap="M5" if pin_grant else None, routed_def=def_path, tech_lef=tech_path)
    finally:
        os.unlink(tmp)
        if def_path:
            os.unlink(def_path)
        if tech_path:
            os.unlink(tech_path)
    return [x for x in res["fails"] if x[1:2] in checks], res.get("summary", "")


def pin_stub_fix(lef_text):
    """(text, note): tools/hier_contract/abstract_pin_stub.py applied to a view LEF text; note '' when nothing moved"""
    with tempfile.TemporaryDirectory() as td:
        a, b = Path(td) / "in.lef", Path(td) / "out.lef"
        a.write_text(lef_text)
        r = subprocess.run([sys.executable, str(CHILD_LINT_DIR / "abstract_pin_stub.py"), str(a), str(b)],
                           capture_output=True, text=True, timeout=600)
        m = re.search(r"pinstub: (\d+) OBS rects moved into (\d+) pins", r.stdout or "")
        if r.returncode != 0 or not m or not b.exists():
            return lef_text, ""
        if m.group(1) == "0":
            return lef_text, ""
        return b.read_text(), f"{m.group(1)} OBS stubs of {m.group(2)} pins"


def child_lint_gate(j):
    """None = pass / not a tile view; else the (c)/(f) failure text.  Raises on ssh failure (the commit is re-tried)."""
    checks = child_lint_gate_checks(j["spec"])
    grant = j["spec"].get("m6_pin_grant")
    if grant is not None:
        checks |= {"c", "f"}  # a pin-only grant never authorizes skipping physical evidence
    if not checks:
        return None
    blk = j["spec"]["block"]
    r = ssh(j["host"], f"find {j['run']}/record -name '*.lef' 2>/dev/null | head -200", timeout=120)
    if r.returncode != 0 and TRANSIENT_RE.search((r.stderr or "") + (r.stdout or "")):
        raise RuntimeError(f"child-lint gate: ssh failure: {(r.stderr or '')[-200:]}")
    lef = pick_view_lef(r.stdout.split(), blk)
    if not lef:
        if j["spec"].get("ref_tile"):
            return f"ref_tile job exported no view LEF {blk}.lef under {{RUN}}/record"
        return None
    t = ssh(j["host"], f"cat {shlex.quote(lef)}", timeout=300)
    if t.returncode != 0 or "MACRO" not in t.stdout:
        raise RuntimeError(f"child-lint gate: could not read {lef}: {(t.stderr or '')[-200:]}")
    text, moved = (t.stdout, "") if grant else pin_stub_fix(t.stdout)
    if moved:
        # PIN-STUB (73e17f447, ot_qkvd_sbuf DRT-0073): write_abstract_lef writes a face pin's own same-layer route stub
        # as OBS over the pin; child_lint (f) now refuses that.  Moving the stub into the pin's PORT is the exact view
        # (in a DRC-clean route, metal touching a pin on its layer is the pin's net), so fix the record's view in place.
        w = ssh(j["host"], f"cat > {shlex.quote(lef)}.pinstub && mv {shlex.quote(lef)}.pinstub {shlex.quote(lef)}",
                timeout=300, input=text)
        if w.returncode != 0:
            raise RuntimeError(f"child-lint gate: could not write the pin-stub view {lef}: {(w.stderr or '')[-200:]}")
        event(j, f"child-lint gate: abstract_pin_stub moved {moved} into their pins' PORTs in {lef}")
    def_text, tech_text = None, None
    if grant:
        # Raw routed geometry copied by ref_tile export, not a modified abstract.
        def_file = str(Path(lef).parent / "pin_only_routed.def")
        dt = ssh(j["host"], f"cat {shlex.quote(def_file)}", timeout=300)
        if dt.returncode != 0:
            return "M6 pin-only grant missing raw routed DEF evidence"
        def_text = dt.stdout
        tech_file = str(Path(lef).parent / "pin_only_tech.lef")
        tt = ssh(j["host"], f"cat {shlex.quote(tech_file)}", timeout=300)
        tech_text = tt.stdout if tt.returncode == 0 else None
    fails, summ = child_lint_view(text, checks, grant, def_text, tech_text)
    j["child_lint"] = dict(lef=lef, checks="".join(sorted(checks)), fails=fails, summary=summ[:400], at=now_iso())
    return "; ".join(fails) if fails else None


def do_commit(j):
    if adoption_held(j):
        return
    m = j["metrics"]
    if not j.get("spec", {}).get("smoke") and (j.get("spec", {}).get("m6_pin_grant") is not None
            or (j.get("child_lint") or {}).get("fails") != []):
        g = child_lint_gate(j)
        if g:
            finish(j, "NEEDS_HUMAN", f"CHILD-LINT: exported view fails {g}"[:300],
                   f"NEEDS_HUMAN: timing closed ({setup_corner_label(m)} {m.get('ss_ps')} / FF {m.get('ff_ps')} / DRC "
                   f"{m.get('drc')}) but the exported view fails child_lint -> not CLOSED (a parent cannot reach its "
                   f"pins / straps). Fix the view (ref_tile.py export) or re-route with the above-only keepout:\n{g}"[:3000])
            return
        if j.get("child_lint"):
            event(j, f"child-lint gate ({j['child_lint']['checks']}) PASS on {j['child_lint']['lef']}")
    try:
        with PUBLISH_LOCK:
            out = publish(j, m)
    except Exception as ex:  # noqa: BLE001
        finish(j, "NEEDS_HUMAN", f"publish failed: {str(ex)[:300]}", f"NEEDS_HUMAN: CLOSED but publish failed: {str(ex)[:400]}")
        return
    j["publish"] = out
    merge = out.get("merge", "")
    rbn = (j.get("rebudget") or {}).get("rb")
    detail = (f"CLOSED {setup_corner_label(m)} {m['ss_ps']:+.2f} / FF {m['ff_ps']:+.2f} ps DRC {m['drc']}" + setup_sensitivity_text(m) + (f" under IO budget {rbn} (re-derived die-link "
              f"budget, no re-route)" if rbn else "") + " | record "
              f"{j['spec']['source']['branch']} {out.get('branch_commit', '')[:9]} ({out.get('files')} files) | {merge}")
    if merge.startswith(("CONFLICT", "PUSH-RACE")):
        finish(j, "NEEDS_HUMAN", f"closed and recorded, merge failed: {merge}", detail)
    else:
        finish(j, "CLOSED", detail, detail)


# ------------------------------------------------------------------------------------------------ commands
FIXED_SIGNATURES = [
    # (fix id, stage kind, regex over the crash log tail) -- a job that died on one of these is re-queued ONCE
    ("label-sanitise-20261006", "calibrate", re.compile(r"nickname-tag|no ORFS base")),
    ("calib-json-placeholder-20261006", "collect", re.compile(r"cl/calib\.json'?: No such file")),
    ("calib-json-placeholder-20261006", "export", re.compile(r"cl/calib\.json'?: No such file")),
]


BENCH_RE = re.compile(r"^(bench_\S+) expected (FAIL|PASS) but rc=(-?\d+)")


def reevaluate_benches(jobs):
    """Fix bench-regex-multiline (2026-10-06): bench verdicts were taken on 20 log lines without re.M.  Re-judge every
    job that stopped on a bench verdict with the fixed rule; a bench that now passes resumes the job at the next stage."""
    fid = "bench-log-retry-20261007"  # was bench-regex-multiline-20261006; re-judge once more with the retried log fetch

    def eligible(j):
        m = BENCH_RE.match(j.get("reason") or "")
        return m if j["status"] in ("NEEDS_RTL", "NEEDS_HUMAN") and m and fid not in j.get("fix_requeued", []) else None
    for j in jobs:
        m = eligible(j)
        if not m:
            continue
        stl = stage_list(j["spec"])
        idx = next((i for i, x in enumerate(stl) if x["key"] == m.group(1)), None)
        if idx is None or not j.get("stage_tag", "").startswith(m.group(1) + "."):
            # STALE-SAVE 2026-10-09: this branch used to save_job(j) with no change -- a rewrite of the snapshot the
            # recovery pass took at its start (minutes to ~45 min earlier, behind slow historical log reads): it
            # reverted pi-ta15prod's hand re-entry twice.  Nothing to write.
            continue
        st = stl[idx]
        try:
            correct = bench_outcome(j, st, int(m.group(3)))
        except RuntimeError as exc:
            # An unavailable historical log must not starve later jobs or the
            # independent recovery passes. Do not consume this retry until read.
            # RETIRED-HOST 2026-10-15: a log on a host retired from hosts.json (EPYC2/3, 10-12) can never be read
            # again; it was re-deferred every tick (~3,400 log lines per job). Consume the retry once: verdict stands.
            if j.get("host") and all(h["name"] != j["host"] for h in hosts_table()):
                with job_lock(j["name"]):
                    fresh = load_job(j["name"])
                    if eligible(fresh) is not None and fresh.get("reason") == j.get("reason"):
                        fresh.setdefault("fix_requeued", []).append(fid)
                        event(fresh, f"{st['key']} not re-judged under {fid}: log on retired host {j['host']}; verdict stands")
                        save_job(fresh)
                continue
            log(f"[{j['name']}] bench re-judgment deferred: {exc}")
            continue
        with job_lock(j["name"]):
            # read-modify-write: act on the CURRENT file, and only if it is still the same bench verdict
            fresh = load_job(j["name"])
            if eligible(fresh) is None or fresh.get("reason") != j.get("reason") or fresh.get("stage_tag") != j.get("stage_tag"):
                continue
            j = fresh
            reevaluate_bench_apply(j, st, idx, m, fid, correct)


def reevaluate_bench_apply(j, st, idx, m, fid, correct):
    j.setdefault("fix_requeued", []).append(fid)
    if correct:
        j["benches"][st["key"]] = dict(expect=st["expect"], rc=int(m.group(3)), ok=True, rejudged=fid)
        j["status"], j["stage_idx"], j["reason"] = "READY", idx + 1, None
        event(j, f"{st['key']} re-judged {('PASS' if st['expect'] == 'pass' else 'FAIL as expected')} under {fid}; resumed")
        ledger(j, f"REQUEUED automatically: {st['key']} re-judged correct under loop fix {fid}")
        experiment(j, f"running: resumed after {fid}")
    else:
        event(j, f"{st['key']} re-judged under {fid}: verdict stands")
    save_job(j)


def requeue_toolchain(jobs):
    fid = "host-caps-20261006"
    for j in jobs:
        if j["status"] != "NEEDS_RTL" or fid in j.get("fix_requeued", []) or j.get("host") != "ot-agidock128":
            continue
        if not re.match(r"^bench_\S+ expected PASS but rc=2", j.get("reason") or ""):
            continue
        if not any("BUILD_FAIL" in (b.get("tail") or "") for b in j.get("benches", {}).values()):
            continue
        j.setdefault("fix_requeued", []).append(fid)
        j["hosts_tried"].append(j["host"])
        j.update(status="QUEUED", stage_idx=0, attempt=j["attempt"] + 1, retries_used=0, reason=None, errors=[],
                 benches={}, host=None, run=None)
        event(j, f"auto re-queued after loop fix {fid}: bench BUILD_FAIL on AGIdock (toolchain); placed by host caps now")
        ledger(j, f"REQUEUED automatically: loop fix {fid} (bench BUILD_FAIL rc=2 on AGIdock, toolchain mismatch)")
        save_job(j)


def requeue_ssh_verdict(jobs):
    fid = "verdict-ssh-retry-20261006"
    for j in jobs:
        if j["status"] == "NEEDS_HUMAN" and fid not in j.get("fix_requeued", []) and \
                re.search(r"verdict inputs missing.*(kex_exchange|Connection reset)", j.get("reason") or ""):
            j.setdefault("fix_requeued", []).append(fid)
            j.update(status="READY", reason=None, errors=[])
            event(j, f"auto re-queued after loop fix {fid} (transient ssh failure at the verdict)")
            ledger(j, f"REQUEUED automatically: loop fix {fid} (ssh reset while reading the verdict)")
            save_job(j)


def requeue_hold_only(jobs):
    jobs = [j for j in jobs if not j.get("eco_overlay_recovery")]  # explicit recovery is one-shot, including flow errors
    fid = "hold-eco-20261006"
    for j in jobs:   # first ECO attempts that died because the helper was not shipped to older run dirs (rc 127)
        e = j.get("eco") or {}
        if j["status"] == "NEEDS_RTL" and e.get("tried") and e.get("result") is None and "hold-eco-reroute-clock" not in j.get("fix_requeued", []):
            j.setdefault("fix_requeued", []).append("hold-eco-reroute-clock")
            # FRESH-ECO-DIR (drive-1010 2026-10-10, hardcore-1010): the dropped ECO goes to eco_history so the re-run gets
            # a fresh output dir (eco-combo<n+1> / eco-r<n+1>); clearing it reused eco-combo1 -> rc=10 (qfd_io_collective)
            j.setdefault("eco_history", []).append(dict(e, requeued="hold-eco-reroute-clock"))
            j["eco"] = {}
            stl = stage_list(j["spec"])
            j.update(status="READY", reason=None, errors=[], stage_idx=next(i for i, x in enumerate(stl) if x["kind"] == "verdict"))
            event(j, "hold ECO re-run: helpers shipped; clock wires re-routed (DRT-0206 with kept clock wires); buffer cap 30 %")
            save_job(j)
    busy = {x["spec"].get("block") for x in jobs if x["status"] not in TERMINAL} | closed_blocks(jobs)
    for j in jobs:
        m = j.get("metrics") or {}
        if j["status"] != "NEEDS_RTL" or fid in j.get("fix_requeued", []) or not hold_only(j, m, blocking_checks(j)):
            continue
        j.setdefault("fix_requeued", []).append(fid)
        if j["spec"].get("block") in busy:
            event(j, f"{fid}: hold-only, but block {j['spec']['block']} has a live or closed sibling job; not re-opened")
            save_job(j)
            continue
        stl = stage_list(j["spec"])
        j.update(status="READY", reason=None, errors=[], stage_idx=next(i for i, x in enumerate(stl) if x["kind"] == "verdict"))
        busy.add(j["spec"]["block"])
        event(j, f"auto re-opened for loop fix {fid}: hold-only miss -> post-route hold ECO")
        ledger(j, f"REQUEUED automatically: loop fix {fid} (hold-only: {setup_corner_label(m)} {m['ss_ps']:+.2f} / FF {m['ff_ps']:+.2f})")
        save_job(j)


def requeue_budget(jobs):
    """NEEDS_BUDGET under the old +-tolerance rule whose measured insertion is <= the block target: accept it now"""
    fid = "budget-measured-below-target-20261006"
    for j in jobs:
        if j["status"] != "NEEDS_BUDGET" or fid in j.get("fix_requeued", []) or not j.get("budget") or not j.get("calibration"):
            continue
        j.setdefault("fix_requeued", []).append(fid)
        if budget_check(j) is None:
            stl = stage_list(j["spec"])
            j["stage_idx"] = next(i for i, x in enumerate(stl) if x["kind"] == "calibrate") + 1
            j.update(status="READY", reason=None, errors=[])
            event(j, f"auto re-queued after loop fix {fid}: measured insertion accepted, budget SDCs regenerated")
            ledger(j, f"REQUEUED automatically: loop fix {fid} (measured {j['budget']['check']['measured_ss']:g} <= target "
                      f"{j['budget']['insertion']['target_ss']:g})")
            record_measured(j)
        save_job(j)


def auto_requeue(jobs):
    live_blocks = {(x["spec"].get("block"), str(x["spec"].get("source", {}).get("commit", ""))[:9])
                   for x in jobs if x["status"] not in TERMINAL}
    for j in jobs:
        if j["status"] != "NEEDS_HUMAN" or not j.get("crashes") or j.get("postroute_repair"):
            continue
        with job_lock(j["name"]):
            j = load_job(j["name"])  # cancellation may have won since the tick snapshot
            if j["status"] != "NEEDS_HUMAN" or not j.get("crashes") or j.get("postroute_repair"):
                continue
            c = j["crashes"][-1]
            stl = stage_list(j["spec"])
            kind = next((x["kind"] for x in stl if x["key"] == c["stage"]), None)
            for fid, k, rx in FIXED_SIGNATURES:
                if kind != k or not rx.search(c.get("tail", "") + c.get("why", "")) or fid in j.get("fix_requeued", []):
                    continue
                if (j["spec"]["block"], str(j["spec"]["source"]["commit"])[:9]) in live_blocks:
                    continue   # its owner already re-dropped it under another name
                j.setdefault("fix_requeued", []).append(fid)
                j["status"], j["retries_used"], j["attempt"], j["errors"], j["reason"] = "READY", 0, j["attempt"] + 1, [], None
                j["stage_idx"] = next(i for i, x in enumerate(stl) if x["key"] == c["stage"])
                event(j, f"auto re-queued after loop fix {fid} (died in {c['stage']} on that signature)")
                ledger(j, f"REQUEUED automatically: loop fix {fid} (failed in {c['stage']}: {c.get('why', '')[:80]})")
                experiment(j, f"running: re-queued after fix {fid}")
                live_blocks.add((j["spec"]["block"], str(j["spec"]["source"]["commit"])[:9]))
                save_job(j)
                break


def kill_own_stage(j):
    """stop ONLY this loop's own stage process group and containers mounting this job's own run dir (and its running
    parallel-bench stage, if any)"""
    for e in list((j.get("btrack") or {}).values()) + ([j["ctrack"]] if (j.get("ctrack") or {}).get("tag") else []):
        if e.get("state") == "running":
            ssh(e["host"], f"p=$(cat {e['run']}/cl/{e['tag']}.pid 2>/dev/null); [ -n \"$p\" ] && kill -TERM -- -$p 2>/dev/null; true",
                timeout=60)
            e["state"] = "killed"
    if not (j.get("stage_tag") and j.get("host")):
        return
    run, t = j["run"], j["stage_tag"]
    ssh(j["host"], f"""p=$(cat {run}/cl/{t}.pid 2>/dev/null); [ -n "$p" ] && kill -TERM -- -$p 2>/dev/null
for c in $(docker ps -q); do {DIE_CONTAINER_SKIP}docker inspect --format '{{{{range .Mounts}}}}{{{{.Source}}}} {{{{end}}}}' $c | grep -q '{run}/' && docker stop -t 5 $c; done; true""",
        timeout=300)


def migrate_checkpoint(j, dest):
    """move a RUNNING route WITH its ORFS checkpoint (coordinator 2026-10-06): stop this job's own stage, stream the
    whole run dir (src snapshot + work/orfs results/logs/objects) to the same path on dest (tar keeps mtimes), patch
    the snapshot's run_abi3_physical.py for resume (resume_patch.py), dry-run make to see which stages re-run, and
    relaunch the route stage there with OT_CL_RESUME=1: ORFS reuses every completed stage, only the in-flight one is lost."""
    require_checkpoint_location(j)
    src = j["host"]
    if src == dest or (is_local(src) and is_local(dest)):
        raise ValueError("checkpoint migration requires a different host")
    if os.path.dirname(j["run"].rstrip("/")) not in host_bases(host_cfg(dest)):
        raise ValueError(f"checkpoint move needs the same run root ({j['run']} vs {host_bases(host_cfg(dest))} on {dest})")
    run = j["run"]
    j["status"] = "MIGRATING"
    save_job(j)
    event(j, f"checkpoint move {host_cfg(src)['label']} -> {host_cfg(dest)['label']}: stopping own stage")
    kill_own_stage(j)
    for _ in range(30):
        r = ssh(src, f"for c in $(docker ps -q); do docker inspect --format '{{{{range .Mounts}}}}{{{{.Source}}}} {{{{end}}}}' $c "
                     f"| grep -q '{run}/' && echo BUSY; done; pgrep -f '{run}/cl/run.sh' >/dev/null && echo BUSY; true", timeout=120)
        if "BUSY" not in r.stdout:
            break
        time.sleep(10)
    t0 = time.time()
    ssh(dest, f"mkdir -p {run}", timeout=60, check=True)
    with ExitStack() as stack:
        # Stable order avoids opposite-direction migrations deadlocking channel leases.
        commands = {h: stack.enter_context(transport_command(h, bulk=True)) for h in sorted({src, dest})}
        read = shlex.join(commands[src] + [f"tar -C {shlex.quote(run)} -cf - ."])
        write = shlex.join(commands[dest] + [f"tar -C {shlex.quote(run)} -xf -"])
        p = subprocess.run(["bash", "-o", "pipefail", "-c", f"{read} | {write}"],
                           capture_output=True, text=True, timeout=7200)
    if p.returncode:
        raise RuntimeError(f"checkpoint transfer failed: {p.stderr[-500:]}")
    ship_helpers(dest, run, j)
    r = ssh(dest, f"cd {run}/src && python3 {run}/cl/resume_patch.py .", timeout=120)
    if r.returncode:
        raise RuntimeError(f"resume patch failed: {(r.stdout + r.stderr)[-400:]}")
    dm = subst(j["spec"].get("verdict", {}).get("drc_metrics", ""), j)
    orfs = dm.split("/logs/")[0] if "/logs/" in dm else None
    if not orfs:
        raise RuntimeError("checkpoint transfer cannot be verified: missing ORFS checkpoint path")
    check = ssh(dest, f"bash {run}/cl/resume_check.sh {orfs} {run}/src", timeout=600)
    chk = check.stdout
    if check.returncode or not re.search(r"^RESUME_OK=1$", chk, re.M):
        raise RuntimeError(f"checkpoint transfer resume check failed rc={check.returncode}: {chk[-400:]}")
    j["resume"] = dict(from_host=src, to_host=dest, run=run, at=now_iso(),
                       transfer_s=round(time.time() - t0), check=chk.strip()[-400:],
                       checkpoint_transfer_verified=True)
    j["checkpoint_affinity"] = dict(host=dest, run=run)
    j["hosts_tried"].append(dest)
    j.update(host=dest, status="READY", attempt=j["attempt"] + 1, wait=None)
    event(j, f"checkpoint moved in {j['resume']['transfer_s']} s; make dry-run: {' '.join(chk.split())[-200:]}")
    experiment(j, f"running: route resumed on {host_cfg(dest)['label']} from checkpoint")
    save_job(j)


def migrate_overloaded(jobs, fleet):
    """LOAD REBALANCE 2: a host above its cap (or a spillover-only host short of its RAM reserve) sheds this loop's
    jobs that have not passed CTS (bench / calibrate running or waiting, route not yet launched) to a host that fits."""
    for j in jobs:
        if j["status"] in TERMINAL or not j.get("host") or checkpoint_location(j):
            continue
        cfg = host_cfg(j["host"])
        info = fleet.probe(j["host"])
        if info is None:
            continue
        over = info["load1"] > cfg["cap"] or (cfg.get("spillover_only") and info["mem_gb"] < cfg.get("reserve_ram_gb", 0))
        if not over:
            continue
        stl = stage_list(j["spec"])
        st = stl[min(j.get("stage_idx", 0), len(stl) - 1)]
        pre_cts = (j["status"] in ("RUNNING", "READY") and st["kind"] in ("bench", "calibrate")) or \
                  (j["status"] == "READY" and st["kind"] == "route") or j["status"] == "SYNC"
        if not pre_cts and j["status"] == "RUNNING" and st["kind"] == "route":
            # OWNER LOAD REBALANCE 2: a route on an overloaded host that has not reached CTS may be relaunched elsewhere
            dm = subst(j["spec"].get("verdict", {}).get("drc_metrics", ""), j)
            if dm:
                rb = dm.replace("/logs/", "/results/").rsplit("/", 1)[0]
                r = ssh(j["host"], f"ls {rb}/4_1_cts.odb {rb}/3_place.odb >/dev/null 2>&1 && echo CTS; "
                                   f"ls -d {rb.rsplit('/', 2)[0]} >/dev/null 2>&1 || echo NOBASE; "
                                   f"ls {rb}/4_1_cts.odb >/dev/null 2>&1 || echo PRECTS", timeout=60)
                pre_cts = r.returncode == 0 and "PRECTS" in r.stdout
        if not pre_cts or at_post_route(j, stl):      # LOST-CLOSED (ROOT-1130): never move a closed route's job
            continue
        h, why = fleet.choose(j["spec"], exclude=[j["host"]])
        if not h or host_cfg(h).get("spillover_only"):
            continue
        old = cfg["label"]
        if j["status"] == "RUNNING":
            kill_own_stage(j)
        cal = next((i for i, x in enumerate(stl) if x["kind"] == "calibrate"), None)
        if st["kind"] in ("bench", "route"):
            idx = j["stage_idx"]                         # re-run the interrupted bench / pre-CTS route
            if st["kind"] == "route" and cal is not None:
                idx = cal                                # calibration is host-local (calib.env): redo it
        else:
            idx = cal if cal is not None else j["stage_idx"]
        j["hosts_tried"].append(h)
        j.update(host=h, run=f"{run_base(h)}/{j['name']}", status="SYNC", stage_idx=idx, wait=None,
                 attempt=j["attempt"] + 1)
        j.pop("wait_since", None)
        fleet.launched(h, j["spec"].get("threads", 16), claim_ram(j["spec"]), j["name"])  # 2026-10-08
        event(j, f"LOAD REBALANCE: {old} over cap (load {info['load1']:.0f}, {info['mem_gb']} GB free); pre-CTS job "
                 f"moved to {host_cfg(h)['label']} (resumes at {stl[idx]['key']})")
        experiment(j, f"running: moved {old} -> {host_cfg(h)['label']}")
        save_job(j)


TRANSIENT_RE = re.compile(r"kex_exchange|Connection (reset|refused|closed|timed out)|ssh: |Broken pipe|"
                          r"No route to host|command failed rc=255|Could not resolve hostname")
TRANSIENT_BACKOFF_S = (120, 240, 480, 900, 1800)


def is_transient(ex):
    """an ssh / network failure (timeout of an ssh call, rc 255, connection errors), not a loop or job error"""
    if isinstance(ex, subprocess.TimeoutExpired):
        return isinstance(ex.cmd, list) and bool(ex.cmd) and ex.cmd[0] in ("ssh", "rsync")
    return bool(TRANSIENT_RE.search(str(ex)))


def handle_transient(j, fleet, ex):
    """robustness (2026-10-07): transient ssh errors back off (2, 4, 8, 15, 30 min); after 3 at a stage that has
    nothing in flight on the host (QUEUED / SYNC / READY before the first launch, or READY at calibrate/route/bench) the job
    moves to another host; a job whose results live on the host (verdict, ECO) keeps backing off and goes NEEDS_HUMAN
    only after 12 consecutive failures (~5 h).  Returns True when handled."""
    n = j.get("transient", 0) + 1
    j["transient"] = n
    j["transient_next"] = time.time() + TRANSIENT_BACKOFF_S[min(n - 1, len(TRANSIENT_BACKOFF_S) - 1)]
    event(j, f"transient ssh/network error #{n} on {j.get('host')} ({type(ex).__name__}: {str(ex)[:160]}); backing off")
    stl = stage_list(j["spec"])
    st = stl[min(j.get("stage_idx", 0), len(stl) - 1)]
    # 2026-10-11: READY at calibrate/route is movable as in launch_ready's capacity move (READY = this stage has not
    # launched; stage_tag is the previous stage's and is never cleared, and the move re-runs calibrate) -- on an
    # overloaded host (load 500+) the loop's own ssh calls time out, and such a job otherwise backed off there for ever
    movable = j["status"] in ("QUEUED", "SYNC") or (j["status"] == "READY" and (
        st["kind"] in ("calibrate", "route") or (st["kind"] == "bench" and not j.get("stage_tag"))))
    if n >= 3 and movable and j.get("host") and not checkpoint_location(j):
        if move_to_other_host(j, fleet, j["spec"], stl, f"{n} transient errors on {host_cfg(j['host'])['label']}"):
            j["transient"] = 0
            j.pop("transient_next", None)
            return True
    if n >= 12:
        return False                     # falls through to the ordinary error accounting
    return True


def advance_job(name, fleet):
    with job_lock(name):
        j = load_job(name)
        if j["status"] in TERMINAL or j.get("admission_hold"):
            return
        nt = j.get("transient_next")
        if nt and time.time() < nt:
            return                       # backing off after a transient ssh / network error
        try:
            before = j["status"]
            step(j, fleet)
            # el1013-fleet4 2026-10-13: a job whose source sync just finished launches its first stage in the same pass.
            # It used to return at READY and wait for the next tick to be submitted again: 45-100 s on idle hosts
            # (median ingest -> first launch 157 s over 21 jobs, 04:16-05:30).
            if before in ("QUEUED", "SYNC") and j["status"] == "READY":
                save_job(j)
                step(j, fleet)
            if j.get("transient"):
                j["transient"] = 0
                j.pop("transient_next", None)
        except Exception as ex:  # noqa: BLE001
            if is_transient(ex) and handle_transient(j, fleet, ex):
                save_job(j)
                return
            j.setdefault("errors", []).append(f"{now_iso()} {type(ex).__name__}: {str(ex)[:500]}")
            j["errors"] = j["errors"][-10:]
            log(f"[{j['name']}] step error:\n{traceback.format_exc()}")
            if len(j["errors"]) >= 10 and j["status"] in ("SYNC", "READY", "ECO_RESULT"):
                finish(j, "NEEDS_HUMAN", f"10 consecutive loop errors: {str(ex)[:200]}",
                       f"NEEDS_HUMAN: loop errors at {j['status']}: {str(ex)[:300]}")
        save_job(j)


BULK_RELEASE_PER_TICK = 4
# NEAR-MISS RETENTION (merge-eco 2026-10-09): eco-sweep found the routed databases of near-miss elements gone
# (smh_tile_w, su12_full, qfd_hub, frame_station, router: review_queue/eco-sweep.md ES-1..8), so nothing was left to
# ECO or re-STA.  A non-closed route with TT >= NEAR_MISS_PS and FF >= NEAR_MISS_PS keeps its whole route tree
# (6_final odb/spef/sdc/v, ORFS objects the re-STA reads, src snapshot) until its element (spec block) has a CLOSED job.
# Enforced in three places: release_bulk() skips it, BULK_RELEASE_SH itself refuses a run whose corner_sta*.json is a
# near miss unless the caller sets NEAR_MISS_RELEASE=1 (manual reuse of the script keeps them), and the hourly fleet
# sweeper keeps any unit holding a near-miss route (tools/fleet/sweep.py) and every run dir in near_miss_retain.json.
NEAR_MISS_PS = -100.0
NEAR_MISS_JSON = STATE / "near_miss_retain.json"
# Route bulk released on terminal jobs (fleet disk guard 2026-10-07): intermediate ODB/DEF/SPEF/guides/netlists and
# ORFS objects under the job's ORFS work trees.  Kept: 6_final.*, 5_2_route.odb, every log / report / json (metrics).
BULK_RELEASE_SH = r"""set -u
R=%(run)s
if [ -e "$R/.keep" ]; then echo "RETAIN owner diagnostic .keep"; exit 4; fi
if [ "${NEAR_MISS_RELEASE:-0}" != 1 ] && python3 - "$R" <<'NMPY'
import json, os, sys
r = sys.argv[1].rstrip("/")
for dp, dn, fn in os.walk(r):
    rel = dp[len(r):]
    dn[:] = [] if rel.count("/") >= 8 else [d for d in dn if not (rel == "" and d == "src") and d not in ("objects", ".git")]
    for f in fn:
        if not (f.startswith("corner_sta") and f.endswith(".json")):
            continue
        try:
            d = json.load(open(os.path.join(dp, f)))
            su = d.get("setup_tt") or d.get("setup_ss") or {}
            tt, ff = su.get("worst_slack_ps"), (d.get("hold_ff") or {}).get("worst_slack_ps")
        except Exception:
            continue
        num = lambda v: isinstance(v, (int, float)) and not isinstance(v, bool)
        if num(tt) and num(ff) and tt >= -100 and ff >= -100 and not (tt >= 0 and ff >= 0):
            print("NEAR_MISS", os.path.join(dp, f), tt, ff)
            sys.exit(0)
sys.exit(1)
NMPY
then echo "RETAIN near-miss route (TT/FF >= -100 ps, not closed); set NEAR_MISS_RELEASE=1 once the element closes"; exit 4; fi
for p in "$R"/cl/*.pid; do [ -f "$p" ] && [ ! -f "${p%%.pid}.rc" ] && kill -0 "$(cat "$p")" 2>/dev/null && { echo LIVE "$p"; exit 3; }; done
for c in $(docker ps -q 2>/dev/null); do docker inspect --format '{{range .Mounts}}{{.Source}} {{end}}' $c | grep -q "$R/" && { echo LIVE docker; exit 3; }; done
before=$(du -sm "$R" 2>/dev/null | cut -f1)
find "$R" -path '*/orfs/*' ! -path "$R/src/*" -type d -name objects -prune -exec rm -rf {} + 2>/dev/null
find "$R" -path '*/orfs/*' ! -path "$R/src/*" -type f \( -name '*.odb' -o -name '*.def' -o -name '*.spef' -o -name '*.guide' -o -name '*.v' -o -name '*.odb.gz' -o -name '*.def.gz' \) \
     ! -name '6_final.*' ! -name '5_2_route.odb' -delete 2>/dev/null
echo FREED $before $(du -sm "$R" 2>/dev/null | cut -f1)
"""



REVOKED_JSON = Path(os.environ.get("CL_REVOKED", str(Path.home() / "claude-takeover-20261007/revoked_closures.json")))
OPTB_STATUS_GLOB = "results/closure_loop/option_b_status_*/status.json"
OPTB_DECISION = "2026-10-07T20:45"   # owner option B: setup judged at TT; SS-era closures of revoked blocks lapse


def _closed_at(j):
    ev = [e for e in j.get("events") or [] if " CLOSED" in e[:40] or "CLOSED:" in e[:40]]
    return (ev[-1] if ev else (j.get("updated") or ""))[:16]


def revoked_closures():
    """(revoked job names, option-B revoked blocks): the two sources of closures that no longer count."""
    names, blocks = set(), set()
    try:
        names |= set(json.loads(REVOKED_JSON.read_text()))
    except Exception:  # noqa: BLE001
        pass
    for p in sorted(REPO.glob(OPTB_STATUS_GLOB))[-1:]:
        try:
            d = json.loads(p.read_text()).get("revoked_previously_closed") or {}
            blocks |= {b["block"] for b in d.get("blocks", [])}
            names |= {b["job"] for b in d.get("blocks", []) if b.get("job")}
        except Exception:  # noqa: BLE001
            pass
    return names, blocks


def closure_counts(j, revoked=None):
    """A CLOSED job counts as its block's closure unless revoked (2026-10-08: dsfd_svcio_q's re-routes were bulk-released
    against a revoked closure). An option-B-revoked block's closure counts only if judged at TT (tt_ps, or closed after
    the option-B decision)."""
    if j.get("status") != "CLOSED":
        return False
    names, blocks = revoked if revoked is not None else revoked_closures()
    if j["name"] in names:
        return False
    if j["spec"].get("block") in blocks:
        return "tt_ps" in (j.get("metrics") or {}) or _closed_at(j) >= OPTB_DECISION
    return True


def closed_blocks(jobs):
    rv = revoked_closures()
    return {x["spec"].get("block") for x in jobs if closure_counts(x, rv)}


def release_source_index(jobs):
    """Counting closures indexed by immutable revision, not just a reused block name."""
    rv = revoked_closures()
    out = {}
    for x in jobs:
        if closure_counts(x, rv):
            commit = x.get("commit_full") or (x.get("spec", {}).get("source") or {}).get("commit") or ""
            out.setdefault(x["spec"].get("block"), set()).add(commit)
    return out


def source_mismatch_retained(j, index):
    """An older/different-source closure cannot retire an unclosed candidate's diagnostics.

    Missing or abbreviated closure revisions cannot prove equivalence. Exact source
    identity is conservative; an owner can retire/archive unique diagnostics explicitly.
    """
    if j.get("status") == "CLOSED":
        return False
    versions = index.get(j.get("spec", {}).get("block"))
    if versions is None:
        return False
    commit = j.get("commit_full") or (j.get("spec", {}).get("source") or {}).get("commit") or ""
    return not (re.fullmatch(r"[0-9a-f]{40}", commit) and commit in versions)


def helper_provenance_retained(j):
    """Keep evidence blocked by helper verification; this confers no timing acceptance.

    Only the current failure/last pending error counts. A later explicit design
    verdict or owner cancellation does not inherit an old provenance failure.
    """
    if j.get("status") in ("CLOSED", "CANCELLED", "NEEDS_RTL", *EARLY_FAIL):
        return False
    reason = j.get("reason") or ""
    pending = j.get("status") not in TERMINAL
    text = ((j.get("errors") or [""])[-1] or reason) if pending else reason
    return any(tag in text for tag in (
        "FROZEN_HELPER_OVERLAY", "effective route helper drift", "helper overlay drift",
        "frozen helper", "frozen-helper", "FROZEN_HELPER_RECOVERY", "original remote helper verification"))


def near_miss(j, closed=None):
    """a non-CLOSED job whose route verdict is TT >= NEAR_MISS_PS and FF >= NEAR_MISS_PS (and not both >= the line),
    while its element (spec block) has no counting CLOSED job: its route tree is retained"""
    if j.get("status") == "CLOSED":
        return False
    m = j.get("metrics") or {}
    tt, ff = m.get("ss_ps"), m.get("ff_ps")
    if not all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in (tt, ff)):
        return False
    if not (tt >= NEAR_MISS_PS and ff >= NEAR_MISS_PS) or (tt >= SS_MIN and ff >= FF_MIN):
        return False
    return closed is None or j["spec"].get("block") not in closed


def write_near_miss_retain(jobs, closed=None):
    """STATE/near_miss_retain.json: run dirs (+ ORFS dir) of retained near-miss routes, read by tools/fleet/fleet_sweep.py"""
    closed = closed_blocks(jobs) if closed is None else closed
    rows = []
    sources = release_source_index(jobs)
    for x in jobs:
        mismatch = source_mismatch_retained(x, sources)
        if x.get("run") and x.get("host") and (near_miss(x, closed) or mismatch or helper_provenance_retained(x)):
            m = x.get("metrics") or {}
            rows.append(dict(job=x["name"], block=x["spec"].get("block"), host=x["host"], run=x["run"],
                             orfs_dir=m.get("orfs_dir"), tt_ps=m.get("ss_ps"), ff_ps=m.get("ff_ps"), drc=m.get("drc"),
                             status=x["status"], reason="helper provenance blocked" if helper_provenance_retained(x) else "source-mismatched closure" if mismatch else "near miss"))
    body = dict(schema="opentallas.closure_loop.near_miss_retain.v1", generated=now_iso(), threshold_ps=NEAR_MISS_PS,
                rule="retain helper-blocked evidence, near misses, and unclosed source revisions not covered by a source-identical closure",
                jobs=sorted(rows, key=lambda r: r["job"]))
    try:
        tmp = NEAR_MISS_JSON.with_suffix(".tmp")
        tmp.write_text(json.dumps(body, indent=1) + "\n")
        tmp.replace(NEAR_MISS_JSON)
    except OSError as ex:
        log(f"near_miss_retain.json not written: {ex}")
    return rows


# Preserve the live daemon's BF protection in pinned source; the owner extended
# the deadline to 21:30 PT on October 10. No progressing job is restarted.
BF_EXEMPT_UNTIL = "2026-10-10T21:30:00-07:00"


def bf_exempt(j, now=None):
    name = j.get("name") or (j.get("spec") or {}).get("name") or ""
    if not name.startswith("bf") and (j.get("spec") or {}).get("block") != "ot_s81_bf_native":
        return False
    current = now if now is not None else dt.datetime.now(dt.timezone.utc)
    return current < dt.datetime.fromisoformat(BF_EXEMPT_UNTIL)


def release_bulk(jobs):
    """CANCELLED jobs, and terminal jobs superseded by a CLOSED job of the same block, give back their route bulk --
    except a near miss (near_miss()) whose block has not closed: it keeps its route tree (NEAR-MISS RETENTION)."""
    closed = closed_blocks(jobs)
    sources = release_source_index(jobs)
    write_near_miss_retain(jobs, closed)
    n = 0
    for x in jobs:
        if n >= BULK_RELEASE_PER_TICK:
            break
        if x.get("bulk_released") or not x.get("host") or not x.get("run") or x["status"] not in TERMINAL:
            continue
        if bf_exempt(x) or source_mismatch_retained(x, sources) or helper_provenance_retained(x):
            continue
        if x["status"] == "CLOSED" or not (x["status"] == "CANCELLED" or x["spec"].get("block") in closed):
            continue
        if near_miss(x, closed) or (x.get("near_miss_retained") and x["spec"].get("block") not in closed):
            continue
        if x["host"] not in {h["name"] for h in hosts_table()}:
            continue
        with job_lock(x["name"]):
            j = load_job(x["name"])
            if j.get("bulk_released") or j["status"] not in TERMINAL or j["status"] == "CLOSED" or source_mismatch_retained(j, sources) or helper_provenance_retained(j):
                continue
            # the block is closed (or the job has no near-miss verdict): a near-miss corner_sta may be released
            rel = "NEAR_MISS_RELEASE=1\n" if j["spec"].get("block") in closed else ""
            r = ssh(j["host"], rel + BULK_RELEASE_SH % dict(run=shlex.quote(j["run"])), timeout=900)
            n += 1
            if r.returncode == 4:
                if not j.get("near_miss_retained"):
                    j["near_miss_retained"] = now_iso()
                    event(j, f"bulk release refused: near-miss route retained ({r.stdout.strip()[-200:]})")
                    save_job(j)
                continue
            if r.returncode == 3:
                event(j, f"bulk release skipped: live process ({r.stdout.strip()[:120]})")
                continue
            if r.returncode != 0 and "FREED" not in r.stdout:
                continue   # host unreachable: retried next tick
            why = "cancelled" if j["status"] == "CANCELLED" else "superseded by a CLOSED job of block " + str(j["spec"].get("block"))
            j["bulk_released"] = dict(at=now_iso(), why=why, du_mb=r.stdout.strip().split("FREED", 1)[-1].strip())
            event(j, f"route bulk released ({why}; MB before/after {j['bulk_released']['du_mb']}); kept 6_final.*, 5_2_route.odb, logs/reports/json")
            save_job(j)


# DEEP RELEASE (disk-1210 2026-10-09): EPYC1 sat at 183 GB free with a 1.6 TB closure-loop tree although every terminal
# job had been bulk-released: BULK_RELEASE_SH keeps 5_2_route.odb, every eco pass's 6_final.*, the src snapshot (~1.3 GB
# per job) and bench builds (Verilator .gch/obj ~1 GB per bench), and it never touched CLOSED jobs or plain failures.
# Owner rule: CLOSED + recorded on main keeps 6_final.{odb,def,v,sdc,spef} of the accepted ORFS dir (metrics.orfs_dir)
# and of the route tree plus logs/reports; a terminal failure older than DEEP_RELEASE_AGE_H loses the ORFS 1_-5_
# intermediates, objects/, the src snapshot and bench builds, keeping 6_final.* and logs/reports; a near miss on an
# open element (near_miss()) keeps 5_2_route.odb, 6_final.*, objects/ and src (re-STA / ECO inputs) and loses only the
# 1_-4_/fill/gds intermediates and bench builds.  Every path a committed receipt on origin/main names is kept whole
# (files, source trees) or keeps its 6_final.* (generic ORFS dirs).  A src snapshot goes only when its SOURCE_COMMIT is
# the job's commit and that commit is in REPO (re-creatable by git archive).
DEEP_RELEASE_AGE_H = 6.0
DEEP_RELEASE_PER_TICK = 4
DEEP_RELEASE_FAIL = {"NEEDS_RTL", "NEEDS_HUMAN", "FLOORPLAN_MARGIN", "PREROUTE_MARGIN", "CANCELLED", "REFUSED", "INVALID",
                     *EARLY_FAIL}
DEEP_RELEASE_REFS_TTL_S = 3600
_DEEP_CACHE = {}
DEEP_RELEASE_PY = r'''
import json, os, shutil, stat, sys
a = json.loads(os.environ["OT_DR"])
R, mode = a["run"].rstrip("/"), a["mode"]
FINAL = {"6_final.odb", "6_final.def", "6_final.v", "6_final.sdc", "6_final.spef"}
BULK = (".odb", ".def", ".spef", ".v", ".gds", ".guide", ".odb.gz", ".def.gz", ".gds.gz", ".pre_eco")
GENERIC = {"orfs", "work", "base", "routes", "cl", "eco", "eco-r2", "eco-r3", "pass1", "pass2", "pass3", "route",
           "results", "logs", "reports", "asap7"}
KEEP_TEXT = (".log", ".json", ".txt", ".rpt", ".rc", ".pid", ".sdc", ".tcl", ".sh", ".env", ".csv", ".md", ".yaml",
             ".yml", ".sv", ".v", ".svh", ".vh", ".f")
if not os.path.isdir(R):
    print("DEEP_FREED 0 (no run dir)"); sys.exit(0)
for p in os.listdir("/proc"):
    if not p.isdigit():
        continue
    try:
        cwd = os.readlink("/proc/%s/cwd" % p)
        argv = open("/proc/%s/cmdline" % p, "rb").read().decode(errors="replace")
    except OSError:
        continue
    if cwd == R or cwd.startswith(R + "/") or (R + "/") in argv or argv.endswith(R) or (R + "\0") in argv:
        print("LIVE pid", p); sys.exit(3)
refs = [r.rstrip("/") for r in a.get("refs") or []]
hard = [r for r in refs if os.path.basename(r) not in GENERIC and r != R]
# token-exact 2026-10-09: a .keep marker protects its directory (exactness fixtures) like a hard reference
hard += [dp.rstrip("/") for dp, dn, fn in os.walk(R) if ".keep" in fn and dp.rstrip("/") != R]
if os.path.exists(os.path.join(R, ".keep")):
    print("DEEP_FREED 0 (.keep)"); sys.exit(0)
soft = [r for r in refs if r not in hard and r != R]
finals = [x.rstrip("/") for x in a.get("final_dirs") or []]
prot = lambda p: any(p == r or p.startswith(r + "/") for r in hard)
anc = lambda p: any(r.startswith(p + "/") for r in hard)
APPLY = not a.get("dry")
freed = 0
def blocks(p):
    try:
        st = os.lstat(p)
        return st.st_blocks * 512 if stat.S_ISREG(st.st_mode) else 0
    except OSError:
        return 0
def rm_tree(p):
    b = sum(blocks(os.path.join(dp, f)) for dp, dn, fn in os.walk(p) for f in fn)
    if APPLY:
        shutil.rmtree(p, ignore_errors=True)
    return b
def rm_file(p):
    b = blocks(p)
    if APPLY:
        try:
            os.unlink(p)
        except OSError:
            return 0
    return b
src_ok = False
try:
    src_ok = bool(a.get("src_commit")) and open(os.path.join(R, "src", "SOURCE_COMMIT")).read().strip() == a["src_commit"]
except OSError:
    pass
def snap_commit(tp):
    try:
        return open(os.path.join(tp, "SOURCE_COMMIT")).read().strip()
    except OSError:
        return ""
def trim_snapshot(tp):
    # disk-1015: a git snapshot (src/, bench_src_a*/) at the job's commit is re-created by git archive; a receipt that
    # names a file or sub-directory inside it keeps THAT path, not the whole 4-5 GB tree (the old whole-tree keep left
    # ~590 GB of snapshots on AGIdock); a receipt naming the snapshot root itself is satisfied by SOURCE_COMMIT
    keep = [r for r in hard if r.startswith(tp + "/")]
    kdirs = [r for r in keep if os.path.isdir(r) and not os.path.islink(r)]
    kfiles = set(keep) | {os.path.join(tp, "SOURCE_COMMIT")}
    b = 0
    for dp, dn, fn in os.walk(tp):
        if any(dp == k or dp.startswith(k + "/") for k in kdirs):
            dn[:] = []
            continue
        for f in fn:
            p = os.path.join(dp, f)
            if p not in kfiles:
                b += rm_file(p)
    if APPLY:
        for dp, dn, fn in os.walk(tp, topdown=False):
            if dp != tp:
                try:
                    os.rmdir(dp)
                except OSError:
                    pass
        with open(os.path.join(tp, "TRIMMED_SOURCE_SNAPSHOT"), "w") as f:
            f.write("source snapshot trimmed by deep release; git archive %s re-creates it; receipt paths kept\n" % a["src_commit"])
    return b
if mode == "src" and a.get("keep_config_paths"):
    # GRT183 2026-10-15 (ROOT): a NEEDS_HUMAN route is diagnosed by re-running its saved ORFS state, which reads the
    # /src files its config.mk names (macro LEF/Liberty/GDS, kit SDC/TCL): qfd_tt_scale_leaf-tg1's replay died on a
    # trimmed ot_sram_1r1w_128x256_m1_r2c2_tt.lib.  Keep every config-named /src path; for a path >= 3 levels deep
    # (physical/asap7_memory_macros/<macro>/..., physical/ref_tile/<kit>/...) keep its whole directory (all corners).
    import re as _re
    for dp, dn, fn in os.walk(R):
        if dp == R + "/src" or dp.startswith(R + "/src/") or "/bench_src" in dp:
            dn[:] = []
            continue
        if "config.mk" not in fn:
            continue
        try:
            txt = open(os.path.join(dp, "config.mk"), errors="replace").read()
        except OSError:
            continue
        for rel in set(_re.findall(r"/src/([A-Za-z0-9_./+-]+)", txt)):
            rel = os.path.normpath(rel)
            if rel.startswith(".."):
                continue
            p = os.path.join(R, "src", rel)
            d = os.path.dirname(rel)
            if d.count("/") >= 2 and os.path.isdir(os.path.join(R, "src", d)):
                p = os.path.join(R, "src", d)
            if os.path.exists(p):
                hard.append(p)
if mode == "src":
    # SRC-RELEASE (ROOT 2026-10-15): only the git snapshots (src/, bench_src*/) at the job's own commit, trimmed to the
    # receipt-named paths; nothing else in the run dir is touched
    for top in sorted(os.listdir(R)):
        tp = os.path.join(R, top)
        if (top == "src" or top.startswith("bench_src")) and os.path.isdir(tp) and not os.path.islink(tp) \
                and a.get("src_commit") and snap_commit(tp) == a["src_commit"] \
                and not os.path.exists(os.path.join(tp, ".keep")) \
                and not os.path.exists(os.path.join(tp, "TRIMMED_SOURCE_SNAPSHOT")):
            freed += trim_snapshot(tp)
    print("DEEP_FREED %d" % (freed // 2 ** 20))
    sys.exit(0)
for top in sorted(os.listdir(R)):
    tp = os.path.join(R, top)
    if not os.path.isdir(tp) or os.path.islink(tp):
        continue
    snap = top == "src" or top.startswith("bench_src")
    if prot(tp) or anc(tp):
        if snap and mode in ("closed", "fail") and a.get("src_commit") and snap_commit(tp) == a["src_commit"] \
                and not os.path.exists(os.path.join(tp, ".keep")):
            freed += trim_snapshot(tp)
        continue
    if top == "src" and mode in ("closed", "fail") and src_ok:
        freed += rm_tree(tp)
    elif top.startswith("bench_src"):
        freed += rm_tree(tp)
for dp, dn, fn in os.walk(R):
    if prot(dp) or dp == R + "/src" or dp.startswith(R + "/src/"):
        dn[:] = []
        continue
    if "/orfs" in dp and mode != "nearmiss":
        for x in [x for x in dn if x == "objects"]:
            p = os.path.join(dp, x)
            if not prot(p) and not anc(p):
                freed += rm_tree(p)
                dn.remove(x)
    verilator = any(f.startswith("V") and f.endswith(".mk") for f in fn)
    for f in fn:
        p = os.path.join(dp, f)
        if prot(p) or os.path.islink(p):
            continue
        if verilator:
            if not f.endswith(KEEP_TEXT):
                freed += rm_file(p)
            continue
        if f.endswith((".gch", ".o", ".a", ".so")) and "/orfs" not in dp:
            freed += rm_file(p)
            continue
        if "/orfs" not in dp or not (f.endswith(BULK) or ".odb." in f):
            continue
        if f in FINAL and (mode != "closed" or "/routes/" in dp or any(dp.startswith(x + "/") for x in finals + soft)):
            continue
        if f == "5_2_route.odb" and mode == "nearmiss":
            continue
        freed += rm_file(p)
print("DEEP_FREED %d" % (freed // 2 ** 20))
'''


def _terminal_age_h(j, now=None):
    """hours since the job's last real event (release / retention bookkeeping does not count)"""
    t = j.get("updated") or j.get("created")
    for e in reversed(j.get("events") or []):
        if not re.search(r"bulk release|route bulk released|near-miss|deep release|disk-1210", e[:160]):
            t = e[:25]
            break
    try:
        return ((now or time.time()) - dt.datetime.fromisoformat(t).timestamp()) / 3600
    except Exception:  # noqa: BLE001
        return 0.0


def _main_evidence():
    """(origin/main sha, tree file list, merged-closure records text, receipt-referenced scratch paths), cached by sha
    (refs refreshed at most every DEEP_RELEASE_REFS_TTL_S: the git grep costs ~20 s)"""
    g = lambda *a: subprocess.run(["git", "-C", str(REPO), *a], capture_output=True, text=True, timeout=600)
    sha = g("rev-parse", "origin/main").stdout.strip()
    if not sha:
        return None
    c = _DEEP_CACHE
    if c.get("sha") != sha:
        recs = "".join(g("show", f"{sha}:{p}").stdout for p in g("ls-tree", "--name-only", sha, "results/closure_loop/").stdout.split()
                       if "merged_closures" in p)
        c.update(sha=sha, files=g("ls-tree", "-r", "--name-only", sha).stdout, recs=recs)
    if c.get("refs_sha") != sha and time.time() - c.get("refs_t", 0) > DEEP_RELEASE_REFS_TTL_S or "refs" not in c:
        out = g("grep", "-h", "-o", "-I", "-E", r"/srv/[A-Za-z0-9_./+-]+", sha).stdout
        c.update(refs=sorted({x.split(":", 1)[-1].rstrip("/.") for x in out.split()}), refs_sha=sha, refs_t=time.time())
    return c


def _on_main(commit, ev):
    """is <commit> (7-40 hex) an ancestor of ev["sha"]?  One 'git rev-list' per origin/main sha, cached in ev.
    el1013-fleet3 2026-10-13: the per-job 'git merge-base --is-ancestor' cost 0.7 s x 214 unreleased CLOSED jobs on the
    daemon's main thread EVERY tick (2.5-6 min before any READY job was looked at)."""
    if ev.get("anc_sha") != ev["sha"]:
        out = subprocess.run(["git", "-C", str(REPO), "rev-list", ev["sha"]], capture_output=True, text=True, timeout=600)
        if out.returncode != 0:
            return subprocess.run(["git", "-C", str(REPO), "merge-base", "--is-ancestor", commit, ev["sha"]],
                                  capture_output=True, timeout=120).returncode == 0
        full = out.stdout.split()
        by7 = {}
        for c in full:
            by7.setdefault(c[:7], []).append(c)
        ev.update(anc_sha=ev["sha"], anc=by7)
    return any(c.startswith(commit) for c in ev["anc"].get(commit[:7], ()))


def closure_on_main(j, ev):
    """a CLOSED job whose record reached origin/main: its record commit is an ancestor, a merged_closures record or a
    main tree path names it"""
    for e in reversed(j.get("events") or []):
        m = re.search(r"CLOSED:.*record (\S+) ([0-9a-f]{7,40})", e)
        if m:
            if _on_main(m.group(2), ev):
                return True
            break
    return j["name"] in ev["files"] or j["name"] in ev["recs"]


def collect_crash_after_closed_verdict(j):
    """ROOT 2026-10-15 (peer review 11:00): a route that finished and was judged CLOSED, then stopped NEEDS_HUMAN in
    collect / export / record (30 S81 fill routes, collect crashed twice on a child_lint bug; 17 run dirs were released
    or deleted before the lint fix), is evidence awaiting re-collection (retry --at collect): never deep-released while
    it stays there.  Cancelling the job or a successful re-collect ends the retention."""
    if j.get("status") == LOST_CLOSED:         # ROOT-1130: a lost closed result keeps its routed state
        return True
    if j.get("status") != "NEEDS_HUMAN" or j.get("stage_key") not in ("collect", "export", "record"):
        return False
    ev = " ".join(j.get("events") or [])
    return "route done (rc=0)" in ev and "-> CLOSED" in ev


def deep_release_mode(j, closed, ev, now=None):
    """closed | fail | nearmiss | None (keep) for one job (DEEP RELEASE)"""
    if j.get("deep_released") or not j.get("host") or not j.get("run") or j["status"] not in TERMINAL:
        return None
    if bf_exempt(j) or helper_provenance_retained(j):
        return None
    if _terminal_age_h(j, now) < DEEP_RELEASE_AGE_H:
        return None
    if viz_elem_running(j):                             # VIZ-ELEM: the element page export still reads the DB
        return None
    if j["status"] == "CLOSED":
        if closure_counts(j):
            return "closed" if closure_on_main(j, ev) else None
        return "fail"                                   # revoked closure: a failure on its element
    if j["status"] not in DEEP_RELEASE_FAIL:
        return None
    if collect_crash_after_closed_verdict(j):
        return None
    if near_miss(j, closed) or (j.get("near_miss_retained") and j["spec"].get("block") not in closed):
        return "nearmiss"
    return "fail"


# STALE-24H (owner 2026-10-10, drive-1010): nothing waits more than a day.  A route / calibrate / bench stage or a
# post-route ECO running > 24 h, or a READY / QUEUED job sitting in a HOLD (adoption hold, HELD, admission_hold) for
# > 24 h, is cancelled through the normal cancel path (own process group + containers mounting the run dir; bulk
# release then frees the scratch) and listed in STALE24_LOG for the drive to route a structural next action to the
# owning stream.  A 40-70 h route or a 24 h+ hold ECO does not close by waiting.  Exempt: die-level runs, and a spec
# carrying "allow_over_24h": "<reason>" (logged at every sweep).
STALE24_H = 24.0
STALE24_LOG = Path(os.environ.get("CL_TAKEOVER", "/home/ubuntu/claude-takeover-20261007")) / "stale24.log"
STALE24_EVERY_S = 600
STALE24_PER_SWEEP = 8      # the sweep runs in the tick thread; each kill is a bounded ssh, so cap the work per sweep
_STALE24_LAST = [0.0]
HOLD_WAIT_RE = re.compile(r"^(HELD|adoption hold)", re.I)


def _iso_age_h(s, now):
    try:
        return (now - dt.datetime.fromisoformat(s).timestamp()) / 3600
    except (TypeError, ValueError):
        return None


def stale24_candidates(jobs, now=None):
    """[(job, why)] of live jobs past the 24 h rule (see STALE-24H)"""
    now = time.time() if now is None else now
    out = []
    for j in jobs:
        st = j.get("status")
        if st in TERMINAL or j["spec"].get("allow_over_24h") or (protected_jobs() and j["name"].startswith(protected_jobs())):
            continue
        run = j.get("run") or ""
        if re.search(DIE_CONTAINER_RE, j["name"]) or re.search(DIE_MOUNT_RE, run):
            continue
        if st == "ECO":
            a = _iso_age_h((j.get("eco") or {}).get("started"), now)
            if a is not None and a > STALE24_H:
                out.append((j, f"post-route ECO running {a:.1f} h"))
        elif st == "RUNNING":
            a = _iso_age_h(j.get("stage_started"), now)
            if a is not None and a > STALE24_H:
                out.append((j, f"{j.get('stage_key') or 'stage'} running {a:.1f} h"))
        elif st in ("READY", "QUEUED"):
            held = j.get("admission_hold") or HOLD_WAIT_RE.match(str(j.get("reason") or "")) or \
                HOLD_WAIT_RE.match(str(j.get("wait") or ""))
            last = j.get("stage_started") or j.get("created")
            a = _iso_age_h(last, now)
            if held and a is not None and a > STALE24_H:
                out.append((j, f"{st} hold for {a:.1f} h ({str(held)[:80] if not isinstance(held, bool) else 'held'})"))
    return out


def stale24_sweep(jobs, now=None, force=False):
    """cancel every STALE-24H candidate (at most every STALE24_EVERY_S); returns the cancelled names"""
    now = time.time() if now is None else now
    if not force and now - _STALE24_LAST[0] < STALE24_EVERY_S:
        return []
    _STALE24_LAST[0] = now
    done = []
    for j, why in stale24_candidates(jobs, now)[:STALE24_PER_SWEEP]:
        try:
            with job_lock(j["name"]):
                x = load_job(j["name"])
                if x["status"] in TERMINAL:
                    continue
                reason = f"owner 10-10: >24h stale ({why}); auto-cancelled by the loop (STALE-24H)"
                event(x, reason)
                if x["status"] in ("RUNNING", "ECO"):
                    kill_own_stage(x)
                x.update(cancelled_at=now_iso())
                finish(x, "CANCELLED", reason, "CANCELLED (STALE-24H): " + why)
                save_job(x)
            try:
                with open(STALE24_LOG, "a") as f:
                    f.write(f"{now_iso()} STALE24 {j['name']} owner={j['spec'].get('owner')} block={j['spec'].get('block')} "
                            f"host={j.get('host')} {why} -> CANCELLED; next: structural action by the owning stream\n")
            except OSError:
                pass
            done.append(j["name"])
        except Exception:  # noqa: BLE001
            log(f"stale24 sweep error on {j['name']}:\n" + traceback.format_exc())
    if done:
        log(f"STALE-24H: cancelled {len(done)}: {', '.join(done[:20])}")
    return done


# MEM-GUARD (drive-1010 2026-10-10): EPYC2 (08:33, MemAvailable 6 GB) and EPYC4 (11:50-55, 7 GB) both hung -- sshd
# stopped answering and every job on them was lost -- after running stages grew past their admission snapshot.  The
# kernel OOM killer did not fire in time.  When a fresh probe shows a host below MEM_GUARD_GB (or MEM_GUARD_FRAC of its
# RAM) available, the loop stops its OWN youngest loop stage there (largest declared peak first among the youngest),
# puts the job back to READY at that stage (it relaunches when memory allows), logs it, and does at most one per host
# per MEM_GUARD_EVERY_S.  Die runs and ECO stages (results live in the run dir) are never chosen.
MEM_GUARD_GB = 24
MEM_GUARD_FRAC = 0.03
MEM_GUARD_EVERY_S = 300
_MEM_GUARD_LAST = {}


def protected_jobs():
    """STATE/protected_jobs.json {"prefixes": [...]}: owner-priority lines (e.g. the BF of record) that MEM-GUARD and
    STALE-24H never stop."""
    try:
        return tuple(json.loads((STATE / "protected_jobs.json").read_text()).get("prefixes") or [])
    except (OSError, ValueError):
        return ()


def mem_guard(jobs, fleet, now=None):
    """returns [(host, job name)] stopped this call"""
    now = time.time() if now is None else now
    done = []
    for h in hosts_table():
        name = h["name"]
        good = getattr(fleet, "last_good", {}).get(name)
        if not good or now - good[0] > 120:
            continue
        floor = max(MEM_GUARD_GB, MEM_GUARD_FRAC * h.get("ram_gb", 1024))
        if good[1].get("mem_gb", 1e9) >= floor or now - _MEM_GUARD_LAST.get(name, 0) < MEM_GUARD_EVERY_S:
            continue
        prot = protected_jobs()
        cand = [j for j in jobs if j.get("host") == name and j["status"] == "RUNNING" and j.get("stage_tag")
                and not (prot and j["name"].startswith(prot))
                and not re.search(DIE_CONTAINER_RE, j["name"]) and not re.search(DIE_MOUNT_RE, j.get("run") or "")]
        if not cand:
            continue
        def key(j):
            try:
                age = now - dt.datetime.fromisoformat(j.get("stage_started")).timestamp()
            except (TypeError, ValueError):
                age = 1e9
            return (int(age // 3600), -float(j["spec"].get("peak_ram_gb") or 0))   # youngest hour first, biggest within it
        victim = sorted(cand, key=key)[0]
        _MEM_GUARD_LAST[name] = now
        try:
            with job_lock(victim["name"]):
                x = load_job(victim["name"])
                if x["status"] != "RUNNING":
                    continue
                kill_own_stage(x)
                why = (f"MEM-GUARD: {host_cfg(name)['label']} MemAvailable {good[1].get('mem_gb')} GB < {floor:.0f} GB floor "
                       f"(hosts hung at 6-7 GB on 10-10); stopped this youngest stage ({x.get('stage_key')}), relaunches when memory allows")
                event(x, why)
                for k in ("stage_tag", "stage_started"):
                    x.pop(k, None)
                x.update(status="READY", wait=why[:200])
                save_job(x)
            log(why + f" [{victim['name']}]")
            done.append((name, victim["name"]))
        except Exception:  # noqa: BLE001
            log("mem guard error:\n" + traceback.format_exc())
    return done


def release_deep(jobs, now=None):
    """DEEP RELEASE of up to DEEP_RELEASE_PER_TICK terminal jobs (see DEEP_RELEASE_PY)"""
    closed = closed_blocks(jobs)
    sources = release_source_index(jobs)
    hosts = {h["name"] for h in hosts_table()}
    shared = {}
    for x in jobs:
        if x.get("run") and x.get("host"):
            shared.setdefault((x["host"], x["run"].rstrip("/")), []).append(x)
    cand = [x for x in jobs if x.get("host") in hosts and not x.get("deep_released") and x["status"] in TERMINAL
            and _terminal_age_h(x, now) >= DEEP_RELEASE_AGE_H]
    if not cand:
        return 0
    ev = _main_evidence()
    if not ev:
        return 0
    n = 0
    for x in cand:
        if n >= DEEP_RELEASE_PER_TICK:
            break
        mode = deep_release_mode(x, closed, ev, now)
        if not mode or source_mismatch_retained(x, sources) or helper_provenance_retained(x):
            continue
        run = x["run"].rstrip("/")
        if any(y["status"] not in TERMINAL or _terminal_age_h(y, now) < DEEP_RELEASE_AGE_H
               for y in shared.get((x["host"], run), [])):
            continue                                    # a sibling job still uses the run dir
        with job_lock(x["name"]):
            j = load_job(x["name"])
            if mode != deep_release_mode(j, closed, ev, now) or source_mismatch_retained(j, sources) or helper_provenance_retained(j):
                continue
            commit = j.get("commit_full") or (j["spec"].get("source") or {}).get("commit") or ""
            if commit and subprocess.run(["git", "-C", str(REPO), "cat-file", "-e", commit + "^{commit}"],
                                         capture_output=True, timeout=60).returncode != 0:
                commit = ""
            arg = dict(run=run, mode=mode, src_commit=commit, refs=[r for r in ev["refs"] if r.startswith(run + "/")],
                       final_dirs=[(j.get("metrics") or {}).get("orfs_dir")] if mode == "closed" and (j.get("metrics") or {}).get("orfs_dir") else [])
            r = ssh(j["host"], f"OT_DR={shlex.quote(json.dumps(arg))} python3 - <<'DRPY'\n{DEEP_RELEASE_PY}\nDRPY\n", timeout=1800)
            n += 1
            if r.returncode == 3:
                event(j, f"deep release skipped: live process ({r.stdout.strip()[:120]})")
                continue
            m = re.search(r"DEEP_FREED (\d+)", r.stdout)
            if r.returncode != 0 or not m:
                continue                                # host unreachable / error: retried next tick
            j["deep_released"] = dict(at=now_iso(), mode=mode, freed_mb=int(m.group(1)))
            kept = {"closed": "6_final.{odb,def,v,sdc,spef} of the accepted ORFS dir + route tree",
                    "fail": "6_final.*", "nearmiss": "5_2_route.odb, 6_final.*, objects/, src"}[mode]
            event(j, f"deep release ({mode}, {m.group(1)} MB): kept {kept}, receipt-referenced paths, logs/reports/json")
            save_job(j)
    return n


# SRC-RELEASE (ROOT 2026-10-15, coordinator): AGIdock's root went 356 -> 0 GB free in 4.5 h because every loop run dir
# keeps src/ (6-14 GB) and bench_src_a*/ (13-14 GB) until DEEP release, which waits DEEP_RELEASE_AGE_H and, for a CLOSED
# job, the closure on main; 61 routes closed on AGIdock in that window.  A route never reads either snapshot after its
# verdict: the record branch is already pushed, the receipts on main name the few files they cite, and a later human
# retry / bench re-judgment re-syncs (source_synced=False).  So a terminal job loses both snapshots (trimmed to the
# receipt-named paths, SOURCE_COMMIT kept) SRC_RELEASE_AGE_H after its last event, on every host.  Kept: near-miss
# retained jobs (hold-ECO successors), collect-crash retention, BF exemption, helper provenance, source-mismatch
# retention, .keep, reaper holds, a live process in the run dir, and a run dir shared with a non-terminal job.
SRC_RELEASE_AGE_H = 0.1
SRC_RELEASE_PER_TICK = 40


def src_release_candidates(jobs, now=None):
    closed = closed_blocks(jobs)
    holds = STATE / "reaper_holds"
    hosts = {h["name"] for h in hosts_table()}
    shared = {}
    for x in jobs:
        if x.get("run") and x.get("host"):
            shared.setdefault((x["host"], x["run"].rstrip("/")), []).append(x)
    out = []
    for x in jobs:
        if x["status"] not in TERMINAL or x.get("src_released") or x.get("snapshot_trimmed") or not x.get("run") \
                or x.get("host") not in hosts or _terminal_age_h(x, now) < SRC_RELEASE_AGE_H:
            continue
        if x["status"] in EARLY_FAIL or x.get("near_miss_retained") or near_miss(x, closed) or bf_exempt(x, now) \
                or helper_provenance_retained(x) or collect_crash_after_closed_verdict(x) or viz_elem_running(x) \
                or (holds / x["name"]).exists():
            continue
        if any(y["status"] not in TERMINAL for y in shared.get((x["host"], x["run"].rstrip("/")), [])):
            continue
        out.append(x)
    return sorted(out, key=lambda x: x.get("updated") or "", reverse=True)    # the newest (largest, still on disk) first


def release_src(jobs, now=None, limit=SRC_RELEASE_PER_TICK):
    cand = src_release_candidates(jobs, now)
    if not cand:
        return 0
    ev = _main_evidence()
    if not ev:
        return 0
    sources = release_source_index(jobs)
    n = freed = 0
    for x in cand:
        if n >= limit:
            break
        if source_mismatch_retained(x, sources):
            continue
        with job_lock(x["name"]):
            j = load_job(x["name"])
            if j["status"] not in TERMINAL or j.get("src_released") or j.get("snapshot_trimmed"):
                continue
            commit = j.get("commit_full") or (j["spec"].get("source") or {}).get("commit") or ""
            if not commit or subprocess.run(["git", "-C", str(REPO), "cat-file", "-e", commit + "^{commit}"],
                                            capture_output=True, timeout=60).returncode != 0:
                continue
            full = git("rev-parse", commit + "^{commit}").stdout.strip()
            run = j["run"].rstrip("/")
            arg = dict(run=run, mode="src", src_commit=full, refs=[r for r in ev["refs"] if r.startswith(run + "/")],
                       keep_config_paths=j["status"] == "NEEDS_HUMAN")
            r = ssh(j["host"], f"OT_DR={shlex.quote(json.dumps(arg))} python3 - <<'DRPY'\n{DEEP_RELEASE_PY}\nDRPY\n", timeout=1800)
            n += 1
            m = re.search(r"DEEP_FREED (\d+)", r.stdout)
            if r.returncode == 3 or r.returncode != 0 or not m:
                continue
            j["src_released"] = dict(at=now_iso(), freed_mb=int(m.group(1)))
            j["source_synced"] = False          # any later resume / human retry re-syncs the snapshot
            event(j, f"src release ({m.group(1)} MB): src/ + bench_src*/ snapshots cut to receipt-named paths "
                     f"(git archive {full[:12]} re-creates them)")
            save_job(j)
            freed += int(m.group(1))
    if n:
        log(f"SRC-RELEASE: {n} run dirs, {freed / 1024:.1f} GB freed")
    return n


# POST-COLLECT TRIM of OFFLOAD locations (ROOT 2026-10-16, coordinator; AGIdock 101 GB free, EPYC4 held 72 '<job>-bench'
# dirs = 1.16 TB): SRC-RELEASE / deep release only ever touch the job's own (host, run).  A bench chain offloaded to
# another host (bench_location / btrack[*].run, '<job>-bench') and a run left behind on a previous host keep their src/
# and bench_src_a*/ git snapshots for ever.  Once the job is terminal (and SRC_RELEASE_AGE_H idle), every such OTHER
# location loses exactly those snapshot subtrees (git archive re-creates them; a retry re-syncs); logs, receipts, cl/,
# routes/ and views stay.  Skipped while any non-terminal job uses the location, under a reaper hold, or .keep.
OFFLOAD_TRIM_PER_TICK = 60
OFFLOAD_TRIM_PY = r"""
import json, os, shutil, sys
a = json.loads(os.environ["OT_OT"]); run = a["run"].rstrip("/")
if not run.startswith(tuple(a["roots"])) or "/closure-loop/" not in run or os.path.exists(run + "/.keep"):
    print("OFFLOAD_SKIP"); sys.exit(0)
freed = 0
if os.path.isdir(run):
    for n in sorted(os.listdir(run)):
        if n == "src" or n.startswith("bench_src"):
            p = os.path.join(run, n)
            if os.path.islink(p) or not os.path.isdir(p):
                continue
            for dp, dn, fn in os.walk(p):
                for f in fn:
                    try: freed += os.lstat(os.path.join(dp, f)).st_size
                    except OSError: pass
            shutil.rmtree(p, ignore_errors=True)
print("OFFLOAD_FREED %d" % (freed // 2**20))
"""


def offload_locations(j):
    own = (j.get("host"), (j.get("run") or "").rstrip("/"))
    locs = set()
    bl = j.get("bench_location") or {}
    if bl.get("host") and bl.get("run"):
        locs.add((bl["host"], bl["run"].rstrip("/")))
    for e in (j.get("btrack") or {}).values():
        if isinstance(e, dict) and e.get("host") and e.get("run"):
            locs.add((e["host"], e["run"].rstrip("/")))
    for r in j.get("bench_helper_relocations") or []:
        d = (r or {}).get("destination") or {}
        if d.get("host") and d.get("run"):
            locs.add((d["host"], d["run"].rstrip("/")))
    locs.discard(own)
    done = {(x["host"], x["run"]) for x in j.get("offload_trimmed") or []}
    return sorted(l for l in locs if l not in done)


def release_offload(jobs, now=None, limit=OFFLOAD_TRIM_PER_TICK):
    hosts = {h["name"] for h in hosts_table()}
    holds = STATE / "reaper_holds"
    busy = set()
    for x in jobs:
        if x["status"] not in TERMINAL:
            busy.add((x.get("host"), (x.get("run") or "").rstrip("/")))
            busy.update(offload_locations(x))
    roots = sorted({str(Path(x["run"]).parent) + "/" for x in jobs if x.get("run")})
    n = freed = 0
    for x in sorted(jobs, key=lambda y: y.get("updated") or "", reverse=True):
        if n >= limit:
            break
        if x["status"] not in TERMINAL or (holds / x["name"]).exists() or _terminal_age_h(x, now) < SRC_RELEASE_AGE_H:
            continue
        locs = [l for l in offload_locations(x) if l[0] in hosts and l not in busy]
        if not locs:
            continue
        with job_lock(x["name"]):
            j = load_job(x["name"])
            if j["status"] not in TERMINAL:
                continue
            for host, run in locs:
                if n >= limit:
                    break
                arg = dict(run=run, roots=roots)
                try:
                    r = ssh(host, f"OT_OT={shlex.quote(json.dumps(arg))} python3 - <<'OTPY'\n{OFFLOAD_TRIM_PY}\nOTPY\n",
                            timeout=1800)
                except Exception as ex:  # noqa: BLE001 -- a host hiccup retries next tick
                    log(f"OFFLOAD-TRIM {j['name']} {host}:{run}: {ex}")
                    continue
                n += 1
                m = re.search(r"OFFLOAD_FREED (\d+)", r.stdout or "")
                if r.returncode != 0 or not (m or "OFFLOAD_SKIP" in (r.stdout or "")):
                    continue
                mb = int(m.group(1)) if m else 0
                j.setdefault("offload_trimmed", []).append(dict(host=host, run=run, at=now_iso(), freed_mb=mb))
                event(j, f"offload trim ({mb} MB): {host}:{run} src/ + bench_src*/ snapshots removed (job terminal; "
                         f"logs/receipts kept)")
                freed += mb
            save_job(j)
    if n:
        log(f"OFFLOAD-TRIM: {n} locations, {freed / 1024:.1f} GB freed")
    return n, freed


def cmd_offload_trim(a):
    n, freed = release_offload(all_jobs(), limit=a.limit)
    print(f"OFFLOAD-TRIM: {n} locations, {freed / 1024:.1f} GB freed")


def snapshot_trim(jobs, limit=200, now=None):
    """SNAPSHOT-TRIM (disk-1015): AGIdock fell to 18 GB free with ~590 GB of src/ + bench_src_a*/ git snapshots left in
    deep-released run dirs -- DEEP_RELEASE_PY kept a whole 4-5 GB snapshot whenever one main receipt named a single
    file inside it (signoff.sdc, a bench gate script) or the snapshot root.  Deep release now keeps only the named paths;
    this pass re-applies the same DEEP_RELEASE_PY, at the recorded mode, to jobs deep-released before that fix.  Run by
    the hourly cron guard (`closure_loop.py snapshot-trim`) and safe to repeat: every deep-release guard is re-checked
    (live process, sibling jobs sharing the run dir, receipt refs, .keep, collect-crash retention, source mismatch)."""
    closed = closed_blocks(jobs)
    sources = release_source_index(jobs)
    hosts = {h["name"] for h in hosts_table()}
    shared = {}
    for x in jobs:
        if x.get("run") and x.get("host"):
            shared.setdefault((x["host"], x["run"].rstrip("/")), []).append(x)
    ev = _main_evidence()
    if not ev:
        return 0, 0
    n = freed = 0
    for x in jobs:
        dr = x.get("deep_released") or {}
        if n >= limit or not dr or x.get("snapshot_trimmed") or dr.get("mode") not in ("closed", "fail") \
                or x.get("host") not in hosts or x["status"] not in TERMINAL:
            continue
        probe = dict(x, deep_released=None)
        if deep_release_mode(probe, closed, ev, now) != dr["mode"] or source_mismatch_retained(x, sources) \
                or helper_provenance_retained(x):
            continue
        run = x["run"].rstrip("/")
        if any(y["status"] not in TERMINAL or _terminal_age_h(y, now) < DEEP_RELEASE_AGE_H
               for y in shared.get((x["host"], run), [])):
            continue
        with job_lock(x["name"]):
            j = load_job(x["name"])
            if j.get("snapshot_trimmed") or j["status"] not in TERMINAL:
                continue
            commit = j.get("commit_full") or (j["spec"].get("source") or {}).get("commit") or ""
            if commit and subprocess.run(["git", "-C", str(REPO), "cat-file", "-e", commit + "^{commit}"],
                                         capture_output=True, timeout=60).returncode != 0:
                commit = ""
            if not commit:
                continue
            mode = dr["mode"]
            arg = dict(run=run, mode=mode, src_commit=commit, refs=[r for r in ev["refs"] if r.startswith(run + "/")],
                       final_dirs=[(j.get("metrics") or {}).get("orfs_dir")] if mode == "closed" and (j.get("metrics") or {}).get("orfs_dir") else [])
            r = ssh(j["host"], f"OT_DR={shlex.quote(json.dumps(arg))} python3 - <<'DRPY'\n{DEEP_RELEASE_PY}\nDRPY\n", timeout=1800)
            n += 1
            m = re.search(r"DEEP_FREED (\d+)", r.stdout)
            if r.returncode != 0 or not m:
                continue
            j["snapshot_trimmed"] = dict(at=now_iso(), freed_mb=int(m.group(1)))
            event(j, f"snapshot trim ({mode}, {m.group(1)} MB): src/bench_src snapshots cut to receipt-referenced paths")
            save_job(j)
            freed += int(m.group(1))
    return n, freed


def cmd_snapshot_trim(a):
    n, freed = snapshot_trim(all_jobs(), limit=a.limit)
    msg = f"SNAPSHOT-TRIM: {n} run dirs visited, {freed / 1024:.1f} GB freed"
    log(msg)
    print(msg)


# ------------------------------------------------------------------------------------------------ AUTO-REACT / READY_NEXT
# LOOP-AUTO (owner concern 2026-10-10: session limits stall design work 2-6 h; the loop must keep closing elements with
# no agent alive).  Every failure verdict (AUTO_REACT_FAIL) finished at most AUTO_REACT_MAX_AGE_H ago is judged ONCE
# (j["auto_react_judged"] = its finished_at) by a recovery pass:
#   a  hold-only miss within 30 ps (TT >= 0, -30 <= FF < 0, DRC 0, checks/benches clean, no installed ECO): the SAME job
#      re-opens at its verdict and runs the narrow KEEPWIRES hold ECO (hold_eco.sh KEEPWIRES=1: untouched nets keep
#      their wires) -- also after a route crash / requeue that never reached an ECO;
#   b  thin TT AND FF miss (combo_eligible: TT in [-45, 0), FF in [-30, 0)) whose combo ECO never ran: same job re-opens
#      at its verdict, where the combo ECO fires;
#   c  EARLY_FAIL_HOLD on a block whose RTL boundary is registered (rtl_boundary PASS) and whose route ran without the
#      pin-flop IO reference -> successor job <job>-arc, same commit, pinflop_ref on (REFGLOB median, OT_IOREF_INPUT_PF);
#   d  FLOORPLAN_MARGIN whose only failing lint check is "sliver" -> successor <job>-ard with "sliver_block": true (the
#      macro + core-edge sliver blockage hooks at PRE GLOBAL_PLACE, before the lint);
#   e  DRT-0073 (no access point) -> successor <job>-are with the recipe's min-width / pin-keepout knob (DRT_RECIPES).
#   f  MACRO-CLK (macro-clk-1010): EARLY_FAIL_HOLD, or a NEEDS_RTL FF hold miss, whose CTS built the SRAM-macro clock as
#      a leaf-less shallow tree (CTS log: macro net with 3+ sinks on 0 leaf buffers, >= 150 um average sink wire) or whose
#      calibrate flagged macro clock-pin slew / lateness (calib.json macro_clk), and whose CTS ran WITHOUT the macro
#      clustering default -> successor <job>-arf, same commit: the default (macro_cts_cluster.tcl, shipped into the
#      snapshot by hold_corners_patch.py) now applies.  Checked before c (the macro clock is the root of the stall).
#   h  LAYER-CAP LEAK (2026-10-13): the hold ECO refused the route (hold_eco.sh rc=11) -> successor <job>-arh, same
#      commit, one re-route (a kit older than dc5594311 too: the fixed GRT hook is shipped into the snapshot); if the
#      successor leaks again the verdict and the owner log say: regenerate the kit.  Checked before a/b.
#   g  NEAR-MISS FINISHING VARIANTS (2026-10-13 finishing recipe): a ref_tile route (tools/ref_tile/ref_route.sh) ends
#      NEEDS_RTL inside the near-miss band -- TT >= 0, FF >= -60 ps, DRC <= 20, not clean, no failed check, benches ok,
#      not itself a successor -- and a/b/f do not apply (their ECO ran, or DRC > 0) -> up to 2 successors <job>-arg1 /
#      -arg2, same commit, dropped in ONE pass (as many as the block@commit has route slots left: MAX_ROUTES_PER_KEY
#      minus the holders).  Hold miss: g1 = hold margin max(30 ps, parent + 20 ps), g2 = g1 + 20 ps at place density
#      - 0.05 (margins capped at 50 ps, never below the parent's).  DRC only: g1 = density - 0.05, g2 = density + 0.05, parent hold margin.  ref_route.sh takes PD / HM
#      inline; the spec carries route_hold_margin_ns, variant_group and near_miss_variant.  The variants are finishing,
#      not structure: structure_repeat_at_submit gives exactly these names the exemption class near_miss_finishing
#      (recorded in submit_checks and in the verdict).  The first sibling to CLOSE cancels the queued one (finish()).
# A successor is a new spec dropped into DROP: intake (validate, route key, submit lint) applies as for any job.  Never
# loosens a constraint (no clock / uncertainty / margin / SDC change; hold margins stay the existing defaults).  At most
# one action per job per class (j["auto_react"] = {class: successor or "in-place"}); a successor (spec
# auto_react_parent) gets no new-job successor of its own.  Anything else -- or a class already used -- is one line in
# the owner's stream log (owner_log_path).  Spec "auto_react": false opts out.
# READY_NEXT (deep queue): READY_NEXT/<element>.json = a list of 1-2 full job specs, each with "after": <block or
# job-name prefix>.  When a job of that element ends in a failure verdict with no auto-react action and the element has
# no other live (or pending-intake) job, the first spec goes to DROP (normal intake), a copy to READY_NEXT/done/, and the
# file keeps the rest (moved to done/ when empty).  Bad files are logged once per content and skipped.
TAKEOVER = Path(os.environ.get("CL_TAKEOVER", "/home/ubuntu/claude-takeover-20261007"))
READY_NEXT = Path(os.environ.get("CL_READY_NEXT_DIR", str(TAKEOVER / "READY_NEXT")))
AUTO_REACT_FAIL = {"NEEDS_RTL", "NEEDS_HUMAN", "FLOORPLAN_MARGIN", "PREROUTE_MARGIN", *EARLY_FAIL}
AUTO_REACT_MAX_AGE_H = 6.0          # < DEEP_RELEASE_AGE_H: an in-place ECO needs the route products
AR_HOLD_FF_FLOOR = -30.0
AR_MACRO_TT_FLOOR = -45.0           # class f on a NEEDS_RTL: TT no worse than the combo band
PINFLOP_SINCE = "2026-10-10T03:05"  # PINFLOP-REF overlay deployed (36795a58e): a route started later used it
FP_LINT_CHECKS = ("bank_distance", "channel", "macro_edge", "pin_density", "pin_width", "sliver", "util")
# (cmd regex the recipe must match, env knob, repo file at the job commit that must honour it, marker text in that file)
DRT_RECIPES = (
    (r"route_lane\.sh", "PINKO", "physical/hbm_accel_die_views/su/route_lane.sh", "PINKO"),
    (r"qwen_rom_fulldie|qwen_kv_die|kv_die\.py", "OT_MINW_PINS", "tools/qwen_rom_fulldie.py", "OT_MINW_PINS"),
)
OWNER_LOG_MAP = ((r"hgi", "hgi-1010.log"), (r"mtp|wfc|dspark", "mtp-wfc-1010.log"),
                 (r"qwen|kv-die|kv_die|qfd|qkd|r22k", "qwen-1010.log"),
                 (r"(?<![a-z])ds(?![a-z])|dsrom|dsfd|s81|redesign-ds", "ds-1010.log"),
                 (r"hbm|vm8|svc|sfu|stn|forks|hfd", "hbm-phys-1010.log"))
_RN_BAD = set()


def owner_log_path(j):
    """the owner's 1010 stream log: an owner naming <stream>-1010 with a log, else by owner/block/name keywords"""
    spec = j.get("spec") or {}
    owner = str(spec.get("owner", ""))
    for s in re.findall(r"([A-Za-z0-9][\w-]*-1010)", owner):
        if (TAKEOVER / f"{s}.log").exists():
            return TAKEOVER / f"{s}.log"
    text = f"{owner} {spec.get('block', '')} {j.get('name', '')}".lower()
    for rx, f in OWNER_LOG_MAP:
        if re.search(rx, text):
            return TAKEOVER / f
    return TAKEOVER / "drive-1010.log"


def owner_note(j, text):
    p = owner_log_path(j)
    line = f"{now_iso()} [loop auto-react] {j['name']}: {j['status']} {str(j.get('reason') or '')[:160]} -- {text}\n"
    try:
        append_locked(p, line)
    except OSError as ex:
        log(f"[{j['name']}] owner log {p} not writable: {ex}")
    event(j, f"auto-react: {text} (noted in {p.name})")


def _verdict_idx(j):
    stl = stage_list(j["spec"])
    return next((i for i, x in enumerate(stl) if x["kind"] == "verdict"), None)


def _at_verdict(j):
    i = _verdict_idx(j)
    return i is not None and j.get("stage_idx") == i


def _benches_ok(j):
    return all(b.get("ok") for b in (j.get("benches") or {}).values())


def ar_hold_window(j):
    """class a: a hold-only miss within 30 ps on a route at its verdict, no KEEPWIRES ECO tried yet"""
    m, he = j.get("metrics") or {}, j["spec"].get("hold_eco") or {}
    tt, ff = m.get("ss_ps"), m.get("ff_ps")
    if j["status"] != "NEEDS_RTL" or not _at_verdict(j) or he.get("enabled", True) is False:
        return False
    if not all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in (tt, ff)):
        return False
    if not (tt >= SS_MIN and AR_HOLD_FF_FLOOR <= ff < FF_MIN and m.get("drc") == 0 and not m.get("errors")):
        return False
    e = j.get("eco") or {}
    if blocking_checks(j) or not _benches_ok(j) or e.get("installed") or j.get("eco_stack") or he.get("keep_wires"):
        return False
    return not any((x or {}).get("keepwires") for x in [*(j.get("eco_history") or []), e])


def ar_combo_window(j):
    """class b: thin TT and FF miss at the verdict whose combo ECO never ran"""
    if j["status"] != "NEEDS_RTL" or not _at_verdict(j):
        return False
    return combo_eligible(j, j.get("metrics") or {}, blocking_checks(j), _benches_ok(j))


def rtl_boundary_verdict(j):
    if j.get("rtl_boundary_verdict"):
        return j["rtl_boundary_verdict"]
    for e in j.get("events") or []:
        mm = re.search(r"submit lint (?:PASS|FIX)\b.*?; (PASS|WARN|REFUSE|SKIP) ", e)
        if mm:
            return mm.group(1)
    try:
        import rtl_boundary
        git_ = submit_lint.Git(REPO)
        return rtl_boundary.check(j.get("spec_submitted") or j["spec"], git_.show).get("verdict")
    except Exception as ex:  # noqa: BLE001
        log(f"[{j['name']}] auto-react rtl_boundary check failed: {type(ex).__name__}: {str(ex)[:160]}")
        return None


def pinflop_used(j):
    spec = j["spec"]
    return bool(j.get("pinflop_ref_applied")) or (spec.get("pinflop_ref", True) is not False
                                                   and str(j.get("stage_started") or "") >= PINFLOP_SINCE)


def _stage_cmds(spec):
    st = spec.get("stages") or {}
    return " ".join(str((st.get(k) or {}).get("cmd", "")) for k in ("calibrate", "route"))


def fp_lint_checks(j):
    return set(re.findall(r"(?:^|\|\s*)(" + "|".join(FP_LINT_CHECKS) + r"):", str(j.get("reason") or "")))


def drt0073_seen(j):
    txt = str(j.get("reason") or "") + " ".join(str(c.get("tail", "")) + str(c.get("first_error", "")) + str(c.get("why", ""))
                                                for c in j.get("crashes") or [])
    return "DRT-0073" in txt


def drt_recipe(j):
    """(knob, why) for the first DRT_RECIPES entry this job's recipe matches and does not set yet, honoured at its commit"""
    spec = j.get("spec_submitted") or j["spec"]
    cmds = _stage_cmds(spec)
    for rx, knob, path, marker in DRT_RECIPES:
        if not re.search(rx, cmds) or re.search(rf"\b{knob}=", cmds):
            continue
        try:
            body = submit_lint.Git(REPO).show(str(spec["source"]["commit"]), path) or ""
        except Exception:  # noqa: BLE001
            body = ""
        if marker in body:
            return knob
    return None


AR_NM_FF_FLOOR = -60.0
AR_NM_DRC_MAX = 20
AR_NM_HM_MAX = 0.050        # ns: above it CTS / GRT hold repair overloads (HM_LOW_SINCE note); never below the parent's
REF_ROUTE_RE = re.compile(r"\bbash\s+(\S*tools/ref_tile/ref_route\.sh)\s+(\S+)")
_INLINE_ENV_RE = r"(?<![\w$])%s=(\S+)\s+(?=(?:\w+=(?:'[^']*'|\S+)\s+)*bash\s+\S*tools/ref_tile/ref_route\.sh)"


# FEED-THROUGH WINDOW (2026-10-13, finishing recipe C follow-up): vm_cp_fw3_cx / vm_cp_fe3_cx-cx1-eca45f5dc ended
# "route hold repair stalled; window I2O=2@-56.2 I2O=2@-49.6" (ck -> qNW[*]: input port to output port, no register in
# between) and class g routed 4 HM / PD variants that failed the same way at FF -54..-68.  A port-to-port path meets the
# IO budget on both sides (0.2 T input-min against 0.2 T output hold) only with a register at the pin: delay cells cannot
# close it, so the tile is a structural defect (owner 10-13: die timing by construction), never a near miss.
PIN_REG_MISSING = "pin register missing: structural"
_WIN_ROW_RE = re.compile(r"^([IR]2[OR])\s+(\d+)\s+(-?[\d.]+)", re.M)
_WIN_TAG_RE = re.compile(r"\b([IR]2[OR])=(\d+)@(-?[\d.]+)")


def feedthrough_window(j):
    """'' or the text of the I2O (input port -> output port) class of the job's stalled hold window, when it violates:
    from the kept ot_hold_stall_*.rpt rows (j["hold_window"]), else the 'window I2O=2@-56.2' tags of its reason"""
    rows = _WIN_ROW_RE.findall(str(j.get("hold_window") or "")) or _WIN_TAG_RE.findall(str(j.get("reason") or ""))
    bad = []
    for cls, n, worst in rows:
        try:
            if cls == "I2O" and int(n) > 0 and float(worst) < FF_MIN:
                bad.append((int(n), float(worst)))
        except ValueError:
            continue
    if not bad:
        return ""
    return (f"{max(n for n, _ in bad)} input-to-output feed-through endpoint(s), worst {min(w for _, w in bad):+.1f} ps "
            f"in the stalled hold window")


def ar_near_miss(j):
    """class g band: (True, kind "hold"|"drc") / (False, None)"""
    spec, m = j["spec"], j.get("metrics") or {}
    tt, ff, drc = m.get("ss_ps"), m.get("ff_ps"), m.get("drc")
    if j["status"] != "NEEDS_RTL" or not spec.get("ref_tile") or spec.get("auto_react_parent"):
        return False, None
    if not all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in (tt, ff, drc)):
        return False, None
    if not (tt >= SS_MIN and ff >= AR_NM_FF_FLOOR and 0 <= drc <= AR_NM_DRC_MAX) or (ff >= FF_MIN and drc == 0):
        return False, None
    if m.get("errors") or blocking_checks(j) or not _benches_ok(j):
        return False, None
    if not REF_ROUTE_RE.search(str(((spec.get("stages") or {}).get("route") or {}).get("cmd") or "")):
        return False, None
    return True, "hold" if ff < FF_MIN else "drc"


def _route_inline(cmd, var):
    mm = re.search(_INLINE_ENV_RE % var, cmd)
    try:
        return float(mm.group(1).strip("'\"")) if mm else None
    except ValueError:
        return None


def near_miss_parent_knobs(j):
    """(place density, hold margin ns) the near-miss route ran with: inline PD / HM in its route cmd, else kit.env PD at
    the job commit (ref_route.sh default 0.55) and spec route_hold_margin_ns (loop default 0.010)"""
    spec = j["spec"]
    cmd = str(spec["stages"]["route"]["cmd"])
    pd, hm = _route_inline(cmd, "PD"), _route_inline(cmd, "HM")
    if pd is None:
        try:
            body = submit_lint.Git(REPO).show(str(spec["source"]["commit"]), REF_ROUTE_RE.search(cmd).group(2)) or ""
            mm = re.search(r"^PD=([0-9.]+)\s*$", body, re.M)
            pd = float(mm.group(1)) if mm else None
        except Exception:  # noqa: BLE001
            pd = None
    if hm is None:
        v = spec.get("route_hold_margin_ns")
        hm = float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else 0.010
    return (0.55 if pd is None else pd), hm


def near_miss_variants(j, kind):
    """[(class, PD, HM ns, text)] for the 2 finishing variants of a near miss (never a looser hold margin)"""
    pd, hm = near_miss_parent_knobs(j)
    lo, hi = round(max(0.30, pd - 0.05), 3), round(min(0.85, pd + 0.05), 3)
    if kind == "hold":
        h1 = round(max(hm, min(AR_NM_HM_MAX, max(0.030, hm + 0.020))), 3)
        rows = [("g1", pd, h1), ("g2", lo, round(max(hm, min(AR_NM_HM_MAX, h1 + 0.020)), 3))]
    else:
        rows = [("g1", lo, hm), ("g2", hi, hm)]
    return [(c, p, h, f"place density {p:g} (parent {pd:g}), route hold margin {h * 1000:g} ps (parent {hm * 1000:g} ps)")
            for c, p, h in rows]


def near_miss_mutate(spec, parent, cls, pd, hm, text):
    st = spec["stages"]["route"]
    cmd = re.sub(_INLINE_ENV_RE % "PD", "", re.sub(_INLINE_ENV_RE % "HM", "", st["cmd"]))
    st["cmd"] = REF_ROUTE_RE.sub(lambda mm: f"PD={pd:g} HM={hm:g} bash {mm.group(1)} {mm.group(2)}", cmd, count=1)
    spec["route_hold_margin_ns"] = hm
    spec["variant_group"] = f"{parent}-arg"
    spec["near_miss_variant"] = dict(parent=parent, cls=cls, place_density=pd, hold_margin_ns=hm)
    spec.pop("structural_change", None)      # a finishing variant states no structure: the exemption class covers it
    spec["notes"] = (str(spec.get("notes") or "") + f" [loop near-miss finishing variant {cls} of {parent}: {text}; "
                     f"same RTL, kit and commit]").strip()


def near_miss_slots(j):
    spec = j["spec"]
    held = route_keys().get(f"{spec['block']}@{str(spec['source']['commit'])[:12]}", [])
    return max(0, min(AR_NM_VARIANTS, MAX_ROUTES_PER_KEY - len(set(held) | {j["name"]})))


def ar_successor(j, cls, why, mutate):
    """drop <job>-ar<cls> (the submitted spec, same commit, mutated) into DROP; returns its name or None"""
    base = json.loads(json.dumps(j.get("spec_submitted") or j["spec"]))
    suffix = f"-ar{cls}"
    name = j["name"][:96 - len(suffix)] + suffix
    base.update(name=name, auto_react_parent=j["name"], auto_react_class=cls)
    base.pop("submit_lint", None)
    mutate(base)
    if jpath(name).exists() or (DROP / f"{name}.json").exists():
        return None
    DROP.mkdir(parents=True, exist_ok=True)
    tmp = DROP / f".{name}.json.tmp"
    tmp.write_text(json.dumps(base, indent=1) + "\n")
    os.replace(tmp, DROP / f"{name}.json")
    return name


def _prefix_env(spec, knob):
    for k in ("calibrate", "route"):
        st = (spec.get("stages") or {}).get(k)
        if isinstance(st, dict) and st.get("cmd"):
            st["cmd"] = f"export {knob}=1; " + st["cmd"]


def macro_clk_flag(j, calib):
    """MACRO-CLK after CTS: keep the calibrate's macro clock verdict with the job and flag outliers in its events"""
    mc = calib.get("macro_clk") if isinstance(calib, dict) else None
    if not isinstance(mc, dict):
        return
    j["calibration"]["macro_clk"] = mc
    txt = macro_clk.calib_flag_text(mc)
    if txt:
        event(j, txt)
        ledger(j, txt)


def macro_clk_sig(j):
    """macro_clk.signature() of this job's CTS logs (+ calibrate verdict), cached per verdict (one ssh per failure)"""
    key = str(j.get("finished_at"))
    c = j.get("macro_clk_sig")
    if isinstance(c, dict) and c.get("at") == key:
        return c
    mc = (j.get("calibration") or {}).get("macro_clk")
    logs = []
    if j.get("host") and j.get("run"):
        try:
            r = ssh(j["host"], macro_clk.scan_cmd(j["run"]), timeout=120)
            logs = macro_clk.parse_cts_logs(r.stdout) if r.returncode == 0 else []
        except Exception as ex:  # noqa: BLE001
            log(f"[{j['name']}] macro-clk scan failed: {type(ex).__name__}: {str(ex)[:160]}")
    sig = dict(macro_clk.signature(logs, mc), at=key)
    j["macro_clk_sig"] = sig
    return sig


def ar_macro_clk(j):
    """class f applies: (True, detail) / (False, why-not or None when there is no macro clock signature)"""
    m = j.get("metrics") or {}
    ff, tt = m.get("ff_ps"), m.get("ss_ps")
    num = lambda v: isinstance(v, (int, float)) and not isinstance(v, bool)  # noqa: E731
    # a NEEDS_RTL counts only when hold is its problem (FF < 0, TT within the combo band): a deep setup miss is not
    hold_fail = j["status"] == "EARLY_FAIL_HOLD" or (
        j["status"] == "NEEDS_RTL" and num(ff) and ff < FF_MIN and num(tt) and tt >= AR_MACRO_TT_FLOOR)
    if not hold_fail or j["spec"].get("macro_cts") is False:
        return False, None
    sig = macro_clk_sig(j)
    if not sig["hit"]:
        return False, None
    if sig["clustered"]:
        return False, f"macro clock outlier WITH the clustering default on ({sig['why']}): structural -- launch the SRAM " \
                      f"inputs from a flop on the macro's leaf / lockup, or re-place the macros"
    return True, f"macro clock on a shallow leaf-less tree ({sig['why']}) -> requeue under the macro clustering default"


def ar_plan(j):
    """(class, kind, detail) for the first recipe that applies, else (None, None, why)"""
    spec = j["spec"]
    if j["status"] == "NEEDS_RTL" and eco_layer_cap_refused(j):     # before a/b: an in-place ECO would be refused again
        if spec.get("auto_react_parent"):
            return None, None, ("layer-cap leak again after the automatic re-route: regenerate the kit and re-route "
                                "(no further automatic route)")
        if not kit_has_grt_cap_fix(j):      # coordinator 2026-10-13: the loop ships the fixed hook into old kits too
            return "h", "successor", (f"hold ECO refused for a layer-cap leak; the kit predates {GRT_CAP_FIX} -> one "
                                      f"re-route with the fixed grt_macro_top_layer*.tcl shipped into the snapshot")
        return "h", "successor", "hold ECO refused for a layer-cap leak -> one re-route with the current kit recipe"
    if ar_hold_window(j):
        return "a", "in-place", "hold-only miss within 30 ps -> narrow KEEPWIRES hold ECO"
    if ar_combo_window(j):
        return "b", "in-place", "thin TT and FF miss -> combo ECO"
    succ_ok = not spec.get("auto_react_parent")
    if j["status"] in ("EARLY_FAIL_HOLD", "NEEDS_RTL"):
        mf, mwhy = ar_macro_clk(j)
        if mf and succ_ok:
            return "f", "successor", mwhy
        nm, kind = ar_near_miss(j)
        ft = feedthrough_window(j) if nm else ""
        if ft:
            if PIN_REG_MISSING not in str(j.get("reason") or ""):      # a verdict written before this class existed
                j["reason"] = f"{j.get('reason') or ''}; {PIN_REG_MISSING}"[:300]
            return None, None, (f"{PIN_REG_MISSING} ({ft}): register the port at the pin (RTL); no finishing variant "
                                f"can close a port-to-port path")
        if nm:
            m = j.get("metrics") or {}
            return "g", "variants", (f"near miss (TT {m.get('ss_ps')} / FF {m.get('ff_ps')} ps / DRC {m.get('drc')}; "
                                     f"{kind}) -> finishing variants")
        if mwhy:
            return None, None, mwhy if succ_ok else f"auto-react successor (class {spec.get('auto_react_class')}); {mwhy}"
    if j["status"] == "EARLY_FAIL_HOLD":
        if not succ_ok:
            return None, None, "auto-react successor failed again (EARLY_FAIL_HOLD)"
        if pinflop_used(j):
            return None, None, "CTS/GRT hold flood with the pin-flop reference already in use"
        if re.search(r"\bOT_REF_PINFLOP=0\b", _stage_cmds(spec)):
            return None, None, "hold flood; recipe pins OT_REF_PINFLOP=0 (owner choice)"
        rb = rtl_boundary_verdict(j)
        if rb != "PASS":
            return None, None, f"hold flood; RTL boundary {rb or 'unknown'} (register the boundary first)"
        return "c", "successor", "hold flood on a registered boundary -> pin-flop IO reference"
    if j["status"] == "FLOORPLAN_MARGIN":
        checks = fp_lint_checks(j)
        if checks == {"sliver"} and not spec.get("sliver_block") and succ_ok:
            return "d", "successor", "sliver-only floorplan lint fail -> macro/edge sliver blockage hooks"
        return None, None, f"floorplan lint {sorted(checks) or 'unparsed'}" + ("" if succ_ok else " (auto-react successor)")
    if drt0073_seen(j):
        knob = drt_recipe(j) if succ_ok else None
        if knob:
            return "e", "successor", f"DRT-0073 no access point -> {knob}=1 pin variant"
        return None, None, "DRT-0073 with no pin-variant knob for this recipe"
    if spec.get("auto_react_parent"):
        return None, None, f"auto-react successor (class {spec.get('auto_react_class')}) failed"
    return None, None, "no recipe"


def ar_reopen(j, cls, detail):
    e = j.get("eco") or {}
    if e:
        j.setdefault("eco_history", []).append(e)
    j["eco"] = {}
    if cls == "a":
        j["auto_react_keepwires"] = True
    j.update(status="READY", stage_idx=_verdict_idx(j), stage_key="verdict", attempt=j["attempt"] + 1, retries_used=0,
             errors=[], reason=None)
    event(j, f"auto-react {cls}: {detail}; re-opened at the verdict (earlier ECO kept in eco_history)")
    ledger(j, f"AUTO-REACT {cls} (loop): {detail}; re-opened in place")


def ready_next_files():
    """[(path, specs)] of valid READY_NEXT files; a bad file is logged once per content and skipped"""
    out = []
    for p in sorted(READY_NEXT.glob("*.json")) if READY_NEXT.is_dir() else []:
        try:
            raw = p.read_text()
        except OSError:
            continue
        key = (p.name, hashlib.sha256(raw.encode()).hexdigest())
        try:
            specs = json.loads(raw)
            if not isinstance(specs, list) or not 1 <= len(specs) <= 2:
                raise ValueError("must be a JSON list of 1-2 job specs")
            for s in specs:
                if not isinstance(s, dict) or not isinstance(s.get("after"), str) or not s["after"].strip():
                    raise ValueError("every spec needs a non-empty \"after\" (block or job-name prefix)")
                errs = validate(drop_retired_hosts({k: v for k, v in s.items() if k != "after"})[0])
                if errs:
                    raise ValueError(f"{s.get('name')}: " + "; ".join(errs)[:400])
        except (ValueError, TypeError) as ex:
            if key not in _RN_BAD:
                _RN_BAD.add(key)
                log(f"READY_NEXT {p} invalid, skipped: {ex}")
            continue
        out.append((p, specs))
    return out


def _element_match(after, block, name):
    return block == after or str(name).startswith(after)


def pending_drop_specs():
    """specs in DROP not ingested yet (no job state): they count as live work of their element"""
    out = []
    for p in DROP.glob("*.json") if DROP.is_dir() else []:
        if jpath(p.stem).exists():
            continue
        try:
            s = json.loads(p.read_text())
        except Exception:  # noqa: BLE001
            continue
        if isinstance(s, dict):
            out.append(s)
    return out


def ready_next_take(j, live):
    """ingest the next READY_NEXT spec for j's element (j just failed, no auto-react action); returns its name"""
    block = j["spec"].get("block")
    pend = pending_drop_specs()
    for p, specs in ready_next_files():
        after = specs[0]["after"]
        if not _element_match(after, block, j["name"]):
            continue
        if any(x["name"] != j["name"] and _element_match(after, x["spec"].get("block"), x["name"]) for x in live) or \
                any(_element_match(after, s.get("block"), s.get("name", "")) for s in pend):
            event(j, f"READY_NEXT {p.name}: element {after} has another live job; not ingested")
            return None
        nxt = dict(specs[0])
        nxt.pop("after")
        nxt["ready_next_from"] = f"{p.name} after {j['name']} {j['status']}"
        if jpath(nxt["name"]).exists() or (DROP / f"{nxt['name']}.json").exists():
            log(f"READY_NEXT {p}: {nxt['name']} already exists; spec dropped from the file")
        else:
            DROP.mkdir(parents=True, exist_ok=True)
            tmp = DROP / f".{nxt['name']}.json.tmp"
            tmp.write_text(json.dumps(nxt, indent=1) + "\n")
            os.replace(tmp, DROP / f"{nxt['name']}.json")
        done = READY_NEXT / "done"
        done.mkdir(parents=True, exist_ok=True)
        (done / f"{p.stem}.{nxt['name']}.json").write_text(json.dumps(specs[0], indent=1) + "\n")
        rest = specs[1:]
        if rest:
            tmp = p.with_name(f".{p.name}.tmp")
            tmp.write_text(json.dumps(rest, indent=1) + "\n")
            os.replace(tmp, p)
        else:
            os.replace(p, done / f"{p.stem}.{now_iso().replace(':', '')}.json")
        event(j, f"READY_NEXT: ingested {nxt['name']} from {p.name} ({len(rest)} left)")
        ledger(j, f"READY_NEXT {p.name}: successor {nxt['name']} dropped for intake after {j['status']}")
        return nxt["name"]
    return None


def auto_react(jobs, now=None):
    """the AUTO-REACT + READY_NEXT recovery pass (header above); returns [(job, action)]"""
    now = now or time.time()
    acted = []
    live = [x for x in jobs if x["status"] not in TERMINAL]
    closed = closed_blocks(jobs)
    for j0 in jobs:
        fin = j0.get("finished_at")
        if j0["status"] not in AUTO_REACT_FAIL or not fin or j0.get("auto_react_judged") == fin:
            continue
        age = _iso_age_h(fin, now)
        if age is None or age > AUTO_REACT_MAX_AGE_H:
            continue
        with job_lock(j0["name"]):
            j = load_job(j0["name"])
            if j["status"] not in AUTO_REACT_FAIL or j.get("finished_at") != fin or j.get("auto_react_judged") == fin:
                continue
            j["auto_react_judged"] = fin
            spec, block = j["spec"], j["spec"].get("block")
            if spec.get("auto_react") is False:
                event(j, "auto-react: off (spec auto_react false)")
                save_job(j)
                continue
            if block in closed or any(x["name"] != j["name"] and x["spec"].get("block") == block for x in live):
                event(j, f"auto-react: block {block} has a live or closed sibling job; no action")
                save_job(j)
                continue
            cls, kind, detail = ar_plan(j)
            done = j.setdefault("auto_react", {})
            action = None
            if cls and cls in done:
                cls, detail = None, f"auto-react class {cls} already used ({done[cls]}); {detail}"
            if cls and kind == "in-place":
                if j.get("bulk_released") or j.get("deep_released"):
                    cls, detail = None, f"{detail}: route products released"
                else:
                    ar_reopen(j, cls, detail)
                    done[cls] = "in-place"
                    action = f"{cls}:in-place"
            elif cls and kind == "variants":
                slots = near_miss_slots(j)
                rows = near_miss_variants(j, ar_near_miss(j)[1])[:slots]
                names = []
                for vc, pd, hm, text in rows:
                    nm = ar_successor(j, vc, detail, lambda s, a=(vc, pd, hm, text): near_miss_mutate(s, j["name"], *a))
                    if nm:
                        names.append(nm)
                        event(j, f"auto-react g: {detail}; variant {nm} dropped for intake (same commit): {text}")
                if names:
                    done[cls] = names
                    action = f"g:{','.join(names)}"
                    ledger(j, f"AUTO-REACT g (loop): {detail}; variants {', '.join(names)} "
                              f"(structure-repeat exemption class {NEAR_MISS_EXEMPT}; first to CLOSE cancels the queued one)")
                else:
                    cls, detail = None, (f"{detail}: no route slot left for the block@commit ({MAX_ROUTES_PER_KEY} routes "
                                         f"per source commit)" if not slots else f"{detail}: variant names already taken")
            elif cls:
                if cls == "c":
                    def mut(s):
                        s["pinflop_ref"] = True
                elif cls == "d":
                    def mut(s):
                        s["sliver_block"] = True
                elif cls == "f":
                    def mut(s):
                        s["macro_cts"] = True        # marker only: the clustering default applies to every job
                elif cls == "h":
                    def mut(s):
                        s.setdefault("structural_change", "re-route under the current kit recipe: the GRT macro hook "
                                     "restores the DRT top layer (dc5594311, shipped into the snapshot for older "
                                     "kits), so no wire lands above the layer cap")
                else:
                    knob = drt_recipe(j)

                    def mut(s, knob=knob):
                        _prefix_env(s, knob)
                if cls == "d":
                    release_route_key(j)     # the lint stopped it before global placement: no route spent
                name = ar_successor(j, cls, detail, mut)
                if name:
                    done[cls] = name
                    action = f"{cls}:{name}"
                    event(j, f"auto-react {cls}: {detail}; successor {name} dropped for intake (same commit)")
                    ledger(j, f"AUTO-REACT {cls} (loop): {detail}; successor {name}")
                else:
                    cls, detail = None, f"{detail}: successor name already taken"
            if not action:
                rn = ready_next_take(j, live)
                owner_note(j, f"{detail}; structural fix needed" + (f"; READY_NEXT ingested {rn}" if rn else ""))
                action = f"none{':' + rn if rn else ''}"
            save_job(j)
            acted.append((j["name"], action))
    return acted


# HOST-DOWN (drive-1010 2026-10-10: ot-epyc2 unreachable from 08:46, 30 jobs requeued by hand): every probe of a host
# (fleet admission probe, stage poll) records success / failure; a host whose probes have ALL failed for more than
# HOST_DOWN_S is "down": it admits no new job (in memory, like smoke_only; hosts.json untouched) and its RUNNING
# calibrate / route / bench stages are requeued from scratch on another host (status QUEUED, host / run None, stage 0,
# attempt + 1, source_synced False).  ECO / ECO_INSTALL / SUMMARY jobs (a finished route on that host) wait up to
# HOST_DOWN_ECO_WAIT_S for the host, then the same.  The first successful probe clears the state.
HOST_DOWN_S = 1800
HOST_DOWN_ECO_WAIT_S = 6 * 3600
HOST_DOWN = {}                      # host -> time of the first failed probe since the last success
_HOST_DOWN_LOCK = threading.Lock()


def note_host(host, ok, now=None):
    if not host:
        return
    now = now or time.time()
    with _HOST_DOWN_LOCK:
        if ok:
            t = HOST_DOWN.pop(host, None)
            if t is not None and now - t > HOST_DOWN_S:
                log(f"HOST-DOWN: {host} reachable again after {(now - t) / 60:.0f} min")
        else:
            HOST_DOWN.setdefault(host, now)


def host_down_s(host, now=None):
    t = HOST_DOWN.get(host)
    return ((now or time.time()) - t) if t else 0.0


def host_down(host, now=None):
    return host_down_s(host, now) > HOST_DOWN_S


def host_down_requeue(j, kind, now=None):
    """requeue j from scratch when its host is down (RUNNING calibrate/route/bench) or down > 6 h (ECO/SUMMARY)"""
    d = host_down_s(j.get("host"), now)
    if j["status"] == "RUNNING" and kind in ("calibrate", "route", "bench"):
        if d <= HOST_DOWN_S:
            return False
    elif j["status"] in ("ECO", "ECO_INSTALL", "SUMMARY"):
        if d <= HOST_DOWN_ECO_WAIT_S:
            return False
    else:
        return False
    host, stage = j.get("host"), j.get("stage_key")
    if j.get("eco"):
        j.setdefault("eco_history", []).append(dict(j["eco"], abandoned=f"host {host} down"))
        j["eco"] = {}
    for k in ("stage_tag", "stage_key", "resume", "hold_stop", "checkpoint_affinity", "bench_location", "ctrack", "metrics"):
        j.pop(k, None)
    j["btrack"] = {k: v for k, v in (j.get("btrack") or {}).items() if v.get("state") == "done"}
    j.update(status="QUEUED", host=None, run=None, stage_idx=0, attempt=j["attempt"] + 1, retries_used=0, errors=[],
             source_synced=False, unreachable=0, reason=None)
    event(j, f"HOST-DOWN: {host} failed every probe for {d / 60:.0f} min; {stage} abandoned, re-queued from scratch "
             f"(another host)")
    ledger(j, f"REQUEUED automatically: host {host} down {d / 60:.0f} min (stage {stage})")
    return True


def tick(fleet):
    if restart_if_requested() or _STOP.is_set():
        return
    try:
        inprocess_sync_on_main_move()
    except Exception:  # noqa: BLE001
        log("inprocess_sync_on_main_move error:\n" + traceback.format_exc())
    t_ph = time.time()
    overlay_drift_check()
    _slow_phase("overlay_drift_check", t_ph)
    t_ph = time.time()
    try:
        ingest()
    except Exception:  # noqa: BLE001
        log("ingest error:\n" + traceback.format_exc())
    _slow_phase("ingest", t_ph)
    own = {}
    for x in all_jobs():
        if x["status"] in ("RUNNING", "ECO", "SUMMARY", "ECO_INSTALL") and x.get("host"):
            stl = stage_list(x["spec"])
            st = stl[min(x.get("stage_idx", 0), len(stl) - 1)]
            own[x["host"]] = own.get(x["host"], 0) + (8 if x["status"] == "ECO" else st.get("threads", 4) or 4)
        for e in (x.get("btrack") or {}).values() if x["status"] not in TERMINAL else ():
            if e.get("state") == "running":
                own[e["host"]] = own.get(e["host"], 0) + 4
    fleet.own_running = own
    sync = {}
    for x in all_jobs():
        if x["status"] == "SYNC" and x.get("host") and not x.get("source_synced"):
            sync[x["host"]] = sync.get(x["host"], 0) + 1
    with FLEET_LOCK:
        fleet.syncing = sync
    schedule_housekeeping()     # release_bulk / release_deep / stale24_sweep: background, never ahead of dispatch
    t_mg = time.time()
    try:
        mem_guard(all_jobs(), fleet)
    except Exception:  # noqa: BLE001
        log("mem guard error:\n" + traceback.format_exc())
    _slow_phase("mem_guard", t_mg)
    for req in sorted((STATE / "migrate_requests").glob("*.json")) if (STATE / "migrate_requests").exists() else []:
        try:
            rq = json.loads(req.read_text())
            with job_lock(rq["name"]):
                j = load_job(rq["name"])
                if j["status"] == "RUNNING" and j.get("stage_key") == "route":
                    migrate_checkpoint(j, rq["host"])
                else:
                    log(f"migrate request {rq['name']} ignored: status {j['status']} stage {j.get('stage_key')}")
        except Exception:  # noqa: BLE001
            log("migrate request error:\n" + traceback.format_exc())
            try:
                j = load_job(rq["name"])
                if j["status"] == "MIGRATING":
                    finish(j, "NEEDS_HUMAN", "checkpoint move failed (see daemon.log)", "NEEDS_HUMAN: checkpoint move failed")
                    save_job(j)
            except Exception:  # noqa: BLE001
                pass
        req.unlink(missing_ok=True)
    schedule_recovery()
    # persistent pool, no per-tick barrier (2026-10-07): a job still being stepped (a source sync, a 30-min verdict check)
    # is skipped this tick instead of holding every other job until the next tick
    global _POOL
    if _POOL is None:
        _POOL = ThreadPoolExecutor(max_workers=WORKERS)
    live = [x for x in all_jobs() if x["status"] not in TERMINAL]
    prio_hosts = {}
    for x in live:
        p = job_priority(x)
        if p <= 0 or x["status"] not in ("QUEUED", "READY") or not x.get("wait"):
            continue
        usable = [x["host"]] if x["status"] == "READY" and x.get("host") else \
            [h["name"] for h in hosts_table() if fleet.compatible(h["name"], x["spec"])]
        for h in usable:
            prio_hosts[h] = max(prio_hosts.get(h, 0), p)
    fleet.prio_hosts = prio_hosts
    # 21:58: a TT batch put ~150 jobs in SYNC; each source sync holds a worker and an ssh channel for minutes, so all 48
    # workers sat in sync_source and no READY stage launched for 15 min.  Syncs (QUEUED / SYNC) get at most SYNC_SLOTS
    # workers; every other state is submitted first.
    with _INFLIGHT_LOCK:
        syncing = sum(1 for x in live if x["name"] in _INFLIGHT and x["status"] in ("QUEUED", "SYNC"))
    order = sorted(live, key=lambda x: (x["status"] in ("QUEUED", "SYNC"), -job_priority(x)))
    for x in order:
        if _STOP.is_set():
            break                        # draining for a restart: no new step starts
        if x["status"] in ("QUEUED", "SYNC"):
            if syncing >= SYNC_SLOTS:
                continue
            with _INFLIGHT_LOCK:
                if x["name"] not in _INFLIGHT:
                    syncing += 1
        with _INFLIGHT_LOCK:
            if x["name"] in _INFLIGHT:
                continue
            _INFLIGHT.add(x["name"])
        _FUTS[x["name"]] = _POOL.submit(_advance_and_release, x["name"], fleet)
    write_status(fleet=fleet)


_RECOVERY_POOL = None
_RECOVERY_FUTURE = None
_HOUSE_POOL = None
_HOUSE_FUTURE = None
SLOW_PHASE_S = 30


def _slow_phase(name, t0):
    """a tick phase on the main thread that took > SLOW_PHASE_S is named in daemon.log (READY jobs wait for it)"""
    dt = time.time() - t0
    if dt > SLOW_PHASE_S:
        log(f"SLOW-TICK: {name} held the dispatch thread {dt:.0f} s")


def housekeeping():
    """disk give-back passes (ssh up to 30 min each, git): one background thread, so a READY job never waits for them"""
    for name, fn in (("release_src", release_src), ("release_offload", release_offload), ("release_bulk", release_bulk),
                     ("release_deep", release_deep),
                     ("stale24 sweep", stale24_sweep)):
        try:
            fn(all_jobs())
        except Exception:  # noqa: BLE001
            log(f"{name} error:\n" + traceback.format_exc())


def schedule_housekeeping():
    global _HOUSE_POOL, _HOUSE_FUTURE
    if _HOUSE_POOL is None:
        _HOUSE_POOL = ThreadPoolExecutor(max_workers=1)
    if _HOUSE_FUTURE is None or _HOUSE_FUTURE.done():
        _HOUSE_FUTURE = _HOUSE_POOL.submit(housekeeping)


def recover_jobs():
    # Historical log reads can wait on an unreachable host for minutes. They
    # must neither block live dispatch nor suppress unrelated recovery classes.
    try:
        auto_react(all_jobs())      # LOOP-AUTO: judges its own sibling / live-element rules, so it sees every job
    except Exception:  # noqa: BLE001
        log("auto_react error:\n" + traceback.format_exc())
    for recover in (reevaluate_benches, requeue_toolchain, requeue_budget,
                    requeue_hold_only, requeue_ssh_verdict, auto_requeue):
        try:
            jobs = all_jobs()
            live_blocks = {j["spec"].get("block") for j in jobs
                           if j["status"] not in TERMINAL} | closed_blocks(jobs)
            # Automatic migration of historical failures must not revive a
            # superseded route alongside an active or closed replacement.
            recover([j for j in jobs if j["status"] not in TERMINAL
                     or j["spec"].get("block") not in live_blocks])
        except Exception:
            log(f"{getattr(recover, '__name__', 'recovery')} error:\n" + traceback.format_exc())


def schedule_recovery():
    global _RECOVERY_POOL, _RECOVERY_FUTURE
    if _RECOVERY_POOL is None:
        _RECOVERY_POOL = ThreadPoolExecutor(max_workers=1)
    if _RECOVERY_FUTURE is None or _RECOVERY_FUTURE.done():
        _RECOVERY_FUTURE = _RECOVERY_POOL.submit(recover_jobs)


_POOL = None
_INFLIGHT = set()
_INFLIGHT_LOCK = threading.Lock()
# RESTART DRAIN (DAEMON-FIX2 2026-10-19): tool syncs restart the daemon several times a day (systemctl restart;
# KillMode=process).  SIGTERM used to kill the process mid-step, losing every in-memory job change made since the step
# began while the step's remote effects stayed (QXPQ-UNSTICK: a publish refresh shipped to cl/, the job kept its old plan
# -> 10 'sidecar differs' errors -> NEEDS_HUMAN).  Now SIGTERM / SIGINT / SIGHUP only set _STOP: no new step starts,
# every in-flight step runs to its end-of-step save_job, the recovery pass and a deferred record merge finish, then the
# daemon exits (systemd restarts it; the unit's TimeoutStopSec must cover the longest step).  Disk-release housekeeping
# is idempotent and is not waited for.
_STOP = threading.Event()
_STOP_SIG = []
_FUTS = {}                       # job name -> its last submitted step future


def request_stop(signum=None, _frame=None):
    """signal handler: only flags (no locks, no logging inside the handler)"""
    _STOP_SIG.append(signum)
    _STOP.set()


def drain(log_every=60.0):
    """wait until every in-flight job step, the recovery pass and a running deferred record merge are done"""
    with _INFLIGHT_LOCK:
        names = sorted(_INFLIGHT)
    log(f"DRAIN: stop requested (signal {_STOP_SIG[:1] or ['restart']}): {len(names)} in-flight step(s) finish and save "
        f"before exit: {', '.join(names[:30])}")
    t0 = time.time()
    if _POOL is not None:
        _POOL.shutdown(wait=False, cancel_futures=True)          # queued, not started steps never start
        with _INFLIGHT_LOCK:
            for n, f in list(_FUTS.items()):
                if f.cancelled():
                    _INFLIGHT.discard(n)
    futs = [f for f in (_RECOVERY_FUTURE, _DEFERRED_MERGE_FUTURE) if f is not None]
    said = t0
    while True:
        with _INFLIGHT_LOCK:
            left = sorted(_INFLIGHT)
        busy = [f for f in futs if not f.done()]
        if not left and not busy:
            break
        _STOP_DRAIN.wait(min(1.0, log_every))
        if time.time() - said >= log_every:
            said = time.time()
            log(f"DRAIN: still waiting on {len(left)} step(s) {', '.join(left[:10])}"
                + (f" + {len(busy)} background pass(es)" if busy else ""))
    log(f"DRAINED in {time.time() - t0:.0f} s: every job state saved; exiting for the restart")
    return True


_STOP_DRAIN = threading.Event()   # never set: an interruptible sleep for drain()


def _advance_and_release(name, fleet):
    try:
        advance_job(name, fleet)
    except Exception:  # noqa: BLE001
        log(f"[{name}] advance error:\n{traceback.format_exc()}")
    finally:
        with _INFLIGHT_LOCK:
            _INFLIGHT.discard(name)


def cmd_daemon(a):
    STATE.mkdir(parents=True, exist_ok=True)
    lock = open(STATE / "daemon.lock", "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        sys.exit("another closure-loop daemon holds the lock")
    lock.write(str(os.getpid()))
    lock.flush()
    DROP.mkdir(parents=True, exist_ok=True)
    global FLEET_REF
    fleet = FLEET_REF = Fleet()
    log(f"closure-loop daemon up (pid {os.getpid()}, interval {a.interval}s, state {STATE})")
    try:
        log(f"variant-keyed insertion backfill: {backfill_variants()} variants added")
    except Exception:  # noqa: BLE001
        log("backfill_variants error:\n" + traceback.format_exc())
    recon = None
    last_recon = 0.0
    import signal
    for s in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(s, request_stop)
    while not _STOP.is_set():
        t0 = time.time()
        # hourly: reconcile the shared experiment register (reconcile.py; never kills anything), in the background
        if (recon is None or recon.poll() is not None) and t0 - last_recon >= 3600:
            last_recon = t0
            out = open(STATE / "reconcile_last.json", "w")
            recon = subprocess.Popen([sys.executable, str(HERE / "reconcile.py")], stdout=out,
                                     stderr=subprocess.STDOUT)
            log("register reconcile started (hourly)")
        tick(fleet)
        _slow_phase("tick", t0)
        if _STOP.is_set():
            break
        try:
            publish_measured()
        except Exception:  # noqa: BLE001
            log("publish_measured error:\n" + traceback.format_exc())
        schedule_deferred_record_merges()
        (STATE / "heartbeat").write_text(now_iso() + "\n")
        _STOP.wait(max(5, a.interval - (time.time() - t0)))
    drain()
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(0)                     # housekeeping (idempotent disk release) is not joined


def cmd_status(a):
    status_report.print_status(all_jobs(), a, TERMINAL, host_label)
    hb = STATE / "heartbeat"
    print("heartbeat:", hb.read_text().strip() if hb.exists() else "none")


def cmd_validate(a):
    spec = json.loads(Path(a.file).read_text())
    spec, host_warns = drop_retired_hosts(spec)
    for w in host_warns:
        print(w)
    errs = validate(spec)
    if not errs:
        spec, _ = expand_benched_by(spec)
        why = bench_gate_check(spec)
        if why and spec.get("ref_tile"):
            errs.append(f"SUBMIT_LINT BENCH_REQUIRED: the loop would REFUSE this job: {why} (fix: {BENCH_GATE_FIX})")
        elif why:
            print(f"BENCH_REQUIRED WARN: {why}: the guarded auto-merge would skip this job's CLOSED")
        cs = (closed_stands_check(spec, spec.get("name")) if closed_stands_mode() != "off"
              else {"verdict": "NA"})
        if cs["verdict"] == "REFUSE" and closed_stands_mode() == "refuse":
            errs.append(f"SUBMIT_LINT CLOSED_STANDS: the loop would REFUSE this job: {cs['message']}")
        elif cs["verdict"] != "NA":
            print(f"closed-stands {cs['verdict']}: {cs.get('message', '')}")
        res = submit_check(spec)
        print(f"submit lint {res['verdict']}: {res.get('message', '')}"
              + (f" (estimate {res.get('est')} b/um, with fix {res.get('est_fix')})" if res.get("est") else ""))
        if res["verdict"] == "REFUSE":
            errs.append(f"SUBMIT_LINT FLOORPLAN_MARGIN: the loop would REFUSE this job: {res['message']}")
        elif res["verdict"] == "FIX":
            print(f"  the loop will add {res['fix']} {res['fix_env']} to the route_master stage commands at intake")
        commit = str((spec.get("source") or {}).get("commit", ""))
        g_ = submit_lint.Git(REPO)
        berrs, bwarns = bench_count.bench_lint((spec.get("stages") or {}).get("bench") or [],
                                               lambda p: g_.show(commit, p))
        for w in bwarns:
            print(f"BENCH_LINT WARN: {w}")
        errs.extend(f"SUBMIT_LINT BENCH_LINT: the loop would REFUSE this job: {x}" for x in berrs)
        need = bench_missing_paths(spec)
        if need:
            print(f"bench needs repo paths outside the source sync: the loop will add {need} to source.extra_paths "
                  f"at intake (or list them in source.extra_paths)")
    print("\n".join(errs) if errs else "OK")
    sys.exit(1 if errs else 0)


def fp_margin_time(j):
    """when the job finished FLOORPLAN_MARGIN (its event), else its last update"""
    for e in reversed(j.get("events", [])):
        if " FLOORPLAN_MARGIN" in e[:60]:
            return e.split(" ", 1)[0]
    return j.get("updated", "")


def release_route_key(j):
    """drop a FLOORPLAN_MARGIN job from its block@commit route-key list: it stopped before global placement and spent
    no route, so its requeue must not be REFUSED by MAX_ROUTES_PER_KEY"""
    keys = route_keys()
    key = f"{j['spec']['block']}@{j['spec']['source']['commit'][:12]}"
    if j["name"] in keys.get(key, []):
        keys[key] = [n for n in keys[key] if n != j["name"]]
        tmp = keys_path().with_suffix(".tmp")
        tmp.write_text(json.dumps(keys, indent=1) + "\n")
        os.replace(tmp, keys_path())


def cmd_submit_recheck(a):
    """lint-at-submit back-check: every FLOORPLAN_MARGIN job since --since with no live successor (a job of the same
    block that is not terminal, or a later CLOSED one) is re-judged by the submit lint; pin-density-only failures an
    approved automatic fix passes (forced: the measured failure outranks the lower-bound estimate) are requeued
    (--requeue: the fixed spec, spec.submit_lint recorded, named <name>-ls in the drop dir; the failed job's route-key
    slot is released, it spent no route); the rest are listed with their failing checks"""
    jobs = all_jobs()
    out = []
    for j in sorted(jobs, key=fp_margin_time):
        if j["status"] != "FLOORPLAN_MARGIN" or fp_margin_time(j) < a.since:
            continue
        blk = j["spec"].get("block")
        succ = [x["name"] for x in jobs if x["name"] != j["name"] and x["spec"].get("block") == blk
                and (x["status"] not in TERMINAL or (x["status"] in ("CLOSED", "SMOKE_OK")
                                                     and x.get("created", "") > j.get("created", "")))]
        reason = j.get("reason") or ""
        checks = sorted({part.split(":", 1)[0].strip() for part in reason.split(" | ") if ":" in part})
        spec = j.get("spec_submitted", j["spec"])
        try:
            rec = submit_lint.util_record(spec, reason, submit_lint.Git(REPO), j["name"])
            if rec:
                util_db_add(*rec)
        except Exception:  # noqa: BLE001
            pass
        if succ:
            out.append(f"SUCCESSOR {j['name']}: {','.join(checks)} -> live successor {', '.join(succ[:3])}")
            continue
        pin_only = checks == ["pin_density"]
        res = submit_check(spec, force=pin_only)
        est = f" est {res.get('est')} with fix {res.get('est_fix')}" if res.get("est") else ""
        if pin_only and res["verdict"] == "FIX":
            new = (j["name"][:92] + "-ls")
            line = f"REQUEUE {j['name']} -> {new}: pin density only, fix {res['fix']} {res['fix_env']}{est}"
            if a.requeue:
                nspec = submit_lint.apply_fix(spec, res, now_iso())
                nspec["name"] = new
                nspec["submit_lint"]["requeued_from"] = j["name"]
                release_route_key(j)
                DROP.mkdir(parents=True, exist_ok=True)
                (DROP / f"{new}.json").write_text(json.dumps(nspec, indent=1) + "\n")
            out.append(line)
        else:
            what = ("pin density only; " if checks == ["pin_density"] else "") + f"submit lint {res['verdict']}"
            out.append(f"LIST {j['name']} [{blk}]: {','.join(checks) or '?'}: {reason[:220]} || {what}: "
                       f"{res.get('message', '')[:400]}{est}")
    text = "\n".join(out)
    print(text)
    if a.log:
        append_locked(Path(a.log), "".join(f"{now_iso()} [lint-at-submit recheck] {x}\n" for x in out))


# RETRY OF A FLOORPLAN_MARGIN JOB (flowfix 2026-10-13).  A job the floorplan / textbook lint stopped could not be retried
# after the LINT was fixed (qfd_sp_res_ser-c1: the cluster utilisation rule changed, the job had to be re-dropped under a
# new name).  `retry` now re-runs both lints with the CURRENT tools (origin/main's fp_margin_lint.py / textbook_lint.py,
# as the loop ships them) on the geometry dump and synthesis netlist the stopped stage left on its host, with the job's
# own thresholds (spec fp_lint / textbook_lint) and the current loop mode.  PASS -> the job is requeued from the stopped
# stage and its block@commit route slot is released (it spent no route); FAIL -> it stays FLOORPLAN_MARGIN and the new
# lint text is printed.  No dump left (run released / deleted): refused unless --force (the stage then starts over and
# the in-flow lint, shipped from main, judges again).
FP_RELINT_TOOLS = ("tools/fp_margin_lint.py", "tools/textbook_lint.py")


def fp_margin_relint(j):
    """(verdict, text): PASS | FAIL | ERROR | NODUMP for a FLOORPLAN_MARGIN job, judged with the current lint tools"""
    import base64
    host, run, tag_ = j.get("host"), j.get("run"), j.get("stage_tag") or "retry"
    if not host or not run:
        return "NODUMP", "the job has no host / run directory"
    d = f"{run}/cl/fplint/{tag_}/relint"
    script = f"set -u\nD={shlex.quote(d)}; rm -rf $D; mkdir -p $D || exit 9\n"
    for rel in FP_RELINT_TOOLS:
        try:
            data = _ovl_resolve(rel)[0]
        except Exception:  # noqa: BLE001  (resolver / git trouble: the daemon tree's copy)
            data = (HERE.parents[1] / rel).read_bytes()
        script += f"base64 -d > $D/{Path(rel).name} <<'OT_B64_EOF'\n{base64.encodebytes(data).decode()}OT_B64_EOF\n"
    cfg = textbook_cfg(j)
    script += (
        f"printf '%s\\n' {shlex.quote(json.dumps(cfg))} > $D/textbook_cfg.json\n"
        f"DUMP=$(find {shlex.quote(run)} -name fp_margin_lint_dump.json -not -path '*/relint/*' -printf '%T@ %p\\n' "
        f"2>/dev/null | sort -n | tail -1 | cut -d' ' -f2-)\n"
        "[ -n \"$DUMP\" ] || { echo RELINT_NODUMP; exit 0; }\n"
        "echo \"RELINT_DUMP=$DUMP\"\n"
        f"python3 $D/fp_margin_lint.py check \"$DUMP\" --out $D/fp_margin_lint.json {gate_args(j['spec'].get('fp_lint', True))} 2>&1; "
        "echo \"RELINT_FP_RC=$?\"\n")
    if cfg.get("mode") != "off":
        script += (
            "RD=$(dirname \"$DUMP\"); RES=${RD/\\/reports\\//\\/results\\/}; NET=\n"
            "for f in $RES/1_2_yosys.v $RES/1_synth.v $RD/textbook_netlist.v; do [ -s $f ] && { NET=$f; break; }; done\n"
            "if [ -n \"$NET\" ]; then timeout 1800 python3 $D/textbook_lint.py check --netlist $NET --dump \"$DUMP\" "
            "--out $D/textbook_lint.json --cfg $D/textbook_cfg.json 2>&1; echo \"RELINT_TB_RC=$?\"; "
            "else echo RELINT_TB_RC=nonetlist; fi\n")
    try:
        r = ssh(host, script, timeout=2400)
    except Exception as ex:  # noqa: BLE001
        return "ERROR", f"{host} not reachable: {type(ex).__name__}: {str(ex)[:160]}"
    out = r.stdout or ""
    if "RELINT_NODUMP" in out:
        return "NODUMP", f"no fp_margin_lint_dump.json under {host}:{run} (run released or deleted)"
    kv = dict(re.findall(r"^(RELINT_[A-Z_]+)=(\S+)", out, re.M))
    lines = [ln for ln in out.splitlines() if ln.startswith(("fp_margin_lint:", "FLOORPLAN_MARGIN:", "TEXTBOOK_LINT:",
                                                             "textbook_lint: REFUSE"))]
    fp_rc, tb_rc = kv.get("RELINT_FP_RC"), kv.get("RELINT_TB_RC", "0")
    fails = [ln for ln in lines if ln.startswith(("FLOORPLAN_MARGIN:", "TEXTBOOK_LINT:"))]
    if fp_rc == "3" or tb_rc == "3":
        return "FAIL", " || ".join(fails or lines)[:1500]
    if fp_rc != "0" or tb_rc not in ("0", "nonetlist"):
        return "ERROR", (f"lint tool error (fp rc {fp_rc}, textbook rc {tb_rc}; rc {r.returncode}): "
                         + (out[-400:] or (r.stderr or "")[-400:]).replace("\n", " | "))
    head = next((ln for ln in lines if ln.startswith("fp_margin_lint:")), "fp_margin_lint: PASS")
    return "PASS", head[:300] + ("" if tb_rc == "0" else "; textbook lint not re-run (no netlist kept)" if cfg.get("mode") != "off" else "")


@locked_job_command
def cmd_retry(a):
    j = load_job(a.name)
    if j["status"] not in ("NEEDS_HUMAN", "NEEDS_BUDGET", "PREROUTE_MARGIN", "FLOORPLAN_MARGIN", *EARLY_FAIL):
        sys.exit(f"{a.name} is {j['status']}; only NEEDS_HUMAN / NEEDS_BUDGET / PREROUTE_MARGIN / FLOORPLAN_MARGIN / "
                 f"EARLY_FAIL_* jobs can be retried")
    if j["status"] == "FLOORPLAN_MARGIN":
        v, text = fp_margin_relint(j)
        if v == "FAIL":
            sys.exit(f"{a.name}: still FLOORPLAN_MARGIN with the current lint, not requeued: {text}")
        if v == "ERROR" or (v == "NODUMP" and not getattr(a, "force", False)):
            sys.exit(f"{a.name}: floorplan lint not re-run ({text}); not requeued"
                     + (" -- `retry --force` starts the stage over (the in-flow lint, shipped from main, judges again)"
                        if v == "NODUMP" else ""))
        release_route_key(j)      # it stopped before global placement: its requeue is not a second route of the key
        event(j, "human retry of FLOORPLAN_MARGIN: " + (f"lint re-run with the current tools PASS ({text})" if v == "PASS"
                                                        else f"--force, {text}"))
    if j["status"] == "NEEDS_BUDGET" and j.get("budget"):
        j["budget"]["override"] = "human retry after NEEDS_BUDGET"
        j["spec"].setdefault("budget", {})["on_deviation"] = "continue"
        j["stage_idx"] += 1           # the calibration is kept: continue after it, on the sheet SDC
    if getattr(a, "replay_frozen_helpers", False):
        if not j.get("route_overlay_plan"):
            sys.exit(f"{a.name}: --replay-frozen-helpers needs a frozen route_overlay_plan")
        j["replay_frozen_helpers"] = dict(at=now_iso(), by="human retry")
        event(j, "human retry: replay the gate-frozen helper bytes (FROZEN-REPLAY)")
    if getattr(a, "at", None):        # resume at a named stage (e.g. verdict: the evidence of the failed stage is valid)
        stl = stage_list(j["spec"])
        idx = [i for i, s in enumerate(stl) if s["key"] == a.at]
        if not idx:
            sys.exit(f"{a.name}: no stage {a.at} (stages: {' '.join(s['key'] for s in stl)})")
        j["stage_idx"], j["stage_key"] = idx[0], a.at
    synchronized = bool(j.get("commit_full")) and j.get("source_synced") is not False
    # FRESH-RETRY (drive-0849 2026-10-10): a released / cleaned-up job (deep release, disk cleanup) has no src/ left but
    # still reads source_synced; seven PINFLOP-REF requeues then died rc=127 "route_mtp.sh: No such file" twice.  A human
    # retry re-syncs the snapshot (sync_source re-extracts in place; cheap when it is intact).
    if not getattr(a, "keep_resume", False):
        synchronized = False
    retry_status = ("READY" if synchronized else "SYNC") if j.get("host") else "QUEUED"
    j["status"], j["retries_used"], j["attempt"] = retry_status, 0, j["attempt"] + 1
    j["errors"] = []
    # FRESH-RETRY (drive-0849 2026-10-10): a human retry re-runs the stage from scratch (retry_aside moves the old
    # output aside).  A stale HOLD-STOP "resume" (+ its OT_HOLD_STOP buffer caps) from an earlier attempt survived the
    # retry: qfd_emb_far92_rxp_b's PINFLOP-REF requeue would have resumed the 10-09 3_place checkpoint under the old IO
    # reference.  --keep-resume keeps both.
    if not getattr(a, "keep_resume", False):
        for k in ("resume", "hold_stop"):
            if j.get(k):
                event(j, f"human retry: dropped the previous attempt's {k} ({str(j[k])[:160]})")
                j.pop(k, None)
    # 2026-10-08: a bench track pinned to an artifact run on another host (bench_location) outlives that run when a
    # purge or move deletes it -- every bench launch then failed 'No such file' until 10 loop errors.  A retry restarts
    # the unfinished benches on the job's own run.
    if j.get("bench_location") and j["bench_location"].get("run") != j.get("run"):
        j.pop("bench_location", None)
        j["btrack"] = {k: v for k, v in (j.get("btrack") or {}).items() if v.get("state") == "done"}
    event(j, "human retry: re-queued from stage " + str(j.get("stage_key")))
    save_job(j)
    ledger(j, "RETRY (human) from stage " + str(j.get("stage_key")))


@locked_job_command
def cmd_bench_rebind(a):
    """Recover the reviewed path-string bench bug without re-syncing or re-routing."""
    from bench_rebind import command
    try:
        command(sys.modules[__name__], a)
    except (ValueError, OSError, subprocess.SubprocessError) as exc:
        sys.exit(str(exc))


@locked_job_command
def cmd_ioref_rejudge(a):
    """human (FLOW-IOREF): re-judge a NEEDS_RTL job at its ROUTED insertion (routed_ioref re-STA, no re-route).  Closes
    -> back to the verdict stage (READY; the cached re-STA is the verdict).  Hold-only at the routed reference with no
    ECO tried yet -> verdict stage too (the post-route hold ECO then runs with io_ref_routed.sdc).  Prints one line."""
    j = load_job(a.name)
    m = dict(j.get("metrics") or {})
    if j["status"] not in ("NEEDS_RTL", "NEEDS_HUMAN") or not m.get("orfs_dir"):
        print(f"SKIP {a.name}: {j['status']}, orfs_dir {m.get('orfs_dir')}")
        return
    if (j.get("eco") or {}).get("installed"):
        print(f"SKIP {a.name}: an installed ECO replaced the route")
        return
    ss0, ff0 = m.get("route_sdc_clock", {}).get("ss_ps", m.get("ss_ps")), m.get("route_sdc_clock", {}).get("ff_ps", m.get("ff_ps"))
    m["ss_ps"], m["ff_ps"] = ss0, ff0
    rr = routed_ioref(j, m)
    drc, failed = m.get("drc"), j.get("failed_checks") or []
    if not rr or not rr.get("available"):
        save_job(j)
        print(f"NOREF {a.name}: {(rr or {}).get('why')}")
        return
    closes = rr["tt"] >= SS_MIN and rr["ff"] >= FF_MIN and drc == 0 and not failed
    holdonly = rr["tt"] >= SS_MIN and rr["ff"] < FF_MIN and drc == 0 and not failed and not (j.get("eco") or {}).get("tried")
    refs = {c: ", ".join(f"{v} {d['mean']:.0f}" for v, d in rr["ioref"].get(c, {}).items()) for c in ("tt", "ff")}
    line = (f"{a.name}: route SDC TT {ss0} / FF {ff0} -> routed ref TT {rr['tt']:+.2f} / FF {rr['ff']:+.2f} DRC {drc} "
            f"(FF ref {refs['ff']}; TT ref {refs['tt']})")
    if closes or holdonly:
        stl = stage_list(j["spec"])
        vidx = next(i for i, x in enumerate(stl) if x["kind"] == "verdict")
        j.update(status="READY", stage_idx=vidx, stage_key="verdict", retries_used=0, errors=[], reason=None)
        event(j, f"FLOW-IOREF re-judge: {line} -> {'CLOSES' if closes else 'hold-only: ECO at the routed reference'}")
        ledger(j, f"RE-JUDGE at the routed insertion (no re-route): {line}")
    save_job(j)
    print(("FLIP " if closes else "HOLDONLY " if holdonly else "STILL ") + line)


@locked_job_command
def cmd_rebudget_rejudge(a):
    """human / tools/budgets/rebudget.py (REBUDGET 2026-10-08): re-judge a NEEDS_RTL job whose internal paths pass, with
    its RE-DERIVED IO budget (budget_rb<N> SDC: real die links, real block needs) appended after io_ref_routed.sdc in the
    routed re-STA -- no re-route.  Closes -> back to the verdict stage (READY; the cached re-STA is the verdict, the
    record cites budget_rb<N>); hold-only at the new budget with no ECO tried -> verdict stage too (post-route hold ECO);
    else it stays NEEDS_RTL with the result recorded under j["rebudget"].  --dry: re-STA only, the job is not changed."""
    j = load_job(a.name)
    m = dict(j.get("metrics") or {})
    if j["status"] not in ("NEEDS_RTL", "NEEDS_HUMAN") or not m.get("orfs_dir"):
        print(f"SKIP {a.name}: {j['status']}, orfs_dir {m.get('orfs_dir')}")
        return
    if (j.get("eco") or {}).get("installed"):
        print(f"SKIP {a.name}: an installed ECO replaced the route")
        return
    sdc = Path(a.sdc).resolve()
    if not sdc.is_file():
        print(f"SKIP {a.name}: no SDC {sdc}")
        return
    old_rb, old_rr = j.get("rebudget"), j.get("routed_ioref")
    j["rebudget"] = dict(rb=a.rb, sdc=str(sdc), at=now_iso())
    ss0 = m.get("route_sdc_clock", {}).get("ss_ps", m.get("ss_ps"))
    ff0 = m.get("route_sdc_clock", {}).get("ff_ps", m.get("ff_ps"))
    m["ss_ps"], m["ff_ps"] = ss0, ff0
    rr = routed_ioref(j, m)
    drc, failed = m.get("drc"), j.get("failed_checks") or []
    if not rr or not rr.get("available"):
        print(f"NOREF {a.name}: {(rr or {}).get('why')}")
        if not a.dry:
            j["rebudget"]["result"] = dict(available=False, why=(rr or {}).get("why"))
            save_job(j)
        return
    closes = rr["tt"] >= SS_MIN and rr["ff"] >= FF_MIN and drc == 0 and not failed
    holdonly = rr["tt"] >= SS_MIN and rr["ff"] < FF_MIN and drc == 0 and not failed and not (j.get("eco") or {}).get("tried")
    line = (f"{a.name}: route IO TT {ss0} / FF {ff0} -> {a.rb} TT {rr['tt']:+.2f} / FF {rr['ff']:+.2f} DRC {drc} "
            f"(TT i2r {rr.get('tt_i2r')} out {rr.get('tt_out')}; FF i2r {rr.get('ff_i2r')} out {rr.get('ff_out')} r2r {rr.get('ff_r2r')})")
    tag = "FLIP " if closes else "HOLDONLY " if holdonly else "STILL "
    if a.dry:
        print("DRY " + tag + line)
        return
    j["rebudget"]["result"] = dict(available=True, tt=rr["tt"], ff=rr["ff"], closes=closes, holdonly=holdonly)
    if closes or holdonly:
        stl = stage_list(j["spec"])
        vidx = next(i for i, x in enumerate(stl) if x["kind"] == "verdict")
        j.update(status="READY", stage_idx=vidx, stage_key="verdict", retries_used=0, errors=[], reason=None)
        event(j, f"REBUDGET re-judge under {a.rb} (re-derived die-link IO budget, no re-route): {line} -> "
                 f"{'CLOSES' if closes else 'hold-only: ECO at the new budget'}")
        ledger(j, f"RE-JUDGE under {a.rb} (re-derived die-link IO budget, no re-route): {line}")
    else:
        event(j, f"REBUDGET re-judge under {a.rb}: {line} -> still failing (stays NEEDS_RTL)")
    save_job(j)
    print(tag + line)


@locked_job_command
def cmd_reverdict(a):
    """human: re-judge a NEEDS_RTL / NEEDS_HUMAN job on its recorded evidence after an acceptance-line change, no re-route.
    Route sign-off meets the line -> back to the verdict stage (READY).  Else an earlier hold ECO whose recorded result
    meets the line but was not installed -> re-enter the ECO completion on the existing ECO output (status ECO; its
    result.json is re-read and judged by eco_passes, then installed and re-verdicted as usual)."""
    j = load_job(a.name)
    if j["status"] not in ("NEEDS_RTL", "NEEDS_HUMAN"):
        sys.exit(f"{a.name} is {j['status']}")
    m, e = j.get("metrics") or {}, j.get("eco") or {}
    stl = stage_list(j["spec"])
    vidx = next(i for i, x in enumerate(stl) if x["kind"] == "verdict")
    if j.get("failed_checks") and getattr(a, "recheck", False):
        # a verdict CHECK was fixed (e.g. LOOP-CORNER TT+SS warn): re-run the verdict stage, which re-runs every check
        # live on the recorded route and then takes the normal path (closed / hold ECO / NEEDS_RTL)
        how = f"re-run verdict checks (were {j['failed_checks']}) on the recorded route"
        j.update(status="READY", stage_idx=vidx, stage_key="verdict", retries_used=0, errors=[], reason=None,
                 failed_checks=[])
        event(j, f"human re-verdict ({a.why}): {how}")
        save_job(j)
        ledger(j, f"RE-VERDICT (human, no re-route): {a.why}; {how}")
        return
    if j.get("failed_checks"):
        sys.exit(f"{a.name}: verdict checks failed {j['failed_checks']}: not a line-only miss (--recheck re-runs them)")
    if eco_passes(dict(m, errors=[]), 0):
        j.update(status="READY", stage_idx=vidx, stage_key="verdict", retries_used=0, errors=[], reason=None)
        how = f"route sign-off {setup_corner_label(m)} {m.get('ss_ps')} / FF {m.get('ff_ps')} / DRC {m.get('drc')}"
    elif e.get("tried") and not e.get("installed") and eco_passes(e.get("result"), 0):
        r = ssh(j["host"], f"ls -t {j['run']}/cl/hold_eco.*.rc 2>/dev/null | head -1", timeout=60)
        rc_file = r.stdout.strip()
        if not rc_file:
            sys.exit(f"{a.name}: no hold_eco rc file under {j['run']}/cl")
        j.update(status="ECO", stage_idx=vidx, stage_key="hold_eco", stage_tag=Path(rc_file).name[:-3], retries_used=0,
                 errors=[], reason=None)
        how = f"recorded hold-ECO result {e.get('result')} ({j['stage_tag']})"
    else:
        sys.exit(f"{a.name}: recorded evidence does not meet {setup_corner_label(m)} >= {SS_MIN:g} / FF >= {FF_MIN:g} / DRC 0 "
                 f"(route {m.get('ss_ps')}/{m.get('ff_ps')}/{m.get('drc')}; eco {e.get('result')})")
    event(j, f"human re-verdict ({a.why}) at the line {setup_corner_label(m)} >= {SS_MIN:g} / FF >= {FF_MIN:g} / DRC 0 on {how}")
    save_job(j)
    ledger(j, f"RE-VERDICT (human, no re-route): {a.why}; {how}")


@locked_job_command
def cmd_retry_eco(a):
    """human: re-run the post-route hold ECO (current hold_eco rev) on a NEEDS_RTL job whose only miss was hold and whose
    earlier ECO missed; the earlier ECO is kept in eco_history and its output dir is preserved (new out: cl/eco-r<n>)."""
    j = load_job(a.name)
    e, m = j.get("eco") or {}, j.get("metrics") or {}
    if getattr(a, "stack", False):
        # DRIVE-1243: an INSTALLED ECO judged at a stale IO reference (the routed-insertion re-STA, e.g. after the
        # c4ffc4f9d vclk mapping, fails it on hold only): a second ECO on top of the installed db, at the routed reference
        if j["status"] != "NEEDS_RTL" or not e.get("installed"):
            sys.exit(f"{a.name}: --stack needs a NEEDS_RTL job with an installed ECO")
        j["eco_stack"] = dict(base=e["rb"], prior_out=e.get("out"), at=now_iso())
    elif j["status"] != "NEEDS_RTL" or not e.get("tried") or e.get("installed"):
        sys.exit(f"{a.name}: {j['status']}, eco tried={e.get('tried')} installed={e.get('installed')}: "
                 f"only a NEEDS_RTL job with an uninstalled, missed hold ECO can re-run it")
    if stage_list(j["spec"])[j["stage_idx"]]["kind"] != "verdict":
        sys.exit(f"{a.name}: not at its verdict stage")
    if not (m.get("ss_ps") is not None and m["ss_ps"] >= SS_MIN and m.get("drc") == 0 and m.get("ff_ps") is not None
            and m["ff_ps"] < FF_MIN):
        sys.exit(f"{a.name}: route verdict {setup_corner_label(m)} {m.get('ss_ps')} / FF {m.get('ff_ps')} / DRC {m.get('drc')} is not hold-only")
    j.setdefault("eco_history", []).append(e)
    j["eco"] = {}
    j.update(status="READY", stage_key="verdict", attempt=j["attempt"] + 1, retries_used=0, errors=[],
             reason=f"human retry-eco: {a.why}")
    event(j, f"human retry-eco ({a.why}): re-judged at the verdict; earlier ECO kept in eco_history")
    save_job(j)
    ledger(j, f"RETRY-ECO (human, hold_eco rev 2): {a.why}; earlier ECO {e.get('out')} -> {e.get('result')} kept")


@locked_job_command
def cmd_cancel(a):
    j = load_job(a.name)
    if j["status"] in TERMINAL:
        sys.exit(f"{a.name} already {j['status']}")
    why = getattr(a, "why", None)
    if why:
        event(j, f"cancel requested: {why}")
    j.update(status="CANCELLED", reason="cancelled by a human" + (f" ({why[:300]})" if why else ""), cancelled_at=now_iso())
    save_job(j)                 # durable even if the remote stop or experiment register fails
    if j.get("stage_tag") and j.get("host"):
        run, t = j["run"], j["stage_tag"]
        # only this loop's own stage process group, and only containers that mount this job's own run dir
        ssh(j["host"], f"""p=$(cat {run}/cl/{t}.pid 2>/dev/null); [ -n "$p" ] && kill -TERM -- -$p 2>/dev/null
for c in $(docker ps -q); do {DIE_CONTAINER_SKIP}docker inspect --format '{{{{range .Mounts}}}}{{{{.Source}}}} {{{{end}}}}' $c | grep -q '{run}/' && docker stop -t 5 $c; done; true""",
            timeout=180)
    finish(j, "CANCELLED", j["reason"], "CANCELLED by a human" + (f": {why}" if why else ""))
    save_job(j)


def early_fail_finish(j, verdict, why, detail=None):
    """Stop a hopeless route (stuckscan gates): kill this job's own stage (and parallel tracks), record the diagnosis
    (STATE/early_fail/<name>.json, {CL}/early_fail.json) and end the job with the EARLY_FAIL_* verdict; failtrig/scan.py
    reports it as redesign work."""
    kill_own_stage(j)
    j["early_fail"] = dict(verdict=verdict, why=why, at=now_iso(), detail=detail or {})
    if j.get("host") and j.get("run") and detail:
        ssh(j["host"], f"cat > {j['run']}/cl/early_fail.json", input=json.dumps(detail, indent=1), timeout=60)
    paths = "\n".join(f"  {p.get('slack_ps')} ps {p.get('cls')} {p.get('dominated')}-dominated (wire {p.get('wire_ps')} / "
                      f"cell {p.get('cell_ps')} ps, fanout {p.get('max_fanout')}) {p.get('start')} -> {p.get('end')}"
                      for p in (detail or {}).get("paths", [])[:6])
    finish(j, verdict, why[:600], f"{verdict}: {why}" + (f"\nworst paths per group (post-CTS/placement report):\n{paths}"
                                                        if paths else ""))


@locked_job_command
def cmd_early_fail(a):
    j = load_job(a.name)
    if j["status"] != "RUNNING":
        sys.exit(f"{a.name} is {j['status']}, not RUNNING")
    if a.verdict not in EARLY_FAIL:
        sys.exit(f"verdict must be one of {EARLY_FAIL}")
    detail = json.loads(Path(a.detail).read_text()) if a.detail else None
    early_fail_finish(j, a.verdict, a.why, detail)
    save_job(j)

# HOLD-STOP (drive-resume 2026-10-09, coordinator APPROVED): a CTS / GRT hold repair that stalls already within a small
# margin (real FF hold WNS >= stuckscan.GATES["hold_nearmiss_ps"], -15 ps; setup gate not firing) is NOT early-failed.
# repair_timing cannot be stopped in-process, so the loop stops the stage and resumes the route from its ORFS checkpoint
# (OT_CL_RESUME=1, same host / run dir) with OT_HOLD_STOP="<stage>:<buffers>": that stage's hold repair replays up to the
# buffer count at which the stalled run reached its final WNS, then the flow continues to route; a later GRT hold repair
# is skipped (grt:0) after a CTS stop, so the flat tail cannot recur there.  The post-route hold ECO repairs the residue.
# A stage is stopped at most once per job (a second near-miss stall on the same stage early-fails as before).
HOLD_STOP_ALLOW = {"cts": "4_1_cts", "grt": "5_1_grt"}


def hold_stop_resume(j, stage, buffers, why):
    """stop the job's route stage (if running) and re-queue it as a same-host checkpoint resume with OT_HOLD_STOP"""
    if stage not in HOLD_STOP_ALLOW:
        raise ValueError(f"hold-stop stage must be one of {sorted(HOLD_STOP_ALLOW)}")
    if any(x.get("stage") == stage for x in j.get("hold_stop_log") or []):
        raise ValueError(f"{j['name']}: its {stage} hold repair was already stopped once")
    stl = stage_list(j["spec"])
    if stl[j["stage_idx"]]["kind"] != "route":
        raise ValueError(f"{j['name']}: stage {stl[j['stage_idx']]['key']} is not a route stage")
    host, run = j["host"], j["run"]
    if j["status"] == "RUNNING":
        kill_own_stage(j)
        for _ in range(30):
            r = ssh(host, f"for c in $(docker ps -q); do docker inspect --format '{{{{range .Mounts}}}}{{{{.Source}}}} {{{{end}}}}' $c "
                          f"| grep -q '{run}/' && echo BUSY; done; true", timeout=120)
            if "BUSY" not in r.stdout:
                break
            time.sleep(10)
    ship_helpers(host, run, j)
    r = ssh(host, f"cd {run}/src && python3 {run}/cl/resume_patch.py .", timeout=120)
    if r.returncode:
        raise RuntimeError(f"resume patch failed: {(r.stdout + r.stderr)[-400:]}")
    dm = subst(j["spec"].get("verdict", {}).get("drc_metrics", ""), j)
    orfs = dm.split("/logs/")[0] if "/logs/" in dm else None
    if not orfs:
        raise RuntimeError("hold-stop resume: no ORFS checkpoint path (verdict.drc_metrics)")
    chk = ssh(host, f"O=$(ls -d {orfs} | tail -1); bash {run}/cl/resume_check.sh $O {run}/src {HOLD_STOP_ALLOW[stage]}",
              timeout=600)
    if chk.returncode or not re.search(r"^RESUME_OK=1$", chk.stdout, re.M):
        raise RuntimeError(f"hold-stop resume check failed rc={chk.returncode}: {(chk.stdout + chk.stderr)[-400:]}")
    hs = dict(j.get("hold_stop") or {})
    hs[stage] = int(buffers)
    if stage == "cts":
        hs.setdefault("grt", 0)
    j["hold_stop"] = hs
    j.setdefault("hold_stop_log", []).append(dict(stage=stage, buffers=int(buffers), why=why[:600], at=now_iso(),
                                                  attempt=j["attempt"] + 1, prev_status=j["status"]))
    j["resume"] = dict(from_host=host, to_host=host, run=run, at=now_iso(), kind="hold_stop",
                       check=chk.stdout.strip()[-400:])
    j["checkpoint_affinity"] = dict(host=host, run=run)
    j.pop("early_fail", None)
    j.update(status="READY", attempt=j["attempt"] + 1, wait=None, errors=[], reason=None)
    stage_txt = " ".join(f"{k}:{v}" for k, v in sorted(hs.items()))
    event(j, f"HOLD-STOP {stage}: near-miss hold stall, not early-failed; route resumes from its checkpoint with "
             f"OT_HOLD_STOP='{stage_txt}' ({why[:300]})")
    ledger(j, f"HOLD-STOP {stage} ({stage_txt}): {why}")
    experiment(j, f"running: route resumed from checkpoint, hold repair stopped at {stage}")


@locked_job_command
def cmd_hold_stop(a):
    """stuckscan / human: stop a near-miss stalled CTS/GRT hold repair and resume the route (hold_stop_resume).  Accepts a
    RUNNING route or an EARLY_FAIL_HOLD job whose run dir still holds its checkpoint."""
    j = load_job(a.name)
    if j["status"] not in ("RUNNING", "EARLY_FAIL_HOLD"):
        sys.exit(f"{a.name} is {j['status']}: hold-stop needs RUNNING or EARLY_FAIL_HOLD")
    hold_stop_resume(j, a.stage, a.buffers, a.why)
    save_job(j)
    print(f"HOLD-STOP {a.name} {a.stage}:{a.buffers} -> READY (attempt {j['attempt']})")


@locked_job_command
def cmd_kill_stage(a):
    """stuckscan: kill a hung / stalled stage of a RUNNING job (its own process group, and the flow containers mounting
    --orfs, else every container of its run dir).  The loop then sees the stage LOST and retries it once (crash path)."""
    j = load_job(a.name)
    if j["status"] != "RUNNING" or not (j.get("stage_tag") and j.get("host")):
        sys.exit(f"{a.name} is {j['status']}: no running stage to kill")
    run, t = j["run"], j["stage_tag"]
    pat = shlex.quote((a.orfs.rstrip("/") + ":") if a.orfs else (run + "/"))
    ssh(j["host"], f"""p=$(cat {run}/cl/{t}.pid 2>/dev/null); [ -n "$p" ] && kill -TERM -- -$p 2>/dev/null
for c in $(docker ps -q); do {DIE_CONTAINER_SKIP}docker inspect --format '{{{{range .Mounts}}}}{{{{.Source}}}}:{{{{.Destination}}}} {{{{end}}}}' $c | grep -qF {pat} && docker stop -t 5 $c; done; true""",
        timeout=300)
    j["stuck_kill"] = dict(at=now_iso(), why=a.why, tag=t)
    event(j, f"stage {t} killed by stuckscan ({a.why[:300]}); the loop retries it once")
    ledger(j, f"STUCK-KILL {t}: {a.why}")
    save_job(j)


def validate_overlay_recovery(j):
    expected_failure = dict(ss_ps=-340500.58, ff_ps=-59.43, drc=0, cells_added=0, errors=[])
    expected_pre = dict(ss_ps=190.49, ff_ps=-70.99)
    e = j.get("eco") or {}
    m = j.get("metrics") or {}
    if (j["name"] != "hbglue_cl_8ddc70024" or j.get("commit_full") != "8ddc7002479798a1e3d5ce5875a163d672973e75"
            or j["spec"]["source"]["commit"] != j["commit_full"] or j["status"] != "NEEDS_RTL"
            or j.get("attempt") != 1 or j.get("eco_overlay_recovery") or j.get("eco_history")
            or e.get("installed") or e.get("post_sdc") or not e.get("tried")
            or e.get("result") != expected_failure or e.get("pre") != expected_pre
            or {k: m.get(k) for k in expected_pre} != expected_pre or m.get("drc") != 0
            or m.get("errors") or j.get("failed_checks") or j["spec"]["verdict"].get("post_sdc")
            or m.get("post_sdc") != ["physical/s81_die_views/hbglue/margin/signoff_cl_hbglue_cl_8ddc70024.sdc"]
            or stage_list(j["spec"])[j["stage_idx"]]["kind"] != "verdict"):
        raise ValueError("not the explicitly authorized, uninstalled hbglue missing-overlay ECO failure")


@locked_job_command
def cmd_recover_eco_overlays(a):
    j = load_job(a.name)
    validate_overlay_recovery(j)
    pinned = json.loads((HERE / "evidence/reliability_20261006.json").read_text())["original_hbglue_hashes_verified"]
    request = dict(job=j, original_hashes={k: pinned[k] for k in ("odb", "spef", "sdc")},
                   post_sdc_hashes={j["metrics"]["post_sdc"][0]: pinned["post_sdc"]})
    r = ssh(j["host"], "python3 - prepare " + shlex.quote(json.dumps(request)),
            input=(HERE / "eco_recovery.py").read_text(), timeout=120, check=True)
    recovery = json.loads(r.stdout)
    recovery.update(requested=now_iso(), reason="owner-authorized one-shot correction of omitted measured overlays")
    j["eco_overlay_recovery"] = recovery
    j.setdefault("eco_history", []).append(j["eco"])
    j["eco"] = {}              # only this named job's verdict can request one new ECO
    j.update(status="READY", stage_key="verdict", attempt=2, errors=[], reason="explicit ECO overlay recovery queued")
    event(j, f"one-shot ECO overlay recovery queued: {recovery['out']}; original failure and inputs preserved")
    save_job(j)
    ledger(j, f"ECO overlay recovery requested; original failed ECO retained; admission at verdict; {recovery['out']}")


@locked_job_command
def cmd_recover_export_lint(a):
    """Attach an explicit main-pinned lint-only recovery, leaving retry to the operator."""
    import base64
    from export_lint_recovery import eligible
    j = load_job(a.name)
    evidence = None
    try:
        eligible(j)
    except ValueError as exc:
        if str(exc) != 'no recorded PG lint collection failure':
            raise
        probe = ("import hashlib,json,pathlib; "
                 "ps=[p for p in pathlib.Path(" + repr(j['run']) + ").glob('record/views/**/provenance/abstract_pin_stub.json') "
                 "if p.parent.parent.name==" + repr(j['spec']['block']) + "]; "
                 "print(json.dumps([dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),"
                 "child_lint=json.loads(p.read_text()).get('child_lint',{})) for p in ps]))")
        r = ssh(j['host'], 'python3 -c ' + shlex.quote(probe), timeout=60, check=True)
        records = json.loads(r.stdout)
        if len(records) != 1:
            raise ValueError('expected one retained structured lint receipt')
        evidence = records[0]
        eligible(j, evidence)
    head = _ovl_head()
    rel = "tools/hier_contract/child_lint.py"
    data = subprocess.run(["git", "-C", str(REPO), "show", f"{head}:{rel}"],
                          capture_output=True, check=True).stdout
    request = dict(job=j, helper_commit=head, helper_b64=base64.b64encode(data).decode(),
                   helper_sha256=hashlib.sha256(data).hexdigest(),
                   guard_b64=base64.b64encode((HERE / "export_lint_recovery.py").read_bytes()).decode())
    if evidence:
        request['pg_lint_evidence'] = evidence
    r = ssh(j["host"], "python3 - prepare " + shlex.quote(json.dumps(request)),
            input=(HERE / "export_lint_recovery.py").read_text(), timeout=120, check=True)
    j["export_lint_recovery"] = dict(json.loads(r.stdout), requested=now_iso())
    event(j, f"explicit collect-only lint recovery pinned to main {head}; frozen helpers and route retained")
    save_job(j)
    print(json.dumps(j["export_lint_recovery"]))


@locked_job_command
def cmd_restore_cancelled(a):
    """Recover pre-lock cancellation lost to a stale save. Never stop remote work."""
    j = load_job(a.name)
    if j["status"] == "CANCELLED":
        return
    # Require explicit historical intent; a replacement name alone is insufficient.
    cancellations = [line for line in LEDGER.read_text().splitlines()
                     if f" | {a.name} | " in line and " | CANCELLED by a human | " in line]
    if not cancellations:
        sys.exit(f"{a.name}: no human cancellation in {LEDGER}")
    if j["status"] == "CLOSED":
        sys.exit(f"{a.name}: already CLOSED; requires parent investigation")
    archive = STATE / "cancel_recovery"
    archive.mkdir(parents=True, exist_ok=True)
    backup = archive / f"{a.name}.{time.time_ns()}.json"
    with backup.open("x") as f:
        f.write(jpath(a.name).read_text())
    j["cancel_recovery"] = dict(backup=str(backup), ledger=cancellations[-1],
                               preserved_stage={k: j.get(k) for k in
                                                ("status", "host", "run", "stage_tag", "stage_started")},
                               remote_action="none; existing processes and evidence preserved")
    j.update(status="CANCELLED", reason="restored ledger cancellation; remote work preserved", cancelled_at=now_iso())
    event(j, j["reason"])
    save_job(j)
    ledger(j, f"CANCELLED restored from ledger; no remote stop; prior state {backup}; "
              f"preserved {j.get('stage_tag')} at {j.get('host')}:{j.get('run')}")


def resume_postroute(j, to_host=None, dry=False):
    """LOST-CLOSED (ROOT-1130): put a terminal job that had a CLOSED verdict back on that closed routed state (copied
    to to_host when the host changes) at its verdict stage: the verdict re-judges the preserved route / installed ECO
    and, when it still closes, collect / export / commit run there.  Never re-routes.  Returns a one-line summary."""
    if j["status"] not in TERMINAL or j["status"] in ("CLOSED", "SMOKE_OK"):
        raise ValueError(f"{j['name']} is {j['status']}: only a terminal non-CLOSED job can be resumed")
    closed = earlier_closed(j)
    if not closed:
        raise ValueError(f"{j['name']} never had a CLOSED verdict")
    c = closed[-1]
    src_host = c["host"]
    if src_host not in {h["name"] for h in hosts_table()}:
        raise ValueError(f"closed attempt's host {src_host} is not in hosts.json")
    src_run = c.get("run") or f"{host_cfg(src_host)['base']}/{j['name']}"
    state = routed_state(j, src_host, src_run)
    if state is None:
        raise ValueError(f"{src_host} unreachable: routed state of attempt {c['attempt']} cannot be checked")
    if not state["present"]:
        raise ValueError(f"routed state of closed attempt {c['attempt']} is gone from {src_host}:{src_run}")
    eco = c.get("eco_record")
    if eco is None and not c.get("route_attempt"):
        # a record before ROOT-1130: the closing ECO is the installed one still in the job, or a retired one
        cands = [j.get("eco") or {}] + [x for r in reversed(j.get("eco_prior_routes") or []) for x in reversed(r["ecos"])]
        eco = next((x for x in cands if x.get("installed") and eco_passes(x.get("result"), x.get("rc", 0))), None)
    if eco and not state["eco_installed"]:
        raise ValueError(f"closed attempt {c['attempt']} closed with a {eco.get('kind')} ECO but {src_host}:{src_run} "
                         f"holds no installed ECO db (6_final.odb.pre_eco missing)")
    dst_host = to_host or src_host
    dst_run = src_run if dst_host == src_host else f"{run_base(dst_host)}/{j['name']}"
    what = (f"resume {j['name']} ({j['status']}) at verdict on closed attempt {c['attempt']}'s routed state "
            f"{src_host}:{src_run}" + (f" copied to {dst_host}:{dst_run}" if dst_host != src_host else "")
            + (f" with its installed {eco.get('kind')} ECO" if eco else ""))
    if dry:
        return what
    if dst_host != src_host:
        copy_routed_state(j, src_host, src_run, dst_host, dst_run)
        if eco:
            eco = json.loads(json.dumps(eco).replace(src_run, dst_run))
    stl = stage_list(j["spec"])
    j.setdefault("lost_closed_history", []).append(dict(status=j["status"], reason=j.get("reason"), at=now_iso(),
                                                        lost_closed=j.get("lost_closed")))
    if j.get("eco") and j.get("eco") is not eco:
        j.setdefault("eco_prior_routes", []).append(dict(attempt=j["attempt"], at=now_iso(), ecos=[j["eco"]]))
    j["eco"] = eco
    if not eco:
        j.pop("eco", None)
    for k in ("eco_history", "eco_stack", "reapply_eco", "lost_closed", "finished_at", "auto_react_judged", "wait",
              "routed_ioref", "src_released", "snapshot_trimmed", "deep_released", "transient", "transient_next"):
        j.pop(k, None)
    c = dict(c, route_attempt=c.get("route_attempt") or f"resumed-a{c['attempt']}", run=src_run)
    j["closed_attempts"] = [x for x in (j.get("closed_attempts") or []) if x is not closed[-1]] + [c]
    j["route_attempt"] = c["route_attempt"]
    j["hosts_tried"] = list(j.get("hosts_tried") or []) + ([dst_host] if dst_host not in (j.get("hosts_tried") or []) else [])
    j.update(host=dst_host, run=dst_run, status="SYNC", reason=None, retries_used=0, postroute_retries=0,
             attempt=j["attempt"] + 1, stage_idx=next(i for i, s in enumerate(stl) if s["kind"] == "verdict"),
             stage_key="verdict")
    event(j, "resume-postroute: " + what)
    ledger(j, "RESUME-POSTROUTE: " + what)
    return what


@locked_job_command
def cmd_resume_postroute(a):
    j = load_job(a.name)
    try:
        what = resume_postroute(j, to_host=a.to_host, dry=a.dry)
    except ValueError as ex:
        sys.exit(str(ex))
    if not a.dry:
        save_job(j)
    print(("DRY " if a.dry else "") + what)


FINISH_EVENT_RE = re.compile(r"^\S+ (NEEDS_[A-Z]+|EARLY_FAIL_[A-Z]+|LOST_CLOSED|CANCELLED|REFUSED|INVALID|"
                             r"FLOORPLAN_MARGIN|PREROUTE_MARGIN): ")


def lost_closed_scan(hours=48.0, now=None):
    """jobs finished non-CLOSED within `hours` that had an earlier CLOSED verdict, with the fate of their block and of
    their routed state: [dict(name, block, status, closed, superseded_by, state, action)]"""
    now = now or time.time()
    jobs = all_jobs()
    out = []
    for j in jobs:
        if j["status"] not in TERMINAL or j["status"] in ("CLOSED", "SMOKE_OK"):
            continue
        # the finish itself, not housekeeping (offload trim / deep release touch 'updated' for days afterwards)
        fin = next((e.split(" ", 1)[0] for e in reversed(j.get("events") or []) if FINISH_EVENT_RE.match(e)), None)
        age = _iso_age_h(j.get("finished_at") or fin or j.get("updated"), now)
        if age is None or age > hours:
            continue
        closed = earlier_closed(j)
        if not closed:
            continue
        c = closed[-1]
        blk = j["spec"].get("block")
        later = [x for x in jobs if x is not j and x["spec"].get("block") == blk and (x.get("created") or "") > (j.get("created") or "")
                 and (x["status"] == "CLOSED" or x["status"] not in TERMINAL)]
        row = dict(name=j["name"], block=blk, status=j["status"], closed=c, superseded_by=[x["name"] for x in later])
        if j["status"] == "CANCELLED":
            row["action"] = "skip: cancelled"
        elif any("superseded by a CLOSED job" in e for e in j.get("events") or []):
            row["action"] = "skip: superseded by a CLOSED job of the block"
        elif later:
            row["action"] = "skip: block has a later CLOSED / active job"
        else:
            if c["host"] not in {h["name"] for h in hosts_table()}:
                row["state"], row["action"] = None, f"closed host {c['host']} retired from hosts.json: resubmit as flow_failure"
            else:
                st = routed_state(j, c["host"], c.get("run") or f"{host_cfg(c['host'])['base']}/{j['name']}")
                row["state"] = st
                row["action"] = ("resume-postroute" if st and st["present"] else
                                 "host unreachable: retry scan" if st is None else "resubmit as flow_failure")
        out.append(row)
    return out


def cmd_lost_closed_scan(a):
    rows = lost_closed_scan(a.hours)
    for r in rows:
        c = r["closed"]
        print(f"{r['name']}  {r['status']}  closed a{c['attempt']} on {c['host']}  -> {r['action']}"
              + (f" ({', '.join(r['superseded_by'][:3])})" if r["superseded_by"] else ""))
        if a.apply and r["action"] == "resume-postroute" and r["name"] not in (a.skip or []):
            with job_lock(r["name"]):
                j = load_job(r["name"])
                try:
                    print("   " + resume_postroute(j))
                    save_job(j)
                except ValueError as ex:
                    print(f"   not resumed: {ex}")
    if a.json:
        Path(a.json).write_text(json.dumps(rows, indent=1, default=str))
    print(f"{len(rows)} job(s) with an earlier CLOSED verdict ended non-CLOSED in the last {a.hours:g} h")


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("daemon"); d.add_argument("--interval", type=int, default=60)
    sub.add_parser("tick")
    status_report.add_arguments(sub.add_parser("status", help="active jobs and recent results (--all for history)"))
    v = sub.add_parser("validate"); v.add_argument("file")
    sr = sub.add_parser("submit-recheck"); sr.add_argument("--since", required=True)
    sr.add_argument("--requeue", action="store_true"); sr.add_argument("--log")
    r = sub.add_parser("retry"); r.add_argument("name"); r.add_argument("--at", help="resume at this stage key")
    r.add_argument("--replay-frozen-helpers", action="store_true",
                   help="run with the exact helper bytes the gate froze (recovery of a helper-drift NEEDS_HUMAN)")
    r.add_argument("--keep-resume", action="store_true", help="keep a pending checkpoint resume / HOLD-STOP caps")
    r.add_argument("--force", action="store_true", help="FLOORPLAN_MARGIN job whose lint dump is gone: requeue anyway")
    r = sub.add_parser("retry-eco"); r.add_argument("name"); r.add_argument("--why", default="hold_eco rev 2")
    r.add_argument("--stack", action="store_true", help="ECO on top of an installed ECO (its db in the route base)")
    r = sub.add_parser("bench-rebind", help="reviewed path-string bench recovery; preserve the completed route")
    r.add_argument("name"); r.add_argument("--commit", required=True)
    r.add_argument("--bench", action="append", required=True, help="affected benchmark stage key; repeat as needed")
    r.add_argument("--why", required=True); r.add_argument("--apply", action="store_true", help="prepare a private source and requeue only benchmarks; default is read-only")
    r = sub.add_parser("ioref-rejudge"); r.add_argument("name")
    r = sub.add_parser("rebudget-rejudge"); r.add_argument("name"); r.add_argument("--rb", required=True)
    r.add_argument("--sdc", required=True); r.add_argument("--dry", action="store_true")
    r = sub.add_parser("reverdict"); r.add_argument("name"); r.add_argument("--why", default="owner line TTsetup>=0/FFhold>=0/DRC0; SS sensitivity")
    r.add_argument("--recheck", action="store_true", help="a failed verdict check was fixed: re-run the verdict stage")
    c = sub.add_parser("cancel"); c.add_argument("name"); c.add_argument("--why")
    ef = sub.add_parser("early-fail"); ef.add_argument("name"); ef.add_argument("--verdict", required=True)
    ef.add_argument("--why", required=True); ef.add_argument("--detail")
    hs = sub.add_parser("hold-stop"); hs.add_argument("name"); hs.add_argument("--stage", required=True, choices=("cts", "grt"))
    hs.add_argument("--buffers", type=int, required=True); hs.add_argument("--why", required=True)
    ks = sub.add_parser("kill-stage"); ks.add_argument("name"); ks.add_argument("--why", required=True)
    ks.add_argument("--orfs")
    rc = sub.add_parser("restore-cancelled"); rc.add_argument("name")
    er = sub.add_parser("recover-eco-overlays"); er.add_argument("name")
    el = sub.add_parser("recover-export-lint"); el.add_argument("name")
    mg = sub.add_parser("migrate"); mg.add_argument("name"); mg.add_argument("host")
    rp = sub.add_parser("resume-postroute", help="re-judge a lost closed result on its preserved routed state (no re-route)")
    rp.add_argument("name"); rp.add_argument("--to-host", help="copy the routed state to this host first")
    rp.add_argument("--dry", action="store_true")
    lc = sub.add_parser("lost-closed-scan", help="jobs that CLOSED once and later ended non-CLOSED")
    lc.add_argument("--hours", type=float, default=48.0); lc.add_argument("--apply", action="store_true")
    lc.add_argument("--skip", nargs="*", help="job names --apply leaves alone"); lc.add_argument("--json")
    st = sub.add_parser("snapshot-trim", help="hourly guard: cut src/bench_src snapshots of deep-released jobs to receipt paths")
    st.add_argument("--limit", type=int, default=200)
    ot_ = sub.add_parser("offload-trim", help="remove src/ + bench_src*/ of terminal jobs at offload (bench) / previous-host locations"); ot_.add_argument("--limit", type=int, default=400)
    a = ap.parse_args()
    if a.cmd == "daemon":
        cmd_daemon(a)
    elif a.cmd == "tick":
        STATE.mkdir(parents=True, exist_ok=True)
        tick(Fleet())
    elif a.cmd == "status":
        cmd_status(a)
    elif a.cmd == "validate":
        cmd_validate(a)
    elif a.cmd == "submit-recheck":
        cmd_submit_recheck(a)
    elif a.cmd == "retry":
        cmd_retry(a)
    elif a.cmd == "retry-eco":
        cmd_retry_eco(a)
    elif a.cmd == "bench-rebind":
        cmd_bench_rebind(a)
    elif a.cmd == "reverdict":
        cmd_reverdict(a)
    elif a.cmd == "ioref-rejudge":
        cmd_ioref_rejudge(a)
    elif a.cmd == "rebudget-rejudge":
        cmd_rebudget_rejudge(a)
    elif a.cmd == "cancel":
        cmd_cancel(a)
    elif a.cmd == "early-fail":
        cmd_early_fail(a)
    elif a.cmd == "kill-stage":
        cmd_kill_stage(a)
    elif a.cmd == "hold-stop":
        cmd_hold_stop(a)
    elif a.cmd == "recover-eco-overlays":
        cmd_recover_eco_overlays(a)
    elif a.cmd == "recover-export-lint":
        cmd_recover_export_lint(a)
    elif a.cmd == "restore-cancelled":
        cmd_restore_cancelled(a)
    elif a.cmd == "snapshot-trim":
        cmd_snapshot_trim(a)
    elif a.cmd == "offload-trim":
        cmd_offload_trim(a)
    elif a.cmd == "resume-postroute":
        cmd_resume_postroute(a)
    elif a.cmd == "lost-closed-scan":
        cmd_lost_closed_scan(a)
    elif a.cmd == "migrate":     # executed by the daemon at its next tick (no race with the job's poller)
        (STATE / "migrate_requests").mkdir(parents=True, exist_ok=True)
        (STATE / "migrate_requests" / f"{a.name}.json").write_text(json.dumps(dict(name=a.name, host=a.host)))
        print(f"migrate request queued: {a.name} -> {a.host}")


if __name__ == "__main__":
    main()
