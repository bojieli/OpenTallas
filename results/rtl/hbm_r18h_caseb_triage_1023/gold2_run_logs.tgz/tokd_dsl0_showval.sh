#!/usr/bin/env bash
# TOKd-HBM: short +SHOWVAL look at ds_l0 first checks (got/expected of rec2 coll ring outputs), same binary, 400 edges
cd /srv/opentallas-scratch/claude/hbmc-token2/dn_r18h_case_b_hw; mkdir -p out_pay/ds_l0_showval
out/obj/Vtb_hbm_slice +verilator+rand+reset+0 +REPLAY=slice/replay/ds_l0 +CYCLES=400 +SHOWVAL > out_pay/ds_l0_showval/run.log 2>&1; echo RC=$?
grep -E "SLICE_CHECK_(FAIL|VAL)|SHOW|got" out_pay/ds_l0_showval/run.log | head -40
