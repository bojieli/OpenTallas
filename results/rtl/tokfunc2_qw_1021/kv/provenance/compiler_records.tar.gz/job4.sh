#!/bin/bash
# KV-MU6 10-20: KVATTN job4 = job3 vehicle (fafc28231, GEN9 9fb1918f6 production RTL) + tb-only bench fix 0e597ed1c
# (STATUS attribution + live k_late mutant). The hierarchical-block libraries of job3 are reused unchanged: tb_kvattn_rel is
# the top and is inside no block, so only the top is re-verilated; top C++ files whose bytes did not change keep job3's
# mtimes (make recompiles only the changed ones). Logged: number of changed top files.
set -euo pipefail
OLD=/srv/opentallas-scratch/claude/toksim-kvattn3-1019; OS=$OLD/src_fafc28231; OO=$OLD/out_fafc28231
N=/srv/opentallas-scratch2/claude/kv-mu6-kvattn4-1020; S=$N/src_0e597ed1c; O=$N/out_0e597ed1c
TB=rtl/test/qwen_kv_die/kvattn_rel_1019/tb_kvattn_rel.sv
mkdir -p $N $O
[ -d $S ] || cp -a $OS $S
cp $N/tb_kvattn_rel.sv $S/$TB; touch -r $OS/$TB $S/$TB
echo "vehicle = claude/kv-mu6-kvattn-1020 0e597ed1c = claude/toksim-kvattn-1019 fafc28231 (GEN9 9fb1918f6 production RTL) + tb-only fix; hier libs reused from job3 $OO" > $O/SOURCE_COMMIT.txt
sha256sum $S/$TB >> $O/SOURCE_COMMIT.txt
if [ ! -d $O/obj ]; then cp -a $OO/obj $O/obj.tmp && mv $O/obj.tmp $O/obj; fi
python3 - "$O/obj" "$OO" "$O" "$OS" "$S" <<'PY'
import os,sys
d,oo,o,os_,s=sys.argv[1:]
a1,b1,a2,b2=oo.encode(),o.encode(),os_.encode(),s.encode()
n=0
for root,_,fs in os.walk(d):
  for f in fs:
    if not f.endswith(('.mk','.f','.d','.dat')): continue
    p=os.path.join(root,f); st=os.stat(p); t=open(p,'rb').read()
    if a1 in t or a2 in t:
      open(p,'wb').write(t.replace(a1,b1).replace(a2,b2)); os.utime(p,ns=(st.st_atime_ns,st.st_mtime_ns)); n+=1
print('paths rewritten in',n,'files (mtimes kept)')
PY
cd $O/obj
find . -maxdepth 1 -type f \( -name '*.cpp' -o -name '*.h' \) -print0 | xargs -0 sha256sum > $O/pre_top.sha
s0=$(date +%s)
make -C $S -f $O/obj/Vtb_kvattn_rel_hier.mk hier_launch_verilator VM_HIER_LAUNCH_VERILATOR_ARGSFILE=$O/obj/Vtb_kvattn_rel__hierMkArgs.f > $O/verilate_top.log 2>&1
python3 - "$O/pre_top.sha" "$O/obj" "$OO/obj" <<'PY' > $O/top_changed.txt
import hashlib,os,sys
pre={l.split()[1]:l.split()[0] for l in open(sys.argv[1])}
d,od=sys.argv[2],sys.argv[3]; ch=[];new=[]
for f in os.listdir(d):
  if not f.endswith(('.cpp','.h')): continue
  k='./'+f; h=hashlib.sha256(open(os.path.join(d,f),'rb').read()).hexdigest()
  if k not in pre: new.append(f)
  elif pre[k]==h: os.utime(os.path.join(d,f),ns=(os.stat(os.path.join(od,f)).st_atime_ns,os.stat(os.path.join(od,f)).st_mtime_ns))
  else: ch.append(f)
print('TOP_CHANGED',len(ch),'NEW',len(new),'OF',len(pre)); print('\n'.join(sorted(ch+new)))
PY
head -1 $O/top_changed.txt
/usr/bin/time -v -o $O/build.time make -C $O/obj -f Vtb_kvattn_rel.mk -j 6 > $O/build.log 2>&1
echo "build_seconds $(( $(date +%s) - s0 ))" >> $O/build.log
sha256sum $O/obj/Vtb_kvattn_rel > $O/binary.sha256
cd $S
bash $S/tools/qwen_layerbench/kvattn_rel/run.sh $S $O > $O/run.out 2>&1
tail -25 $O/run.out
python3 $S/tools/qwen_layerbench/kvattn_rel/collect.py $O $O/record.json > $O/collect.out 2>&1; cat $O/collect.out
echo JOB4_DONE
