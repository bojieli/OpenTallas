`timescale 1ns/1ps
// ---------------------------------------------------------------------------
// ot_v41_chain4: ot_v41_chain3 (byte-identical body, renamed) plus the opt-in PD (default 0 = chain3): the adder is
// ot_v41_fadd2 with its step 0 (decode, zero / nonfinite, 24-bit compare) formed by ot_v41_fadd_s0 on each operand
// candidate (adder output, previous sum, accumulator, zero for a first term) in parallel against the term, and the
// bundle selected by the per-slice forward-select copies -- the 32-bit operand mux no longer sits in front of the
// compare (DS-V4.1 ROM q-pair, route Z15a: fwd select -> step 0 -> u_c0 -18.9 ps).  Zero cycles, bit-identical.
// ot_v41_chain3: ot_v41_chain2 (body unchanged) with the forwarding selects fwd5 / fwd6 held in ND separately kept
// registers (ot_v41_kreg), each driving 32 / ND bits of the adder's operand multiplexer (DS-V4.1 ROM q-element QZ,
// 2026-10-04; zero added cycles: every copy loads the same next-state expression).  In the routed QPIPE q-pair one
// fwd5 register drove 32+ operand bits through a 25-load buffer (and, merged across the macro halves by Yosys, the
// other macro's chain as well): -67 ps at SS.
// ---------------------------------------------------------------------------
// ot_v41_chain2: ot_v41_chain on the LAT-stage ot_v41_fadd (W10, 1.2 GHz at SS): a slot may be presented again
// LAT cycles after its previous term.  Otherwise identical.
// ot_v41_chain: one lane's golden chunk chains.  Golden csum (tools/hdc_golden_v41.py) sums each
// chunk of 8 consecutive terms sequentially from +0; the element interleaves up to NCH chunks
// (chains) of different units through ONE pipelined binary32 adder (ot_fp32_add_rne_pipe,
// LATENCY 5).  A term names its chain `slot`; `first` starts the chain from +0 (the add 0 + t is
// performed, as the golden does), `last` makes the lane emit the chunk sum instead of storing it.
// A slot may be presented again 5 cycles after its previous term (the adder's latency): the sum leaving the
// adder in that cycle is forwarded straight back as the operand.  Sooner is a violation and raises `fault`;
// the issuer (ot_v41_rom_elem_w10) never does it.  TW tag bits ride with the chain's last term.
// ---------------------------------------------------------------------------
module ot_v41_chain4 #(
    parameter integer ND = 4,
    parameter integer NCH = 16,
    parameter integer TW = 8,
    parameter [8:0] CUT = 9'b1_0111_1011,
    parameter integer LAT = 1 + CUT[0] + CUT[1] + CUT[2] + CUT[3] + CUT[4] + CUT[5] + CUT[6] + CUT[7] + CUT[8]
,
    parameter integer PD = 0) (
    input  wire                     clk,
    input  wire                     rst_n,
    input  wire                     v,
    input  wire [$clog2(NCH)-1:0]   slot,
    input  wire                     first,
    input  wire                     last,
    input  wire [31:0]              term,
    input  wire                     term_f,
    input  wire [TW-1:0]            tag,
    output wire                     ov,
    output wire [31:0]              osum,
    output wire                     of,
    output wire [TW-1:0]            otag,
    output reg                      fault
);
    localparam integer SW = $clog2(NCH);
    reg [31:0] acc [0:NCH-1];
    reg [NCH-1:0] accf;
    // input register: the chain slot's stored sum is read one cycle before the term meets the adder, so the
    // adder's operand is a 4-way choice (+0, the sum leaving the adder now, the one that left a cycle ago, the
    // stored sum) rather than a slot-wide read in front of the adder's first stage
    reg          v_r, first_r, last_r, termf_r, accf_r;
    reg [SW-1:0] slot_r;
    reg [31:0]   term_r, acc_r;
    reg [TW-1:0] tag_r;
    always @(posedge clk or negedge rst_n)
        if (!rst_n) v_r <= 1'b0; else v_r <= v;
    always @(posedge clk) begin
        slot_r <= slot; first_r <= first; last_r <= last; term_r <= term; termf_r <= term_f; tag_r <= tag;
        acc_r <= acc[slot]; accf_r <= accf[slot];
    end
    reg [LAT-1:0] pv;
    reg [SW-1:0] ps [0:LAT-1];
    // loop-scoped: k (S81-CORE-LAT/QB 10-26 rtl_lint shared loop integer)
    reg hazard;
    always @* begin
        hazard = 1'b0;
        for (int k = 0; k < LAT - 1; k = k + 1) if (pv[k] && ps[k] == slot_r) hazard = 1'b1;
    end
    wire [31:0] sum;
    wire [1:0] err;
    wire sv;
    wire [31:0] a;
    wire af;
    // PD: the adder's step 0 formed on every forward candidate in parallel, the bundle selected (see the header)
    wire [104:0] o0_ext;
    ot_v41_fadd2 #(.CUT(CUT), .EXT0(PD != 0 ? 1 : 0)) u_add (.clk(clk), .rst_n(rst_n), .valid_in(v_r), .a(a), .b(term_r),
                                     .o0_ext(o0_ext), .y(sum), .err(err), .valid_out(sv));
    wire [TW+2:0] dt;
    ot_hdc_delay #(.W(TW + 3), .D(LAT)) u_t (.clk(clk), .rst_n(rst_n), .d({tag_r, last_r, af | termf_r, 1'b0}), .q(dt));
    wire d_last = dt[2];
    wire d_f = dt[1] | (err != 2'd0);
    // the slot's previous sum: leaving the adder now (5 cycles ago), or one cycle ago (not yet in acc_r)
    reg          sp_v, sp_f;
    reg [SW-1:0] sp_slot;
    reg [31:0]   sp_val;
    // forwarding decisions are made a cycle ahead against the incoming slot and registered (the compare no
    // longer sits in front of the adder): fwd5 = the slot's sum leaves the adder in the operand cycle,
    // fwd6 = it left one cycle before
    reg [LAT-1:0] pl;
    wire [ND-1:0] fwd5, fwd6;
    wire fwd5_d = pv[LAT-2] && !pl[LAT-2] && ps[LAT-2] == slot;
    wire fwd6_d = sv && !d_last && ps[LAT-1] == slot;
    genvar g;
    for (g = 0; g < ND; g = g + 1) begin : g_fw
        ot_v41_kreg #(.W(2), .AR(1), .RV(2'b00)) u_f (.clk(clk), .arst_n(rst_n), .d({fwd6_d, fwd5_d}),
                                                       .q({fwd6[g], fwd5[g]}));
        localparam integer LO = (32 * g) / ND, HI = (32 * (g + 1)) / ND;
        assign a[HI-1:LO] = first_r ? {(HI-LO){1'b0}} : (fwd5[g] ? sum[HI-1:LO] : (fwd6[g] ? sp_val[HI-1:LO] : acc_r[HI-1:LO]));
    end
    always @(posedge clk) pl <= {pl[LAT-2:0], last_r};
    if (PD != 0) begin : g_pd
        wire [104:0] c5, c6, ca, cz;
        ot_v41_fadd_s0 u_s5 (.valid_in(v_r), .a(sum),    .b(term_r), .o0(c5));
        ot_v41_fadd_s0 u_s6 (.valid_in(v_r), .a(sp_val), .b(term_r), .o0(c6));
        ot_v41_fadd_s0 u_sa (.valid_in(v_r), .a(acc_r),  .b(term_r), .o0(ca));
        ot_v41_fadd_s0 u_sz (.valid_in(v_r), .a(32'd0),  .b(term_r), .o0(cz));
        for (genvar g2 = 0; g2 < ND; g2 = g2 + 1) begin : g_ps
            localparam integer LO = (105 * g2) / ND, HI = (105 * (g2 + 1)) / ND;
`ifdef CH_MUTANT_PD
            assign o0_ext[HI-1:LO] = first_r ? cz[HI-1:LO] : (fwd5[g2] ? c6[HI-1:LO] : (fwd6[g2] ? c5[HI-1:LO] : ca[HI-1:LO]));   // negative control: forward candidates swapped (a priority swap is equivalent: fwd5 and fwd6 are never both set, a back-to-back slot is a hazard)
`else
            assign o0_ext[HI-1:LO] = first_r ? cz[HI-1:LO] : (fwd5[g2] ? c5[HI-1:LO] : (fwd6[g2] ? c6[HI-1:LO] : ca[HI-1:LO]));
`endif
        end
    end else begin : g_npd
        assign o0_ext = '0;
    end
    assign af = first_r ? 1'b0 : (fwd5[0] ? d_f : (fwd6[0] ? sp_f : accf_r));
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pv <= '0; fault <= 1'b0; accf <= '0; sp_v <= 1'b0;
        end else begin
            pv <= {pv[LAT-2:0], v_r};
            if (v_r && hazard) fault <= 1'b1;
            if (sv && !d_last) accf[ps[LAT-1]] <= d_f;
            sp_v <= sv && !d_last;
        end
    end
    always @(posedge clk) begin
        ps[0] <= slot_r;
        for (int k = 1; k < LAT; k = k + 1) ps[k] <= ps[k-1];
        if (sv && !d_last) acc[ps[LAT-1]] <= sum;
        sp_slot <= ps[LAT-1]; sp_val <= sum; sp_f <= d_f;
    end
    assign ov = sv && d_last;
    assign osum = sum;
    assign of = d_f;
    assign otag = dt[TW+2:3];
endmodule
