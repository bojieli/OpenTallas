`timescale 1ns/1ps
module tb;
reg  clk;
reg  por_n;
reg  run_enable;
reg  quiesce;
reg  cmd_valid;
wire  cmd_ready;
reg [2:0] cmd_op;
reg [63:0] cmd_identity;
reg [19:0] cmd_key;
reg [63:0] cmd_producer;
reg [63:0] cmd_sequence;
reg [10:0] cmd_PC;
reg  cmd_consumer;
reg [3:0] cmd_stage_beat;
reg [9:0] cmd_stage_base;
reg [4:0] cmd_stage_SM;
reg [511:0] cmd_stage_data;
reg [33:0] cmd_K_base;
reg [33:0] cmd_V_base;
wire  rsp_valid;
reg  rsp_ready;
wire  rsp_fault;
wire [2:0] rsp_op;
wire [63:0] rsp_identity;
wire [19:0] rsp_key;
wire [63:0] rsp_sequence;
wire [10:0] rsp_PC;
wire [511:0] rsp_capture;
wire [63:0] rsp_producer;
wire  rsp_consumer;
wire [3:0] rsp_stage_beat;
wire  shared_valid;
wire  shared_write;
reg  shared_ready;
wire [9:0] shared_addr;
wire [4:0] shared_SM;
wire  shared_rank;
wire [511:0] shared_wdata;
reg  shared_done;
wire  shared_done_ready;
reg [511:0] shared_rdata;
wire  commit_valid;
reg  commit_ready;
wire [63:0] writer_identity;
wire [19:0] writer_key;
wire [9:0] writer_stage_base;
wire [4:0] writer_stage_SM;
wire [33:0] writer_K_base;
wire [33:0] writer_V_base;
reg  payload_valid;
wire  payload_ready;
reg [63:0] payload_identity;
reg [19:0] payload_key;
reg [8:0] payload_sector;
reg [33:0] payload_source_addr;
reg  payload_visible;
reg  payload_reverse;
reg  payload_write;
reg [255:0] payload_rdata;
wire  payload_req_valid;
reg  payload_req_ready;
wire  payload_req_write;
wire [8:0] payload_req_sector;
wire [33:0] payload_req_source_addr;
wire [255:0] payload_req_data;
wire  payload_req_rmw;
wire  payload_req_rmw_last;
reg  metadata_valid;
wire  metadata_ready;
reg [63:0] metadata_identity;
reg [19:0] metadata_key;
reg  metadata_record;
reg  consumer_valid;
wire  consumer_ready;
reg [63:0] consumer_identity;
reg [19:0] consumer_key;
reg  consumer_stage;
reg  consumer_accepted;
reg  consumer_reverse;
reg  reader_metadata_valid;
wire  reader_metadata_ready;
reg [63:0] reader_metadata_identity;
reg [19:0] reader_metadata_key;
reg  reader_metadata_stage;
reg  hydrate_valid;
wire  hydrate_ready;
reg [19:0] hydrate_key;
reg [63:0] hydrate_producer;
wire  drain_valid;
reg  drain_ready;
wire [63:0] drain_identity;
wire [19:0] drain_key;
reg  drain_done_valid;
wire  drain_done_ready;
reg [63:0] drain_done_identity;
reg [19:0] drain_done_key;
reg [7:0] drain_done_allcopies;
wire  fault;
wire  writer_retained;
wire  idle;
ot_gpu_qwen_kv_lifecycle_controller #(.ENABLE(1)) dut(.clk(clk),.por_n(por_n),.run_enable(run_enable),.quiesce(quiesce),.cmd_valid(cmd_valid),.cmd_ready(cmd_ready),.cmd_op(cmd_op),.cmd_identity(cmd_identity),.cmd_key(cmd_key),.cmd_producer(cmd_producer),.cmd_sequence(cmd_sequence),.cmd_PC(cmd_PC),.cmd_consumer(cmd_consumer),.cmd_stage_beat(cmd_stage_beat),.cmd_stage_base(cmd_stage_base),.cmd_stage_SM(cmd_stage_SM),.cmd_stage_data(cmd_stage_data),.cmd_K_base(cmd_K_base),.cmd_V_base(cmd_V_base),.rsp_valid(rsp_valid),.rsp_ready(rsp_ready),.rsp_fault(rsp_fault),.rsp_op(rsp_op),.rsp_identity(rsp_identity),.rsp_key(rsp_key),.rsp_sequence(rsp_sequence),.rsp_PC(rsp_PC),.rsp_capture(rsp_capture),.rsp_producer(rsp_producer),.rsp_consumer(rsp_consumer),.rsp_stage_beat(rsp_stage_beat),.shared_valid(shared_valid),.shared_write(shared_write),.shared_ready(shared_ready),.shared_addr(shared_addr),.shared_SM(shared_SM),.shared_rank(shared_rank),.shared_wdata(shared_wdata),.shared_done(shared_done),.shared_done_ready(shared_done_ready),.shared_rdata(shared_rdata),.commit_valid(commit_valid),.commit_ready(commit_ready),.writer_identity(writer_identity),.writer_key(writer_key),.writer_stage_base(writer_stage_base),.writer_stage_SM(writer_stage_SM),.writer_K_base(writer_K_base),.writer_V_base(writer_V_base),.payload_valid(payload_valid),.payload_ready(payload_ready),.payload_identity(payload_identity),.payload_key(payload_key),.payload_sector(payload_sector),.payload_source_addr(payload_source_addr),.payload_visible(payload_visible),.payload_reverse(payload_reverse),.payload_write(payload_write),.payload_rdata(payload_rdata),.payload_req_valid(payload_req_valid),.payload_req_ready(payload_req_ready),.payload_req_write(payload_req_write),.payload_req_sector(payload_req_sector),.payload_req_source_addr(payload_req_source_addr),.payload_req_data(payload_req_data),.payload_req_rmw(payload_req_rmw),.payload_req_rmw_last(payload_req_rmw_last),.metadata_valid(metadata_valid),.metadata_ready(metadata_ready),.metadata_identity(metadata_identity),.metadata_key(metadata_key),.metadata_record(metadata_record),.consumer_valid(consumer_valid),.consumer_ready(consumer_ready),.consumer_identity(consumer_identity),.consumer_key(consumer_key),.consumer_stage(consumer_stage),.consumer_accepted(consumer_accepted),.consumer_reverse(consumer_reverse),.reader_metadata_valid(reader_metadata_valid),.reader_metadata_ready(reader_metadata_ready),.reader_metadata_identity(reader_metadata_identity),.reader_metadata_key(reader_metadata_key),.reader_metadata_stage(reader_metadata_stage),.hydrate_valid(hydrate_valid),.hydrate_ready(hydrate_ready),.hydrate_key(hydrate_key),.hydrate_producer(hydrate_producer),.drain_valid(drain_valid),.drain_ready(drain_ready),.drain_identity(drain_identity),.drain_key(drain_key),.drain_done_valid(drain_done_valid),.drain_done_ready(drain_done_ready),.drain_done_identity(drain_done_identity),.drain_done_key(drain_done_key),.drain_done_allcopies(drain_done_allcopies),.fault(fault),.writer_retained(writer_retained),.idle(idle));
initial clk=0; always #5 clk=~clk;
reg [511:0] scratch[0:1023]; reg [1:0] pending;
integer j;
// Explicit test SRAM acceptance/capture, not production ready/fence ties.
always @(posedge clk) begin
 if(!por_n) begin pending<=0; shared_done<=0; end
 else begin
  if(shared_done && shared_done_ready) shared_done<=0;
  if(shared_valid && shared_ready) begin
   if(shared_write) begin scratch[shared_addr]<=shared_wdata; shared_done<=1; end
   else begin shared_rdata<=scratch[shared_addr] ^ 512'd0; pending<=1; end
  end
  if(pending!=0) begin pending<=0; shared_done<=1; end
 end
end
always @* shared_ready=por_n && !shared_done && pending==0;
task offer(input [2:0] kind,input [63:0] identity,input [19:0] k);
 begin @(negedge clk); cmd_op=kind; cmd_identity=identity; cmd_key=k;
 cmd_sequence=cmd_sequence+1; cmd_valid=1;
 #1; while(!cmd_ready) begin @(negedge clk); #1; end
 @(negedge clk); cmd_valid=0;
 end
endtask
task response;
 begin while(!rsp_valid && !fault) @(negedge clk);
 if(fault || rsp_fault) $fatal(1,"unexpected fault");
 if(rsp_identity!=cmd_identity || rsp_op!=cmd_op || rsp_key!=cmd_key || rsp_sequence!=cmd_sequence)
  $fatal(1,"identity");
 rsp_ready=1; @(negedge clk); rsp_ready=0;
 end
endtask
task begin_writer;
 begin offer(0,64'd99,20'd0); response(); end
endtask
task stages;
 begin for(j=0;j<16;j=j+1) begin
 cmd_stage_beat=j; cmd_stage_data={64{j[7:0]}};
 offer(1,64'd99,20'd0); response();
 if(rsp_capture!={64{j[7:0]}}) $fatal(1,"readback"); end end
endtask
task payloads;
 integer transaction, index, k;
 reg is_write; reg [33:0] address; reg [255:0] data, expected;
 begin for(transaction=0;transaction<528;transaction=transaction+1) begin
 while(!payload_req_valid) @(negedge clk);
 index=payload_req_sector; is_write=payload_req_write;
 address=payload_req_source_addr; data=payload_req_data;
 if(is_write) begin
  if(index<256) begin
   expected={32{8'haa}};
   expected[7:0]=index>>5; expected[135:128]=index>>5;
  end else begin expected=0; for(k=0;k<32;k=k+1) expected[k*8+:8]=8+((index-256)>>1); end
  if(data!==expected) $fatal(1,"actual staged byte merge/old tail index %0d",index);
 end
 repeat(2) @(negedge clk);
 if(!payload_req_valid || payload_req_sector!=index || payload_req_source_addr!=address || payload_req_write!=is_write)
   $fatal(1,"request changed under backpressure");
 payload_req_ready=1; @(negedge clk); payload_req_ready=0;
 payload_valid=1; payload_identity=99; payload_key=0; payload_sector=index;
 payload_source_addr=address; payload_write=is_write;
 payload_rdata={32{8'haa}}; payload_visible=1; payload_reverse=0;
 @(negedge clk); payload_valid=0; payload_visible=0;
 repeat(2) @(negedge clk);
 payload_valid=1; payload_reverse=1;
 @(negedge clk); payload_valid=0; payload_reverse=0;
 end end
endtask
task commit_writer;
 begin offer(2,99,0);
 while(!commit_valid) @(negedge clk);
 repeat(3) @(negedge clk);
 if(rsp_valid) $fatal(1,"commit before accept");
 commit_ready=1; @(negedge clk); commit_ready=0;
 payloads(); response(); end
endtask
task publish_writer;
 begin offer(3,99,0);
 repeat(3) @(negedge clk);
 if(rsp_valid) $fatal(1,"publish without metadata");
 metadata_valid=1; metadata_identity=99; metadata_key=0; metadata_record=0;
 @(negedge clk); metadata_record=1;
 @(negedge clk); metadata_valid=0;
 response(); if(writer_retained) $fatal(1,"writer held after publish"); end
endtask
task consume(input bit stage);
 begin cmd_consumer=stage; offer(5,777,0);
 repeat(3) @(negedge clk);
 if(rsp_valid) $fatal(1,"consumer always-ready");
 consumer_valid=1; consumer_identity=777; consumer_key=0; consumer_stage=stage;
 consumer_accepted=1; consumer_reverse=0;
 @(negedge clk); consumer_valid=0; consumer_accepted=0;
 repeat(3) @(negedge clk);
 if(rsp_valid) $fatal(1,"missing reverse");
 consumer_valid=1; consumer_reverse=1;
 @(negedge clk); consumer_valid=0; consumer_reverse=0;
 response();
 reader_metadata_valid=1; reader_metadata_identity=777; reader_metadata_key=0;
 reader_metadata_stage=stage; @(negedge clk); reader_metadata_valid=0;
 end
endtask
initial begin
por_n=0;
run_enable=0;
quiesce=0;
cmd_valid=0;
cmd_op=0;
cmd_identity=0;
cmd_key=0;
cmd_producer=0;
cmd_sequence=0;
cmd_PC=0;
cmd_consumer=0;
cmd_stage_beat=0;
cmd_stage_base=0;
cmd_stage_SM=0;
cmd_stage_data=0;
cmd_K_base=0;
cmd_V_base=0;
rsp_ready=0;
shared_ready=0;
shared_done=0;
shared_rdata=0;
commit_ready=0;
payload_valid=0;
payload_identity=0;
payload_key=0;
payload_sector=0;
payload_source_addr=0;
payload_visible=0;
payload_reverse=0;
payload_write=0;
payload_rdata=0;
payload_req_ready=0;
metadata_valid=0;
metadata_identity=0;
metadata_key=0;
metadata_record=0;
consumer_valid=0;
consumer_identity=0;
consumer_key=0;
consumer_stage=0;
consumer_accepted=0;
consumer_reverse=0;
reader_metadata_valid=0;
reader_metadata_identity=0;
reader_metadata_key=0;
reader_metadata_stage=0;
hydrate_valid=0;
hydrate_key=0;
hydrate_producer=0;
drain_ready=0;
drain_done_valid=0;
drain_done_identity=0;
drain_done_key=0;
drain_done_allcopies=0;
cmd_stage_base=100; cmd_K_base=34'h100000; cmd_V_base=34'h1000000;
pending=0; por_n=0; run_enable=1;
repeat(2) @(negedge clk); por_n=1;
begin: allrows
integer r, st; reg [19:0] rowkey;
for(r=0;r<72;r=r+1) begin
 rowkey=(r<<13)|13'd17;
 @(negedge clk); hydrate_key=rowkey; hydrate_producer=99; hydrate_valid=1;
 #1; while(!hydrate_ready) begin @(negedge clk); #1; end
 @(negedge clk); hydrate_valid=0;
 cmd_producer=99; offer(4,777+r,rowkey); response();
end
if(dut.reader_count!=72 || idle) $fatal(1,"missing retained rows");
for(r=0;r<72;r=r+1) begin
 rowkey=(r<<13)|13'd17;
 for(st=0;st<2;st=st+1) begin
  cmd_consumer=st; offer(5,777+r,rowkey);
  consumer_valid=1; consumer_identity=777+r; consumer_key=rowkey; consumer_stage=st;
  consumer_accepted=1; consumer_reverse=1;
  @(negedge clk); consumer_valid=0; consumer_accepted=0; consumer_reverse=0;
  response();
  reader_metadata_valid=1; reader_metadata_identity=777+r; reader_metadata_key=rowkey;
  reader_metadata_stage=st; @(negedge clk); reader_metadata_valid=0;
 end
 offer(6,777+r,rowkey); while(!drain_valid) @(negedge clk);
 if(drain_identity!=777+r || drain_key!=rowkey) $fatal(1,"saved drain row");
 drain_ready=1; @(negedge clk); drain_ready=0;
 drain_done_valid=1; drain_done_identity=777+r; drain_done_key=rowkey; drain_done_allcopies=255;
 @(negedge clk); drain_done_valid=0; response();
end
if(!idle || dut.reader_count!=0) $fatal(1,"real drains did not retire rows");
end
$display("PASS"); $finish;
end
initial begin #500000; $fatal(1,"fixture watchdog"); end

integer cycles=0, accepted=0;
always @(posedge clk) begin
 cycles<=cycles+1;
 if(cmd_valid && cmd_ready) begin accepted<=cycles; $display("CMD %0d %0d %0d",cmd_op,cmd_identity,cycles); end
 if(rsp_valid && rsp_ready) $display("RSP %0d %0d %0d",rsp_op,rsp_identity,cycles-accepted);
 if(payload_req_valid && payload_req_ready) $display("SECTOR %0d %0d %0d",payload_req_write,payload_req_sector,cycles);
end

endmodule
