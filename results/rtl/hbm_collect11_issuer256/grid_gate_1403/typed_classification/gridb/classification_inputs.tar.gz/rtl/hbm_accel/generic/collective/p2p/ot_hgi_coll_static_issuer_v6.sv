`timescale 1ns/1ps
`default_nettype none
// H-NETLIST/H-ELEM 1515 V6 issuer: ot_hgi_coll_static_issuer_v5 (gate 15f52eabd: reg->reg -348.5 cur_has, in->reg -310.1
// cur_cm1 <- start_pc) with the per-row loop count PRE-DECODED: rowhas[r] = count != 0 and rowcm1[r] = count - 1 are
// registered one edge after the row's meta lo / hi write (both halves read from the stored meta), so the successor
// load is a 64:1 read only (no 32-bit decrement / OR-reduce behind the mux) on the advance AND the start path.
// Programme constraint (met by every F20 programme: 55-edge row drain, 66-edge descriptor scan before launch): start
// is never on the edge right after a meta write of the started programme.
// (V5 header follows.)
// H-NETLIST/COLL-CTL 1045: timing successor of ot_hgi_coll_static_issuer (that file is unchanged and keeps
// ot_hgi_coll_static_program_bank, which this module instantiates). Cycle-exact on every port (busy, done, fault,
// uop_v, uop, iteration, uop_pc) for every programme the original accepts, including several loop-ending rows that
// share a loop id (miter tb_hgi_coll_static_issuer_v5_miter.sv).
//
// The original next-pc recurrence is pc -> meta[pc] (64:1 x 64b) -> lid -> loops[lid] (64:1 x 32b) -> 32b compare
// with count-1 -> pc / loops[lid]+1, in one edge (issuer gate: 19 levels, reg->reg -365 ps). Here:
//  * the CURRENT row's fields are registers (cur_*), loaded with the successor row's fields when pc moves, so no
//    64:1 mux precedes the decision;
//  * loops[] is held per ROW (rowloops[r] == loops[lid(r)] at every edge; every row whose lid equals the visited
//    row's lid is written together), so the successor's loop value is ONE 64:1 read, forwarded when the successor
//    shares the visited row's lid;
//  * cur_loops / cur_cm1 (count-1) are registers: the decision is one 32b compare of two flops;
//  * both successors' fields (target, next) are read in parallel with the decision and the decision only selects.
// No async reset on rowloops / meta / the cur_* data registers: start loads all of them before the first fetch, and
// no fetch happens without a successful start (the original's reset of loops[] is unobservable). Control flops and
// the row-valid bits keep the original's async reset.
// XDIE-HBM4 (10-19): ROWS (default 64 = the closed issuer, every port/edge unchanged). ROWS=128: 7-bit pc; the row
// metadata's spare bits carry the pc MSBs (next[6]=m[51], target[6]=m[52], lid[6]=m[53]; m[63:54] must be 0), cfg row
// select bit 6 = cfg[8] (mode 0) and meta-hi bits [53:51] = cfg[21:19] (mode 3); program banks = 2 x 64-row macros.
// Same edges, same ISA otherwise (a 64-row programme behaves identically at ROWS 128).
// HBM-ARGMAX (10-19, coordinator 0kj): ROWS=256: 8-bit pc; next[7]=m[54], target[7]=m[55], lid[7]=m[56] (m[63:57]
// must be 0), cfg row bits [7:6] = cfg[9:8] (mode 0), meta-hi bits [56:51] = cfg[24:19] (mode 3); program banks =
// 4 x 64-row macros (u_sram, g128.u_sram_hi, g256.u_sram_h2/_h3). ROWS 64/128 unchanged.
module ot_hgi_coll_static_issuer_v6 #(
    parameter integer MUT_DATA=0, MUT_BRANCH=0, MUT_RELOAD=0, parameter integer ROWS=64,
    parameter integer PW=(ROWS>128)?8:(ROWS>64)?7:6      // derived; never override
)(
    input wire clk_control,
    input wire [2:0] clk_mem,
    input wire rst_n,
    input wire [36:0] cfg,
    input wire start,
    input wire [PW-1:0] start_pc,
    output reg busy,done,fault,
    output reg uop_v,
    output wire [1535:0] uop,
    output reg [31:0] iteration,
    output reg [PW-1:0] uop_pc
);
    reg [63:0] meta[0:ROWS-1];
    reg [31:0] rowloops[0:ROWS-1];
    reg [ROWS-1:0] word_valid[0:2];
    reg [ROWS-1:0] meta_lo_valid,meta_hi_valid;
    reg [PW-1:0] cfg_row,pc;
    // metadata fields (ROWS 64: the original bit positions exactly)
    function automatic [PW-1:0] f_next(input [63:0] x); f_next=(PW==8)?{x[54],x[51],x[5:0]}:(PW==7)?{x[51],x[5:0]}:x[5:0]; endfunction
    function automatic [PW-1:0] f_tgt(input [63:0] x); f_tgt=(PW==8)?{x[55],x[52],x[11:6]}:(PW==7)?{x[52],x[11:6]}:x[11:6]; endfunction
    function automatic [PW-1:0] f_lid(input [63:0] x); f_lid=(PW==8)?{x[56],x[53],x[50:45]}:(PW==7)?{x[53],x[50:45]}:x[50:45]; endfunction
    localparam integer MHB=(PW==8)?25:(PW==7)?22:19;
    wire [12:0] spare_mask=(PW==8)?13'h1fc0:(PW==7)?13'h1ff8:13'h1fff;   // m[63:51] bits that must be zero
    reg [1:0] cfg_bank;
    reg cfg_selected;
    reg [3:0] fragment;
    reg [511:0] assemble;
    reg [2:0] write_v;
    reg [PW-1:0] write_row;
    reg [511:0] write_data;
    reg fetching,fetch_v,v1,h0,h1;
    reg [PW-1:0] fetch_pc,pc1;
    reg [31:0] it0,it1;
    // current row (the row at pc): registered fields
    reg [PW-1:0] cur_lid,cur_target,cur_next;
    reg cur_halt,cur_has;
    reg [31:0] cur_cm1,cur_loops;
    reg [31:0] rowcm1[0:ROWS-1];reg [ROWS-1:0] rowhas;reg dv;reg [PW-1:0] drow;    // pre-decoded loop counts
    for(genvar b=0;b<3;b=b+1)begin:g_mem
        ot_hgi_coll_static_program_bank #(.MUT_DATA(MUT_DATA && b==0),.ROWS(ROWS)) u_bank(
            .clk(clk_mem[b]),.read_v(fetch_v),.read_row(fetch_pc),
            .write_v(write_v[b]),.write_row(write_row),.write_data(write_data),
            .data(uop[b*512+:512]));
    end
    // ---- the decision (two flops into one compare)
    wire take=cur_has && ((MUT_RELOAD!=0) ? (cur_loops<=cur_cm1) : (cur_loops<cur_cm1)) && MUT_BRANCH==0;
    wire [31:0] wv=take ? cur_loops+32'd1 : 32'd0;             // loops[cur_lid] after this visit (when cur_has)
    wire advance=fetching && !cur_halt;
    wire upd=advance && cur_has && MUT_BRANCH==0;              // loops[cur_lid] is written this edge
    // ---- both successors, read in parallel with the decision
    wire [63:0] mt=meta[cur_target], mn=meta[cur_next];
    wire [31:0] lt=(upd && f_lid(mt)==cur_lid) ? wv : rowloops[cur_target];
    wire [31:0] ln=(upd && f_lid(mn)==cur_lid) ? wv : rowloops[cur_next];
    wire [63:0] ms=meta[start_pc];wire [31:0] cs=rowcm1[start_pc];wire hs=rowhas[start_pc];
    wire [31:0] ct=rowcm1[cur_target],cn=rowcm1[cur_next];wire ht=rowhas[cur_target],hn=rowhas[cur_next];
    wire [63:0] m=meta[pc];
    // pre-decode one edge after a meta write (dv/drow are set by the cfg 2/3 writes below)
    always @(posedge clk_control)if(dv)begin rowhas[drow]<=meta[drow][43:12]!=0;rowcm1[drow]<=meta[drow][43:12]-32'd1;end
    always @(posedge clk_control)begin
        // data registers without reset (loaded by start before any fetch)
        if(start && !(busy || cfg[36] || fragment!=0))begin
            for(integer i=0;i<ROWS;i=i+1)rowloops[i]<=0;
            cur_lid<=f_lid(ms);cur_target<=f_tgt(ms);cur_next<=f_next(ms);cur_halt<=ms[44];
            cur_has<=hs;cur_cm1<=cs;cur_loops<=0;
        end
        if(advance)begin
            if(upd)for(integer i=0;i<ROWS;i=i+1)if(f_lid(meta[i])==cur_lid)rowloops[i]<=wv;
            if(take)begin
                cur_lid<=f_lid(mt);cur_target<=f_tgt(mt);cur_next<=f_next(mt);cur_halt<=mt[44];
                cur_has<=ht;cur_cm1<=ct;cur_loops<=lt;
            end else begin
                cur_lid<=f_lid(mn);cur_target<=f_tgt(mn);cur_next<=f_next(mn);cur_halt<=mn[44];
                cur_has<=hn;cur_cm1<=cn;cur_loops<=ln;
            end
        end
    end
    always @(posedge clk_control or negedge rst_n)begin
        if(!rst_n)begin
            busy<=0;done<=0;fault<=0;fetching<=0;fetch_v<=0;v1<=0;uop_v<=0;dv<=0;
            h0<=0;h1<=0;cfg_selected<=0;fragment<=0;write_v<=0;
            meta_lo_valid<=0;meta_hi_valid<=0;iteration<=0;uop_pc<=0;
            for(integer b=0;b<3;b=b+1)word_valid[b]<=0;
        end else begin
            done<=0;write_v<=0;fetch_v<=0;dv<=0;
            v1<=fetch_v;uop_v<=v1;
            pc1<=fetch_pc;uop_pc<=pc1;it1<=it0;iteration<=it1;h1<=h0;
            if(v1 && h1)begin busy<=0;done<=1;end
            if(start)begin
                if(busy || cfg[36] || fragment!=0)fault<=1;
                else begin
                    pc<=start_pc;busy<=1;fetching<=1;
                end
            end
            if(fetching)begin
                if(!word_valid[0][pc] || !word_valid[1][pc] || !word_valid[2][pc] ||
                   !meta_lo_valid[pc] || !meta_hi_valid[pc])fault<=1;
                fetch_v<=1;fetch_pc<=pc;it0<=cur_loops;h0<=cur_halt;
                if((m[63:51]&spare_mask)!=0)fault<=1;
                if(cur_halt)fetching<=0;
`ifdef OT_COLL_ISS_MUT_PCWRAP
                else pc<=(take ? cur_target : cur_next) & {1'b0,{(PW-1){1'b1}}};   // mutant: pc MSB dropped (wraps at ROWS/2)
`else
                else pc<=take ? cur_target : cur_next;
`endif
            end
            if(cfg[36])begin
                if(busy || start)fault<=1;
                else case(cfg[35:32])
                    4'd0:begin
                        if(fragment!=0 || cfg[31:PW+2]!=0 || cfg[7:6]==3)fault<=1;
                        cfg_row<=(PW==8)?{cfg[9:8],cfg[5:0]}:(PW==7)?{cfg[8],cfg[5:0]}:cfg[5:0];cfg_bank<=cfg[7:6];cfg_selected<=cfg[7:6]!=3;
                        fragment<=0;
                    end
                    4'd1:begin
                        if(!cfg_selected || cfg_bank==3)fault<=1;
                        else begin
                            assemble[fragment*32+:32]<=cfg[31:0];fragment<=fragment+1'b1;
                            if(fragment==15)begin
                                write_v[cfg_bank]<=1;write_row<=cfg_row;
                                write_data<={cfg[31:0],assemble[479:0]};
                                word_valid[cfg_bank][cfg_row]<=1;
                            end
                        end
                    end
                    4'd2:begin
                        if(!cfg_selected || fragment!=0)fault<=1;
                        else begin meta[cfg_row][31:0]<=cfg[31:0];meta_lo_valid[cfg_row]<=1;dv<=1;drow<=cfg_row;end
                    end
                    4'd3:begin
                        if(!cfg_selected || fragment!=0 || cfg[31:MHB]!=0)fault<=1;
                        else begin meta[cfg_row][63:32]<=cfg[31:0];meta_hi_valid[cfg_row]<=1;dv<=1;drow<=cfg_row;end
                    end
                    default:fault<=1;
                endcase
            end
        end
    end
endmodule
`default_nettype wire
