`timescale 1ns/1ps
// ot_hgi_coll_qrec (HBM peer-to-peer step 1, owner approval 2026-10-14 09:00 PT, study results/arch/hbm_p2p_1014):
// the QUADRANT form of ot_hgi_coll_record (derived from rtl/hbm_accel/generic/collective/ot_hgi_coll_record.sv @ main
// 2a64aca68; the central file is untouched).  Every quadrant engine q (0 SW, 1 SE, 2 NW, 3 NE: pin qid, a die strap)
// receives the SAME normative COLL record and runs the element quarter q of it on its own rail of links; the four
// quarters together deliver exactly the words the central engine delivers (bit-exact: every element keeps the rank-order
// pairwise tree, gathers copy).  Quarter rules (all exact, all decided from the record alone, identical on every die):
//   ALL_REDUCE_SUM / GROUP_REDUCE_MCAST (op 0 / 4): pf = A.n / 16 flits; units of 16 flits (256 elements:
//       pf_q % NC == 0 and an even owner slice OF for every legal NC <= 8, so the BF16 result pairs never straddle a
//       quarter); quarter q = units [floor(q U / 4), floor((q + 1) U / 4)), the pf mod 16 remainder in quarter 3;
//       A_q = A + 16 lo, O_q = O + (BF16 ? 8 : 16) lo.
//   ALL_GATHER sliced (32-bit A, F3): each rank's slice [s_r, s_r+1) (len_r) is split into four sub-slices
//       [s_r + floor(q len_r / 4), s_r + floor((q + 1) len_r / 4)); the slice table holds {end, start} per rank and the
//       delivery formatter writes start + 16 (gi - r pf_q), lanes = min(16, end - w); pf_q = ceil(max sub-slice / 16).
//   ALL_GATHER whole row (other formats): flits [floor(q pf / 4), floor((q + 1) pf / 4)) of every rank's row; the table
//       holds the gi offset r (pf - pf_q) + lo per rank (formatter gi' = gi + table[r]: the global flit index).
//   ARGMAX_MERGE / TOPK_MERGE / ROW_GATHER (ops 3 / 2 / 5): run whole on quadrant QSOLO (one flit a rank, a merge sink,
//       an owner-row stream); the other quadrants retire the record as a no-op.
//   A quarter with no flits (tiny n) retires as a no-op once its pipelined gathers have retired (in-order completion).
// MUT_Q (bench mutant): the quarter of qid ^ 1 is computed (wrong quadrant).
// ---------------------------------------------------------------------------------------------------------------------
// HGI-1 collective record binding (hgi-takeover, 2026-10-09).
//
// Binds one normative record from the HGI-1 sequencer (ot_hgi_seq, main ef3135b44: u_v / u_rdy, d_hdr, d_desc
// {I,R,O,D,C,B,A}, d_n 7 x 21, u_done / u_fault) to the collective engine.  The die taps unit 6 of the dispatch:
// header, the A, O and I effective descriptors and their effective counts (960 bits, tools/hgi_die_dispatch.py).
//
//   record station (registered) -> ot_hgi_coll_decode (unchanged, GX11 reject) -> backend:
//     ALL_REDUCE_SUM (op 0), GROUP_REDUCE_MCAST (op 4): endpoint control {rank, gsz, mcast_all, mcast_group_size,
//                       pf = A.n / 16 flits}, go / start_ready, done_valid / done_ready, fault / fault_ack;
//                       A and O effective bases go to the SU inject / deliver addressing (ep_a_base, ep_o_base).
//     ROW_GATHER (op 5), param[8] = 1 and RGXHW = 1 (G25 hardware form): the endpoint in RGX mode (bypass, the source's
//                       tags, K * F deliveries) + the owner-row source and list-order sink started with it; retires
//                       when the endpoint completed and the sink drained.  K from I's count (n_sel 63) or imm_a.
//     ROW_GATHER (op 5): row formatter start {G, B, destinations, row count, row words = ceil(A.n * bits(A.fmt) /
//                       512), context rows = A.m}, done / fault.
//     ALL_GATHER, TOPK_MERGE, ARGMAX_MERGE (ops 1-3): no generic backend is installed on this collective yet; the
//                       record retires with u_fault (fail-closed, no silent completion).
//   Any decode error, endpoint fault or formatter fault retires the record with u_fault (sticky until rst_n: the CP
//   halts; recovery is the drained reset, HGI-1 MX-1).
//
// Every output is a flop; every input is captured before use.  Added edges: record station 1 + decode 2 (priced in
// ot_hgi_coll_decode) + backend issue 1; completion 1.
module ot_hgi_coll_qrec #(
    parameter integer QSOLO = 0,           // the quadrant that runs ARGMAX / TOPK / ROW_GATHER whole
    parameter integer SOLO_CAP = 1,        // 0: this master never runs the whole ops (the NPT-2 die master: its strap is 1..3)
    parameter integer MUT_Q = 0,           // mutant: wrong quadrant quarter
    parameter integer MUT_PF = 0,          // mutant: pf from A.n without the /16 flit conversion
    parameter integer MUT_DONE = 0,        // mutant: retire on issue instead of on endpoint completion
    parameter integer MUT_SLICE = 0,       // 1: no slicing (the whole A row from every rank, pre-F3 behaviour)
    parameter integer PIPE = 0,            // hgi-unitrate: 1 = ALL_GATHER records pipeline (epoch-tagged; the block
                                           // ot_hgi_coll_ep PIPE retires them in order), every other op waits until
                                           // no pipelined gather is open
    parameter integer RGXHW = 0,           // 1: ROW_GATHER param[8] runs the hardware form (G25, ot_hgi_coll_rgx_src / _sink)
    parameter integer RFMT = 1,            // 0: no row formatter on this die (hfd_coll RGXHW views): ROW_GATHER param[8] = 0 faults (E_RANGE)
                                           //    instead of waiting on an unbound formatter (hgi-1010/c)
    parameter integer TKM = 0,             // hgi-1010/k: 1 = TOPK_MERGE (op 2) runs on the merge sink ot_hgi_coll_tkm (gather bypass,
                                           //    8 {value, id} pairs a flit); 0 = op 2 faults as before
    parameter integer TKM_KMAX = 2048      // the sink's largest k
) (
    input  wire          clk,
    input  wire          rst_n,
    // static configuration (config master)
    input  wire [7:0]    cfg_coll_group_size,
    input  wire [7:0]    cfg_die_id,
    input  wire [1:0]    qid,            // die strap: this engine's quadrant (0 SW, 1 SE, 2 NW, 3 NE)
    // record (unit 6 of the sequencer dispatch)
    input  wire          rec_v,
    output wire          rec_rdy,
    input  wire [127:0]  rec_hdr,
    input  wire [255:0]  rec_a,
    input  wire [255:0]  rec_o,
    input  wire [255:0]  rec_i,
    input  wire [20:0]   rec_n_a,
    input  wire [20:0]   rec_n_o,
    input  wire [20:0]   rec_n_i,
    // TOPK_MERGE (TKM = 1): the B (ids) and R (values out) effective descriptors and counts (ot_hgi_cp_die coll_recx)
    input  wire [255:0]  rec_b,
    input  wire [255:0]  rec_r,
    input  wire [20:0]   rec_n_b,
    input  wire [20:0]   rec_n_r,
    output reg           rec_done,
    output reg           rec_fault,
    // collective endpoint control (ot_hbm_accel_tu_endpoint_psg)
    output reg  [7:0]    ep_rank,
    output reg  [7:0]    ep_mcast_group_size,
    output reg           ep_mcast_all,
    output reg  [3:0]    ep_gsz,
    output reg           ep_byp,         // exact gather bypass (ALL_GATHER, ARGMAX_MERGE)
    output reg           ep_amx,         // ARGMAX_MERGE: the delivered flits fold to one token (ot_hgi_coll_amerge)
    output reg           ep_bf16,        // F2: a reduction's result format = O.fmt (1 BF16, 0 FP32)
    output reg  [15:0]   ep_pf,
    output reg           ep_go,
    input  wire          ep_start_ready,
    input  wire          ep_done_valid,
    output reg           ep_done_ready,
    input  wire          ep_fault,
    output reg  [39:0]   ep_a_base,
    output reg  [39:0]   ep_o_base,
    // F3 (hgi-e2e): ALL_GATHER of a 32-bit format sends only the rank's even-split slice [s_r, s_{r+1}) (spec 6.7), as
    // pf = ceil(max slice / 16) flits from A + s_r; the delivery formatter maps a delivered flit (src q, gi) to the word
    // offset s_q + 16 (gi - q pf) and its valid lanes min(16, s_{q+1} - that) from the slice table written here
    output reg           ep_gslice,      // this run is a sliced gather (the delivery formatter rewrites)
    output reg  [7:0]    ep_gbase,       // the group's first rank (src - ep_gbase = q)
    output reg           gs_we,          // slice table write: s_q for q = 0 .. G
    output reg  [6:0]    gs_wa,
    output reg  [31:0]   gs_wd,          // {end (sliced) | 0, start (sliced) | gi offset (whole row)}
    output reg           ep_goff,        // whole-row gather: the formatter adds the table gi offset
    // row formatter (ot_hgi_coll_row_formatter)
    output reg           rf_start_v,
    input  wire          rf_start_r,
    output reg  [7:0]    rf_group_size,
    output reg  [7:0]    rf_owner_block,
    output reg  [7:0]    rf_destinations,
    output reg  [20:0]   rf_row_count,
    output reg  [15:0]   rf_row_words,
    output reg  [31:0]   rf_context_rows,
    input  wire          rf_done_v,
    output reg           rf_done_r,
    input  wire          rf_fault,
    // PIPE: the endpoint's pipelined start ready, the block's open-epoch state, and this go's mode
    input  wire          ep_start_ready_p,
    input  wire          pipe_room,          // fewer than EQ pipelined gathers open
    input  wire          pipe_idle,          // none open
    output reg           ep_pipe,
    // hardware ROW_GATHER (G25): endpoint mode + source / sink run configuration
    output reg           ep_rgx,
    output reg  [16:0]   ep_rgx_total,   // K * F
    output reg           rg_start,       // source and sink start (with ep_go)
    output reg  [11:0]   rg_k,
    output reg  [2:0]    rg_lb,
    output reg  [7:0]    rg_g,
    output reg  [7:0]    rg_rrel,
    output reg  [7:0]    rg_dests,
    output reg  [34:0]   rg_abase,       // A: HBM sector address
    output reg  [15:0]   rg_astride,     // A: sectors between rows
    output reg  [6:0]    rg_sec,         // S
    output reg  [5:0]    rg_nflit,       // F
    output reg  [31:0]   rg_lbase,       // I: VM 512-bit word address
    output reg  [39:0]   rg_obase,
    output reg  [31:0]   rg_ostride,
    output reg           rg_ovm,
    input  wire          rg_drained,
    // TOPK_MERGE merge sink (TKM = 1): endpoint mode + sink configuration, started with ep_go; retires when the endpoint
    // completed and the sink wrote its last O / R line (tk_done pulse, latched)
    output reg           ep_tkm,
    output reg  [39:0]   ep_b_base,      // B: VM word address of the ids (inject hi half = B + 8 f)
    output reg           tk_start,
    output reg  [11:0]   tk_n,
    output reg  [7:0]    tk_g,
    output reg  [7:0]    tk_gbase,
    output reg  [15:0]   tk_pf,
    output reg  [12:0]   tk_nout,
    output reg  [12:0]   tk_kout,        // k (the sink checks O.n = min(k, elements received))
    output reg  [39:0]   tk_obase,
    output reg  [39:0]   tk_rbase,
    output reg           tk_has_r,
    input  wire          tk_done,
    input  wire          tk_fault
);
    localparam S_IDLE = 4'd0, S_DEC = 4'd1, S_WAITDEC = 4'd2, S_EPGO = 4'd3, S_EPRUN = 4'd4, S_RFGO = 4'd5,
               S_RFRUN = 4'd6, S_HALT = 4'd7, S_DIV = 4'd8, S_TAB = 4'd9, S_NOOP = 4'd10, S_GTAB = 4'd11;
    reg [3:0] st;
    // slice computation: n div G / n mod G by restoring division (21 steps), then s_q = floor(q n / G) incrementally
    reg [20:0] dv_q, dv_r; reg [4:0] dv_i; reg [7:0] sg, sr_rel, tq; reg [15:0] s_acc; reg [7:0] s_rem; reg [15:0] s_mine;
    // record station
    reg [127:0] hdr_q;
    reg [255:0] a_q, i_q;
    reg [39:0]  o_base_q; reg [2:0] o_fmt_q; reg [1:0] o_space_q; reg [31:0] o_stride_q; reg rg_run;
    reg         in_rg_drained;
    reg [20:0]  n_a_q, n_i_q;
    reg [255:0] b_q, r_q; reg [20:0] n_b_q, n_r_q, rec_n_o_q; reg tk_run, tk_fin, in_tk_fault;
    reg [7:0]   g_q, die_q;
    reg         in_ep_fault, in_ep_done, in_ep_ready, in_rf_start_r, in_rf_done, in_rf_fault;
    reg         in_ready_p, in_room, in_idle;
    always @(posedge clk) begin
        in_ready_p <= ep_start_ready_p; in_room <= pipe_room; in_idle <= pipe_idle;
        in_ep_fault <= ep_fault; in_ep_done <= ep_done_valid; in_ep_ready <= ep_start_ready;
        in_rf_start_r <= rf_start_r; in_rf_done <= rf_done_v; in_rf_fault <= rf_fault; in_rg_drained <= rg_drained;
        g_q <= cfg_coll_group_size; if (rec_v) die_q <= cfg_die_id; in_tk_fault <= tk_fault;
    end
    assign rec_rdy = (st == S_IDLE);
    wire [6:0] opnd = hdr_q[99:93];
    // decoder (count from the I table when I's n_sel is N_FROM_VM: the sequencer resolved it into rec_n_i)
    wire        dc_cmd_r, dc_bv, dc_ev;
    wire [5:0]  dc_op;
    wire [3:0]  dc_gsz;
    wire [7:0]  dc_g, dc_rank, dc_group, dc_sub, dc_blk, dc_dest;
    wire [20:0] dc_rows;
    reg         dc_cmd_v;
    // PIPE gate: an ALL_GATHER needs a free epoch, any other op an empty pipe (classic collectives never overlap one)
    wire        gate_ok;
    ot_hgi_coll_decode #(.ENABLE(1), .HWRG(RGXHW)) u_dec (
        .clk(clk), .rst_n(rst_n), .coll_group_size(g_q), .die_id(die_q),
        .cmd_v(dc_cmd_v), .cmd_r(dc_cmd_r), .hdr(hdr_q),
        .selected_count({11'd0, n_i_q}), .selected_count_valid(opnd[6] && i_q[206:201] == 6'd63),
        .backend_v(dc_bv), .backend_r(st == S_WAITDEC && gate_ok), .backend_op(dc_op), .backend_gsz(dc_gsz),
        .backend_group_size(dc_g), .backend_rank(dc_rank), .backend_group(dc_group), .backend_subgroup(dc_sub),
        .backend_owner_block(dc_blk), .backend_destinations(dc_dest), .backend_row_count(dc_rows),
        .error_v(dc_ev), .error_r(st == S_WAITDEC));
    // A row length in 512-bit words: n * bits(fmt) / 512, rounded up
    wire [2:0]  a_fmt = a_q[4:2];
    wire [5:0]  a_bits = (a_fmt == 3'd0 || a_fmt == 3'd5) ? 6'd32 : (a_fmt == 3'd1) ? 6'd16 : (a_fmt == 3'd3) ? 6'd4 : 6'd8;
    wire [25:0] a_rowbits = n_a_q * a_bits;
    wire [16:0] a_rowwords = (a_rowbits + 26'd511) >> 9;
    wire        pf_bad = (n_a_q[3:0] != 4'd0) || (n_a_q == 21'd0) || (n_a_q[20:4] > 17'hFFFF);
    // ALL_GATHER (bypass): pf = A row bits / 512 in any element format; a partial flit or an empty row faults
    wire        pfg_bad = (a_rowbits[8:0] != 9'd0) || (n_a_q == 21'd0) || (a_rowwords > 17'hFFFF);
    // endpoint rank = the die's position on the 96-rank TU fabric (die mod 96: groups of 1..8 stay aligned)
    assign gate_ok = (PIPE == 0) || !dc_bv || ((dc_op == 6'd1) ? in_room : in_idle);
    wire [7:0]  rank96 = (die_q >= 8'd192) ? die_q - 8'd192 : (die_q >= 8'd96) ? die_q - 8'd96 : die_q;
    // GROUP_REDUCE_MCAST: the endpoint's gsz is the reduction sub-group s (2 / 4 / 8), the outer group is G
    wire [3:0]  sub_gsz = (dc_sub == 8'd2) ? 4'd1 : (dc_sub == 8'd4) ? 4'd2 : 4'd3;
    // G25 hardware ROW_GATHER: B a power of two <= 128, K <= 2,048, A in HBM (32 B aligned, stride a 32 B multiple, S <= 64
    // sectors a row), I in VM (16-word aligned), O in HBM (64 B aligned rows) or VM (16-word aligned rows)
    wire        hwrg = (RGXHW != 0) && hdr_q[72];
    wire [2:0]  blg = dc_blk[7] ? 3'd7 : dc_blk[6] ? 3'd6 : dc_blk[5] ? 3'd5 : dc_blk[4] ? 3'd4 : dc_blk[3] ? 3'd3 :
                      dc_blk[2] ? 3'd2 : dc_blk[1] ? 3'd1 : 3'd0;
    wire [16:0] a_secs = 17'((a_rowbits + 26'd255) >> 8);
    wire [31:0] a_stride_b = a_q[119:88];
    wire [5:0]  rg_f = 6'((a_secs + 17'd1) >> 1);
    wire        rg_bad = (dc_blk & (dc_blk - 8'd1)) != 8'd0 || dc_rows == 21'd0 || dc_rows > 21'd2048 ||
                         a_q[1:0] != 2'd0 || a_q[12:8] != 5'd0 || a_stride_b[4:0] != 5'd0 || a_stride_b[31:21] != 11'd0 ||
                         n_a_q == 21'd0 || a_secs > 17'd64 || i_q[1:0] != 2'd1 || i_q[11:8] != 4'd0 ||
                         !(o_space_q == 2'd0 || o_space_q == 2'd1) || (o_space_q == 2'd0 ? o_base_q[5:0] != 6'd0 : o_base_q[3:0] != 4'd0);
    // TOPK_MERGE (TKM): A FP32 / B U32 in VM, 8-word aligned, n_A = n_B in 1 .. 2048; O U32 (R FP32) in VM, 16-word aligned;
    // k = imm_a in 1 .. TKM_KMAX.  param[11:0] = M, the group's per-rank stream length (0: this rank's n); every rank
    // streams pf = ceil(M / 8) flits (its n elements, then pad slots), so ranks with different n (the DS candidate merge:
    // 341 / 342 owned blocks) share one flit count; n > M faults.  O.n (and R.n) must equal min(k, the group's total n):
    // the sink checks it against the elements it received.
    wire [31:0] tk_k = hdr_q[63:32];
    wire        tk_hr = opnd[5];
    wire [11:0] tk_m = hdr_q[75:64];
    wire [11:0] tk_mx = (tk_m == 12'd0) ? n_a_q[11:0] : tk_m;
    wire [18:0] tk_gn = 19'(dc_g) * 19'(tk_mx);
    wire [18:0] tk_cap = (19'(tk_k[12:0]) < tk_gn) ? 19'(tk_k[12:0]) : tk_gn;
    wire        tk_bad = !opnd[1] || a_q[1:0] != 2'd1 || a_q[4:2] != 3'd0 || b_q[1:0] != 2'd1 || b_q[4:2] != 3'd5 ||
                         o_space_q != 2'd1 || o_fmt_q != 3'd5 || (tk_hr && (r_q[1:0] != 2'd1 || r_q[4:2] != 3'd0)) ||
                         a_q[10:8] != 3'd0 || b_q[10:8] != 3'd0 || o_base_q[3:0] != 4'd0 || (tk_hr && r_q[11:8] != 4'd0) ||
                         n_a_q == 21'd0 || n_a_q > 21'd2048 || n_b_q != n_a_q || tk_k == 32'd0 || tk_k > 32'(TKM_KMAX) ||
                         hdr_q[88:76] != 13'd0 || (tk_m != 12'd0 && (21'(tk_m) < n_a_q || tk_m > 12'd2048)) ||
                         dc_g == 8'd0 || dc_g > 8'd96 || rec_n_o_q == 21'd0 || 19'(rec_n_o_q) > tk_cap ||
                         (tk_hr && n_r_q != rec_n_o_q);
    // ---- quadrant quarter arithmetic (exact; every die computes the same split) ------------------------------------
    reg  [1:0]  qid_q; always @(posedge clk) qid_q <= qid ^ ((MUT_Q != 0) ? 2'd1 : 2'd0);   // strap, captured
    wire [2:0]  q0 = {1'b0, qid_q}, q1 = {1'b0, qid_q} + 3'd1;
    // reductions: units of 16 flits, remainder in quarter 3
    wire [15:0] r_pf  = n_a_q[19:4];
    wire [11:0] r_u   = r_pf[15:4];
    wire [15:0] r_lo  = {12'(14'(r_u * q0) >> 2), 4'd0};
    wire [15:0] r_hi  = (qid_q == 2'd3) ? r_pf : {12'(14'(r_u * q1) >> 2), 4'd0};
    wire [15:0] r_pfq = r_hi - r_lo;
    // whole-row gathers: flits [floor(q pf / 4), floor((q + 1) pf / 4))
    wire [15:0] w_pf  = a_rowwords[15:0];
    wire [15:0] w_lo  = 16'(18'(w_pf * q0) >> 2);
    wire [15:0] w_hi  = 16'(18'(w_pf * q1) >> 2);
    wire [15:0] w_pfq = w_hi - w_lo;
    // sliced gathers: sub-slice of a rank slice of length L
    function automatic [15:0] sub_lo(input [15:0] L, input [2:0] k); sub_lo = 16'(19'(L * k) >> 2); endfunction
    wire [15:0] s_l0  = dv_q[15:0], s_l1 = dv_q[15:0] + ((dv_r != 21'd0) ? 16'd1 : 16'd0);
    wire [15:0] s_m0  = sub_lo(s_l0, q1) - sub_lo(s_l0, q0), s_m1 = sub_lo(s_l1, q1) - sub_lo(s_l1, q0);
    wire [15:0] s_max = (s_m1 > s_m0) ? s_m1 : s_m0;
    wire        solo  = (SOLO_CAP != 0) && (qid_q == 2'(QSOLO));
    reg  [15:0] g_acc, g_dlt;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st <= S_IDLE; ep_goff <= 1'b0; g_acc <= 16'd0; g_dlt <= 16'd0; dc_cmd_v <= 1'b0; rec_done <= 1'b0; rec_fault <= 1'b0;
            ep_go <= 1'b0; ep_done_ready <= 1'b0; rf_start_v <= 1'b0; rf_done_r <= 1'b0; ep_pipe <= 1'b0;
            ep_rank <= 8'd0; ep_mcast_group_size <= 8'd96; ep_mcast_all <= 1'b0; ep_gsz <= 4'hF; ep_pf <= 16'd0; ep_byp <= 1'b0; ep_amx <= 1'b0; ep_bf16 <= 1'b1;
            ep_a_base <= 40'd0; ep_o_base <= 40'd0; ep_gslice <= 1'b0; ep_gbase <= 8'd0; gs_we <= 1'b0;
            rf_group_size <= 8'd96; rf_owner_block <= 8'd8; rf_destinations <= 8'd0; rf_row_count <= 21'd0;
            rf_row_words <= 16'd0; rf_context_rows <= 32'd0;
            hdr_q <= 128'd0; a_q <= 256'd0; i_q <= 256'd0; o_base_q <= 40'd0; n_a_q <= 21'd0; n_i_q <= 21'd0;
            o_space_q <= 2'd0; o_stride_q <= 32'd0; rg_run <= 1'b0; ep_rgx <= 1'b0; ep_rgx_total <= 17'd0; rg_start <= 1'b0;
            rg_k <= 12'd1; rg_lb <= 3'd0; rg_g <= 8'd96; rg_rrel <= 8'd0; rg_dests <= 8'd0; rg_abase <= 35'd0; rg_astride <= 16'd0;
            rg_sec <= 7'd1; rg_nflit <= 6'd1; rg_lbase <= 32'd0; rg_obase <= 40'd0; rg_ostride <= 32'd0; rg_ovm <= 1'b0;
            b_q <= 256'd0; r_q <= 256'd0; n_b_q <= 21'd0; n_r_q <= 21'd0; rec_n_o_q <= 21'd0; tk_run <= 1'b0; tk_fin <= 1'b0;
            ep_tkm <= 1'b0; ep_b_base <= 40'd0; tk_start <= 1'b0; tk_n <= 12'd1; tk_g <= 8'd1; tk_gbase <= 8'd0; tk_pf <= 16'd1;
            tk_nout <= 13'd1; tk_kout <= 13'd1; tk_obase <= 40'd0; tk_rbase <= 40'd0; tk_has_r <= 1'b0;
        end else begin
            rec_done <= 1'b0; rec_fault <= 1'b0; ep_go <= 1'b0; ep_done_ready <= 1'b0; rf_done_r <= 1'b0; gs_we <= 1'b0; rg_start <= 1'b0;
            tk_start <= 1'b0;
            if (tk_done) tk_fin <= 1'b1;
            case (st)
                S_IDLE: if (rec_v) begin
                    hdr_q <= rec_hdr; a_q <= rec_a; i_q <= rec_i; o_base_q <= rec_o[47:8]; o_fmt_q <= rec_o[4:2];
                    o_space_q <= rec_o[1:0]; o_stride_q <= rec_o[119:88];
                    n_a_q <= rec_n_a; n_i_q <= rec_n_i; st <= S_DEC;
                    b_q <= rec_b; r_q <= rec_r; n_b_q <= rec_n_b; n_r_q <= rec_n_r; rec_n_o_q <= rec_n_o;
                end
                S_DEC: begin dc_cmd_v <= 1'b1; if (dc_cmd_v && dc_cmd_r) begin dc_cmd_v <= 1'b0; st <= S_WAITDEC; end end
                S_WAITDEC: if (dc_ev) begin rec_fault <= 1'b1; st <= S_HALT; end
                    else if (dc_bv && gate_ok) begin
                        ep_pipe <= (PIPE != 0) && (dc_op == 6'd1);
                        ep_goff <= 1'b0;
                        ep_rgx <= 1'b0; rg_run <= 1'b0; ep_tkm <= 1'b0; tk_run <= 1'b0; tk_fin <= 1'b0;
                        if (dc_op == 6'd5 && hwrg) begin    // G25: one collective, no loop
                            if (rg_bad) begin rec_fault <= 1'b1; st <= S_HALT; end
                            else if (!solo) begin ep_pipe <= 1'b0; st <= S_NOOP; end   // quadrant: run whole on QSOLO
                            else begin
                                ep_rank <= rank96; ep_byp <= 1'b1; ep_amx <= 1'b0; ep_gslice <= 1'b0; ep_rgx <= 1'b1; rg_run <= 1'b1;
                                ep_gsz <= (dc_g == 8'd96) ? 4'd3 : dc_gsz; ep_mcast_all <= (dc_g == 8'd96);
                                ep_mcast_group_size <= dc_g; ep_pf <= 16'd1;
                                ep_rgx_total <= 17'(dc_rows) * 17'(rg_f);
                                rg_k <= 12'(dc_rows); rg_lb <= blg; rg_g <= dc_g; rg_rrel <= dc_rank; rg_dests <= dc_dest;
                                rg_abase <= 35'(a_q[47:8] >> 5); rg_astride <= 16'(a_stride_b >> 5); rg_sec <= 7'(a_secs); rg_nflit <= rg_f;
                                rg_lbase <= 32'(i_q[47:8] >> 4);
                                rg_obase <= o_base_q; rg_ostride <= o_stride_q; rg_ovm <= (o_space_q == 2'd1);
                                st <= S_EPGO;
                            end
                        end else if (dc_op == 6'd0 || dc_op == 6'd4) begin
                            if (pf_bad || (o_fmt_q != 3'd0 && o_fmt_q != 3'd1)) begin rec_fault <= 1'b1; st <= S_HALT; end   // O FP32 / BF16 only
                            else begin
                                ep_rank <= rank96; ep_gsz <= (dc_op == 6'd4) ? sub_gsz : dc_gsz; ep_mcast_all <= (dc_op == 6'd4);
                                ep_mcast_group_size <= dc_g; ep_byp <= 1'b0; ep_amx <= 1'b0; ep_bf16 <= (o_fmt_q == 3'd1); ep_gslice <= 1'b0;
                                ep_pf <= MUT_PF ? n_a_q[15:0] : r_pfq;
                                ep_a_base <= a_q[47:8] + {20'd0, r_lo, 4'd0};
                                ep_o_base <= o_base_q + ((o_fmt_q == 3'd1) ? {21'd0, r_lo, 3'd0} : {20'd0, r_lo, 4'd0});
                                // result gi offset per reduction group g (src = OG): g (pf - pf_q) (/ 2 for BF16); the
                                // central result index of group g's owner J is (g NA + J) ROF, the quarter's (g NA + J) ROF_q
                                ep_goff <= 1'b1; ep_gbase <= 8'd0; tq <= 8'd0; g_acc <= 16'd0;
                                g_dlt <= (o_fmt_q == 3'd1) ? ((r_pf - r_pfq) >> 1) : (r_pf - r_pfq);
                                begin : ng
                                    reg [3:0] lg; lg = (dc_op == 6'd4) ? sub_gsz : dc_gsz;
                                    sg <= (lg == 4'hF) ? 8'd12 : (8'd96 >> lg[1:0]);   // groups on the 96-rank fabric
                                end
                                st <= (r_pfq == 16'd0) ? S_NOOP : S_GTAB;
                            end
                        end else if (dc_op == 6'd1 && a_bits == 6'd32 && MUT_SLICE == 0) begin   // F3: sliced gather
                            if (n_a_q == 21'd0 || n_a_q > 21'd65535 || dc_g == 8'd0 || dc_g > 8'd96) begin rec_fault <= 1'b1; st <= S_HALT; end
                            else begin
                                ep_rank <= rank96; ep_byp <= 1'b1; ep_amx <= 1'b0; ep_gslice <= 1'b1;
                                ep_gsz <= (dc_g == 8'd96) ? 4'd3 : dc_gsz; ep_mcast_all <= (dc_g == 8'd96);
                                ep_mcast_group_size <= dc_g; ep_o_base <= o_base_q;
                                ep_gbase <= (dc_g == 8'd96) ? 8'd0 : (rank96 & ~(dc_g - 8'd1));
                                sg <= dc_g; sr_rel <= (dc_g == 8'd96) ? rank96 : (rank96 & (dc_g - 8'd1));
                                dv_q <= 21'd0; dv_r <= 21'd0; dv_i <= 5'd20; st <= S_DIV;
                            end
                        end else if (dc_op == 6'd1) begin   // ALL_GATHER: exact bypass over the group (G = 96: outer group)
                            if (pfg_bad) begin rec_fault <= 1'b1; st <= S_HALT; end
                            else begin
                                ep_gslice <= 1'b0;
                                ep_rank <= rank96; ep_byp <= 1'b1; ep_amx <= 1'b0;
                                ep_gsz <= (dc_g == 8'd96) ? 4'd3 : dc_gsz; ep_mcast_all <= (dc_g == 8'd96);
                                ep_mcast_group_size <= dc_g;
                                ep_pf <= MUT_PF ? n_a_q[15:0] : w_pfq;
                                ep_a_base <= a_q[47:8] + {20'd0, w_lo, 4'd0}; ep_o_base <= o_base_q;
                                // gi offset table: rank r -> r (pf - pf_q) + lo (the global flit index of its quarter)
                                ep_goff <= 1'b1; ep_gbase <= (dc_g == 8'd96) ? 8'd0 : (rank96 & ~(dc_g - 8'd1));
                                sg <= dc_g; tq <= 8'd0; g_acc <= w_lo; g_dlt <= w_pf - w_pfq;
                                st <= (w_pfq == 16'd0) ? S_NOOP : S_GTAB;
                            end
                        end else if (dc_op == 6'd5 && RFMT == 0) begin rec_fault <= 1'b1; st <= S_HALT;
                        end else if (dc_op == 6'd5) begin
                            rf_group_size <= dc_g; rf_owner_block <= dc_blk; rf_destinations <= dc_dest;
                            rf_row_count <= dc_rows; rf_row_words <= a_rowwords[15:0];
                            rf_context_rows <= {12'd0, a_q[87:68]}; rf_start_v <= 1'b1; st <= S_RFGO;
                        end else if (dc_op == 6'd3) begin   // ARGMAX_MERGE: A = {value FP32, id U32}: one flit a rank
                            if (n_a_q != 21'd2) begin rec_fault <= 1'b1; st <= S_HALT; end
                            else if (!solo) st <= S_NOOP;
                            else begin
                                ep_rank <= rank96; ep_byp <= 1'b1; ep_amx <= 1'b1; ep_gslice <= 1'b0;
                                ep_gsz <= (dc_g == 8'd96) ? 4'd3 : dc_gsz; ep_mcast_all <= (dc_g == 8'd96);
                                ep_mcast_group_size <= dc_g; ep_pf <= 16'd1;
                                ep_a_base <= a_q[47:8]; ep_o_base <= o_base_q; st <= S_EPGO;
                            end
                        end else if (dc_op == 6'd2 && TKM != 0) begin   // TOPK_MERGE on the merge sink (gather bypass)
                            if (tk_bad) begin rec_fault <= 1'b1; st <= S_HALT; end
                            else if (!solo) begin ep_pipe <= 1'b0; st <= S_NOOP; end
                            else begin
                                ep_rank <= rank96; ep_byp <= 1'b1; ep_amx <= 1'b0; ep_gslice <= 1'b0; ep_tkm <= 1'b1; tk_run <= 1'b1;
                                ep_gsz <= (dc_g == 8'd96) ? 4'd3 : dc_gsz; ep_mcast_all <= (dc_g == 8'd96);
                                ep_mcast_group_size <= dc_g;
                                ep_pf <= 16'((tk_mx + 12'd7) >> 3);
                                ep_a_base <= a_q[47:8]; ep_b_base <= b_q[47:8]; ep_o_base <= o_base_q;
                                tk_n <= n_a_q[11:0]; tk_g <= dc_g; tk_gbase <= (dc_g == 8'd96) ? 8'd0 : (rank96 & ~(dc_g - 8'd1));
                                tk_pf <= 16'((tk_mx + 12'd7) >> 3); tk_nout <= 13'(rec_n_o_q); tk_kout <= 13'(tk_k[12:0]); tk_obase <= o_base_q;
                                tk_rbase <= r_q[47:8]; tk_has_r <= tk_hr;
                                st <= S_EPGO;
                            end
                        end else begin rec_fault <= 1'b1; st <= S_HALT; end   // op 2 (TOPK_MERGE) without the merge sink (TKM = 0)
                    end
                S_DIV: begin : div                  // restoring division n / G, one quotient bit a cycle (MSB first)
                    reg [21:0] t_;
                    t_ = {dv_r, n_a_q[dv_i]};
                    if (t_ >= {14'd0, sg}) begin dv_r <= 21'(t_ - {14'd0, sg}); dv_q[dv_i] <= 1'b1; end
                    else dv_r <= t_[20:0];
                    if (dv_i == 5'd0) begin st <= S_TAB; tq <= 8'd0; s_acc <= 16'd0; s_rem <= 8'd0; end
                    else dv_i <= dv_i - 5'd1;
                end
                S_TAB: begin : tab                  // s_tq written; s_{tq+1} = s_tq + (n div G) + carry(rem + n mod G >= G)
                    reg [8:0] r2; reg [15:0] ln, st_, en_;
                    r2 = {1'b0, s_rem} + {1'b0, dv_r[7:0]};
                    ln = (r2 >= {1'b0, sg}) ? dv_q[15:0] + 16'd1 : dv_q[15:0];   // len of rank tq's slice
                    st_ = s_acc + sub_lo(ln, q0); en_ = s_acc + sub_lo(ln, q1);
                    gs_we <= 1'b1; gs_wa <= tq[6:0]; gs_wd <= {en_, st_};
                    if (tq == sr_rel) s_mine <= st_;
                    if (r2 >= {1'b0, sg}) begin s_rem <= 8'(r2 - {1'b0, sg}); s_acc <= s_acc + dv_q[15:0] + 16'd1; end
                    else begin s_rem <= r2[7:0]; s_acc <= s_acc + dv_q[15:0]; end
                    if (tq == sg) begin
                        // pf = ceil(ceil(n / G) / 16); the slice starts at A + s_r
                        ep_pf <= 16'((s_max + 16'd15) >> 4);
                        ep_a_base <= a_q[47:8] + {24'd0, s_mine};   // rank sr_rel < sg: s_mine already written
                        st <= (s_max == 16'd0) ? S_NOOP : S_EPGO;
                    end else tq <= tq + 8'd1;
                end
                S_GTAB: begin                       // whole-row gather gi offsets, one rank a cycle
                    gs_we <= 1'b1; gs_wa <= tq[6:0]; gs_wd <= {16'd0, g_acc}; g_acc <= g_acc + g_dlt;
                    if (tq + 8'd1 == sg) st <= S_EPGO; else tq <= tq + 8'd1;
                end
                S_NOOP: if (in_ep_fault) begin rec_fault <= 1'b1; st <= S_HALT; end
                    else if (in_idle && in_ep_ready) begin ep_pipe <= 1'b0; rec_done <= 1'b1; st <= S_IDLE; end
                S_EPGO: if (in_ep_fault) begin rec_fault <= 1'b1; st <= S_HALT; end
                    else if (ep_pipe && in_ready_p && !ep_go) begin
                        ep_go <= 1'b1; st <= S_IDLE;           // the block retires it (in order) when its epoch completes
                    end
                    else if (!ep_pipe && in_ep_ready && (!rg_run || in_rg_drained)) begin
                        ep_go <= 1'b1; rg_start <= rg_run; tk_start <= tk_run;
                        if (MUT_DONE) begin rec_done <= 1'b1; st <= S_IDLE; end else st <= S_EPRUN;
                    end
                S_EPRUN: if (in_ep_fault || (tk_run && in_tk_fault)) begin rec_fault <= 1'b1; st <= S_HALT; end
                    else if (in_ep_done && !ep_done_ready && (!rg_run || (in_rg_drained && rg_drained)) && (!tk_run || tk_fin)) begin
                        ep_done_ready <= 1'b1; rec_done <= 1'b1; st <= S_IDLE;
                    end
                S_RFGO: if (in_rf_start_r) begin rf_start_v <= 1'b0; st <= S_RFRUN; end
                S_RFRUN: if (in_rf_done && !rf_done_r) begin
                        rf_done_r <= 1'b1;
                        if (in_rf_fault) begin rec_fault <= 1'b1; st <= S_HALT; end
                        else begin rec_done <= 1'b1; st <= S_IDLE; end
                    end
                S_HALT: ;   // sticky: the CP halts; only rst_n (drained reset) leaves
                default: st <= S_HALT;
            endcase
        end
    end
endmodule
