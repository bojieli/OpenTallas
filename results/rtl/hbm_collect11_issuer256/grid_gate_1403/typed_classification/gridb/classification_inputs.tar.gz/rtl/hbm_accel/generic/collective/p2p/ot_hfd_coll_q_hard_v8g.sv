`timescale 1ns/1ps
`default_nettype none
// HBM-COLLQ (10-18): d4g COLL quadrant parents with the gather-capable ring A. Successors of ot_hfd_coll_q3_hard_v7x
// (SW) and ot_hfd_coll_q2_hard_v5 (SE/NW/NE), generated from ot_hfd_coll_q_hard_v5.sv (body text identical except the
// ring): u_ring = ot_hgi_coll_ring_ag #(SPLIT_CLOCKS 1, AG 1) (RTL3: at AG=0 behaviour cycle/bit-identical to
// ring_v5); its command ports come in on ra_* from the per-quadrant gather master's ring-A merge register
// (ot_hgi_coll_gq_issue), which receives this parent's ISA ring fields on isa_ring (= p_ring[57:0]) and lp data on
// isa_lp_data (= rc_d) and returns them +2 edges later, OR the gather fields. Ring gather publishes leave on ag_*.
// COMPILER: every ISA ring-A command (lp / state reads / adds / inject / forward / rx / rr_local) and its rc_d take
// effect 2 edges later than on v5: every ring-A-relative constant (rr_v / rr_d to the SU, carry / result timing) +2.
// Children, clocks, every other port and edge: unchanged (wires only).
// XDIE-HBM4 (10-19), both default 0/64 = the closed v8g (no new flop, every port and edge unchanged):
//  AR_ITER=1: iterated reduce tags. The reserved uop field ring[87:84] (word[717:714]) becomes iter_ar_tag_step: the
//    reduce load/read/publication tags advance by (iteration x step) mod 16 and the publication index by iteration x step
//    (16 b), so a loop body streams frames through the reduce engine like the AG LOOPS stream link sequences / VM sectors
//    / delivery offsets (static schedule; no credits / backpressure). The products are formed from the d2 stream and the
//    issuer's iteration delayed 2 edges and registered at the d3 edge (the edge every AR field already uses); the ctl
//    leaf sees the step bits as 0 (its reserved-field fault is unchanged).
//  ROWS=128: static_issuer_v6 / programme target with 128 rows (7-bit pc; see ot_hgi_coll_static_issuer_v6).
module ot_hfd_coll_q_hard_v8g_body #(
 parameter integer NPT=3,SOLO=1,TP=96,AR_ITER=0,ROWS=64,PW=(ROWS>128)?8:(ROWS>64)?7:6,
 parameter integer NS=(SOLO!=0)?NPT+8:NPT+7,ND=NPT+13,NSL=18,NCK=NS+NSL,
 // HBM-BANKLAT-COLL 10-19: VM_RT = VM read edges beyond the fixed n+8 capture (d4g VM faces bank pin + die lanes + COLL
 // read share hcollrs_<q>, padded by the die to this scalar budget). 0 = the v8 parent, identical hierarchy and edges
 // (protocol leaf ot_hgi_coll_ctl_v5_*, vm_sel from the uop pipe d3). VM_RT > 0: protocol leaf ot_hgi_coll_ctl_v5r_*
 // #(VM_RT) (valid check / select / metadata +VM_RT) and vm_sel = its vm_sel_d (select delayed VM_RT edges, flop Q);
 // the 16 vmasm slices are unchanged. COMPILER: every COLL VM read request leads its capture by 10 + VM_RT instruction
 // edges (was 10): tools/hbm_coll_static/row_gather_rows.py --vm-rt.
 parameter integer VM_RT=0
)(
 input wire rst_n,
 input wire [1:0] qid,
 input wire clk_program,clk_control,
 input wire [15:0] clk_vmasm,           // V7: 16 VM read-data assembly slice leaves (ot_hgi_coll_vmasm_slice16), one entry each
 input wire [15:0] clk_upipe,           // V7: 16 issue-stream delay slice leaves (ot_hgi_coll_uop_slice96), one entry each
 input wire clk_issue,
 input wire [NCK-1:0] clk_qslots,       // [NS-1:0] capture leaves, [NCK-1:NS] switch slices
 input wire [16:0] clk_ring,
 input wire [32:0] clk_reduce,
 input wire clk_arg,
 input wire [15:0] clk_vmwrite,         // v6 writer: rgx_data0..3, rgx_ctrl, tkw, meta, body, bank0..7
 input wire [5*NPT-1:0] clk_link,
 input wire cfg_v,input wire [7:0] cfg_target,input wire [11:0] cfg_addr,input wire [255:0] cfg_data,
 input wire desc_v,input wire [11:0] desc_base,input wire [12:0] desc_limit,input wire [15:0] desc_loops,
 input wire launch_v,
 output wire program_configured,program_init_busy,program_fault,
 output wire hgi_busy,hgi_done,hgi_fault,
 output wire [1:0] inj_rd,output wire [31:0] inj_idx,output wire [159:0] hgi_inj_addr,input wire [1023:0] inj_d,
 output wire [3:0] del_valid,output wire [2179:0] del_flit,output wire [159:0] hgi_del_obase,
 input wire rc_v,input wire [2:0] rc_tag,input wire [255:0] rc_d,
 output wire rr_v,output wire [2:0] rr_tag,output wire [255:0] rr_d,
 input wire [NPT-1:0] phy_up,output wire [NPT-1:0] tx_pin_v,output wire [NPT*612-1:0] tx_pin_flit,
 input wire [NPT-1:0] rx_pin_v,input wire [NPT*612-1:0] rx_pin_flit,output wire [NPT-1:0] retry_requested,
 input wire [279:0] pr_cw_i,pr_ccw_i,output wire [279:0] pr_cw_o,pr_ccw_o,

 // v8g (HBM-COLLQ): ring A = ot_hgi_coll_ring_ag (gather-capable successor of ring_v5, AG=0 behaviour identical); its
 // command ports are driven by the quadrant gather master's ring-A merge register (die instance hcollgi_<q>), which takes
 // this parent's ISA ring fields + lp data and adds 2 edges; the ring's gather publishes leave on ag_*.
 output wire [57:0] isa_ring,output wire [255:0] isa_lp_data,
 input wire ra_lp_we,input wire [2:0] ra_lp_tag,input wire [255:0] ra_lp_data,
 input wire ra_state_read_add,ra_state_read_tx,ra_state_read_rr,input wire [2:0] ra_state_add_tag,ra_state_tx_tag,ra_state_rr_tag,
 input wire [1:0] ra_state_add_src,input wire ra_state_add_rhs_acc,ra_state_tx_acc,ra_add_v,input wire [2:0] ra_add_tag,
 input wire [1:0] ra_add_src,input wire ra_add_rhs_acc,input wire [1:0] ra_tx_inject,ra_tx_forward,input wire [2:0] ra_tx_tag,
 input wire [1:0] ra_tx_dst,input wire ra_tx_result,ra_tx_acc,ra_tx_gather,input wire [3:0] ra_tx_ttl,
 input wire [1:0] ra_rx_slot,input wire [3:0] ra_rx_kind,ra_rx_src,input wire [5:0] ra_rx_tag,input wire ra_rr_local,
 input wire [2:0] ra_rr_local_tag,
 output wire [1:0] ag_v,output wire [3:0] ag_src,output wire [5:0] ag_tag,output wire [511:0] ag_d,
 output wire [135:0] vm_rq,input wire [2055:0] vm_rr,output wire [2247:0] vm_kq,
 // TKM interface (d4f H-DIE 10-17: TKM hoisted to its own die sub-cluster tkm_SW; q3_hard_v5 keeps it inside)
 output wire tkx_start,tkx_arg_mode,output wire [11:0] tkx_cfg_n,output wire [12:0] tkx_cfg_k,tkx_cfg_nout,
 output wire [7:0] tkx_cfg_g,tkx_cfg_gbase,output wire [15:0] tkx_cfg_pf,output wire [39:0] tkx_cfg_obase,tkx_cfg_rbase,
 output wire tkx_cfg_has_r,output wire [3:0] tkx_del_slot,tkx_del_valid,output wire [2179:0] tkx_del_flit,
 input wire tkx_w_v,input wire [39:0] tkx_w_addr,input wire [15:0] tkx_w_mask,input wire [511:0] tkx_w_data,
 input wire tkx_busy,tkx_done,tkx_fault,
 output wire fault,output wire [15:0] fault_cause,output wire done,output wire [31:0] stat_cycles
);
 localparam integer PWT=545,SELW=4;
 // ---- issuer + programme target + fault join
 wire [36:0] program_cfg;wire hgi_start;wire [PW-1:0] hgi_start_pc;
 wire issue_fault,issue_done,uop_v;wire [1535:0] inst,inst_d1,inst_d2;wire [PW-1:0] uop_pc;wire busy_d2,start_d3;
 wire issue_busy_raw,issue_done_raw,start_d2;wire [31:0] tap_iteration;wire [87:0] tap_steps;
 // HBM-COLL256-KITS (10-19): ROWS 256 binds the safe 256-row issuer leaf ot_hgi_coll_issuer_m256 (v7 core: SRAM metadata
 // lookahead, 2 x 256x256 per bank); ROWS 64/128 keep ot_hgi_coll_issuer_m (v6). Same ports and edges.
 generate if(ROWS>128)begin:g_iss256
 // Default-off source variant: true 256-row native32 leaf; same cfg37 and edge contract.
`ifdef OT_COLL_ISSUER256_NATIVE32
 ot_hgi_coll_issuer_m256v8
`else
 ot_hgi_coll_issuer_m256
`endif
 u_issuer(.clk_control(clk_issue),.rst_n(rst_n),
  .cfg(program_cfg),.start(hgi_start),.start_pc(hgi_start_pc),.busy(issue_busy_raw),.done(issue_done_raw),
  .fault(issue_fault),.uop_v(uop_v),.uop_pc(uop_pc),.uop_d1(inst_d1),.busy_d3(hgi_busy),.done_d3(issue_done),
  .start_d3(start_d3),.busy_d2(busy_d2),.start_d2(start_d2),.tap_iteration(tap_iteration),.tap_steps(tap_steps));
 end else begin:g_iss
 ot_hgi_coll_issuer_m #(.ROWS(ROWS)) u_issuer(.clk_control(clk_issue),.rst_n(rst_n),
  .cfg(program_cfg),.start(hgi_start),.start_pc(hgi_start_pc),.busy(issue_busy_raw),.done(issue_done_raw),
  .fault(issue_fault),.uop_v(uop_v),.uop_pc(uop_pc),.uop_d1(inst_d1),.busy_d3(hgi_busy),.done_d3(issue_done),
  .start_d3(start_d3),.busy_d2(busy_d2),.start_d2(start_d2),.tap_iteration(tap_iteration),.tap_steps(tap_steps));
 end endgenerate
 // V7 compact slices (Codex a08f80c6e/b1c5ffa0e; grant coll_slice_geometry_grant_1552): 16 x 96-bit hard leaves, same
 // d1 -> d2 -> d3 edges as ot_hgi_coll_uop_pipe (monolithic V6b leaf native FAIL L303.8/C372.4).
 ot_hgi_coll_upipe_sliced_v7 u_upipe(.clk(clk_upipe),.d1(inst_d1),.d2(inst_d2),.d3(inst));
 assign hgi_done=issue_done;assign done=issue_done;assign hgi_fault=fault;
 // ---- ISA fields (wires; identical positions to ot_hfd_coll_q_static_v4)
 wire [9:0] p_capture_slot=inst[0+:10];
 wire [15:0] p_sink_slot=inst[10+:16];
 wire [63:0] p_sink_select=inst[26+:64];
 wire [2:0] p_lk_wr_v=inst[350+:3],p_lk_rd_v=inst[371+:3],p_lk_rx_expect=inst[392+:3],p_lk_epoch_begin=inst[413+:3];
 wire [7:0] p_lk_epoch=inst[416+:8];
 wire p_rgx_vm=inst[584];
 wire [4:0] p_vm_ingress_slot=inst[585+:5];
 wire [7:0] p_vm_slot_valid=inst[590+:8];
 wire [31:0] p_vm_slot_owner=inst[598+:32];
 wire [87:0] p_ring=inst[630+:88];
 wire p_tkm_start=inst[718];
 wire [3:0] p_tkm_del_slot=inst[719+:4];
 wire [11:0] p_tkm_cfg_n=inst[723+:12];
 wire [12:0] p_tkm_cfg_k=inst[735+:13],p_tkm_cfg_nout=inst[748+:13];
 wire [7:0] p_tkm_cfg_g=inst[761+:8],p_tkm_cfg_gbase=inst[769+:8];
 wire [15:0] p_tkm_cfg_pf=inst[777+:16];
 wire [39:0] p_tkm_cfg_obase=inst[793+:40],p_tkm_cfg_rbase=inst[833+:40];
 wire p_tkm_cfg_has_r=inst[873];
 wire [30:0] p_ar_low=inst[1505+:31];
 wire [54:0] ar={p_ring[81:58],p_ar_low};
 wire a_load_v=ar[0];wire a_add_read=ar[5];wire [3:0] a_load_tag,a_read_tag,a_pub_tag_a,a_pub_tag_b;wire [15:0] a_pub_index;
 wire a_add_issue=ar[10];wire a_pub_read=ar[11];
 // ---- XDIE-HBM4 AR_ITER: iterated reduce tags (d2 fields + iteration_d2 x step, registered at d3)
 wire [1535:0] inst_ctl;
 generate if(AR_ITER!=0)begin:g_ariter
  reg [15:0] it_d1,it_d2;reg [3:0] t_load,t_read,t_pa,t_pb;reg [15:0] t_idx;
  wire [54:0] ar2={inst_d2[688+:24],inst_d2[1505+:31]};wire [3:0] st2=inst_d2[714+:4];
  wire [19:0] prod=it_d2*st2;
  always @(posedge clk_issue)begin it_d1<=tap_iteration[15:0];it_d2<=it_d1;end
  always @(posedge clk_reduce[0])begin
`ifdef OT_COLL_ARITER_MUT_NOSTEP
   t_load<=ar2[1+:4];t_read<=ar2[6+:4];t_pa<=ar2[12+:4];t_pb<=ar2[16+:4];t_idx<=ar2[31+:16];
`else
   t_load<=ar2[1+:4]+prod[3:0];t_read<=ar2[6+:4]+prod[3:0];t_pa<=ar2[12+:4]+prod[3:0];t_pb<=ar2[16+:4]+prod[3:0];
   t_idx<=ar2[31+:16]+prod[15:0];
`endif
  end
  assign a_load_tag=t_load;assign a_read_tag=t_read;assign a_pub_tag_a=t_pa;assign a_pub_tag_b=t_pb;assign a_pub_index=t_idx;
  assign inst_ctl={inst_d2[1535:718],4'b0,inst_d2[713:0]};
 end else begin:g_arfix
  assign a_load_tag=ar[1+:4];assign a_read_tag=ar[6+:4];assign a_pub_tag_a=ar[12+:4];assign a_pub_tag_b=ar[16+:4];
  assign a_pub_index=ar[31+:16];assign inst_ctl=inst_d2;
 end endgenerate
 wire a_pub_bf16=ar[20],a_pub_release=ar[21],a_pub_issue=ar[22];wire [7:0] a_pub_src=ar[23+:8];
 wire a_arg_mode=ar[47],a_arg_start=ar[48],a_arg_flush=ar[49],a_arg_publish=ar[50];
 wire [3:0] a_arg_in_slot=ar[51+:4];
 // ---- protocol leaf
 wire [135:0] vm_req_pin;wire [1:0] inj_req_pin,inj_source_v;wire [31:0] inj_idx_pin;
 wire [159:0] inj_addr_pin,delivery_obase_pin,rgx_addr_pin;wire [65:0] inj_source_meta;wire [131:0] vm_source_meta;
 wire [2047:0] vm_assembled;wire [3:0] vm_assembled_v;wire [8*NPT-1:0] held_epoch;
 // V6: VM read data -> assembly leaf, valid bits -> protocol leaf (wires only)
 wire [7:0] vm_rv;wire [2047:0] vm_rd_il,vm_as_il;
 // V7: the pair select is the uop pipe's d3 word (same register edge as the protocol leaf's inst_q)
 wire [23:0] vm_sel_ctl;
 wire [23:0] vm_sel=(VM_RT==0)?inst[1383+:24]:vm_sel_ctl;
 for(genvar b=0;b<8;b=b+1)begin:g_vmsplit
  assign vm_rv[b]=vm_rr[b*257+256];
  for(genvar i=0;i<256;i=i+1)begin:g_bit assign vm_rd_il[i*8+b]=vm_rr[b*257+i];end
 end
 for(genvar j=0;j<4;j=j+1)begin:g_vmout
  for(genvar i=0;i<256;i=i+1)begin:g_bit
   assign vm_assembled[j*512+i]=vm_as_il[i*8+2*j];assign vm_assembled[j*512+256+i]=vm_as_il[i*8+2*j+1];
  end
 end
 // V7: 16 x 16-column assembly slices (replicated 9-stage select pipe), same edges as V6 ot_hgi_coll_vmasm (whose
 // 2,048-pin faces failed GRT, 440e737a7). The VMSEL mutant swaps the halves of every pair at the select input.
`ifdef OT_COLL_V6_MUT_VMSEL
 wire [23:0] vm_sel_x;
 for(genvar j=0;j<4;j=j+1)begin:g_vmsel_mut assign vm_sel_x[j*6+:6]={vm_sel[j*6+:3],vm_sel[j*6+3+:3]};end
`else
 wire [23:0] vm_sel_x=vm_sel;
`endif
 ot_hgi_coll_vmasm_sliced_v7 u_vmasm(.clk(clk_vmasm),.sel(vm_sel_x),.rd_il(vm_rd_il),.as_il(vm_as_il));
 wire [NPT*16-1:0] wr_sequence_pin,rd_sequence_pin,rx_sequence_pin;wire protocol_fault;
 wire tkm_done,tkm_busy;
 wire [ND-1:0] dest_v;wire [ND*PWT-1:0] dest_d;
 assign hgi_del_obase=delivery_obase_pin;assign inj_rd=inj_req_pin;assign inj_idx=inj_idx_pin;
 assign hgi_inj_addr=inj_addr_pin;assign vm_rq=vm_req_pin;
 // ---- sources
 wire [NS-1:0] source_v;wire [NS*PWT-1:0] source_d;
 for(genvar j=0;j<2;j=j+1)begin:g_inj
  assign source_v[j]=inj_source_v[j];
  assign source_d[j*PWT+:PWT]={inj_source_meta[j*33+:33],inj_d[j*512+:512]};
 end
 for(genvar j=0;j<4;j=j+1)begin:g_vm
  assign source_v[2+NPT+j]=vm_assembled_v[j];
  assign source_d[(2+NPT+j)*PWT+:PWT]={vm_source_meta[j*33+:33],vm_assembled[j*512+:512]};
 end
 wire reduce_out_v,reduce_fault;wire [PWT-1:0] reduce_out_data;wire [7:0] reduce_fault_cause;
 assign source_v[NPT+6]=reduce_out_v;assign source_d[(NPT+6)*PWT+:PWT]=reduce_out_data;
 wire [NS-1:0] capture_calendar;
 assign capture_calendar[NPT+6:0]=p_capture_slot[NPT+6:0];
 wire arg_fault,tkm_fault,ring_fault,writer_fault;
 wire tk_w_v;wire [39:0] tk_w_addr;wire [15:0] tk_w_mask;wire [511:0] tk_w_data;wire [31:0] tk_cycles;
 wire [NPT-1:0] link_rx_v,link_abort;wire [NPT*PWT-1:0] link_rx_data;wire [NPT*11-1:0] link_cause;
 wire [NS-1:0] capture_fault;wire [NSL-1:0] select_fault,unavailable_fault;
 generate if(SOLO!=0)begin:g_q3
  wire arg_out_v;wire [PWT-1:0] arg_out_data;
  assign source_v[NPT+7]=arg_out_v;assign source_d[(NPT+7)*PWT+:PWT]=arg_out_data;
  assign capture_calendar[NPT+7]=p_ring[82];
  if(NPT==3 && VM_RT==0)begin:n_u_control 
  ot_hgi_coll_ctl_v5_q3 u_control(.clk_control(clk_control),.rst_n(rst_n),.inst(inst_ctl),
   .tap_iteration(tap_iteration),.tap_steps(tap_steps),.hgi_start(start_d2),.hgi_busy(busy_d2),.issue_done(issue_done),.tkm_done(tkm_done),.tkm_busy(tkm_busy),
   .dest_v(dest_v),.rc_v(rc_v),.rc_tag(rc_tag),.vm_rv(vm_rv),
   .vm_req_pin(vm_req_pin),.inj_req_pin(inj_req_pin),.inj_idx_pin(inj_idx_pin),.inj_addr_pin(inj_addr_pin),
   .delivery_obase_pin(delivery_obase_pin),.rgx_addr_pin(rgx_addr_pin),
   .inj_source_v(inj_source_v),.inj_source_meta(inj_source_meta),.vm_source_meta(vm_source_meta),
   .vm_assembled_v(vm_assembled_v),.held_epoch(held_epoch),
   .wr_sequence_pin(wr_sequence_pin),.rd_sequence_pin(rd_sequence_pin),.rx_sequence_pin(rx_sequence_pin),
   .protocol_fault(protocol_fault),.cycles(stat_cycles));
  end else if(NPT==3)begin:n_u_control_r
  ot_hgi_coll_ctl_v5r_q3 #(.VM_RT(VM_RT)) u_control(.clk_control(clk_control),.rst_n(rst_n),.inst(inst_ctl),
   .tap_iteration(tap_iteration),.tap_steps(tap_steps),.hgi_start(start_d2),.hgi_busy(busy_d2),.issue_done(issue_done),.tkm_done(tkm_done),.tkm_busy(tkm_busy),
   .dest_v(dest_v),.rc_v(rc_v),.rc_tag(rc_tag),.vm_rv(vm_rv),
   .vm_req_pin(vm_req_pin),.inj_req_pin(inj_req_pin),.inj_idx_pin(inj_idx_pin),.inj_addr_pin(inj_addr_pin),
   .delivery_obase_pin(delivery_obase_pin),.rgx_addr_pin(rgx_addr_pin),
   .inj_source_v(inj_source_v),.inj_source_meta(inj_source_meta),.vm_source_meta(vm_source_meta),
   .vm_assembled_v(vm_assembled_v),.held_epoch(held_epoch),
   .wr_sequence_pin(wr_sequence_pin),.rd_sequence_pin(rd_sequence_pin),.rx_sequence_pin(rx_sequence_pin),
   .protocol_fault(protocol_fault),.cycles(stat_cycles),.vm_sel_d(vm_sel_ctl));
  end else if(VM_RT==0)begin:a_u_control
  ot_hgi_coll_ctl_v5_n2s1 u_control(.clk_control(clk_control),.rst_n(rst_n),.inst(inst_ctl),
   .tap_iteration(tap_iteration),.tap_steps(tap_steps),.hgi_start(start_d2),.hgi_busy(busy_d2),.issue_done(issue_done),.tkm_done(tkm_done),.tkm_busy(tkm_busy),
   .dest_v(dest_v),.rc_v(rc_v),.rc_tag(rc_tag),.vm_rv(vm_rv),
   .vm_req_pin(vm_req_pin),.inj_req_pin(inj_req_pin),.inj_idx_pin(inj_idx_pin),.inj_addr_pin(inj_addr_pin),
   .delivery_obase_pin(delivery_obase_pin),.rgx_addr_pin(rgx_addr_pin),
   .inj_source_v(inj_source_v),.inj_source_meta(inj_source_meta),.vm_source_meta(vm_source_meta),
   .vm_assembled_v(vm_assembled_v),.held_epoch(held_epoch),
   .wr_sequence_pin(wr_sequence_pin),.rd_sequence_pin(rd_sequence_pin),.rx_sequence_pin(rx_sequence_pin),
   .protocol_fault(protocol_fault),.cycles(stat_cycles));
  end else begin:a_u_control_r
  ot_hgi_coll_ctl_v5r_n2s1 #(.VM_RT(VM_RT)) u_control(.clk_control(clk_control),.rst_n(rst_n),.inst(inst_ctl),
   .tap_iteration(tap_iteration),.tap_steps(tap_steps),.hgi_start(start_d2),.hgi_busy(busy_d2),.issue_done(issue_done),.tkm_done(tkm_done),.tkm_busy(tkm_busy),
   .dest_v(dest_v),.rc_v(rc_v),.rc_tag(rc_tag),.vm_rv(vm_rv),
   .vm_req_pin(vm_req_pin),.inj_req_pin(inj_req_pin),.inj_idx_pin(inj_idx_pin),.inj_addr_pin(inj_addr_pin),
   .delivery_obase_pin(delivery_obase_pin),.rgx_addr_pin(rgx_addr_pin),
   .inj_source_v(inj_source_v),.inj_source_meta(inj_source_meta),.vm_source_meta(vm_source_meta),
   .vm_assembled_v(vm_assembled_v),.held_epoch(held_epoch),
   .wr_sequence_pin(wr_sequence_pin),.rd_sequence_pin(rd_sequence_pin),.rx_sequence_pin(rx_sequence_pin),
   .protocol_fault(protocol_fault),.cycles(stat_cycles),.vm_sel_d(vm_sel_ctl));
  end
if(TP==96)begin:t96
  ot_hgi_coll_argmax_m u_arg(.clk(clk_arg),.rst_n(rst_n),.start(a_arg_start),.mode(a_arg_mode),
   .cfg_g(p_tkm_cfg_g),.cfg_gbase(p_tkm_cfg_gbase),.cfg_rank(a_pub_src),
   .in_slot(a_arg_in_slot),.in_v(dest_v[NPT+8+:4]),
   .in_key({dest_d[(NPT+11)*PWT+:64],dest_d[(NPT+10)*PWT+:64],dest_d[(NPT+9)*PWT+:64],dest_d[(NPT+8)*PWT+:64]}),
   .in_meta({dest_d[(NPT+11)*PWT+512+:33],dest_d[(NPT+10)*PWT+512+:33],dest_d[(NPT+9)*PWT+512+:33],dest_d[(NPT+8)*PWT+512+:33]}),
   .flush_slot(a_arg_flush),.publish_slot(a_arg_publish),.out_v(arg_out_v),.out_flit(arg_out_data),.fault(arg_fault));
  end else begin:t192
  ot_hgi_coll_argmax_m_tp192 u_arg(.clk(clk_arg),.rst_n(rst_n),.start(a_arg_start),.mode(a_arg_mode),
   .cfg_g(p_tkm_cfg_g),.cfg_gbase(p_tkm_cfg_gbase),.cfg_rank(a_pub_src),
   .in_slot(a_arg_in_slot),.in_v(dest_v[NPT+8+:4]),
   .in_key({dest_d[(NPT+11)*PWT+:64],dest_d[(NPT+10)*PWT+:64],dest_d[(NPT+9)*PWT+:64],dest_d[(NPT+8)*PWT+:64]}),
   .in_meta({dest_d[(NPT+11)*PWT+512+:33],dest_d[(NPT+10)*PWT+512+:33],dest_d[(NPT+9)*PWT+512+:33],dest_d[(NPT+8)*PWT+512+:33]}),
   .flush_slot(a_arg_flush),.publish_slot(a_arg_publish),.out_v(arg_out_v),.out_flit(arg_out_data),.fault(arg_fault));
  end
  // TKM interface: wires only (the engine is outside the body: inside q3_hard_v5, or die instance tkm_SW for q3_hard_v7x)
  assign tkx_start=p_tkm_start;assign tkx_arg_mode=a_arg_mode;assign tkx_cfg_n=p_tkm_cfg_n;assign tkx_cfg_k=p_tkm_cfg_k;
  assign tkx_cfg_nout=p_tkm_cfg_nout;assign tkx_cfg_g=p_tkm_cfg_g;assign tkx_cfg_gbase=p_tkm_cfg_gbase;
  assign tkx_cfg_pf=p_tkm_cfg_pf;assign tkx_cfg_obase=p_tkm_cfg_obase;assign tkx_cfg_rbase=p_tkm_cfg_rbase;
  assign tkx_cfg_has_r=p_tkm_cfg_has_r;assign tkx_del_slot=p_tkm_del_slot;assign tkx_del_valid=dest_v[NPT+8+:4];
  assign tkx_del_flit=dest_d[(NPT+8)*PWT+:4*PWT];
  assign tk_w_v=tkx_w_v;assign tk_w_addr=tkx_w_addr;assign tk_w_mask=tkx_w_mask;assign tk_w_data=tkx_w_data;
  assign tkm_busy=tkx_busy;assign tkm_done=tkx_done;assign tkm_fault=tkx_fault;assign tk_cycles=32'd0;
  if(NPT==3)begin:n_u_fj 
  ot_hgi_coll_fj_q3 #(.ROWS(ROWS)) u_fj(.clk(clk_program),.rst_n(rst_n),.qid(qid),.cfg_v(cfg_v),.cfg_target(cfg_target),
   .cfg_addr(cfg_addr),.cfg_data(cfg_data),.desc_v(desc_v),.desc_base(desc_base),.desc_limit(desc_limit),
   .desc_loops(desc_loops),.launch_v(launch_v),.program_active(issue_busy_raw),.issuer_busy(issue_busy_raw),
   .issuer_fault(issue_fault),.issuer_uop_v(uop_v),.issuer_uop_pc(uop_pc),
   .issuer_cfg(program_cfg),.issuer_start(hgi_start),.issuer_start_pc(hgi_start_pc),
   .configured(program_configured),.init_busy(program_init_busy),.program_fault(program_fault),
   .protocol_fault(protocol_fault),.capture_fault(capture_fault),.select_fault(select_fault),
   .unavailable_fault(unavailable_fault),.link_abort(link_abort),.ring_fault(ring_fault),
   .writer_fault(writer_fault),.reduce_fault(reduce_fault),.arg_fault(arg_fault),.tkm_fault(tkm_fault),
   .fault(fault),.fault_cause(fault_cause));
  end else begin:a_u_fj
  ot_hgi_coll_fj_n2s1 #(.ROWS(ROWS)) u_fj(.clk(clk_program),.rst_n(rst_n),.qid(qid),.cfg_v(cfg_v),.cfg_target(cfg_target),
   .cfg_addr(cfg_addr),.cfg_data(cfg_data),.desc_v(desc_v),.desc_base(desc_base),.desc_limit(desc_limit),
   .desc_loops(desc_loops),.launch_v(launch_v),.program_active(issue_busy_raw),.issuer_busy(issue_busy_raw),
   .issuer_fault(issue_fault),.issuer_uop_v(uop_v),.issuer_uop_pc(uop_pc),
   .issuer_cfg(program_cfg),.issuer_start(hgi_start),.issuer_start_pc(hgi_start_pc),
   .configured(program_configured),.init_busy(program_init_busy),.program_fault(program_fault),
   .protocol_fault(protocol_fault),.capture_fault(capture_fault),.select_fault(select_fault),
   .unavailable_fault(unavailable_fault),.link_abort(link_abort),.ring_fault(ring_fault),
   .writer_fault(writer_fault),.reduce_fault(reduce_fault),.arg_fault(arg_fault),.tkm_fault(tkm_fault),
   .fault(fault),.fault_cause(fault_cause));
  end
 end else begin:g_q2
  // No arg/tkm engine in q2: their tkm sinks are unrouted switch outputs; illegal reservations fault in u_fj.
  assign tk_w_v=1'b0;assign tk_w_addr=40'd0;assign tk_w_mask=16'd0;assign tk_w_data=512'd0;
  assign tkm_done=1'b0;assign tkm_busy=1'b0;assign arg_fault=1'b0;assign tkm_fault=1'b0;assign tk_cycles=32'd0;
  assign tkx_start=1'b0;assign tkx_arg_mode=1'b0;assign tkx_cfg_n=0;assign tkx_cfg_k=0;assign tkx_cfg_nout=0;
  assign tkx_cfg_g=0;assign tkx_cfg_gbase=0;assign tkx_cfg_pf=0;assign tkx_cfg_obase=0;assign tkx_cfg_rbase=0;
  assign tkx_cfg_has_r=1'b0;assign tkx_del_slot=0;assign tkx_del_valid=0;assign tkx_del_flit=0;
  if(NPT==2 && VM_RT==0)begin:n_u_control 
  ot_hgi_coll_ctl_v5_q2 u_control(.clk_control(clk_control),.rst_n(rst_n),.inst(inst_ctl),
   .tap_iteration(tap_iteration),.tap_steps(tap_steps),.hgi_start(start_d2),.hgi_busy(busy_d2),.issue_done(issue_done),.tkm_done(tkm_done),.tkm_busy(tkm_busy),
   .dest_v(dest_v),.rc_v(rc_v),.rc_tag(rc_tag),.vm_rv(vm_rv),
   .vm_req_pin(vm_req_pin),.inj_req_pin(inj_req_pin),.inj_idx_pin(inj_idx_pin),.inj_addr_pin(inj_addr_pin),
   .delivery_obase_pin(delivery_obase_pin),.rgx_addr_pin(rgx_addr_pin),
   .inj_source_v(inj_source_v),.inj_source_meta(inj_source_meta),.vm_source_meta(vm_source_meta),
   .vm_assembled_v(vm_assembled_v),.held_epoch(held_epoch),
   .wr_sequence_pin(wr_sequence_pin),.rd_sequence_pin(rd_sequence_pin),.rx_sequence_pin(rx_sequence_pin),
   .protocol_fault(protocol_fault),.cycles(stat_cycles));
  end else if(NPT==2)begin:n_u_control_r
  ot_hgi_coll_ctl_v5r_q2 #(.VM_RT(VM_RT)) u_control(.clk_control(clk_control),.rst_n(rst_n),.inst(inst_ctl),
   .tap_iteration(tap_iteration),.tap_steps(tap_steps),.hgi_start(start_d2),.hgi_busy(busy_d2),.issue_done(issue_done),.tkm_done(tkm_done),.tkm_busy(tkm_busy),
   .dest_v(dest_v),.rc_v(rc_v),.rc_tag(rc_tag),.vm_rv(vm_rv),
   .vm_req_pin(vm_req_pin),.inj_req_pin(inj_req_pin),.inj_idx_pin(inj_idx_pin),.inj_addr_pin(inj_addr_pin),
   .delivery_obase_pin(delivery_obase_pin),.rgx_addr_pin(rgx_addr_pin),
   .inj_source_v(inj_source_v),.inj_source_meta(inj_source_meta),.vm_source_meta(vm_source_meta),
   .vm_assembled_v(vm_assembled_v),.held_epoch(held_epoch),
   .wr_sequence_pin(wr_sequence_pin),.rd_sequence_pin(rd_sequence_pin),.rx_sequence_pin(rx_sequence_pin),
   .protocol_fault(protocol_fault),.cycles(stat_cycles),.vm_sel_d(vm_sel_ctl));
  end else if(VM_RT==0)begin:a_u_control
  ot_hgi_coll_ctl_v5_n1s0 u_control(.clk_control(clk_control),.rst_n(rst_n),.inst(inst_ctl),
   .tap_iteration(tap_iteration),.tap_steps(tap_steps),.hgi_start(start_d2),.hgi_busy(busy_d2),.issue_done(issue_done),.tkm_done(tkm_done),.tkm_busy(tkm_busy),
   .dest_v(dest_v),.rc_v(rc_v),.rc_tag(rc_tag),.vm_rv(vm_rv),
   .vm_req_pin(vm_req_pin),.inj_req_pin(inj_req_pin),.inj_idx_pin(inj_idx_pin),.inj_addr_pin(inj_addr_pin),
   .delivery_obase_pin(delivery_obase_pin),.rgx_addr_pin(rgx_addr_pin),
   .inj_source_v(inj_source_v),.inj_source_meta(inj_source_meta),.vm_source_meta(vm_source_meta),
   .vm_assembled_v(vm_assembled_v),.held_epoch(held_epoch),
   .wr_sequence_pin(wr_sequence_pin),.rd_sequence_pin(rd_sequence_pin),.rx_sequence_pin(rx_sequence_pin),
   .protocol_fault(protocol_fault),.cycles(stat_cycles));
  end else begin:a_u_control_r
  ot_hgi_coll_ctl_v5r_n1s0 #(.VM_RT(VM_RT)) u_control(.clk_control(clk_control),.rst_n(rst_n),.inst(inst_ctl),
   .tap_iteration(tap_iteration),.tap_steps(tap_steps),.hgi_start(start_d2),.hgi_busy(busy_d2),.issue_done(issue_done),.tkm_done(tkm_done),.tkm_busy(tkm_busy),
   .dest_v(dest_v),.rc_v(rc_v),.rc_tag(rc_tag),.vm_rv(vm_rv),
   .vm_req_pin(vm_req_pin),.inj_req_pin(inj_req_pin),.inj_idx_pin(inj_idx_pin),.inj_addr_pin(inj_addr_pin),
   .delivery_obase_pin(delivery_obase_pin),.rgx_addr_pin(rgx_addr_pin),
   .inj_source_v(inj_source_v),.inj_source_meta(inj_source_meta),.vm_source_meta(vm_source_meta),
   .vm_assembled_v(vm_assembled_v),.held_epoch(held_epoch),
   .wr_sequence_pin(wr_sequence_pin),.rd_sequence_pin(rd_sequence_pin),.rx_sequence_pin(rx_sequence_pin),
   .protocol_fault(protocol_fault),.cycles(stat_cycles),.vm_sel_d(vm_sel_ctl));
  end
  if(NPT==2)begin:n_u_fj 
  ot_hgi_coll_fj_q2 #(.ROWS(ROWS)) u_fj(.clk(clk_program),.rst_n(rst_n),.qid(qid),.cfg_v(cfg_v),.cfg_target(cfg_target),
   .cfg_addr(cfg_addr),.cfg_data(cfg_data),.desc_v(desc_v),.desc_base(desc_base),.desc_limit(desc_limit),
   .desc_loops(desc_loops),.launch_v(launch_v),.program_active(issue_busy_raw),.issuer_busy(issue_busy_raw),
   .issuer_fault(issue_fault),.issuer_uop_v(uop_v),.issuer_uop_pc(uop_pc),
   .issuer_cfg(program_cfg),.issuer_start(hgi_start),.issuer_start_pc(hgi_start_pc),
   .configured(program_configured),.init_busy(program_init_busy),.program_fault(program_fault),
   .protocol_fault(protocol_fault),.capture_fault(capture_fault),.select_fault(select_fault),
   .unavailable_fault(unavailable_fault),.link_abort(link_abort),.ring_fault(ring_fault),
   .writer_fault(writer_fault),.reduce_fault(reduce_fault),
   .arg_capture_slot(p_capture_slot[NPT+7]),.tkm_start(p_tkm_start),.tkm_del_slot(p_tkm_del_slot),
   .tkm_dest_v(dest_v[NPT+8+:4]),.fault(fault),.fault_cause(fault_cause));
  end else begin:a_u_fj
  ot_hgi_coll_fj_n1s0 #(.ROWS(ROWS)) u_fj(.clk(clk_program),.rst_n(rst_n),.qid(qid),.cfg_v(cfg_v),.cfg_target(cfg_target),
   .cfg_addr(cfg_addr),.cfg_data(cfg_data),.desc_v(desc_v),.desc_base(desc_base),.desc_limit(desc_limit),
   .desc_loops(desc_loops),.launch_v(launch_v),.program_active(issue_busy_raw),.issuer_busy(issue_busy_raw),
   .issuer_fault(issue_fault),.issuer_uop_v(uop_v),.issuer_uop_pc(uop_pc),
   .issuer_cfg(program_cfg),.issuer_start(hgi_start),.issuer_start_pc(hgi_start_pc),
   .configured(program_configured),.init_busy(program_init_busy),.program_fault(program_fault),
   .protocol_fault(protocol_fault),.capture_fault(capture_fault),.select_fault(select_fault),
   .unavailable_fault(unavailable_fault),.link_abort(link_abort),.ring_fault(ring_fault),
   .writer_fault(writer_fault),.reduce_fault(reduce_fault),
   .arg_capture_slot(p_capture_slot[NPT+7]),.tkm_start(p_tkm_start),.tkm_del_slot(p_tkm_del_slot),
   .tkm_dest_v(dest_v[NPT+8+:4]),.fault(fault),.fault_cause(fault_cause));
  end
 end endgenerate
 // ---- reduction (hybrid cluster)
 ot_hgi_coll_reduce_static u_reduce(
  .clk_control(clk_reduce[0]),.clk_state(clk_reduce[16:1]),.clk_add(clk_reduce[32:17]),
  .rst_n(rst_n),.clear(p_ring[83]),.in_v(dest_v[ND-1]),.in_flit(dest_d[(ND-1)*PWT+:PWT]),
  .load_v(a_load_v),.load_tag(a_load_tag),.add_read(a_add_read),.read_tag(a_read_tag),.add_issue(a_add_issue),
  .pub_read(a_pub_read),.pub_tag_a(a_pub_tag_a),.pub_tag_b(a_pub_tag_b),.pub_bf16(a_pub_bf16),
  .pub_meta({1'b1,8'hff,a_pub_src,a_pub_index}),.pub_release(a_pub_release),.pub_issue(a_pub_issue),
  .out_v(reduce_out_v),.out_flit(reduce_out_data),.fault(reduce_fault),.fault_cause(reduce_fault_cause));
 // ---- qslots (pin_v2 partition, flattened: capture leaves + 32-bit switch slices)
 wire [NS*PWT-1:0] captured;wire [NS-1:0] captured_slot;
 for(genvar s=0;s<NS;s=s+1)begin:g_qcap
  ot_hgi_coll_qslots_capture_pin_v2 u_cap(.clk(clk_qslots[s]),.rst_n(rst_n),.src_v(source_v[s]),
   .capture_slot(capture_calendar[s]),.src_d(source_d[s*PWT+:PWT]),.captured(captured[s*PWT+:PWT]),
   .captured_slot(captured_slot[s]),.fault(capture_fault[s]));
 end
 wire [ND-1:0] slice_v[0:NSL-1];
 for(genvar k=0;k<NSL;k=k+1)begin:g_qout
  localparam integer CW=(k<NSL-1)?32:1;
  wire [NS*CW-1:0] words;wire [ND*CW-1:0] results;
  for(genvar s=0;s<NS;s=s+1)begin:g_in
   assign words[s*CW+:CW]=captured[s*PWT+k*32+:CW];
  end
  if(SOLO!=0)begin:g3
   if(k<NSL-1)begin:w if(NPT==3)begin:o ot_hgi_coll_qso_q3_b32 u_out(.clk(clk_qslots[NS+k]),.rst_n(rst_n),.captured(words),
    .captured_slot(captured_slot),.sink_slot(p_sink_slot[ND-1:0]),.sink_select(p_sink_select[ND*SELW-1:0]),
    .dst_v(slice_v[k]),.dst_d(results),.select_fault(select_fault[k]),.unavailable_fault(unavailable_fault[k])); end else begin:a ot_hgi_coll_qso_n2s1_b32 u_out(.clk(clk_qslots[NS+k]),.rst_n(rst_n),.captured(words),
    .captured_slot(captured_slot),.sink_slot(p_sink_slot[ND-1:0]),.sink_select(p_sink_select[ND*SELW-1:0]),
    .dst_v(slice_v[k]),.dst_d(results),.select_fault(select_fault[k]),.unavailable_fault(unavailable_fault[k])); end end
   else begin:n if(NPT==3)begin:o ot_hgi_coll_qso_q3_b1 u_out(.clk(clk_qslots[NS+k]),.rst_n(rst_n),.captured(words),
    .captured_slot(captured_slot),.sink_slot(p_sink_slot[ND-1:0]),.sink_select(p_sink_select[ND*SELW-1:0]),
    .dst_v(slice_v[k]),.dst_d(results),.select_fault(select_fault[k]),.unavailable_fault(unavailable_fault[k])); end else begin:a ot_hgi_coll_qso_n2s1_b1 u_out(.clk(clk_qslots[NS+k]),.rst_n(rst_n),.captured(words),
    .captured_slot(captured_slot),.sink_slot(p_sink_slot[ND-1:0]),.sink_select(p_sink_select[ND*SELW-1:0]),
    .dst_v(slice_v[k]),.dst_d(results),.select_fault(select_fault[k]),.unavailable_fault(unavailable_fault[k])); end end
  end else begin:g2
   if(k<NSL-1)begin:w if(NPT==2)begin:o ot_hgi_coll_qso_q2_b32 u_out(.clk(clk_qslots[NS+k]),.rst_n(rst_n),.captured(words),
    .captured_slot(captured_slot),.sink_slot(p_sink_slot[ND-1:0]),.sink_select(p_sink_select[ND*SELW-1:0]),
    .dst_v(slice_v[k]),.dst_d(results),.select_fault(select_fault[k]),.unavailable_fault(unavailable_fault[k])); end else begin:a ot_hgi_coll_qso_n1s0_b32 u_out(.clk(clk_qslots[NS+k]),.rst_n(rst_n),.captured(words),
    .captured_slot(captured_slot),.sink_slot(p_sink_slot[ND-1:0]),.sink_select(p_sink_select[ND*SELW-1:0]),
    .dst_v(slice_v[k]),.dst_d(results),.select_fault(select_fault[k]),.unavailable_fault(unavailable_fault[k])); end end
   else begin:n if(NPT==2)begin:o ot_hgi_coll_qso_q2_b1 u_out(.clk(clk_qslots[NS+k]),.rst_n(rst_n),.captured(words),
    .captured_slot(captured_slot),.sink_slot(p_sink_slot[ND-1:0]),.sink_select(p_sink_select[ND*SELW-1:0]),
    .dst_v(slice_v[k]),.dst_d(results),.select_fault(select_fault[k]),.unavailable_fault(unavailable_fault[k])); end else begin:a ot_hgi_coll_qso_n1s0_b1 u_out(.clk(clk_qslots[NS+k]),.rst_n(rst_n),.captured(words),
    .captured_slot(captured_slot),.sink_slot(p_sink_slot[ND-1:0]),.sink_select(p_sink_select[ND*SELW-1:0]),
    .dst_v(slice_v[k]),.dst_d(results),.select_fault(select_fault[k]),.unavailable_fault(unavailable_fault[k])); end end
  end
  for(genvar d=0;d<ND;d=d+1)begin:g_res
   assign dest_d[d*PWT+k*32+:CW]=results[d*CW+:CW];
  end
 end
 assign dest_v=slice_v[0];
 // ---- rails
 for(genvar k=0;k<NPT;k=k+1)begin:g_link
  assign source_v[2+k]=link_rx_v[k];
  assign source_d[(2+k)*PWT+:PWT]=link_rx_data[k*PWT+:PWT];
  ot_hgi_coll_link_e u_link(.ck(clk_link[k*5+:5]),.rst_n(rst_n),
   .epoch_begin(p_lk_epoch_begin[k]),.epoch_new(p_lk_epoch),.held_epoch(held_epoch[k*8+:8]),
   .wr_v(p_lk_wr_v[k]),.wr_observed_v(dest_v[k]),.wr_seq(wr_sequence_pin[k*16+:16]),
   .wr_flit(dest_d[k*PWT+:PWT]),.rd_v(p_lk_rd_v[k]),.rd_seq(rd_sequence_pin[k*16+:16]),
   .rx_expect_v(p_lk_rx_expect[k]),.rx_expect_seq(rx_sequence_pin[k*16+:16]),
   .phy_up(phy_up[k]),.tx_pin_v(tx_pin_v[k]),.tx_pin_flit(tx_pin_flit[k*612+:612]),
   .rx_pin_v(rx_pin_v[k]),.rx_pin_flit(rx_pin_flit[k*612+:612]),
   .rx_v(link_rx_v[k]),.rx_flit(link_rx_data[k*PWT+:PWT]),
   .epoch_abort(link_abort[k]),.retry_requested(retry_requested[k]),.fault_cause(link_cause[k*11+:11]));
 end
 // ---- deliveries
 for(genvar j=0;j<4;j=j+1)begin:g_delivery
  assign del_valid[j]=dest_v[NPT+j];
  assign del_flit[j*PWT+:PWT]=dest_d[(NPT+j)*PWT+:PWT];
 end
 // ---- VM writer (CLOSED v6 roots physical view; same vector ABI as ot_hgi_coll_static_vmwrite)
 ot_hgi_coll_static_vmwrite_roots_v6_physical u_writer(
  .clk_rgx_data0(clk_vmwrite[0]),.clk_rgx_data1(clk_vmwrite[1]),.clk_rgx_data2(clk_vmwrite[2]),
  .clk_rgx_data3(clk_vmwrite[3]),.clk_rgx_ctrl(clk_vmwrite[4]),.clk_tkw(clk_vmwrite[5]),
  .clk_meta(clk_vmwrite[6]),.clk_body(clk_vmwrite[7]),
  .clk_bank0(clk_vmwrite[8]),.clk_bank1(clk_vmwrite[9]),.clk_bank2(clk_vmwrite[10]),.clk_bank3(clk_vmwrite[11]),
  .clk_bank4(clk_vmwrite[12]),.clk_bank5(clk_vmwrite[13]),.clk_bank6(clk_vmwrite[14]),.clk_bank7(clk_vmwrite[15]),
  .rst_n(rst_n),.sid(qid),.rgx_v(dest_v[NPT+4+:4]),.rgx_addr(rgx_addr_pin),
  .rgx_data0(dest_d[(NPT+4)*PWT+:512]),.rgx_data1(dest_d[(NPT+5)*PWT+:512]),
  .rgx_data2(dest_d[(NPT+6)*PWT+:512]),.rgx_data3(dest_d[(NPT+7)*PWT+:512]),
  .rgx_vm(p_rgx_vm),.tkw_v(tk_w_v),.tkw_d({tk_w_addr,tk_w_mask,tk_w_data}),
  .ingress_slot(p_vm_ingress_slot),.slot_valid(p_vm_slot_valid),.slot_owner(p_vm_slot_owner),
  .kq0(vm_kq[0*281+:281]),.kq1(vm_kq[1*281+:281]),.kq2(vm_kq[2*281+:281]),.kq3(vm_kq[3*281+:281]),
  .kq4(vm_kq[4*281+:281]),.kq5(vm_kq[5*281+:281]),.kq6(vm_kq[6*281+:281]),.kq7(vm_kq[7*281+:281]),
  .launch_done(),.fault(writer_fault));
 // ---- ring A (v8g): ot_hgi_coll_ring_ag (8 CLOSED state-capture lanes + 8 add lanes + the gather-capable control root
 // hcoll_ring_ag_ctl_1017); commands from the gather master's merge register (ISA fields +2 edges, OR the gather fields)
 assign isa_ring=p_ring[57:0];assign isa_lp_data=rc_d;
 ot_hgi_coll_ring_ag #(.SPLIT_CLOCKS(1),.AG(1)) u_ring(.clk(clk_ring[0]),.clk_ctl(clk_ring[0]),.clk_state(clk_ring[8:1]),
  .clk_add(clk_ring[16:9]),.rst_n(rst_n),.qid(qid),.cw_i(pr_cw_i),.ccw_i(pr_ccw_i),.cw_o(pr_cw_o),.ccw_o(pr_ccw_o),
  .lp_we(ra_lp_we),.lp_tag(ra_lp_tag),.lp_data(ra_lp_data),
  .state_read_add(ra_state_read_add),.state_read_tx(ra_state_read_tx),.state_read_rr(ra_state_read_rr),
  .state_add_tag(ra_state_add_tag),.state_tx_tag(ra_state_tx_tag),.state_rr_tag(ra_state_rr_tag),
  .state_add_src(ra_state_add_src),.state_add_rhs_acc(ra_state_add_rhs_acc),.state_tx_acc(ra_state_tx_acc),
  .add_v(ra_add_v),.add_tag(ra_add_tag),.add_src(ra_add_src),.add_rhs_acc(ra_add_rhs_acc),
  .tx_inject(ra_tx_inject),.tx_forward(ra_tx_forward),.tx_tag(ra_tx_tag),.tx_dst(ra_tx_dst),.tx_result(ra_tx_result),
  .tx_acc(ra_tx_acc),.tx_gather(ra_tx_gather),.tx_ttl(ra_tx_ttl),.rx_slot(ra_rx_slot),.rx_kind(ra_rx_kind),
  .rx_src(ra_rx_src),.rx_tag(ra_rx_tag),.rr_local(ra_rr_local),.rr_local_tag(ra_rr_local_tag),
  .rr_v(rr_v),.rr_tag(rr_tag),.rr_d(rr_d),.ag_v(ag_v),.ag_src(ag_src),.ag_tag(ag_tag),.ag_d(ag_d),.fault(ring_fault));
endmodule

// d4f (H-DIE 10-17): the q3 parent with TKM hoisted to a die-level sub-cluster (tkm_SW, ot_hgi_coll_tkm_m_tp192): same
// body, the TKM interface on pins (zero-latency wires in the lockstep bench; die hop granted <= 450 um, no relay).
module ot_hfd_coll_q3_hard_v8x #(parameter integer NLINK=3,parameter integer TP=96,parameter integer VM_RT=0,AR_ITER=0,ROWS=64)(
 input wire rst_n,input wire [1:0] qid,
 input wire clk_program,clk_control,input wire [15:0] clk_vmasm,clk_upipe,input wire clk_issue,input wire [NLINK+8+18-1:0] clk_qslots,
 input wire [16:0] clk_ring,input wire [32:0] clk_reduce,input wire clk_arg,
 input wire [15:0] clk_vmwrite,input wire [5*NLINK-1:0] clk_link,
 input wire cfg_v,input wire [7:0] cfg_target,input wire [11:0] cfg_addr,input wire [255:0] cfg_data,
 input wire desc_v,input wire [11:0] desc_base,input wire [12:0] desc_limit,input wire [15:0] desc_loops,
 input wire launch_v,
 output wire program_configured,program_init_busy,program_fault,hgi_busy,hgi_done,hgi_fault,
 output wire [1:0] inj_rd,output wire [31:0] inj_idx,output wire [159:0] hgi_inj_addr,input wire [1023:0] inj_d,
 output wire [3:0] del_valid,output wire [2179:0] del_flit,output wire [159:0] hgi_del_obase,
 input wire rc_v,input wire [2:0] rc_tag,input wire [255:0] rc_d,
 output wire rr_v,output wire [2:0] rr_tag,output wire [255:0] rr_d,
 input wire [NLINK-1:0] phy_up,output wire [NLINK-1:0] tx_pin_v,output wire [NLINK*612-1:0] tx_pin_flit,
 input wire [NLINK-1:0] rx_pin_v,input wire [NLINK*612-1:0] rx_pin_flit,output wire [NLINK-1:0] retry_requested,
 input wire [279:0] pr_cw_i,pr_ccw_i,output wire [279:0] pr_cw_o,pr_ccw_o,

 // v8g (HBM-COLLQ): ring A = ot_hgi_coll_ring_ag (gather-capable successor of ring_v5, AG=0 behaviour identical); its
 // command ports are driven by the quadrant gather master's ring-A merge register (die instance hcollgi_<q>), which takes
 // this parent's ISA ring fields + lp data and adds 2 edges; the ring's gather publishes leave on ag_*.
 output wire [57:0] isa_ring,output wire [255:0] isa_lp_data,
 input wire ra_lp_we,input wire [2:0] ra_lp_tag,input wire [255:0] ra_lp_data,
 input wire ra_state_read_add,ra_state_read_tx,ra_state_read_rr,input wire [2:0] ra_state_add_tag,ra_state_tx_tag,ra_state_rr_tag,
 input wire [1:0] ra_state_add_src,input wire ra_state_add_rhs_acc,ra_state_tx_acc,ra_add_v,input wire [2:0] ra_add_tag,
 input wire [1:0] ra_add_src,input wire ra_add_rhs_acc,input wire [1:0] ra_tx_inject,ra_tx_forward,input wire [2:0] ra_tx_tag,
 input wire [1:0] ra_tx_dst,input wire ra_tx_result,ra_tx_acc,ra_tx_gather,input wire [3:0] ra_tx_ttl,
 input wire [1:0] ra_rx_slot,input wire [3:0] ra_rx_kind,ra_rx_src,input wire [5:0] ra_rx_tag,input wire ra_rr_local,
 input wire [2:0] ra_rr_local_tag,
 output wire [1:0] ag_v,output wire [3:0] ag_src,output wire [5:0] ag_tag,output wire [511:0] ag_d,
 output wire [135:0] vm_rq,input wire [2055:0] vm_rr,output wire [2247:0] vm_kq,
 // TKM interface (d4f H-DIE 10-17: TKM hoisted to its own die sub-cluster tkm_SW; q3_hard_v5 keeps it inside)
 output wire tkx_start,tkx_arg_mode,output wire [11:0] tkx_cfg_n,output wire [12:0] tkx_cfg_k,tkx_cfg_nout,
 output wire [7:0] tkx_cfg_g,tkx_cfg_gbase,output wire [15:0] tkx_cfg_pf,output wire [39:0] tkx_cfg_obase,tkx_cfg_rbase,
 output wire tkx_cfg_has_r,output wire [3:0] tkx_del_slot,tkx_del_valid,output wire [2179:0] tkx_del_flit,
 input wire tkx_w_v,input wire [39:0] tkx_w_addr,input wire [15:0] tkx_w_mask,input wire [511:0] tkx_w_data,
 input wire tkx_busy,tkx_done,tkx_fault,
 output wire fault,output wire [15:0] fault_cause,output wire done,output wire [31:0] stat_cycles
);
 ot_hfd_coll_q_hard_v8g_body #(.NPT(NLINK),.TP(TP),.SOLO(1),.VM_RT(VM_RT),.AR_ITER(AR_ITER),.ROWS(ROWS)) u_body(.*);
endmodule

module ot_hfd_coll_q2_hard_v8g #(parameter integer NLINK=2,parameter integer TP=96,parameter integer VM_RT=0,AR_ITER=0,ROWS=64)(
 input wire rst_n,input wire [1:0] qid,
 input wire clk_program,clk_control,input wire [15:0] clk_vmasm,clk_upipe,input wire clk_issue,input wire [NLINK+7+18-1:0] clk_qslots,
 input wire [16:0] clk_ring,input wire [32:0] clk_reduce,
 input wire [15:0] clk_vmwrite,input wire [5*NLINK-1:0] clk_link,
 input wire cfg_v,input wire [7:0] cfg_target,input wire [11:0] cfg_addr,input wire [255:0] cfg_data,
 input wire desc_v,input wire [11:0] desc_base,input wire [12:0] desc_limit,input wire [15:0] desc_loops,
 input wire launch_v,
 output wire program_configured,program_init_busy,program_fault,hgi_busy,hgi_done,hgi_fault,
 output wire [1:0] inj_rd,output wire [31:0] inj_idx,output wire [159:0] hgi_inj_addr,input wire [1023:0] inj_d,
 output wire [3:0] del_valid,output wire [2179:0] del_flit,output wire [159:0] hgi_del_obase,
 input wire rc_v,input wire [2:0] rc_tag,input wire [255:0] rc_d,
 output wire rr_v,output wire [2:0] rr_tag,output wire [255:0] rr_d,
 input wire [NLINK-1:0] phy_up,output wire [NLINK-1:0] tx_pin_v,output wire [NLINK*612-1:0] tx_pin_flit,
 input wire [NLINK-1:0] rx_pin_v,input wire [NLINK*612-1:0] rx_pin_flit,output wire [NLINK-1:0] retry_requested,
 input wire [279:0] pr_cw_i,pr_ccw_i,output wire [279:0] pr_cw_o,pr_ccw_o,

 // v8g (HBM-COLLQ): ring A = ot_hgi_coll_ring_ag (gather-capable successor of ring_v5, AG=0 behaviour identical); its
 // command ports are driven by the quadrant gather master's ring-A merge register (die instance hcollgi_<q>), which takes
 // this parent's ISA ring fields + lp data and adds 2 edges; the ring's gather publishes leave on ag_*.
 output wire [57:0] isa_ring,output wire [255:0] isa_lp_data,
 input wire ra_lp_we,input wire [2:0] ra_lp_tag,input wire [255:0] ra_lp_data,
 input wire ra_state_read_add,ra_state_read_tx,ra_state_read_rr,input wire [2:0] ra_state_add_tag,ra_state_tx_tag,ra_state_rr_tag,
 input wire [1:0] ra_state_add_src,input wire ra_state_add_rhs_acc,ra_state_tx_acc,ra_add_v,input wire [2:0] ra_add_tag,
 input wire [1:0] ra_add_src,input wire ra_add_rhs_acc,input wire [1:0] ra_tx_inject,ra_tx_forward,input wire [2:0] ra_tx_tag,
 input wire [1:0] ra_tx_dst,input wire ra_tx_result,ra_tx_acc,ra_tx_gather,input wire [3:0] ra_tx_ttl,
 input wire [1:0] ra_rx_slot,input wire [3:0] ra_rx_kind,ra_rx_src,input wire [5:0] ra_rx_tag,input wire ra_rr_local,
 input wire [2:0] ra_rr_local_tag,
 output wire [1:0] ag_v,output wire [3:0] ag_src,output wire [5:0] ag_tag,output wire [511:0] ag_d,
 output wire [135:0] vm_rq,input wire [2055:0] vm_rr,output wire [2247:0] vm_kq,
 output wire fault,output wire [15:0] fault_cause,output wire done,output wire [31:0] stat_cycles
);
 ot_hfd_coll_q_hard_v8g_body #(.NPT(NLINK),.TP(TP),.SOLO(0),.VM_RT(VM_RT),.AR_ITER(AR_ITER),.ROWS(ROWS)) u_body(.*,.clk_arg(1'b0),
  .tkx_start(),.tkx_arg_mode(),.tkx_cfg_n(),.tkx_cfg_k(),.tkx_cfg_nout(),.tkx_cfg_g(),.tkx_cfg_gbase(),.tkx_cfg_pf(),
  .tkx_cfg_obase(),.tkx_cfg_rbase(),.tkx_cfg_has_r(),.tkx_del_slot(),.tkx_del_valid(),.tkx_del_flit(),
  .tkx_w_v(1'b0),.tkx_w_addr(40'd0),.tkx_w_mask(16'd0),.tkx_w_data(512'd0),.tkx_busy(1'b0),.tkx_done(1'b0),.tkx_fault(1'b0));
endmodule
`default_nettype wire
