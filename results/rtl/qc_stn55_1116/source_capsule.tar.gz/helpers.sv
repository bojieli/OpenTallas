`timescale 1ns/1ps
module qfd_dv_kept_valid #(parameter integer ID = 0) (input wire ck, rst_n, d, output reg q);
    always @(posedge ck or negedge rst_n) if (!rst_n) q <= 1'b0; else q <= d;
endmodule
module qfd_dv_sram_bank64 #(parameter integer W=546)(
 input wire clk,r_ce_in,w_ce_in,input wire[4:0] r_addr_in,w_addr_in,
 output wire[W-1:0] rd_out,input wire[W-1:0] wd_in,w_mask_in
);
 localparam integer N=(W+63)/64,P=64*N-W;
 wire[64*N-1:0] data={{P{1'b0}},wd_in},mask={{P{1'b0}},w_mask_in};
 wire[64*N-1:0] result;
 generate for(genvar b=0;b<N;b=b+1) begin:g_bank
  ot_sram_1r1w_32x64_m1 u_m(.clk(clk),.r_ce_in(r_ce_in),.r_addr_in(r_addr_in),.rd_out(result[64*b+:64]),
   .w_ce_in(w_ce_in),.w_addr_in(w_addr_in),.wd_in(data[64*b+:64]),.w_mask_in(mask[64*b+:64]));
 end endgenerate
 assign rd_out=result[W-1:0];

 initial if(W<1||W>546) $fatal(1,"SRAM_BANK64_WIDTH");

endmodule
module qfd_dv_station_copy #(parameter integer W=1,ID=0)(input wire ck,input wire[W-1:0] d,output reg[W-1:0] q);
always @(posedge ck) q<=d;
endmodule
module qfd_dv_station_out #(parameter integer W=16,ID=0)(input wire ck,rst_n,input wire[W-1:0] d,output reg[W-1:0] q);
always @(posedge ck or negedge rst_n) if(!rst_n) q<=0;else q<=d;
endmodule
module qfd_dv_station_cfgbit #(parameter integer ID=0)(input wire ck,rst_n,cfg_v,d,output reg q);
always @(posedge ck or negedge rst_n) if(!rst_n)q<=0;else if(cfg_v)q<=d;
endmodule
module qfd_dv_station_mode #(parameter integer ID=0,USE2=1)(input wire ck,rst_n,cfg_v,input wire[1:0] mode,output wire[3:0] q);
reg[2:0] used_q;
always @(posedge ck or negedge rst_n) if(!rst_n) used_q<=3'b001;else if(cfg_v) used_q<={mode==3,mode==1,mode==0};
assign {q[3],q[1],q[0]}=used_q;
generate if(USE2) begin:g_two
reg m2;always @(posedge ck or negedge rst_n) if(!rst_n)m2<=0;else if(cfg_v)m2<=mode==2;assign q[2]=m2;
end else begin:g_no_two assign q[2]=1'b0;end endgenerate
endmodule

module qfd_dv_kept_bit #(parameter integer ID = 0) (input wire ck, d, output reg q);
    always @(posedge ck) q <= d;
endmodule
