`define KVA_PW0_F 1'b0
`define KVA_PW1_F 1'b0
