`timescale 1ns/1ps
module tb_xface;
 reg clk=0; always #0.4165 clk=~clk;
 reg rst_n=0; reg tx_v=0; reg [511:0] tx_d=0;
 wire p_v; wire [543:0] p_d; wire enc_fault;
 reg [543:0] ch_d;
 ot_s81_kp4_enc u_enc(.clk(clk),.rst_n(rst_n),.tx_v(tx_v),.tx_d(tx_d),.p_v(p_v),.p_d(p_d),.fault(enc_fault));
wire gv,gf,gu,gl; wire [511:0] gd; wire [4:0] gn; wire [7:0] gs; wire [31:0] gc,ge,gr;
gold_dec u_g (.rst_n(rst_n), .p_v(p_v), .p_d(ch_d), .q_v(gv), .q_d(gd), .q_first(gf), .q_unc(gu), .q_nerr(gn), .q_seq(gs), .lock(gl), .n_corr(gc), .n_unc(ge), .n_relock(gr), .ck_syn(clk), .ck_dly(clk), .ck_chn(clk), .ck_out(clk));
wire cv,cf,cu,cl; wire [511:0] cd; wire [4:0] cn; wire [7:0] cs; wire [31:0] cc,ce,cr;
ot_s81_kp4_dec_native_flat_lp u_c (.rst_n(rst_n), .p_v(p_v), .p_d(ch_d), .q_v(cv), .q_d(cd), .q_first(cf), .q_unc(cu), .q_nerr(cn), .q_seq(cs), .lock(cl), .n_corr(cc), .n_unc(ce), .n_relock(cr), .ck_syn(clk), .ck_dly(clk), .ck_chn(clk), .ck_out(clk));
wire mv,mf,mu,ml; wire [511:0] md; wire [4:0] mn; wire [7:0] ms; wire [31:0] mc,me,mr;
mutant_dec u_m (.rst_n(rst_n), .p_v(p_v), .p_d(ch_d), .q_v(mv), .q_d(md), .q_first(mf), .q_unc(mu), .q_nerr(mn), .q_seq(ms), .lock(ml), .n_corr(mc), .n_unc(me), .n_relock(mr), .ck_syn(clk), .ck_dly(clk), .ck_chn(clk), .ck_out(clk));

 integer cyc=0,epoch=0,age=0,bad=0,checks=0,valid_words=0,mut_bad=0,mut_epoch[0:3];
 reg [31:0] rng=32'hb1730a19;
 integer i;
 always @(negedge clk) begin
   cyc=cyc+1;
   if(cyc==9 || cyc==921 || cyc==1841) begin rst_n=1;age=0;end
   if(cyc==901 || cyc==1821) begin rst_n=0;age=0;epoch=epoch+1;end
   tx_v=rst_n;
   for(i=0;i<16;i=i+1) begin
     rng=rng^(rng<<13);rng=rng^(rng>>17);rng=rng^(rng<<5);
     tx_d[i*32+:32]=rng;
   end
   ch_d=p_d;
   // Finite symbol errors, including uncorrectable frames, exercise unchanged syndrome path.
   if(p_v && cyc%97==0) ch_d[123+:10]=p_d[123+:10]^10'h093;
   if(p_v && cyc%211==0) ch_d[300+:160]=p_d[300+:160]^{16{10'h001}};
   if(rst_n) age=age+1;
   if(age>12) begin
     checks=checks+1;
     if({cv,cl,cc,ce,cr} !== {gv,gl,gc,ge,gr}) begin
       bad=bad+1; if(bad<4)$display("XFACE_CONTROL_BAD cycle=%0d age=%0d",cyc,age);
     end
     if(gv || cv) begin
       valid_words=valid_words+1;
       if({cf,cu,cn,cs,cd} !== {gf,gu,gn,gs,gd}) begin
         bad=bad+1; if(bad<4)$display("XFACE_DATA_BAD cycle=%0d epoch=%0d",cyc,epoch);
       end
       if({mf,mu,mn,ms,md} !== {gf,gu,gn,gs,gd}) begin mut_bad=mut_bad+1;mut_epoch[epoch]=mut_epoch[epoch]+1;end
     end
   end
   if(cyc==2800) begin
     if(bad==0 && valid_words>1800 && mut_bad>0 && mut_epoch[0]>0 && mut_epoch[1]>0 && mut_epoch[2]>0)
       $display("XFACE_FULL_DECODER_PASS checks=%0d valid_words=%0d resets=3 mutant_mismatches=%0d",checks,valid_words,mut_bad);
     else $display("XFACE_FULL_DECODER_FAIL checks=%0d valid_words=%0d bad=%0d mutant=%0d epochs=%0d,%0d,%0d",checks,valid_words,bad,mut_bad,mut_epoch[0],mut_epoch[1],mut_epoch[2]);
     $finish;
   end
 end
 initial begin for(i=0;i<4;i=i+1)mut_epoch[i]=0;end
endmodule
