`timescale 1ns/1ps
module coupon(input wire ck,rst_n,input wire[3:0]sid,input wire[1:0]colsel,input wire[452:0]hr_q,input wire xt_v,input wire[23:0]xt_a,input wire[1023:0]xt_d,output wire[515:0]cw_n0,cs0,output wire fault);
wire[1566:0]hw;wire[23:0]cid;wire tap_fault,fch0;wire[7:0]lqb0;
qfd_dv_s8_tap_bounded u_tap(.ck(ck),.rst_n(rst_n),.sid(sid),.hr_q(hr_q),.xt_vcopies({6{xt_v}}),.xt_a(xt_a),.xt_d(xt_d),.xt_bad(1'b0),.lq_bad({24'd0,lqb0}),.hw(hw),.cid(cid),.tap_fault(tap_fault));
    // ---- column 0: xhead + 8 x leaves (two write chains of 4)
    wire [1:0] lw_v0, lw_ep0, lc_v0, lc_ep0; wire [11:0] lw_off0; wire [127:0] lw_m0; wire [2047:0] lw_d0;
    wire [143:0] lw_ctl0; wire [7:0] lr_v0, lr_t0, lr_ep0, lq_v0; wire [223:0] lr_p0; wire [511:0] lq0; wire lrst0;
    qfd_dv_s5_xhead3 u_xh0 (.ck(ck), .rst_n(rst_n), .cid(cid[6*colsel+:6]), .fault_i(1'b0), .a_d(hw),
        .n_d(cw_n0), .s_d(cs0), .lw_v(lw_v0), .lw_ep(lw_ep0), .lc_v(lc_v0), .lc_ep(lc_ep0), .lw_off(lw_off0),
        .lw_m(lw_m0), .lw_d(lw_d0), .lw_ctl(lw_ctl0), .lr_v(lr_v0), .lr_t(lr_t0), .lr_ep(lr_ep0), .lr_p(lr_p0),
        .lq(lq0), .lq_v(lq_v0), .lq_bad(lqb0), .l_rst_n(lrst0), .fault(fch0));
    wire x00cv0, x00cep0, x00wv0, x00wep0; wire [5:0] x00woff0; wire [63:0] x00wm0; wire [1023:0] x00wd0; wire [71:0] x00wc0;
    wire x00cv1, x00cep1, x00wv1, x00wep1; wire [5:0] x00woff1; wire [63:0] x00wm1; wire [1023:0] x00wd1; wire [71:0] x00wc1;
    wire x00cv2, x00cep2, x00wv2, x00wep2; wire [5:0] x00woff2; wire [63:0] x00wm2; wire [1023:0] x00wd2; wire [71:0] x00wc2;
    wire x00cv3, x00cep3, x00wv3, x00wep3; wire [5:0] x00woff3; wire [63:0] x00wm3; wire [1023:0] x00wd3; wire [71:0] x00wc3;
    wire x00cv4, x00cep4, x00wv4, x00wep4; wire [5:0] x00woff4; wire [63:0] x00wm4; wire [1023:0] x00wd4; wire [71:0] x00wc4;
    assign x00cv0 = lc_v0[0]; assign x00cep0 = lc_ep0[0]; assign x00wv0 = lw_v0[0]; assign x00wep0 = lw_ep0[0];
    assign x00woff0 = lw_off0[5:0]; assign x00wm0 = lw_m0[63:0]; assign x00wd0 = lw_d0[1023:0]; assign x00wc0 = lw_ctl0[71:0];
    ot_qfd_xs_leaf_fo32_w
`ifdef OT_S8_SIM
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`else
`ifndef OT_S5_HARD
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`endif
`endif
        u_xl0_0 (.clk(ck), .rst_n(rst_n),
        .w_v(x00wv0), .w_ep(x00wep0), .w_off(x00woff0), .w_m(x00wm0), .w_d(x00wd0), .w_ctl(x00wc0),
        .c_v(x00cv0), .c_ep(x00cep0), .wo_v(x00wv1), .wo_ep(x00wep1), .wo_off(x00woff1),
        .wo_m(x00wm1), .wo_d(x00wd1), .wo_ctl(x00wc1), .co_v(x00cv1), .co_ep(x00cep1),
        .r_v(lr_v0[0]), .r_t(lr_t0[0]), .r_ep(lr_ep0[0]), .r_p(lr_p0[27:0]),
        .q_v(lq_v0[0]), .q(lq0[63:0]), .q_bad(lqb0[0]));
    ot_qfd_xs_leaf_fo32_w
`ifdef OT_S8_SIM
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`else
`ifndef OT_S5_HARD
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`endif
`endif
        u_xl0_1 (.clk(ck), .rst_n(rst_n),
        .w_v(x00wv1), .w_ep(x00wep1), .w_off(x00woff1), .w_m(x00wm1), .w_d(x00wd1), .w_ctl(x00wc1),
        .c_v(x00cv1), .c_ep(x00cep1), .wo_v(x00wv2), .wo_ep(x00wep2), .wo_off(x00woff2),
        .wo_m(x00wm2), .wo_d(x00wd2), .wo_ctl(x00wc2), .co_v(x00cv2), .co_ep(x00cep2),
        .r_v(lr_v0[1]), .r_t(lr_t0[1]), .r_ep(lr_ep0[1]), .r_p(lr_p0[55:28]),
        .q_v(lq_v0[1]), .q(lq0[127:64]), .q_bad(lqb0[1]));
    ot_qfd_xs_leaf_fo32_w
`ifdef OT_S8_SIM
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`else
`ifndef OT_S5_HARD
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`endif
`endif
        u_xl0_2 (.clk(ck), .rst_n(rst_n),
        .w_v(x00wv2), .w_ep(x00wep2), .w_off(x00woff2), .w_m(x00wm2), .w_d(x00wd2), .w_ctl(x00wc2),
        .c_v(x00cv2), .c_ep(x00cep2), .wo_v(x00wv3), .wo_ep(x00wep3), .wo_off(x00woff3),
        .wo_m(x00wm3), .wo_d(x00wd3), .wo_ctl(x00wc3), .co_v(x00cv3), .co_ep(x00cep3),
        .r_v(lr_v0[2]), .r_t(lr_t0[2]), .r_ep(lr_ep0[2]), .r_p(lr_p0[83:56]),
        .q_v(lq_v0[2]), .q(lq0[191:128]), .q_bad(lqb0[2]));
    ot_qfd_xs_leaf_fo32_w
`ifdef OT_S8_SIM
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`else
`ifndef OT_S5_HARD
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`endif
`endif
        u_xl0_3 (.clk(ck), .rst_n(rst_n),
        .w_v(x00wv3), .w_ep(x00wep3), .w_off(x00woff3), .w_m(x00wm3), .w_d(x00wd3), .w_ctl(x00wc3),
        .c_v(x00cv3), .c_ep(x00cep3), .wo_v(x00wv4), .wo_ep(x00wep4), .wo_off(x00woff4),
        .wo_m(x00wm4), .wo_d(x00wd4), .wo_ctl(x00wc4), .co_v(x00cv4), .co_ep(x00cep4),
        .r_v(lr_v0[3]), .r_t(lr_t0[3]), .r_ep(lr_ep0[3]), .r_p(lr_p0[111:84]),
        .q_v(lq_v0[3]), .q(lq0[255:192]), .q_bad(lqb0[3]));
    wire x01cv0, x01cep0, x01wv0, x01wep0; wire [5:0] x01woff0; wire [63:0] x01wm0; wire [1023:0] x01wd0; wire [71:0] x01wc0;
    wire x01cv1, x01cep1, x01wv1, x01wep1; wire [5:0] x01woff1; wire [63:0] x01wm1; wire [1023:0] x01wd1; wire [71:0] x01wc1;
    wire x01cv2, x01cep2, x01wv2, x01wep2; wire [5:0] x01woff2; wire [63:0] x01wm2; wire [1023:0] x01wd2; wire [71:0] x01wc2;
    wire x01cv3, x01cep3, x01wv3, x01wep3; wire [5:0] x01woff3; wire [63:0] x01wm3; wire [1023:0] x01wd3; wire [71:0] x01wc3;
    wire x01cv4, x01cep4, x01wv4, x01wep4; wire [5:0] x01woff4; wire [63:0] x01wm4; wire [1023:0] x01wd4; wire [71:0] x01wc4;
    assign x01cv0 = lc_v0[1]; assign x01cep0 = lc_ep0[1]; assign x01wv0 = lw_v0[1]; assign x01wep0 = lw_ep0[1];
    assign x01woff0 = lw_off0[11:6]; assign x01wm0 = lw_m0[127:64]; assign x01wd0 = lw_d0[2047:1024]; assign x01wc0 = lw_ctl0[143:72];
    ot_qfd_xs_leaf_fo32_w
`ifdef OT_S8_SIM
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`else
`ifndef OT_S5_HARD
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`endif
`endif
        u_xl0_4 (.clk(ck), .rst_n(rst_n),
        .w_v(x01wv0), .w_ep(x01wep0), .w_off(x01woff0), .w_m(x01wm0), .w_d(x01wd0), .w_ctl(x01wc0),
        .c_v(x01cv0), .c_ep(x01cep0), .wo_v(x01wv1), .wo_ep(x01wep1), .wo_off(x01woff1),
        .wo_m(x01wm1), .wo_d(x01wd1), .wo_ctl(x01wc1), .co_v(x01cv1), .co_ep(x01cep1),
        .r_v(lr_v0[4]), .r_t(lr_t0[4]), .r_ep(lr_ep0[4]), .r_p(lr_p0[139:112]),
        .q_v(lq_v0[4]), .q(lq0[319:256]), .q_bad(lqb0[4]));
    ot_qfd_xs_leaf_fo32_w
`ifdef OT_S8_SIM
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`else
`ifndef OT_S5_HARD
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`endif
`endif
        u_xl0_5 (.clk(ck), .rst_n(rst_n),
        .w_v(x01wv1), .w_ep(x01wep1), .w_off(x01woff1), .w_m(x01wm1), .w_d(x01wd1), .w_ctl(x01wc1),
        .c_v(x01cv1), .c_ep(x01cep1), .wo_v(x01wv2), .wo_ep(x01wep2), .wo_off(x01woff2),
        .wo_m(x01wm2), .wo_d(x01wd2), .wo_ctl(x01wc2), .co_v(x01cv2), .co_ep(x01cep2),
        .r_v(lr_v0[5]), .r_t(lr_t0[5]), .r_ep(lr_ep0[5]), .r_p(lr_p0[167:140]),
        .q_v(lq_v0[5]), .q(lq0[383:320]), .q_bad(lqb0[5]));
    ot_qfd_xs_leaf_fo32_w
`ifdef OT_S8_SIM
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`else
`ifndef OT_S5_HARD
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`endif
`endif
        u_xl0_6 (.clk(ck), .rst_n(rst_n),
        .w_v(x01wv2), .w_ep(x01wep2), .w_off(x01woff2), .w_m(x01wm2), .w_d(x01wd2), .w_ctl(x01wc2),
        .c_v(x01cv2), .c_ep(x01cep2), .wo_v(x01wv3), .wo_ep(x01wep3), .wo_off(x01woff3),
        .wo_m(x01wm3), .wo_d(x01wd3), .wo_ctl(x01wc3), .co_v(x01cv3), .co_ep(x01cep3),
        .r_v(lr_v0[6]), .r_t(lr_t0[6]), .r_ep(lr_ep0[6]), .r_p(lr_p0[195:168]),
        .q_v(lq_v0[6]), .q(lq0[447:384]), .q_bad(lqb0[6]));
    ot_qfd_xs_leaf_fo32_w
`ifdef OT_S8_SIM
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`else
`ifndef OT_S5_HARD
        #(.NCH(4), .READ_PIN_PIPE(1), .FILL_PIPE(1))
`endif
`endif
        u_xl0_7 (.clk(ck), .rst_n(rst_n),
        .w_v(x01wv3), .w_ep(x01wep3), .w_off(x01woff3), .w_m(x01wm3), .w_d(x01wd3), .w_ctl(x01wc3),
        .c_v(x01cv3), .c_ep(x01cep3), .wo_v(x01wv4), .wo_ep(x01wep4), .wo_off(x01woff4),
        .wo_m(x01wm4), .wo_d(x01wd4), .wo_ctl(x01wc4), .co_v(x01cv4), .co_ep(x01cep4),
        .r_v(lr_v0[7]), .r_t(lr_t0[7]), .r_ep(lr_ep0[7]), .r_p(lr_p0[223:196]),
        .q_v(lq_v0[7]), .q(lq0[511:448]), .q_bad(lqb0[7]));
assign fault=tap_fault|fch0;
endmodule
