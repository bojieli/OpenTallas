localparam integer NCASE = 2;
localparam integer NVMI = 40960;
localparam integer NHBM = 122888;
localparam integer NEXP = 48;
localparam [31:0] NEPS = 32'h1E3CE508;
