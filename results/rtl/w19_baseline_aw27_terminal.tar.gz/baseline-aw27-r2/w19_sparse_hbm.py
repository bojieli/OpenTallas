"""Generate test-only exact-address backing for the pinned finiteHBM service.

Only backing-store reads/writes change. All controller queue, bank timing,
refresh, return and DUT ready/valid logic stays byte-identical. Missing full
addresses fail; finite stored keys never wrap into another resident address.
"""
import hashlib
from pathlib import Path

PIN='d19116e6485266aef997ae52c82a46421267f5de9bb6d0b380d7348b30ffd57d'
BACKING='''
    reg [AW-1:0] mem_addr [0:MEM_WORDS-1];
    reg mem_valid [0:MEM_WORDS-1];
    integer sparse_init;
    initial for(sparse_init=0;sparse_init<MEM_WORDS;sparse_init=sparse_init+1) mem_valid[sparse_init]=0;
    function automatic integer sparse_slot(input [AW-1:0] address);
        integer s;
        begin
            sparse_slot=-1;
            for(s=0;s<MEM_WORDS;s=s+1)
                if(mem_valid[s] && mem_addr[s]==address) sparse_slot=s;
        end
    endfunction
    function automatic [DW-1:0] sparse_read(input [AW-1:0] address);
        integer s;
        begin
            s=sparse_slot(address);
            if(s<0) begin
                $fatal(1,"SPARSE_HBM_UNMAPPED_ADDRESS %h",address);
                sparse_read=0;
            end else sparse_read=mem[s];
        end
    endfunction
    task automatic sparse_write(input [AW-1:0] address,input [DW-1:0] data);
        integer s,j;
        begin
            s=sparse_slot(address);
            if(s<0) for(j=MEM_WORDS-1;j>=0;j=j-1) if(!mem_valid[j]) s=j;
            if(s<0) $fatal(1,"SPARSE_HBM_BACKING_FULL");
            else begin mem_addr[s]=address;mem_valid[s]=1;mem[s]=data;end
        end
    endtask
'''


def generate(source,output):
    raw=Path(source).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=PIN:raise ValueError('Pinned finiteHBM controller source changed')
    original=raw.decode()
    text=original.replace('module ot_hdc_hbm_model #(', 'module ot_hdc_hbm_sparse_model #(',1)
    anchor='    reg [DW-1:0] mem [0:MEM_WORDS-1];'
    if text.count(anchor)!=1:raise ValueError('Backing declaration changed')
    text=text.replace(anchor,anchor+BACKING)
    write='mem[q_addr[p][slot] % MEM_WORDS] = q_data[p][slot];'
    read='r_data[p][k] = mem[q_addr[p][slot] % MEM_WORDS];'
    if text.count(write)!=1 or text.count(read)!=1:raise ValueError('Controller backing accesses changed')
    text=text.replace(write,'sparse_write(q_addr[p][slot],q_data[p][slot]);')
    text=text.replace(read,'r_data[p][k] = sparse_read(q_addr[p][slot]);')
    recovered=text.replace(BACKING,'').replace('module ot_hdc_hbm_sparse_model #(','module ot_hdc_hbm_model #(',1)
    recovered=recovered.replace('sparse_write(q_addr[p][slot],q_data[p][slot]);',write)
    recovered=recovered.replace('r_data[p][k] = sparse_read(q_addr[p][slot]);',read)
    if recovered!=original:raise ValueError('Controller service differs beyond declared backing-store replacements')
    Path(output).write_text(text)
    return dict(pinned_controller_sha256=PIN,generated_sha256=hashlib.sha256(text.encode()).hexdigest(),
        controller_service_byte_identical_after_declared_backing_substitutions=True,
        default_address_bits=24,backing='Exact full-address bounded dictionary; no modulo aliases or reloads')
