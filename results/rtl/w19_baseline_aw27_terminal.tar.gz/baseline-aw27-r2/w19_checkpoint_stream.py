#!/usr/bin/env python3
"""Bounded raw-checkpoint -> golden SM issue-order payload stream.

No decoded whole tensor is allocated. Existing golden issue_order is the
producer contract; slices preserve packed FP4 nibbles, FP8 signed zeros and
UE8M0 codes. BF16 wo_a conversion uses the golden's existing rounding point.
"""
import hashlib
from pathlib import Path
import numpy as np
import rtl_v41_fullshape_layer_campaign as LC
import rtl_gpu_sm_exact as S
import hdc_golden as G
import hdc_golden_v41 as V


def shape(ck,name):
    meta,_,_=ck.meta(name)
    rows,cols=meta['shape']
    return rows,cols*2 if meta['dtype']=='I8' else cols


def close_mappings(ck):
    # Call only after an exhausted generator has released its tensor views.
    for mm in ck._mm.values():mm._mmap.close()
    ck._mm.clear()


def raw_view(ck,name):
    _,_,file=ck.meta(name)
    if file not in ck._mm:
        ck._mm[file]=np.memmap(ck.snap/file,dtype=np.uint8,mode='r')
    raw,dt,dims=ck.raw(name)
    dtype={'I8':np.uint8,'F8_E4M3':np.uint8,'F8_E8M0':np.uint8,'BF16':np.uint16,'F32':np.float32}[dt]
    return np.frombuffer(raw,dtype=dtype).reshape(dims),dt


def records(ck,names,rows,k,fmt,*,column=0,source_hash=None):
    """Yield136B records; `rows` is global row range over concatenated names."""
    if isinstance(names,str):names=[names]
    r0,r1=rows
    weights=[];scales=[];limits=[];offset=0
    for name in names:
        w,dt=raw_view(ck,name)
        width=w.shape[1]*(2 if dt=='I8' else 1)
        if column+k>width:raise ValueError('K slice outside checkpoint tensor')
        scale_name=name[:-len('.weight')]+'.scale'
        scale=None
        if scale_name in ck:
            scale,sd=raw_view(ck,scale_name)
            if sd!='F8_E8M0':raise ValueError('Unsupported scale contract')
            if scale.shape not in ((w.shape[0],width//32),((w.shape[0]+31)//32,width//32)):
                raise ValueError('Checkpoint scale geometry mismatch')
        if fmt=='fp4' and dt!='I8':raise ValueError('FP4 source dtype mismatch')
        if fmt=='fp8' and dt!='F8_E4M3':raise ValueError('FP8 source dtype mismatch')
        if fmt!='bf16' and scale is None:raise ValueError('Quantised source lacks UE8M0 scale')
        if fmt=='bf16' and dt not in ('BF16','F8_E4M3'):raise ValueError('Unmodelled BF16 source conversion')
        weights.append((w,dt));scales.append(scale);limits.append((offset,offset+w.shape[0]));offset+=w.shape[0]
    if not 0<=r0<=r1<=offset:raise ValueError('Rows outside checkpoint')
    lanes={'fp4':8,'fp8':4,'bf16':64}[fmt]
    chunks=(k+7)//8 if fmt=='bf16' else (k//32+7)//8
    groups=(chunks+lanes-1)//lanes
    if groups*8>128:raise ValueError('Existing x store geometry exceeded')
    for local,g,t in S.issue_order(r1-r0,groups,8,True):
        global_row=r0+local
        tensor=next(i for i,(lo,hi) in enumerate(limits) if lo<=global_row<hi)
        row=global_row-limits[tensor][0];w,dt=weights[tensor];scale=scales[tensor]
        sr=row if scale is not None and len(scale)==len(w) else row//32
        out=bytearray(136)
        for lane in range(lanes):
            ch=g*lanes+lane
            if ch>=chunks:continue
            if fmt=='bf16':
                col=column+ch*8+t
                if col>=column+k:continue
                if dt=='BF16':raw=int(w[row,col]).to_bytes(2,'little')
                else:
                    if scale is None:raise ValueError('Scaled BF16 source lacks scale')
                    code=int(w[row,col]);exp=int(scale[sr,col//32])-127
                    if code&127==127:raise ValueError('Checkpoint E4M3 NaN code')
                    value=np.ldexp(np.float32(V.E4M3[code]),exp).astype(np.float32)
                    bits=int(S.bf16_bits(np.array([value],dtype=np.float32))[0])
                    raw=bits.to_bytes(2,'little')
                    if source_hash:source_hash.update(bytes([code,int(scale[sr,col//32])]))
                out[lane*2:lane*2+2]=raw
                if source_hash and dt=='BF16':source_hash.update(raw)
            else:
                block=ch*8+t
                if block>=k//32:continue
                col=column+block*32
                if fmt=='fp4':raw=w[row,col//2:col//2+16].tobytes();begin=lane*16
                else:
                    raw=w[row,col:col+32].tobytes();begin=lane*32
                    if any(x&127==127 for x in raw):raise ValueError('Checkpoint E4M3 NaN code')
                expo=int(scale[sr,col//32])
                out[begin:begin+len(raw)]=raw;out[128+lane]=expo
                if source_hash:source_hash.update(raw+bytes([expo]))
        yield bytes(out)


def write_logical(ck,names,rows,k,fmt,output,*,column=0):
    digest=hashlib.sha256();source=hashlib.sha256();count=0
    with Path(output).open('x') as f:
        for word in records(ck,names,rows,k,fmt,column=column,source_hash=source):
            text=f'{int.from_bytes(word,"little"):0272x}\n';f.write(text);digest.update(text.encode());count+=1
    close_mappings(ck)
    return dict(payloads=count,logical_sha256=digest.hexdigest(),consumed_checkpoint_bytes_sha256=source.hexdigest())
