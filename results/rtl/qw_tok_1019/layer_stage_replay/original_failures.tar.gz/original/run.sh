#!/bin/bash
# REFILL-1225/QWLAYER: replay the Codex TP8 recorded VECTOR stage cuts (resid1/resid2/SiLU/QK; d47ceb7b1/416cd1a11 fixtures)
# on the die-of-record dv2f18dh2 source 0d4c9808f RTL (fresh Verilator 5.050 tb_qfd_dv2 N12 build) at MU_NU=$1.
# Lowering/bench overlay = files absent in 0d4c9808f taken from 416cd1a11 (dv_lower_vec*, dv_layer*). Matrix cuts (qkv/gu/od)
# NOT run: dh2 dv_lower.cmd_stn needs kc (redstn2 last-k) and dv_lower_mat.py does not emit it (compiler port owed).
set -uo pipefail
NU=$1; R=/srv/opentallas-scratch/claude/refill-1225/QWLAYER; SRC=$R/src; FX=$R/fx_qk; W=$R/nu$NU
export QWEN_O4_TP=8 QWEN_O4_GROUPS=3072 HDC_SU_WIDTH=64 HDC_KV_FMT=fp8 OT_GOLD_ROOT=$SRC
export PATH=$HOME/.local/opentallas-tools/verilator-5.050/bin:$PATH
mkdir -p $W; verilator --version; date -Is
SRCS=$(cd $SRC/rtl/test/qwen_dv && python3 -c "import dv_bench2 as B2; print(' '.join('$SRC/'+s for s in B2.SRCS2))")
OBJ=$W/obj_n12
verilator --cc --exe --build -O2 -j 16 -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD --x-assign 0 --x-initial 0 \
  --top-module tb_qfd_dv2 --prefix Vtb -GMUT=0 -GN=12 -GMU_NU=$NU -Mdir $OBJ $SRC/rtl/test/qwen_dv/main2.cpp $SRCS > $W/build.log 2>&1
echo "build rc=$?"; date -Is
[ -x $OBJ/Vtb ] || { echo BUILD FAILED; tail -30 $W/build.log; exit 1; }
sha256sum $OBJ/Vtb
job() {
  name=$1; exp=$2; shift 2; d=$W/runs/$name; mkdir -p $d; ln -sfn $OBJ $d/obj_n12
  python3 $SRC/rtl/test/qwen_dv/dv_lower_vec_bench.py "$@" --work $d > $d/bench.out 2>&1; rc=$?
  echo "rc=$rc" >> $d/bench.out; v=OK; [ $rc -eq $exp ] || v=UNEXPECTED
  echo "CASE $name exp=$exp rc=$rc $v :: $(head -1 $d/bench.out | cut -c1-260)"
}
export -f job; export W OBJ SRC FX
{
for L in 0 1; do
  echo "L${L}_resid1 0 --mode resid --ar-order row --fixture $FX/L${L}_resid1_tp8.npz"
  echo "L${L}_silu 0 --mode silu --fixture $FX/L${L}_silu_tp8.npz"
  echo "L${L}_qk 0 --mode qk --fixture $FX/L${L}_qk_tp8.npz"
done
echo "L0_resid2 0 --mode resid --ar-order row --fixture $FX/L0_resid2_tp8.npz"
echo "MUT_L0_resid1_arwin 1 --mode resid --ar-order row --mutant arwin --fixture $FX/L0_resid1_tp8.npz"
echo "MUT_L0_silu_nor 1 --mode silu --mutant nor --fixture $FX/L0_silu_tp8.npz"
echo "MUT_L0_qk_ropesign 1 --mode qk --mutant ropesign --fixture $FX/L0_qk_tp8.npz"
} | xargs -P 5 -L 1 bash -c 'job "$@"' _
date -Is; echo ALL DONE NU=$NU
