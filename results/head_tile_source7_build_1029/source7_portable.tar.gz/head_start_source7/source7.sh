#!/bin/bash
set -euo pipefail
W=/srv/opentallas-scratch2/claude/wt/codex-head-start-0251
R=/srv/opentallas-scratch2/claude/codex-head-start-0251
cd "$W"
python3 tools/s81_head/head_start_sources.py "$W/run/head_start_0251/compose4c" "$R/local_start6" "$R/leaf_reset6.json" --observer-spec "$R/observer5.json" --observer-rtl "$R/ot_s81hd_ctl_core.sv" --out "$W/run/head_start_0251/source7" --origin-export-copy hd_tile > "$R/source7.log" 2>&1

python3 tools/s81_head/head_start_native_headers.py "$W/run/head_start_0251/source7" --repo "$W" --out "$R/source7_headers.json" > "$R/source7_headers.log" 2>&1
