estimate_parasitics -placement
source /src/physical/ref_tile/s81frame_col_h9_rf2/clock_entry.sdc
