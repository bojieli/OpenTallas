#!/bin/bash
set -euo pipefail
mkdir -p receipts_cont
hostname > receipts_cont/host.txt
docker image inspect sha256:16470cea1d346bfa245e402108995a4f04a1e54fe7c7bb7441774d7f6a2ece29 > receipts_cont/image_inspect.json
sha256sum check_v2.py continue.sh elaborated.json mutant* x_assess.sv > receipts_cont/input_hashes.txt
docker run --rm -v "$PWD:/work" -w /work sha256:16470cea1d346bfa245e402108995a4f04a1e54fe7c7bb7441774d7f6a2ece29 bash -c '
set -euo pipefail
python3 check_v2.py > receipts_cont/structural_check.log
for F in mutant_*.ys; do
 N=${F%.ys}
 /usr/bin/time -v -o receipts_cont/$N.time yosys -Q -T -s "$F" > receipts_cont/$N.log 2>&1
 grep -q "SAT proof finished - model found: FAIL" receipts_cont/$N.log
done
if command -v iverilog >/dev/null; then
 iverilog -V > receipts_cont/iverilog.version 2>&1
 /usr/bin/time -v -o receipts_cont/x_assess_compile.time iverilog -g2012 -s xtest -o x_assess.vvp x_assess.sv > receipts_cont/x_assess_compile.log 2>&1
 /usr/bin/time -v -o receipts_cont/x_assess.time vvp x_assess.vvp > receipts_cont/x_assess.log 2>&1
else
 echo "IVERILOG_UNAVAILABLE_SOURCE_NATIVE_X_UNRESOLVED" > receipts_cont/x_assess.log
fi
echo PRIVATE_PUBLICATION_CONTROLS_COMPLETE
'
date -u > receipts_cont/end.txt
du -sk . > receipts_cont/disk_kib.txt
