#!/bin/bash
set -euo pipefail
mkdir -p receipts_x
hostname > receipts_x/host.txt
iverilog -V > receipts_x/iverilog.version 2>&1
sha256sum "$(command -v iverilog)" "$(command -v vvp)" x_assess.sv > receipts_x/input_tool_hashes.txt
/usr/bin/time -v -o receipts_x/compile.time iverilog -g2012 -s xtest -o x_host.vvp x_assess.sv > receipts_x/compile.log 2>&1
/usr/bin/time -v -o receipts_x/run.time vvp x_host.vvp > receipts_x/result.log 2>&1
cat receipts_x/result.log
