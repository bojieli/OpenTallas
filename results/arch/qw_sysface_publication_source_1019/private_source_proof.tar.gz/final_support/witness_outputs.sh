#!/bin/bash
set -euo pipefail
mkdir -p receipts_outputs
hostname > receipts_outputs/host.txt
sha256sum mutant*_outputs.ys mutant*.sv > receipts_outputs/input_hashes.txt
docker run --rm -v "$PWD:/work" -w /work sha256:16470cea1d346bfa245e402108995a4f04a1e54fe7c7bb7441774d7f6a2ece29 bash -c '
set -euo pipefail
for F in mutant_*_outputs.ys; do
 N=${F%.ys}
 /usr/bin/time -v -o receipts_outputs/$N.time yosys -Q -T -s "$F" > receipts_outputs/$N.log 2>&1
 grep -q "SAT proof finished - model found: FAIL" receipts_outputs/$N.log
done'
