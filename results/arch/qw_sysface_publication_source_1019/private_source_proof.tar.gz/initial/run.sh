#!/bin/bash
set -euo pipefail
mkdir -p receipts
hostname > receipts/host.txt
date -u > receipts/start.txt
docker image inspect sha256:16470cea1d346bfa245e402108995a4f04a1e54fe7c7bb7441774d7f6a2ece29 > receipts/image_inspect.json
sha256sum input/* *.py *.sv *.ys > receipts/input_hashes.txt
docker run --rm -v "$PWD:/work" -w /work sha256:16470cea1d346bfa245e402108995a4f04a1e54fe7c7bb7441774d7f6a2ece29 bash -c '
set -euo pipefail
yosys -V > receipts/yosys.version
sha256sum "$(command -v yosys)" > receipts/tool_hashes.txt
for F in elab binary native_binary four; do
 /usr/bin/time -v -o receipts/$F.time yosys -Q -T -s $F.ys > receipts/$F.log 2>&1
done
python3 check.py > receipts/structural_check.log
for F in mutant_*.ys; do
 N=${F%.ys}
 /usr/bin/time -v -o receipts/$N.time yosys -Q -T -s "$F" > receipts/$N.log 2>&1
 grep -q "SAT proof finished - model found: FAIL" receipts/$N.log
done
if command -v iverilog >/dev/null; then
 iverilog -V > receipts/iverilog.version 2>&1
 /usr/bin/time -v -o receipts/x_assess_compile.time iverilog -g2012 -s xtest -o x_assess.vvp x_assess.sv > receipts/x_assess_compile.log 2>&1
 /usr/bin/time -v -o receipts/x_assess.time vvp x_assess.vvp > receipts/x_assess.log 2>&1
else
 echo "IVERILOG_UNAVAILABLE_SOURCE_NATIVE_X_UNRESOLVED" > receipts/x_assess.log
fi
echo PRIVATE_PUBLICATION_PROOF_COMPLETE
'
date -u > receipts/end.txt
du -sk . > receipts/disk_kib.txt
