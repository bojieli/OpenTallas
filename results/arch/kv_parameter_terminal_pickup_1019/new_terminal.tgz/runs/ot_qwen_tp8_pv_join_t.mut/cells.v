module AND2x2_ASAP7_75t_R (A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = (A & B);
endmodule
module AND2x4_ASAP7_75t_R (A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = (A & B);
endmodule
module AND3x1_ASAP7_75t_R (A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = (A & B & C);
endmodule
module AND3x2_ASAP7_75t_R (A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = (A & B & C);
endmodule
module AND4x1_ASAP7_75t_R (A, B, C, D, Y);
  input A;
  input B;
  input C;
  input D;
  output Y;
  assign Y = (A & B & C & D);
endmodule
module AND5x1_ASAP7_75t_R (A, B, C, D, E, Y);
  input A;
  input B;
  input C;
  input D;
  input E;
  output Y;
  assign Y = (A & B & C & D & E);
endmodule
module AO211x2_ASAP7_75t_R (A1, A2, B, C, Y);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  assign Y = ((A1 & A2) | B | C);
endmodule
module AO21x1_ASAP7_75t_R (A1, A2, B, Y);
  input A1;
  input A2;
  input B;
  output Y;
  assign Y = ((A1 & A2) | B);
endmodule
module AO21x2_ASAP7_75t_R (A1, A2, B, Y);
  input A1;
  input A2;
  input B;
  output Y;
  assign Y = ((A1 & A2) | B);
endmodule
module AO221x1_ASAP7_75t_R (A1, A2, B1, B2, C, Y);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  assign Y = ((A1 & A2) | (B1 & B2) | C);
endmodule
module AO222x2_ASAP7_75t_R (A1, A2, B1, B2, C1, C2, Y);
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
  assign Y = ((A1 & A2) | (B1 & B2) | (C1 & C2));
endmodule
module AO22x1_ASAP7_75t_R (A1, A2, B1, B2, Y);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  assign Y = ((A1 & A2) | (B1 & B2));
endmodule
module AO22x2_ASAP7_75t_R (A1, A2, B1, B2, Y);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  assign Y = ((A1 & A2) | (B1 & B2));
endmodule
module AO31x2_ASAP7_75t_R (A1, A2, A3, B, Y);
  input A1;
  input A2;
  input A3;
  input B;
  output Y;
  assign Y = ((A1 & A2 & A3) | B);
endmodule
module AO32x1_ASAP7_75t_R (A1, A2, A3, B1, B2, Y);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  output Y;
  assign Y = ((A1 & A2 & A3) | (B1 & B2));
endmodule
module AO33x2_ASAP7_75t_R (A1, A2, A3, B1, B2, B3, Y);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
  assign Y = ((A1 & A2 & A3) | (B1 & B2 & B3));
endmodule
module AOI211x1_ASAP7_75t_R (A1, A2, B, C, Y);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  assign Y = (((~A1) & (~B) & (~C)) | ((~A2) & (~B) & (~C)));
endmodule
module AOI21x1_ASAP7_75t_R (A1, A2, B, Y);
  input A1;
  input A2;
  input B;
  output Y;
  assign Y = (((~A1) & (~B)) | ((~A2) & (~B)));
endmodule
module AOI221x1_ASAP7_75t_R (A1, A2, B1, B2, C, Y);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  assign Y = (((~A1) & (~B1) & (~C)) | ((~A1) & (~B2) & (~C)) | ((~A2) & (~B1) & (~C)) | ((~A2) & (~B2) & (~C)));
endmodule
module AOI22x1_ASAP7_75t_R (A1, A2, B1, B2, Y);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  assign Y = (((~A1) & (~B1)) | ((~A1) & (~B2)) | ((~A2) & (~B1)) | ((~A2) & (~B2)));
endmodule
module BUFx10_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module BUFx12_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module BUFx12f_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module BUFx16f_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module BUFx24_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module BUFx2_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module BUFx3_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module BUFx4f_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module BUFx6f_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module BUFx8_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module CKINVDCx10_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module CKINVDCx11_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module CKINVDCx14_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module CKINVDCx20_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module CKINVDCx5p33_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module CKINVDCx6p67_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module CKINVDCx8_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module CKINVDCx9p33_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module DFFASRHQNx1_ASAP7_75t_R (CLK, D, RESETN, SETN, QN, OT_S);
  input CLK;
  input D;
  input RESETN;
  input SETN;
  output QN;
  output OT_S;
  reg IQN;
  assign OT_S = ~IQN;
  wire IQNN = ~IQN;
  wire clr__w = (~SETN);
  wire pre__w = (~RESETN);
  always @(posedge CLK or posedge clr__w or posedge pre__w) begin if (clr__w) IQN <= 1'b0; else if (pre__w) IQN <= 1'b1; else IQN <= (~D); end
  assign QN = IQN;
endmodule
module DFFHQNx1_ASAP7_75t_R (CLK, D, QN, OT_S);
  input CLK;
  input D;
  output QN;
  output OT_S;
  reg IQN;
  assign OT_S = ~IQN;
  wire IQNN = ~IQN;
  always @(posedge CLK) begin IQN <= (~D); end
  assign QN = IQN;
endmodule
module DFFHQNx2_ASAP7_75t_R (CLK, D, QN, OT_S);
  input CLK;
  input D;
  output QN;
  output OT_S;
  reg IQN;
  assign OT_S = ~IQN;
  wire IQNN = ~IQN;
  always @(posedge CLK) begin IQN <= (~D); end
  assign QN = IQN;
endmodule
module HB2xp67_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = A;
endmodule
module INVx11_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module INVx1_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module INVx2_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module INVx3_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module INVx4_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module INVx5_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module INVx6_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module INVx8_ASAP7_75t_R (A, Y);
  input A;
  output Y;
  assign Y = (~A);
endmodule
module MAJx2_ASAP7_75t_R (A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = ((A & B) | (A & C) | (B & C));
endmodule
module NAND2x1_ASAP7_75t_R (A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = ((~A) | (~B));
endmodule
module NAND2x2_ASAP7_75t_R (A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = ((~A) | (~B));
endmodule
module NAND3x1_ASAP7_75t_R (A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = ((~A) | (~B) | (~C));
endmodule
module NAND3x2_ASAP7_75t_R (A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = ((~A) | (~B) | (~C));
endmodule
module NOR2x1_ASAP7_75t_R (A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = ((~A) & (~B));
endmodule
module NOR2x2_ASAP7_75t_R (A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = ((~A) & (~B));
endmodule
module NOR3x1_ASAP7_75t_R (A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = ((~A) & (~B) & (~C));
endmodule
module OA211x2_ASAP7_75t_R (A1, A2, B, C, Y);
  input A1;
  input A2;
  input B;
  input C;
  output Y;
  assign Y = ((A1 & B & C) | (A2 & B & C));
endmodule
module OA21x2_ASAP7_75t_R (A1, A2, B, Y);
  input A1;
  input A2;
  input B;
  output Y;
  assign Y = ((A1 & B) | (A2 & B));
endmodule
module OA221x2_ASAP7_75t_R (A1, A2, B1, B2, C, Y);
  input A1;
  input A2;
  input B1;
  input B2;
  input C;
  output Y;
  assign Y = ((A1 & B1 & C) | (A1 & B2 & C) | (A2 & B1 & C) | (A2 & B2 & C));
endmodule
module OA222x2_ASAP7_75t_R (A1, A2, B1, B2, C1, C2, Y);
  input A1;
  input A2;
  input B1;
  input B2;
  input C1;
  input C2;
  output Y;
  assign Y = ((A1 & B1 & C1) | (A1 & B1 & C2) | (A1 & B2 & C1) | (A1 & B2 & C2) | (A2 & B1 & C1) | (A2 & B1 & C2) | (A2 & B2 & C1) | (A2 & B2 & C2));
endmodule
module OA22x2_ASAP7_75t_R (A1, A2, B1, B2, Y);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  assign Y = ((A1 & B1) | (A1 & B2) | (A2 & B1) | (A2 & B2));
endmodule
module OA31x2_ASAP7_75t_R (A1, A2, A3, B1, Y);
  input A1;
  input A2;
  input A3;
  input B1;
  output Y;
  assign Y = ((A1 & B1) | (A2 & B1) | (A3 & B1));
endmodule
module OA33x2_ASAP7_75t_R (A1, A2, A3, B1, B2, B3, Y);
  input A1;
  input A2;
  input A3;
  input B1;
  input B2;
  input B3;
  output Y;
  assign Y = ((A1 & B1) | (A1 & B2) | (A1 & B3) | (A2 & B1) | (A2 & B2) | (A2 & B3) | (A3 & B1) | (A3 & B2) | (A3 & B3));
endmodule
module OAI21x1_ASAP7_75t_R (A1, A2, B, Y);
  input A1;
  input A2;
  input B;
  output Y;
  assign Y = (((~A1) & (~A2)) | (~B));
endmodule
module OAI22x1_ASAP7_75t_R (A1, A2, B1, B2, Y);
  input A1;
  input A2;
  input B1;
  input B2;
  output Y;
  assign Y = (((~A1) & (~A2)) | ((~B1) & (~B2)));
endmodule
module OR2x2_ASAP7_75t_R (A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = (A | B);
endmodule
module OR3x1_ASAP7_75t_R (A, B, C, Y);
  input A;
  input B;
  input C;
  output Y;
  assign Y = (A | B | C);
endmodule
module OR4x1_ASAP7_75t_R (A, B, C, D, Y);
  input A;
  input B;
  input C;
  input D;
  output Y;
  assign Y = (A | B | C | D);
endmodule
module OR5x1_ASAP7_75t_R (A, B, C, D, E, Y);
  input A;
  input B;
  input C;
  input D;
  input E;
  output Y;
  assign Y = (A | B | C | D | E);
endmodule
module TIEHIx1_ASAP7_75t_R (H);
  output H;
  assign H = 1'b1;
endmodule
module XNOR2x2_ASAP7_75t_R (A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = ((A & B) | ((~A) & (~B)));
endmodule
module XOR2x2_ASAP7_75t_R (A, B, Y);
  input A;
  input B;
  output Y;
  assign Y = ((A & (~B)) | ((~A) & B));
endmodule
