import json, os, re, sys, time
from pathlib import Path

def capture(pids):
    boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip().replace('-', '')
    hz = os.sysconf('SC_CLK_TCK')
    observed = time.time_ns() // 1000
    boot_us = int(time.clock_gettime(time.CLOCK_BOOTTIME) * 1000000)
    for pid in pids:
        try:
            stat = Path('/proc/' + pid + '/stat').read_text().rsplit(')', 1)[1].split()
            ticks = int(stat[19])
            cg = Path('/proc/' + pid + '/cgroup').read_text().splitlines()
            exclusive = []
            for line in cg:
                # Unified cgroups only: controller-specific mount mapping is not guessed.
                if not line.startswith('0::'):
                    continue
                path = line.split(':', 2)[2]
                try:
                    members = Path('/sys/fs/cgroup' + path + '/cgroup.procs').read_text().split()
                    if members and all(os.getpgid(int(p)) == os.getpgrp() for p in members):
                        exclusive.append(path)
                except (OSError, ValueError):
                    pass
            # Re-read stat: reject a process that disappeared/reused during capture.
            again = Path('/proc/' + pid + '/stat').read_text().rsplit(')', 1)[1].split()
            if int(again[19]) != ticks:
                continue
            yield dict(pid=int(pid), boot_id=boot, start_ticks=ticks,
                       birth_us=observed-boot_us+ticks*1000000//hz,
                       observed_us=observed, cgroups=[x.split(':', 2)[2] for x in cg],
                       exclusive_cgroups=exclusive)
        except (OSError, ValueError, IndexError):
            continue

def attribute(events, samples, run, stage_tag):
    # Kernel companion records carry the killed task's cgroup, unlike journald's
    # own _SYSTEMD_CGROUP for an earlyoom service message.
    context = {}
    for e in events:
        m = re.search(r'task_memcg=([^, ]+).*?pid=(\d+)', str(e.get('MESSAGE', '')))
        if m:
            context.setdefault((e.get('_BOOT_ID'), int(m[2])), []).append((int(e.get('__REALTIME_TIMESTAMP', 0)), m[1]))
    owned, unknown, consumed = [], [], set()
    def event_time(e):
        try: return int(e.get('__REALTIME_TIMESTAMP', 0))
        except (ValueError, TypeError): return 0
    for e in sorted(events, key=event_time):
        msg = str(e.get('MESSAGE', ''))
        m = re.search(r'(?:to process|Killed process) (\d+)', msg)
        if not m or not (re.search(r'sending SIG(?:TERM|KILL) to process', msg) or 'Killed process ' in msg):
            continue
        try:
            pid, when = int(m[1]), int(e['__REALTIME_TIMESTAMP'])
        except (ValueError, KeyError):
            unknown.append(dict(event=e, reason='missing event identity/time')); continue
        identities = [s for s in samples if s['pid'] == pid and s['boot_id'] == e.get('_BOOT_ID')
                      and s['birth_us'] <= when and s['observed_us'] <= when]
        # A later captured incarnation existing before this event supersedes old
        # records. Do not combine bare PIDs across process lifetimes.
        if identities:
            latest = max(s['start_ticks'] for s in identities)
            identities = [s for s in identities if s['start_ticks'] == latest]
        key = (e.get('_BOOT_ID'), pid)
        prior = [x for x in context.get(key, []) if x[0] <= when and (key, x) not in consumed]
        # A kernel companion is consumed by its next kernel kill, never by an
        # earlyoom PID-only message or a later reuse of this PID.
        chosen = max(prior) if prior and 'Killed process ' in msg else None
        cg = chosen[1] if chosen else None
        if chosen:
            consumed.add((key, chosen))
        stage_path = run.rstrip('/') + '/cl/' + stage_tag + '.sh'
        path_owned = bool(stage_tag and re.search(r"(?:^|[\s'\"])" + re.escape(stage_path) +
                                                r"(?=$|[\s'\";,()\[\]])", msg))
        # A root/user/session shared cgroup is not stage ownership evidence.
        def private(c):
            return c not in ('/', '/user.slice') and ('.scope' in c or '/docker/' in c or 'docker-' in c)
        # Missing journal kill records must not carry a previous incarnation's
        # companion into a later PID reuse, even when the cgroup text matches.
        context_identities = [s for s in identities if chosen and chosen[0] >= s['birth_us']]
        cg_owned = bool(cg and private(cg) and any(cg in s.get('exclusive_cgroups', []) for s in context_identities))
        mismatch = bool(cg and context_identities and not any(cg in s['cgroups'] for s in context_identities))
        if (path_owned or cg_owned) and not mismatch:
            owned.append(msg)
        else:
            unknown.append(dict(event=e, reason='target cgroup mismatch' if mismatch else
                                'no independently proven process incarnation ownership'))
    return owned, unknown

if __name__ == '__main__':
    if sys.argv[1] == 'capture':
        for s in capture(sys.argv[2:]): print(json.dumps(s, sort_keys=True))
    else:
        def records(path):
            out = []
            try:
                for line in Path(path).read_text().splitlines():
                    try: out.append(json.loads(line))
                    except ValueError: pass
            except OSError: pass
            return out
        owned, unknown = attribute(records(sys.argv[2]), records(sys.argv[3]), sys.argv[4], sys.argv[7])
        Path(sys.argv[5]).write_text(''.join(x + '\n' for x in owned))
        Path(sys.argv[6]).write_text(''.join(json.dumps(x, sort_keys=True) + '\n' for x in unknown))

