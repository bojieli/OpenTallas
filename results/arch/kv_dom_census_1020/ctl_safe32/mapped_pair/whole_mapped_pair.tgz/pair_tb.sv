`timescale 1ns/1ps
module tb; parameter integer MUT=0; reg ck=0; always #5 ck=~ck; integer e=0,checks=0,failures=0;
reg rst_n;
reg [142:0] boot__boot_pr;
reg [3:0] boot__boot_image_target;
reg boot__boot_image_ready;
reg boot__boot_image_fault;
reg [15:0] boot__boot_image_epoch;
reg [63:0] boot__boot_image_digest;
reg [173:0] d2d__svc;
reg por_n;
reg [292:0] embgw__bw;
reg st;
reg [81:0] auth;
reg [58:0] cht;
reg [1:0] chg;
reg [11:0] d2d__skw;
reg oobs__host_launch_quiet;
reg [5:0] oobs__host_upstream_quiet;
reg [521:0] d2d__srx;
reg [58:0] d2d__kvn_word_identity;
reg [1:0] d2d__kvn_word_generation;
wire boot__link_cfg_tx_we_ref, boot__link_cfg_tx_we_dut;
wire boot__link_cfg_rx_we_ref, boot__link_cfg_rx_we_dut;
wire [5:0] boot__link_cfg_addr_ref, boot__link_cfg_addr_dut;
wire [31:0] boot__link_cfg_data_ref, boot__link_cfg_data_dut;
wire [60:0] kvi_ref, kvi_dut;
wire oobs__kv_drained_local_ref, oobs__kv_drained_local_dut;
wire oobs__kv_flush_local_ref, oobs__kv_flush_local_dut;
wire oobs__kv_active_local_ref, oobs__kv_active_local_dut;
wire [22:0] kg_ref, kg_dut;
wire [20:0] lp_ref, lp_dut;
wire boot__setup_ready_ref, boot__setup_ready_dut;
wire own__native_reserved_ref, own__native_reserved_dut;
wire own__ownership_valid_ref, own__ownership_valid_dut;
wire cf_root__fault_ref, cf_root__fault_dut;
wire [76:0] o_attn_ref, o_attn_dut;
wire [72:0] o_emb_ref, o_emb_dut;
wire [1117:0] o_hroot_WS_ref, o_hroot_WS_dut;
reg [143:0] i_hroot_WS;
wire [1117:0] o_hroot_WN_ref, o_hroot_WN_dut;
reg [143:0] i_hroot_WN;
wire [1117:0] o_hroot_ES_ref, o_hroot_ES_dut;
reg [143:0] i_hroot_ES;
wire [1117:0] o_hroot_EN_ref, o_hroot_EN_dut;
reg [143:0] i_hroot_EN;
qkd_kvs_ctl reference(.ck(ck),.rst_n(rst_n),.boot__boot_pr(boot__boot_pr),.boot__boot_image_target(boot__boot_image_target),.boot__boot_image_ready(boot__boot_image_ready),.boot__boot_image_fault(boot__boot_image_fault),.boot__boot_image_epoch(boot__boot_image_epoch),.boot__boot_image_digest(boot__boot_image_digest),.d2d__svc(d2d__svc),.por_n(por_n),.embgw__bw(embgw__bw),.st(st),.auth(auth),.cht(cht),.chg(chg),.d2d__skw(d2d__skw),.oobs__host_launch_quiet(oobs__host_launch_quiet),.oobs__host_upstream_quiet(oobs__host_upstream_quiet),.d2d__srx(d2d__srx),.d2d__kvn_word_identity(d2d__kvn_word_identity),.d2d__kvn_word_generation(d2d__kvn_word_generation),.boot__link_cfg_tx_we(boot__link_cfg_tx_we_ref),.boot__link_cfg_rx_we(boot__link_cfg_rx_we_ref),.boot__link_cfg_addr(boot__link_cfg_addr_ref),.boot__link_cfg_data(boot__link_cfg_data_ref),.kvi(kvi_ref),.oobs__kv_drained_local(oobs__kv_drained_local_ref),.oobs__kv_flush_local(oobs__kv_flush_local_ref),.oobs__kv_active_local(oobs__kv_active_local_ref),.kg(kg_ref),.lp(lp_ref),.boot__setup_ready(boot__setup_ready_ref),.own__native_reserved(own__native_reserved_ref),.own__ownership_valid(own__ownership_valid_ref),.cf_root__fault(cf_root__fault_ref),.o_attn(o_attn_ref),.o_emb(o_emb_ref),.o_hroot_WS(o_hroot_WS_ref),.i_hroot_WS(i_hroot_WS),.o_hroot_WN(o_hroot_WN_ref),.i_hroot_WN(i_hroot_WN),.o_hroot_ES(o_hroot_ES_ref),.i_hroot_ES(i_hroot_ES),.o_hroot_EN(o_hroot_EN_ref),.i_hroot_EN(i_hroot_EN));
qkd_kvs_ctl_s32 candidate(.ck(ck),.rst_n(rst_n),.boot__boot_pr(boot__boot_pr),.boot__boot_image_target(boot__boot_image_target),.boot__boot_image_ready(boot__boot_image_ready),.boot__boot_image_fault(boot__boot_image_fault),.boot__boot_image_epoch(boot__boot_image_epoch),.boot__boot_image_digest(boot__boot_image_digest),.d2d__svc(d2d__svc),.por_n(por_n),.embgw__bw(embgw__bw),.st(st),.auth(auth),.cht(cht),.chg(chg),.d2d__skw(d2d__skw),.oobs__host_launch_quiet(oobs__host_launch_quiet),.oobs__host_upstream_quiet(oobs__host_upstream_quiet),.d2d__srx(d2d__srx),.d2d__kvn_word_identity(d2d__kvn_word_identity),.d2d__kvn_word_generation(d2d__kvn_word_generation),.boot__link_cfg_tx_we(boot__link_cfg_tx_we_dut),.boot__link_cfg_rx_we(boot__link_cfg_rx_we_dut),.boot__link_cfg_addr(boot__link_cfg_addr_dut),.boot__link_cfg_data(boot__link_cfg_data_dut),.kvi(kvi_dut),.oobs__kv_drained_local(oobs__kv_drained_local_dut),.oobs__kv_flush_local(oobs__kv_flush_local_dut),.oobs__kv_active_local(oobs__kv_active_local_dut),.kg(kg_dut),.lp(lp_dut),.boot__setup_ready(boot__setup_ready_dut),.own__native_reserved(own__native_reserved_dut),.own__ownership_valid(own__ownership_valid_dut),.cf_root__fault(cf_root__fault_dut),.o_attn(o_attn_dut),.o_emb(o_emb_dut),.o_hroot_WS(o_hroot_WS_dut),.i_hroot_WS(i_hroot_WS),.o_hroot_WN(o_hroot_WN_dut),.i_hroot_WN(i_hroot_WN),.o_hroot_ES(o_hroot_ES_dut),.i_hroot_ES(i_hroot_ES),.o_hroot_EN(o_hroot_EN_dut),.i_hroot_EN(i_hroot_EN));
initial begin
rst_n='0;
boot__boot_pr='0;
boot__boot_image_target='0;
boot__boot_image_ready='0;
boot__boot_image_fault='0;
boot__boot_image_epoch='0;
boot__boot_image_digest='0;
d2d__svc='0;
por_n='0;
embgw__bw='0;
st='0;
auth='0;
cht='0;
chg='0;
d2d__skw='0;
oobs__host_launch_quiet='0;
oobs__host_upstream_quiet='0;
d2d__srx='0;
d2d__kvn_word_identity='0;
d2d__kvn_word_generation='0;
i_hroot_WS='0;
i_hroot_WN='0;
i_hroot_ES='0;
i_hroot_EN='0;
for(e=0;e<3000;e=e+1) begin @(negedge ck);
boot__boot_pr[31:0]=$urandom;
boot__boot_pr[63:32]=$urandom;
boot__boot_pr[95:64]=$urandom;
boot__boot_pr[127:96]=$urandom;
boot__boot_pr[142:128]=$urandom;
boot__boot_image_target[3:0]=$urandom;
boot__boot_image_ready=$urandom;
boot__boot_image_fault=$urandom;
boot__boot_image_epoch[15:0]=$urandom;
boot__boot_image_digest[31:0]=$urandom;
boot__boot_image_digest[63:32]=$urandom;
d2d__svc[31:0]=$urandom;
d2d__svc[63:32]=$urandom;
d2d__svc[95:64]=$urandom;
d2d__svc[127:96]=$urandom;
d2d__svc[159:128]=$urandom;
d2d__svc[173:160]=$urandom;
embgw__bw[31:0]=$urandom;
embgw__bw[63:32]=$urandom;
embgw__bw[95:64]=$urandom;
embgw__bw[127:96]=$urandom;
embgw__bw[159:128]=$urandom;
embgw__bw[191:160]=$urandom;
embgw__bw[223:192]=$urandom;
embgw__bw[255:224]=$urandom;
embgw__bw[287:256]=$urandom;
embgw__bw[292:288]=$urandom;
st=$urandom;
auth[31:0]=$urandom;
auth[63:32]=$urandom;
auth[81:64]=$urandom;
cht[31:0]=$urandom;
cht[58:32]=$urandom;
chg[1:0]=$urandom;
d2d__skw[11:0]=$urandom;
oobs__host_launch_quiet=$urandom;
oobs__host_upstream_quiet[5:0]=$urandom;
d2d__srx[31:0]=$urandom;
d2d__srx[63:32]=$urandom;
d2d__srx[95:64]=$urandom;
d2d__srx[127:96]=$urandom;
d2d__srx[159:128]=$urandom;
d2d__srx[191:160]=$urandom;
d2d__srx[223:192]=$urandom;
d2d__srx[255:224]=$urandom;
d2d__srx[287:256]=$urandom;
d2d__srx[319:288]=$urandom;
d2d__srx[351:320]=$urandom;
d2d__srx[383:352]=$urandom;
d2d__srx[415:384]=$urandom;
d2d__srx[447:416]=$urandom;
d2d__srx[479:448]=$urandom;
d2d__srx[511:480]=$urandom;
d2d__srx[521:512]=$urandom;
d2d__kvn_word_identity[31:0]=$urandom;
d2d__kvn_word_identity[58:32]=$urandom;
d2d__kvn_word_generation[1:0]=$urandom;
i_hroot_WS[31:0]=$urandom;
i_hroot_WS[63:32]=$urandom;
i_hroot_WS[95:64]=$urandom;
i_hroot_WS[127:96]=$urandom;
i_hroot_WS[143:128]=$urandom;
i_hroot_WN[31:0]=$urandom;
i_hroot_WN[63:32]=$urandom;
i_hroot_WN[95:64]=$urandom;
i_hroot_WN[127:96]=$urandom;
i_hroot_WN[143:128]=$urandom;
i_hroot_ES[31:0]=$urandom;
i_hroot_ES[63:32]=$urandom;
i_hroot_ES[95:64]=$urandom;
i_hroot_ES[127:96]=$urandom;
i_hroot_ES[143:128]=$urandom;
i_hroot_EN[31:0]=$urandom;
i_hroot_EN[63:32]=$urandom;
i_hroot_EN[95:64]=$urandom;
i_hroot_EN[127:96]=$urandom;
i_hroot_EN[143:128]=$urandom;
rst_n=!((e<24)||(e>=900&&e<924)||(e>=1800&&e<1824)); por_n=!(e<24);
@(posedge ck); #1; if(e>=32) begin
checks++;if(boot__link_cfg_tx_we_ref !== (boot__link_cfg_tx_we_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d boot__link_cfg_tx_we ref%h got%h",e,boot__link_cfg_tx_we_ref,boot__link_cfg_tx_we_dut);end
checks++;if(boot__link_cfg_rx_we_ref !== (boot__link_cfg_rx_we_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d boot__link_cfg_rx_we ref%h got%h",e,boot__link_cfg_rx_we_ref,boot__link_cfg_rx_we_dut);end
checks++;if(boot__link_cfg_addr_ref !== (boot__link_cfg_addr_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d boot__link_cfg_addr ref%h got%h",e,boot__link_cfg_addr_ref,boot__link_cfg_addr_dut);end
checks++;if(boot__link_cfg_data_ref !== (boot__link_cfg_data_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d boot__link_cfg_data ref%h got%h",e,boot__link_cfg_data_ref,boot__link_cfg_data_dut);end
checks++;if(kvi_ref !== (kvi_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d kvi ref%h got%h",e,kvi_ref,kvi_dut);end
checks++;if(oobs__kv_drained_local_ref !== (oobs__kv_drained_local_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d oobs__kv_drained_local ref%h got%h",e,oobs__kv_drained_local_ref,oobs__kv_drained_local_dut);end
checks++;if(oobs__kv_flush_local_ref !== (oobs__kv_flush_local_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d oobs__kv_flush_local ref%h got%h",e,oobs__kv_flush_local_ref,oobs__kv_flush_local_dut);end
checks++;if(oobs__kv_active_local_ref !== (oobs__kv_active_local_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d oobs__kv_active_local ref%h got%h",e,oobs__kv_active_local_ref,oobs__kv_active_local_dut);end
checks++;if(kg_ref !== (kg_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d kg ref%h got%h",e,kg_ref,kg_dut);end
checks++;if(lp_ref !== (lp_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d lp ref%h got%h",e,lp_ref,lp_dut);end
checks++;if(boot__setup_ready_ref !== (boot__setup_ready_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d boot__setup_ready ref%h got%h",e,boot__setup_ready_ref,boot__setup_ready_dut);end
checks++;if(own__native_reserved_ref !== (own__native_reserved_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d own__native_reserved ref%h got%h",e,own__native_reserved_ref,own__native_reserved_dut);end
checks++;if(own__ownership_valid_ref !== (own__ownership_valid_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d own__ownership_valid ref%h got%h",e,own__ownership_valid_ref,own__ownership_valid_dut);end
checks++;if(cf_root__fault_ref !== (cf_root__fault_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d cf_root__fault ref%h got%h",e,cf_root__fault_ref,cf_root__fault_dut);end
checks++;if(o_attn_ref !== (o_attn_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d o_attn ref%h got%h",e,o_attn_ref,o_attn_dut);end
checks++;if(o_emb_ref !== (o_emb_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d o_emb ref%h got%h",e,o_emb_ref,o_emb_dut);end
checks++;if(o_hroot_WS_ref !== (o_hroot_WS_dut ^ ((MUT==1) ? 1118'd1 : 1118'd0))) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d o_hroot_WS ref%h got%h",e,o_hroot_WS_ref,o_hroot_WS_dut);end
checks++;if(o_hroot_WN_ref !== (o_hroot_WN_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d o_hroot_WN ref%h got%h",e,o_hroot_WN_ref,o_hroot_WN_dut);end
checks++;if(o_hroot_ES_ref !== (o_hroot_ES_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d o_hroot_ES ref%h got%h",e,o_hroot_ES_ref,o_hroot_ES_dut);end
checks++;if(o_hroot_EN_ref !== (o_hroot_EN_dut)) begin failures++; if(failures<10)$display("PAIR_MISMATCH e%0d o_hroot_EN ref%h got%h",e,o_hroot_EN_ref,o_hroot_EN_dut);end
end end
if(failures)$fatal(1,"CTL_PAIR_FAIL checks%0d failures%0d",checks,failures);
$display("CTL_PAIR_PASS checks%0d edges3000 fulloutputs warmresets2 matchedzeroInit",checks);$finish;end endmodule
