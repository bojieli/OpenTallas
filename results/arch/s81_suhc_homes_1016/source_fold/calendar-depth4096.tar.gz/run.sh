#!/bin/bash
set -euo pipefail
mkdir -p out
iverilog -g2012 -s tb_s81_su_calendar_store_depth -o out/positive tb_depth.sv rtl/dsrom_sys/s81_suhc/hier/ot_s81_su_calendar_store.sv rtl/dsrom_sys/s81_suhc/hier/ot_s81_su_calendar_ctl.sv physical/asap7_memory_macros_v2/ot_sram_1r1w_64x512_m1_r2c2/ot_sram_1r1w_64x512_m1_r2c2.v rtl/hdc/ot_sram_bank.sv
vvp out/positive >out/positive.log 2>&1
grep -q 'MAPPED_CALENDAR PASS' out/positive.log
iverilog -g2012 -s tb_s81_su_calendar_store_depth -o out/bank_mutant tb_depth.sv rtl/dsrom_sys/s81_suhc/hier/ot_s81_su_calendar_store.sv rtl/dsrom_sys/s81_suhc/hier/ot_s81_su_calendar_ctl.sv physical/asap7_memory_macros_v2/ot_sram_1r1w_64x512_m1_r2c2/ot_sram_1r1w_64x512_m1_r2c2.v bank_mutant.sv
set +e
vvp out/bank_mutant >out/bank_mutant.log 2>&1
rc=$?
set -e
[ "$rc" -ne 0 ]
grep -q 'calendar read address/order mismatch' out/bank_mutant.log
printf '%s
' "$rc" >out/bank_mutant.rc
echo 'DEFAULT_DEPTH_CALENDAR_GATE PASS'
