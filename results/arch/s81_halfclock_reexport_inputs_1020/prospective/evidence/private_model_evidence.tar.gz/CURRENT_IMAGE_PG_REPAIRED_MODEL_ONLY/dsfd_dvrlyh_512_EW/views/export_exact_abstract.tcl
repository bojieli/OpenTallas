read_db /base/6_final.odb
write_abstract_lef -bloat_factor 0 /out/dsfd_dvrlyh_512_EW.lef.exact
exit
