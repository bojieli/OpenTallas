# relay_reach_bench batch b02: 16 pairs, 1772 sink bits, die 1395.1 x 1249.1 um
proc mem {tag} { set f [open /proc/self/status]; set s [read $f]; close $f
  regexp {VmHWM:\s+(\d+)} $s -> h; puts "OTMEM $tag hwm_mb=[expr {$h/1024}] t=[clock seconds]"; flush stdout }
read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7_tech_1x_201209.lef
read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7sc7p5t_28_R_1x_220121a.lef
read_lef /stage/views/dsfd_stnh_70x1/dsfd_stnh_70x1_lef.lef
read_lef /stage/views/dsfd_stnv_10x1/dsfd_stnv_10x1_lef.lef
read_lef /stage/views/dsfd_stnv_293x1/dsfd_stnv_293x1_lef.lef
read_lef /stage/views/dsfd_stnv_70x1/dsfd_stnv_70x1_lef.lef
read_liberty /stage/views/dsfd_stnh_70x1/dsfd_stnh_70x1_tt.lib
read_liberty /stage/views/dsfd_stnv_10x1/dsfd_stnv_10x1_tt.lib
read_liberty /stage/views/dsfd_stnv_293x1/dsfd_stnv_293x1_tt.lib
read_liberty /stage/views/dsfd_stnv_70x1/dsfd_stnv_70x1_tt.lib
read_verilog /work/reach.v
link_design reach_top
initialize_floorplan -die_area {0 0 1415.040 1269.120} -core_area {0 0 1415.040 1269.120} -site asap7sc7p5t
source /OpenROAD-flow-scripts/flow/platforms/asap7/openRoad/make_tracks.tcl
place_inst -name P0_A -location {68.736 68.736} -orientation R0 -status FIRM
place_inst -name P0_B -location {68.736 805.248} -orientation R0 -status FIRM
place_inst -name P1_A -location {249.408 66.816} -orientation R0 -status FIRM
place_inst -name P1_B -location {249.408 783.936} -orientation R0 -status FIRM
place_inst -name P2_A -location {400.128 66.816} -orientation R0 -status FIRM
place_inst -name P2_B -location {400.128 783.936} -orientation R0 -status FIRM
place_inst -name P3_A -location {542.784 58.752} -orientation R0 -status FIRM
place_inst -name P3_B -location {542.784 595.392} -orientation R0 -status FIRM
place_inst -name P4_A -location {703.488 56.640} -orientation R0 -status FIRM
place_inst -name P4_B -location {703.488 573.888} -orientation R0 -status FIRM
place_inst -name P5_A -location {834.240 56.640} -orientation R0 -status FIRM
place_inst -name P5_B -location {834.240 573.888} -orientation R0 -status FIRM
place_inst -name P6_A -location {956.928 48.576} -orientation R0 -status FIRM
place_inst -name P6_B -location {956.928 385.152} -orientation R0 -status FIRM
place_inst -name P7_A -location {1097.664 46.656} -orientation R0 -status FIRM
place_inst -name P7_B -location {1097.664 363.840} -orientation R0 -status FIRM
place_inst -name P8_A -location {1208.448 46.656} -orientation R0 -status FIRM
place_inst -name P8_B -location {1208.448 363.840} -orientation R0 -status FIRM
place_inst -name P9_A -location {1311.168 38.592} -orientation R0 -status FIRM
place_inst -name P9_B -location {1311.168 175.104} -orientation R0 -status FIRM
place_inst -name P10_A -location {36.672 947.328} -orientation R0 -status FIRM
place_inst -name P10_B -location {36.672 1064.448} -orientation R0 -status FIRM
place_inst -name P11_A -location {127.488 947.328} -orientation R0 -status FIRM
place_inst -name P11_B -location {127.488 1064.448} -orientation R0 -status FIRM
place_inst -name P12_A -location {248.064 977.280} -orientation R0 -status FIRM
place_inst -name P12_B -location {965.184 977.280} -orientation R0 -status FIRM
place_inst -name P13_A -location {56.640 1175.040} -orientation R0 -status FIRM
place_inst -name P13_B -location {573.888 1175.040} -orientation R0 -status FIRM
place_inst -name P14_A -location {694.656 1165.056} -orientation R0 -status FIRM
place_inst -name P14_B -location {1011.840 1165.056} -orientation R0 -status FIRM
place_inst -name P15_A -location {1112.640 1155.072} -orientation R0 -status FIRM
place_inst -name P15_B -location {1229.760 1155.072} -orientation R0 -status FIRM
mem placed
source /OpenROAD-flow-scripts/flow/platforms/asap7/setRC.tcl
set_routing_layers -signal M4-M9
set_global_routing_layer_adjustment M4-M5 0.30
set_global_routing_layer_adjustment M6-M9 0.146
global_route -congestion_iterations 30 -allow_congestion -verbose -congestion_report_file /work/grt_congestion.rpt
mem grt
report_wire_length -net * -global_route -detailed_route -file /work/wirelength.csv
estimate_parasitics -global_routing -spef_file /work/reach.spef
write_verilog /work/reach_grt.v
mem done
puts OT_REACH_GRT_DONE
