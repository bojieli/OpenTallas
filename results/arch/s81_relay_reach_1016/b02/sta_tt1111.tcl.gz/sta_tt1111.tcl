# tt1111: tt setup at 1111.111 ps, neighbour skew 80.0 ps adverse
read_liberty /stage/views/dsfd_stnh_70x1/dsfd_stnh_70x1_tt.lib
read_liberty /stage/views/dsfd_stnv_10x1/dsfd_stnv_10x1_tt.lib
read_liberty /stage/views/dsfd_stnv_293x1/dsfd_stnv_293x1_tt.lib
read_liberty /stage/views/dsfd_stnv_70x1/dsfd_stnv_70x1_tt.lib
read_verilog /work/reach_grt.v
link_design reach_top
read_spef /work/reach_sta.spef
set cp [concat [get_pins -regexp {P0_A/fi0\[0\]}] [get_pins -regexp {P0_B/fi0\[0\]}] [get_pins -regexp {P1_A/fi0\[0\]}] [get_pins -regexp {P1_B/fi0\[0\]}] [get_pins -regexp {P2_A/fi0\[0\]}] [get_pins -regexp {P2_B/fi0\[0\]}] [get_pins -regexp {P3_A/fi0\[0\]}] [get_pins -regexp {P3_B/fi0\[0\]}] [get_pins -regexp {P4_A/fi0\[0\]}] [get_pins -regexp {P4_B/fi0\[0\]}] [get_pins -regexp {P5_A/fi0\[0\]}] [get_pins -regexp {P5_B/fi0\[0\]}] [get_pins -regexp {P6_A/fi0\[0\]}] [get_pins -regexp {P6_B/fi0\[0\]}] [get_pins -regexp {P7_A/fi0\[0\]}] [get_pins -regexp {P7_B/fi0\[0\]}] [get_pins -regexp {P8_A/fi0\[0\]}] [get_pins -regexp {P8_B/fi0\[0\]}] [get_pins -regexp {P9_A/fi0\[0\]}] [get_pins -regexp {P9_B/fi0\[0\]}] [get_pins -regexp {P10_A/fi0\[0\]}] [get_pins -regexp {P10_B/fi0\[0\]}] [get_pins -regexp {P11_A/fi0\[0\]}] [get_pins -regexp {P11_B/fi0\[0\]}] [get_pins -regexp {P12_A/fi0\[0\]}] [get_pins -regexp {P12_B/fi0\[0\]}] [get_pins -regexp {P13_A/fi0\[0\]}] [get_pins -regexp {P13_B/fi0\[0\]}] [get_pins -regexp {P14_A/fi0\[0\]}] [get_pins -regexp {P14_B/fi0\[0\]}] [get_pins -regexp {P15_A/fi0\[0\]}] [get_pins -regexp {P15_B/fi0\[0\]}]]
if {[llength $cp] != 32} { error "clock pin coverage mismatch" }
create_clock -name clk -period 1111.111 $cp
set_clock_uncertainty -setup 140.0 [all_clocks]
set_clock_uncertainty -hold 105.0 [all_clocks]
set f [open /work/tt1111.slk w]
set fp [open /work/sinks.txt r]
set n 0
while {[gets $fp pn] >= 0} {
  if {$pn eq ""} continue
  set p [get_pins $pn]
  puts $f "$pn [get_property $p slack_max] [get_property $p slew_max]"
  incr n
}
close $fp; close $f
report_checks -path_delay max -group_path_count 3 -fields {slew cap} -digits 2
puts "OT_REACH_STA_DONE tt1111 $n"
