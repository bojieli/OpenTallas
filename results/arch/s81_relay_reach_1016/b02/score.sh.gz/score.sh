#!/bin/bash
set -eu
B=$(cd "$(dirname "$0")" && pwd); S=${1:?stage dir}; cd "$B"
# This bench has no top ports. OpenROAD emits an empty *PORTS section;
# OpenSTA rejects it. Remove only that empty header; all extracted RC stays byte-identical.
sed '/^\*PORTS$/d' reach.spef > reach_sta.spef
for c in tt833 tt1111 ff_hold ss833; do
  docker run --rm --name reach_$(basename $(dirname $B))_$(basename $B)_$c --cpus=2 -v $B:/work -v $S:/stage:ro -w /work openroad/orfs:asap7lock \
    bash -lc "source /OpenROAD-flow-scripts/env.sh >/dev/null 2>&1; sta -no_init -exit /work/sta_$c.tcl > /work/sta_$c.log 2>&1; chmod -R a+rwX /work" &
done
wait
for c in tt833 tt1111 ff_hold ss833; do grep -q OT_REACH_STA_DONE sta_$c.log || { echo STA_FAIL $c; exit 1; }; done
rm -f reach.spef.gz; gzip -f reach.spef
echo BATCH_DONE
