# relay_reach_bench batch b03: 4 pairs, 344 sink bits, die 482.9 x 867.8 um
proc mem {tag} { set f [open /proc/self/status]; set s [read $f]; close $f
  regexp {VmHWM:\s+(\d+)} $s -> h; puts "OTMEM $tag hwm_mb=[expr {$h/1024}] t=[clock seconds]"; flush stdout }
read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7_tech_1x_201209.lef
read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7sc7p5t_28_R_1x_220121a.lef
read_lef /stage/views/dsfd_stnv_86x1/dsfd_stnv_86x1_lef.lef
read_liberty /stage/views/dsfd_stnv_86x1/dsfd_stnv_86x1_tt.lib
read_verilog /work/reach.v
link_design reach_top
initialize_floorplan -die_area {0 0 502.848 887.808} -core_area {0 0 502.848 887.808} -site asap7sc7p5t
source /OpenROAD-flow-scripts/flow/platforms/asap7/openRoad/make_tracks.tcl
place_inst -name P0_A -location {66.816 66.816} -orientation R0 -status FIRM
place_inst -name P0_B -location {66.816 783.936} -orientation R0 -status FIRM
place_inst -name P1_A -location {207.360 56.640} -orientation R0 -status FIRM
place_inst -name P1_B -location {207.360 573.888} -orientation R0 -status FIRM
place_inst -name P2_A -location {328.128 46.656} -orientation R0 -status FIRM
place_inst -name P2_B -location {328.128 363.840} -orientation R0 -status FIRM
place_inst -name P3_A -location {428.928 36.672} -orientation R0 -status FIRM
place_inst -name P3_B -location {428.928 153.792} -orientation R0 -status FIRM
mem placed
source /OpenROAD-flow-scripts/flow/platforms/asap7/setRC.tcl
set_routing_layers -signal M4-M9
set_global_routing_layer_adjustment M4-M5 0.30
set_global_routing_layer_adjustment M6-M9 0.146
global_route -congestion_iterations 30 -allow_congestion -verbose -congestion_report_file /work/grt_congestion.rpt
mem grt
report_wire_length -net * -global_route -detailed_route -file /work/wirelength.csv
estimate_parasitics -global_routing -spef_file /work/reach.spef
write_verilog /work/reach_grt.v
mem done
puts OT_REACH_GRT_DONE
