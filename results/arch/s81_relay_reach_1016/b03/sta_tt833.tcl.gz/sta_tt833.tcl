# tt833: tt setup at 833.333 ps, neighbour skew 80.0 ps adverse
read_liberty /stage/views/dsfd_stnv_86x1/dsfd_stnv_86x1_tt.lib
read_verilog /work/reach_grt.v
link_design reach_top
read_spef /work/reach_sta.spef
set cp [concat [get_pins -regexp {P0_A/fi0\[0\]}] [get_pins -regexp {P0_B/fi0\[0\]}] [get_pins -regexp {P1_A/fi0\[0\]}] [get_pins -regexp {P1_B/fi0\[0\]}] [get_pins -regexp {P2_A/fi0\[0\]}] [get_pins -regexp {P2_B/fi0\[0\]}] [get_pins -regexp {P3_A/fi0\[0\]}] [get_pins -regexp {P3_B/fi0\[0\]}]]
if {[llength $cp] != 8} { error "clock pin coverage mismatch" }
create_clock -name clk -period 833.333 $cp
set_clock_uncertainty -setup 140.0 [all_clocks]
set_clock_uncertainty -hold 105.0 [all_clocks]
set f [open /work/tt833.slk w]
set fp [open /work/sinks.txt r]
set n 0
while {[gets $fp pn] >= 0} {
  if {$pn eq ""} continue
  set p [get_pins $pn]
  puts $f "$pn [get_property $p slack_max] [get_property $p slew_max]"
  incr n
}
close $fp; close $f
report_checks -path_delay max -group_path_count 3 -fields {slew cap} -digits 2
puts "OT_REACH_STA_DONE tt833 $n"
