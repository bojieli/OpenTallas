# relay_reach_bench batch b00: 28 pairs, 15848 sink bits, die 2014.6 x 1698.1 um
proc mem {tag} { set f [open /proc/self/status]; set s [read $f]; close $f
  regexp {VmHWM:\s+(\d+)} $s -> h; puts "OTMEM $tag hwm_mb=[expr {$h/1024}] t=[clock seconds]"; flush stdout }
read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7_tech_1x_201209.lef
read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7sc7p5t_28_R_1x_220121a.lef
read_lef /stage/views/dsfd_stnv_566x1/dsfd_stnv_566x1_lef.lef
read_liberty /stage/views/dsfd_stnv_566x1/dsfd_stnv_566x1_tt.lib
read_verilog /work/reach.v
link_design reach_top
initialize_floorplan -die_area {0 0 2034.624 1718.016} -core_area {0 0 2034.624 1718.016} -site asap7sc7p5t
source /OpenROAD-flow-scripts/flow/platforms/asap7/openRoad/make_tracks.tcl
place_inst -name P0_A -location {67.584 67.584} -orientation R0 -status FIRM
place_inst -name P0_B -location {67.584 793.344} -orientation R0 -status FIRM
place_inst -name P1_A -location {261.888 66.432} -orientation R0 -status FIRM
place_inst -name P1_B -location {261.888 767.232} -orientation R0 -status FIRM
place_inst -name P2_A -location {453.888 65.088} -orientation R0 -status FIRM
place_inst -name P2_B -location {453.888 740.928} -orientation R0 -status FIRM
place_inst -name P3_A -location {643.200 63.744} -orientation R0 -status FIRM
place_inst -name P3_B -location {643.200 714.432} -orientation R0 -status FIRM
place_inst -name P4_A -location {830.208 62.592} -orientation R0 -status FIRM
place_inst -name P4_B -location {830.208 688.320} -orientation R0 -status FIRM
place_inst -name P5_A -location {1014.528 61.248} -orientation R0 -status FIRM
place_inst -name P5_B -location {1014.528 662.016} -orientation R0 -status FIRM
place_inst -name P6_A -location {1196.544 60.096} -orientation R0 -status FIRM
place_inst -name P6_B -location {1196.544 635.904} -orientation R0 -status FIRM
place_inst -name P7_A -location {1375.872 58.752} -orientation R0 -status FIRM
place_inst -name P7_B -location {1375.872 609.600} -orientation R0 -status FIRM
place_inst -name P8_A -location {1552.704 57.600} -orientation R0 -status FIRM
place_inst -name P8_B -location {1552.704 583.296} -orientation R0 -status FIRM
place_inst -name P9_A -location {1727.232 56.256} -orientation R0 -status FIRM
place_inst -name P9_B -location {1727.232 556.992} -orientation R0 -status FIRM
place_inst -name P10_A -location {1899.072 55.104} -orientation R0 -status FIRM
place_inst -name P10_B -location {1899.072 530.880} -orientation R0 -status FIRM
place_inst -name P11_A -location {53.760 940.608} -orientation R0 -status FIRM
place_inst -name P11_B -location {53.760 1391.424} -orientation R0 -status FIRM
place_inst -name P12_A -location {220.800 939.456} -orientation R0 -status FIRM
place_inst -name P12_B -location {220.800 1365.120} -orientation R0 -status FIRM
place_inst -name P13_A -location {385.152 938.112} -orientation R0 -status FIRM
place_inst -name P13_B -location {385.152 1338.816} -orientation R0 -status FIRM
place_inst -name P14_A -location {547.008 936.960} -orientation R0 -status FIRM
place_inst -name P14_B -location {547.008 1312.704} -orientation R0 -status FIRM
place_inst -name P15_A -location {706.368 935.616} -orientation R0 -status FIRM
place_inst -name P15_B -location {706.368 1286.400} -orientation R0 -status FIRM
place_inst -name P16_A -location {863.232 934.464} -orientation R0 -status FIRM
place_inst -name P16_B -location {863.232 1260.288} -orientation R0 -status FIRM
place_inst -name P17_A -location {1017.792 933.120} -orientation R0 -status FIRM
place_inst -name P17_B -location {1017.792 1233.792} -orientation R0 -status FIRM
place_inst -name P18_A -location {1169.664 931.968} -orientation R0 -status FIRM
place_inst -name P18_B -location {1169.664 1207.680} -orientation R0 -status FIRM
place_inst -name P19_A -location {1319.040 930.624} -orientation R0 -status FIRM
place_inst -name P19_B -location {1319.040 1181.376} -orientation R0 -status FIRM
place_inst -name P20_A -location {1465.920 929.472} -orientation R0 -status FIRM
place_inst -name P20_B -location {1465.920 1155.264} -orientation R0 -status FIRM
place_inst -name P21_A -location {1610.304 928.128} -orientation R0 -status FIRM
place_inst -name P21_B -location {1610.304 1128.960} -orientation R0 -status FIRM
place_inst -name P22_A -location {1752.192 926.976} -orientation R0 -status FIRM
place_inst -name P22_B -location {1752.192 1102.656} -orientation R0 -status FIRM
place_inst -name P23_A -location {1891.584 925.632} -orientation R0 -status FIRM
place_inst -name P23_B -location {1891.584 1076.352} -orientation R0 -status FIRM
place_inst -name P24_A -location {37.632 1508.928} -orientation R0 -status FIRM
place_inst -name P24_B -location {37.632 1634.688} -orientation R0 -status FIRM
place_inst -name P25_A -location {172.032 1507.584} -orientation R0 -status FIRM
place_inst -name P25_B -location {172.032 1608.384} -orientation R0 -status FIRM
place_inst -name P26_A -location {303.936 1506.432} -orientation R0 -status FIRM
place_inst -name P26_B -location {303.936 1582.272} -orientation R0 -status FIRM
place_inst -name P27_A -location {433.344 1505.088} -orientation R0 -status FIRM
place_inst -name P27_B -location {433.344 1555.776} -orientation R0 -status FIRM
mem placed
source /OpenROAD-flow-scripts/flow/platforms/asap7/setRC.tcl
set_routing_layers -signal M4-M9
set_global_routing_layer_adjustment M4-M5 0.30
set_global_routing_layer_adjustment M6-M9 0.146
global_route -congestion_iterations 30 -allow_congestion -verbose -congestion_report_file /work/grt_congestion.rpt
mem grt
report_wire_length -net * -global_route -detailed_route -file /work/wirelength.csv
estimate_parasitics -global_routing -spef_file /work/reach.spef
write_verilog /work/reach_grt.v
mem done
puts OT_REACH_GRT_DONE
