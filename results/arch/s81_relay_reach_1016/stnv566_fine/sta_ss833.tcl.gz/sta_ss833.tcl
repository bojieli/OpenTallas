# ss833: ss setup at 833.333 ps, neighbour skew 80.0 ps adverse
read_liberty /stage/views/dsfd_stnv_566x1/dsfd_stnv_566x1_ss.lib
read_verilog /work/reach_grt.v
link_design reach_top
read_spef /work/reach_sta.spef
set cp [concat [get_pins -regexp {P0_A/fi0\[0\]}] [get_pins -regexp {P0_B/fi0\[0\]}] [get_pins -regexp {P1_A/fi0\[0\]}] [get_pins -regexp {P1_B/fi0\[0\]}] [get_pins -regexp {P2_A/fi0\[0\]}] [get_pins -regexp {P2_B/fi0\[0\]}] [get_pins -regexp {P3_A/fi0\[0\]}] [get_pins -regexp {P3_B/fi0\[0\]}] [get_pins -regexp {P4_A/fi0\[0\]}] [get_pins -regexp {P4_B/fi0\[0\]}] [get_pins -regexp {P5_A/fi0\[0\]}] [get_pins -regexp {P5_B/fi0\[0\]}] [get_pins -regexp {P6_A/fi0\[0\]}] [get_pins -regexp {P6_B/fi0\[0\]}] [get_pins -regexp {P7_A/fi0\[0\]}] [get_pins -regexp {P7_B/fi0\[0\]}] [get_pins -regexp {P8_A/fi0\[0\]}] [get_pins -regexp {P8_B/fi0\[0\]}] [get_pins -regexp {P9_A/fi0\[0\]}] [get_pins -regexp {P9_B/fi0\[0\]}] [get_pins -regexp {P10_A/fi0\[0\]}] [get_pins -regexp {P10_B/fi0\[0\]}] [get_pins -regexp {P11_A/fi0\[0\]}] [get_pins -regexp {P11_B/fi0\[0\]}] [get_pins -regexp {P12_A/fi0\[0\]}] [get_pins -regexp {P12_B/fi0\[0\]}] [get_pins -regexp {P13_A/fi0\[0\]}] [get_pins -regexp {P13_B/fi0\[0\]}] [get_pins -regexp {P14_A/fi0\[0\]}] [get_pins -regexp {P14_B/fi0\[0\]}] [get_pins -regexp {P15_A/fi0\[0\]}] [get_pins -regexp {P15_B/fi0\[0\]}] [get_pins -regexp {P16_A/fi0\[0\]}] [get_pins -regexp {P16_B/fi0\[0\]}] [get_pins -regexp {P17_A/fi0\[0\]}] [get_pins -regexp {P17_B/fi0\[0\]}] [get_pins -regexp {P18_A/fi0\[0\]}] [get_pins -regexp {P18_B/fi0\[0\]}] [get_pins -regexp {P19_A/fi0\[0\]}] [get_pins -regexp {P19_B/fi0\[0\]}] [get_pins -regexp {P20_A/fi0\[0\]}] [get_pins -regexp {P20_B/fi0\[0\]}] [get_pins -regexp {P21_A/fi0\[0\]}] [get_pins -regexp {P21_B/fi0\[0\]}] [get_pins -regexp {P22_A/fi0\[0\]}] [get_pins -regexp {P22_B/fi0\[0\]}] [get_pins -regexp {P23_A/fi0\[0\]}] [get_pins -regexp {P23_B/fi0\[0\]}] [get_pins -regexp {P24_A/fi0\[0\]}] [get_pins -regexp {P24_B/fi0\[0\]}] [get_pins -regexp {P25_A/fi0\[0\]}] [get_pins -regexp {P25_B/fi0\[0\]}] [get_pins -regexp {P26_A/fi0\[0\]}] [get_pins -regexp {P26_B/fi0\[0\]}] [get_pins -regexp {P27_A/fi0\[0\]}] [get_pins -regexp {P27_B/fi0\[0\]}]]
if {[llength $cp] != 56} { error "clock pin coverage mismatch" }
create_clock -name clk -period 833.333 $cp
set_clock_uncertainty -setup 140.0 [all_clocks]
set_clock_uncertainty -hold 105.0 [all_clocks]
set f [open /work/ss833.slk w]
set fp [open /work/sinks.txt r]
set n 0
while {[gets $fp pn] >= 0} {
  if {$pn eq ""} continue
  set p [get_pins $pn]
  puts $f "$pn [get_property $p slack_max] [get_property $p slew_max]"
  incr n
}
close $fp; close $f
report_checks -path_delay max -group_path_count 3 -fields {slew cap} -digits 2
puts "OT_REACH_STA_DONE ss833 $n"
