#!/bin/bash
set -eu
B=$(cd "$(dirname "$0")" && pwd)
docker run --rm --cpus=1 -v "$B":/work openroad/orfs:asap7lock bash -lc 'source /OpenROAD-flow-scripts/env.sh >/dev/null 2>&1; openroad -threads 1 -no_init -exit /work/native.tcl > /work/native.log 2>&1; chmod -R a+rwX /work'
grep -q OT_NATIVE_ELECTRICAL_DONE "$B/native.log"
