# relay_reach_bench batch b00: 8 pairs, 1212 sink bits, die 910.6 x 915.4 um
proc mem {tag} { set f [open /proc/self/status]; set s [read $f]; close $f
  regexp {VmHWM:\s+(\d+)} $s -> h; puts "OTMEM $tag hwm_mb=[expr {$h/1024}] t=[clock seconds]"; flush stdout }
read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7_tech_1x_201209.lef
read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7sc7p5t_28_R_1x_220121a.lef
read_lef /stage/views/dsfd_stnh_10x1/dsfd_stnh_10x1_lef.lef
read_lef /stage/views/dsfd_stnh_293x1/dsfd_stnh_293x1_lef.lef
read_liberty /stage/views/dsfd_stnh_10x1/dsfd_stnh_10x1_tt.lib
read_liberty /stage/views/dsfd_stnh_293x1/dsfd_stnh_293x1_tt.lib
read_verilog /work/reach.v
link_design reach_top
initialize_floorplan -die_area {0 0 930.624 935.424} -core_area {0 0 930.624 935.424} -site asap7sc7p5t
source /OpenROAD-flow-scripts/flow/platforms/asap7/openRoad/make_tracks.tcl
place_inst -name P0_A -location {68.736 68.736} -orientation R0 -status FIRM
place_inst -name P0_B -location {805.248 68.736} -orientation R0 -status FIRM
place_inst -name P1_A -location {58.752 252.096} -orientation R0 -status FIRM
place_inst -name P1_B -location {595.200 252.096} -orientation R0 -status FIRM
place_inst -name P2_A -location {48.576 415.680} -orientation R0 -status FIRM
place_inst -name P2_B -location {385.152 415.680} -orientation R0 -status FIRM
place_inst -name P3_A -location {66.816 587.136} -orientation R0 -status FIRM
place_inst -name P3_B -location {783.936 587.136} -orientation R0 -status FIRM
place_inst -name P4_A -location {38.592 709.824} -orientation R0 -status FIRM
place_inst -name P4_B -location {175.104 709.824} -orientation R0 -status FIRM
place_inst -name P5_A -location {307.200 727.872} -orientation R0 -status FIRM
place_inst -name P5_B -location {824.448 727.872} -orientation R0 -status FIRM
place_inst -name P6_A -location {46.656 851.328} -orientation R0 -status FIRM
place_inst -name P6_B -location {363.840 851.328} -orientation R0 -status FIRM
place_inst -name P7_A -location {464.640 841.344} -orientation R0 -status FIRM
place_inst -name P7_B -location {581.760 841.344} -orientation R0 -status FIRM
mem placed
source /OpenROAD-flow-scripts/flow/platforms/asap7/setRC.tcl
set_routing_layers -signal M4-M9
set_global_routing_layer_adjustment M4-M5 0.30
set_global_routing_layer_adjustment M6-M9 0.146
global_route -congestion_iterations 30 -allow_congestion -verbose -congestion_report_file /work/grt_congestion.rpt
mem grt
report_wire_length -net * -global_route -detailed_route -file /work/wirelength.csv
estimate_parasitics -global_routing -spef_file /work/reach.spef
write_verilog /work/reach_grt.v
mem done
puts OT_REACH_GRT_DONE
