#!/bin/bash
# chain_after_build.sh TAG : (on the host, under ot-run) bind real views on TAG/out/case, build the STA libs, run the die chain
# (real case -> PDN r8 -> GRT 12 iters -> STA tt / ff / ss; SS is reported sensitivity) into TAG/chain; port-bind verdict first
set -u
T=$1; S=/srv/opentallas-scratch/claude/qwen-split-compute/$T
if [ "${OT_SAVED_CASE_PHYSICAL_DIAGNOSTIC:-0}" = 1 ]; then
  S=${OT_SAVED_CASE_ROOT:?explicit captured case path required}
  python3 "$(dirname "$0")/saved_case_diagnostic.py" "$S" "${OT_SAVED_CASE_MANIFEST:?exact source/case manifest required}" || exit 7
  export OT_CHAIN_DIAGNOSTIC=1
  # This physical path has no qualified schedule. The existing die-chain step
  # records SKIPPED rather than a fabricated calendar PASS.
  unset OT_RELAY_SCHEDULE
else
  grep -q '^rc=0' $S/out.log || { echo "build $T not rc=0"; exit 7; }
fi
R=$S/chain
mkdir -p $R/libs $R/case_r22k
cd $S/src
# several closed revisions of one master name: bind the recorded choice (bind.json lists the others per master)
[ -z "${OT_BIND_VIEW_SELECT:-}" ] && [ -f results/arch/qwen_split_compute_1014/bind_view_select.json ] && \
  export OT_BIND_VIEW_SELECT=results/arch/qwen_split_compute_1014/bind_view_select.json
python3 tools/qwen_tp8/bind_real.py --case ../out/case --repo . --out ../bind.json > $R/bind.log 2>&1 || { echo bind failed; exit 8; }
python3 tools/qwen_tp8/die_sta_libs.py --case ../out/case --repo . --bind ../bind.json --out $R/libs > $R/libs.log 2>&1 || { echo libs failed; exit 9; }
python3 tools/qwen_split/prepare_chain_case.py $R/case_r22k || exit 11
rsync -a ../out/case/ $R/case_r22k/
cp ../bind.json ../out/relay_run.json $R/
cat SOURCE_COMMIT > $R/case_r22k/SOURCE_COMMIT
# r3 (2026-10-14): PDN r7 -- M8 on the 2.16-um-commensurate 8.64 lattice, no macro grid for die relays (pdngen costs
# ~2 s per instance grid: the r5 case PDN of C3 ran > 5 h); the r5 file is kept beside it
# r8 (Q-COMPUTE-DIE 2026-10-15, default): r7 + die-top tie cells on local rows stacked M2->M9 (die_tie_rows.tcl), no
# die-wide M3..M7 stdcell ladder -- that ladder (58533b5a0) drove C19s / C21sa PDN to the 420 GiB cgroup kill
PDN_REV=${OT_PDN_REV:-r8}
TIE_LOCAL=; UP4SKIP="--skip-prefix up4_sel_"
# up4_sel_* (8.64-um-tall selector blocks) cannot host an M8 macro grid (PDN-0185): recorded PG islands with the PHYs
[ "$PDN_REV" = r8 ] && TIE_LOCAL=--tie-local
if [ "$PDN_REV" = r7 ] || [ "$PDN_REV" = r8 ]; then
  cp $R/case_r22k/pdn.tcl $R/case_r22k/pdn_r5.tcl
# licensed link-PHY abstracts (io_serdes*, io_ucie) carry their own M4 PG straps under a full M1-M5 OBS: no die macro
# grid reaches them (PDN-0006); their PG hookup is the PHY IP integration, recorded open (OT_PGCHECK reports it)
# Q-DIEPLAN8 10-17: the DV plans place ~500 hard relay macros (qfd_rly_*: VDD/VSS on M7 + one M8 rect at the cell foot).
# Under r8 with --skip-prefix rly_ no M8 stripe meets those pins (dv2f10 PSM-0039 on all 498 relays). OT_PDN_RELAY_GRIDS=1
# groups the relays into the per-phase macro grids like every other macro (4 y-phases on the 2.16 lattice).
  RLYSKIP="--skip-prefix rly_"; [ "${OT_PDN_RELAY_GRIDS:-0}" = 1 ] && RLYSKIP=
  # Q-DIE15 10-18: the CLOSED qfd_rst_rep / _p8 (12.96 x 6.48) carry VSS+VDD only as M5 straps in y 2.137..4.343: their
  # own M8 grid VSS 2.16 / VDD 3.84 (pitch 3.36) inside that window (dv2f14bi PDN-0185 on the 8.64 phase grid)
  OWNG=; [ "${OT_RST_REP_VIEW:-}" = closed ] && OWNG="--own-grid qfd_rst_rep=2.16,3.36 --own-grid qfd_rst_rep_p8=2.16,3.36"
  python3 tools/qwen_split/pdn_regroup.py $R/case_r22k $RLYSKIP $UP4SKIP $OWNG --skip-prefix io_serdes --skip-prefix io_ucie --pos ../out/rom_tp8b.json --out pdn.tcl $TIE_LOCAL > $R/pdn_$PDN_REV.json || { echo pdn regroup failed; exit 10; }
fi
# Binding supplies the actual modeled PHY masters, and regroup writes the final
# PDN grid. Apply the explicit contract here, before run.tcl creates any ODB.
if [ "${OT_ASSUMED_PHY_PG_ACCESS:-0}" = 1 ]; then
  python3 tools/phy_pg/apply_case.py $R/case_r22k --ack-assumed-phy-contract > $R/assumed_phy_pg_apply.json || exit 11
fi
# owner no-stub gate (08:05): strict port-bind first; the physical chain runs only on PASS (or as a marked diagnosis)
bash tools/qwen_split/port_bind_compute.sh $R/case_r22k/die.v $R/port_bind > $R/port_bind.line 2>&1; pb=$?
echo "$(date '+%F %T %Z') port-bind (no stubs): $(cat $R/port_bind.line) rc=$pb" >> $R/STATUS.log
# fail closed (Q-DIEPLAN2r 2026-10-16; r2h5 ran PDN/PLACE after strict bind rc3): no physical work on a die that
# fails the strict port-bind, unless explicitly run as a diagnosis (OT_CHAIN_DIAGNOSTIC=1), which leaves a durable
# DIAGNOSTIC_ONLY marker so the result can never be read as a die qualification
if [ $pb -ne 0 ]; then
  if [ "${OT_CHAIN_DIAGNOSTIC:-0}" != 1 ]; then
    echo "$(date '+%F %T %Z') STOP: strict port-bind rc=$pb; no physical chain (set OT_CHAIN_DIAGNOSTIC=1 for a diagnosis-only run)" >> $R/STATUS.log
    echo "strict port-bind rc=$pb: chain stopped before physical work"; exit 12
  fi
  echo "DIAGNOSTIC_ONLY: strict port-bind rc=$pb $(date '+%F %T %Z')" > $R/DIAGNOSTIC_ONLY
fi
echo "$(date '+%F %T %Z') qwen-split compute chain $T (src $(cat SOURCE_COMMIT)); real views: $(python3 -c "import json;b=json.load(open('../bind.json'));print(b['masters_bound'],'masters /',b['instances_bound'],'of',b['instances'],'instances')")" >> $R/STATUS.log
exec env OT_STA_SUMMARY=${OT_STA_SUMMARY:-1} OT_PG_OPEN_DIAG=${OT_PG_OPEN_DIAG:-1} OT_ADMIT=pass OT_ITERS=12 OT_ROUTE_RESET=1 OT_CORNERS="tt ff ss" OT_STA_CLOCKS=$R/libs/clocks.tcl bash $S/src/tools/qwen_kv_die/chain/die_chain.sh r22k $R $S/src
