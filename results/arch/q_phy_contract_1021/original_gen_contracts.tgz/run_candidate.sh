#!/bin/bash
set -eu
export ONE_HARD_M=qfd_c_b16_dv,qfd_dv_slice2
export OT_SPLIT_RST_REGION_LAND=1 OT_SPLIT_FWD_RST_SYNC=1
export OT_BIND_VIEW_SELECT=results/arch/qwen_split_compute_1014/bind_view_select.json
export OT_SPLIT_FWD_CLASSES=0 OT_SPLIT_FWD_CLASS_PACK=0 OT_BIND_FWD_CLASSES=0
export OT_QWEN_D2D_IMAGE=rtl/qwen_sys/d2d_static_20261015/d2d_cal_image_mu_ew595_r16.svh
export OT_GEN_SAFETY_FACTS_OUT=$PWD/gen_safety_facts.json
bash gen.sh
