`timescale 1ps/1fs
// Full actual three-producer fixture. Source stimulus: DMA4a49c18bc + quant88b62f789 immutable vectors.
module tb_hbm_native_threeproducer;
    parameter integer PHASE=61;
    parameter integer MUT = 0;
    parameter integer LD = 16;     // front lane buffer = svc initial credit
    parameter integer HOPS = 3;    // registered die-wire stages each way (data svc -> front, credit front -> svc)
    parameter integer NL = 8;      // svc data lanes a stack (lane l = idx % NL)
    parameter integer NB = 32;     // VM wide lanes (banks)
    parameter integer PCX4 = 0;
    parameter integer XP = 0;      // hbm-fq/dma 10-11: the textbook rebuild (registered X1 request vectors, X2 split, count rungs)
    parameter integer XS = 0;      // el1011-hbm-dmafs 10-12: 1 = the two-level split ot_hgi_dma_front_xsw (core + 4 slices)
    parameter integer XQ = 0;      // hbm-fq/mvf 10-11: X2 select rung + conversion rung + pin output register (needs XP)
    parameter integer AP = 0;      // hgi-1010 b: the weight aperture (VM words >= 2^18, 2 slots of 32,768): 281-b lanes, random
                                   //   per-bank wl_rdy stops (no lane may carry a sector 5+ edges into a stop), slot loads
    localparam integer VMW = AP ? 327680 : 262144, LWW = 280 + AP;    // HBM supply a stack in sectors per 4 cycles (99 = 3.80 TB/s a die at 1.2 GHz); 0 = unlimited
    localparam integer NS = 4, NIN = NS * NL, BW = $clog2(NB);
    localparam integer SBIT = 35; localparam longint SB = 22500000000;   // 1 MiB stacks in the bench
    reg [3:0] cclk=0;
    for(genvar q=0;q<4;q++)begin:clocks
      initial begin #(PHASE+q*17);forever #416.666625 cclk[q]=~cclk[q];end
    end
    wire clk=cclk[0];reg vmclk=0;always #555.5555 vmclk=~vmclk;reg rst_n=0;
    reg mv_v = 0; reg [226:0] mv = 0; wire mv_rdy, mv_done, mv_fault;
    reg ix_v = 0; reg [175:0] ix_cmd = 0; wire ix_rdy; reg id_v = 0; reg [31:0] id = 0; wire id_rdy;
    wire [NS*51-1:0] dq; reg [NS-1:0] dq_rdy = 0; reg [NIN*270-1:0] dd_m = 0; wire [NIN*270-1:0] dd; wire [NIN-1:0] dd_cr;
    wire [NB*LWW-1:0] wl; reg [NB-1:0] wl_done = 0; reg [NB-1:0] wl_rdy = '1; integer rlow [0:NB-1];
    wire [8*281-1:0] producer_packet;wire [7:0] producer_issue,vm_bad;wire leasebusy;
    wire [31:0] producer_credit,producer_done,qfault,native_done;wire [3:0] drained,lfault;wire [7:0] rfault;wire [32*281-1:0] native_dq;wire [31:0] dma_valid;
    for(genvar b=0;b<32;b++)assign dma_valid[b]=native_dq[b*281+280];
    ot_hgi_dma_front_xsw6b #(.QID(0),.NL(8),.LD(16),.SBIT(SBIT),.STACK_BYTES(36'(SB)),.MUT(MUT))dut(
      .clk(clk),.lane_clk({8{clk}}),.slice_clk(clk),.rst_n(rst_n),.mv_v(mv_v),.mv_rdy(mv_rdy),.mv(mv),.mv_done(mv_done),.mv_fault(mv_fault),
      .ix_v(ix_v),.ix_rdy(ix_rdy),.ix_cmd(ix_cmd),.id_v(id_v),.id_rdy(id_rdy),.id(id),.dq(dq),.dq_rdy(dq_rdy),.dd(dd),.dd_cr(dd_cr),
      .lease_grant(1'b1),.lease_busy(leasebusy),.wl_credit(producer_credit[7:0]),.wl_done(producer_done[7:0]),.issue_v(producer_issue),.vm_packet(producer_packet),.vm_bad(vm_bad));
    ot_hgi_dma_vm_transport tr(.source_clk(cclk),.vm_clk(vmclk),.rst_n(rst_n),.lease_grant(4'hf),.producer_busy({3'd0,leasebusy}),
      .issue_v({24'd0,producer_issue}),.source_packet({{24*281{1'b0}},producer_packet}),.source_credit(producer_credit),.source_done(producer_done),.queue_fault(qfault),.drained(drained),.lease_fault(lfault),
      .dma_q(native_dq),.dma_done(native_done),.router_fault(rfault));
    // ---- memories
    // HBM byte at address a: a full 64-bit mix (every address bit reaches every data bit; hgi-1010/c: the old hash
    // (a * K + (a >> 7) * K2) >> 3 ignored address bits >= 11, so a high-address error went unseen)
    function automatic [7:0] hb(input longint a);
        longint x;
        begin x = a ^ (a >> 31); x = x * 64'h9E3779B97F4A7C15; x = x ^ (x >> 29); x = x * 64'hBF58476D1CE4E5B9; hb = 8'(x >> 40); end
    endfunction
    reg [31:0] vm [0:VMW-1];
    // Actual native B2/SECDED vehicle pinned to 64fced1f9. No behavioral VM writer.
    wire [32*16-1:0] su_rq;wire [32*257-1:0] su_rr;
    wire [32*280-1:0] su_wq;wire [31:0] su_rc,su_wc,su_done,vehicle_fault;
    wire [32*18-1:0] bank_status;
    wire [159:0] parent_fault;wire [3:0] su_rg,su_wg,su_ra,su_wa,quant_drained;
    wire [31:0] su_cd,su_vd,dma_cd,dma_vd;wire [11:0] owner_r,owner_w;
    wire [3:0] su_read_req=stgo|~stdn,su_write_req=(drgo|~drdn)&{4{!park_admission}};
    wire [95:0] cdc_source_clocks;
    for(genvar cq=0;cq<4;cq++)for(genvar cb=0;cb<8;cb++)begin:cdc_domains
      assign cdc_source_clocks[cq*8+cb]=cclk[cq];
      assign cdc_source_clocks[32+cq*8+cb]=cclk[cq];
      assign cdc_source_clocks[64+cq*8+cb]=clk;
    end
    wire [32*280-1:0] admitted_su_wq;
    for(genvar aq=0;aq<4;aq++)for(genvar ab=0;ab<8;ab++)begin:admission_mutant
      assign admitted_su_wq[(aq*8+ab)*280+:280]={su_wq[(aq*8+ab)*280+279]&&((MUT!=11)||su_wg[aq]),su_wq[(aq*8+ab)*280+:279]};
    end
    ot_hbm_b2_native_owned4 #(.MUT(MUT==10?1:MUT==13?3:0),.FASTFIN(1),.FRONTFAST(1),.HARD_CLOCKS(1),.HARD_VM_CLOCKS(1),.HARD_CDC_CLOCKS(1),.HARD_COMMIT_CLOCKS(1),.VM_NC(4)) vehicle(
      .su_clk(cclk),.quant_clk(cclk),.dma_clk({4{clk}}),.vclk(vmclk),.rst_n(rst_n),.station_clk({32{vmclk}}),.commit_clk({32{vmclk}}),.commit_rst_n({32{rst_n}}),
      .cdc_cclk(cdc_source_clocks),.cdc_vclk({96{vmclk}}),.cdc_crst_n({96{rst_n}}),.cdc_vrst_n({96{rst_n}}),
      .vm_child_clk({52{vmclk}}),.vm_child_rst_n({52{rst_n}}),.relay_clk({24{vmclk}}),.relay_rst_n({24{rst_n}}),
      .su_native_rq(544'b0),.su_native_wq(8992'b0),.su_rreq(su_read_req),.su_wreq(su_write_req),.su_drained(stdn&drdn&~stgo&~drgo),.su_mirror(su_mirror),
      .su_rq(su_rq),.su_rcredit(su_rc),.su_rr(su_rr),.su_wq(admitted_su_wq),.su_wcredit(su_wc),.su_done(su_done),
      .su_rgrant(su_rg),.su_wgrant(su_wg),.su_rack(su_ra),.su_wack(su_wa),
      .quant_rec(quant_rec),.quant_mirror(4'b0),.quant_ret(quant_ret),.quant_drained(quant_drained),
      .dma_rreq(dma_bridge_req),.dma_wreq(4'b0),.dma_peer_drained(dma_bridge_drained),.dma_rq(dma_bridge_rq),.dma_rcredit(dma_bridge_credit),.dma_rr(dma_bridge_rr),
      .dma_wq(8992'b0),.dma_wcredit(),.dma_wdone(),.dma_rgrant(dma_bridge_grant),.dma_wgrant(),.dma_rack(dma_bridge_ack),.dma_wack(),
      .dma_dq(native_dq),.dma_dq_done(native_done),.probe_clk(cclk),.probe_permit(4'hf),.probe_mirror(4'b0),
      .probe_rq(512'b0),.probe_rcredit(),.probe_rr(),.probe_wq(8960'b0),.probe_wcredit(),.probe_done(),
      .su_cdrained(su_cd),.su_vdrained(su_vd),.dma_cdrained(dma_cd),.dma_vdrained(dma_vd),
      .vm_rgrant(owner_r),.vm_wgrant(owner_w),.bank_status(bank_status),.fault(parent_fault));
    assign vehicle_fault=parent_fault[31:0];
    reg quant_go=0,quant_seed=0,quant_check=0,dma_core_go=0;
    wire [4*683-1:0] quant_rec;wire [11:0] quant_ret;
    wire quant_done;wire [31:0] quant_cycles,quant_checked;
    ot_native_quant_stimulus quant(.clk(clk),.rst_n(rst_n),.go(quant_go),.rec(quant_rec),.ret(quant_ret),.done(quant_done),.cycles(quant_cycles),.checked(quant_checked));
    wire [512:0] dma_legacy_q;wire [8256:0] dma_legacy_r;
    wire [3:0] dma_bridge_req,dma_bridge_drained,dma_bridge_released,dma_bridge_grant,dma_bridge_ack;
    wire [543:0] dma_bridge_rq;wire [31:0] dma_bridge_credit;wire [8223:0] dma_bridge_rr;wire [64:0] dma_bridge_fault;
    wire dma_core_done;wire [31:0] dma_core_checked,dma_core_requests,dma_core_peak;
    ot_hgi_dma_native_read_owned #(.HARD_CLOCKS(1),.MUT(MUT==20?1:MUT==22?2:MUT==23?3:0)) dma_bridge(
      .clk(clk),.rst_n(rst_n),.leaf_clk({64{clk}}),.legacy_q(dma_legacy_q),.legacy_r(dma_legacy_r),
      .rgrant(dma_bridge_grant),.rack(dma_bridge_ack),.rreq(dma_bridge_req),.drained(dma_bridge_drained),.released(dma_bridge_released),
      .native_rq(dma_bridge_rq),.native_credit(dma_bridge_credit),.native_rr(dma_bridge_rr),.fault(dma_bridge_fault));
    ot_native_dma_core_stimulus #(.MUT(MUT)) dma_core(.clk(clk),.rst_n(rst_n),.go(dma_core_go),.bridge_released(dma_bridge_released),
      .legacy_q(dma_legacy_q),.legacy_r(dma_legacy_r),.done(dma_core_done),.checked_words(dma_core_checked),.request_count(dma_core_requests),.peak_pending(dma_core_peak));
    reg [3:0] su_mirror=0,su_mask=4'hf;reg mirror_wave=0,park_admission=0;
    reg [3:0] stgo=0,drgo=0;wire [3:0] stdn,drdn,su_ov;
    reg [23:0] su_lo=0,su_hi=65535;
    reg [3:0] st_seen=0,dr_seen=0;integer read_mode=0;
    integer read_count[0:3];integer contention=0;integer scratch_checks=0;
    function automatic [255:0] seed(input integer q,input integer sec);
      for(integer w=0;w<8;w++)seed[w*32+:32]=32'hA5A5_0000+(q<<16)+sec*8+w;
    endfunction
    for(genvar q=0;q<4;q++)begin:su
      wire [7:0] sv,drv;wire [103:0] ss,ds;wire [2047:0] sd;
      reg [7:0] drvalid=0;reg [2047:0] drdata=0;reg [63:0] drm=0;
      ot_hgi_su_ctlw_native_h #(.LWB(16),.LQ(10),.LQSRAM(1)) ctl(
        .clk(cclk[q]),.clk_p0(cclk[q]),.clk_p1(cclk[q]),.clk_p2(cclk[q]),.clk_p3(cclk[q]),.rst_n(rst_n),
        .wst_go_i(stgo[q]),.wdr_go_i(drgo[q]),.lo_i({120'b0,su_lo}),.hi_i({120'b0,su_hi}),.lb_i(102'b0),.rv_i(6'b1),.dsec_i(126'b0),
        .d_lo_i({24'b0,su_lo}),.d_hi_i({24'b0,su_hi}),.d_lb_i({17'b0,17'(su_lo)}),.d_rv_i(2'b01),.d_dsec_i(42'b0),.d_os_i(1'b0),.sl_i(2'(q)),
        .wst_go_o(),.wdr_go_o(),.d_os_o(),.lo_o(),.hi_o(),.lb_o(),.rv_o(),.dsec_o(),.d_lo_o(),.d_hi_o(),.d_lb_o(),.d_rv_o(),.d_dsec_o(),
        .wst_dn_i(1'b1),.wdr_dn_i(1'b1),.ovf_i(1'b0),
        .wrq(su_rq[q*128+:128]),.wrq_cr(su_rc[q*8+:8]),.wrr(su_rr[q*2056+:2056]),
        .wwq(su_wq[q*2240+:2240]),.wwq_cr(su_wc[q*8+:8]),.wwq_done(su_done[q*8+:8]),
        .lsw_v(sv),.lsw_sec(ss),.lsw_d(sd),.ldc_v(),.ldc_sec(),.ldr_v(drv),.ldr_sec(ds),
        .ldr_d(drdata),.ldr_dm(drm),.ldr_rv(drvalid),.wst_dn(stdn[q]),.wdr_dn(drdn[q]),.ovf(su_ov[q]));
      initial read_count[q]=0;
      always @(posedge cclk[q])if(rst_n)begin
        if(stgo[q])st_seen[q]<=0;else if(!stdn[q])st_seen[q]<=1;
        if(drgo[q])dr_seen[q]<=0;else if(!drdn[q])dr_seen[q]<=1;
        drvalid<=drv;
        for(integer b=0;b<8;b++)begin
          drdata[b*256+:256]<=quant_seed?quant.preload_sector(int'(ds[b*13+:13]),seed(q,int'(ds[b*13+:13]))):seed(q,int'(ds[b*13+:13]));drm[b*8+:8]<=8'hff;
          if(sv[b])begin
            integer sec;sec=int'(ss[b*13+:13]);
            if(sec%8!=b)$fatal(1,"FATAL actual SU bank/sector q%0d b%0d sec%0d",q,b,sec);
            read_count[q]=read_count[q]+1;
            if(read_mode==1)begin
              if(sd[b*256+:256]!==seed(q,sec))$fatal(1,"FATAL actual contention SU read q%0d sec%0d",q,sec);
              scratch_checks=scratch_checks+1;
            end else if(read_mode==3)begin
              if(sd[b*256+:256]!==seed(0,sec))$fatal(1,"THREEPRODUCER global mirror mismatch q%0d sec%0d",q,sec);
              mirror_checked++;
            end else if(read_mode==2)
              begin
                for(integer w=0;w<8;w++)vm[(q<<16)+sec*8+w]=sd[b*256+w*32+:32];
                if(quant_check)quant.check_sector(q,sec,sd[b*256+:256]);
              end
          end
        end
      end
      for(genvar b=0;b<8;b++)begin:observe
        always @(posedge vmclk)if(rst_n && vehicle.vm.quad[q].vm.g_bank[b].u_bank.dma_v && vehicle.vm.quad[q].vm.g_bank[b].u_bank.wqn[1]!=0)contention=contention+1;
      end
    end
    always @(posedge vmclk)if(rst_n)begin
      if(qfault||rfault||lfault||parent_fault||dma_bridge_fault||bank_status||su_ov)
        $fatal(1,"FATAL actual native hardware queue%h router%h lease%h parent%h DMAbridge%h status%h su%h",qfault,rfault,lfault,parent_fault,dma_bridge_fault,bank_status,su_ov);
    end
    integer mirror_checked=0,mirror_posts=0,mirror_commits=0,mirror_macro_writes=0;
    integer dma_read_owner_edges=0,read_handoffs=0;reg [11:0] seen_read_owners=0,previous_rowner=0;
    integer parked_su_posts=0,owner_handoffs=0,su_owner_edges=0,quant_owner_edges=0,su_write_posts=0,su_write_commits=0,su_read_posts=0,su_read_replies=0;
    reg [11:0] previous_wowner=0;
    always @(posedge clk)if(rst_n)for(integer q=0;q<4;q++)for(integer b=0;b<8;b++)
      begin
        if(su_wq[(q*8+b)*280+279])begin if(su_mirror[q])mirror_posts++;su_write_posts++;if(!su_wg[q])parked_su_posts++;end
        if(su_done[q*8+b])su_write_commits++;
        if(su_rq[(q*8+b)*16+15])su_read_posts++;
        if(su_rr[(q*8+b)*257+256])su_read_replies++;
      end
    always @(posedge vmclk)if(rst_n)begin
      if(mirror_wave)begin
        for(integer b=0;b<32;b++)if(vehicle.bd[b])begin
          if(|vehicle.mirror_busy)$fatal(1,"THREEPRODUCER premature actual global mirror commit bank%0d",b);
          mirror_commits++;
        end
      end
      for(integer q=0;q<4;q++)begin
        if(owner_r[q*3+:3]!=0 && !$onehot(owner_r[q*3+:3]))$fatal(1,"THREEPRODUCER multiple read owners q%0d",q);
        if(owner_w[q*3+:3]!=0 && !$onehot(owner_w[q*3+:3]))$fatal(1,"THREEPRODUCER multiple write owners q%0d",q);
        if(owner_w[q*3])su_owner_edges++;
        if(owner_w[q*3+1])quant_owner_edges++;
        if(owner_r[q*3+2])dma_read_owner_edges++;
        seen_read_owners[q*3+:3]=seen_read_owners[q*3+:3]|owner_r[q*3+:3];
        if(owner_r[q*3+:3]!=0)begin
          if(previous_rowner[q*3+:3]!=0&&previous_rowner[q*3+:3]!=owner_r[q*3+:3])read_handoffs++;
          previous_rowner[q*3+:3]=owner_r[q*3+:3];
        end
        if(owner_w[q*3+2])$fatal(1,"THREEOWNER read-only DMA peer gained write owner");
        if(owner_w[q*3+:3]!=0)begin
          if(previous_wowner[q*3+:3]!=0&&previous_wowner[q*3+:3]!=owner_w[q*3+:3])owner_handoffs++;
          previous_wowner[q*3+:3]=owner_w[q*3+:3];
        end
      end
    end
    for(genvar mq=0;mq<4;mq++)begin:mirror_trace
      for(genvar mb=6;mb<8;mb++)begin:bank
        always @(posedge vmclk)if(rst_n&&mirror_wave&&vehicle.vm.quad[mq].vm.g_bank[mb].u_bank.m_wC)begin
          $display("THREEPRODUCER_MIRROR_MACRO time%0t q%0d bank%0d row%0d mask%h data%h globalbusy%h",$time,mq,mb,vehicle.vm.quad[mq].vm.g_bank[mb].u_bank.m_wa,vehicle.vm.quad[mq].vm.g_bank[mb].u_bank.m_mC,vehicle.vm.quad[mq].vm.g_bank[mb].u_bank.wdat,vehicle.mirror_busy);$fflush();
          if(vehicle.vm.quad[mq].vm.g_bank[mb].u_bank.m_wa!=511||vehicle.vm.quad[mq].vm.g_bank[mb].u_bank.m_mC!=8'hff||vehicle.vm.quad[mq].vm.g_bank[mb].u_bank.wdat!==seed(0,4088+mb))$fatal(1,"THREEPRODUCER mirror actual macro pin mismatch q%0d bank%0d",mq,mb);
          mirror_macro_writes++;
        end
      end
      always @(posedge vmclk)if(rst_n&&mirror_wave&&(vehicle.vm.quad[mq].vm.ack01||vehicle.vm.quad[mq].vm.ack10))begin
        $display("THREEPRODUCER_MIRROR_ACK time%0t q%0d CWack%b CCWack%b globalbusy%h",$time,mq,vehicle.vm.quad[mq].vm.ack01,vehicle.vm.quad[mq].vm.ack10,vehicle.mirror_busy);$fflush();
      end
    end
    task automatic su_run(input integer mode,input integer first,input integer last,input bit wr,input bit rd);
      integer start;
      begin
        $display("THREEPRODUCER_SU_START load%0d mode%0d range%0d:%0d cycle%0d",load_count,mode,first,last,cyc);$fflush();
        su_lo=24'(first);su_hi=24'(last);read_mode=mode;
        for(integer q=0;q<4;q++)read_count[q]=0;
        if(load_count==0&&mode==0&&!quant_go)park_admission=1;
        @(negedge clk);stgo=rd?su_mask:0;drgo=wr?su_mask:0;
        repeat(2)@(negedge clk);stgo=0;drgo=0;start=cyc;
        if(park_admission)begin
          while(su_write_posts==0)begin @(negedge clk);if(cyc-start>1000)$fatal(1,"THREEPRODUCER actual SU never posted into reserved admission");end
          if(MUT==14)begin
            repeat(2)@(negedge clk);su_mirror=4'hf;
            $display("THREEOWNER_BAD_APERTURE offered_new_mirror%h held_metadata%h pending_SU_writes%0d before_returned_ACK",su_mirror,vehicle.smeta,su_write_posts-su_write_commits);$fflush();
            repeat(4)@(negedge clk);
          end else repeat(6)@(negedge clk);
          park_admission=0;
          $display("THREEPRODUCER_PARKED_POSTS observed%0d before_grant retained_positive_requires_fullcommit",parked_su_posts);
        end
        while((wr && ((dr_seen&su_mask)!=su_mask||(drdn&su_mask)!=su_mask)) || (rd && ((st_seen&su_mask)!=su_mask||(stdn&su_mask)!=su_mask||read_count[0]!=(last-first+1)/8||read_count[1]!=(last-first+1)/8||read_count[2]!=(last-first+1)/8||read_count[3]!=(last-first+1)/8)))begin
          @(negedge clk);if(cyc-start>su_limit)$fatal(1,"FATAL actual SU timeout mode%0d seen%h/%h done%h/%h count%0d/%0d/%0d/%0d",mode,st_seen,dr_seen,stdn,drdn,read_count[0],read_count[1],read_count[2],read_count[3]);
        end
        $display("THREEPRODUCER_SU_DONE load%0d mode%0d cycle%0d",load_count,mode,cyc);$fflush();
      end
    endtask
    // ---- svc model: per stack a request queue; per lane a beat queue in idx order; credit 4 a lane
    integer rq_n [0:NS-1]; reg [49:0] rq [0:NS-1][0:63]; integer rq_h [0:NS-1];
    integer cr [0:NIN-1]; integer nxt [0:NS-1];               // next idx of the head request to schedule
    reg [269:0] lb [0:NIN-1][0:1023]; integer lh [0:NIN-1]; integer lt [0:NIN-1];
    // die-wire stages: data and credits each cross HOPS registers
    reg [NIN*270-1:0] dpipe [0:7]; reg [NIN-1:0] cpipe [0:7]; wire [NIN-1:0] cr_in;
    always @(posedge clk) begin dpipe[0] <= dd_m; cpipe[0] <= dd_cr; for (integer h = 1; h < 8; h = h + 1) begin dpipe[h] <= dpipe[h-1]; cpipe[h] <= cpipe[h-1]; end end
    assign dd = (HOPS == 0) ? dd_m : dpipe[HOPS-1];
    assign cr_in = (HOPS == 0) ? dd_cr : cpipe[HOPS-1];
    initial for (integer i = 0; i < NIN; i = i + 1) begin cr[i] = LD; lh[i] = 0; lt[i] = 0; end
    initial for (integer p = 0; p < NB; p = p + 1) rlow[p] = 0;
    integer tok [0:NS-1]; longint sched = 0;
    initial for (integer s = 0; s < NS; s = s + 1) begin tok[s] = 0; rq_n[s] = 0; rq_h[s] = 0; nxt[s] = 0; end
    always @(posedge clk) if (rst_n) begin
        dd_m <= 0;
        for (integer s = 0; s < NS; s = s + 1) begin
            dq_rdy[s] <= full || ($urandom % 4) != 0;
            if (dq[s*51 + 50] && dq_rdy[s]) begin rq[s][(rq_h[s] + rq_n[s]) % 64] = dq[s*51 +: 50]; rq_n[s] = rq_n[s] + 1; end
            // schedule up to 8 sectors of the head request into the lane queues (the svc reading its PCs)
            if (PCX4 != 0) tok[s] = (tok[s] + PCX4 > 4 * PCX4) ? 4 * PCX4 : tok[s] + PCX4;   // token bucket, 4 x sectors
            for (integer k = 0; k < NL && rq_n[s] > 0 && (PCX4 == 0 || tok[s] >= 4) && lt[s * NL + (nxt[s] % NL)] - lh[s * NL + (nxt[s] % NL)] < 512; k = k + 1) begin : sch
                reg [49:0] r; reg [255:0] sd; longint a; integer l;
                r = rq[s][rq_h[s] % 64];
                a = longint'(r[36:0]) + 32 * nxt[s];
                for (integer b = 0; b < 32; b = b + 1) sd[8*b +: 8] = hb(a + b);
                l = s * NL + (nxt[s] % NL); if (PCX4 != 0) tok[s] = tok[s] - 4; sched = sched + 1;
                lb[l][lt[l] % 1024] = {1'b1, 1'b0, r[49:46], 8'(nxt[s]), sd}; lt[l] = lt[l] + 1;
                nxt[s] = nxt[s] + 1;
                if (nxt[s] == int'(r[45:37])) begin nxt[s] = 0; rq_h[s] = rq_h[s] + 1; rq_n[s] = rq_n[s] - 1; end
            end
        end
        for (integer i = 0; i < NIN; i = i + 1) begin
            if (cr_in[i]) cr[i] = cr[i] + 1;
            if (lt[i] > lh[i] && cr[i] > 0 && (full || ($urandom % 5) != 0)) begin dd_m[i*270 +: 270] <= lb[i][lh[i] % 1024]; lh[i] = lh[i] + 1; cr[i] = cr[i] - 1; end
        end
    end
    // ---- reference decode
    // binary32 bits of an exactly representable normal / zero double (Verilator's $shortrealtobits is not reliable)
    function automatic [31:0] f32(input real v);
        reg [63:0] d;
        begin
            d = $realtobits(v);
            f32 = (d[62:0] == 63'd0) ? {d[63], 31'd0} : {d[63], 8'(d[62:52] - 11'd1023 + 11'd127), d[51:29]};
        end
    endfunction
    function automatic [31:0] e4(input [7:0] c);
        real v; integer e, m; reg [31:0] r;
        begin
            e = c[6:3]; m = c[2:0];
            if (e == 15 && m == 7) e4 = 32'h7FC00000;
            else begin
                v = (e == 0) ? (m / 8.0) * (2.0 ** -6) : (1.0 + m / 8.0) * (2.0 ** (e - 7));
                r = f32(v); r[31] = c[7];
                if (v == 0.0) r = {c[7], 31'd0};
                e4 = r;
            end
        end
    endfunction
    function automatic [31:0] i8(input [7:0] c); i8 = f32(real'($signed(c))); if (c == 0) i8 = 0; endfunction
    integer full = 0; initial full = $test$plusargs("FULL");     // +FULL: the svc model at its full rate (no gaps)
    integer errs = 0, cyc = 0, tbytes = 0, tcyc = 0;
    always @(posedge clk) cyc <= cyc + 1;
    task automatic load(input [2:0] f, input longint sbase, input longint sstr, input integer dbase, input integer dstr,
                        input integer m, input integer n);
        integer es, t0, o, i, e0, dma_cycles;bit dma_ok; longint a; reg [31:0] want;
        begin
            es = (f == 0 || f == 5) ? 4 : (f == 1) ? 2 : 1; e0 = errs;
            if(load_count==0)begin quant_seed=1;wait(quant.loaded);end
            su_run(0,0,65535,1,0);
            if(load_count==0)begin quant_go=1;quant_check=1;dma_core_go=1;end
            mv = 0; mv[1:0] = 0; mv[4:2] = f; mv[44:5] = 40'(sbase); mv[76:45] = 32'(sstr); mv[92:77] = 1;
            mv[94:93] = 1; mv[97:95] = 0; mv[137:98] = 40'(dbase); mv[169:138] = 32'(dstr); mv[185:170] = 1;
            mv[205:186] = 20'(m); mv[226:206] = 21'(n);
            @(negedge clk); mv_v = 1; t0 = cyc; while (!mv_rdy) begin @(negedge clk); if (cyc - t0 > 50000) $fatal(1, "FATAL front never ready (previous load stuck)"); end @(negedge clk); mv_v = 0; t0 = cyc;
            fork
              begin
                while(!(|dma_valid))@(negedge clk);
                su_run(1,65472,65535,1,1);
              end
              begin
                while (!mv_done && !mv_fault && cyc - t0 < 50000) @(negedge clk);
                dma_cycles=cyc-t0;dma_ok=mv_done;
              end
            join
            if(load_count==0)wait(quant_done&&dma_core_done);
            if (!dma_ok) begin $display("FAIL load f %0d m %0d n %0d: done %0d fault %0d", f, m, n, mv_done, mv_fault); errs = errs + 1; end
            else begin
                tcyc = tcyc + dma_cycles;
                su_run(2,0,65535,0,1); tbytes = tbytes + m * n * 4;
                for (o = 0; o < m; o = o + 1) for (i = 0; i < n; i = i + 1) begin
                    a = sbase + o * sstr + i * es;
                    case (f)
                        1: want = {hb(a + 1), hb(a), 16'd0};
                        2: want = e4(hb(a));
                        4: want = i8(hb(a));
                        default: want = {hb(a + 3), hb(a + 2), hb(a + 1), hb(a)};
                    endcase
                    if (vm[dbase + o * dstr + i] !== want) begin
                        if (errs < 8) $display("FAIL f %0d row %0d elem %0d: vm %h want %h", f, o, i, vm[dbase + o * dstr + i], want);
                        errs = errs + 1;
                    end
                end
                begin : untouched
                    integer w, o2, hit, bad; bad = 0;
                    for (w = 0; w < VMW; w = w + 1) begin
                        hit = 0;
                        for (o2 = 0; o2 < m; o2 = o2 + 1) if (w >= dbase + o2 * dstr && w < dbase + o2 * dstr + n) hit = 1;
                        if (!hit && vm[w] !== (load_count==0?quant.expected_word(w%65536,32'hA5A5_0000+w):32'hA5A5_0000+w)) bad = bad + 1;
                    end
                    if (bad != 0) begin $display("FAIL f %0d: %0d words outside the destination changed", f, bad); errs = errs + 1; end
                end
                if (errs != e0) $display("  load f %0d: %0d errors", f, errs - e0);
                $display("LOAD f %0d m %0d n %0d: %0d cycles, %0.1f destination B / cycle, %0.1f source B / cycle = %0.1f %% of 3.80 TB/s at 1.2 GHz (3,166.7 B / cycle)",
                         f, m, n, dma_cycles, (m * n * 4.0) / dma_cycles, (m * n * es * 1.0) / dma_cycles, 100.0 * (m * n * es * 1.0) / dma_cycles / 3166.7);
            end
            if(load_count==0)begin
              if(quant_checked!=13312)$fatal(1,"THREEPRODUCER quant golden count %0d expected13312",quant_checked);
              $display("THREEPRODUCER_QUANT_EXACT PASS records32 words13312 cycles%0d immutable_price168",quant_cycles);
              quant_seed=0;quant_check=0;
            end
            load_count++;
        end
    endtask
    task finish_contract;
      begin
        if(quant_cycles*10>168*11)$display("THREEPRODUCER_QUANT_PRICE_FAIL cycles%0d immutable168 ratio%0.9f limit1.10",quant_cycles,quant_cycles/168.0);
        else $display("THREEPRODUCER_QUANT_PRICE_PASS cycles%0d immutable168",quant_cycles);
        for(integer meta_wait=0;su_ra!=4'hf||su_wa!=4'hf||su_cd!=32'hffffffff||su_vd!=32'hffffffff||owner_r!=0||owner_w!=0||quant_drained!=4'hf||dma_bridge_released!=4'hf;meta_wait++)begin
          @(negedge clk);if(meta_wait>4000)$fatal(1,"THREEOWNER source metadata flip before actual drain ACKs");
        end
        // One real SU_h source posts mirrored beats; all four actual VM copies
        // are checked through the real SU_h read path after global commit.
        quant_seed=0;su_mask=4'b0001;su_mirror=4'b0001;mirror_wave=1;
        su_run(0,32752,32767,1,0);
        for(integer meta_wait=0;su_ra!=4'hf||su_wa!=4'hf||su_cd!=32'hffffffff||su_vd!=32'hffffffff||owner_r!=0||owner_w!=0;meta_wait++)begin
          @(negedge clk);if(meta_wait>4000)$fatal(1,"THREEOWNER mirrored lease did not ACK before aperture change");
        end
        mirror_wave=0;su_mirror=4'hf;su_mask=4'hf;
        su_run(3,32752,32767,0,1);
        for(integer meta_wait=0;su_ra!=4'hf||su_wa!=4'hf||su_cd!=32'hffffffff||su_vd!=32'hffffffff||owner_r!=0||owner_w!=0;meta_wait++)begin
          @(negedge clk);if(meta_wait>4000)$fatal(1,"THREEOWNER mirrored reads did not ACK before aperture change");
        end
        su_mirror=0;
        if(mirror_posts!=2||mirror_commits!=2||mirror_checked!=8||mirror_macro_writes!=8)$fatal(1,"THREEPRODUCER mirror count posts%0d commits%0d checked%0d macros%0d",mirror_posts,mirror_commits,mirror_checked,mirror_macro_writes);
        $display("THREEPRODUCER_GLOBAL_MIRROR PASS actual_source_posts2 global_commits2 destination_sectors8 words64");
        for(integer waitdrain=0;su_cd!=32'hffffffff||su_vd!=32'hffffffff||quant_drained!=4'hf||drained!=4'hf||owner_r!=0||owner_w!=0;waitdrain++)begin
          @(negedge clk);if(waitdrain>4000)$fatal(1,"THREEPRODUCER drain timeout SU%h/%h quant%h DMA%h owner%h/%h",su_cd,su_vd,quant_drained,drained,owner_r,owner_w);
        end
        if(parked_su_posts==0||owner_handoffs==0||quant_owner_edges==0||su_owner_edges==0)$fatal(1,"THREEPRODUCER missing posted/grant/handoff evidence parked%0d handoff%0d SU%0d quant%0d",parked_su_posts,owner_handoffs,su_owner_edges,quant_owner_edges);
        if(su_write_posts!=su_write_commits||su_read_posts!=su_read_replies)$fatal(1,"THREEPRODUCER lost actual post W%0d/%0d R%0d/%0d",su_write_posts,su_write_commits,su_read_posts,su_read_replies);
        if(seen_read_owners!=12'hfff||dma_read_owner_edges==0||read_handoffs<8||dma_core_checked!=1024||dma_core_requests!=128)$fatal(1,"THREEOWNER actual sources missing owner%h DMAedges%0d handoffs%0d golden%0d requests%0d",seen_read_owners,dma_read_owner_edges,read_handoffs,dma_core_checked,dma_core_requests);
        $display("THREEOWNER_READ_HANDOFF PASS actual_q10_source39 requests128 goldenwords1024 all4_three_owner_mask%h handoffs%0d DMA_owner_edges%0d source_peak_pending%0d truthful_capacity32",seen_read_owners,read_handoffs,dma_read_owner_edges,dma_core_peak);
        $display("THREEPRODUCER_POST_RETENTION PASS write%0d commit%0d read%0d reply%0d parked%0d",su_write_posts,su_write_commits,su_read_posts,su_read_replies,parked_su_posts);
        $display("THREEPRODUCER_DRAIN PASS parked_SU_posts%0d handoffs%0d SU_owner_edges%0d quant_owner_edges%0d three_group1_R_owners_actual_DMAcore_and_separate_frontDQ",parked_su_posts,owner_handoffs,su_owner_edges,quant_owner_edges);
      end
    endtask
    integer su_limit=100000;
    integer load_count=0;
    initial begin:production
        if($test$plusargs("SMOKE"))su_limit=10000;
        repeat (4) @(negedge clk); rst_n = 1; repeat (4) @(negedge clk);
        load(3'd0, 64'd8594136608, 64'd0, 12544, 0, 1, 128); // dispatch3 disjoint from all quant vectors
        if($test$plusargs("SMOKE"))begin
          finish_contract();
          $display("THREEPRODUCER_SMOKE PASS actualSU actualQDQ32 actualDMA_dispatch3 actualq10_STORE4_FENCE4 quantwords13312 phase%0d production147_not_run",PHASE);
          $finish;disable production;
        end
        load(3'd4, 64'd4294967296, 64'd0, 0, 0, 1, 4096); // dispatch0
        load(3'd1, 64'd17186160640, 64'd0, 156672, 0, 1, 1536); // dispatch7
        load(3'd1, 64'd17190358016, 64'd0, 156672, 0, 1, 4096); // dispatch26
        load(3'd1, 64'd17215532032, 64'd0, 156672, 0, 1, 6144); // dispatch30
        load(3'd1, 64'd17228127232, 64'd0, 156672, 0, 1, 4096); // dispatch35
        load(3'd1, 64'd17234444288, 64'd0, 156672, 0, 1, 1536); // dispatch39
        load(3'd1, 64'd17238641664, 64'd0, 156672, 0, 1, 4096); // dispatch58
        load(3'd1, 64'd17263815680, 64'd0, 156672, 0, 1, 6144); // dispatch62
        load(3'd1, 64'd17276410880, 64'd0, 156672, 0, 1, 4096); // dispatch67
        load(3'd1, 64'd17282727936, 64'd0, 156672, 0, 1, 1536); // dispatch71
        load(3'd1, 64'd17286925312, 64'd0, 156672, 0, 1, 4096); // dispatch90
        load(3'd1, 64'd17312099328, 64'd0, 156672, 0, 1, 6144); // dispatch94
        load(3'd1, 64'd17324694528, 64'd0, 156672, 0, 1, 4096); // dispatch99
        load(3'd1, 64'd17331011584, 64'd0, 156672, 0, 1, 1536); // dispatch103
        load(3'd1, 64'd17335208960, 64'd0, 156672, 0, 1, 4096); // dispatch122
        load(3'd1, 64'd17360382976, 64'd0, 156672, 0, 1, 6144); // dispatch126
        load(3'd1, 64'd17372978176, 64'd0, 156672, 0, 1, 4096); // dispatch131
        load(3'd1, 64'd17379295232, 64'd0, 156672, 0, 1, 1536); // dispatch135
        load(3'd1, 64'd17383492608, 64'd0, 156672, 0, 1, 4096); // dispatch154
        load(3'd1, 64'd17408666624, 64'd0, 156672, 0, 1, 6144); // dispatch158
        load(3'd1, 64'd17421261824, 64'd0, 156672, 0, 1, 4096); // dispatch163
        load(3'd1, 64'd17427578880, 64'd0, 156672, 0, 1, 1536); // dispatch167
        load(3'd1, 64'd17431776256, 64'd0, 156672, 0, 1, 4096); // dispatch186
        load(3'd1, 64'd17456950272, 64'd0, 156672, 0, 1, 6144); // dispatch190
        load(3'd1, 64'd17469545472, 64'd0, 156672, 0, 1, 4096); // dispatch195
        load(3'd1, 64'd17475862528, 64'd0, 156672, 0, 1, 1536); // dispatch199
        load(3'd1, 64'd17480059904, 64'd0, 156672, 0, 1, 4096); // dispatch218
        load(3'd1, 64'd17505233920, 64'd0, 156672, 0, 1, 6144); // dispatch222
        load(3'd1, 64'd17517829120, 64'd0, 156672, 0, 1, 4096); // dispatch227
        load(3'd1, 64'd17524146176, 64'd0, 156672, 0, 1, 1536); // dispatch231
        load(3'd1, 64'd17528343552, 64'd0, 156672, 0, 1, 4096); // dispatch250
        load(3'd1, 64'd17553517568, 64'd0, 156672, 0, 1, 6144); // dispatch254
        load(3'd1, 64'd17566112768, 64'd0, 156672, 0, 1, 4096); // dispatch259
        load(3'd1, 64'd17572429824, 64'd0, 156672, 0, 1, 1536); // dispatch263
        load(3'd1, 64'd17576627200, 64'd0, 156672, 0, 1, 4096); // dispatch282
        load(3'd1, 64'd17601801216, 64'd0, 156672, 0, 1, 6144); // dispatch286
        load(3'd1, 64'd17614396416, 64'd0, 156672, 0, 1, 4096); // dispatch291
        load(3'd1, 64'd17620713472, 64'd0, 156672, 0, 1, 1536); // dispatch295
        load(3'd1, 64'd17624910848, 64'd0, 156672, 0, 1, 4096); // dispatch314
        load(3'd1, 64'd17650084864, 64'd0, 156672, 0, 1, 6144); // dispatch318
        load(3'd1, 64'd17662680064, 64'd0, 156672, 0, 1, 4096); // dispatch323
        load(3'd1, 64'd17668997120, 64'd0, 156672, 0, 1, 1536); // dispatch327
        load(3'd1, 64'd17673194496, 64'd0, 156672, 0, 1, 4096); // dispatch346
        load(3'd1, 64'd17698368512, 64'd0, 156672, 0, 1, 6144); // dispatch350
        load(3'd1, 64'd17710963712, 64'd0, 156672, 0, 1, 4096); // dispatch355
        load(3'd1, 64'd17717280768, 64'd0, 156672, 0, 1, 1536); // dispatch359
        load(3'd1, 64'd17721478144, 64'd0, 156672, 0, 1, 4096); // dispatch378
        load(3'd1, 64'd17746652160, 64'd0, 156672, 0, 1, 6144); // dispatch382
        load(3'd1, 64'd17759247360, 64'd0, 156672, 0, 1, 4096); // dispatch387
        load(3'd1, 64'd17765564416, 64'd0, 156672, 0, 1, 1536); // dispatch391
        load(3'd1, 64'd17769761792, 64'd0, 156672, 0, 1, 4096); // dispatch410
        load(3'd1, 64'd17794935808, 64'd0, 156672, 0, 1, 6144); // dispatch414
        load(3'd1, 64'd17807531008, 64'd0, 156672, 0, 1, 4096); // dispatch419
        load(3'd1, 64'd17813848064, 64'd0, 156672, 0, 1, 1536); // dispatch423
        load(3'd1, 64'd17818045440, 64'd0, 156672, 0, 1, 4096); // dispatch442
        load(3'd1, 64'd17843219456, 64'd0, 156672, 0, 1, 6144); // dispatch446
        load(3'd1, 64'd17855814656, 64'd0, 156672, 0, 1, 4096); // dispatch451
        load(3'd1, 64'd17862131712, 64'd0, 156672, 0, 1, 1536); // dispatch455
        load(3'd1, 64'd17866329088, 64'd0, 156672, 0, 1, 4096); // dispatch474
        load(3'd1, 64'd17891503104, 64'd0, 156672, 0, 1, 6144); // dispatch478
        load(3'd1, 64'd17904098304, 64'd0, 156672, 0, 1, 4096); // dispatch483
        load(3'd1, 64'd17910415360, 64'd0, 156672, 0, 1, 1536); // dispatch487
        load(3'd1, 64'd17914612736, 64'd0, 156672, 0, 1, 4096); // dispatch506
        load(3'd1, 64'd17939786752, 64'd0, 156672, 0, 1, 6144); // dispatch510
        load(3'd1, 64'd17952381952, 64'd0, 156672, 0, 1, 4096); // dispatch515
        load(3'd1, 64'd17958699008, 64'd0, 156672, 0, 1, 1536); // dispatch519
        load(3'd1, 64'd17962896384, 64'd0, 156672, 0, 1, 4096); // dispatch538
        load(3'd1, 64'd17988070400, 64'd0, 156672, 0, 1, 6144); // dispatch542
        load(3'd1, 64'd18000665600, 64'd0, 156672, 0, 1, 4096); // dispatch547
        load(3'd1, 64'd18006982656, 64'd0, 156672, 0, 1, 1536); // dispatch551
        load(3'd1, 64'd18011180032, 64'd0, 156672, 0, 1, 4096); // dispatch570
        load(3'd1, 64'd18036354048, 64'd0, 156672, 0, 1, 6144); // dispatch574
        load(3'd1, 64'd18048949248, 64'd0, 156672, 0, 1, 4096); // dispatch579
        load(3'd1, 64'd18055266304, 64'd0, 156672, 0, 1, 1536); // dispatch583
        load(3'd1, 64'd18059463680, 64'd0, 156672, 0, 1, 4096); // dispatch602
        load(3'd1, 64'd18084637696, 64'd0, 156672, 0, 1, 6144); // dispatch606
        load(3'd1, 64'd18097232896, 64'd0, 156672, 0, 1, 4096); // dispatch611
        load(3'd1, 64'd18103549952, 64'd0, 156672, 0, 1, 1536); // dispatch615
        load(3'd1, 64'd18107747328, 64'd0, 156672, 0, 1, 4096); // dispatch634
        load(3'd1, 64'd18132921344, 64'd0, 156672, 0, 1, 6144); // dispatch638
        load(3'd1, 64'd18145516544, 64'd0, 156672, 0, 1, 4096); // dispatch643
        load(3'd1, 64'd18151833600, 64'd0, 156672, 0, 1, 1536); // dispatch647
        load(3'd1, 64'd18156030976, 64'd0, 156672, 0, 1, 4096); // dispatch666
        load(3'd1, 64'd18181204992, 64'd0, 156672, 0, 1, 6144); // dispatch670
        load(3'd1, 64'd18193800192, 64'd0, 156672, 0, 1, 4096); // dispatch675
        load(3'd1, 64'd18200117248, 64'd0, 156672, 0, 1, 1536); // dispatch679
        load(3'd1, 64'd18204314624, 64'd0, 156672, 0, 1, 4096); // dispatch698
        load(3'd1, 64'd18229488640, 64'd0, 156672, 0, 1, 6144); // dispatch702
        load(3'd1, 64'd18242083840, 64'd0, 156672, 0, 1, 4096); // dispatch707
        load(3'd1, 64'd18248400896, 64'd0, 156672, 0, 1, 1536); // dispatch711
        load(3'd1, 64'd18252598272, 64'd0, 156672, 0, 1, 4096); // dispatch730
        load(3'd1, 64'd18277772288, 64'd0, 156672, 0, 1, 6144); // dispatch734
        load(3'd1, 64'd18290367488, 64'd0, 156672, 0, 1, 4096); // dispatch739
        load(3'd1, 64'd18296684544, 64'd0, 156672, 0, 1, 1536); // dispatch743
        load(3'd1, 64'd18300881920, 64'd0, 156672, 0, 1, 4096); // dispatch762
        load(3'd1, 64'd18326055936, 64'd0, 156672, 0, 1, 6144); // dispatch766
        load(3'd1, 64'd18338651136, 64'd0, 156672, 0, 1, 4096); // dispatch771
        load(3'd1, 64'd18344968192, 64'd0, 156672, 0, 1, 1536); // dispatch775
        load(3'd1, 64'd18349165568, 64'd0, 156672, 0, 1, 4096); // dispatch794
        load(3'd1, 64'd18374339584, 64'd0, 156672, 0, 1, 6144); // dispatch798
        load(3'd1, 64'd18386934784, 64'd0, 156672, 0, 1, 4096); // dispatch803
        load(3'd1, 64'd18393251840, 64'd0, 156672, 0, 1, 1536); // dispatch807
        load(3'd1, 64'd18397449216, 64'd0, 156672, 0, 1, 4096); // dispatch826
        load(3'd1, 64'd18422623232, 64'd0, 156672, 0, 1, 6144); // dispatch830
        load(3'd1, 64'd18435218432, 64'd0, 156672, 0, 1, 4096); // dispatch835
        load(3'd1, 64'd18441535488, 64'd0, 156672, 0, 1, 1536); // dispatch839
        load(3'd1, 64'd18445732864, 64'd0, 156672, 0, 1, 4096); // dispatch858
        load(3'd1, 64'd18470906880, 64'd0, 156672, 0, 1, 6144); // dispatch862
        load(3'd1, 64'd18483502080, 64'd0, 156672, 0, 1, 4096); // dispatch867
        load(3'd1, 64'd18489819136, 64'd0, 156672, 0, 1, 1536); // dispatch871
        load(3'd1, 64'd18494016512, 64'd0, 156672, 0, 1, 4096); // dispatch890
        load(3'd1, 64'd18519190528, 64'd0, 156672, 0, 1, 6144); // dispatch894
        load(3'd1, 64'd18531785728, 64'd0, 156672, 0, 1, 4096); // dispatch899
        load(3'd1, 64'd18538102784, 64'd0, 156672, 0, 1, 1536); // dispatch903
        load(3'd1, 64'd18542300160, 64'd0, 156672, 0, 1, 4096); // dispatch922
        load(3'd1, 64'd18567474176, 64'd0, 156672, 0, 1, 6144); // dispatch926
        load(3'd1, 64'd18580069376, 64'd0, 156672, 0, 1, 4096); // dispatch931
        load(3'd1, 64'd18586386432, 64'd0, 156672, 0, 1, 1536); // dispatch935
        load(3'd1, 64'd18590583808, 64'd0, 156672, 0, 1, 4096); // dispatch954
        load(3'd1, 64'd18615757824, 64'd0, 156672, 0, 1, 6144); // dispatch958
        load(3'd1, 64'd18628353024, 64'd0, 156672, 0, 1, 4096); // dispatch963
        load(3'd1, 64'd18634670080, 64'd0, 156672, 0, 1, 1536); // dispatch967
        load(3'd1, 64'd18638867456, 64'd0, 156672, 0, 1, 4096); // dispatch986
        load(3'd1, 64'd18664041472, 64'd0, 156672, 0, 1, 6144); // dispatch990
        load(3'd1, 64'd18676636672, 64'd0, 156672, 0, 1, 4096); // dispatch995
        load(3'd1, 64'd18682953728, 64'd0, 156672, 0, 1, 1536); // dispatch999
        load(3'd1, 64'd18687151104, 64'd0, 156672, 0, 1, 4096); // dispatch1018
        load(3'd1, 64'd18712325120, 64'd0, 156672, 0, 1, 6144); // dispatch1022
        load(3'd1, 64'd18724920320, 64'd0, 156672, 0, 1, 4096); // dispatch1027
        load(3'd1, 64'd18731237376, 64'd0, 156672, 0, 1, 1536); // dispatch1031
        load(3'd1, 64'd18735434752, 64'd0, 156672, 0, 1, 4096); // dispatch1050
        load(3'd1, 64'd18760608768, 64'd0, 156672, 0, 1, 6144); // dispatch1054
        load(3'd1, 64'd18773203968, 64'd0, 156672, 0, 1, 4096); // dispatch1059
        load(3'd1, 64'd18779521024, 64'd0, 156672, 0, 1, 1536); // dispatch1063
        load(3'd1, 64'd18783718400, 64'd0, 156672, 0, 1, 4096); // dispatch1082
        load(3'd1, 64'd18808892416, 64'd0, 156672, 0, 1, 6144); // dispatch1086
        load(3'd1, 64'd18821487616, 64'd0, 156672, 0, 1, 4096); // dispatch1091
        load(3'd1, 64'd18827804672, 64'd0, 156672, 0, 1, 1536); // dispatch1095
        load(3'd1, 64'd18832002048, 64'd0, 156672, 0, 1, 4096); // dispatch1114
        load(3'd1, 64'd18857176064, 64'd0, 156672, 0, 1, 6144); // dispatch1118
        load(3'd1, 64'd18869771264, 64'd0, 156672, 0, 1, 4096); // dispatch1123
        load(3'd1, 64'd18876088320, 64'd0, 156672, 0, 1, 1536); // dispatch1127
        load(3'd1, 64'd18880285696, 64'd0, 156672, 0, 1, 4096); // dispatch1146
        load(3'd1, 64'd18905459712, 64'd0, 156672, 0, 1, 6144); // dispatch1150
        load(3'd1, 64'd18918054912, 64'd0, 156672, 0, 1, 4096); // dispatch1155
        load(3'd1, 64'd13040484352, 64'd0, 80640, 0, 1, 37984); // dispatch1158
        if (errs != 0) $fatal(1,"FATAL QWEN_LOAD errors=%0d",errs);
        if(contention==0||scratch_checks!=147*32)$fatal(1,"FATAL actual contention missing cycles%0d scratch%0d",contention,scratch_checks);
        $display("ACTUAL_VM4 phase=%0d contention=%0d SU_scratch_sectors=%0d",PHASE,contention,scratch_checks);
        $display("THREEPRODUCER_DMA_EXACT PASS records=147 bytes=%0d cycles=%0d price=15674.320143998 ratio=%0.9f",tbytes,tcyc,tcyc/15674.320143998484);
        if(tcyc>1.10*15674.320143998484)$display("THREEPRODUCER_DMA_PRICE_FAIL cycles%0d immutable15674.320143998 ratio%0.9f limit1.10",tcyc,tcyc/15674.320143998484);
        if($test$plusargs("CHECK_PRICE") && tcyc>1.10*15674.320143998484)
          $fatal(1,"FATAL QWEN_VM4_PRICE cycles=%0d immutable_price=15674.320143998 bound=1.10 ratio=%0.9f",tcyc,tcyc/15674.320143998484);
        finish_contract();
        $display("THREEPRODUCER_FUNCTIONAL PASS actualSU actualQDQ actualDMA records147+32 quantwords13312 phase%0d",PHASE);
        $finish;
    end
endmodule
