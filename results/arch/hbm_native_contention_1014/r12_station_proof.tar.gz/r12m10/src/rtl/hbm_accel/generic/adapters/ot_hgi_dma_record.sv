`timescale 1ns/1ps
`default_nettype none
// ---------------------------------------------------------------------------------------------------------------------
// HGI-1 DMA record adapter (hgi-adapters, 2026-10-09).  Unit 8 (DMA.LOAD / STORE / FENCE / KVWB_DS) of the normative
// sequencer dispatch onto a ROW-MOVE command port and a FENCE port of the die's DMA mover.  Decode + handshake only:
// the mover (svc native read / write clients + the VM packet client + the element format converters) is the engine.
//
// Move command (one per LOAD / STORE / KVWB_DS record):
//   227 b, LSB first: {src space 2, src fmt 3, src base 40, src stride 32, src istride 16, dst space 2, dst fmt 3,
//    dst base 40, dst stride 32, dst istride 16, m 20, n 21}  (spec 6.4 fields of the EFFECTIVE descriptors: the CP has already
//   applied L / L1 / DYN / the indexed id; istride 0 means 1, ibcast means 0)
//   LOAD  (op 0): A (HBM, or VM) -> O (VM); A.fmt in {FP32, BF16, FP8E4M3, INT8, U32} (decoded to the O word), O.fmt in
//                 {FP32, U32}, U32 only from U32 (hgi_sim u_dma_load);
//   STORE (op 1): A (VM, FP32 / U32) -> O (HBM, FP32 / BF16 / FP8E4M3 / U32) (hgi_sim u_dma_store, encode_fmt);
//   KVWB_DS (op 3): the DS window-ring write-back: A (VM, one row) -> slot (POS mod O.m) of ring O (HBM): dst base =
//                 O.base + (POS mod O.m) * O.stride, m 1.  POS = d_pos1 - 1; O.m must be a power of two (the DS ring).
//                 The product is a radix-16 iterative multiply (5 digits) -> KVWB issues 6 edges after decode.
//   n = effective n of A, which must equal O's; m = A.m = O.m (KVWB: A.m 1).
// FENCE (op 2): the fence port; the record retires when the mover reports every DMA write before it visible.
// Retire = the mover's done for the move (in order: one move outstanding) / fence_done.  Refusals (rec_fault, sticky
// halt): unit != 8, op > 3, a missing / wrong-space / wrong-format operand, n or m mismatch, KVWB ring not a power of 2.
// Latency: accept E0 (pin flops), checks E1, move word E2, move_v visible after E2 (KVWB: +6 for slot x stride).  LEGACY = 1 adds the static legacy pass-through on both ports.
// POSTED = 1 (hgi-1010/c 2026-10-10, coordinator budget audit): STORE and KVWB_DS retire when the mover reports their
//   source consumed (mv_src: every VM source sector read and landed), not when every HBM write is acknowledged; the HBM
//   writes complete in the background and DMA.FENCE (the mover's fence is accepted only when it is idle) / CTL.FENCE drain
//   them.  At most one posted move is in flight (the mover runs one move at a time); its completion is mv_pdone (the
//   mover's done), a front LOAD's is mv_fdone.  A posted move's fault halts the unit (rec_fault, sticky) when it occurs.
//   MUT_FENCE (bench): the fence retires without draining the posted move (stale data after the fence: must FAIL).
// INDEXED ROW STREAM (hgi-1010/c, spec 3.3): a LOAD whose A is indexed with n_sel = N_FROM_VM (63) goes to the engines'
//   stream port is_*: {ilist 32 = the I table's effective base + L (rec_ilist, from the CP), rebase 1, cnt 20 = A's
//   effective n (the CP read it from row 1 of I), O stride 32, O base 32, O n 21, A dyn_mul 27, A effective base 40
//   (holds id_0 x dyn_mul), A fmt 3}.  Checks: A HBM, O VM (FP32 / U32 as a LOAD), 1 <= cnt <= O.m, I operand present.
// ---------------------------------------------------------------------------------------------------------------------
module ot_hgi_dma_record #(
    parameter integer MUT_SLOT = 0,       // mutant: KVWB slot = POS (no ring wrap)
    parameter integer MUT_EARLY = 0,      // mutant: retire on issue
    parameter integer LEGACY = 1,
    parameter integer POSTED = 1,
    parameter integer MUT_FENCE = 0,
    parameter integer B2 = 0,             // el1011-hbm-b2 (2026-10-12): 1 = the DMA unit of B2 cluster QID (one a stack).  The B2
                                          //   dispatcher sends a record to onehot(stack of its HBM-side descriptor (A if A is HBM,
                                          //   else O)) or, STRIPE4 (base[39:37] = 1) / the indexed stream form, to all four; this
                                          //   unit faults (fail-closed, before any move) on any other record whose HBM side sits on
                                          //   a stack != QID.  The engines serve only stack QID (ot_hgi_dma_engines B2 / QID).
    parameter integer QID = 0,
    parameter integer SBIT = 35           // stack = HBM byte address [SBIT+1:SBIT] (B2 only)
) (
    input  wire          clk,
    input  wire          rst_n,
    input  wire          hgi_en,
    input  wire          rec_v,
    output wire          rec_rdy,
    input  wire [127:0]  rec_hdr,
    input  wire [255:0]  rec_a, rec_o,
    input  wire [20:0]   rec_n_a, rec_n_o,
    input  wire [20:0]   rec_pos1,
    input  wire [31:0]   rec_ilist,      // VM word address of this iteration's I row 0 entry (I effective base + L)
    output reg           rec_done,
    output reg           rec_fault,
    output wire          halted,
    output wire          wr_quiet,       // no posted STORE / KVWB in flight (CTL.FENCE waits for it); updates with rec_done
    // legacy (DS control path) mover / fence ports
    input  wire          lg_mv_v,
    output wire          lg_mv_rdy,
    input  wire [226:0]  lg_mv,
    input  wire          lg_fence_v,
    output wire          lg_fence_rdy,
    // mover ports
    output wire          mv_v,
    input  wire          mv_rdy,
    output wire [226:0]  mv,
    input  wire          mv_done,
    input  wire          mv_fault,
    input  wire          mv_src,         // the mover: the move's source consumed (POSTED)
    input  wire          mv_pdone,       // the mover's done (POSTED; mv_done = front done | mover done)
    input  wire          mv_fdone,       // the front's done (POSTED)
    output wire          is_v,           // indexed row stream command (ot_hgi_dma_engines)
    input  wire          is_rdy,
    output wire [207:0]  is_cmd,
    output wire          fence_v,
    input  wire          fence_rdy,
    input  wire          fence_done
);
    wire hen = LEGACY ? hgi_en : 1'b1;
    reg          raw_v, busy, halt_q, iss, is_fence, kv, kv_iss, mul_run;
    reg  [127:0] hdr_q; reg [255:0] a_q, o_q; reg [20:0] na_q, no_q, pos1_q; reg [31:0] il_q, il1; reg [20:0] no1;
    reg          is_str; reg [207:0] is_q;
    reg  [226:0] mv_q;
    reg  [2:0]   dig;
    reg  [19:0]  slot; reg [31:0] ost; reg [51:0] prod;
    reg          s1_v, bad1, rdy_r; reg [5:0] op1; reg [255:0] a1, o1; reg [20:0] na1; reg [19:0] slot1;
    reg          in_done, in_fault, in_fdone, in_src, in_pd, in_fd;
    always @(posedge clk) begin in_done <= mv_done; in_fault <= mv_fault; in_fdone <= fence_done; in_src <= mv_src; in_pd <= mv_pdone; in_fd <= mv_fdone; end
    reg          pst, post_cur;                                          // a posted move in flight; the current move is posted
    // the current (non-posted) move's completion: a front done, or a mover done that is not the posted move's
    wire cur_done = (POSTED != 0) ? (in_fd || (in_pd && !pst)) : in_done;
    assign halted = halt_q;
    assign wr_quiet = !pst;
    assign rec_rdy = hen && rdy_r;                                       // registered
    assign mv_v    = hen ? (iss && !is_fence && !is_str) : lg_mv_v;
    assign is_v    = hen && iss && is_str;
    assign is_cmd  = is_q;
    assign mv      = hen ? mv_q : lg_mv;
    assign lg_mv_rdy = !hen && mv_rdy;
    assign fence_v = hen ? (iss && is_fence && !pst && MUT_FENCE == 0) : lg_fence_v;
    assign lg_fence_rdy = !hen && fence_rdy;
    // ---- decode
    wire [5:0] op = hdr_q[123:118];
    wire [6:0] opnd = hdr_q[99:93];
    wire [1:0] as = a_q[1:0], os = o_q[1:0];
    wire [2:0] af = a_q[4:2], of = o_q[4:2];
    wire [19:0] om = o_q[87:68];
    wire a_ok_load  = (as == 2'd0 || as == 2'd1) && (af == 3'd0 || af == 3'd1 || af == 3'd2 || af == 3'd4 || af == 3'd5);
    wire o_ok_load  = os == 2'd1 && (of == 3'd0 || of == 3'd5) && ((of == 3'd5) == (af == 3'd5));
    wire a_ok_store = as == 2'd1 && (af == 3'd0 || af == 3'd5);
    wire o_ok_store = os == 2'd0 && (of == 3'd0 || of == 3'd1 || of == 3'd2 || of == 3'd5) && ((of == 3'd5) == (af == 3'd5));
    wire shape_ok   = (na_q == no_q) && (a_q[87:68] == om);
    wire str        = (op == 6'd0) && a_q[6] && a_q[206:201] == 6'd63;     // the indexed stream form
    wire str_ok     = opnd[6] && as == 2'd0 && na_q <= {1'b0, om} && na_q != 21'd0;
    wire kv_ok      = (om != 20'd0) && ((om & (om - 20'd1)) == 20'd0) && (na_q == no_q) && (a_q[87:68] == 20'd1);
    // B2: the HBM-side descriptor's stack / stripe code (HBM byte base = d[47:8])
    wire [255:0] hsd = (as == 2'd0) ? a_q : o_q;
    wire hs_v = (as == 2'd0) || (os == 2'd0);
    wire b2_bad = (B2 != 0) && (op != 6'd2) && hs_v && hsd[47:45] != 3'd1 && !str && hsd[8 + SBIT +: 2] != 2'(QID);
    wire bad = b2_bad || (hdr_q[127:124] != 4'd8) || (op > 6'd3) ||
               (op == 6'd0 && !(opnd[0] && opnd[4] && a_ok_load && o_ok_load && (str ? str_ok : shape_ok))) ||
               (op == 6'd1 && !(opnd[0] && opnd[4] && a_ok_store && o_ok_store && shape_ok)) ||
               (op == 6'd3 && !(opnd[0] && opnd[4] && a_ok_store && o_ok_store && kv_ok));
    function automatic [15:0] ist(input [255:0] d);
        ist = d[5] ? 16'd0 : (d[135:120] == 16'd0) ? 16'd1 : d[135:120];
    endfunction
    wire [20:0] pos = pos1_q - 21'd1;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            raw_v <= 1'b0; s1_v <= 1'b0; bad1 <= 1'b0; rdy_r <= 1'b0; busy <= 1'b0; halt_q <= 1'b0; iss <= 1'b0; is_fence <= 1'b0; kv <= 1'b0; kv_iss <= 1'b0; mul_run <= 1'b0; is_str <= 1'b0;
            rec_done <= 1'b0; rec_fault <= 1'b0; hdr_q <= 0; a_q <= 0; o_q <= 0; na_q <= 0; no_q <= 0; pos1_q <= 0;
            mv_q <= 0; dig <= 0; slot <= 0; ost <= 0; prod <= 0; pst <= 1'b0; post_cur <= 1'b0;
        end else begin
            rec_done <= 1'b0; rec_fault <= 1'b0;
            hdr_q <= rec_hdr; a_q <= rec_a; o_q <= rec_o; na_q <= rec_n_a; no_q <= rec_n_o; pos1_q <= rec_pos1; il_q <= rec_ilist;  // pin flops
            if (rec_v && rec_rdy) raw_v <= 1'b1;
            rdy_r <= hen && !raw_v && !s1_v && !busy && !halt_q && !(rec_v && rec_rdy);
            if (raw_v) begin                                   // E1: checks + the ring slot, operands copied
                raw_v <= 1'b0; s1_v <= 1'b1; bad1 <= bad; op1 <= op; a1 <= a_q; o1 <= o_q; na1 <= na_q; no1 <= no_q; il1 <= il_q;
                is_str <= str;
                slot1 <= MUT_SLOT ? pos[19:0] : (pos[19:0] & (om - 20'd1));
            end
            if (s1_v) begin                                    // E2: the move word
                s1_v <= 1'b0;
                if (bad1) begin rec_fault <= 1'b1; halt_q <= 1'b1; end
                else begin
                    busy <= 1'b1; is_fence <= (op1 == 6'd2); kv <= (op1 == 6'd3); kv_iss <= 1'b0;
                    post_cur <= (POSTED != 0) && (op1 == 6'd1 || op1 == 6'd3);
                    is_q <= {il1, 1'b1, na1[19:0], o1[119:88], o1[39:8], no1, a1[200:174], a1[47:8], a1[4:2]};
                    mv_q <= {na1, a1[87:68], ist(o1), o1[119:88], o1[47:8], o1[4:2], o1[1:0],
                             ist(a1), a1[119:88], a1[47:8], a1[4:2], a1[1:0]};
                    if (op1 == 6'd3) begin
                        slot <= slot1; ost <= o1[119:88]; prod <= 52'd0; dig <= 3'd5; mul_run <= 1'b1;
                    end else iss <= 1'b1;
                end
            end
            if (mul_run) begin                                 // dst base = O.base + slot * O.stride (radix 16, the
                dig <= dig - 3'd1;                             // slot shifts out its top digit: no indexed select)
                prod <= (prod << 4) + ost * slot[19:16];
                slot <= slot << 4;
                if (dig == 3'd1) mul_run <= 1'b0;
            end
            if (kv && busy && !mul_run && !kv_iss && dig == 3'd0) begin   // fields: o base [137:98], m [205:186]
                mv_q[137:98] <= mv_q[137:98] + prod[39:0]; mv_q[205:186] <= 20'd1; iss <= 1'b1; kv_iss <= 1'b1;
            end
            if (iss && ((!is_fence && !is_str && mv_rdy) || (is_str && is_rdy) || (is_fence && fence_rdy && !pst) || (is_fence && MUT_FENCE != 0)) && hen) begin
                iss <= 1'b0;
                if (MUT_EARLY) begin rec_done <= 1'b1; busy <= 1'b0; kv <= 1'b0; end
            end
            // the posted move's background completion (or its fault)
            if (pst && in_pd) pst <= 1'b0;
            if (pst && in_fault) begin rec_fault <= 1'b1; halt_q <= 1'b1; pst <= 1'b0; end
            if (busy && !iss && !mul_run && (!kv || kv_iss)) begin
                if (!is_fence && in_fault && !pst) begin rec_fault <= 1'b1; halt_q <= 1'b1; busy <= 1'b0; end
                else if (!is_fence && post_cur && in_src) begin                       // posted: source consumed
                    rec_done <= 1'b1; busy <= 1'b0; kv <= 1'b0; post_cur <= 1'b0;
                    pst <= !in_pd;                                                    // (done in the same cycle: not pending)
                end
                else if ((!is_fence && !post_cur && cur_done) || (is_fence && (in_fdone || MUT_FENCE != 0))) begin
                    rec_done <= 1'b1; busy <= 1'b0; kv <= 1'b0;
                end
            end
        end
    end
endmodule
`default_nettype wire
