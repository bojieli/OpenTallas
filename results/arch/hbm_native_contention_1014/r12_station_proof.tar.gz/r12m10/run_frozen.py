#!/usr/bin/env python3
import json,pathlib,os,subprocess,sys,hashlib
out=pathlib.Path(__file__).resolve().parent
meta=json.loads((out/'sourcegraph.json').read_text())
for entry in meta['files']:
 path=out/entry['path'] if entry['path'].startswith('vectors/') else out/'src'/entry['path']
 if hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:raise SystemExit(f"frozen source mismatch {entry['path']}")
v=os.environ.get('VERILATOR',str(pathlib.Path.home()/'.local/opentallas-tools/verilator-5.050/bin/verilator'))
src=[str(out/'src'/f['path']) for f in meta['files'] if not f['path'].startswith('vectors/')]
cmd=[v,'--lint-only' if '--lint-only' in sys.argv else '--binary','--timing','-O2','-CFLAGS','-O0','-j','4','-Wno-fatal','-Wno-lint','-Wno-style','--top-module','tb_hbm_native_threeproducer',f"-GMUT={meta['mut']}",f"-GPHASE={meta['phase']}",'--Mdir',str(out/'obj'),'-o','sim']+src
(out/'build-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'build.log').open('w') as f:rc=subprocess.call(cmd,stdout=f,stderr=subprocess.STDOUT)
if rc:print((out/'build.log').read_text()[-7000:]);sys.exit(rc)
if '--lint-only' in sys.argv:sys.exit(0)
runtime=[str(out/'obj'/'sim'),'+FULL',f'+QDIR={out/"vectors"}']+(['+SMOKE'] if '--smoke' in sys.argv else [])
(out/'runtime-command.json').write_text(json.dumps(runtime,indent=2)+'\n')
with (out/'run.log').open('w') as f:rc=subprocess.call(runtime,stdout=f,stderr=subprocess.STDOUT)
print((out/'run.log').read_text()[-7000:]);sys.exit(rc)
