read_liberty /w/libs/asap7sc7p5t_AO_RVT_TT_nldm_211120.lib
read_liberty /w/libs/asap7sc7p5t_INVBUF_RVT_TT_nldm_220122.lib
read_liberty /w/libs/asap7sc7p5t_OA_RVT_TT_nldm_211120.lib
read_liberty /w/libs/asap7sc7p5t_SEQ_RVT_TT_nldm_220123.lib
read_liberty /w/libs/asap7sc7p5t_SIMPLE_RVT_TT_nldm_211120.lib
read_liberty /src/physical/asap7_memory_macros/ot_rom_4096x266_m8/ot_rom_4096x266_m8_tt.lib
read_liberty /src/physical/asap7_memory_macros/ot_rom_4096x72_m8/ot_rom_4096x72_m8_tt.lib
read_liberty /src/physical/asap7_memory_macros/ot_sram_1r1w_64x512_m1_r2c2_p192_mir/ot_sram_1r1w_64x512_m1_r2c2_p192_mir_tt.lib
read_liberty /src/physical/ref_tile/qfd_tt_ctlm_dv_wtn/views/qfd_tt_ctlm_dv_wtn/qfd_tt_ctlm_dv_wtn_tt.lib
read_liberty /src/physical/ref_tile/qfd_tt_head_static_h16c/views/ot_qfd_tt_ctlm_static_hr/ot_qfd_tt_ctlm_static_hr_tt.lib
read_db /w/placed.odb
read_sdc /src/physical/ref_tile/qfd_tt_ctlm_dv_safe12c/clock.sdc
source /src/physical/ref_tile/qfd_tt_ctlm_dv_safe12c/pre_cts.tcl
source /w/contact_trace.tcl
set expected [dict create ck_core 11940 ck_hr 5188]
set actual [ot_dsp::admit]
dict for {root count} $expected {if {[dict get $actual $root] != $count} {error "physical/source count mismatch $root"}}
puts "ACTUAL_COLLECTOR_BASELINE PASS (physical Liberty contacts, not STA sinkcount)"
