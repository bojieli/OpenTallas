`timescale 1ns/1ps
// Candidate: one of 32 local 16-lane slices. All products are computed here.
// Feedback lives in two actual 128x256 SRAM macros, not a flop-array proxy.
module ot_qwen_tp8_pv256_slice(
 input wire clk,rst_n, take, input wire [6:0] c,
 input wire init_zero,input wire[6:0] init_c,
 input wire first, input wire [127:0] v, input wire [15:0] e,
 input wire read_leaf, input wire [6:0] leaf_c,
 input wire reduce_issue,reduce_capture,reduce_last,input wire[6:0] reduce_dst,
 output reg[511:0] tree_sum,
 output wire [511:0] leaf, output wire commit,
 output wire [6:0] commit_c, output wire fault
);
 reg [6:0] cp[0:10]; reg [10:0] vp,fp;
 wire [511:0] rd,prod,sum; wire [15:0] pv,pf,av; wire [31:0] ae;
 reg [511:0] old[0:2],reduce_a;
 reg[6:0] wp[0:6];reg[6:0] lastp;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n)begin vp<=0;fp<=0;lastp<=0;tree_sum<=0;end
  else begin vp<={vp[9:0],take};fp<={fp[9:0],first};lastp<={lastp[5:0],reduce_issue&&reduce_last};if(commit&&lastp[6])tree_sum<=sum;end
 end
 integer i;
 always @(posedge clk)begin
  cp[0]<=c;for(i=1;i<11;i=i+1)cp[i]<=cp[i-1];
  old[0]<=rd; old[1]<=old[0];old[2]<=old[1];
  if(reduce_capture)reduce_a<=rd;
  wp[0]<=reduce_issue?reduce_dst:cp[3];for(i=1;i<7;i=i+1)wp[i]<=wp[i-1];
 end
 assign commit=av[0];assign commit_c=wp[6];
 wire [15:0] bad_add;
 assign fault=(|(pf & pv)) || (|bad_add);
 assign leaf=rd;
 genvar m,l;
 generate for(m=0;m<2;m=m+1)begin:g_mem
  ot_sram_1r1w_128x256_m1_r2c2 u_mem(.clk(clk),
   .r_ce_in(take||read_leaf),.r_addr_in(read_leaf?leaf_c:c),.rd_out(rd[256*m+:256]),
   .w_ce_in(init_zero||commit),.w_addr_in(init_zero?init_c:commit_c),.wd_in(init_zero?256'b0:sum[256*m+:256]),.w_mask_in({256{1'b1}}),
   .rr_en(2'b0),.rr_addr(12'b0),.cr_en(2'b0),.cr_sel(16'b0));
 end
 for(l=0;l<16;l=l+1)begin:g_lane
  assign bad_add[l]=av[l] && (|ae[2*l+:2]);
  ot_qwen_nearhbm_prod u_prod(.clk(clk),.rst_n(rst_n),.valid_in(take),.a(e),.k(v[8*l+:8]),
   .y(prod[32*l+:32]),.fault(pf[l]),.valid_out(pv[l]));
  ot_hdc_fp32_add_lat #(.LAT(7)) u_add(.clk(clk),.rst_n(rst_n),.valid_in(pv[l]||reduce_issue),
   .a(reduce_issue?reduce_a[32*l+:32]:(fp[3]?32'b0:old[2][32*l+:32])),.b(reduce_issue?rd[32*l+:32]:prod[32*l+:32]),
   .y(sum[32*l+:32]),.err(ae[2*l+:2]),.valid_out(av[l]));
 end endgenerate
endmodule
