# ref_tile PRE_DETAIL_PLACE (kit recipe 2): release the FIRM hold cells / drivers and the pin flops for DPL
source /src/physical/dsrom_window_source/leaf_inhold_release.tcl
source /src/physical/qwen_die_masters/out_flop_release.tcl
source /src/physical/ref_tile/qfd_tt_ctlm_dv_safe12c/lcr_dissolve_after_gpl.tcl
