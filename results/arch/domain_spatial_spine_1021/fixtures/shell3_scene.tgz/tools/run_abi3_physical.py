#!/usr/bin/env python3
"""Physical characterisation driver for OpenTallas ABI 3.0 RTL blocks.

Runs one named RTL top module through one named technology view:

  * ``synth``  -- pinned Yosys + pinned ABC map to the view's standard-cell
                  liberty and report cell count / cell area / sequential area /
                  macro count.
  * ``sta``    -- pinned OpenSTA pre-layout static timing on the mapped
                  netlist and report WNS / TNS / hold WNS / Fmax.
  * ``pnr``    -- full place-and-route through the pinned OpenROAD-flow-scripts
                  container, reporting routed wire length, via count, DRC and
                  antenna violation counts.  Only for views whose ``pnr``
                  platform is populated.

Every recorded number comes from a tool this script actually invoked.  Nothing
is estimated, scaled or interpolated.  Output is canonical JSON and the driver
fails closed if the output path already exists unless ``--force`` is given.

Reproduce, from the repository root::

    python3 tools/run_abi3_physical.py --view sky130hd --block reduction_s8_g2 \\
        --clock-period-ns 20 --stages synth,sta \\
        --output results/physical_abi3/sky130hd/reduction_s8_g2/physical.json

Signal integrity.  ``--max-transition-ns`` and ``--max-fanout`` put explicit
``set_max_transition`` / ``set_max_fanout`` constraints in the SDC so ORFS's
repair_design buffers and sizes to them; ``--slew-margin-percent`` hands ORFS
its SLEW_MARGIN so the repair overfixes.  Bare ``--max-transition-ns`` takes
the corner's own liberty limit (asap7 RVT 0.32 ns, sky130hd 1.5 ns).  The
values used are recorded under ``place_and_route.signal_integrity_constraints``
and nothing is emitted or recorded when the options are absent.

Memory macros.  ``--memory-macro NAME`` (repeatable) names a memory macro the
place-and-route platform itself ships; its LEF and liberty are resolved inside
the pinned container from the platform's own ``lef/`` and ``lib/``
directories, never copied, and reach the flow as ``ADDITIONAL_LEFS``,
``ADDITIONAL_LIBS`` and ``SYNTH_BLACKBOXES``, which is how ORFS's own
macro-bearing designs get theirs.  ``--macro-place-halo X Y`` overrides the
platform's ``MACRO_PLACE_HALO``; without it the platform default stands.  What
was used is recorded under ``place_and_route.memory_macros`` and nothing is
emitted or recorded when the option is absent.

Design for test.  ``--dft scan`` inserts muxed-D full scan into the netlist
ORFS synthesised, between synthesis and floorplan, with ``tools/dft``: every
flop becomes a scan cell, stitched into ``--scan-chains`` balanced chains (or
as many as ``--scan-max-length`` needs), with ``scan_en``, ``scan_in[N-1:0]``
and ``scan_out[N-1:0]`` ports and lock-up latches where a chain crosses clock
domains (``--scan-clock-mixing mix``).  The scan description is retained as
``scan_chains.json`` beside the other artifacts and summarised under
``place_and_route.dft``; the route gets its own DESIGN_NICKNAME so it cannot
collide with an unscanned route of the same top.  Without ``--dft`` nothing is
emitted or recorded and the config.mk is byte-for-byte unchanged.

Pinned sources.  ``--source-root DIR`` reads the RTL from another checkout
(a worktree pinned at the commit being characterised); the record's ``git``
block then describes that tree and ``runner.driver`` names the commit this
driver came from.

Timeouts. ``--synth-timeout-seconds unlimited`` and
``--flow-timeout-seconds unlimited`` disable synthesis/STA and route wall
timeouts respectively. ``none`` is an alias. The corresponding environment
variables are ``OT_SYNTH_TIMEOUT_SECONDS`` and ``OT_FLOW_TIMEOUT_SECONDS``.
Python callers may use ``main(argv, synth_timeout=None, flow_timeout=None)``
or ``run(command, timeout=None)``. CLI overrides take precedence over Python
overrides; both are scoped to the invocation. Synthesis/STA has no default wall
cap; route retains its numeric default. Tool identity and platform probes keep
their own timeouts; this policy does not change inherited operating-system limits.
"""

from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import math
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# DRIVER_ROOT is the tree this file lives in.  ROOT is the tree the RTL
# sources, their git identity, the container's /src mount and every relative
# path are taken from: the driver's own tree unless --source-root rebinds it
# to a worktree pinned at the commit being characterised.
DRIVER_ROOT = Path(__file__).resolve().parent.parent
ROOT = DRIVER_ROOT
CAMPAIGN_ID = "opentallas-abi3-physical-v1"
SCHEMA_VERSION = 1

TOOLS_ROOT = Path(os.environ.get("OPENTALLAS_TOOLS_ROOT", Path.home() / ".local/opentallas-tools"))
YOSYS = TOOLS_ROOT / "yosys-0.68/bin/yosys"
YOSYS_ABC = TOOLS_ROOT / "yosys-0.68/bin/yosys-abc"
STA = TOOLS_ROOT / "opensta-be771a0/bin/sta"

PDK_FULL_ROOT = Path(
    os.environ.get("OPENTALLAS_PDK_FULL_ROOT", Path.home() / ".local/opentallas-pdk-full")
)
PDK_ASAP7_ROOT = Path(
    os.environ.get("OPENTALLAS_PDK_ASAP7_ROOT", Path.home() / ".local/opentallas-pdk-asap7")
)

SKY130_HD = PDK_FULL_ROOT / "sky130A/libs.ref/sky130_fd_sc_hd"
ASAP7_NLDM = PDK_ASAP7_ROOT / "lib/NLDM"

ORFS_IMAGE = os.environ.get("OPENTALLAS_ORFS_IMAGE", "openroad/orfs:latest")
# Clock gating (--clock-gating) and multi-corner hold repair (--hold-corners).
CLOCK_GATE_CELL = "ICGx1_ASAP7_75t_R"
CLOCK_GATE_MIN_FLOPS = 8
# ORFS asap7 corner names -> the liberty file list variable the platform defines
ORFS_LIB_CORNERS = {"TC": "TC_NLDM_LIB_FILES", "BC": "BC_NLDM_LIB_FILES", "WC": "WC_NLDM_LIB_FILES"}
# the memory compiler's liberty tag of each ORFS corner (tools/mem_compiler writes NAME_{tt,ss,ff}.lib)
ORFS_CORNER_MACRO_TAG = {"TC": "tt", "WC": "ss", "BC": "ff"}
ORFS_EXPECTED_IMAGE_ID = (
    "sha256:af971398d91e5d154ec40d3df26554efd8790107268a4c7f1e6bb8f222979d34"
)


class FlowError(RuntimeError):
    """Raised when a stage cannot produce a trustworthy result."""


# --------------------------------------------------------------------------
# Technology views
# --------------------------------------------------------------------------
#
# ``liberty`` files are the exact library the local pinned Yosys/OpenSTA lane
# reads.  ``pnr`` describes the OpenROAD-flow-scripts platform used for the
# place-and-route lane; that lane reads the platform files baked into the
# container image, which are NOT the same files as ``liberty`` (see
# docs/ABI3_PHYSICAL_VIEWS.md).

VIEWS: dict[str, dict[str, Any]] = {
    "sky130hd": {
        "description": (
            "SkyWater SKY130 high-density standard cells; open manufacturable "
            "130 nm foundry PDK.  Mature implementation view."
        ),
        "evidence_class": "mature open foundry PDK (manufacturable)",
        "node_nm": 130,
        "predictive": False,
        "pdk_lock": "configs/pdk/sky130_full_physical_lock.json",
        "cell_library": "sky130_fd_sc_hd",
        "default_corner": "tt",
        # Liberty time unit is 1 ns and capacitance unit is 1 pF.
        "time_unit_ns": 1.0,
        "cap_unit_ff": 1000.0,
        "output_load_ff": 5.0,
        "corners": {
            "tt": {
                "liberty": [SKY130_HD / "lib/sky130_fd_sc_hd__tt_025C_1v80.lib"],
                "voltage_v": 1.80,
                "temperature_c": 25.0,
                "process": "typical",
            },
            "ss": {
                "liberty": [SKY130_HD / "lib/sky130_fd_sc_hd__ss_100C_1v60.lib"],
                "voltage_v": 1.60,
                "temperature_c": 100.0,
                "process": "slow",
            },
            "ss_lv": {
                "liberty": [SKY130_HD / "lib/sky130_fd_sc_hd__ss_n40C_1v28.lib"],
                "voltage_v": 1.28,
                "temperature_c": -40.0,
                "process": "slow, extreme low voltage",
            },
            "ff": {
                "liberty": [SKY130_HD / "lib/sky130_fd_sc_hd__ff_n40C_1v95.lib"],
                "voltage_v": 1.95,
                "temperature_c": -40.0,
                "process": "fast",
            },
        },
        "dff_liberty_corner_relative": "lib/sky130_fd_sc_hd__tt_025C_1v80.lib",
        "dont_use": [
            "sky130_fd_sc_hd__probe_p_8",
            "sky130_fd_sc_hd__probec_p_8",
            "sky130_fd_sc_hd__lpflow_*",
        ],
        "pnr": {
            "platform": "sky130hd",
            "extra_config": {},
            # sky130hd ships a single tt liberty; ORFS has no corner switch.
            "corner_env": None,
        },
    },
    "asap7": {
        "description": (
            "ASAP7 7 nm predictive FinFET academic PDK (RVT), as distributed "
            "inside the pinned OpenROAD-flow-scripts image.  Predictive view."
        ),
        "evidence_class": "predictive academic PDK (not manufacturable)",
        "node_nm": 7,
        "predictive": True,
        "pdk_lock": "configs/pdk/asap7_local_liberty_lock.json",
        "cell_library": "asap7sc7p5t_RVT",
        "default_corner": "TT",
        # Liberty time unit is 1 ps and capacitance unit is 1 fF.
        "time_unit_ns": 0.001,
        "cap_unit_ff": 1.0,
        "output_load_ff": 3.898,
        "corners": {
            "TT": {
                "liberty": [
                    ASAP7_NLDM / "asap7sc7p5t_AO_RVT_TT_nldm_211120.lib",
                    ASAP7_NLDM / "asap7sc7p5t_INVBUF_RVT_TT_nldm_220122.lib",
                    ASAP7_NLDM / "asap7sc7p5t_OA_RVT_TT_nldm_211120.lib",
                    ASAP7_NLDM / "asap7sc7p5t_SEQ_RVT_TT_nldm_220123.lib",
                    ASAP7_NLDM / "asap7sc7p5t_SIMPLE_RVT_TT_nldm_211120.lib",
                ],
                "voltage_v": 0.70,
                "temperature_c": 0.0,
                "process": "typical",
            },
        },
        "dff_liberty_corner_relative": "asap7sc7p5t_SEQ_RVT_TT_nldm_220123.lib",
        "dont_use": ["*x1p*_ASAP7*", "*xp*_ASAP7*", "SDF*", "ICG*"],
        "pnr": {
            "platform": "asap7",
            "extra_config": {"ASAP7_USE_VT": "RVT"},
            "corner_env": "TC",
        },
    },
}


# --------------------------------------------------------------------------
# Design blocks
# --------------------------------------------------------------------------

BLOCKS: dict[str, dict[str, Any]] = {
    "reduction_s8_g2": {
        "top": "ot_reduction_endpoint",
        "sources": ["rtl/ot_reduction_tree.sv"],
        "parameters": {"DATA_W": 32, "GROUPS": 2, "SOURCES": 8, "TAG_W": 16},
        "clock_port": "clk",
        "false_path_from_ports": ["rst_n"],
        "description": (
            "Eight-source, two-group tagged deterministic reduction endpoint."
        ),
    },
    "matmul_bf16_sram_engine": {
        "top": "ot_ta_matmul_bf16_sram_engine",
        "sources": [
            "rtl/ot_fp32_rne_pkg.sv",
            "rtl/ot_ta_command_decoder.sv",
            "rtl/ot_ta_matmul_bf16_sram_engine.sv",
        ],
        "parameters": {},
        "clock_port": "clk",
        "false_path_from_ports": ["rst_n"],
        "description": (
            "MATMUL_BF16_TILE stream executor: command decode, exact BF16 "
            "widening multiply, binary32 RNE accumulate and BF16 conversion, "
            "with ordered 16-bit SRAM operand and accumulator traffic.  This "
            "is the block the cycle model's tensor engine actually is, and "
            "the one every tensor cycle in every study rests on; SRAM arrays "
            "are external, so it maps to standard cells only.  Its critical "
            "path is a whole FP32 multiply-add-convert chain in one cycle, so "
            "it closes far below the other blocks and needs a target period "
            "chosen for it -- 200 ns on sky130hd, 18 ns on asap7 -- rather "
            "than the period the smaller blocks use."
        ),
    },
    "add_bf16_sram_engine": {
        "top": "ot_ta_add_bf16_sram_engine",
        "sources": [
            "rtl/ot_ta_add_bf16_sram_engine.sv",
            "rtl/ot_ta_command_decoder.sv",
            "rtl/ot_bf16_add_rne.sv",
            "rtl/ot_ta_add_bf16_executor.sv",
        ],
        "parameters": {},
        "clock_port": "clk",
        "false_path_from_ports": ["rst_n"],
        "description": (
            "Memory-bound ADD_BF16 stream executor: command decode, RNE bf16 "
            "adder and ordered SRAM read/write control.  SRAM arrays are "
            "external, so the block maps to standard cells only."
        ),
    },
}


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def synth_memory_max_bits() -> int:
    """The inferred-memory ceiling ORFS synthesis will map rather than refuse.

    Reads ``OT_SYNTH_MEMORY_MAX_BITS`` when set, defaulting to 65,536 bits -- large
    enough for the descriptor and window register files these blocks carry, and
    still a bound rather than an invitation: a block that legitimately needs an SRAM
    macro should ask for one with ``--memory-macro`` and be measured with it.
    """
    import os

    raw = os.environ.get("OT_SYNTH_MEMORY_MAX_BITS")
    if not raw:
        return 65536
    try:
        value = int(raw)
    except ValueError:
        raise FlowError(
            f"OT_SYNTH_MEMORY_MAX_BITS={raw!r} is not an integer number of bits"
        ) from None
    if value < 1:
        raise FlowError("OT_SYNTH_MEMORY_MAX_BITS must be positive")
    return value


def flow_timeout_seconds() -> int | None:
    """Route wall timeout: legacy six-hour default, or explicit none/unlimited."""
    import os

    raw = os.environ.get("OT_FLOW_TIMEOUT_SECONDS")
    if not raw:
        return 21600
    if raw.strip().lower() in {"none", "unlimited"}:
        return None
    try:
        value = int(raw)
    except ValueError:
        raise FlowError(
            f"OT_FLOW_TIMEOUT_SECONDS={raw!r} is not an integer number of seconds"
        ) from None
    if value < 600:
        raise FlowError(
            f"OT_FLOW_TIMEOUT_SECONDS={value} is below the 600 s floor; a ceiling "
            "that short reports every real route as an error"
        )
    return value


def tns_end_percent() -> int:
    """ORFS repair_timing TNS target; allow explicit limited-repair routes."""
    import os

    raw = os.environ.get("OT_TNS_END_PERCENT", "100")
    try:
        value = int(raw)
    except ValueError:
        raise FlowError(f"OT_TNS_END_PERCENT={raw!r} is not an integer") from None
    if not 0 <= value <= 100:
        raise FlowError(f"OT_TNS_END_PERCENT={value} must be between 0 and 100")
    return value


def synth_timeout_seconds() -> int | None:
    """Synthesis/STA wall timeout: unlimited unless a positive cap is explicit."""
    import os

    raw = os.environ.get("OT_SYNTH_TIMEOUT_SECONDS")
    if not raw:
        return None
    if raw.strip().lower() in {"none", "unlimited"}:
        return None
    try:
        value = int(raw)
    except ValueError as exc:
        raise SystemExit(f"OT_SYNTH_TIMEOUT_SECONDS is not an integer: {raw!r}") from exc
    if value < 0:
        raise SystemExit("OT_SYNTH_TIMEOUT_SECONDS must be nonnegative")
    return value or None


def orfs_num_cores() -> int | None:
    """ORFS thread count, from ``OT_ORFS_NUM_CORES`` when set.

    ORFS defaults ``NUM_CORES`` to the container's ``nproc``; on a shared worker
    that oversubscribes the host when several routes run.  Unset keeps the ORFS
    default, so no existing route moves.  The value is recorded under
    ``runner.orfs_num_cores``.
    """
    raw = os.environ.get("OT_ORFS_NUM_CORES")
    if not raw:
        return None
    try:
        value = int(raw)
    except ValueError as exc:
        raise SystemExit(f"OT_ORFS_NUM_CORES is not an integer: {raw!r}") from exc
    if value <= 0:
        raise SystemExit("OT_ORFS_NUM_CORES must be positive")
    return value


def run(cmd: list[str], *, cwd: Path | None = None, timeout: int | None = 7200) -> subprocess.CompletedProcess:
    proc = subprocess.run(
        cmd,
        cwd=str(cwd or ROOT),
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )
    return proc


def require_success(proc: subprocess.CompletedProcess, what: str) -> None:
    if proc.returncode != 0:
        tail = (proc.stdout or "")[-3000:] + "\n" + (proc.stderr or "")[-3000:]
        raise FlowError(f"{what} failed with exit {proc.returncode}:\n{tail}")


def tool_identity(path: Path, version_args: list[str]) -> dict[str, Any]:
    if not path.is_file():
        raise FlowError(f"pinned tool missing: {path}")
    proc = run([str(path), *version_args], timeout=120)
    text = ((proc.stdout or "") + (proc.stderr or "")).strip().splitlines()
    version = ""
    for line in text:
        if line.strip():
            version = line.strip()
            break
    return {
        "path": str(path),
        "version": version,
        "sha256": sha256_file(path),
    }


def git_identity() -> dict[str, Any]:
    """Commit and cleanliness of the tree the sources are read from.

    The flow writes its own records under ``results/`` inside the tree, so an
    earlier run's untracked output must not mark a later run dirty; those
    paths are listed separately.  Anything else -- a modified tracked file or
    an untracked file outside ``results/`` -- is dirt, because it could be
    source the record's commit does not describe.
    """
    head = run(["git", "rev-parse", "HEAD"])
    status = run(["git", "status", "--porcelain"])
    lines = [line for line in (status.stdout or "").splitlines() if line.strip()]

    def untracked_result(line: str) -> bool:
        return line.startswith("?? ") and line[3:].startswith("results/")

    dirt = [line for line in lines if not untracked_result(line)]
    return {
        "commit": (head.stdout or "").strip() or None,
        "worktree_dirty": bool(dirt),
        "worktree_status": dirt[:50],
        "untracked_results": [line[3:] for line in lines if untracked_result(line)][:50],
        "dirty_basis": (
            "a tracked file modified or an untracked file outside results/; "
            "untracked files under results/ (records the flow itself writes) "
            "are listed in untracked_results and do not count"
        ),
    }


def driver_identity() -> dict[str, Any]:
    """Which driver file ran, and the commit of the tree it came from.

    ``git`` in the record describes the tree the sources came from (``ROOT``).
    With ``--source-root`` that is a worktree pinned at the RTL's commit, whose
    own copy of this driver may be older; the driver that actually ran is
    identified here so the record names both commits.
    """
    path = Path(__file__).resolve()
    head = run(["git", "rev-parse", "HEAD"], cwd=DRIVER_ROOT)
    status = run(["git", "status", "--porcelain", "--", str(path)], cwd=DRIVER_ROOT)
    same_tree = DRIVER_ROOT.resolve() == ROOT.resolve()
    return {
        "path": str(path),
        "sha256": sha256_file(path),
        "tree": str(DRIVER_ROOT),
        "commit": (head.stdout or "").strip() or None,
        "file_modified_since_commit": bool((status.stdout or "").strip()),
        "same_tree_as_sources": same_tree,
        "note": (
            "the driver and the sources come from the same tree; git.commit describes both"
            if same_tree
            else (
                "the sources, their git identity (the record's git block) and the "
                "container's /src mount come from --source-root; the driver ran from "
                "a different checkout, so git.commit is the sources' commit and "
                "runner.driver.commit is the driver's"
            )
        ),
    }


def canonical_dump(payload: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False)
    # Publish only a complete, flushed record. A full disk must not truncate
    # an existing result or leave an empty destination that blocks a retry.
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8",
                                         dir=path.parent, prefix=f".{path.name}.",
                                         suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(text + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


# --------------------------------------------------------------------------
# Liberty scanning (cell area + sequential classification)
# --------------------------------------------------------------------------

_CELL_SPLIT = re.compile(r"\n\s*cell\s*\(\s*\"?([A-Za-z0-9_./\\\[\]-]+)\"?\s*\)\s*\{")
_AREA_RE = re.compile(r"\n\s*area\s*:\s*([0-9.eE+-]+)[ \t]*(?:;|$)", re.MULTILINE)
_SEQ_RE = re.compile(r"\n\s*(?:ff|ff_bank|latch|latch_bank)\s*\(")


def scan_liberty(paths: list[Path]) -> dict[str, dict[str, Any]]:
    """Return {cell_name: {"area": float, "sequential": bool}} for the library.

    Cells are top-level groups in every liberty file used here, so splitting on
    the ``cell (NAME) {`` header is sufficient to bound each cell's body.
    """
    cells: dict[str, dict[str, Any]] = {}
    for path in paths:
        text = path.read_text(errors="ignore")
        matches = list(_CELL_SPLIT.finditer(text))
        for index, match in enumerate(matches):
            name = match.group(1)
            end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
            body = text[match.end(): end]
            area_match = _AREA_RE.search("\n" + body)
            cells[name] = {
                "area": float(area_match.group(1)) if area_match else 0.0,
                "sequential": bool(_SEQ_RE.search("\n" + body)),
                "macro": bool(re.search(r"\bmemory\s*\(|\bis_macro_cell\s*:\s*true\s*;", body)),
            }
    return cells


def expand_dont_use(patterns: list[str], cells: dict[str, dict[str, Any]]) -> list[str]:
    matched = {
        name
        for name in cells
        if any(fnmatch.fnmatch(name, pattern) for pattern in patterns)
    }
    return sorted(matched)


# --------------------------------------------------------------------------
# Netlist normalisation
# --------------------------------------------------------------------------

_SIGNED_RE = re.compile(r"\b(input|output|inout|wire|reg)\s+signed\b")


def normalise_netlist(source: Path, target: Path) -> int:
    """Strip ``signed`` from declarations; OpenSTA's Verilog reader rejects it.

    This is a declaration-attribute-only edit on a structural gate netlist: it
    removes no cells, nets, ports or connectivity.
    """
    text = source.read_text(encoding="utf-8")
    normalised, count = _SIGNED_RE.subn(r"\1", text)
    target.write_text(normalised, encoding="utf-8")
    return count


# --------------------------------------------------------------------------
# Stage: synthesis
# --------------------------------------------------------------------------


# Summary rows emitted by ``stat`` that are not standard cells.
_STAT_SUMMARY_ROWS = {
    "wires",
    "wire",
    "bits",
    "ports",
    "cells",
    "memories",
    "processes",
}


def parse_stat(text: str, top: str | None = None) -> dict[str, Any]:
    """Select one authoritative Yosys cell table, never add hierarchy rows.

    With preserved submodules, only ``design hierarchy`` contains flattened
    primitive counts. Its initial indented tree and final submodule summary
    describe ownership, not additional cells. Multiple stat invocations or
    partial/ambiguous module-only reports fail closed.
    """
    sections = []
    current = None
    number = r"(?:[0-9]+(?:\.[0-9]*)?(?:[eE][+-]?[0-9]+)?|-)"
    row_re = re.compile(rf"^\s+(\d+)\s+({number})\s+(\S+)\s*$")
    for line in text.splitlines():
        header = re.fullmatch(r"=== (.+) ===", line.strip())
        if header:
            current = {"name": header[1].lstrip("\\"), "per_cell": {},
                       "count": None, "area": None, "area_top": None,
                       "submodules": False}
            sections.append(current)
            continue
        if current is None:
            continue
        area = re.match(r"\s*Chip area for (?:top )?module '([^']+)':\s*([0-9.eE+-]+)", line)
        if area:
            if current["area"] is not None:
                raise FlowError("duplicate chip area in Yosys stat section")
            current["area"], current["area_top"] = float(area[2]), area[1].lstrip("\\")
            continue
        row = row_re.match(line)
        if not row:
            continue
        count, area_text, name = int(row[1]), row[2], row[3]
        if name == "cells":
            if current["count"] is not None:
                raise FlowError("duplicate cell table in Yosys stat section")
            current["count"] = count
            continue
        if name == "submodules":
            current["submodules"] = True
        if (current["count"] is None or current["submodules"]
                or name in _STAT_SUMMARY_ROWS):
            continue
        if name in current["per_cell"]:
            raise FlowError(f"duplicate cell type in Yosys stat: {name}")
        current["per_cell"][name] = {
            "count": count, "area": None if area_text == "-" else float(area_text)}

    hierarchy = [section for section in sections if section["name"] == "design hierarchy"]
    if hierarchy:
        if len(hierarchy) != 1:
            raise FlowError("ambiguous multiple design hierarchy stat sections")
        selected = hierarchy[0]
    else:
        if len(sections) != 1:
            raise FlowError("Yosys stat needs one flat module or one design hierarchy summary")
        selected = sections[0]
        if selected["submodules"]:
            raise FlowError("module-local stat with submodules lacks hierarchy totals")
    if selected["count"] is None:
        raise FlowError("Yosys stat has no authoritative cell total")
    if sum(item["count"] for item in selected["per_cell"].values()) != selected["count"]:
        raise FlowError("Yosys stat cell table disagrees with authoritative cell total")
    selected_top = selected["area_top"] or (selected["name"] if not hierarchy else None)
    if top is not None and selected_top != top.lstrip("\\"):
        raise FlowError(f"Yosys stat top mismatch: expected {top}, got {selected['area_top']}")
    return {"per_cell": selected["per_cell"], "chip_area_um2": selected["area"],
            "selection": {"section": selected["name"], "top": selected_top,
                          "cell_count": selected["count"],
                          "basis": "design hierarchy leaf cells" if hierarchy else "flat module cells"}}


def summarize_stat(stat: dict[str, Any], cells: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Classify library cells; absent library entries remain explicitly unknown.

    Missing library cells are not evidence of hard macros. Known macro identity
    comes from Liberty memory groups / is_macro_cell, never a name heuristic.
    """
    total = seq = macros = unknown_count = 0
    area = seq_area = 0.0
    unknown = []
    unknown_area = []
    for name, info in sorted(stat["per_cell"].items()):
        count = info["count"]
        total += count
        entry = cells.get(name)
        if entry is None:
            unknown.append(name)
            unknown_count += count
            if info["area"] is None:
                unknown_area.append(name)
            else:
                area += info["area"]
            continue
        cell_area = count * entry["area"]
        area += cell_area
        if entry.get("macro", False):
            macros += count
        elif entry["sequential"]:
            seq += count
            seq_area += cell_area
    if (not unknown and all(info["area"] is not None for info in stat["per_cell"].values())
            and stat["chip_area_um2"] is not None
            and abs(area - stat["chip_area_um2"]) > max(0.00001, abs(area) * 0.000001)):
        raise FlowError("Yosys chip area disagrees with selected counts and Liberty area")
    return {"cell_count": total, "cell_area_um2": None if unknown_area else round(area, 6),
            "chip_area_um2": stat["chip_area_um2"],
            "sequential_cell_count": seq, "sequential_area_um2": round(seq_area, 6),
            "combinational_cell_count": total - seq - macros - unknown_count,
            "macro_count": macros, "unmapped_cell_count": unknown_count,
            "unmapped_cell_types": unknown, "unknown_area_cell_types": unknown_area,
            "cell_types_used": len(stat["per_cell"]), "stat_selection": stat["selection"],
            "cell_area_basis": "Liberty area times count; stat area only for unknown cells"}


def w11_controller_endpoint_commands(block: dict[str, Any]) -> list[str]:
    """Opt-in physical-stub register retention; production RTL is unchanged."""
    if not block.get("preserve_w11_controller_endpoints", False):
        return []
    expected = {"BREG": 1, "D": 512, "NSTAGE": 2, "PHYS": 1, "REPL": 2}
    if block["top"] != "ot_v41_attn_eng_ctl_phys" or block["parameters"] != expected:
        raise FlowError("W11 endpoint preservation requires the pinned full 64-tile PHYS controller configuration")
    # Wire-level keep cannot prevent bit-level duplicate-register merging.
    # Mark only the register cells representing tile/transposer/merge/macro
    # boundaries, before synth decomposes vector registers into individual bits.
    return ["proc", "flatten", *[
        f"setattr -set keep 1 c:*{region}* t:*dff* %i"
        for region in ("g_t[", "g_tr[", "g_m[", "u_stage")]]


def run_synthesis(
    view: dict[str, Any],
    corner: dict[str, Any],
    block: dict[str, Any],
    work: Path,
    clock_period_ns: float,
    dont_use: list[str],
) -> dict[str, Any]:
    liberty = [Path(p) for p in corner["liberty"]]
    for path in liberty:
        if not path.is_file():
            raise FlowError(f"liberty file missing: {path}")

    dff_lib = None
    relative = view["dff_liberty_corner_relative"]
    for path in liberty:
        if str(path).endswith(relative) or path.name == Path(relative).name:
            dff_lib = path
    if dff_lib is None:
        dff_lib = liberty[0]

    sources = [ROOT / s for s in block["sources"]]
    for path in sources:
        if not path.is_file():
            raise FlowError(f"RTL source missing: {path}")

    chparam = "".join(
        f" -chparam {name} {value}" for name, value in sorted(block["parameters"].items())
    )
    liberty_args = "".join(f" -liberty {path}" for path in liberty)
    dont_use_args = "".join(f" -dont_use {name}" for name in dont_use)
    # ABC's delay target is expressed in picoseconds regardless of the library.
    delay_target_ps = clock_period_ns * 1000.0

    raw_netlist = work / "mapped.raw.v"
    stat_path = work / "stat.txt"
    script = work / "synth.ys"
    # An integrated clock gate the RTL instantiates (ot_hdc_cg) is a liberty
    # cell: read the sequential library as black boxes so hierarchy -check
    # accepts it.  Only when a source names one, so every other synth.ys is
    # byte-identical to before.
    icg_lib = [f"read_liberty -lib {dff_lib}"] if any(
        "ICGx" in path.read_text(encoding="utf-8", errors="replace") for path in sources) else []
    script.write_text(
        "\n".join(
            [
                *icg_lib,
                *(f"read_verilog -sv {path}" for path in sources),
                f"hierarchy -check -top {block['top']}{chparam}",
                *w11_controller_endpoint_commands(block),
                f"synth -top {block['top']} -flatten",
                f"dfflibmap -liberty {dff_lib}",
                f"abc{liberty_args}{dont_use_args} -D {delay_target_ps:g}",
                "setundef -zero",
                "splitnets -ports",
                "opt_clean -purge",
                f"tee -o {stat_path} stat{liberty_args}",
                f"write_verilog -noattr {raw_netlist}",
                "",
            ]
        ),
        encoding="utf-8",
    )

    proc = run([str(YOSYS), "-s", str(script)], timeout=synth_timeout_seconds())
    require_success(proc, "yosys synthesis")
    (work / "yosys.log").write_text((proc.stdout or "") + (proc.stderr or ""), encoding="utf-8")
    if not raw_netlist.is_file():
        raise FlowError("yosys produced no mapped netlist")

    stat = parse_stat(stat_path.read_text(encoding="utf-8"), top=block["top"])
    summary = summarize_stat(stat, scan_liberty(liberty))
    seq_cells = summary["sequential_cell_count"]

    netlist = work / "mapped.v"
    stripped = normalise_netlist(raw_netlist, netlist)

    if block.get("preserve_w11_controller_endpoints"):
        # Keep the historical full-size admission bound. Check mapped cells,
        # using liberty's sequential classification, before any P&R starts.
        expected = 338023
        threshold = expected * 8 // 10
        guard = {"expected_sequential": expected, "threshold": threshold,
                 "observed_sequential": seq_cells,
                 "normalized_netlist_sha256": sha256_file(netlist),
                 "verdict": "passed" if seq_cells >= threshold else "aborted",
                 "check": "liberty-classified sequential cells after host synthesis"}
        (work / "w11_endpoint_guard.json").write_text(json.dumps(guard, indent=2) + "\n")
        if seq_cells < threshold:
            raise FlowError(f"W11 full-size endpoint guard failed: {seq_cells} < {threshold}")

    return {
        "netlist": netlist,
        "record": {
            **summary,
            "abc_delay_target_ps": delay_target_ps,
            "dont_use_cell_count": len(dont_use),
            "netlist_normalization": {
                "signed_declarations_stripped": stripped,
                "raw_netlist_sha256": sha256_file(raw_netlist),
                "normalized_netlist_sha256": sha256_file(netlist),
            },
        },
    }


# --------------------------------------------------------------------------
def prepare_w11_orfs_endpoint_netlist(block: dict[str, Any], work: Path, case: Path) -> dict[str, Any] | None:
    """Use the guarded mapped endpoints in ORFS, avoiding independent RTL synthesis."""
    if not block.get("preserve_w11_controller_endpoints"):
        return None
    w11_controller_endpoint_commands(block)
    guard_path, netlist = work / "w11_endpoint_guard.json", work / "mapped.v"
    if not guard_path.is_file() or not netlist.is_file():
        raise FlowError("W11 endpoint P&R requires the guarded host synthesis stage")
    guard = json.loads(guard_path.read_text())
    if (guard.get("verdict") != "passed" or guard.get("threshold") != 270418
            or guard.get("expected_sequential") != 338023
            or guard.get("observed_sequential", 0) < 270418
            or guard.get("normalized_netlist_sha256") != sha256_file(netlist)):
        raise FlowError("W11 endpoint mapped-netlist admission failed")
    shutil.copyfile(netlist, case / "w11_endpoint_mapped.v")
    return {"mapped_netlist_sha256": sha256_file(netlist), "guard": guard,
            "basis": "ORFS SYNTH_NETLIST_FILES copies the guarded host netlist without reoptimization. "
                     "Host synthesis uses the selected driver liberty; routed setup/hold use ORFS WC/BC."}


# SDC and signal-integrity constraints
# --------------------------------------------------------------------------
#
# Every SDC the driver writes carries ``set_max_fanout 32``; nothing else
# bounded slew, so the only max-transition limits ORFS saw were the liberty
# files' own (``default_max_transition`` and per-pin ``max_transition``:
# 320 ps in ASAP7 RVT, 1.5 ns in sky130hd).  repair_design buffers and sizes
# every net to the tightest limit on each of its pins -- SDC or liberty --
# under placement- and global-route-estimated parasitics; the finish report
# re-checks the same limits with extracted parasitics, and an LQ8 route came
# out with 292 pins over 320 ps.  ``--max-transition-ns`` puts an explicit
# design-wide limit in the SDC, ``--max-fanout`` replaces the fixed 32, and
# ``--slew-margin-percent`` hands ORFS its SLEW_MARGIN so repair_design
# overfixes by that fraction of the limit.  None of the three is emitted or
# recorded unless given: a record without
# ``place_and_route.signal_integrity_constraints`` was routed with exactly
# the SDC every earlier record had.

DEFAULT_MAX_FANOUT = 32
LIBRARY_LIMIT = "library"
DRIVER_DEFAULT = "default"

_DEFAULT_MAX_TRANSITION_RE = re.compile(
    r"^\s*default_max_transition\s*:\s*([0-9.eE+-]+)\s*;", re.M
)
_DEFAULT_MAX_FANOUT_RE = re.compile(r"^\s*default_max_fanout\s*:\s*([0-9.eE+-]+)\s*;", re.M)
_PIN_MAX_TRANSITION_RE = re.compile(r"^\s*max_transition\s*:", re.M)
_PIN_MAX_FANOUT_RE = re.compile(r"^\s*max_fanout\s*:", re.M)


def library_slew_limits(corner: dict[str, Any]) -> list[dict[str, Any]]:
    """What each liberty file of the corner declares as its slew limit.

    ``default_max_transition`` is in the library's own time unit (ps for
    ASAP7, ns for sky130); ``pin_max_transition_count`` is how many per-pin
    ``max_transition`` attributes the file carries, which override it.
    """
    found: list[dict[str, Any]] = []
    for path in corner["liberty"]:
        path = Path(path)
        text = path.read_text(errors="ignore")
        match = _DEFAULT_MAX_TRANSITION_RE.search(text)
        found.append(
            {
                "liberty": path.name,
                "default_max_transition": float(match.group(1)) if match else None,
                "pin_max_transition_count": len(_PIN_MAX_TRANSITION_RE.findall(text)),
            }
        )
    return found


def library_fanout_limits(corner: dict[str, Any]) -> list[dict[str, Any]]:
    """What each liberty file of the corner declares as its fanout limit, if anything."""
    found: list[dict[str, Any]] = []
    for path in corner["liberty"]:
        path = Path(path)
        text = path.read_text(errors="ignore")
        match = _DEFAULT_MAX_FANOUT_RE.search(text)
        found.append(
            {
                "liberty": path.name,
                "default_max_fanout": float(match.group(1)) if match else None,
                "pin_max_fanout_count": len(_PIN_MAX_FANOUT_RE.findall(text)),
            }
        )
    return found


def signal_integrity_sdc_lines(constraints: dict[str, Any] | None) -> list[str]:
    """The ``set_max_*`` lines of the SDC for these constraints (legacy 32 fanout when none)."""
    constraints = constraints or {}
    lines = [f"set_max_fanout {constraints.get('max_fanout', DEFAULT_MAX_FANOUT)} [current_design]"]
    if constraints.get("max_transition_library_units") is not None:
        lines.append(
            f"set_max_transition {constraints['max_transition_library_units']:g} [current_design]"
        )
    return lines


def resolve_signal_integrity_constraints(
    view: dict[str, Any],
    corner: dict[str, Any],
    max_transition_ns: float | str | None,
    max_fanout: int | str | None,
    slew_margin_percent: float | None,
    hold_margin_ns: float | None = None,
    clock_gating: bool = False,
    hold_corners: list[str] | None = None,
) -> dict[str, Any] | None:
    """Turn the command-line options into the recorded constraint block.

    Returns ``None`` when no option was given, so the SDC and the record are
    exactly what they were before the options existed.
    """
    if (
        max_transition_ns is None
        and max_fanout is None
        and slew_margin_percent is None
        and hold_margin_ns is None
        and not clock_gating
        and not hold_corners
    ):
        return None
    time_unit_ns = view["time_unit_ns"]
    out: dict[str, Any] = {}

    if max_transition_ns is not None:
        slew_limits = library_slew_limits(corner)
        declared = [e["default_max_transition"] for e in slew_limits if e["default_max_transition"] is not None]
        if max_transition_ns == LIBRARY_LIMIT:
            if not declared:
                raise FlowError(
                    "no liberty file of this corner declares default_max_transition; "
                    "give --max-transition-ns a value"
                )
            limit_lib = min(declared)
            ns = float(f"{limit_lib * time_unit_ns:.6g}")
            source = (
                "library: the smallest default_max_transition declared by the corner's "
                "liberty files, in the library time unit"
            )
        else:
            ns = float(max_transition_ns)
            if ns <= 0:
                raise FlowError(f"--max-transition-ns must be positive, got {ns}")
            limit_lib = float(f"{ns / time_unit_ns:.6g}")
            source = "command line"
        out["max_transition_ns"] = ns
        out["max_transition_library_units"] = limit_lib
        out["max_transition_source"] = source
        out["library_default_max_transition"] = slew_limits

    if max_fanout is not None:
        fanout_limits = library_fanout_limits(corner)
        declares_any = any(
            e["default_max_fanout"] is not None or e["pin_max_fanout_count"] for e in fanout_limits
        )
        if max_fanout == DRIVER_DEFAULT:
            n = DEFAULT_MAX_FANOUT
            source = "driver default: the set_max_fanout every earlier record's SDC carried"
        else:
            n = int(max_fanout)
            if n <= 0:
                raise FlowError(f"--max-fanout must be positive, got {n}")
            source = "command line"
        out["max_fanout"] = n
        out["max_fanout_source"] = source
        out["library_default_max_fanout"] = fanout_limits
        out["library_declares_fanout_limit"] = declares_any

    if slew_margin_percent is not None:
        margin = float(slew_margin_percent)
        if not 0.0 <= margin < 100.0:
            raise FlowError(f"--slew-margin-percent must be in [0, 100), got {margin}")
        out["slew_margin_percent"] = margin
    if hold_margin_ns is not None:
        out["hold_margin_ns"] = float(hold_margin_ns)
        out["hold_margin_library_units"] = float(f"{float(hold_margin_ns) / time_unit_ns:.6g}")
        out["hold_margin_basis"] = (
            "ORFS HOLD_SLACK_MARGIN: repair_timing targets this much POSITIVE hold "
            "slack under global-route-estimated parasitics so the RCX-extracted "
            "finish check still lands non-negative.  Absent: ORFS default 0, which "
            "leaves the estimate-versus-extraction gap standing as a violation"
        )
    if clock_gating:
        out["clock_gating"] = {
            "infer": True,
            "cell": CLOCK_GATE_CELL,
            "min_flops_per_gate": CLOCK_GATE_MIN_FLOPS,
            "basis": (
                "ORFS INFER_CLKGATES: yosys `clockgate` turns every set of at least "
                f"{CLOCK_GATE_MIN_FLOPS} flip-flops sharing a clock and an enable into "
                f"one {CLOCK_GATE_CELL} integrated clock gate and enable-less flops "
                "(register-bank gating); ICG cells instantiated in the RTL (ot_hdc_cg, "
                "unit gating) are kept either way.  The platform lists ICG* as "
                "dont_use, which only stops the resizer from choosing one"
            ),
        }
    if hold_corners:
        bad = [c for c in hold_corners if c not in ORFS_LIB_CORNERS]
        if bad:
            raise FlowError(f"--hold-corners: unknown ORFS corner(s) {bad}; known {sorted(ORFS_LIB_CORNERS)}")
        out["hold_corners"] = list(hold_corners)
        out["hold_corners_basis"] = (
            "ORFS CORNERS: every listed corner's liberty is read as its own "
            "scene, so repair_timing fixes setup AND hold at each of them (ASAP7: "
            "TC = TT 0.70 V 25 C, BC = FF 0.77 V 0 C, WC = SS 0.63 V 100 C); the "
            "platform's multi-bit flop views stay the primary corner's"
        )
    if hold_margin_ns is not None:
        # (the slew-margin wording rides with the hold margin, as it always has)
        out["slew_margin_basis"] = (
            "ORFS SLEW_MARGIN, passed to repair_design -slew_margin at placement and "
            "after global routing: the repair targets (100 - margin)% of each pin's "
            "slew limit under estimated parasitics; the finish check keeps the full limit"
        )

    out["sdc_lines"] = signal_integrity_sdc_lines(out)
    out["basis"] = (
        "explicit SDC signal-integrity constraints this route was repaired against; "
        "absent from a record means the SDC carried only set_max_fanout 32 and the "
        "liberty files' own max_transition limits"
    )
    return out


def sdc_lines(
    view: dict[str, Any],
    block: dict[str, Any],
    clock_period_ns: float,
    constraints: dict[str, Any] | None = None,
) -> list[str]:
    """The SDC both the host OpenSTA stage and the ORFS flow are constrained by."""
    period_lib = clock_period_ns / view["time_unit_ns"]
    load_lib = view["output_load_ff"] / view["cap_unit_ff"]
    lines = [
        f"set clk_period {period_lib:g}",
        f"create_clock -name core_clk -period $clk_period [get_ports {block['clock_port']}]",
        *([f"create_clock -name ingress_clk -period $clk_period [get_ports {block['ingress_clock_port']}]"]
          if block.get("ingress_clock_port") else []),
        *([f"set_clock_uncertainty -setup {block['clock_uncertainty_ns'] / view['time_unit_ns']:g} [get_clocks core_clk]"
           if block.get("clock_uncertainty_setup_only") else
           f"set_clock_uncertainty -setup {block['clock_uncertainty_ns'] / view['time_unit_ns']:g} [all_clocks]"
           if block.get("clock_uncertainty_hold_ns") is not None else
           f"set_clock_uncertainty {block['clock_uncertainty_ns'] / view['time_unit_ns']:g} [all_clocks]"]
          if block.get("clock_uncertainty_ns") is not None else []),
        *([f"set_clock_uncertainty -hold {block['clock_uncertainty_hold_ns'] / view['time_unit_ns']:g} [all_clocks]"]
          if block.get("clock_uncertainty_hold_ns") is not None else []),
        "set non_clock_inputs [all_inputs -no_clocks]",
        *([f"set core_inputs [get_ports {{{' '.join(block['core_input_ports'])}}}]"]
          if block.get("core_input_ports") else []),
        *([f"set ingress_inputs [get_ports {{{' '.join(block['ingress_input_ports'])}}}]"]
          if block.get("ingress_clock_port") else []),
        f"set_input_delay [expr $clk_period * {block.get('io_delay_fraction', 0.2):g}] -clock core_clk "
        f"${'core_inputs' if block.get('core_input_ports') else 'non_clock_inputs'}",
        *(
            [
                f"set_input_delay -min {block['core_input_delay_min_ns'] / view['time_unit_ns']:g} -clock core_clk "
                f"${'core_inputs' if block.get('core_input_ports') else 'non_clock_inputs'}",
                f"set_input_delay -max {block['core_input_delay_max_ns'] / view['time_unit_ns']:g} -clock core_clk "
                f"${'core_inputs' if block.get('core_input_ports') else 'non_clock_inputs'}",
            ] if "core_input_delay_min_ns" in block else []
        ),
        *(
            [
                f"set_input_delay -min {block['ingress_input_delay_min_ns'] / view['time_unit_ns']:g} -clock ingress_clk $ingress_inputs",
                f"set_input_delay -max {block['ingress_input_delay_max_ns'] / view['time_unit_ns']:g} -clock ingress_clk $ingress_inputs",
            ] if block.get("ingress_clock_port") else []
        ),
        f"set_output_delay [expr $clk_period * {block.get('io_delay_fraction', 0.2):g}] -clock core_clk [all_outputs]",
        *(
            [
                f"set_output_delay -min {block['output_delay_min_ns'] / view['time_unit_ns']:g} -clock core_clk [all_outputs]",
                f"set_output_delay -max {block['output_delay_max_ns'] / view['time_unit_ns']:g} -clock core_clk [all_outputs]",
            ] if "output_delay_min_ns" in block else []
        ),
        f"set_load {load_lib:g} [all_outputs]",
        *signal_integrity_sdc_lines(constraints),
        *(f"set_false_path -from [get_ports {port}]" for port in block["false_path_from_ports"]),
        *(["set_false_path -from $non_clock_inputs", "set_false_path -to [all_outputs]"]
          if block.get("false_path_io") else []),
        # --sdc-append: design-intent exceptions (e.g. a ping-pong macro's 2-cycle read), verbatim
        *block.get("extra_sdc_lines", []),
    ]
    return lines


def sdc_text(
    view: dict[str, Any],
    block: dict[str, Any],
    clock_period_ns: float,
    constraints: dict[str, Any] | None = None,
) -> str:
    return "\n".join(sdc_lines(view, block, clock_period_ns, constraints)) + "\n"


# --------------------------------------------------------------------------
# Stage: static timing
# --------------------------------------------------------------------------


def run_sta(
    view: dict[str, Any],
    corner: dict[str, Any],
    block: dict[str, Any],
    work: Path,
    netlist: Path,
    clock_period_ns: float,
    constraints: dict[str, Any] | None = None,
) -> dict[str, Any]:
    time_unit_ns = view["time_unit_ns"]
    period_lib = clock_period_ns / time_unit_ns

    sdc = work / "constraint.sdc"
    sdc.write_text(sdc_text(view, block, clock_period_ns, constraints), encoding="utf-8")

    script = work / "sta.tcl"
    script.write_text(
        "\n".join(
            [
                *(f"read_liberty {path}" for path in corner["liberty"]),
                f"read_verilog {netlist}",
                f"link_design {block['top']}",
                f"source {sdc}",
                'puts "OT_WNS [sta::worst_slack -max]"',
                'puts "OT_TNS [sta::total_negative_slack -max]"',
                'puts "OT_HOLD_WNS [sta::worst_slack -min]"',
                'puts "OT_SETUP_VIOL [llength [find_timing_paths -path_delay max -slack_max 0 -group_count 100000]]"',
                'puts "OT_HOLD_VIOL [llength [find_timing_paths -path_delay min -slack_max 0 -group_count 100000]]"',
                f"report_checks -path_delay max -digits 4 -group_count 1 > {work / 'setup_path.rpt'}",
                f"report_checks -path_delay min -digits 4 -group_count 1 > {work / 'hold_path.rpt'}",
                "exit",
                "",
            ]
        ),
        encoding="utf-8",
    )

    proc = run([str(STA), "-no_init", "-exit", str(script)], timeout=synth_timeout_seconds())
    require_success(proc, "OpenSTA")
    text = (proc.stdout or "") + (proc.stderr or "")
    (work / "sta.log").write_text(text, encoding="utf-8")

    def grab(tag: str) -> float:
        match = re.search(rf"^{tag}\s+(-?[0-9.eE+-]+)\s*$", text, re.M)
        if not match:
            raise FlowError(f"OpenSTA did not report {tag}")
        return float(match.group(1))

    wns_lib = grab("OT_WNS")
    tns_lib = grab("OT_TNS")
    hold_lib = grab("OT_HOLD_WNS")
    setup_viol = int(grab("OT_SETUP_VIOL"))
    hold_viol = int(grab("OT_HOLD_VIOL"))

    wns_ns = wns_lib * time_unit_ns
    critical_path_ns = clock_period_ns - wns_ns
    if critical_path_ns <= 0:
        raise FlowError("non-positive critical path; STA result is not usable")

    return {
        "clock_period_ns": clock_period_ns,
        "sdc_clock_period_library_units": period_lib,
        "library_time_unit_ns": time_unit_ns,
        "setup_wns_ns": wns_ns,
        "setup_tns_ns": tns_lib * time_unit_ns,
        "hold_wns_ns": hold_lib * time_unit_ns,
        "setup_violating_paths": setup_viol,
        "hold_violating_paths": hold_viol,
        "timing_met": wns_ns >= 0.0,
        "critical_path_ns": critical_path_ns,
        "fmax_hz": 1e9 / critical_path_ns,
        "fmax_definition": (
            "1 / (target clock period - setup WNS) at this target period.  Note "
            "the SDC derives input/output delay as 20% of the clock period, so "
            "for an I/O-bounded path this quantity varies with the target "
            "period; use fmax_search for a period-independent figure."
        ),
        "raw_library_units": {
            "setup_wns": wns_lib,
            "setup_tns": tns_lib,
            "hold_wns": hold_lib,
        },
    }


def search_fmax(
    view: dict[str, Any],
    corner: dict[str, Any],
    block: dict[str, Any],
    work: Path,
    netlist: Path,
    start_period_ns: float,
    tolerance: float = 0.001,
    max_iterations: int = 40,
    constraints: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Bisect the clock period for the shortest period that still meets setup.

    The mapped netlist is held fixed; only the SDC period is varied.  This is
    period-independent, unlike ``1 / (period - WNS)``, because the SDC scales
    input and output delay with the clock period.
    """
    evaluations: list[dict[str, float]] = []

    def wns_at(period_ns: float) -> float:
        stage = work / f"fmax_{period_ns:.6f}"
        stage.mkdir(parents=True, exist_ok=True)
        result = run_sta(view, corner, block, stage, netlist, period_ns, constraints)
        evaluations.append(
            {"clock_period_ns": period_ns, "setup_wns_ns": result["setup_wns_ns"]}
        )
        return result["setup_wns_ns"]

    # Establish a period that meets timing (hi) and one that does not (lo).
    hi = start_period_ns
    iterations = 0
    while wns_at(hi) < 0.0:
        hi *= 1.5
        iterations += 1
        if iterations > 20:
            raise FlowError("could not find a clock period that meets setup timing")
    lo = hi / 1.5 if iterations else hi / 2.0
    while wns_at(lo) >= 0.0:
        hi = lo
        lo /= 2.0
        iterations += 1
        if iterations > 40 or lo < 1e-4:
            break

    for _ in range(max_iterations):
        if (hi - lo) / hi <= tolerance:
            break
        mid = 0.5 * (lo + hi)
        if wns_at(mid) >= 0.0:
            hi = mid
        else:
            lo = mid

    return {
        "min_clock_period_ns": hi,
        "fmax_hz": 1e9 / hi,
        "method": (
            "bisection on the SDC clock period with the mapped netlist held "
            "fixed; reported period is the smallest evaluated period with "
            "setup WNS >= 0"
        ),
        "relative_tolerance": tolerance,
        "evaluations": len(evaluations),
        "search_trace": sorted(evaluations, key=lambda item: item["clock_period_ns"]),
    }


# --------------------------------------------------------------------------
# Stage: place-and-route via OpenROAD-flow-scripts
# --------------------------------------------------------------------------

PNR_ARTIFACTS_LIGHT = [
    "config.mk",
    "constraint.sdc",
    "io_constraints.tcl",
    "metadata.json",
    "1_2_yosys.v",
    "6_final.v",
    "6_finish.rpt",
    "5_route_drc.rpt",
]
PNR_ARTIFACTS_HEAVY = ["6_final.def", "6_final.gds", "6_final.odb", "6_final.spef"]

# Metrics whose metadata value is a time in the SDC/liberty time unit.
PNR_TIMING_METRICS_NS = {
    "setup_wns_ns",
    "setup_tns_ns",
    "hold_wns_ns",
    "hold_tns_ns",
}

PNR_METRIC_KEYS = {
    "setup_wns_ns": "finish__timing__setup__ws",
    "setup_tns_ns": "finish__timing__setup__tns",
    "setup_violations": "finish__timing__drv__setup_violation_count",
    "hold_wns_ns": "finish__timing__hold__ws",
    "hold_tns_ns": "finish__timing__hold__tns",
    "hold_violations": "finish__timing__drv__hold_violation_count",
    # Signal-integrity design-rule violations.  ORFS reports them beside the
    # timing ones and nothing read them, so an LQ8 route with 292 max-slew
    # violations was recorded closed=true (results/physical_abi3/asap7/
    # a3_lq8_array/pnr.json at 2f6b0a4).  A closed netlist has none.
    "max_slew_violations": "finish__timing__drv__max_slew",
    "max_cap_violations": "finish__timing__drv__max_cap",
    "max_fanout_violations": "finish__timing__drv__max_fanout",
    "fmax_hz": "finish__timing__fmax",
    "core_area_um2": "finish__design__core__area",
    "die_area_um2": "finish__design__die__area",
    "standard_cell_area_um2": "finish__design__instance__area__stdcell",
    "macro_area_um2": "finish__design__instance__area__macros",
    "sequential_area_um2": "finish__design__instance__area__class__sequential_cell",
    "instance_count": "finish__design__instance__count",
    "standard_cell_count": "finish__design__instance__count__stdcell",
    "macro_count": "finish__design__instance__count__macros",
    "sequential_cell_count": "finish__design__instance__count__class__sequential_cell",
    "utilization_fraction": "finish__design__instance__utilization",
    "routed_wirelength_um": "detailedroute__route__wirelength",
    "vias": "detailedroute__route__vias",
    "drc_errors": "detailedroute__route__drc_errors",
    "antenna_violating_nets": "detailedroute__antenna__violating__nets",
    "antenna_violating_pins": "detailedroute__antenna__violating__pins",
    "routed_nets": "detailedroute__route__net",
    "clock_count": "constraints__clocks__count",
    "power_total_w": "finish__power__total",
}


def conservative_fmax_metrics(raw: dict[str, Any], stage: str) -> dict[str, Any]:
    """Keep ORFS's aggregate Fmax, but use the slowest constrained clock.

    ORFS can report the fastest clock under ``<stage>__timing__fmax`` in a
    multi-clock design. A fast ingress clock must not hide a slower core.
    """
    key = f"{stage}__timing__fmax"
    clock_prefix = key + "__clock:"
    per_clock = {
        name[len(clock_prefix):]: float(value)
        for name, value in raw.items()
        if name.startswith(clock_prefix) and value is not None
        and math.isfinite(float(value)) and float(value) > 0
    }
    aggregate = float(raw[key]) if raw.get(key) is not None else None
    limiting = min(per_clock.values()) if per_clock else aggregate
    return {
        "fmax_hz": limiting,
        "per_clock_fmax_hz": per_clock,
        "orfs_aggregate_fmax_hz": aggregate,
        "fmax_basis": "minimum per-clock ORFS Fmax when available; aggregate otherwise",
    }


def orfs_identity() -> dict[str, Any]:
    proc = run(["docker", "image", "inspect", ORFS_IMAGE, "--format", "{{.Id}}"], timeout=300)
    require_success(proc, "docker image inspect")
    image_id = (proc.stdout or "").strip()
    proc = run(
        ["docker", "image", "inspect", ORFS_IMAGE, "--format", "{{json .RepoDigests}}"],
        timeout=300,
    )
    require_success(proc, "docker image inspect digests")
    digests = json.loads((proc.stdout or "[]").strip() or "[]")

    probe = run(
        [
            "docker", "run", "--rm", ORFS_IMAGE, "bash", "-lc",
            "source /OpenROAD-flow-scripts/env.sh >/dev/null 2>&1; "
            "echo OPENROAD $(openroad -version 2>&1 | head -1); "
            "echo YOSYS $(yosys -V 2>&1 | head -1); "
            "sha256sum $(command -v openroad) $(command -v yosys)",
        ],
        timeout=900,
    )
    require_success(probe, "ORFS toolchain probe")
    text = probe.stdout or ""
    openroad_version = ""
    yosys_version = ""
    for line in text.splitlines():
        if line.startswith("OPENROAD "):
            openroad_version = line[len("OPENROAD "):].strip()
        elif line.startswith("YOSYS "):
            yosys_version = line[len("YOSYS "):].strip()
    binaries = {}
    for line in text.splitlines():
        match = re.match(r"^([0-9a-f]{64})\s+(\S+)\s*$", line)
        if match:
            binaries[match.group(2)] = match.group(1)

    return {
        "image_reference": ORFS_IMAGE,
        "image_id": image_id,
        "image_id_matches_archived_asap7_lock": image_id == ORFS_EXPECTED_IMAGE_ID,
        "repo_digests": digests,
        "openroad_version": openroad_version,
        "yosys_version": yosys_version,
        "binary_sha256": binaries,
    }


def platform_file_hashes(platform_name: str) -> dict[str, str]:
    proc = run(
        [
            "docker", "run", "--rm", ORFS_IMAGE, "bash", "-lc",
            f"cd /OpenROAD-flow-scripts/flow/platforms/{platform_name} && "
            "find . -type f \\( -name '*.lib' -o -name '*.lib.gz' -o -name '*.lef' "
            "-o -name '*.tlef' -o -name 'config.mk' \\) -print0 | sort -z | xargs -0 sha256sum",
        ],
        timeout=1800,
    )
    require_success(proc, "ORFS platform hash probe")
    hashes: dict[str, str] = {}
    for line in (proc.stdout or "").splitlines():
        match = re.match(r"^([0-9a-f]{64})\s+\./(\S+)\s*$", line)
        if match:
            hashes[match.group(2)] = match.group(1)
    return hashes


# --------------------------------------------------------------------------
# Platform memory macros
# --------------------------------------------------------------------------
#
# Every routed record to date has macro_count 0: the driver could COUNT
# macros but had no way to SUPPLY one, so the memory system of gate G2
# (docs/OPENTALLAS_REDESIGN_PLAN.md) could not be in any netlist.  The pinned
# ORFS image ships compiled SRAM macros on ASAP7 with both an abstract LEF
# and an NLDM liberty view (docs/CHIP_ARCHITECTURE_DESIGN.md section 11.2);
# ``--memory-macro NAME`` names one of them.  The views are resolved inside
# the container, from the platform's own lef/ and lib/ directories -- nothing
# is copied into the design, so the macro identity is the platform's -- and
# reach the flow exactly the way ORFS's own macro-bearing designs get theirs
# (flow/designs/asap7/swerv_wrapper/config.mk):
#
#   ADDITIONAL_LEFS   the abstract the floorplanner, PDN and router place
#   ADDITIONAL_LIBS   the timing view; the platform config appends it to
#                     LIB_FILES, and scripts/synth_stdcells.tcl reads
#                     LIB_FILES with ``read_liberty -lib``, which is what
#                     makes the module a black box in Yosys and keeps the
#                     instance in 1_2_yosys.v instead of inferring flops
#   SYNTH_BLACKBOXES  scripts/synth_preamble.tcl blackboxes these module
#                     names after ``hierarchy -check``, so a behavioural
#                     body in the sources loses to the liberty view -- the
#                     mechanism the slang frontend applies automatically to
#                     every ADDITIONAL_LIBS cell
#
# Macro placement is the flow's own: scripts/macro_place_util.tcl runs
# rtl_macro_placer whenever the netlist holds macros, with the platform's
# MACRO_PLACE_HALO.  ``--macro-place-halo X Y`` overrides it; without the
# option nothing is emitted and the platform default stands, and either way
# the value and where it came from are recorded.
#
# Nothing here is emitted or recorded unless --memory-macro is given: a
# record without ``place_and_route.memory_macros`` was routed with exactly
# the config.mk every earlier record had.

ORFS_PLATFORMS_DIR = "/OpenROAD-flow-scripts/flow/platforms"

_MACRO_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.+-]*$")

# Runs INSIDE the pinned image: resolves each named macro to the platform's
# own LEF and liberty, hashes them, and reads back what the views declare.
_MACRO_PROBE = r'''
import glob, gzip, hashlib, json, os, re, sys

PLATFORMS = "/OpenROAD-flow-scripts/flow/platforms"


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_text(path):
    if path.endswith(".gz"):
        with gzip.open(path, "rt", errors="ignore") as handle:
            return handle.read()
    with open(path, errors="ignore") as handle:
        return handle.read()


def find(root, pattern):
    return sorted(
        p for p in glob.glob(os.path.join(root, "**", pattern), recursive=True)
        if os.path.isfile(p)
    )


def view_entry(path):
    return {"path": path, "sha256": sha256(path), "size_bytes": os.path.getsize(path)}


def number(text):
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


platform = sys.argv[1]
names = sys.argv[2:]
root = os.path.join(PLATFORMS, platform)
out = {"platform": platform, "platform_dir": root, "macros": [], "error": None}
if not os.path.isdir(root):
    out["error"] = "no such platform directory: " + root
    print(json.dumps(out, sort_keys=True))
    raise SystemExit(0)

config_mk = os.path.join(root, "config.mk")
config_text = read_text(config_mk) if os.path.isfile(config_mk) else ""
halo = re.search(r"^\s*export\s+MACRO_PLACE_HALO\s*\??=\s*(\S+)\s+(\S+)\s*$", config_text, re.M)
out["platform_macro_place_halo"] = [halo.group(1), halo.group(2)] if halo else None
out["platform_macro_place_halo_line"] = halo.group(0).strip() if halo else None

# What this platform offers: every LEF whose stem also has a liberty view.
offered = []
for lef in find(root, "*.lef"):
    stem = os.path.basename(lef)[: -len(".lef")]
    if find(root, stem + ".lib") or find(root, stem + ".lib.gz"):
        offered.append(stem)
out["macros_with_lef_and_lib"] = sorted(set(offered))

for name in names:
    entry = {"name": name}
    lefs = find(root, name + ".lef")
    libs = find(root, name + ".lib") + find(root, name + ".lib.gz")
    if not lefs:
        entry["error"] = "no %s.lef under %s" % (name, root)
        out["macros"].append(entry)
        continue
    if not libs:
        entry["error"] = "no %s.lib (or .lib.gz) under %s" % (name, root)
        out["macros"].append(entry)
        continue
    entry["lef"] = view_entry(lefs[0])
    entry["lib"] = view_entry(libs[0])
    if len(lefs) > 1:
        entry["lef"]["other_candidates"] = lefs[1:]
    if len(libs) > 1:
        entry["lib"]["other_candidates"] = libs[1:]

    lef_text = read_text(lefs[0])
    block = re.search(
        r"^MACRO\s+" + re.escape(name) + r"\s*$(.*?)^END\s+" + re.escape(name) + r"\s*$",
        lef_text,
        re.M | re.S,
    )
    body = block.group(1) if block else ""
    entry["lef_macro_found"] = bool(block)
    size = re.search(r"^\s*SIZE\s+([0-9.]+)\s+BY\s+([0-9.]+)\s*;", body, re.M)
    entry["width_um"] = number(size.group(1)) if size else None
    entry["height_um"] = number(size.group(2)) if size else None
    klass = re.search(r"^\s*CLASS\s+(\S+)\s*;", body, re.M)
    entry["lef_class"] = klass.group(1) if klass else None
    for prop in ("width", "depth", "banks"):
        found = re.search(r"^\s*PROPERTY\s+" + prop + r"\s+([0-9]+)\s*;", body, re.M)
        entry["lef_property_" + prop] = int(found.group(1)) if found else None
    pins = re.findall(r"^\s*PIN\s+(\S+)\s*$", body, re.M)
    power = re.findall(r"^\s*USE\s+(POWER|GROUND)\s*;", body, re.M)
    entry["pin_count"] = len(pins)
    entry["power_pin_count"] = len(power)
    entry["signal_pin_count"] = len(pins) - len(power)

    lib_text = read_text(libs[0])
    cell = re.search(r"^\s*cell\s*\(\s*\"?([A-Za-z0-9_./\[\]-]+)\"?\s*\)\s*\{", lib_text, re.M)
    entry["liberty_cell"] = cell.group(1) if cell else None
    for key, pattern in (
        ("liberty_area", r"^\s*area\s*:\s*([0-9.eE+-]+)\s*;"),
        ("liberty_min_period", r"^\s*min_period\s*:\s*([0-9.eE+-]+)\s*;"),
    ):
        found = re.search(pattern, lib_text, re.M)
        entry[key] = number(found.group(1)) if found else None
    for key, pattern in (
        ("liberty_address_width", r"^\s*address_width\s*:\s*([0-9]+)\s*;"),
        ("liberty_word_width", r"^\s*word_width\s*:\s*([0-9]+)\s*;"),
    ):
        found = re.search(pattern, lib_text, re.M)
        entry[key] = int(found.group(1)) if found else None
    unit = re.search(r"^\s*time_unit\s*:\s*\"([^\"]+)\"\s*;", lib_text, re.M)
    entry["liberty_time_unit"] = unit.group(1) if unit else None
    unit = re.search(r"^\s*capacitive_load_unit\s*\(([^)]*)\)", lib_text, re.M)
    entry["liberty_capacitive_load_unit"] = unit.group(1).strip() if unit else None
    out["macros"].append(entry)

print(json.dumps(out, sort_keys=True))
'''

_LIBERTY_TIME_UNIT_NS = {"1ns": 1.0, "1ps": 0.001, "1us": 1000.0, "1fs": 1e-6}


def probe_platform_macros(platform_name: str, names: list[str]) -> dict[str, Any]:
    """Ask the pinned image what the platform's own views of these macros are."""
    proc = run(
        ["docker", "run", "--rm", ORFS_IMAGE, "python3", "-c", _MACRO_PROBE,
         platform_name, *names],
        timeout=1800,
    )
    require_success(proc, "ORFS platform macro probe")
    try:
        return json.loads((proc.stdout or "").strip())
    except json.JSONDecodeError as exc:
        raise FlowError(f"unreadable macro probe output: {exc}: {(proc.stdout or '')[:500]}") from exc


def macro_capacity(entry: dict[str, Any]) -> tuple[int | None, str]:
    """Bits the macro holds, and where that number came from."""
    depth = entry.get("lef_property_depth")
    width = entry.get("lef_property_width")
    if depth and width:
        return depth * width, "LEF PROPERTY depth x width"
    address_width = entry.get("liberty_address_width")
    word_width = entry.get("liberty_word_width")
    if address_width and word_width:
        return (1 << address_width) * word_width, (
            "liberty memory(): 2^address_width x word_width (the LEF declares no "
            "depth/width property)"
        )
    return None, "neither the LEF properties nor the liberty memory() group declares a size"


def resolve_memory_macros(
    view_name: str,
    view: dict[str, Any],
    names: list[str],
    halo: list[float] | None,
) -> dict[str, Any] | None:
    """Resolve --memory-macro / --macro-place-halo into the recorded macro block.

    Returns ``None`` when no macro was named, so the config.mk and the record
    are exactly what they were before the option existed.
    """
    if not names:
        if halo is not None:
            raise FlowError("--macro-place-halo needs --memory-macro; it places nothing on its own")
        return None
    pnr = view.get("pnr")
    if not pnr:
        raise FlowError(f"view {view_name} has no place-and-route platform, so it has no macros")
    for name in names:
        if not _MACRO_NAME_RE.match(name):
            raise FlowError(f"not a platform macro name: {name!r}")
    ordered: list[str] = []
    for name in names:
        if name not in ordered:
            ordered.append(name)

    platform_name = pnr["platform"]
    probe = probe_platform_macros(platform_name, ordered)
    if probe.get("error"):
        raise FlowError(f"macro probe on platform {platform_name}: {probe['error']}")
    found = {entry["name"]: entry for entry in probe["macros"]}
    unresolved = [entry for entry in probe["macros"] if entry.get("error")]
    if unresolved:
        offered = probe.get("macros_with_lef_and_lib") or []
        raise FlowError(
            "; ".join(f"{entry['name']}: {entry['error']}" for entry in unresolved)
            + f".  Platform {platform_name} offers, with both LEF and liberty: "
            + (", ".join(offered) if offered else "no macro at all")
        )

    view_time_unit_ns = view["time_unit_ns"]
    macros: list[dict[str, Any]] = []
    for name in ordered:
        entry = found[name]
        bits, bits_source = macro_capacity(entry)
        width = entry.get("width_um")
        height = entry.get("height_um")
        liberty_unit = entry.get("liberty_time_unit")
        unit_ns = _LIBERTY_TIME_UNIT_NS.get(str(liberty_unit))
        macros.append(
            {
                "name": name,
                "lef": entry["lef"],
                "lib": entry["lib"],
                "views_resolved_from": (
                    f"the platform's own directories inside {ORFS_IMAGE} "
                    f"({probe['platform_dir']}); no view is copied into the design"
                ),
                "capacity_bits": bits,
                "capacity_bytes": None if bits is None else bits / 8.0,
                "capacity_source": bits_source,
                "words": entry.get("lef_property_depth"),
                "bits_per_word": entry.get("lef_property_width"),
                "banks": entry.get("lef_property_banks"),
                "footprint": {
                    "width_um": width,
                    "height_um": height,
                    "area_um2": None if width is None or height is None else round(width * height, 6),
                    "source": "LEF SIZE of the macro's own abstract",
                },
                "lef_class": entry.get("lef_class"),
                "pin_count": entry.get("pin_count"),
                "signal_pin_count": entry.get("signal_pin_count"),
                "power_pin_count": entry.get("power_pin_count"),
                "liberty": {
                    "cell": entry.get("liberty_cell"),
                    "area": entry.get("liberty_area"),
                    "min_period_library_units": entry.get("liberty_min_period"),
                    "address_width": entry.get("liberty_address_width"),
                    "word_width": entry.get("liberty_word_width"),
                    "time_unit": liberty_unit,
                    "time_unit_ns": unit_ns,
                    "capacitive_load_unit": entry.get("liberty_capacitive_load_unit"),
                    "time_unit_matches_standard_cells": (
                        None if unit_ns is None else unit_ns == view_time_unit_ns
                    ),
                    "unit_note": (
                        "the macro liberty declares its own units; the SDC and every "
                        "reported time stay in the standard cells' unit "
                        f"({view_time_unit_ns} ns), which is read first"
                    ),
                },
            }
        )

    if halo is not None:
        halo_x, halo_y = float(halo[0]), float(halo[1])
        if halo_x < 0 or halo_y < 0:
            raise FlowError(f"--macro-place-halo must not be negative, got {halo_x} {halo_y}")
        halo_source = "command line"
        emitted = True
    else:
        declared = probe.get("platform_macro_place_halo")
        if not declared:
            raise FlowError(
                f"platform {platform_name} declares no MACRO_PLACE_HALO and none was "
                "given; pass --macro-place-halo X Y"
            )
        halo_x, halo_y = float(declared[0]), float(declared[1])
        halo_source = (
            f"platform default: platforms/{platform_name}/config.mk "
            f"{probe.get('platform_macro_place_halo_line')}"
        )
        emitted = False

    block: dict[str, Any] = {
        "platform": platform_name,
        "requested": list(names),
        "macros": macros,
        "additional_lefs": [entry["lef"]["path"] for entry in macros],
        "additional_libs": [entry["lib"]["path"] for entry in macros],
        "synth_blackboxes": [entry["name"] for entry in macros],
        "synth_blackbox_basis": (
            "ORFS scripts/synth_preamble.tcl blackboxes SYNTH_BLACKBOXES module names "
            "after hierarchy -check, so the liberty view read from ADDITIONAL_LIBS by "
            "scripts/synth_stdcells.tcl (read_liberty -lib) is what survives into "
            "1_2_yosys.v -- the mechanism ORFS's own macro-bearing designs use"
        ),
        "capacity_bits_total": (
            None
            if any(entry["capacity_bits"] is None for entry in macros)
            else sum(entry["capacity_bits"] for entry in macros)
        ),
        "footprint_area_um2_total": (
            None
            if any(entry["footprint"]["area_um2"] is None for entry in macros)
            else round(sum(entry["footprint"]["area_um2"] for entry in macros), 6)
        ),
        "macro_place_halo": {
            "x_um": halo_x,
            "y_um": halo_y,
            "source": halo_source,
            "emitted_in_config": emitted,
            "used_by": (
                "ORFS scripts/macro_place_util.tcl: rtl_macro_placer -halo_width "
                "-halo_height, run automatically whenever the netlist holds macros"
            ),
        },
        "counts_are_per_macro_type": (
            "one entry per named macro TYPE; how many instances the netlist holds is "
            "place_and_route.metrics.macro_count, which the flow reports"
        ),
        "basis": (
            "the platform memory macros this route was given, resolved inside the "
            "pinned image from the platform's own lef/ and lib/ directories; absent "
            "from a record means no ADDITIONAL_LEFS, ADDITIONAL_LIBS or "
            "SYNTH_BLACKBOXES were emitted and the config.mk is the one every "
            "earlier record had"
        ),
    }
    block["config_lines"] = memory_macro_config_lines(block)
    return block


def memory_macro_config_lines(macros: dict[str, Any] | None) -> list[str]:
    """The ADDITIONAL_LEFS / ADDITIONAL_LIBS / SYNTH_BLACKBOXES lines, or none."""
    if not macros:
        return []
    lines = [
        "export ADDITIONAL_LEFS = " + " ".join(macros["additional_lefs"]),
        "export ADDITIONAL_LIBS = " + " ".join(macros["additional_libs"]),
        "export SYNTH_BLACKBOXES = " + " ".join(macros["synth_blackboxes"]),
    ]
    halo = macros.get("macro_place_halo") or {}
    if halo.get("emitted_in_config"):
        lines.append(f"export MACRO_PLACE_HALO = {halo['x_um']:g} {halo['y_um']:g}")
    if macros.get("gds_allow_empty"):
        lines.append(f"export GDS_ALLOW_EMPTY = {macros['gds_allow_empty']}")
    return lines


def resolve_macro_views(
    view_name: str,
    view: dict[str, Any],
    specs: list[str],
    halo: list[float] | None,
    memory_macros: dict[str, Any] | None,
    corners: list[str] | None = None,
) -> dict[str, Any] | None:
    """Resolve --macro-view NAME=DIR: a macro compiled by tools/mem_compiler.

    DIR (relative to the source tree) holds ``NAME.lef`` and ``NAME_<corner>.lib``
    written by ``tools/mem_compiler/{sram,rom}_gen.py``; the flow reads them from
    the read-only ``/src`` mount, so the record's source identity covers them.
    The views are abstracts with no GDS, so the macro names are added to
    GDS_ALLOW_EMPTY exactly as the platform does for its own fakeram macros.
    Merged into the --memory-macro block when both are given.
    """
    if not specs:
        return memory_macros
    pnr = view.get("pnr")
    if not pnr:
        raise FlowError(f"view {view_name} has no place-and-route platform")
    corner = pnr.get("corner_env") or "TC"
    corner_tag = ORFS_CORNER_MACRO_TAG.get(str(corner).upper()) or \
        {"TT": "tt", "SS": "ss", "FF": "ff"}.get(str(corner).upper(), "tt")
    # every ORFS corner the run reads (primary + --hold-corners) needs the macro's own liberty of that corner;
    # a missing one FAILS CLOSED (no silent fallback to another corner's timing)
    all_corners = [str(corner).upper()] + [c for c in (corners or []) if c != str(corner).upper()]
    entries = []
    for spec in specs:
        if "=" not in spec:
            raise FlowError(f"--macro-view expects NAME=DIR, got {spec!r}")
        name, rel = spec.split("=", 1)
        if not _MACRO_NAME_RE.match(name):
            raise FlowError(f"not a macro name: {name!r}")
        base = (ROOT / rel).resolve()
        lef = base / f"{name}.lef"
        lib = base / f"{name}_{corner_tag}.lib"
        sheet_path = base / f"{name}.json"
        for path in (lef, lib):
            if not path.is_file():
                raise FlowError(f"--macro-view {name}: {path} missing; run tools/mem_compiler/build_library.py")
        libs_by_corner = {}
        for c in all_corners:
            tag = ORFS_CORNER_MACRO_TAG.get(c)
            if tag is None:
                continue
            cl = base / f"{name}_{tag}.lib"
            if not cl.is_file():
                raise FlowError(f"--macro-view {name}: no {tag.upper()} liberty for ORFS corner {c} ({cl}); "
                                "refusing to time the macro with another corner's view")
            libs_by_corner[c] = cl
        try:
            rel_lef = lef.relative_to(ROOT.resolve())
            rel_lib = lib.relative_to(ROOT.resolve())
        except ValueError as exc:
            raise FlowError(f"--macro-view {name}: views must live inside the source tree") from exc
        sheet = json.loads(sheet_path.read_text()) if sheet_path.is_file() else {}
        area = sheet.get("area", {})
        spec_rec = sheet.get("spec", {})
        bits = sheet.get("capacity_bits")
        entries.append({
            "name": name,
            "lef": {"path": f"/src/{rel_lef}", "sha256": sha256_file(lef)},
            "lib": {"path": f"/src/{rel_lib}", "sha256": sha256_file(lib)},
            "libs_by_corner": {c: {"path": f"/src/{cl.resolve().relative_to(ROOT.resolve())}",
                                   "sha256": sha256_file(cl)} for c, cl in libs_by_corner.items()},
            "views_resolved_from": "OpenTallas memory compiler views in the source tree (tools/mem_compiler)",
            "generator": sheet.get("generator"),
            "capacity_bits": bits,
            "capacity_bytes": None if bits is None else bits / 8.0,
            "capacity_source": "compiler datasheet",
            "words": spec_rec.get("words"),
            "bits_per_word": spec_rec.get("bits"),
            "banks": spec_rec.get("banks", 1),
            "footprint": {"width_um": area.get("macro_width_um"), "height_um": area.get("macro_height_um"),
                          "area_um2": area.get("macro_area_um2"), "source": "LEF SIZE (compiler datasheet)"},
            "liberty": {"corner": corner_tag, "time_unit": "1ps", "time_unit_ns": 0.001,
                        "time_unit_matches_standard_cells": view.get("time_unit_ns") == 0.001},
        })
    block = memory_macros
    if block is None:
        if halo is None:
            raise FlowError("--macro-view needs --macro-place-halo X Y (the compiler macros declare none)")
        block = {
            "platform": pnr["platform"], "requested": [], "macros": [], "additional_lefs": [],
            "additional_libs": [], "synth_blackboxes": [],
            "macro_place_halo": {"x_um": float(halo[0]), "y_um": float(halo[1]), "source": "command line",
                                 "emitted_in_config": True,
                                 "used_by": "ORFS scripts/macro_place_util.tcl"},
            "basis": "memory-compiler macros given by --macro-view",
        }
    block["requested"] = list(block.get("requested", [])) + list(specs)
    block["macros"] = list(block["macros"]) + entries
    block["additional_lefs"] = list(block["additional_lefs"]) + [e["lef"]["path"] for e in entries]
    block["additional_libs"] = list(block["additional_libs"]) + [e["lib"]["path"] for e in entries]
    block["synth_blackboxes"] = list(block["synth_blackboxes"]) + [e["name"] for e in entries]
    names = "|".join(re.escape(e["name"]) for e in entries)
    block["gds_allow_empty"] = f"(fakeram.*|{names})"
    block["capacity_bits_total"] = sum((e["capacity_bits"] or 0) for e in block["macros"])
    block["footprint_area_um2_total"] = round(sum((e["footprint"]["area_um2"] or 0) for e in block["macros"]), 6)
    block["config_lines"] = memory_macro_config_lines(block)
    return block


# Floorplan geometry, pin edges and routing layers.
#
# Every route so far is a square core sized by utilisation with the pins left
# to the IO placer, which is right for a block and wrong for a WIRE: to measure
# what a long repeated link costs, the die has to be long and thin and the two
# ends of the link have to be pinned to opposite edges, so the routed wire
# really spans a known distance.  ``--die-area``/``--core-area`` hand ORFS an
# explicit DIE_AREA/CORE_AREA (in place of CORE_UTILIZATION), ``--pin-region
# REGEX=EDGE`` writes an IO_CONSTRAINTS file that pins every port whose name
# matches REGEX to that die edge, and ``--routing-layers MIN MAX`` overrides the
# platform's MIN/MAX_ROUTING_LAYER.  Without any of them nothing is emitted and
# the config.mk is byte-for-byte what it was.

PIN_EDGES = ("left", "right", "top", "bottom")
PIN_EDGE_REGION_RE = re.compile(
    r"^(left|right|top|bottom)(?::([0-9]+(?:\.[0-9]+)?)-([0-9]+(?:\.[0-9]+)?))?$"
)


def floorplan_size_lines(core_utilization: int, floorplan: dict[str, Any] | None) -> list[str]:
    if floorplan and floorplan.get("die_area_um"):
        return [
            "export DIE_AREA = " + " ".join(f"{v:g}" for v in floorplan["die_area_um"]),
            "export CORE_AREA = " + " ".join(f"{v:g}" for v in floorplan["core_area_um"]),
        ]
    return [
        f"export CORE_UTILIZATION = {core_utilization}",
        "export CORE_ASPECT_RATIO = 1",
        "export CORE_MARGIN = 2",
    ]


def floorplan_extra_lines(floorplan: dict[str, Any] | None) -> list[str]:
    if not floorplan:
        return []
    lines = []
    if floorplan.get("pin_regions"):
        lines.append("export IO_CONSTRAINTS = /work/io_constraints.tcl")
    if floorplan.get("routing_layers"):
        low, high = floorplan["routing_layers"]
        lines.append(f"export MIN_ROUTING_LAYER = {low}")
        lines.append(f"export MAX_ROUTING_LAYER = {high}")
    for hook in floorplan.get("step_tcl", []):
        lines.append(f"export {hook['hook']}_TCL = /work/hooks/{hook['name']}")
    return lines


def ot_tt_lib_override(config: list[str]) -> list[str]:
    """LOOP-LVT (2026-10-10): option B makes corner WC read TT via `export WC_NLDM_LIB_FILES = $(TC_NLDM_LIB_FILES)`,
    but the asap7 platform config.mk (included AFTER the design config) then appends every OTHER_VT's libraries with
    `WC_NLDM_LIB_FILES += $(subst PLACEHOLDER,<vt>,$(WC_NLDM_LIB_FILES_T))` -- the SS template -- so an
    ASAP7_USE_VT='RVT LVT[ SLVT]' route repaired setup against LVT/SLVT SS cells.  The template cannot be overridden
    from the design config (the platform re-assigns it); `override` makes the platform's later `+=` a no-op, and
    $(TC_NLDM_LIB_FILES) already holds every VT's TT libraries.  RVT-only routes: same value, unchanged."""
    return [("override " + line) if re.fullmatch(r"export WC_NLDM_LIB_FILES\s*=\s*\$\(TC_NLDM_LIB_FILES\)\s*", line)
            else line for line in config]


def apply_cts_fix_hooks(config: list[str], case: Path) -> list[str]:
    """Opt-in flow fixes chained after the block's own PRE_CTS hook (setup-triage 2026-10-07).

    OT_CTS_FIX_HOOKS = space-separated Tcl files (repo-relative or absolute).  When set, PRE_CTS_TCL becomes
    hooks/pre_cts_ot_cts_fix.tcl, which sources the block's own PRE_CTS hook (if any) and then each fix, in order;
    every fix's sha256 is written to hooks/ot_cts_fix.json.  Unset: config unchanged (byte-identical).
    """
    fixes = os.environ.get("OT_CTS_FIX_HOOKS", "").split()
    if not fixes:
        return config
    hooks_dir = case / "hooks"
    hooks_dir.mkdir(exist_ok=True)
    orig = None
    kept = []
    for line in config:
        m = re.match(r"\s*export\s+PRE_CTS_TCL\s*=\s*(.*)$", line)
        if m:
            orig = m.group(1).strip()
            continue
        kept.append(line)
    body = ["# Written by tools/run_abi3_physical.py (OT_CTS_FIX_HOOKS)."]
    # Hook knobs exported in the job shell (OT_SPINE_PORT=clk, ...) never reached the ORFS container: the hooks read
    # ::env, which only carries config.mk exports, so clock_spine.tcl fell back to ck[0] and was SKIPPED (hgi-idx-topk
    # w8c-a/b-fa1bc12bc ran plain TritonCTS, TT -1,913).  Forward every OT_SPINE_* / OT_CG_* knob into the hook; an
    # explicit --orfs-var of the same name (already in ::env) wins.
    knobs = sorted(k for k in os.environ if re.match(r"OT_(SPINE|CG)_[A-Z0-9_]+$", k))
    for k in knobs:
        v = os.environ[k].replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}")
        body.append(f"if {{![info exists ::env({k})] || $::env({k}) eq \"\"}} {{ set ::env({k}) {{{v}}} }}")
    if orig:
        body.append(f"source {orig}")
    record = []
    for i, fix in enumerate(fixes):
        source = Path(fix)
        if not source.is_absolute():
            source = ROOT / source
        if not source.is_file():
            raise ValueError(f"OT_CTS_FIX_HOOKS: no such file {source}")
        name = f"ot_cts_fix_{i}_{source.name}"
        shutil.copy2(source, hooks_dir / name)
        body.append(f"source /work/hooks/{name}")
        record.append({"path": fix, "name": name, "sha256": sha256_file(source)})
    (hooks_dir / "pre_cts_ot_cts_fix.tcl").write_text("\n".join(body) + "\n", encoding="utf-8")
    (hooks_dir / "ot_cts_fix.json").write_text(json.dumps({"pre_cts_orig": orig, "fixes": record, "env_knobs": {k: os.environ[k] for k in knobs}}, indent=1) + "\n",
                                               encoding="utf-8")
    kept.append("export PRE_CTS_TCL = /work/hooks/pre_cts_ot_cts_fix.tcl")
    return kept


GRT183_HOOK = "physical/common_flow/grt183_resume.tcl"


def apply_grt183_hook(config: list[str], case: Path) -> list[str]:
    """GRT183-RESUME (ROOT 2026-10-15; physical/common_flow/grt183_resume.tcl): PRE_GLOBAL_ROUTE_TCL becomes
    hooks/pre_grt_ot_grt183.tcl, which sources the block's own PRE_GLOBAL_ROUTE hook (if any) and then the resume hook.
    Inert unless an incremental GRT-0183 kills stage 5_1_grt (see orfs_make).  OT_GRT183_RESUME=0 opts out."""
    if os.environ.get("OT_GRT183_RESUME", "1") == "0" or not (ROOT / GRT183_HOOK).is_file():
        return config
    hooks_dir = case / "hooks"
    hooks_dir.mkdir(exist_ok=True)
    orig, kept = None, []
    for line in config:
        m = re.match(r"\s*export\s+PRE_GLOBAL_ROUTE_TCL\s*=\s*(.*)$", line)
        if m:
            orig = m.group(1).strip()
            continue
        kept.append(line)
    if orig == "/work/hooks/pre_grt_ot_grt183.tcl":     # already applied (a re-generated config): never chain to itself
        return config
    shutil.copy2(ROOT / GRT183_HOOK, hooks_dir / "ot_grt183_resume.tcl")
    body = ["# Written by tools/run_abi3_physical.py (GRT183-RESUME): resume hook first (records the stage's input "
            "obstructions), then the block's own hook.", "source /work/hooks/ot_grt183_resume.tcl"]
    if orig:
        body.append(f"source {orig}")
    (hooks_dir / "pre_grt_ot_grt183.tcl").write_text("\n".join(body) + "\n", encoding="utf-8")
    kept.append("export PRE_GLOBAL_ROUTE_TCL = /work/hooks/pre_grt_ot_grt183.tcl")
    return kept


def _grt183_copy(src: Path, dst: Path) -> None:
    """copy2 into a fresh file renamed over dst: ORFS outputs are root-owned (docker), so utime on them fails."""
    tmp = dst.with_name(dst.name + ".grt183.tmp")
    shutil.copy2(src, tmp)
    os.replace(tmp, dst)


def grt183_resume_prepare(results_dir: Path, logs_dir: Path, case: Path, log_name: str) -> dict | None:
    """After a failed ORFS make: if stage 5_1_grt saved a GRT183 resume design (and no resume was used yet), stage it
    as the 5_1_grt input for ONE fresh-process re-run.  The original 4_cts.odb is kept aside (restored afterwards by
    grt183_resume_restore); the failed attempt's logs are kept.  Returns the receipt, or None when not applicable."""
    resume = results_dir / "5_1_grt.grt183_resume.odb"
    marker = results_dir / "5_1_grt.grt183_recovered.json"
    log = logs_dir / "5_1_grt.log"
    if marker.exists() or not resume.is_file() or not log.is_file():
        return None
    text = log.read_text(encoding="utf-8", errors="replace")
    if "OT_GRT183_RESUME_SAVED" not in text or "GRT-0183" not in text:
        return None
    cts = results_dir / "4_cts.odb"
    kept_cts = results_dir / "4_cts.pre_grt183.odb"
    _grt183_copy(cts, kept_cts)
    _grt183_copy(log, logs_dir / "5_1_grt.grt183_attempt1.log")
    if (case / log_name).is_file():
        _grt183_copy(case / log_name, case / (log_name + ".grt183_attempt1"))
    failed = [ln for ln in text.splitlines() if "GRT-0183" in ln or "OT_GRT183_RESUME_SAVED" in ln][:6]
    receipt = {
        "schema": "opentallas.grt183_resume.v1",
        "reason": "incremental GRT-0183 inside 5_1_grt repair; same-process recovery is unsafe (measured), so stage "
                  "5_1_grt re-runs once in a fresh process from the saved resized design with every repair re-run",
        "attempt1_log": "logs/5_1_grt.grt183_attempt1.log",
        "attempt1_lines": failed,
        "cts_odb_sha256": sha256_file(cts),
        "resume_odb_sha256": sha256_file(resume),
    }
    _grt183_copy(resume, cts)
    marker.write_text(json.dumps(receipt, indent=1) + "\n", encoding="utf-8")
    print("GRT183-RESUME: " + json.dumps({k: receipt[k] for k in ("cts_odb_sha256", "resume_odb_sha256")}),
          file=sys.stderr)
    return receipt


def grt183_resume_restore(results_dir: Path) -> None:
    """Put the original CTS database back (4_cts.odb readers downstream see the real CTS result)."""
    kept_cts = results_dir / "4_cts.pre_grt183.odb"
    if kept_cts.is_file():
        _grt183_copy(kept_cts, results_dir / "4_cts.odb")
        kept_cts.unlink()


def io_constraints_tcl(pin_regions: list[dict[str, str]], exhaustive: bool = False,
                       die_area_um: list[float] | None = None) -> str:
    """set_io_pin_constraint per region; ports are matched by Tcl regexp on the
    block's own terminal names, so a bus is pinned bit by bit, in order.
    OT_PIN_GROUP_MAX optionally bounds each ordered group; every chunk keeps
    the original region. Zero (default) retains the original single group.
    OT_PIN_BALANCE_H/V optionally fixes uniformly spaced pins across the
    named edge layers, alternating groups, to bound per-layer density.

    exhaustive (--pin-regions-exhaustive): before any constraint, every signal
    terminal must match EXACTLY ONE region regex, else the floorplan errors out.
    A prefix written '^(x_|go)(\\[|$)' matches only a port named 'x_', so the
    x_* bus went unconstrained while 'go' kept the region non-empty."""
    # BUS-AWARE (drive-1010 2026-10-10): a regex written for a bus BASE name ('^(a|b)$') silently missed every bit
    # 'a[3]' -- ot_gpu_rf_visibility_fence_p left 4,105 pins without a face.  A pattern now matches a terminal when it
    # matches its full name OR its bus base name (trailing [n] stripped; a scalar and a bus can never share a base),
    # and every pin-region run checks that no bus is left partly assigned (ot_check_bus_complete, always on).
    # ESCAPED BITS (hgi-1010 2026-10-11): a netlist whose top ports were bit-blasted to escaped scalars
    # ('\\out_data[5] ', the W11 endpoint netlist) loads into odb as the terminal name 'out_data\\[5\\]' (OpenROAD
    # keeps the escape on the brackets; PPL prints 'in_data\\[997\\]').  Neither the full name nor ot_pin_base (whose
    # '[n]$' needs a bare ']') then matched a bit-indexed region such as '^(out_data\\[(...)\\])$', so
    # w2-rb-safe-no3-nesw-43c045555 failed 'matches no port', and ot_check_bus_complete skipped every such bus.  Names
    # are now compared in their plain bus spelling (ot_pin_plain); the escaped odb name is still what is placed.
    lines = [
        "# Written by tools/run_abi3_physical.py --pin-region.",
        "proc ot_pin_plain {name} { return [string map {\\\\\\[ \\[ \\\\\\] \\]} $name] }",
        "proc ot_pin_base {name} { regsub {\\[[0-9]+\\]$} [ot_pin_plain $name] {} base; return $base }",
        "proc ot_pin_matches {pattern name} {",
        "  return [expr {[regexp -- $pattern $name] || [regexp -- $pattern [ot_pin_plain $name]] ||",
        "                [regexp -- $pattern [ot_pin_base $name]]}]",
        "}",
        "proc ot_match_pins {pattern} {",
        "  set names {}",
        "  foreach bterm [[ord::get_db_block] getBTerms] {",
        "    set name [$bterm getName]",
        "    if {[ot_pin_matches $pattern $name]} { lappend names $name }",
        "  }",
        "  if {[llength $names] == 0} { error \"--pin-region $pattern matches no port\" }",
        "  return [lsort -dictionary $names]",
        "}",
        "proc ot_check_bus_complete {patterns} {",
        "  array set hit {}; array set all {}",
        "  foreach bterm [[ord::get_db_block] getBTerms] {",
        "    if {[lsearch -exact {POWER GROUND} [$bterm getSigType]] >= 0} { continue }",
        "    set name [$bterm getName]",
        "    set base [ot_pin_base $name]",
        "    if {$base eq [ot_pin_plain $name]} { continue }",
        "    incr all($base)",
        "    foreach p $patterns { if {[ot_pin_matches $p $name]} { incr hit($base); break } }",
        "  }",
        "  set bad {}",
        "  foreach base [array names hit] { if {$hit($base) != $all($base)} { lappend bad \"$base:$hit($base)/$all($base)\" } }",
        "  if {[llength $bad] > 0} {",
        "    error \"--pin-region leaves bus bits unassigned (bus:assigned/bits): [lrange [lsort $bad] 0 23]\"",
        "  }",
        "}",
        "ot_check_bus_complete [list " + " ".join("{" + r["regex"] + "}" for r in pin_regions) + "]",
    ]
    if exhaustive:
        pats = " ".join("{" + r["regex"] + "}" for r in pin_regions)
        lines += [
            "proc ot_check_pin_regions {patterns} {",
            "  set bad {}",
            "  foreach bterm [[ord::get_db_block] getBTerms] {",
            "    if {[lsearch -exact {POWER GROUND} [$bterm getSigType]] >= 0} { continue }",
            "    set name [$bterm getName]",
            "    set n 0",
            "    foreach p $patterns { if {[ot_pin_matches $p $name]} { incr n } }",
            "    if {$n != 1} { lappend bad \"$name:$n\" }",
            "  }",
            "  if {[llength $bad] > 0} {",
            "    error \"--pin-regions-exhaustive: [llength $bad] ports match no region or more than one (port:matches): [lrange $bad 0 23]\"",
            "  }",
            "}",
            f"ot_check_pin_regions [list {pats}]",
        ]
    # DESCENDING BIT ORDER (HCRING 2026-10-19): OT_PIN_ORDER_DESC names bus ports (base names) whose bits are laid
    # out from the HIGH bit at the region's low end.  A tile placed R180 against an R0 neighbour sees that
    # neighbour's face mirrored: the R0 side's ranges are mirrored AND its bits must run high-to-low, or an abutted
    # 2,048-b chain arrives bit-reversed (HC ring e0 S -> b5, b7 -> b0 S).  Unset (every other kit): output unchanged.
    desc = os.environ.get("OT_PIN_ORDER_DESC", "").split()
    if any(not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", d) for d in desc):
        raise ValueError("OT_PIN_ORDER_DESC: port base names only")
    if desc:
        lines += [
            # ORFS sources this script inside a proc: a plain `set` is proc-local and `global` then finds nothing
            # (HC bank e0/b0 pord1 gates: "can't read ot_pin_desc").  Use the namespace-qualified global.
            f"set ::ot_pin_desc {{{' '.join(desc)}}}",
            "proc ot_order_pins {names} {",
            "  if {[llength $names] > 0 && [lsearch -exact $::ot_pin_desc [ot_pin_base [lindex $names 0]]] >= 0} {",
            "    foreach n $names { if {[lsearch -exact $::ot_pin_desc [ot_pin_base $n]] < 0} {",
            "      error \"OT_PIN_ORDER_DESC: region mixes descending [ot_pin_base [lindex $names 0]] with $n\" } }",
            "    return [lreverse $names]",
            "  }",
            "  return $names",
            "}",
        ]
    match_pins = "ot_order_pins [ot_match_pins {%s}]" if desc else "ot_match_pins {%s}"
    for region in pin_regions:
        edge_region = region["edge"] + ":*"
        if "range_um" in region:
            lo, hi = region["range_um"]
            edge_region = f"{region['edge']}:{lo:g}-{hi:g}"
        # A large ordered group must fit on one edge/layer. Merely adding
        # IO layers cannot legalize that group. Opt-in chunks retain its
        # region and port order while allowing the placer to use all layers.
        group_max = int(os.environ.get("OT_PIN_GROUP_MAX", "0"))
        if group_max < 0:
            raise ValueError("OT_PIN_GROUP_MAX must be nonnegative")
        balanced_h = os.environ.get("OT_PIN_BALANCE_H", "").split()
        balanced_v = os.environ.get("OT_PIN_BALANCE_V", "").split()
        if balanced_h or balanced_v:
            if not (group_max and balanced_h and balanced_v and die_area_um):
                raise ValueError("balanced pins require group bound, both layer lists and die area")
            if any(not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", layer)
                   for layer in balanced_h + balanced_v):
                raise ValueError("invalid balanced pin layer name")
            dx0, dy0, dx1, dy1 = die_area_um
            edge = region["edge"]
            lo, hi = region.get("range_um", (dy0, dy1) if edge in ("left", "right") else (dx0, dx1))
            # CORNER AVOIDANCE (ROOT 2026-10-16, H-SM ot_hgi_sm_xload_cl2_ctl cl2d DRC 4): place_pin bypasses place_pins
            # -corner_avoidance, so a balanced full face put its first/last pin 0.04 um from the tile corner, where it
            # met the perpendicular face's corner pin (M5 spacing x4).  Balanced positions stay inside
            # [d0 + C, d1 - C] of the edge, C = OT_PIN_CORNER_UM (default 1.0 um, 0 = off).  Only a FULL-FACE region
            # is clipped: an explicit range is the author's placement (b2_dma_mv_*_wface 0.2-0.82 um, qfd_xcst_* corner
            # windows; 27 ranges on main sit inside 1 um of a corner) and stays as written.
            corner = float(os.environ.get("OT_PIN_CORNER_UM", "1.0"))
            if corner < 0:
                raise ValueError("OT_PIN_CORNER_UM must be nonnegative")
            if "range_um" not in region and hi - lo > 2 * corner:
                lo, hi = lo + corner, hi - corner
            layers = balanced_h if edge in ("left", "right") else balanced_v
            location = (f"[list {dx1 if edge == 'right' else dx0:g} $ot_pos]"
                        if edge in ("left", "right") else
                        f"[list $ot_pos {dy1 if edge == 'top' else dy0:g}]")
            lines += [
                f"set ot_region_pins [{match_pins % region['regex']}]",
                "set ot_count [llength $ot_region_pins]",
                "set ot_first 0",
                "foreach ot_pin $ot_region_pins {",
                f"  set ot_pos [expr {{{lo:g} + ({hi:g} - {lo:g}) * ($ot_first + 0.5) / $ot_count}}]",
                f"  set ot_layer [lindex {{{' '.join(layers)}}} [expr {{($ot_first / {group_max}) % {len(layers)}}}]]",
                f"  place_pin -pin_name $ot_pin -layer $ot_layer -location {location} -force_to_die_boundary",
                "  incr ot_first",
                "}",
            ]
        elif group_max:
            lines += [
                f"set ot_region_pins [{match_pins % region['regex']}]",
                f"for {{set ot_first 0}} {{$ot_first < [llength $ot_region_pins]}} {{incr ot_first {group_max}}} {{",
                f"  set_io_pin_constraint -group -order -region {edge_region} "
                f"-pin_names [lrange $ot_region_pins $ot_first [expr {{$ot_first + {group_max} - 1}}]]",
                "}",
            ]
        else:
            lines.append(
                f"set_io_pin_constraint -group -order -region {edge_region} "
                f"-pin_names [{match_pins % region['regex']}]"
            )
    return "\n".join(lines) + "\n"


def resolve_floorplan(
    die_area: list[float] | None,
    core_area: list[float] | None,
    pin_regions: list[str] | None,
    routing_layers: list[str] | None,
    step_tcl: list[str] | None = None,
) -> dict[str, Any] | None:
    """Validate the floorplan options into the block recorded under
    place_and_route.floorplan, or None when none was given."""
    if (die_area is None) != (core_area is None):
        raise ValueError("--die-area and --core-area must be given together")
    floorplan: dict[str, Any] = {}
    if die_area is not None:
        dx0, dy0, dx1, dy1 = die_area
        cx0, cy0, cx1, cy1 = core_area
        if not (dx1 > dx0 and dy1 > dy0 and cx1 > cx0 and cy1 > cy0):
            raise ValueError("--die-area/--core-area need x1 > x0 and y1 > y0")
        if not (dx0 <= cx0 and dy0 <= cy0 and cx1 <= dx1 and cy1 <= dy1):
            raise ValueError("--core-area must lie inside --die-area")
        floorplan["die_area_um"] = list(die_area)
        floorplan["core_area_um"] = list(core_area)
    if pin_regions:
        regions = []
        for item in pin_regions:
            regex, sep, edge_spec = item.rpartition("=")
            match = PIN_EDGE_REGION_RE.fullmatch(edge_spec)
            if not sep or not regex or match is None:
                raise ValueError(
                    f"--pin-region {item!r}: expected REGEX=EDGE or "
                    "REGEX=EDGE:LOW-HIGH, EDGE in " + str(PIN_EDGES)
                )
            region = {"regex": regex, "edge": match.group(1)}
            if match.group(2) is not None:
                lo, hi = float(match.group(2)), float(match.group(3))
                if hi <= lo:
                    raise ValueError(f"--pin-region {item!r}: HIGH must exceed LOW")
                region["range_um"] = [lo, hi]
            regions.append(region)
        floorplan["pin_regions"] = regions
    if routing_layers:
        floorplan["routing_layers"] = list(routing_layers)
    if step_tcl:
        hooks = []
        for item in step_tcl:
            hook, sep, path = item.partition("=")
            if not sep or not re.fullmatch(r"(PRE|POST)_[A-Z_]+", hook):
                raise ValueError(f"--step-tcl {item!r}: expected (PRE|POST)_STEP=FILE")
            source = Path(path)
            if not source.is_absolute():
                source = ROOT / source
            if not source.is_file():
                raise ValueError(f"--step-tcl {item!r}: no such file {source}")
            hooks.append({
                "hook": hook,
                "path": path,
                "name": f"{hook.lower()}_{source.name}",
                "sha256": sha256_file(source),
                "source": str(source),
            })
        floorplan["step_tcl"] = hooks
    return floorplan or None


# 738746b2 (2026-09-19T10:07:51Z) began emitting SYNTH_MEMORY_MAX_BITS in every
# config.mk; records written before it have no such line.
SYNTH_MEMORY_MAX_BITS_SINCE = "2026-09-19T10:07:51+00:00"


# asap7 adder mapping.  The platform's ADDER_MAP_FILE (yoSys/cells_adders: extract_fa + FA/HA cells) builds
# ripple adders that ABC cannot restructure; set empty, yosys keeps its Kogge-Stone $alu map.  Measured (W10,
# WC floorplan, 0.833 ns): the FP32 add pipe 840 -> 1,091 MHz, the V4.1 element 659 -> 715 MHz.  New runs
# default to the Kogge-Stone map (--asap7-adder-map restores the platform's); the choice is recorded as
# place_and_route.adder_map, and a record without it used the platform map.
ADDER_MAP_KOGGE_STONE = "yosys_kogge_stone"
ADDER_MAP_PLATFORM = "platform_fa_cells"


def with_adder_map(view: dict[str, Any], adder_map: str) -> dict[str, Any]:
    """The view whose ORFS config carries `adder_map` (asap7 only; other platforms are returned unchanged)."""
    pnr = view.get("pnr")
    if not pnr or pnr.get("platform") != "asap7" or adder_map != ADDER_MAP_KOGGE_STONE:
        return view
    out = dict(view)
    out["pnr"] = dict(pnr)
    out["pnr"]["extra_config"] = {**pnr["extra_config"], "ADDER_MAP_FILE": ""}
    return out


def recorded_view(record: dict[str, Any]) -> dict[str, Any]:
    """The view a routed record's config.mk was written from (its recorded adder map applied)."""
    view = VIEWS[record["view"]["name"]]
    return with_adder_map(view, record.get("place_and_route", {}).get("adder_map", ADDER_MAP_PLATFORM))


def recorded_memory_max_bits(record: dict[str, Any]) -> int | None:
    """The SYNTH_MEMORY_MAX_BITS a routed record's config.mk carried (None: no line)."""
    pnr = record.get("place_and_route", {})
    if "synth_memory_max_bits" in pnr:
        return pnr["synth_memory_max_bits"]
    generated = datetime.fromisoformat(record["generated_at"])
    if generated < datetime.fromisoformat(SYNTH_MEMORY_MAX_BITS_SINCE):
        return None
    return 65536   # the only value any record between 738746b2 and this field used


def corner_lib_lines(corners: list[str], memory_macros: dict[str, Any] | None) -> list[str]:
    """CORNERS config: each ORFS corner reads its standard cells AND every macro's own liberty of that corner.

    ADDITIONAL_LIBS reaches only LIB_FILES, so without this a multi-corner run drops (or mistimes) the macros.
    A macro lacking a corner's liberty FAILS CLOSED.
    """
    lines = ["export CORNERS = " + " ".join(corners)]
    for c in corners:
        mlibs = []
        for m in (memory_macros or {}).get("macros", []):
            lbc = m.get("libs_by_corner")
            if not lbc or c not in lbc:
                raise FlowError(f"macro {m.get('name')}: no liberty for ORFS corner {c}; multi-corner "
                                "timing would drop or mistime the macro")
            mlibs.append(lbc[c]["path"])
        lines.append(f"export {c}_LIB_FILES = $({ORFS_LIB_CORNERS[c]})" + "".join(" " + l for l in mlibs))
    return lines


def orfs_config_value(key: str, value: Any) -> str:
    """Preserve literal control names/patterns across Make's export expansion.

    Other ORFS options retain their Make expressions, notably corner-library
    references. These options are consumed as literal Tcl names or regexes;
    Make must not consume anchors such as ``$|`` before synthesis sees them.
    """
    value = str(value)
    literal = (key.startswith("OT_PIN_REGS_") or key.endswith(("_RE", "_REGEX", "_PATTERN"))
               or key in {"RESET_INCLUDE", "RESET_EXCLUDE", "SYNTH_RESET_INCLUDE", "SYNTH_RESET_EXCLUDE"})
    if not literal:
        return value
    if "\n" in value or "\r" in value:
        raise FlowError(f"literal ORFS option {key} must occupy one config.mk line")
    # Make strips comments before expanding dollars. Preserve both the hash
    # and any literal backslashes immediately before it.
    value = re.sub(r"(\\*)#", lambda m: "\\" * (2 * len(m[1]) + 1) + "#", value)
    return value.replace("$", "$$")


def orfs_config_lines(
    nickname: str,
    block: dict[str, Any],
    platform_name: str,
    pnr: dict[str, Any],
    core_utilization: int,
    place_density: float,
    constraints: dict[str, Any] | None = None,
    memory_macros: dict[str, Any] | None = None,
    floorplan: dict[str, Any] | None = None,
    memory_max_bits: int | None | str = "current",
) -> list[str]:
    """The ORFS config.mk for one route.

    ``memory_max_bits`` is the SYNTH_MEMORY_MAX_BITS line: "current" (the
    default) emits ``synth_memory_max_bits()``, an integer emits that value,
    and None omits the line, as every config.mk before 738746b2 did.  Records
    carry the value used under ``place_and_route.synth_memory_max_bits`` so a
    config.mk can be rebuilt byte for byte; ``recorded_memory_max_bits``
    recovers it for the records written before that field existed.

    SLEW_MARGIN appears only when a margin was given, and the macro lines only
    when a memory macro was named; without either the file is byte-for-byte
    the config.mk of every earlier record.
    """
    # ORFS applies top parameters sequentially, deriving the module each time.
    # Preserve explicit --param order: dependent features must be enabled after
    # their prerequisites, or a valid final configuration can fail mid-derive.
    params = " ".join(f"{k} {v}" for k, v in block["parameters"].items())
    config = [
        f"export DESIGN_NICKNAME = {nickname}",
        f"export DESIGN_NAME = {block['top']}",
        f"export PLATFORM = {platform_name}",
        "export VERILOG_FILES = " + " ".join(f"/src/{s}" for s in block["sources"]),
        "export VERILOG_DEFINES = -DSYNTHESIS",
        "export SDC_FILE = /work/constraint.sdc",
        *floorplan_size_lines(core_utilization, floorplan),
        f"export PLACE_DENSITY = {place_density}",
        "export PLACE_DENSITY_LB_ADDON = 0.05",
        "export SYNTH_REPEATABLE_BUILD = 1",
        "export SYNTH_HIERARCHICAL = 0",
        # ORFS refuses an inferred memory above SYNTH_MEMORY_MAX_BITS rather than
        # mapping it to flops, and its default is small enough that a descriptor
        # block's own register file trips it: ``ot_a3_hc_pre_t1_descriptor_rne``
        # failed synthesis with "Synthesized memory size 4096 exceeds
        # SYNTH_MEMORY_MAX_BITS".  These blocks have no SRAM macro in the flow --
        # every routed record here is standard cells plus the platform's fakeram
        # where one is asked for -- so the right answer is to let yosys map the
        # array to flops, which is what the routed area then honestly reports.
        *([] if memory_max_bits is None else [
            "export SYNTH_MEMORY_MAX_BITS = "
            + str(synth_memory_max_bits() if memory_max_bits == "current" else memory_max_bits)]),
        "export LEC_CHECK = 0",
        f"export TNS_END_PERCENT = {tns_end_percent()}",
        # ORFS repairs hold under GLOBAL-ROUTE-ESTIMATED parasitics and the finish
        # check measures it under RCX-EXTRACTED ones, so repairing to exactly zero
        # leaves the extraction gap as a violation.  Measured on the G2 cluster at
        # 4.5 ns with a 55% slew margin: zero max-slew, max-cap, max-fanout and DRC
        # violations and +1.2683 ns of SETUP slack, refused for a hold violation of
        # 1.62 PICOSECONDS.  That is rule R13 -- the same estimate-versus-extraction
        # gap the slew margin exists to cover -- applied to hold.  Default stays 0
        # so no existing record moves.
        "export HOLD_SLACK_MARGIN = 0",
        "export SETUP_SLACK_MARGIN = 0",
        "export SKIP_REPORT_METRICS = 0",
        "export REPORT_CLOCK_SKEW = 1",
    ]
    if params:
        config.append(f"export VERILOG_TOP_PARAMS = {params}")
    if pnr["corner_env"]:
        config.append(f"export CORNER = {pnr['corner_env']}")
    for key, value in sorted(pnr["extra_config"].items()):
        config.append(f"export {key} = {orfs_config_value(key, value)}")
    if pnr["extra_config"].get("OT_MULTI_VT"):
        # MULTI-VT (OT_MULTI_VT=lvt|lvt+slvt): synthesis maps RVT only (the platform reads ASAP7_USE_VT for the
        # synthesis make goals, including the recursive do-yosys* ones), so the netlist ABC produces is the RVT
        # baseline; floorplan..route load every listed VT, and repair_timing's VT swap (SKIP_VT_SWAP /
        # SKIP_CRIT_VT_SWAP unset = on) moves only the cells it repairs to LVT/SLVT twins (same LEF footprint)
        config.extend([
            "ifneq ($(filter %/1_1_yosys_canonicalize.rtlil %/1_2_yosys.v do-yosys do-yosys-canonicalize,"
            "$(MAKECMDGOALS)),)",
            "export ASAP7_USE_VT = RVT",
            "endif",
        ])
    if constraints and constraints.get("slew_margin_percent") is not None:
        config.append(f"export SLEW_MARGIN = {constraints['slew_margin_percent']:g}")
    if constraints and constraints.get("hold_margin_ns") is not None:
        # ORFS repairs hold under GLOBAL-ROUTE-ESTIMATED parasitics and the finish
        # check measures it under RCX-EXTRACTED ones, so repairing to exactly zero
        # leaves the extraction gap standing as a violation.  Measured on the G2
        # cluster at 4.5 ns with a 55% slew margin: zero max-slew, max-cap,
        # max-fanout and DRC violations and +1.2683 ns of SETUP slack, refused for a
        # hold violation of 1.62 PICOSECONDS.  That is rule R13 -- the same
        # estimate-versus-extraction gap the slew margin exists to cover -- applied
        # to hold.  The later line wins in an ORFS config, so this overrides the
        # HOLD_SLACK_MARGIN = 0 above only when a margin was asked for, and every
        # record without one keeps a byte-identical config.mk.
        #
        # UNITS: repair_timing -hold_margin is in the user time unit, which is
        # the liberty's -- PICOSECONDS on asap7.  Until 2026-09-26 the ns value
        # was written as is, so every asap7 record with --hold-margin-ns 0.02
        # (the G2 cluster's "20 ps", hold_margin_locus.json) asked for 0.02 ps:
        # that is why its margin "did not move" the violation.  The library-unit
        # value is now recorded and written (identical on sky130, whose unit is ns).
        lib_units = constraints.get("hold_margin_library_units", constraints["hold_margin_ns"])
        config.append(
            f"export HOLD_SLACK_MARGIN = {lib_units:g}"
        )
    if constraints and constraints.get("clock_gating"):
        config.append("export INFER_CLKGATES = 1")
        config.append(
            f"export POS_CLKGATE_AND_PORTS = {constraints['clock_gating']['cell']} ENA:CLK:GCLK "
            f"-tie_lo SE -min_net_size {constraints['clock_gating']['min_flops_per_gate']}"
        )
    if constraints and constraints.get("hold_corners"):
        # the first corner is the primary one the rest of the flow (CORNER) names
        corners = constraints["hold_corners"]
        config.extend(corner_lib_lines(corners, memory_macros))
    config.extend(memory_macro_config_lines(memory_macros))
    config.extend(floorplan_extra_lines(floorplan))
    return config


KEEP_REGS_HOOK = "/src/physical/common_flow/ot_keep_regs.tcl"


def keep_regs_config_lines(config: list[str]) -> list[str]:
    """FLOW-FIX-0410 2026-10-09: (* keep *) register copies survive the ORFS yosys opt_merge.

    physical/common_flow/ot_keep_regs.tcl (SYNTH_CANONICALIZE_TCL) sets keep on the flip-flop cells driving keep wires;
    without it identical copies fold into one flop (ot_sc_pfifo 22 -> 9 control flops).  Default on; OT_KEEP_REGS=0
    or a config that already names its own SYNTH_CANONICALIZE_TCL omits it."""
    if os.environ.get("OT_KEEP_REGS", "1").strip() == "0":
        return []
    if any(line.startswith("export SYNTH_CANONICALIZE_TCL") for line in config):
        return []
    if not (ROOT / "physical/common_flow/ot_keep_regs.tcl").is_file():
        return []
    return [f"export SYNTH_CANONICALIZE_TCL = {KEEP_REGS_HOOK}"]


def design_nickname(block_name: str, view_name: str, tag: str | None = None) -> str:
    """ORFS DESIGN_NICKNAME; a tag lets two concurrent routes of one top coexist."""
    base = f"opentallas_{block_name}_{view_name}"
    if not tag:
        return base
    if not re.fullmatch(r"[A-Za-z0-9_]+", tag):
        raise ValueError(f"--nickname-tag {tag!r} must be [A-Za-z0-9_]+")
    return f"{base}_{tag}"


DFT_SUPPORTED_VIEWS = {"asap7"}


def resolve_dft(mode: str | None, chains: int | None, max_length: int | None,
                clock_mixing: str | None) -> dict[str, Any] | None:
    """The scan configuration, or None when no DFT was asked for."""
    if mode in (None, "none"):
        if chains is not None or max_length is not None or clock_mixing is not None:
            raise ValueError("--scan-chains/--scan-max-length/--scan-clock-mixing need --dft scan")
        return None
    if mode != "scan":
        raise ValueError(f"--dft: unknown mode {mode!r}")
    if chains is not None and chains < 1:
        raise ValueError("--scan-chains must be positive")
    if max_length is not None and max_length < 1:
        raise ValueError("--scan-max-length must be positive")
    return {
        "mode": "scan",
        "chains": chains if chains is not None else (None if max_length else 1),
        "max_length": max_length,
        "clock_mixing": clock_mixing or "no_mix",
    }


def apply_scan_insertion(mapped: Path, case: Path, block: dict[str, Any], view_name: str,
                         corner: dict[str, Any] | None, dft: dict[str, Any]) -> dict[str, Any]:
    """Insert scan into the ORFS-synthesised netlist in place; return the record."""
    sys.path.insert(0, str(DRIVER_ROOT / "tools"))
    from dft import liberty as dft_liberty  # noqa: PLC0415
    from dft import netlist as dft_netlist  # noqa: PLC0415
    from dft import scan_insert  # noqa: PLC0415

    if view_name not in DFT_SUPPORTED_VIEWS or corner is None:
        raise FlowError(f"--dft scan supports views {sorted(DFT_SUPPORTED_VIEWS)}")
    cells = dft_liberty.load_cells([Path(p) for p in corner["liberty"]], case / "dft_cache")
    pre = case / "1_2_yosys.prescan.v"
    shutil.copy2(mapped, pre)
    module = dft_netlist.read_module(mapped, block["top"])
    if dft.get("bound_macros"):
        # default-off successor path: X-bounded hard macros + ICG test enable (tools/dft/macro_bound.py)
        from dft import macro_bound  # noqa: PLC0415
        bb_ports = {name: macro_bound.read_bb_ports(Path(path)) for name, path in dft["bound_macros"].items()}
        text, report = macro_bound.insert_scan_bounded(
            module, cells, bb_ports, chains=dft["chains"], max_length=dft["max_length"],
            clock_mixing=dft["clock_mixing"], tech=view_name,
        )
    else:
        text, report = scan_insert.insert_scan(
            module, cells, chains=dft["chains"], max_length=dft["max_length"],
            clock_mixing=dft["clock_mixing"], tech=view_name,
        )
    mapped.write_text(text, encoding="utf-8")
    shutil.copy2(mapped, case / "1_2_yosys.scan.v")
    report["prescan_netlist_sha256"] = sha256_file(pre)
    report["scan_netlist_sha256"] = sha256_file(mapped)
    (case / "scan_chains.json").write_text(json.dumps(report, indent=1, sort_keys=True) + "\n")
    summary = {k: v for k, v in report.items() if k not in ("chains", "clock_roots")}
    summary["chain_lengths"] = [c["length"] for c in report["chains"]]
    summary["requested"] = dft
    summary["inserted_by"] = "tools/dft/scan_insert.py (host, between ORFS synthesis and floorplan)"
    return summary


def run_pnr(
    view_name: str,
    view: dict[str, Any],
    block_name: str,
    block: dict[str, Any],
    work: Path,
    clock_period_ns: float,
    core_utilization: int,
    place_density: float,
    keep_heavy: bool,
    artifact_dir: Path,
    constraints: dict[str, Any] | None = None,
    memory_macros: dict[str, Any] | None = None,
    floorplan: dict[str, Any] | None = None,
    dft: dict[str, Any] | None = None,
    corner: dict[str, Any] | None = None,
    nickname_tag: str | None = None,
    stop_after: str = "finish",
) -> dict[str, Any]:
    pnr = view["pnr"]
    platform_name = pnr["platform"]
    case = work / "orfs"
    case.mkdir(parents=True, exist_ok=True)

    time_unit_ns = view["time_unit_ns"]
    period_lib = clock_period_ns / time_unit_ns

    (case / "constraint.sdc").write_text(
        sdc_text(view, block, clock_period_ns, constraints), encoding="utf-8"
    )

    nickname = design_nickname(block_name, view_name, nickname_tag) + ("_scan" if dft else "")
    config = orfs_config_lines(
        nickname, block, platform_name, pnr, core_utilization, place_density,
        constraints, memory_macros, floorplan,
    )
    config.extend(keep_regs_config_lines(config))
    endpoint_netlist = prepare_w11_orfs_endpoint_netlist(block, work, case)
    if endpoint_netlist:
        config.append("export SYNTH_NETLIST_FILES = /work/w11_endpoint_mapped.v")
    config = apply_cts_fix_hooks(config, case)
    config = apply_grt183_hook(config, case)
    config = ot_tt_lib_override(config)
    (case / "config.mk").write_text("\n".join(config) + "\n", encoding="utf-8")
    if floorplan and floorplan.get("pin_regions"):
        (case / "io_constraints.tcl").write_text(
            io_constraints_tcl(floorplan["pin_regions"], bool(floorplan.get("pin_regions_exhaustive")),
                               floorplan.get("die_area_um")),
            encoding="utf-8"
        )
    if floorplan and floorplan.get("step_tcl"):
        (case / "hooks").mkdir(exist_ok=True)
        for hook in floorplan["step_tcl"]:
            shutil.copy2(hook["source"], case / "hooks" / hook["name"])

    def orfs_make(goal: str, log_name: str, timeout: int | None) -> subprocess.CompletedProcess:
        cmd = [
            "docker", "run", "--rm",
            "-v", f"{ROOT}:/src:ro",
            "-v", f"{case}:/work",
            "-w", "/OpenROAD-flow-scripts/flow",
            ORFS_IMAGE, "bash", "-lc",
            "trap 'chmod -R a+rwX /work >/dev/null 2>&1 || true' EXIT; "
            "source /OpenROAD-flow-scripts/env.sh >/dev/null 2>&1; "
            "python3 /src/tools/orfs_hold_mm.py /OpenROAD-flow-scripts/flow/scripts && "
            "python3 /src/tools/orfs_allcorner_spef.py "
            "/OpenROAD-flow-scripts/flow/scripts/final_outputs.tcl && "
            "make DESIGN_CONFIG=/work/config.mk WORK_HOME=/work FLOW_VARIANT=base "
            + (f"NUM_CORES={orfs_num_cores()} " if orfs_num_cores() else "")
            + goal,
        ]
        completed = run(cmd, timeout=timeout)
        (case / log_name).write_text(
            (completed.stdout or "") + (completed.stderr or ""), encoding="utf-8"
        )
        if completed.returncode and not goal.startswith("-o "):
            rdir = case / "results" / platform_name / nickname / "base"
            if grt183_resume_prepare(rdir, case / "logs" / platform_name / nickname / "base", case, log_name):
                # GRT183-RESUME: one fresh-process re-run of 5_1_grt (and the rest of the goal) from the saved design
                try:
                    completed = orfs_make(f"-o /work/results/{platform_name}/{nickname}/base/4_cts.odb " + goal,
                                          log_name, timeout)
                finally:
                    grt183_resume_restore(rdir)
        return completed

    results_dir = case / "results" / platform_name / nickname / "base"
    mapped_container = f"/work/results/{platform_name}/{nickname}/base/1_2_yosys.v"

    # Phase 1: ORFS synthesis only.  OpenROAD's Verilog reader rejects the
    # ``input signed`` declarations Yosys emits for signed RTL ports, so the
    # mapped netlist is normalised on the host before the flow resumes.
    # The SAME ceiling ``synth_timeout_seconds`` documents, which until now
    # governed only the local-Yosys path at ``--stages synth``.  Synthesis inside
    # ORFS -- which is what ``--stages pnr`` runs -- carried a hardcoded 7,200 s,
    # so a block that legitimately needs longer could not ask: the override
    # existed and did not reach the path where the need appears.  Measured on two
    # blocks, both killed at exactly 7,200 s having produced nothing:
    # ``ot_a3_engine_array`` and ``ot_a3_fp32_transcendental_cr_rne``, the latter
    # the widest-fan-in leaf in the datapath at eight parents.  The default is
    # now unlimited unless an operator explicitly supplies a positive cap.
    proc = orfs_make(
        f"{mapped_container} && chmod a+w {mapped_container}",
        "orfs_synth.log",
        synth_timeout_seconds(),
    )
    require_success(proc, "ORFS synthesis")
    mapped = results_dir / "1_2_yosys.v"
    if not mapped.is_file():
        raise FlowError(f"ORFS produced no mapped netlist at {mapped}")
    raw_mapped = case / "1_2_yosys.raw.v"
    shutil.copy2(mapped, raw_mapped)
    if endpoint_netlist and sha256_file(raw_mapped) != endpoint_netlist["mapped_netlist_sha256"]:
        raise FlowError("ORFS changed the guarded W11 endpoint input netlist")
    signed_stripped = normalise_netlist(mapped, mapped)
    dft_record = None
    if dft:
        dft_record = apply_scan_insertion(mapped, case, block, view_name, corner, dft)

    # Phase 2: floorplan through routing and metadata.
    #
    # The same class of bug the synthesis ceiling had: a fixed six hours, right for
    # every block characterised so far and wrong for at least one.
    # ``ot_a3_attention_sparse`` -- the block whose closure would cover EIGHT
    # uncovered datapath modules at once, including the correctly-rounded
    # transcendental -- was killed at exactly 21,600 s while in GLOBAL ROUTE, stage
    # five of six, and reported as an error.  Worse, the container outlives the
    # wrapper, so the killed run kept burning cores on a result nobody would read.
    reports_dir = case / "reports" / platform_name / nickname / "base"
    logs_dir = case / "logs" / platform_name / nickname / "base"
    if stop_after in ("cts", "floorplan"):
        # through clock-tree synthesis and its setup/hold repair only (or through
        # floorplan: the synthesised netlist timed at the run's ORFS corner before
        # placement, a fast path-finding pass); the record carries that stage's own
        # metrics (ORFS 4_1_cts.json / 2_1_floorplan.json)
        st = stop_after
        proc = orfs_make(st, "orfs_flow.log", flow_timeout_seconds())
        require_success(proc, f"ORFS place-and-route through {st}")
        cts_json = logs_dir / ("4_1_cts.json" if st == "cts" else "2_1_floorplan.json")
        if not cts_json.is_file():
            raise FlowError(f"ORFS produced no {st} metrics at {cts_json}")
        cts = json.loads(cts_json.read_text(encoding="utf-8"))
        errors = {k: v for k, v in cts.items() if k.endswith("__flow__errors__count")}
        try:
            from orfs_hold_mm import tolerate_flow_errors as _ot_tol  # FLOW-HOLD: RSZ-0060 in a completed mm repair
            errors = _ot_tol(errors, logs_dir)
        except ImportError:
            pass
        if any(int(v) != 0 for v in errors.values()):
            raise FlowError(f"ORFS reported flow errors: {errors}")
        fmax_info = conservative_fmax_metrics(cts, st)
        fmax = fmax_info["fmax_hz"]
        return {
            "platform": platform_name,
            "design_nickname": nickname,
            "stopped_after": st,
            "core_utilization_percent": core_utilization,
            "synth_memory_max_bits": synth_memory_max_bits(),
            "place_density": place_density,
            "clock_period_ns": clock_period_ns,
            "flow_timeout_seconds": flow_timeout_seconds(),
            "tns_end_percent": tns_end_percent(),
            "sdc_clock_period_library_units": period_lib,
            **({"signal_integrity_constraints": constraints} if constraints else {}),
            "metrics": {
                "stage": "cts (placement-estimated parasitics)" if st == "cts" else "floorplan (synthesised netlist, no placement parasitics)",
                "setup_wns_ns": float(cts[f"{st}__timing__setup__ws"]) * time_unit_ns,
                "hold_wns_ns": float(cts[f"{st}__timing__hold__ws"]) * time_unit_ns,
                "setup_tns_ns": float(cts[f"{st}__timing__setup__tns"]) * time_unit_ns,
                "hold_tns_ns": float(cts[f"{st}__timing__hold__tns"]) * time_unit_ns,
                "setup_violations": cts.get(f"{st}__timing__drv__setup_violation_count"),
                "hold_violations": cts.get(f"{st}__timing__drv__hold_violation_count"),
                "fmax_mhz": float(fmax) / 1e6 if fmax is not None else None,
                **fmax_info,
                "hold_buffers": cts.get(f"{st}__design__instance__count__hold_buffer"),
                "setup_buffers": cts.get(f"{st}__design__instance__count__setup_buffer"),
                "instance_count": cts.get(f"{st}__design__instance__count"),
                "instance_area_um2": cts.get(f"{st}__design__instance__area"),
                "clock_skew_setup_ps": cts.get(f"{st}__clock__skew__setup"),
                "clock_skew_hold_ps": cts.get(f"{st}__clock__skew__hold"),
                "vectorless_power_total_w": cts.get(f"{st}__power__total"),
                "orfs_cts_metrics": cts,
            },
            "toolchain": orfs_identity(),
            "platform_file_sha256": platform_file_hashes(platform_name),
        }
    proc = orfs_make("finish metadata-generate", "orfs_flow.log", flow_timeout_seconds())
    require_success(proc, "ORFS place-and-route")
    metadata_path = reports_dir / "metadata.json"
    if not metadata_path.is_file():
        raise FlowError(f"ORFS produced no metadata.json at {metadata_path}")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))

    # ORFS reports slack in the SDC's own time unit, which is the liberty time
    # unit: nanoseconds for sky130hd but PICOSECONDS for asap7.  Convert the
    # timing metrics into nanoseconds and keep the raw values alongside.
    metrics: dict[str, Any] = {}
    missing: list[str] = []
    raw_timing: dict[str, Any] = {}
    for name, key in sorted(PNR_METRIC_KEYS.items()):
        if key not in metadata:
            missing.append(key)
            continue
        value = metadata[key]
        if name in PNR_TIMING_METRICS_NS:
            raw_timing[name] = value
            metrics[name] = float(value) * time_unit_ns
        else:
            metrics[name] = value
    metrics["missing_metadata_keys"] = missing
    metrics["raw_timing_library_units"] = raw_timing
    metrics["library_time_unit_ns"] = time_unit_ns
    metrics.update(conservative_fmax_metrics(metadata, "finish"))

    flow_errors = {
        key: metadata[key]
        for key in sorted(metadata)
        if key.endswith("__flow__errors__count")
    }
    metrics["flow_error_counts"] = flow_errors
    g183 = results_dir / "5_1_grt.grt183_recovered.json"
    if g183.is_file():   # GRT183-RESUME receipt: stage 5_1_grt re-ran once in a fresh process from the resized design
        metrics["grt183_resume"] = json.loads(g183.read_text(encoding="utf-8"))
    try:
        from orfs_hold_mm import tolerate_flow_errors as _ot_tol  # FLOW-HOLD: RSZ-0060 in a completed mm repair
        flow_errors = _ot_tol(flow_errors, logs_dir)
        metrics["flow_error_counts_tolerated"] = flow_errors
    except ImportError:
        pass
    if any(int(v) != 0 for v in flow_errors.values()):
        raise FlowError(f"ORFS reported flow errors: {flow_errors}")
    if endpoint_netlist and metrics.get("sequential_cell_count", 0) < 270418:
        raise FlowError("Routed W11 endpoint netlist fell below the original full-size guard")

    # Collect artifacts.
    artifacts: dict[str, Any] = {}
    search_dirs = [results_dir, reports_dir, logs_dir, case]
    wanted = list(PNR_ARTIFACTS_LIGHT) + (PNR_ARTIFACTS_HEAVY if keep_heavy else [])
    out_dir = artifact_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    for name in wanted:
        for directory in search_dirs:
            candidate = directory / name
            if candidate.is_file():
                shutil.copy2(candidate, out_dir / name)
                artifacts[name] = {
                    "sha256": sha256_file(candidate),
                    "size_bytes": candidate.stat().st_size,
                    "retained": True,
                }
                break
    if dft_record:
        for name in ("scan_chains.json", "1_2_yosys.scan.v"):
            candidate = case / name
            shutil.copy2(candidate, out_dir / name)
            artifacts[name] = {
                "sha256": sha256_file(candidate),
                "size_bytes": candidate.stat().st_size,
                "retained": True,
            }
    # Record identity of heavy artifacts even when they are not retained.
    if not keep_heavy:
        for name in PNR_ARTIFACTS_HEAVY:
            candidate = results_dir / name
            if candidate.is_file():
                artifacts[name] = {
                    "sha256": sha256_file(candidate),
                    "size_bytes": candidate.stat().st_size,
                    "retained": False,
                }

    return {
        "platform": platform_name,
        "extracted_spef_annotation": {
            "policy": "explicit read_spef -corner for every configured CORNERS scene before finish metrics",
            "helper": "tools/orfs_allcorner_spef.py",
            "helper_sha256": sha256_file(ROOT / "tools/orfs_allcorner_spef.py"),
        },
        **({"w11_endpoint_netlist": endpoint_netlist} if endpoint_netlist else {}),
        "design_nickname": nickname,
        "netlist_normalization": {
            "signed_declarations_stripped": signed_stripped,
            "raw_netlist_sha256": sha256_file(raw_mapped),
            "normalized_netlist_sha256": sha256_file(mapped),
            "note": (
                "declaration-attribute-only edit on the ORFS-synthesised gate "
                "netlist; no cell, net, port or connectivity change"
            ),
        },
        "core_utilization_percent": core_utilization,
        "synth_memory_max_bits": synth_memory_max_bits(),
        "place_density": place_density,
        "clock_period_ns": clock_period_ns,
        "flow_timeout_seconds": flow_timeout_seconds(),
        "tns_end_percent": tns_end_percent(),
        "sdc_clock_period_library_units": period_lib,
        **({"signal_integrity_constraints": constraints} if constraints else {}),
        **({"memory_macros": memory_macros} if memory_macros else {}),
        **({"floorplan": floorplan} if floorplan else {}),
        **({"dft": dft_record} if dft_record else {}),
        "metrics": metrics,
        "artifacts": artifacts,
        "artifact_dir": str(out_dir.relative_to(ROOT)) if out_dir.is_relative_to(ROOT) else str(out_dir),
        "toolchain": orfs_identity(),
        "platform_file_sha256": platform_file_hashes(platform_name),
    }


# --------------------------------------------------------------------------
# Engineering verdict
# --------------------------------------------------------------------------
#
# ``status`` is the ENGINEERING result, not "the script finished".  Whether the
# flow ran to completion is reported separately as ``flow_completed``.  A run
# whose timing did not close must never be emitted as ``pass``: a downstream
# report generator reads ``status``, and a slow corner that fails to close at
# the target period would otherwise silently become a claim that the block
# closes at that period.

STATUS_PASS = "pass"
STATUS_NOT_MET = "not_met"
STATUS_NOT_EVALUATED = "not_evaluated"
STATUS_ERROR = "error"


def evaluate_verdict(record: dict[str, Any]) -> dict[str, Any]:
    """Derive the engineering verdict from whatever stages actually ran."""
    checks: list[dict[str, Any]] = []

    sta = record.get("static_timing")
    if sta:
        setup_ok = sta["setup_wns_ns"] >= 0.0 and sta["setup_violating_paths"] == 0
        hold_ok = sta["hold_wns_ns"] >= 0.0 and sta["hold_violating_paths"] == 0
        checks.append(
            {
                "stage": "static_timing",
                "scope": "pre-layout, ideal clock",
                "met": bool(setup_ok and hold_ok),
                "setup_met": bool(setup_ok),
                "hold_met": bool(hold_ok),
                "setup_wns_ns": sta["setup_wns_ns"],
                "setup_violating_paths": sta["setup_violating_paths"],
                "hold_wns_ns": sta["hold_wns_ns"],
                "hold_violating_paths": sta["hold_violating_paths"],
            }
        )

    pnr = record.get("place_and_route")
    if pnr:
        m = pnr["metrics"]

        def number(key: str) -> float | None:
            value = m.get(key)
            try:
                parsed = float(value)
            except (TypeError, ValueError):
                return None
            return parsed if math.isfinite(parsed) else None

        setup_wns = number("setup_wns_ns")
        hold_wns = number("hold_wns_ns")
        setup_viol = number("setup_violations")
        hold_viol = number("hold_violations")
        drc = number("drc_errors")
        ant_nets = number("antenna_violating_nets")
        ant_pins = number("antenna_violating_pins")
        timing_ok = (
            setup_wns is not None
            and hold_wns is not None
            and setup_wns >= 0.0
            and hold_wns >= 0.0
            and setup_viol == 0
            and hold_viol == 0
        )
        signal_checks = {key: number(key) for key in (
            "max_slew_violations", "max_cap_violations", "max_fanout_violations"
        )}
        signal_ok = all(value == 0 for value in signal_checks.values())
        clean_ok = drc == 0 and ant_nets == 0 and ant_pins == 0 and signal_ok
        if pnr.get("stopped_after") == "cts":
            # a route stopped after CTS has no routed checks to be clean in
            checks.append({
                "stage": "place_and_route",
                "scope": "post-CTS, placement-estimated parasitics (stopped after cts)",
                "met": bool(timing_ok), "timing_met": bool(timing_ok),
                "setup_wns_ns": setup_wns, "setup_violations": setup_viol,
                "hold_wns_ns": hold_wns, "hold_violations": hold_viol,
            })
            pnr = None
    if pnr:
        checks.append(
            {
                "stage": "place_and_route",
                "scope": "post-route, extracted parasitics",
                "met": bool(timing_ok and clean_ok),
                "timing_met": bool(timing_ok),
                "physically_clean": bool(clean_ok),
                "signal_integrity_clean": bool(signal_ok),
                **signal_checks,
                "setup_wns_ns": setup_wns,
                "setup_violations": setup_viol,
                "hold_wns_ns": hold_wns,
                "hold_violations": hold_viol,
                "drc_errors": drc,
                "antenna_violating_nets": ant_nets,
                "antenna_violating_pins": ant_pins,
            }
        )

    if not checks:
        return {
            "status": STATUS_NOT_EVALUATED,
            "reason": "no timing-bearing stage ran; nothing to accept or reject",
            "checks": checks,
        }
    failed = [c["stage"] for c in checks if not c["met"]]
    if failed:
        return {
            "status": STATUS_NOT_MET,
            "reason": f"did not meet in: {', '.join(failed)}",
            "checks": checks,
        }
    return {"status": STATUS_PASS, "reason": "all evaluated stages met", "checks": checks}


# --------------------------------------------------------------------------
# Design summary: lanes, MAC rate and per-MAC figures (redesign gates D3, D4)
# --------------------------------------------------------------------------
#
# docs/OPENTALLAS_REDESIGN_PLAN.md gates D3 and D4 read a ``design`` block from
# each pnr.json: the declared lane count, the MAC (lane-op) rate the RTL
# campaign measured for the block, and the per-MAC area and period derived
# from the routed result with the same arithmetic as the recorded baseline
# (docs/CHIP_ARCHITECTURE_DESIGN.md section 8.4: standard-cell area / MAC per
# cycle = 48,274 um2; closed target period / MAC per cycle = 104.1 ns).  The
# MAC rate is never measured here -- it is cited from the results/rtl artifact
# named on the command line -- and the per-MAC period is meaningful only when
# the routed block closed at the target period (``closed`` says so).

_NETLIST_INSTANCE_RE = re.compile(r"^\s*(\w+)\s+(\\\S+|\w+)\s+\(", re.M)
_NETLIST_NET_RE = re.compile(
    r"^\s*(?:wire|reg|input|output|inout)\s+(?:\[[^\]]*\]\s*)?(\\\S+|\w+)\s*;", re.M
)


def count_lane_instances(netlist: Path, lane_regex: str) -> dict[str, Any]:
    """Count the distinct lane indices named in a flattened gate netlist.

    ORFS flattens the hierarchy (SYNTH_HIERARCHICAL = 0), but Yosys keeps the
    hierarchical prefix on every net it declares, so a generate-loop lane
    survives as a net-name prefix such as ``gen_lane[3].u_lane.``.  Whether
    the mapped registers keep that prefix as an instance name depends on the
    Yosys version (0.68 renames them ``_NNN_`` like ABC renames the
    combinational cells), so both instance names and net names are scanned
    and a lane counts as present when either carries its index.  The per-lane
    counts are over named objects only and are a lower bound on what each
    lane contributes.
    """
    pattern = re.compile(lane_regex)
    cells_per_lane: dict[str, int] = {}
    nets_per_lane: dict[str, int] = {}
    instances_total = 0
    nets_total = 0
    text = netlist.read_text(encoding="utf-8", errors="ignore")
    for match in _NETLIST_INSTANCE_RE.finditer(text):
        instances_total += 1
        found = pattern.search(match.group(2))
        if found:
            key = found.group(1)
            cells_per_lane[key] = cells_per_lane.get(key, 0) + 1
    for match in _NETLIST_NET_RE.finditer(text):
        nets_total += 1
        found = pattern.search(match.group(1))
        if found:
            key = found.group(1)
            nets_per_lane[key] = nets_per_lane.get(key, 0) + 1
    lanes_seen = set(cells_per_lane) | set(nets_per_lane)

    def ordered(counts: dict[str, int]) -> dict[str, int]:
        return {key: counts[key] for key in sorted(counts, key=lambda k: (len(k), k))}

    return {
        "netlist": netlist.name,
        "netlist_sha256": sha256_file(netlist),
        "instance_regex": lane_regex,
        "instances_total": instances_total,
        "nets_total": nets_total,
        "distinct_lanes": len(lanes_seen),
        "distinct_lanes_by_instance_name": len(cells_per_lane),
        "distinct_lanes_by_net_name": len(nets_per_lane),
        "named_cells_per_lane": ordered(cells_per_lane),
        "named_nets_per_lane": ordered(nets_per_lane),
        "note": (
            "distinct_lanes is the union of lane indices found on instance "
            "names and on declared net names; ABC renames combinational cells "
            "and Yosys 0.68 renames mapped registers, so instance names may "
            "carry no lane prefix while the nets keep it"
        ),
    }

def evidence_entry(spec: str) -> dict[str, Any]:
    """Resolve ``PATH`` or ``PATH:DOTTED.FIELD`` into a hashed citation."""
    path_str, _, field = spec.partition(":")
    path = Path(path_str)
    if not path.is_absolute():
        path = ROOT / path
    entry: dict[str, Any] = {"path": path_str}
    if not path.is_file():
        entry["error"] = "missing"
        return entry
    entry["sha256"] = sha256_file(path)
    if field:
        entry["field"] = field
        try:
            node: Any = json.loads(path.read_text(encoding="utf-8"))
            for part in field.split("."):
                node = node[part]
            entry["value"] = node
        except Exception as exc:  # noqa: BLE001 - recorded, not fatal
            entry["error"] = f"{type(exc).__name__}: {exc}"
    return entry


def augment_design(
    record: dict[str, Any],
    lanes: int | None,
    mac_per_cycle: float | None,
    evidence: list[str],
    lane_regex: str | None,
    netlists: list[Path | None],
) -> None:
    """Attach the gate-facing design summary to ``record['design']``.

    Every number here is copied from a stage this run executed; when a stage
    did not run (or the flow errored) the corresponding field is absent and
    ``closed`` is false, so a partial record can never read as a result.
    """
    # The closure verdict and the signal-integrity counts belong to EVERY
    # routed record.  This used to return early when no lane argument was
    # given, so five routed records -- the D4 baseline among them -- carried no
    # verdict at all.  Lane-specific fields stay conditional below.
    design = record.setdefault("design", {})
    pnr = record.get("place_and_route")
    synth = record.get("synthesis")
    sta = record.get("static_timing") or {}
    metrics = (pnr or {}).get("metrics", {})

    if lanes is not None:
        design["lanes"] = lanes
        design["lanes_basis"] = (
            "declared lane count of the block (its LANES parameter, or 1 for a "
            "single lane); lanes_in_netlist is the count recovered from the "
            "mapped netlist"
        )
    if lane_regex:
        counted: dict[str, Any] | None = None
        for candidate in netlists:
            if candidate is not None and candidate.is_file():
                counted = count_lane_instances(candidate, lane_regex)
                break
        if counted is None:
            counted = {"error": "no netlist available", "instance_regex": lane_regex}
        design["lanes_in_netlist"] = counted
        design["lanes_verified_in_netlist"] = bool(
            lanes is not None and counted.get("distinct_lanes") == lanes
        )

    if mac_per_cycle is not None:
        design["mac_per_cycle"] = mac_per_cycle
        design["mac_per_cycle_basis"] = (
            "lane-ops retired per cycle by the whole block in steady state, as "
            "measured by the RTL campaign cited in mac_rate_evidence (one "
            "product per lane-op at g = 1); not measured by this flow"
        )
        design["mac_rate_evidence"] = [evidence_entry(item) for item in evidence]

    if pnr:
        design["cells"] = metrics.get("standard_cell_count")
        design["cells_basis"] = (
            "place_and_route.metrics.standard_cell_count: routed netlist after "
            "timing repair and clock-tree synthesis, buffers included"
        )
        design["area_um2"] = metrics.get("standard_cell_area_um2")
        design["area_basis"] = "place_and_route.metrics.standard_cell_area_um2"
        design["core_area_um2"] = metrics.get("core_area_um2")
        design["utilization_fraction"] = metrics.get("utilization_fraction")
        design["fmax_hz"] = metrics.get("fmax_hz")
        design["fmax_basis"] = "place_and_route.metrics.fmax_hz (ORFS finish__timing__fmax)"
        design["clock_period_ns"] = pnr.get("clock_period_ns")
        design["setup_wns_ns"] = metrics.get("setup_wns_ns")
        design["hold_wns_ns"] = metrics.get("hold_wns_ns")
        design["drc"] = metrics.get("drc_errors")
        nets = metrics.get("antenna_violating_nets")
        pins = metrics.get("antenna_violating_pins")
        design["antenna_violating_nets"] = nets
        design["antenna_violating_pins"] = pins
        design["antenna"] = (
            int(nets) + int(pins) if nets is not None and pins is not None else None
        )
        drv = {k: metrics.get(k) for k in ("max_slew_violations", "max_cap_violations", "max_fanout_violations")}
        design["signal_integrity_violations"] = drv
        design["signal_integrity_clean"] = all(v is not None and int(v) == 0 for v in drv.values())
    elif synth:
        design["cells"] = synth.get("cell_count")
        design["cells_basis"] = "synthesis.cell_count (pre-layout, pinned host Yosys)"
        design["area_um2"] = synth.get("cell_area_um2")
        design["area_basis"] = "synthesis.cell_area_um2 (pre-layout)"
        design["fmax_hz"] = sta.get("fmax_hz")
        design["fmax_basis"] = "static_timing.fmax_hz (pre-layout)" if sta else None
        design["clock_period_ns"] = sta.get("clock_period_ns")
        design["drc"] = None
        design["antenna"] = None

    closed = bool(pnr) and record.get("status") == STATUS_PASS
    if closed and design.get("signal_integrity_clean") is False:
        closed = False
        design["closed_reason"] = (
            "signal-integrity violations in the routed netlist: "
            + ", ".join(f"{k} {v}" for k, v in design["signal_integrity_violations"].items() if v)
        )
    design["closed"] = closed
    design["closed_basis"] = (
        "true only when place-and-route ran, the routed netlist carries zero "
        "max-slew, max-cap and max-fanout violations, and the engineering verdict is "
        "pass: setup and hold met with zero violating paths, zero DRC, zero "
        "antenna violations at the target period"
    )

    if mac_per_cycle:
        area = design.get("area_um2")
        period = design.get("clock_period_ns")
        fmax = design.get("fmax_hz")
        if area is not None:
            design["per_mac_area_um2"] = float(area) / mac_per_cycle
        if period is not None:
            design["per_mac_period_ns"] = float(period) / mac_per_cycle
        if fmax:
            design["per_mac_period_ns_at_fmax"] = (1e9 / float(fmax)) / mac_per_cycle
        design["per_mac_basis"] = (
            "per_mac_area_um2 = standard-cell area / MAC per cycle; "
            "per_mac_period_ns = target clock period / MAC per cycle -- the "
            "arithmetic behind the baseline's 48,274 um2 and 104.1 ns "
            "(results/physical_abi3/asap7/matmul_bf16_sram_engine/pnr.json: "
            "8,348.44 um2 / 0.17294 and 18 ns / 0.17294; "
            "docs/CHIP_ARCHITECTURE_DESIGN.md section 8.4).  The period figure "
            "is a result only when closed is true; per_mac_period_ns_at_fmax "
            "is the same quantity at the reported post-route fmax, for "
            "information.  Nothing is scaled across nodes."
        )


# --------------------------------------------------------------------------
# Driver
# --------------------------------------------------------------------------


def _max_transition_arg(text: str) -> float | str:
    if text == LIBRARY_LIMIT:
        return text
    try:
        value = float(text)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"expected a time in ns or '{LIBRARY_LIMIT}', got {text!r}") from exc
    if value <= 0:
        raise argparse.ArgumentTypeError(f"max transition must be positive, got {text}")
    return value


def _max_fanout_arg(text: str) -> int | str:
    if text == DRIVER_DEFAULT:
        return text
    try:
        value = int(text)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"expected an integer or '{DRIVER_DEFAULT}', got {text!r}") from exc
    if value <= 0:
        raise argparse.ArgumentTypeError(f"max fanout must be positive, got {text}")
    return value


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--synth-timeout-seconds", default=argparse.SUPPRESS,
                        help="synthesis/STA seconds (0 = unlimited, alias: none); otherwise env/default unlimited")
    parser.add_argument("--flow-timeout-seconds", default=argparse.SUPPRESS,
                        help="route seconds or unlimited (alias: none); otherwise env/default 21600")
    parser.add_argument("--view", required=True, choices=sorted(VIEWS))
    parser.add_argument("--block", choices=sorted(BLOCKS), help="named block from the built-in registry")
    parser.add_argument("--top", help="RTL top module (with --source, overrides --block)")
    parser.add_argument("--source", action="append", default=[], help="RTL source, repeatable")
    parser.add_argument("--param", action="append", default=[], help="NAME=VALUE top parameter, repeatable")
    parser.add_argument("--clock-port", default="clk")
    parser.add_argument("--ingress-clock-port", help="related, same-period ingress capture clock port")
    parser.add_argument("--ingress-input-port", action="append", default=[],
                        help="input port timed relative to ingress clock; repeat for each port")
    parser.add_argument("--ingress-input-delay-min-ns", type=float,
                        help="earliest ingress data arrival relative to ingress clock")
    parser.add_argument("--ingress-input-delay-max-ns", type=float,
                        help="latest ingress data arrival relative to ingress clock")
    parser.add_argument("--core-input-delay-min-ns", type=float,
                        help="earliest non-clock input arrival relative to core clock")
    parser.add_argument("--core-input-delay-max-ns", type=float,
                        help="latest non-clock input arrival relative to core clock")
    parser.add_argument("--core-input-port", action="append", default=[],
                        help="core-clocked input port or port pattern; repeat to keep clock domains disjoint")
    parser.add_argument("--false-path-from", action="append", default=None)
    parser.add_argument(
        "--false-path-io",
        action="store_true",
        help="false-path every non-clock input and every output, so closure is the block's internal "
             "register-to-register timing; for blocks whose ports are registered on the block side and "
             "face registered neighbours or memory macros. Recorded under design.false_path_io",
    )
    parser.add_argument(
        "--io-delay-fraction",
        type=float,
        default=None,
        help="external input/output delay as a fraction of the clock period (default 0.2). "
             "0 models a block whose ports face adjacent macros or registered neighbours in the "
             "same clock domain, so only its internal register-to-register paths set closure; the "
             "value is recorded under design.io_delay_fraction",
    )
    parser.add_argument("--corner", default=None, help="corner name within the view")
    parser.add_argument("--clock-period-ns", type=float, required=True)
    parser.add_argument("--clock-uncertainty-ns", type=float, default=None,
                        help="nonnegative clock uncertainty applied to all clocks (setup and hold) in the "
                             "source-pinned SDC; absent emits nothing. The value is recorded under "
                             "design.clock_uncertainty_ns")
    parser.add_argument("--clock-uncertainty-hold-ns", type=float, default=None,
                        help="with --clock-uncertainty-ns: a separate hold uncertainty on all clocks (the setup "
                             "uncertainty is then emitted with -setup); project SDC policy 2026-09-29 is 0.060 "
                             "setup / 0.025 hold; recorded under design.clock_uncertainty_hold_ns")
    parser.add_argument("--clock-uncertainty-setup-only", action="store_true",
                        help="with --clock-uncertainty-ns: emit set_clock_uncertainty -setup on core_clk only, "
                             "so hold is timed without it (the claude/w5-qwen-physical semantics of "
                             "--clock-uncertainty-ns); recorded under design.clock_uncertainty_setup_only")
    parser.add_argument("--output-delay-min-ns", type=float, default=None,
                        help="set_output_delay -min on every output (with --output-delay-max-ns), after the "
                             "io-delay-fraction default; a negative value models a downstream capture flop "
                             "whose clock arrives that much later than the ideal edge (the same tree's "
                             "insertion delay)")
    parser.add_argument("--output-delay-max-ns", type=float, default=None,
                        help="set_output_delay -max on every output (with --output-delay-min-ns)")
    parser.add_argument("--stages", default="synth,sta", help="comma list of synth,sta,pnr")
    parser.add_argument("--preserve-w11-controller-endpoints", action="store_true",
                        help="retain physical-stub endpoint register cells in the full W11 controller vehicle; off by default")
    parser.add_argument(
        "--fmax-search",
        action="store_true",
        help="bisect the clock period for the shortest period meeting setup timing",
    )
    parser.add_argument("--core-utilization", type=int, default=35)
    parser.add_argument(
        "--vt",
        default=None,
        help=(
            "ASAP7 threshold-voltage flavour(s) for place-and-route, e.g. 'LVT' or "
            "'RVT LVT SLVT'.  ORFS reads this as ASAP7_USE_VT: the first entry is "
            "primary and the rest are added as extra liberty/LEF/GDS so the sizer "
            "may pick a faster cell on a critical path.  The view's own default "
            "(RVT) stands when this is not given.  NOTE: only the pnr stage honours "
            "it -- the sta stage reads the local PDK mirror, which carries RVT only."
        ),
    )
    parser.add_argument("--place-density", type=float, default=0.60)
    parser.add_argument("--cts-cluster-size", type=int, default=None,
                        help="ORFS clock sink clustering size; controls clock-tree fanout without relaxing SDC limits")
    parser.add_argument("--keep-heavy-artifacts", action="store_true")
    parser.add_argument(
        "--max-transition-ns",
        nargs="?",
        const=LIBRARY_LIMIT,
        default=None,
        type=_max_transition_arg,
        metavar="NS",
        help=(
            "emit set_max_transition NS [current_design] in the SDC so repair_design "
            "buffers and sizes every net to that slew; given bare (or as 'library') "
            "it is the smallest default_max_transition of the corner's liberty files "
            "(asap7 RVT 0.32 ns, sky130hd 1.5 ns).  Absent: no set_max_transition, "
            "the liberty limits alone, as every earlier record"
        ),
    )
    parser.add_argument(
        "--max-fanout",
        nargs="?",
        const=DRIVER_DEFAULT,
        default=None,
        type=_max_fanout_arg,
        metavar="N",
        help=(
            "emit set_max_fanout N [current_design] and record it; given bare (or as "
            "'default') it is the 32 every SDC carries anyway.  Absent: set_max_fanout "
            "32, unrecorded, as every earlier record"
        ),
    )
    parser.add_argument(
        "--slew-margin-percent",
        type=float,
        default=None,
        metavar="PCT",
        help=(
            "ORFS SLEW_MARGIN: repair_design overfixes max-slew to (100 - PCT)%% of "
            "each pin's limit under estimated parasitics.  Absent: ORFS default, no margin"
        ),
    )
    parser.add_argument(
        "--hold-margin-ns",
        type=float,
        default=None,
        metavar="NS",
        help=(
            "ORFS HOLD_SLACK_MARGIN: repair_timing targets this much POSITIVE hold "
            "slack under estimated parasitics so the extracted finish check still "
            "lands non-negative.  Absent: ORFS default 0"
        ),
    )
    parser.add_argument(
        "--clock-gating",
        action="store_true",
        help=(
            "ORFS INFER_CLKGATES: yosys turns every group of >= 8 flops sharing an "
            "enable into an integrated clock gate (ASAP7 ICGx1) plus plain flops; "
            "recorded under signal_integrity_constraints.clock_gating.  ICGs the RTL "
            "instantiates (ot_hdc_cg) are kept with or without it"
        ),
    )
    parser.add_argument(
        "--orfs-corner", choices=sorted(ORFS_LIB_CORNERS), default=None,
        help=("the primary ORFS corner of place and route (asap7: TC typical, WC slow = SS, BC fast = FF); "
              "overrides the view's corner_env.  --macro-view macros are timed with their own liberty of "
              "that corner (NAME_{tt,ss,ff}.lib), and a missing one fails the run"),
    )
    parser.add_argument(
        "--hold-corners",
        default=None,
        metavar="C1,C2",
        help=(
            "ORFS CORNERS: repair setup and hold at each listed ORFS corner (asap7: "
            "TC, BC, WC), e.g. TC,BC to fix hold at the fast corner too; the first "
            "is the primary.  Combine with --hold-margin-ns for an on-chip-variation "
            "budget.  Recorded under signal_integrity_constraints.hold_corners"
        ),
    )
    parser.add_argument(
        "--orfs-var",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="set an ORFS config.mk variable verbatim (repeatable; e.g. PDN_TCL=/src/...); recorded "
             "under the view's pnr.extra_config.  Absent: nothing added",
    )
    parser.add_argument(
        "--sdc-append", action="append", default=[], metavar="FILE",
        help=("append this SDC file's lines (design-intent timing exceptions, e.g. a multicycle macro read) to "
              "the generated constraints; recorded with its digest under design.extra_sdc"),
    )
    parser.add_argument(
        "--asap7-adder-map", action="store_true",
        help=("asap7: keep the platform's ADDER_MAP_FILE (FA/HA ripple adders).  Default: ADDER_MAP_FILE is set "
              "empty so yosys keeps its Kogge-Stone adders; recorded as place_and_route.adder_map"),
    )
    parser.add_argument(
        "--pnr-stop-after",
        default="finish",
        choices=["finish", "cts", "floorplan"],
        help=(
            "cts: run ORFS through clock-tree synthesis (with its setup/hold repair) "
            "and record the CTS-stage metrics, for a block whose global route does "
            "not finish in the flow limit; recorded as place_and_route.stopped_after"
        ),
    )
    parser.add_argument(
        "--memory-macro",
        action="append",
        default=[],
        metavar="NAME",
        help=(
            "place-and-route with this memory macro of the platform available: its LEF "
            "and liberty are resolved inside the pinned image from the platform's own "
            "lef/ and lib/ directories and emitted as ADDITIONAL_LEFS, ADDITIONAL_LIBS "
            "and SYNTH_BLACKBOXES, so an instance in the RTL survives synthesis as a "
            "black box and is placed as a macro.  Repeatable.  Absent: no macro lines "
            "in config.mk, as every earlier record"
        ),
    )
    parser.add_argument(
        "--macro-view",
        action="append",
        default=[],
        metavar="NAME=DIR",
        help=(
            "place-and-route with a macro compiled by tools/mem_compiler: DIR (in the source "
            "tree) holds NAME.lef and NAME_<corner>.lib; emitted as ADDITIONAL_LEFS, "
            "ADDITIONAL_LIBS, SYNTH_BLACKBOXES and GDS_ALLOW_EMPTY.  Repeatable; needs "
            "--macro-place-halo unless --memory-macro is also given"
        ),
    )
    parser.add_argument(
        "--macro-place-halo",
        nargs=2,
        type=float,
        default=None,
        metavar=("X_UM", "Y_UM"),
        help=(
            "override MACRO_PLACE_HALO, the keep-out rtl_macro_placer leaves around "
            "each macro.  Absent: the platform's own default, which is recorded either "
            "way; needs --memory-macro"
        ),
    )
    parser.add_argument(
        "--source-root",
        default=None,
        metavar="DIR",
        help=(
            "tree to read the RTL sources from (default: this driver's own checkout).  "
            "Its git identity becomes the record's git block, it is mounted as /src in "
            "the ORFS container, and relative --output, --keep-workdir and "
            "--mac-rate-evidence paths resolve under it; the commit this driver came "
            "from is recorded in runner.driver"
        ),
    )
    parser.add_argument(
        "--purpose",
        default="characterization",
        choices=["characterization", "signoff_target"],
        help=(
            "characterization: this target period is a probe, not a claim that "
            "the block must close at it.  signoff_target: this period is the "
            "intended operating point."
        ),
    )
    parser.add_argument(
        "--expected-not-met",
        action="store_true",
        help=(
            "record that this corner is deliberately expected not to close at "
            "the target period; does not change status, only documents intent"
        ),
    )
    parser.add_argument(
        "--die-area", nargs=4, type=float, default=None, metavar=("X0", "Y0", "X1", "Y1"),
        help="explicit ORFS DIE_AREA in um (with --core-area; replaces --core-utilization)",
    )
    parser.add_argument(
        "--core-area", nargs=4, type=float, default=None, metavar=("X0", "Y0", "X1", "Y1"),
        help="explicit ORFS CORE_AREA in um (with --die-area)",
    )
    parser.add_argument(
        "--pin-region", action="append", default=None, metavar="REGEX=EDGE",
        help="pin matching ports to EDGE (left/right/top/bottom), optionally "
             "within EDGE:LOW-HIGH microns along that edge; repeatable and recorded",
    )
    parser.add_argument(
        "--pin-regions-exhaustive", action="store_true",
        help="fail the floorplan unless every signal port matches exactly one --pin-region",
    )
    parser.add_argument(
        "--routing-layers", nargs=2, default=None, metavar=("MIN", "MAX"),
        help="override the platform's MIN_ROUTING_LAYER / MAX_ROUTING_LAYER",
    )
    parser.add_argument(
        "--step-tcl", action="append", default=None, metavar="HOOK=FILE",
        help="source FILE at ORFS step hook HOOK (e.g. POST_PDN), repeatable; "
             "its sha256 is recorded under place_and_route.floorplan.step_tcl",
    )
    parser.add_argument(
        "--dft", default=None, choices=["none", "scan"],
        help="scan: insert muxed-D full scan between ORFS synthesis and floorplan "
             "(tools/dft/scan_insert.py) and route the scanned netlist; recorded "
             "under place_and_route.dft.  Absent or none: no DFT, as every earlier record",
    )
    parser.add_argument("--scan-chains", type=int, default=None, metavar="N",
                        help="number of balanced scan chains (default 1)")
    parser.add_argument("--scan-max-length", type=int, default=None, metavar="L",
                        help="longest allowed chain; raises the chain count to fit")
    parser.add_argument("--scan-clock-mixing", default=None, choices=["no_mix", "mix"],
                        help="no_mix (default): one clock domain per chain; mix: chains "
                             "cross domains through lock-up latches")
    parser.add_argument("--dft-bound-macros", action="store_true",
                        help="with --dft scan: treat every --macro-view macro as an X-bounded black box "
                             "(outputs AND !test_mode) and open ICGs in test mode (SE = test_mode); "
                             "tools/dft/macro_bound.py.  Default off: the plain inserter, as every earlier record")
    parser.add_argument("--output", required=True)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--keep-workdir", default=None, help="directory to retain intermediate files in")
    parser.add_argument(
        "--nickname-tag",
        default=None,
        help=(
            "suffix appended to the ORFS DESIGN_NICKNAME, so a route of a top that is "
            "already being routed elsewhere (e.g. a sign-off re-route with --keep-workdir) "
            "does not share its results namespace; default: none (nickname unchanged)"
        ),
    )
    parser.add_argument(
        "--lanes",
        type=int,
        default=None,
        help="declared lane count of the block; recorded as design.lanes (gate D3)",
    )
    parser.add_argument(
        "--mac-per-cycle",
        type=float,
        default=None,
        help=(
            "MAC (lane-ops) per cycle for the whole block as measured by the RTL "
            "campaign named in --mac-rate-evidence; recorded as design.mac_per_cycle "
            "and used for the per-MAC figures (gate D4)"
        ),
    )
    parser.add_argument(
        "--mac-rate-evidence",
        action="append",
        default=[],
        help="results/rtl artifact behind --mac-per-cycle, as PATH or PATH:DOTTED.FIELD (repeatable)",
    )
    parser.add_argument(
        "--lane-instance-regex",
        default=None,
        help=(
            "regex over instance names of the mapped netlist whose first group is "
            "the lane index; distinct indices are counted into design.lanes_in_netlist"
        ),
    )
    return parser


def with_cts_cluster_size(view: dict[str, Any], size: int | None) -> dict[str, Any]:
    """Copy the view so a CTS experiment cannot change another run's defaults."""
    if size is None:
        return view
    if size < 1:
        raise ValueError("--cts-cluster-size must be positive")
    if view.get("pnr") is None:
        raise ValueError("--cts-cluster-size requires a place-and-route platform")
    result = dict(view)
    result["pnr"] = dict(view["pnr"])
    result["pnr"]["extra_config"] = dict(view["pnr"]["extra_config"])
    result["pnr"]["extra_config"]["CTS_CLUSTER_SIZE"] = size
    return result


_TIMEOUT_UNSET = object()


def main(argv: list[str] | None = None, *,
         synth_timeout: int | None | object = _TIMEOUT_UNSET,
         flow_timeout: int | None | object = _TIMEOUT_UNSET) -> int:
    """Run with optional, invocation-scoped timeout overrides; None is unlimited."""
    args = build_parser().parse_args(argv)
    # OPTION B (owner 2026-10-07 20:45): setup signs off at TT.  OT_ORFS_CORNER_OVERRIDE=TC (alias OT_ORFS_CORNER, the
    # closure loop's name) keeps every recipe's corner NAMES (WC primary, WC,BC hold; the loop ships its own WC-scene mm
    # hold session into each snapshot) but makes the WC corner READ the TT liberties: WC_NLDM_LIB_FILES =
    # $(TC_NLDM_LIB_FILES) and every macro's WC view = its _tt.lib.  Setup repair runs at TT; hold stays at BC (FF).
    # v1 (renaming the corner to TC, 852d9b461 / c10b5fc9a) died in floorplan report_metrics: STA-0102 (hbm-blocks
    # 4aadc92bc).
    _ot_cov = (os.environ.get("OT_ORFS_CORNER_OVERRIDE", "") or os.environ.get("OT_ORFS_CORNER", "")).strip().upper()
    if _ot_cov == "TC":
        try:
            ORFS_CORNER_MACRO_TAG["WC"] = "tt"
        except NameError:
            pass
        args.orfs_var = list(args.orfs_var or []) + ["WC_NLDM_LIB_FILES=$(TC_NLDM_LIB_FILES)"]
        print("OT_ORFS_CORNER_OVERRIDE=TC: corner WC reads the TT liberties (std cells + macro _tt.lib)", file=sys.stderr)
    _ot_rhc = os.environ.get("OT_ROUTE_HOLD_CORNERS", "").strip()
    if _ot_rhc == "mm":
        # FLOW-HOLD (2026-10-07): multi-mode route-time repair, SS setup (scene WC) + FF hold (scene BC) each under its
        # own constraints (tools/orfs_hold_mm.tcl, patched into the flow container by tools/orfs_hold_mm.py)
        _ot_p = args.orfs_corner or (args.hold_corners or "WC").split(",")[0].strip()
        args.hold_corners = ",".join(dict.fromkeys([_ot_p, "BC"]))
        args.orfs_var = list(args.orfs_var or []) + ["OT_HOLD_MM=1"]
        _ot_ff = " ".join(("/src/" + f.lstrip("/")) if not f.startswith("/src/") else f
                          for f in os.environ.get("OT_MM_FF_SDC", "").split() if f)
        if _ot_ff:
            args.orfs_var.append(f"OT_MM_FF_SDC={_ot_ff}")
        print(f"OT_ROUTE_HOLD_CORNERS=mm: repair scenes {args.hold_corners} (SS setup + FF hold), FF SDCs [{_ot_ff}]",
              file=sys.stderr)
        _ot_rhc = ""
    if _ot_rhc and args.hold_corners:
        # closure loop (2026-10-07): route-time repair corners; "primary" = --orfs-corner (or the first listed corner)
        _ot_new = (args.orfs_corner or args.hold_corners.split(",")[0].strip()) if _ot_rhc == "primary" else _ot_rhc
        # a step hook that times a dropped corner by name (s81_ph vclk_latency.tcl: report_clock_latency -scenes BC)
        # would error (counted as an ORFS flow error) and fall back to a different IO model: keep the corners then
        _ot_drop = [c.strip() for c in args.hold_corners.split(",") if c.strip() not in _ot_new.split(",")]
        _ot_seen, _ot_todo, _ot_hit = set(), [h.split("=", 1)[-1] for h in (args.step_tcl or [])], None
        while _ot_todo and _ot_drop and not _ot_hit:
            _ot_f = _ot_todo.pop()
            _ot_p = Path(_ot_f[5:] if _ot_f.startswith("/src/") else _ot_f)
            if str(_ot_p) in _ot_seen or not _ot_p.is_file():
                continue
            _ot_seen.add(str(_ot_p))
            _ot_t = _ot_p.read_text(errors="replace")
            if any(re.search(rf"(-scenes|-corner|ot_clk_ins)\s+{re.escape(c)}\b", _ot_t) for c in _ot_drop):
                _ot_hit = str(_ot_p)
            _ot_todo += re.findall(r"^\s*source\s+(\S+)", _ot_t, re.M)
        if _ot_hit:
            print(f"OT_ROUTE_HOLD_CORNERS={_ot_rhc}: kept {args.hold_corners}: step hook {_ot_hit} times corner(s) "
                  f"{_ot_drop} by name", file=sys.stderr)
        else:
            print(f"OT_ROUTE_HOLD_CORNERS={_ot_rhc}: place-and-route repair corners {args.hold_corners} -> {_ot_new} "
                  f"(FF hold: post-route hold ECO; sign-off unchanged)", file=sys.stderr)
            args.hold_corners = _ot_new
    _ot_mvt = os.environ.get("OT_MULTI_VT", "").strip().lower()
    if _ot_mvt:
        # MULTI-VT (2026-10-07, opt-in): RVT netlist from synthesis, LVT (and SLVT) as repair_timing VT-swap targets
        _ot_vts = {"lvt": "RVT LVT", "lvt+slvt": "RVT LVT SLVT"}.get(_ot_mvt)
        if _ot_vts is None:
            print(f"OT_MULTI_VT={_ot_mvt!r}: expected lvt or lvt+slvt", file=sys.stderr)
            return 2
        if args.vt is not None and args.vt.split() != _ot_vts.split():
            print(f"OT_MULTI_VT={_ot_mvt} conflicts with --vt {args.vt!r}", file=sys.stderr)
            return 2
        args.vt = _ot_vts
        args.orfs_var = list(args.orfs_var or []) + [f"OT_MULTI_VT={_ot_mvt}"]
        print(f"OT_MULTI_VT={_ot_mvt}: ASAP7_USE_VT '{_ot_vts}' (synthesis RVT only; VT swap in repair_timing)",
              file=sys.stderr)
    previous = {}
    try:
        for option, override, env, callback in (
            ("synth_timeout_seconds", synth_timeout, "OT_SYNTH_TIMEOUT_SECONDS", synth_timeout_seconds),
            ("flow_timeout_seconds", flow_timeout, "OT_FLOW_TIMEOUT_SECONDS", flow_timeout_seconds),
        ):
            if hasattr(args, option):
                override = getattr(args, option)
            if override is _TIMEOUT_UNSET:
                continue
            previous[env] = os.environ.get(env)
            os.environ[env] = "unlimited" if override is None else str(override)
            callback()  # Validate before starting any tools.
        return _main(args, argv=argv)
    finally:
        for env, value in previous.items():
            if value is None:
                os.environ.pop(env, None)
            else:
                os.environ[env] = value


def _main(args: argparse.Namespace, *, argv: list[str] | None = None) -> int:
    global ROOT

    if args.source_root:
        source_root = Path(args.source_root).resolve()
        if not (source_root / "rtl").is_dir():
            print(f"--source-root {source_root} has no rtl/ directory", file=sys.stderr)
            return 2
        ROOT = source_root
    else:
        ROOT = DRIVER_ROOT

    output = Path(args.output)
    if not output.is_absolute():
        output = ROOT / output
    if output.exists() and not args.force:
        print(f"refusing to overwrite existing output: {output} (use --force)", file=sys.stderr)
        return 2

    stages = [s.strip() for s in args.stages.split(",") if s.strip()]
    for stage in stages:
        if stage not in {"synth", "sta", "pnr"}:
            print(f"unknown stage: {stage}", file=sys.stderr)
            return 2
    if "sta" in stages and "synth" not in stages:
        print("stage sta requires stage synth", file=sys.stderr)
        return 2

    view = VIEWS[args.view]

    # ``--vt`` is a place-and-route parameter, not a view identity: the view still
    # names the same PDK and the same corner, and only the cell flavour ORFS is
    # allowed to size with changes.  Copy rather than mutate the module-level
    # VIEWS entry, so one process cannot leak the choice into a later run.
    if args.vt is not None:
        flavours = args.vt.split()
        if not flavours:
            print("--vt needs at least one flavour", file=sys.stderr)
            return 2
        allowed = {"RVT", "LVT", "SLVT"}
        unknown = [f for f in flavours if f not in allowed]
        if unknown:
            print(f"--vt: unknown flavour(s) {unknown}; choose from {sorted(allowed)}",
                  file=sys.stderr)
            return 2
        if view.get("pnr") is None:
            print(f"--vt: view {args.view} has no place-and-route platform", file=sys.stderr)
            return 2
        view = dict(view)
        view["pnr"] = dict(view["pnr"])
        view["pnr"]["extra_config"] = dict(view["pnr"]["extra_config"])
        view["pnr"]["extra_config"]["ASAP7_USE_VT"] = " ".join(flavours)

    if args.orfs_var:
        # --orfs-var KEY=VALUE: an ORFS variable set verbatim in config.mk (e.g. PDN_TCL for a
        # die-level power grid); recorded with the view under pnr.extra_config
        if view.get("pnr") is None:
            print(f"--orfs-var: view {args.view} has no place-and-route platform", file=sys.stderr)
            return 2
        view = dict(view)
        view["pnr"] = dict(view["pnr"])
        view["pnr"]["extra_config"] = dict(view["pnr"]["extra_config"])
        for item in args.orfs_var:
            key, sep, value = item.partition("=")
            if not sep or not re.fullmatch(r"[A-Z][A-Z0-9_]*", key):
                print(f"--orfs-var {item!r}: expected KEY=VALUE", file=sys.stderr)
                return 2
            view["pnr"]["extra_config"][key] = value

    adder_map = ADDER_MAP_PLATFORM if args.asap7_adder_map else ADDER_MAP_KOGGE_STONE
    view = with_adder_map(view, adder_map)

    if args.hold_corners and args.orfs_corner:
        # ORFS CORNERS replaces the primary corner's liberty: a hold list without the primary corner
        # (e.g. --orfs-corner WC --hold-corners BC) would run every setup repair at FF only
        hc = [c.strip() for c in args.hold_corners.split(",")]
        if args.orfs_corner not in hc:
            args.hold_corners = ",".join([args.orfs_corner] + hc)
            print(f"--hold-corners: primary corner {args.orfs_corner} added first -> {args.hold_corners}", file=sys.stderr)
    if args.orfs_corner:
        if view.get("pnr") is None:
            print(f"--orfs-corner: view {args.view} has no place-and-route platform", file=sys.stderr)
            return 2
        view = dict(view)
        view["pnr"] = dict(view["pnr"])
        view["pnr"]["corner_env"] = args.orfs_corner

    try:
        if args.cts_cluster_size is not None and "pnr" not in stages:
            raise ValueError("--cts-cluster-size requires stage pnr")
        view = with_cts_cluster_size(view, args.cts_cluster_size)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    if args.block:
        block = dict(BLOCKS[args.block])
        block_name = args.block
    elif args.top and args.source:
        parameters: dict[str, Any] = {}
        for item in args.param:
            name, _, value = item.partition("=")
            parameters[name] = int(value) if value.lstrip("-").isdigit() else value
        block = {
            "top": args.top,
            "sources": args.source,
            "parameters": parameters,
            "clock_port": args.clock_port,
            "false_path_from_ports": args.false_path_from or [],
            "description": "ad-hoc block supplied on the command line",
        }
        block_name = args.top
    else:
        print("either --block or (--top with at least one --source) is required", file=sys.stderr)
        return 2

    if args.false_path_from is not None:
        block["false_path_from_ports"] = args.false_path_from
    if args.preserve_w11_controller_endpoints:
        block["preserve_w11_controller_endpoints"] = True
        try:
            w11_controller_endpoint_commands(block)
        except FlowError as exc:
            print(str(exc), file=sys.stderr)
            return 2
    if args.sdc_append:
        block["extra_sdc_lines"] = []
        block["extra_sdc_files"] = []
        for f in args.sdc_append:
            path = (ROOT / f) if not Path(f).is_absolute() else Path(f)
            if not path.is_file():
                print(f"--sdc-append: {f} missing", file=sys.stderr)
                return 2
            block["extra_sdc_lines"] += [ln for ln in path.read_text().splitlines()
                                         if ln.strip() and not ln.lstrip().startswith("#")]
            block["extra_sdc_files"].append({"path": f, "sha256": sha256_file(path)})
    if args.core_input_port:
        block["core_input_ports"] = args.core_input_port
    if args.core_input_delay_min_ns is not None or args.core_input_delay_max_ns is not None:
        if (args.core_input_delay_min_ns is None or args.core_input_delay_max_ns is None or
                args.core_input_delay_min_ns < 0 or
                args.core_input_delay_max_ns < args.core_input_delay_min_ns):
            print("core input arrivals require 0 <= min delay <= max delay", file=sys.stderr)
            return 2
        block["core_input_delay_min_ns"] = args.core_input_delay_min_ns
        block["core_input_delay_max_ns"] = args.core_input_delay_max_ns
    if args.ingress_clock_port:
        if (not args.ingress_input_port or args.ingress_input_delay_min_ns is None or
                args.ingress_input_delay_max_ns is None or
                args.ingress_input_delay_min_ns < 0 or
                args.ingress_input_delay_max_ns < args.ingress_input_delay_min_ns):
            print("ingress clock requires input ports and 0 <= min delay <= max delay", file=sys.stderr)
            return 2
        block["ingress_clock_port"] = args.ingress_clock_port
        block["ingress_input_ports"] = args.ingress_input_port
        block["ingress_input_delay_min_ns"] = args.ingress_input_delay_min_ns
        block["ingress_input_delay_max_ns"] = args.ingress_input_delay_max_ns
    if args.io_delay_fraction is not None:
        block["io_delay_fraction"] = args.io_delay_fraction
    if args.clock_uncertainty_ns is not None:
        if args.clock_uncertainty_ns < 0:
            print("--clock-uncertainty-ns must be nonnegative", file=sys.stderr)
            return 2
        block["clock_uncertainty_ns"] = args.clock_uncertainty_ns
        if args.clock_uncertainty_setup_only:
            block["clock_uncertainty_setup_only"] = True
        if args.clock_uncertainty_hold_ns is not None:
            if args.clock_uncertainty_hold_ns < 0 or args.clock_uncertainty_setup_only:
                print("--clock-uncertainty-hold-ns must be nonnegative and excludes --clock-uncertainty-setup-only",
                      file=sys.stderr)
                return 2
            block["clock_uncertainty_hold_ns"] = args.clock_uncertainty_hold_ns
    elif args.clock_uncertainty_setup_only:
        print("--clock-uncertainty-setup-only needs --clock-uncertainty-ns", file=sys.stderr)
        return 2
    if (args.output_delay_min_ns is None) != (args.output_delay_max_ns is None):
        print("--output-delay-min-ns and --output-delay-max-ns go together", file=sys.stderr)
        return 2
    if args.output_delay_min_ns is not None:
        block["output_delay_min_ns"] = args.output_delay_min_ns
        block["output_delay_max_ns"] = args.output_delay_max_ns
    if args.false_path_io:
        block["false_path_io"] = True

    corner_name = args.corner or view["default_corner"]
    if corner_name not in view["corners"]:
        print(f"unknown corner {corner_name} for view {args.view}", file=sys.stderr)
        return 2
    corner = view["corners"][corner_name]

    if "pnr" in stages and not view.get("pnr"):
        print(f"view {args.view} does not support place-and-route", file=sys.stderr)
        return 2

    try:
        constraints = resolve_signal_integrity_constraints(
            view, corner, args.max_transition_ns, args.max_fanout,
            args.slew_margin_percent, args.hold_margin_ns,
            clock_gating=args.clock_gating,
            hold_corners=[c.strip() for c in args.hold_corners.split(",")] if args.hold_corners else None,
        )
    except FlowError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    if (args.memory_macro or args.macro_view) and stages != ["pnr"]:
        print(
            "--memory-macro is a place-and-route option: the macro views live inside "
            "the ORFS image, not on the host, so the host synth and sta stages cannot "
            "see them; run --stages pnr",
            file=sys.stderr,
        )
        return 2

    try:
        floorplan = resolve_floorplan(
            args.die_area, args.core_area, args.pin_region, args.routing_layers,
            args.step_tcl,
        )
        if args.pin_regions_exhaustive:
            if not (floorplan and floorplan.get("pin_regions")):
                raise ValueError("--pin-regions-exhaustive needs --pin-region")
            floorplan["pin_regions_exhaustive"] = True
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    if floorplan and "pnr" not in stages:
        print("--die-area/--core-area/--pin-region/--routing-layers/--step-tcl require stage pnr",
              file=sys.stderr)
        return 2

    try:
        memory_macros = resolve_memory_macros(
            args.view, view, args.memory_macro,
            None if args.macro_view and not args.memory_macro else args.macro_place_halo,
        )
        memory_macros = resolve_macro_views(
            args.view, view, args.macro_view, args.macro_place_halo, memory_macros,
            corners=[c.strip() for c in args.hold_corners.split(",")] if args.hold_corners else None,
        )
    except FlowError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    try:
        dft = resolve_dft(args.dft, args.scan_chains, args.scan_max_length, args.scan_clock_mixing)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    if dft and "pnr" not in stages:
        print("--dft scan is applied to the ORFS netlist; it requires stage pnr", file=sys.stderr)
        return 2
    if getattr(args, "dft_bound_macros", False):
        if not dft or not args.macro_view:
            print("--dft-bound-macros needs --dft scan and at least one --macro-view", file=sys.stderr)
            return 2
        dft["bound_macros"] = {}
        for spec in args.macro_view:
            name, _, mdir = spec.partition("=")
            bb = Path(mdir) / f"{name}_bb.v"
            if not bb.is_absolute():
                bb = (Path.cwd() / bb).resolve()
            dft["bound_macros"][name] = str(bb)
    if dft and args.view not in DFT_SUPPORTED_VIEWS:
        print(f"--dft scan supports views {sorted(DFT_SUPPORTED_VIEWS)}", file=sys.stderr)
        return 2

    workdir_ctx = None
    if args.keep_workdir:
        work = Path(args.keep_workdir)
        if not work.is_absolute():
            work = ROOT / work
        work.mkdir(parents=True, exist_ok=True)
    else:
        # OT_PHYSICAL_WORK_ROOT puts the (deleted-on-exit) work dir on a disk rather than a
        # small /tmp tmpfs; it does not change the record.
        work_root = os.environ.get("OT_PHYSICAL_WORK_ROOT") or None
        if work_root:
            Path(work_root).mkdir(parents=True, exist_ok=True)
        workdir_ctx = tempfile.TemporaryDirectory(prefix="abi3-physical-", dir=work_root)
        work = Path(workdir_ctx.name)

    started = datetime.now(timezone.utc)
    record: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "campaign_id": CAMPAIGN_ID,
        "generated_at": started.isoformat(),
        "git": git_identity(),
        "runner": {
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "argv": ["tools/run_abi3_physical.py", *(argv if argv is not None else sys.argv[1:])],
            "source_root": str(ROOT),
            "driver": driver_identity(),
            **({"orfs_num_cores": orfs_num_cores()} if orfs_num_cores() else {}),
        },
        "view": {
            "name": args.view,
            "description": view["description"],
            "evidence_class": view["evidence_class"],
            "node_nm": view["node_nm"],
            "predictive": view["predictive"],
            "cell_library": view["cell_library"],
            "pdk_lock": view["pdk_lock"],
            "flows_supported": ["synth", "sta"] + (["pnr"] if view.get("pnr") else []),
        },
        "corner": {
            "name": corner_name,
            "process": corner["process"],
            "voltage_v": corner["voltage_v"],
            "temperature_c": corner["temperature_c"],
            "liberty": [
                {
                    "path": str(path),
                    "sha256": sha256_file(Path(path)),
                    "size_bytes": Path(path).stat().st_size,
                }
                for path in corner["liberty"]
            ],
        },
        "design": {
            "block": block_name,
            "top": block["top"],
            "description": block.get("description"),
            "parameters": block["parameters"],
            "clock_port": block["clock_port"],
            **({k: block[k] for k in ("core_input_delay_min_ns", "core_input_delay_max_ns")}
               if "core_input_delay_min_ns" in block else {}),
            **({"core_input_ports": block["core_input_ports"]}
               if block.get("core_input_ports") else {}),
            **({k: block[k] for k in ("ingress_clock_port", "ingress_input_ports",
                                         "ingress_input_delay_min_ns", "ingress_input_delay_max_ns")}
               if block.get("ingress_clock_port") else {}),
            "false_path_from_ports": block["false_path_from_ports"],
            **({"extra_sdc": {"files": block["extra_sdc_files"], "lines": block["extra_sdc_lines"]}}
               if block.get("extra_sdc_lines") else {}),
            "io_delay_fraction": block.get("io_delay_fraction", 0.2),
            **({"clock_uncertainty_ns": block["clock_uncertainty_ns"]}
               if block.get("clock_uncertainty_ns") is not None else {}),
            **({"clock_uncertainty_setup_only": True}
               if block.get("clock_uncertainty_setup_only") else {}),
            **({"clock_uncertainty_hold_ns": block["clock_uncertainty_hold_ns"]}
               if block.get("clock_uncertainty_hold_ns") is not None else {}),
            **({k: block[k] for k in ("output_delay_min_ns", "output_delay_max_ns")}
               if "output_delay_min_ns" in block else {}),
            "false_path_io": bool(block.get("false_path_io", False)),
            **({"preserve_w11_controller_endpoints": True}
               if block.get("preserve_w11_controller_endpoints") else {}),
            "sources": [
                {
                    "path": source,
                    "sha256": sha256_file(ROOT / source),
                    "size_bytes": (ROOT / source).stat().st_size,
                }
                for source in block["sources"]
            ],
        },
        "target_clock_period_ns": args.clock_period_ns,
        "purpose": args.purpose,
        "expected_not_met": bool(args.expected_not_met),
        "target_semantics": (
            "the target clock period is a characterisation probe, not an "
            "operating-point requirement"
            if args.purpose == "characterization"
            else "the target clock period is the intended operating point"
        ),
        "stages_requested": stages,
        "stages_completed": [],
        "flow_completed": False,
        "status": STATUS_ERROR,
    }

    netlist: Path | None = None
    try:
        tools: dict[str, Any] = {}
        if "synth" in stages:
            tools["yosys"] = tool_identity(YOSYS, ["-V"])
            tools["abc"] = {"path": str(YOSYS_ABC), "sha256": sha256_file(YOSYS_ABC)}
        if "sta" in stages:
            tools["opensta"] = tool_identity(STA, ["-version"])
        record["tools"] = tools

        if "synth" in stages:
            cells = scan_liberty([Path(p) for p in corner["liberty"]])
            dont_use = expand_dont_use(view["dont_use"], cells)
            result = run_synthesis(
                view, corner, block, work, args.clock_period_ns, dont_use
            )
            netlist = result["netlist"]
            record["synthesis"] = result["record"]
            record["synthesis"]["liberty_cell_count"] = len(cells)
            record["stages_completed"].append("synth")

        if "sta" in stages:
            assert netlist is not None
            record["static_timing"] = run_sta(
                view, corner, block, work, netlist, args.clock_period_ns, constraints
            )
            if args.fmax_search:
                record["static_timing"]["fmax_search"] = search_fmax(
                    view, corner, block, work, netlist, args.clock_period_ns,
                    constraints=constraints,
                )
            record["stages_completed"].append("sta")

        if "pnr" in stages:
            record["place_and_route"] = run_pnr(
                args.view,
                view,
                block_name,
                block,
                work,
                args.clock_period_ns,
                args.core_utilization,
                args.place_density,
                args.keep_heavy_artifacts,
                output.parent / f"{output.stem}_artifacts",
                constraints,
                memory_macros,
                floorplan,
                dft,
                corner,
                nickname_tag=args.nickname_tag,
                stop_after=args.pnr_stop_after,
            )
            if view["pnr"].get("platform") == "asap7":
                record["place_and_route"]["adder_map"] = adder_map
            if args.cts_cluster_size is not None:
                record["place_and_route"]["clock_tree_config"] = {
                    "CTS_CLUSTER_SIZE": args.cts_cluster_size,
                    "basis": "explicit command-line sink clustering; SDC fanout limit unchanged",
                }
            record["stages_completed"].append("pnr")

        record["flow_completed"] = True
    except Exception as exc:  # noqa: BLE001 - recorded, then reported as an error
        record["flow_completed"] = False
        record["status"] = STATUS_ERROR
        record["error"] = f"{type(exc).__name__}: {exc}"
        record["completed_at"] = datetime.now(timezone.utc).isoformat()
        augment_design(
            record,
            args.lanes,
            args.mac_per_cycle,
            args.mac_rate_evidence,
            args.lane_instance_regex,
            [netlist],
        )
        canonical_dump(record, output)
        print(f"FAILED: {record['error']}", file=sys.stderr)
        print(f"partial record written to {output}", file=sys.stderr)
        if workdir_ctx is not None:
            workdir_ctx.cleanup()
        return 1

    verdict = evaluate_verdict(record)
    record["status"] = verdict["status"]
    record["acceptance"] = {
        "status": verdict["status"],
        "reason": verdict["reason"],
        "checks": verdict["checks"],
        "criterion": (
            "pass requires every timing-bearing stage that ran to meet setup "
            "and hold with zero violating paths; place-and-route additionally "
            "requires finite reported timing and zero DRC, antenna, max-slew, "
            "max-capacitance and max-fanout violations"
        ),
        "note": (
            "status is the engineering result, not whether the script "
            "finished; see flow_completed for that"
        ),
    }
    record["completed_at"] = datetime.now(timezone.utc).isoformat()
    record["elapsed_seconds"] = round(
        (datetime.now(timezone.utc) - started).total_seconds(), 3
    )
    artifact_dir = output.parent / f"{output.stem}_artifacts"
    augment_design(
        record,
        args.lanes,
        args.mac_per_cycle,
        args.mac_rate_evidence,
        args.lane_instance_regex,
        [artifact_dir / "6_final.v", artifact_dir / "1_2_yosys.v", netlist],
    )
    canonical_dump(record, output)

    if workdir_ctx is not None:
        workdir_ctx.cleanup()

    synth = record.get("synthesis", {})
    sta = record.get("static_timing", {})
    pnr = record.get("place_and_route", {})
    print(
        f"view={args.view} corner={corner_name} block={block_name} "
        f"top={block['top']} purpose={args.purpose}"
    )
    if synth:
        print(
            f"  synth: cells={synth['cell_count']} area={synth['cell_area_um2']} um2 "
            f"seq_area={synth['sequential_area_um2']:.3f} um2 macros={synth['macro_count']}"
        )
    if sta:
        print(
            f"  sta:   WNS={sta['setup_wns_ns']:.4f} ns TNS={sta['setup_tns_ns']:.4f} ns "
            f"Fmax={sta['fmax_hz'] / 1e6:.2f} MHz met={sta['timing_met']}"
        )
    if pnr:
        m = pnr["metrics"]
        print(
            f"  pnr:   wirelength={m.get('routed_wirelength_um')} um vias={m.get('vias')} "
            f"DRC={m.get('drc_errors')} antenna_nets={m.get('antenna_violating_nets')} "
            f"Fmax={float(m.get('fmax_hz', 0)) / 1e6:.2f} MHz"
        )
        print(
            f"  drv:   max_slew={m.get('max_slew_violations')} max_cap={m.get('max_cap_violations')} "
            f"max_fanout={m.get('max_fanout_violations')}"
        )
    if constraints:
        print(
            "  sdc:   " + "; ".join(constraints["sdc_lines"])
            + (
                f"; SLEW_MARGIN={constraints['slew_margin_percent']:g}"
                if constraints.get("slew_margin_percent") is not None
                else ""
            )
        )
    if pnr and pnr.get("dft"):
        d = pnr["dft"]
        print(
            f"  dft:   {d['flops']} flops -> {d['chain_count']} chains (max {d['chain_length_max']}), "
            f"{d['scan_cells']} scan cells + {d['scan_mux_cells']} muxed, "
            f"{d['lockup_latches']} lock-up latches, pre-layout +{d['cell_area_added_um2']:.2f} um2"
        )
    if memory_macros:
        halo = memory_macros["macro_place_halo"]
        for macro in memory_macros["macros"]:
            footprint = macro["footprint"]
            print(
                f"  macro: {macro['name']} {macro['capacity_bits']} bits "
                f"({footprint['width_um']} x {footprint['height_um']} um) "
                f"lef={Path(macro['lef']['path']).name} lib={Path(macro['lib']['path']).name}"
            )
        print(
            f"  halo:  {halo['x_um']:g} {halo['y_um']:g} um ({halo['source']}); "
            f"placed macros={pnr.get('metrics', {}).get('macro_count') if pnr else None}"
        )
    design = record["design"]
    if "per_mac_area_um2" in design or "lanes" in design:
        print(
            f"  design: lanes={design.get('lanes')} "
            f"lanes_in_netlist={(design.get('lanes_in_netlist') or {}).get('distinct_lanes')} "
            f"mac_per_cycle={design.get('mac_per_cycle')} cells={design.get('cells')} "
            f"per_mac_area={design.get('per_mac_area_um2')} um2 "
            f"per_mac_period={design.get('per_mac_period_ns')} ns closed={design.get('closed')}"
        )
    verdict_line = f"  STATUS: {record['status'].upper()} ({verdict['reason']})"
    if record["status"] != STATUS_PASS:
        verdict_line += "  <-- failed engineering acceptance"
        if args.expected_not_met:
            verdict_line += " (expected for this corner)"
    print(verdict_line)
    print(f"  wrote {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
