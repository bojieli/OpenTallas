#!/bin/bash
set -eu
export PATH="$HOME/.local/opentallas-tools/verilator-5.050/bin:$PATH"
D=/srv/opentallas-scratch/claude/codex-qw-syscal32-protocol-1020
set +e
bash rtl/test/qwen_split/run_sys_face_native32_protocol.sh "$D/bounded2_clockmut" "$D/src_bounded/protocol_bounded_clockmut" 0
r=$?
set -e
test "$r" != 0
grep -q SYSFACE32_WRAPPER_MISMATCH "$D/bounded2_clockmut/run.log"
echo SYSFACE32_ACTUAL_BOUNDED_CLOCK_MUTANT_CAUGHT
