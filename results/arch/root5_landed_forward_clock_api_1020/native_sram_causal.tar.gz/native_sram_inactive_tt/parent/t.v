module top(input ck_ra, input ck_rb, input d, input xk, output y, output z, output qa, output qb, output ca, output cb);
BUFx4_ASAP7_75t_R pb(.A(xk),.Y(xp));
INVx3_ASAP7_75t_R pi(.A(xk),.Y(xn));
fc_coupon f0(.ck(xp),.d(d),.q(qa),.ck_o(ca));
fc_coupon f1(.ck(xn),.d(d),.q(qb),.ck_o(cb));
ot_sram_1r1w2c_32x64_m1 ram(.wclk(xk),.rclk(ck_ra),.w_ce_in(1'b0),.r_ce_in(1'b0),.w_addr_in(5'b0),.r_addr_in(5'b0),.wd_in(64'b0),.w_mask_in(64'b0),.rd_out());
hard h(.CLK(ck_ra), .D(d), .Q(hq));
DFFHQNx1_ASAP7_75t_R r0 (.CLK(ck_ra), .D(hq), .QN(q0));
DFFHQNx1_ASAP7_75t_R r1 (.CLK(ck_ra), .D(d), .QN(y));
DFFHQNx1_ASAP7_75t_R \u_lpl_0_w.bank_reg  (.CLK(ck_ra), .D(q0), .QN(b0));
DFFHQNx1_ASAP7_75t_R \u_lpl_0_r.o_reg  (.CLK(ck_rb), .D(b0), .QN(l0));
DFFHQNx1_ASAP7_75t_R s0 (.CLK(ck_rb), .D(l0), .QN(z));
endmodule
