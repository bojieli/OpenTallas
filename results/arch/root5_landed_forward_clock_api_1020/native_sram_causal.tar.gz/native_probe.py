import json,sys,pathlib,tempfile,subprocess,shutil,re
sys.path[:0]=['tools/ref_tile','tools/ref_tile/tests']
import test_landed_cluster_kit as K
import clock_entry_constraints as CE
ROOT=pathlib.Path.cwd(); IMAGE=K.IMAGE; OR=K.OR
N=ROOT/'native_inputs/results/arch/s81_halfclock_truth_1020/native35/buf'
case=sys.argv[1] if len(sys.argv)>1 else 'positive'
corner=sys.argv[2] if len(sys.argv)>2 else 'tt'
work=ROOT/('native_'+case+'_'+corner);work.mkdir(exist_ok=True)
boundaries={}
for c in CE.CORNERS:
 d=work/('child_'+c);d.mkdir(exist_ok=True)
 text=(N/f'export35e931766/export_{c}.tcl').read_text()
 text=text[:text.index('write_timing_model')]
 text+='''\nsta::find_timing_paths -path_delay min -group_path_count 1
sta::find_timing_paths -path_delay max -group_path_count 1
set source [sta::get_port_pin [get_ports ck]]
set sink [get_pins ff/CLK]
foreach prop {arrival_min_rise arrival_max_rise arrival_min_fall arrival_max_fall} {puts "BOUND $prop [expr {[get_property $sink $prop]-[get_property $source $prop]}]"}
puts CHILD_BOUND_DONE
exit
'''
 (d/'probe.tcl').write_text(text)
 cmd=['docker','run','--rm','-v',f'{N/"orfs"}:/in:ro','-v',f'{d}:/out',IMAGE,OR,'-no_init','-exit','/out/probe.tcl']
 p=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(d/'native.log').write_text(p.stdout)
 assert p.returncode==0 and 'CHILD_BOUND_DONE' in p.stdout,p.stdout[-3000:]
 vals=[float(v) for _,v in re.findall(r'^BOUND (\S+) (\S+)$',p.stdout,re.M)]
 assert len(vals)==4 and min(vals)>=0
 boundaries[c]=dict(boundary=dict(n=1,min=min(vals),mean=sum(vals)/4,max=max(vals)))
w=work/'parent';w.mkdir(exist_ok=True)
K.view(w);s=K.spec(w)
view=w/'fc_coupon';shutil.copytree(N/'export35e931766',view,dirs_exist_ok=True)
(view/'insertion.json').write_text(json.dumps(dict(lib_clock_pin='ck',clock='ck',**boundaries)))
rtl=K.RTL.replace('output y, output z','input xk, output y, output z, output qa, output qb, output ca, output cb')
rtl=rtl.replace('hard h(', '''BUFx4_ASAP7_75t_R pb(.A(xk),.Y(xp));
INVx3_ASAP7_75t_R pi(.A(xk),.Y(xn));
fc_coupon f0(.ck(xp),.d(d),.q(qa),.ck_o(ca));
fc_coupon f1(.ck(xn),.d(d),.q(qb),.ck_o(cb));
hard h(''')
rtl=rtl.replace('u_lpl_0_w.bank_reg','\\u_lpl_0_w.bank_reg ').replace('u_lpl_0_r.o_reg','\\u_lpl_0_r.o_reg ')
(w/'t.v').write_text(rtl);(w/'top.v').write_text(rtl)
s['children'] += [dict(view='fc_coupon',inst='f0'),dict(view='fc_coupon',inst='f1')]
s['sources']=[str(w/'top.v')];s['landed_record']='top_lp_record.json'
s['clock_entry_domains']['core']['inputs'].append('xk')
s['clock_entry_domains']['core']['outputs'] += ['qa','qb','ca','cb']
s['forwarded_clock_ports']=['xk'];s['forwarded_clock_bindings']={'xk':dict(clock='original_fwd',root='original_fwd',pins={'f0/ck':'fc_coupon','f1/ck':'fc_coupon'},outputs={'ca':'f0/ck_o','cb':'f1/ck_o'})}
if case in ('sram_active','sram_inactive'):
 master='ot_sram_1r1w2c_32x64_m1'
 enable='d' if case=='sram_active' else "1'b0"
 instance=f"{master} ram(.wclk(xk),.rclk(ck_ra),.w_ce_in({enable}),.r_ce_in(1'b0),.w_addr_in(5'b0),.r_addr_in(5'b0),.wd_in(64'b0),.w_mask_in(64'b0),.rd_out());"
 rtl=rtl.replace('hard h(', instance+'\nhard h(')
 (w/'t.v').write_text(rtl);(w/'top.v').write_text(rtl)
if case == 'wrong_clock': s['forwarded_clock_bindings']['xk']['clock']='wrong_clock'
if case == 'wrong_root': s['forwarded_clock_bindings']['xk']['root']='core'
if case == 'wrong_master': s['forwarded_clock_bindings']['xk']['pins']['f1/ck']='wrong_master'
if case == 'unbound_pin': del s['forwarded_clock_bindings']['xk']['pins']['f1/ck']
if case == 'unbound_output': del s['forwarded_clock_bindings']['xk']['outputs']['cb']
if case == 'missing_proof': (view/'forwarded_clock.json').unlink()
if case == 'nonunary':
 rtl=rtl.replace('INVx3_ASAP7_75t_R pi(.A(xk),.Y(xn))','NAND2x1_ASAP7_75t_R pi(.A(xk),.B(d),.Y(xn))')
 (w/'t.v').write_text(rtl);(w/'top.v').write_text(rtl)
if case == 'unbound_seq':
 rtl=rtl.replace('hard h(', 'DFFHQNx1_ASAP7_75t_R stray(.CLK(xk),.D(d),.QN(stray_q));\nhard h(')
 (w/'t.v').write_text(rtl);(w/'top.v').write_text(rtl)
(w/'spec.json').write_text(json.dumps(s,indent=2));(work/'native_child_boundary.json').write_text(json.dumps(boundaries,indent=2))
(w/'clocks.tcl').write_text(CE.clocks(s,833.333)+'''\n# Original native coupon interface, independent from the API.
create_clock -name original_fwd -period 833.333 -waveform {23 377} [get_ports xk]
set_clock_latency -source 17 [get_clocks original_fwd]
set_clock_uncertainty -setup 60 [get_clocks original_fwd]
set_clock_uncertainty -hold 25 [get_clocks original_fwd]
''')
clockfile=w/'clocks.tcl'
if case == 'missing_clock': clockfile.write_text(clockfile.read_text().split('# Original native coupon')[0])
if case == 'ambiguous_clock': clockfile.write_text(clockfile.read_text()+'\ncreate_clock -add -name second -period 833.333 [get_ports xk]\n')
if case == 'multi_source': clockfile.write_text(clockfile.read_text().replace('[get_ports xk]', '[get_ports {xk d}]'))
(w/'pre.tcl').write_text('set ::ot_ref_pre_cts 1\n'+CE.generate(s,w)+CE.landed_sdc(s,w))
(w/'post.tcl').write_text('set ::ot_ref_pre_cts 0\nset ::ot_ce_require_wire 1\n'+CE.generate(s,w)+CE.landed_sdc(s,w))
flow='''
set_thread_count 2
set P /OpenROAD-flow-scripts/flow/platforms/asap7
read_lef $P/lef/asap7_tech_1x_201209.lef
read_lef $P/lef/asap7sc7p5t_28_R_1x_220121a.lef
foreach m {hard fc_coupon} {read_lef /w/$m/$m.lef}
foreach l [glob $P/lib/NLDM/*RVT_TT*] {read_liberty $l}
foreach m {hard fc_coupon} {read_liberty /w/$m/${m}_tt.lib}
read_verilog /w/t.v
link_design top
initialize_floorplan -die_area {0 0 200 200} -core_area {5.4 5.4 194.6 194.6} -site asap7sc7p5t
source $P/openRoad/make_tracks.tcl
place_pins -hor_layers M4 -ver_layers M5
source /w/clocks.tcl
source $P/setRC.tcl
set u [[ord::get_db_block] getDbUnitsPerMicron]
set at [dict create h {20 160} f0 {15 15} f1 {105 15}]
set k 0
foreach i [[ord::get_db_block] getInsts] {
 set n [$i getName]
 if {[dict exists $at $n]} {lassign [dict get $at $n] x y;$i setLocation [expr {int($x*$u)}] [expr {int($y*$u)}];$i setPlacementStatus FIRM} else {$i setLocation [expr {int((15+6*$k)*$u)}] [expr {int(130*$u)}];$i setPlacementStatus PLACED;incr k}
}
detailed_placement
set ::ot_ce_cts_roots {ck_ra ck_rb}
set ::ot_ce_landed_cluster 1
set ::ot_ce_counts [dict create hard 1 fc_coupon 2]
source /w/pre.tcl
source /src/physical/common_flow/clock_entries.tcl
clock_tree_synthesis -sink_clustering_enable -buf_list BUFx4_ASAP7_75t_R -root_buf BUFx4_ASAP7_75t_R
estimate_parasitics -placement
set_propagated_clock [all_clocks]
source /w/post.tcl
puts ACTUAL_NATIVE_FORWARD_PAIR_PASS
'''
if case in ('sram_active','sram_inactive'):
 macro='/src/physical/asap7_memory_macros_v2/ot_sram_1r1w2c_32x64_m1/ot_sram_1r1w2c_32x64_m1'
 flow=flow.replace('read_verilog /w/t.v',f'read_lef {macro}.lef\nread_liberty {macro}_tt.lib\nread_verilog /w/t.v')
 flow=flow.replace('set at [dict create h {20 160}', 'set at [dict create ram {100 100} h {20 160}')
flow=flow.replace('*RVT_TT*','*RVT_'+corner.upper()+'*').replace('${m}_tt.lib','${m}_'+corner+'.lib')
if case == 'wrong_polarity':
 flow=flow.replace('source /w/post.tcl', 'create_generated_clock -name wrong_phase -source [get_ports xk] -divide_by 1 [get_pins pi/Y]\nsource /w/post.tcl')
if case == 'changed_ownership':
 flow=flow.replace('source /w/post.tcl', 'dict set ::ot_ce_fwd_identity f1/ck {xk original_fwd original_fwd fc_coupon 0}\nsource /w/post.tcl')
if case == 'fall_only_skew':
 # Causal observation corruption only; not physically qualified insertion.
 post=w/'post.tcl'
 post.write_text(post.read_text().replace('return [lindex $values 0]', 'if {[get_full_name $pin] eq "f1/ck" && $source_edge eq "fall"} {return [expr {[lindex $values 0]+40.0}]}\n  return [lindex $values 0]'))
(w/'run.tcl').write_text(flow)
p=subprocess.run(['docker','run','--rm','-v',f'{w}:/w','-v',f'{ROOT}:/src:ro',IMAGE,OR,'-no_init','-exit','/w/run.tcl'],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(w/'native.log').write_text(p.stdout)
print(p.stdout,flush=True);print('NATIVE_PARENT_RC',p.returncode,flush=True)
raise SystemExit(p.returncode)
