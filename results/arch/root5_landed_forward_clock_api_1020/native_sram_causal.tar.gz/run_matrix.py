import subprocess,pathlib,json
rs=[]
for case in ['sram_active','sram_inactive']:
 p=subprocess.run(['python3','-u','native_probe.py',case,'tt'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 pathlib.Path(case+'.log').write_text(p.stdout)
 rs.append(dict(case=case,rc=p.returncode,physical_reject='unbound physical sequential/SRAM/gating/data endpoint ram/wclk' in p.stdout))
 print(rs[-1],flush=True)
pathlib.Path('MATRIX_RESULTS.json').write_text(json.dumps(rs,indent=2))
raise SystemExit(0 if all(r['rc']!=0 and r['physical_reject'] for r in rs) else 1)
