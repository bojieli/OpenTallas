read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7_tech_1x_201209.lef
read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7sc7p5t_28_R_1x_220121a.lef
read_liberty /OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_AO_RVT_FF_nldm_211120.lib.gz
read_liberty /OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_INVBUF_RVT_FF_nldm_220122.lib.gz
read_liberty /OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_OA_RVT_FF_nldm_211120.lib.gz
read_liberty /OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_SEQ_RVT_FF_nldm_220123.lib
read_liberty /OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_SIMPLE_RVT_FF_nldm_211120.lib.gz
read_db /in/results/asap7/fc_coupon/base/6_final.odb
set ::ot_ce_corner ff
read_spef /in/results/asap7/fc_coupon/base/6_final.spef
read_sdc /in/results/asap7/fc_coupon/base/6_final.sdc
set_propagated_clock [all_clocks]
puts "OT_WS max [sta::worst_slack_cmd max] min [sta::worst_slack_cmd min]"

sta::find_timing_paths -path_delay min -group_path_count 1
sta::find_timing_paths -path_delay max -group_path_count 1
set source [sta::get_port_pin [get_ports ck]]
set sink [get_pins ff/CLK]
foreach prop {arrival_min_rise arrival_max_rise arrival_min_fall arrival_max_fall} {puts "BOUND $prop [expr {[get_property $sink $prop]-[get_property $source $prop]}]"}
puts CHILD_BOUND_DONE
exit
