# OT_CLOCK_ENTRY_DOMAIN_API_VERSION 1
create_clock -name core_clk -period 833.333000000
create_clock -name ot_io_rb -period 833.333000000
create_clock -name ot_entry_0 -period 833.333000000 [get_ports {ck_ra}]
create_clock -name ot_entry_1 -period 833.333000000 [get_ports {ck_rb}]

# Original native coupon interface, independent from the API.
create_clock -name original_fwd -period 833.333 -waveform {23 377} [get_ports xk]
set_clock_latency -source 17 [get_clocks original_fwd]
set_clock_uncertainty -setup 60 [get_clocks original_fwd]
set_clock_uncertainty -hold 25 [get_clocks original_fwd]

create_clock -add -name second -period 833.333 [get_ports xk]
