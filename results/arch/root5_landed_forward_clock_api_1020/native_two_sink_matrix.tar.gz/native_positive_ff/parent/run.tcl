
set_thread_count 2
set P /OpenROAD-flow-scripts/flow/platforms/asap7
read_lef $P/lef/asap7_tech_1x_201209.lef
read_lef $P/lef/asap7sc7p5t_28_R_1x_220121a.lef
foreach m {hard fc_coupon} {read_lef /w/$m/$m.lef}
foreach l [glob $P/lib/NLDM/*RVT_FF*] {read_liberty $l}
foreach m {hard fc_coupon} {read_liberty /w/$m/${m}_ff.lib}
read_verilog /w/t.v
link_design top
initialize_floorplan -die_area {0 0 200 200} -core_area {5.4 5.4 194.6 194.6} -site asap7sc7p5t
source $P/openRoad/make_tracks.tcl
place_pins -hor_layers M4 -ver_layers M5
source /w/clocks.tcl
source $P/setRC.tcl
set u [[ord::get_db_block] getDbUnitsPerMicron]
set at [dict create h {20 160} f0 {15 15} f1 {105 15}]
set k 0
foreach i [[ord::get_db_block] getInsts] {
 set n [$i getName]
 if {[dict exists $at $n]} {lassign [dict get $at $n] x y;$i setLocation [expr {int($x*$u)}] [expr {int($y*$u)}];$i setPlacementStatus FIRM} else {$i setLocation [expr {int((15+6*$k)*$u)}] [expr {int(130*$u)}];$i setPlacementStatus PLACED;incr k}
}
detailed_placement
set ::ot_ce_cts_roots {ck_ra ck_rb}
set ::ot_ce_landed_cluster 1
set ::ot_ce_counts [dict create hard 1 fc_coupon 2]
source /w/pre.tcl
source /src/physical/common_flow/clock_entries.tcl
clock_tree_synthesis -sink_clustering_enable -buf_list BUFx4_ASAP7_75t_R -root_buf BUFx4_ASAP7_75t_R
estimate_parasitics -placement
set_propagated_clock [all_clocks]
source /w/post.tcl
puts ACTUAL_NATIVE_FORWARD_PAIR_PASS
