# clock_entries.tcl -- strict hard-entry checks; hybrid_entries additionally builds declared glue roots.
#
# A WIRES-ONLY cluster has no register of its own, so it has no tree to build: every hard child takes its clock from
# its OWN port on the cluster face (RTL: port -> child clock pin, one net, one sink).  The die delivers phi - R_i at
# entry i, R_i = entry wire + the child's routed boundary insertion (views/<child>/insertion.json), so no child waits
# for the slowest one and the cluster adds no insertion of its own (a spine over 9 children measured 1.5 - 2.3 ns).
#
# Source it FIRST in pre_cts.tcl (the io_ref wrappers wrap this one).  It replaces clock_tree_synthesis by a check:
# every clock source port must drive exactly one hard-child clock pin and nothing else; a clock port that reaches a
# standard-cell register is an ERROR (that register belongs in a leaf).  Long entry wires (> OT_ENTRY_WIRE_MAX_UM,
# default 60) are reported: put the entry pin at the child's clock pin.
# Only generator-validated raw Liberty memories with exact instance/pin/root
# bindings may be ordinary sinks of glue CTS. Hard-child entries stay exclusive.
proc ot_ce_raw_memory_sink {inst pin source} {
  if {$inst eq "NULL" || ![[$inst getMaster] isBlock]} {return 0}
  set master [[$inst getMaster] getName]
  if {[info exists ::ot_ce_counts] && [dict exists $::ot_ce_counts $master]} {return 0}
  set name [string map {\\ {}} [$inst getName]]
  if {![info exists ::ot_ce_raw_memory_bindings]} {return 0}
  # KV-HOST6 10-20: a pin-register wrapper (ref_tile pin_regs) prefixes the core as u_ot_pr_core; the spec binding names
  # the core instance exactly as place.tcl's ot_ref_wrapped_match does
  if {![dict exists $::ot_ce_raw_memory_bindings $name]} {
    if {![regsub {^u_ot_pr_core[./]} $name {} core] || ![dict exists $::ot_ce_raw_memory_bindings $core]} {return 0}
    set name $core
  }
  set b [dict get $::ot_ce_raw_memory_bindings $name]
  set leaf [lindex [split [get_full_name $pin] /] end]
  if {[dict exists $b clock_pins]} {
    # dual-clock raw memory: each actual Liberty clock pin is a sink of exactly its own bound region root
    set cps [dict get $b clock_pins]
    if {$master ne [dict get $b master] || ![dict exists $cps $leaf] || $source ne [dict get $cps $leaf]} {
      error "OT_HYBRID: raw memory $name actual master/pin/source differs from its exact source binding"
    }
    set key "$name/$leaf"
  } else {
    if {$master ne [dict get $b master] || $leaf ne [dict get $b clock_pin] || $source ne [dict get $b root]} {
      error "OT_HYBRID: raw memory $name actual master/pin/source differs from its exact source binding"
    }
    set key $name
  }
  if {[dict exists $::ot_ce_raw_memory_seen $key]} {error "OT_HYBRID: duplicate raw memory clock sink $key"}
  dict set ::ot_ce_raw_memory_seen $key 1
  return 1
}
proc ot_ce_raw_memory_expected {} {
  set keys {}
  dict for {name b} $::ot_ce_raw_memory_bindings {
    if {[dict exists $b clock_pins]} {
      foreach leaf [dict keys [dict get $b clock_pins]] {lappend keys "$name/$leaf"}
    } else {lappend keys $name}
  }
  return [lsort $keys]
}
# TW-HBM-COLLP 10-19: a landed hard child's clock pin may carry only timing checks (a capture domain with no clk->Q arc
# in the ETM, e.g. the COLL writer's clk_rgx_data* landing captures).  OpenSTA does not list it in all_registers
# -clock_pins, but it is a Liberty clock pin and an ordinary sink of its region root (the post-CTS SDC measures it and
# fails closed on unbound or uncounted pins).  Liberty attribute only: no mode-dependent timing-graph query.
proc ot_ce_check_only_clock_pin {pin} {
  set lc [get_lib_cells -quiet -of_objects [get_cells -quiet -of_objects $pin]]
  if {[llength $lc] != 1} {return 0}
  set name [get_property $pin lib_pin_name]
  foreach lp [get_lib_pins -quiet -of_objects $lc] {
    if {[get_property $lp name] eq $name} {return [expr {[get_property $lp is_clock] == 1}]}
  }
  return 0
}
if {[info procs clock_tree_synthesis] ne "" && [info procs ot_ce_cts_orig] eq ""} {
  rename clock_tree_synthesis ot_ce_cts_orig
  proc clock_tree_synthesis {args} {
    set block [ord::get_db_block]
    set lim [expr {[info exists ::env(OT_ENTRY_WIRE_MAX_UM)] ? $::env(OT_ENTRY_WIRE_MAX_UM) : 60.0}]
    set dbu [expr {double([$block getDbUnitsPerMicron])}]
    set n 0; set bad 0; set far 0; set cts_nets {}; set cts_seen {}; set entry_nets {}
    set ::ot_ce_raw_memory_seen [dict create]
    set ot_ce_unused_hits 0
    set roots [expr {[info exists ::ot_ce_cts_roots] ? $::ot_ce_cts_roots : {}}]
    set forwarded {};set forwarded_seen {}
    if {[info exists ::ot_ce_fwd_bindings] && [dict size $::ot_ce_fwd_bindings]} {
      if {![llength [info commands ot_ce_fwd_cts_prepare]]} {error "OT_FORWARDED: missing strict native preflight"}
      set forwarded [ot_ce_fwd_cts_prepare]
    }
    foreach clk [all_clocks] {
      foreach src [get_property $clk sources] {
        set pname [get_full_name $src]
        set bt [$block findBTerm $pname]
        if {$bt eq "NULL"} { puts "OT_ENTRIES ERROR: clock source $pname is not a top port"; incr bad; continue }
        set net [$bt getNet]
        if {$pname in $forwarded} {
          set binding [dict get $::ot_ce_fwd_bindings $pname]
          if {[get_full_name $clk] ne [dict get $binding clock] || $pname in $forwarded_seen || $pname in $roots} {error "OT_FORWARDED: ambiguous/conflicting CTS source $pname"}
          set endpoints [get_fanout -flat -endpoints_only -from $src];set actual_endpoints {}
          foreach pin $endpoints {
            ot_ce_fwd_cts_endpoint $pname $pin
            lappend actual_endpoints [get_full_name $pin]
          }
          set expected_endpoints [concat [dict keys [dict get $binding pins]] [dict keys [dict get $binding outputs]]]
          foreach endpoint $actual_endpoints {
            if {$endpoint ni $expected_endpoints} {error "OT_FORWARDED: unbound actual endpoint $pname/$endpoint"}
          }
          # Native clock-forwarding ETMs can make a clock pin an internal graph
          # vertex rather than an endpoint. The strict preflight independently
          # enumerates every actual sequential/check-only role and validates
          # every bound pin's native clock path. All output escapes must remain
          # actual endpoints with exact native output provenance.
          foreach output [dict keys [dict get $binding outputs]] {
            if {$output ni $actual_endpoints} {error "OT_FORWARDED: declared output is not reached by this source $pname/$output"}
          }
          lappend forwarded_seen $pname;lappend cts_nets [$net getName]
          puts "OT_FORWARDED CTS_SOURCE $pname clock=[get_full_name $clk] endpoints=[llength $actual_endpoints] native_complete"
          continue
        }
        if {$pname in $roots} {
          if {$pname in $cts_seen} { error "OT_HYBRID: duplicate CTS source $pname" }
          lappend cts_seen $pname
          set endpoints [get_fanout -flat -endpoints_only -from $src]
          set registers [all_registers -clock [get_full_name $clk] -clock_pins]
          if {![llength $registers]} { error "OT_HYBRID: CTS source $pname has no registers" }
          set regnames {}
          foreach pin $registers { lappend regnames [get_full_name $pin] }
          foreach pin $endpoints {
            set cell [get_cells -quiet -of_objects $pin]
            if {[llength $cell] != 1} { error "OT_HYBRID: CTS source $pname reaches a non-register endpoint" }
            # STA renders escaped identifiers differently from OpenDB names.
            # Convert the actual instance object rather than reparsing its name.
            set inst [sta::sta_to_db_inst [lindex $cell 0]]
            if {[ot_ce_raw_memory_sink $inst $pin $pname]} {continue}
            # PL-KIT 10-18 landed cluster (ref_tile clock_entry_constraints.landed_cluster): a bound hard child's clock
            # pin is an ordinary sink of its region root (the post-CTS SDC measures it at the child's flops); HF-4d 10-19:
            # so is a bound RAW SRAM clock pin of that child (::ot_ce_landed_raw, leaf closed record; no ETM arcs, judged
            # post-CTS against its co-timed CTS-root pin)
            # TW-HBM-COLLP 10-19: so is a CHECK-ONLY Liberty clock pin of that child (setup/hold arcs, no clk->Q, so not in
            # all_registers), e.g. the COLL writer's clk_rgx_data* landing captures
            if {[info exists ::ot_ce_landed_cluster] && $::ot_ce_landed_cluster && $inst ne "NULL" && [[$inst getMaster] isBlock]
                && [info exists ::ot_ce_counts] && [dict exists $::ot_ce_counts [[$inst getMaster] getName]]
                && ([get_full_name $pin] in $regnames
                    || [ot_ce_check_only_clock_pin $pin]
                    || ([info exists ::ot_ce_landed_raw]
                        && [dict exists $::ot_ce_landed_raw "[[$inst getMaster] getName]/[get_property $pin lib_pin_name]"]))} {continue}
            # HBM-PGLG2 10-19: an UNLOADED input pin of a bound landed hard child (::ot_ce_landed_unused, from the
            # child's closed-route ROUTED NETLIST via ref_tile clock_entry_constraints.landed_unused_pins: no load, no
            # arc, never by name) may hang on its region root: not a sink, nothing to time (KIND0 clk_insert_0..3)
            if {[info exists ::ot_ce_landed_cluster] && $::ot_ce_landed_cluster && $inst ne "NULL" && [[$inst getMaster] isBlock]
                && [info exists ::ot_ce_counts] && [dict exists $::ot_ce_counts [[$inst getMaster] getName]]
                && [info exists ::ot_ce_landed_unused]
                && [dict exists $::ot_ce_landed_unused "[[$inst getMaster] getName]/[get_property $pin lib_pin_name]"]} {
              incr ot_ce_unused_hits
              continue
            }
            if {$inst eq "NULL" || [[$inst getMaster] isBlock] || [get_full_name $pin] ni $regnames} {
              error "OT_HYBRID: CTS source $pname must reach only standard-cell clock pins"
            }
          }
          lappend cts_nets [$net getName]
          continue
        }
        set sinks {}
        foreach it [$net getITerms] { if {[$it isInputSignal]} { lappend sinks $it } }
        if {[llength $sinks] != 1} {
          puts "OT_ENTRIES ERROR: clock entry $pname drives [llength $sinks] pins (one hard-child clock pin per entry)"
          incr bad; continue
        }
        set it [lindex $sinks 0]
        set inst [$it getInst]
        if {![[$inst getMaster] isBlock]} {
          puts "OT_ENTRIES ERROR: clock entry $pname drives [$inst getName]/[[$it getMTerm] getName] ([[$inst getMaster] getName]): not a hard child (a cluster register belongs in a leaf)"
          incr bad; continue
        }
        set pb [$bt getBBox]; set ib [$it getBBox]
        set d [expr {(abs(([$pb xMin] + [$pb xMax]) / 2 - ([$ib xMin] + [$ib xMax]) / 2)
                      + abs(([$pb yMin] + [$pb yMax]) / 2 - ([$ib yMin] + [$ib yMax]) / 2)) / $dbu}]
        if {$d > $lim} { incr far }
        lappend entry_nets [list $net $it]
        puts [format "OT_ENTRIES entry %s -> %s/%s (%s) wire %.1f um%s" $pname [$inst getName] [[$it getMTerm] getName] \
                  [[$inst getMaster] getName] $d [expr {$d > $lim ? " LONG" : ""}]]
        incr n
      }
    }
    if {[info exists ::ot_ce_raw_memory_bindings]
        && [ot_ce_raw_memory_expected] ne [lsort [dict keys $::ot_ce_raw_memory_seen]]} {
      error "OT_HYBRID: declared raw-memory clock sinks were not all reached from their granted source roots"
    }
    if {$ot_ce_unused_hits} { puts "OT_LANDED UNUSED_PINS $ot_ce_unused_hits unloaded hard-child input pins on region roots (routed-netlist proven; not sinks)" }
    if {$bad} { error "OT_ENTRIES: $bad clock entries are not port -> one hard-child clock pin" }
    if {[lsort $cts_seen] ne [lsort $roots]} { error "OT_HYBRID: declared CTS root coverage mismatch" }
    if {[lsort $forwarded_seen] ne [lsort $forwarded]} {error "OT_FORWARDED: declared native source coverage mismatch"}
    if {[llength $cts_nets]} {
      if {[lsearch -exact $args -clk_nets] >= 0} { error "OT_HYBRID: caller cannot override declared CTS nets" }
      # TritonCTS splits -clk_nets on whitespace (TritonCTS::setClockNets); a Tcl list braces bus-bit names
      # ({clk_outputs[0]}), which findNet never matches -> CTS-0056 (s81coll_calendar7 gate 10-15). Pass plain words.
      # TritonCTS -repair_clock_nets repairs ALL clock nets, including
      # excluded hard entries (observed clk_macro0 -> wire3581 -> SRAM).
      # Keep those entries as the required one-port/one-pin wire. CTS still
      # builds and balances the explicitly selected standard-cell roots;
      # ordinary timing and post-CTS ownership/insertion checks remain.
      set cts_args $args
      if {$n > 0 && [lsearch -exact $cts_args -repair_clock_nets] >= 0} {
        set cts_args {}
        foreach arg $args {if {$arg ne "-repair_clock_nets"} {lappend cts_args $arg}}
        puts "OT_HYBRID excluded hard entries: in-CTS -repair_clock_nets disabled; selected-root trees repaired after CTS"
      }
      ot_ce_cts_orig {*}$cts_args -clk_nets [join $cts_nets " "]
      # Without long-wire repair the selected-root trees keep unbuffered leaf hops (qfd_tt_head_static h4 gate
      # 10-15: a 300 um clkbuf_6_63__f -> leaf_193 hop added 266 ps, insertion 535.9 / spread 245.8 ps).  Repair
      # the trees AFTER CTS with every hard entry net marked do-not-touch, then prove each entry is still the one
      # port -> one hard-child clock pin wire (fail closed).
      if {[llength $cts_args] != [llength $args]} {
        set ot_ce_prev {}
        foreach e $entry_nets { set en [lindex $e 0]; lappend ot_ce_prev [$en isDoNotTouch]; $en setDoNotTouch 1 }
        # OpenROAD 6cb3f2b704 repair_clock_nets iterates every SDC clock source,
        # including dont_touch hard entries, and errors if a long entry needs a buffer.
        # Repair only the selected soft-root nets. This runs the same resizer net
        # repair engine, with additional slew/cap/fanout checks, without modifying
        # clocks, their latency/phase constraints, or hard-entry connectivity.
        est::check_parasitics
        set ot_ce_max_wire [rsz::check_max_wire_length 0 true]
        foreach name $cts_nets {
          set dn [$block findNet $name]
          if {$dn eq "NULL"} { error "OT_HYBRID: selected repair net $name is missing" }
          rsz::repair_net_cmd [sta::db_net_to_sta $dn] $ot_ce_max_wire 0 0
        }
        foreach e $entry_nets p $ot_ce_prev {
          set en [lindex $e 0]; $en setDoNotTouch $p
          set its {}
          foreach it [$en getITerms] { if {[$it isInputSignal]} { lappend its $it } }
          if {[llength $its] != 1 || [lindex $its 0] ne [lindex $e 1]} {
            error "OT_HYBRID: post-CTS clock repair changed hard entry net [$en getName]"
          }
        }
        puts "OT_HYBRID post-CTS scoped net repair on selected roots; [llength $entry_nets] hard entries unchanged"
      }
      if {[llength $forwarded]} {
        puts "OT_HYBRID CTS roots [join $roots { }]; verified native forwarded roots [join $forwarded { }]; independent hard-child entries excluded"
      } else {
      puts "OT_HYBRID CTS roots [join $roots " "]; hard-child entries excluded"
      }
    }
    if {[llength $cts_nets]} {
      puts "OT_ENTRIES done: $n independent hard entries, [llength $cts_nets] glue CTS roots, $far entry wires over $lim um"
    } else {
      puts "OT_ENTRIES done: $n clock entries, no tree built, $far entry wires over $lim um"
    }
  }
}
