set ::ot_ref_pre_cts 1
# OT_CLOCK_ENTRY_DOMAIN_API_VERSION 1
# AUTO clock entries: bound insertion.json boundary refs; no ETM arc modification.
set ::ot_ce_leaf_roots 1
set ::ot_ce_related_data 1
set ::ot_ce_landed_cluster 1
set ::ot_ce_landed_child_pins 3
set ::ot_ce_fwd_ports {{xk}}
set ::ot_ce_fwd_bindings [dict create {xk} {clock {wrong_clock} root {original_fwd} pins {{f0/ck} {fc_coupon} {f1/ck} {fc_coupon}} outputs {{ca} {f0/ck_o} {cb} {f1/ck_o}}}]
set ::ot_ce_fwd_native_outputs [dict create {f0/ck_o} {master {fc_coupon} input {f0/ck} parity 0 port {ca} bit {xk}} {f1/ck_o} {master {fc_coupon} input {f1/ck} parity 0 port {cb} bit {xk}}]
set ::ot_ce_check_only [dict create {fc_coupon/ck} 1 {hard/CLK} 1]
set ::ot_ce_refs [dict create {hard/CLK} {tt {90.0 100.0 110.0} ff {90.0 100.0 110.0} ss {90.0 100.0 110.0}} {fc_coupon/ck} {tt {0.8705140000000142 0.9106667500000096 0.9497380000000248} ff {0.9027709999999729 0.9405222499999972 0.9789430000000152} ss {0.8502500000000168 0.891799749999997 0.9321589999999986}}]
set ::ot_ce_counts [dict create {hard} 1 {fc_coupon} 2]
set ::ot_ce_domains [dict create {core} {clock core_clk io_budget_ps 166.667 inputs {{d} {xk}} outputs {{y} {qa} {qb} {ca} {cb}}} {rb} {clock ot_io_rb io_budget_ps 166.667 inputs {} outputs {{z}}}]
set ::ot_ce_source_domains [dict create {ck_ra} {core} {ck_rb} {rb}]
set ::ot_ce_explicit_domains 1
set ::ot_ce_cts_roots {{ck_ra} {ck_rb}}
set ::ot_ce_ports {{ck_ra} {ck_rb}}

proc ot_ce_fwd_trace {pin} {
  set block [ord::get_db_block]
  set it [$block findITerm [get_full_name $pin]]
  if {$it in {"" NULL}} {error "OT_FORWARDED: missing physical sink [get_full_name $pin]"}
  set parity 0
  if {[$it getIoType] eq "OUTPUT" && [dict exists $::ot_ce_fwd_native_outputs [get_full_name $pin]]} {
    set native [dict get $::ot_ce_fwd_native_outputs [get_full_name $pin]]
    set parity [dict get $native parity];set it [$block findITerm [dict get $native input]]
  }
  if {$it in {"" NULL} || [$it getIoType] ne "INPUT"} {error "OT_FORWARDED: physical path does not start at a bound clock input/native output"}
  set net [$it getNet]; set seen {}
  while {1} {
    if {$net in {"" NULL} || $net in $seen} {error "OT_FORWARDED: disconnected/cyclic physical path"}
    lappend seen $net
    set ports [$net getBTerms]
    set drivers {}; foreach p [$net getITerms] {if {[$p getIoType] eq "OUTPUT"} {lappend drivers $p}}
    if {[llength $ports]} {
      if {[llength $ports] != 1 || [llength $drivers] || [[lindex $ports 0] getIoType] ne "INPUT"} {error "OT_FORWARDED: aliased or internally driven boundary root"}
      return [list [[lindex $ports 0] getName] $parity]
    }
    if {[llength $drivers] != 1} {error "OT_FORWARDED: physical path needs one driver"}
    set out [lindex $drivers 0]; set inst [$out getInst]; set master [[$inst getMaster] getName]
    if {[dict exists $::ot_ce_counts $master]} {
      set full "[$inst getName]/[[$out getMTerm] getName]"
      if {![info exists ::ot_ce_fwd_native_outputs] || ![dict exists $::ot_ce_fwd_native_outputs $full]} {error "OT_FORWARDED: unsupported/unproven hard-child clock transit"}
      set native [dict get $::ot_ce_fwd_native_outputs $full]
      if {[dict get $native master] ne $master} {error "OT_FORWARDED: native output actual master mismatch"}
      set it [$block findITerm [dict get $native input]]
      if {$it in {"" NULL}} {error "OT_FORWARDED: native input physical pin missing"}
      set parity [expr {$parity ^ [dict get $native parity]}];set net [$it getNet]
      continue
    }
    set inputs {}; set outputs {}
    foreach p [$inst getITerms] {
      if {[$p getIoType] eq "INPUT"} {lappend inputs $p}
      if {[$p getIoType] eq "OUTPUT"} {lappend outputs $p}
    }
    if {[llength $inputs] != 1 || [llength $outputs] != 1} {error "OT_FORWARDED: physical driver is not unary BUF/INV"}
    set input [lindex $inputs 0]; set ip [[$input getMTerm] getName]; set op [[$out getMTerm] getName]
    set functions {}
    foreach library [get_libs -quiet *] {
      set cell [$library find_liberty_cell $master]
      if {$cell in {"" NULL}} continue
      set lp [$cell find_liberty_port $op]
      if {$lp in {"" NULL} || [sta::liberty_port_direction $lp] ne "output"} {error "OT_FORWARDED: invalid Liberty output"}
      dict set functions [string map {" " "" "\t" "" "\n" "" "(" "" ")" ""} [$lp function]] 1
    }
    if {[dict size $functions] != 1} {error "OT_FORWARDED: missing/ambiguous physical Liberty function"}
    set fn [lindex [dict keys $functions] 0]
    if {$fn eq $ip} {set inv 0} elseif {$fn in [list !$ip ~$ip ${ip}']} {set inv 1} else {error "OT_FORWARDED: physical Liberty function is not BUF/INV"}
    set parity [expr {$parity ^ $inv}]; set net [$input getNet]
  }
}
proc ot_ce_fwd_values {pin clock transition source_edge bound judged} {
  set cn [get_full_name $clock]; set scene [get_property [sta::cmd_scene] name]
  set marker [expr {$transition eq "rise" ? "^" : "v"}]; set want [expr {$source_edge eq "rise" ? "^" : "v"}]
  set values {}
  foreach vertex [$pin vertices] {
    if {$vertex eq "NULL"} continue
    set paths [$vertex path_iterator $transition $bound]
    while {[$paths has_next]} {
      set path [$paths next]; set tag [$path tag]
      if {[lindex $tag 1] ne $scene || [lindex $tag 2] ne "${marker}${bound}" || [lindex $tag 3] ne $cn || [string first "(clock prop)" $tag] < 0} continue
      if {[lindex $tag 4] ne $want} {$paths finish; error "OT_FORWARDED: physical Liberty/source phase mismatch [get_full_name $pin] $transition"}
      set value [sta::time_sta_ui [$path arrival]]
      if {![ot_ce_finite $value]} {$paths finish; error "OT_FORWARDED: nonfinite clock arrival"}
      lappend values $value
    }
    $paths finish
  }
  if {[llength $values] != 1} {
    if {!$judged && ![llength $values]} {return ""}
    error "OT_FORWARDED: missing/ambiguous propagated $transition/$bound arrival [get_full_name $pin] clock=$cn"
  }
  return [lindex $values 0]
}
proc ot_ce_fwd_freeze {pin identity} {
  if {![info exists ::ot_ce_fwd_identity]} {set ::ot_ce_fwd_identity {}}
  if {[dict exists $::ot_ce_fwd_identity $pin] && [dict get $::ot_ce_fwd_identity $pin] ne $identity} {error "OT_FORWARDED: immutable pin/bit/clock/root/master/polarity ownership changed $pin"}
  dict set ::ot_ce_fwd_identity $pin $identity
}
proc ot_ce_forwarded_visit {corner} {
  ot_cf_refresh
  set ::ot_ce_fwd_cells {}; set ::ot_ce_fwd_root_names {}; set ::ot_ce_fwd_inputs {}
  set judged [expr {!([info exists ::ot_ref_pre_cts] && $::ot_ref_pre_cts) || ([info exists ::ot_ce_require_wire] && $::ot_ce_require_wire)}]
  if {[info exists ::ot_ce_fwd_cts_preflight] && $::ot_ce_fwd_cts_preflight} {set judged 0}
  set actual_bits {}
  foreach port $::ot_ce_fwd_ports {
    set found [get_ports -quiet $port -filter "direction == input"]
    if {![llength $found]} {set found [get_ports -quiet [format {%s\[*\]} $port] -filter "direction == input"]}
    if {![llength $found]} {error "OT_FORWARDED: missing actual input port $port"}
    foreach p $found {lappend actual_bits [get_full_name $p]}
  }
  if {[lsort -unique $actual_bits] ne [lsort [dict keys $::ot_ce_fwd_bindings]]} {error "OT_FORWARDED: incomplete or foreign actual bit bindings"}
  set expected_pins {}; set seen_pins {}; set groups {}; set hits 0
  dict for {bit binding} $::ot_ce_fwd_bindings {
    set port [get_ports -quiet $bit]; set source [sta::get_port_pin $port]
    set clocks [get_property $source clocks]
    if {[llength $clocks] != 1} {error "OT_FORWARDED: $bit lacks one actual source clock (DATA input delay is not a clock)"}
    set clock [lindex $clocks 0]; set cn [get_full_name $clock]; set root [ot_cf_root $cn]
    set rc [get_clocks -quiet $root]
    set source_points [get_property $clock sources]
    if {[llength $source_points] != 1 || [get_full_name [lindex $source_points 0]] ne $bit || [llength [get_property $rc sources]] != 1} {error "OT_FORWARDED: source clock/root must have one actual source point for this input bit"}
    if {$cn ne [dict get $binding clock] || $root ne [dict get $binding root] || [$rc is_virtual]} {error "OT_FORWARDED: wrong or virtual actual clock/root $bit"}
    if {$judged && ![$clock is_propagated]} {error "OT_FORWARDED: ideal source clock cannot qualify $bit"}
    set wave [$clock waveform]
    if {[llength $wave] != 2 || ![ot_ce_finite [$clock period]] || [$clock period] <= 0} {error "OT_FORWARDED: invalid native clock waveform"}
    foreach v $wave {if {![ot_ce_finite $v]} {error "OT_FORWARDED: nonfinite native waveform"}}
    lappend ::ot_ce_fwd_root_names $root; lappend ::ot_ce_fwd_inputs $bit
    set domain [ot_ce_fwd_domain $bit]
    dict for {full master} [dict get $binding pins] {
      if {[dict exists $expected_pins $full]} {error "OT_FORWARDED: duplicate bound pin $full"}
      dict set expected_pins $full $bit
      set pin [get_pins -quiet $full]
      if {[llength $pin] != 1 || [get_property [get_cells -of_objects $pin] ref_name] ne $master} {error "OT_FORWARDED: actual sink/master mismatch $full"}
      set key "$master/[get_property $pin lib_pin_name]"
      if {![dict exists $::ot_ce_refs $key] || ![dict exists $::ot_ce_counts $master]} {error "OT_FORWARDED: sink lacks actual bound child insertion $full"}
      if {[info exists ::ot_ce_landed_raw] && [dict exists $::ot_ce_landed_raw $key]} {error "OT_FORWARDED: raw SRAM entry requires its unchanged co-timed audit; cannot count as forwarded ETM sink"}
      lassign [ot_ce_fwd_trace $pin] actual_bit parity
      if {$actual_bit ne $bit} {error "OT_FORWARDED: bound pin has wrong actual root bit $full"}
      set owners [get_property $pin clocks]
      if {[llength $owners] != 1 || [get_full_name [lindex $owners 0]] ne $cn} {error "OT_FORWARDED: wrong/ambiguous sink clock or unsupported intermediate generated clock $full"}
      ot_ce_fwd_freeze $full [list $bit $cn $root $master $parity]
      set cell [get_full_name [get_cells -of_objects $pin]]
      if {[dict exists $::ot_ce_fwd_cells $cell] && [dict get $::ot_ce_fwd_cells $cell] ne $domain} {error "OT_FORWARDED: conflicting hard-child domain ownership $cell"}
      if {[dict exists $::ot_ce_landed_owner $cell] && [dict get $::ot_ce_landed_owner $cell] ne $domain} {error "OT_FORWARDED: conflicting region/forwarded ownership $cell"}
      dict set ::ot_ce_fwd_cells $cell $domain
      lassign [dict get $::ot_ce_refs $key $corner] clo mean chi
      foreach v [list $clo $mean $chi] {if {![ot_ce_finite $v]} {error "OT_FORWARDED: nonfinite child insertion"}}
      if {$clo < 0 || $clo > $mean || $mean > $chi} {error "OT_FORWARDED: invalid child insertion bounds"}
      foreach edge {rise fall} {
        set input_edge [expr {$parity ? ($edge eq "rise" ? "fall" : "rise") : $edge}]
        set local {}
        foreach bound {min max} {
          set a [ot_ce_fwd_values $pin $clock $edge $input_edge $bound $judged]
          set b [ot_ce_fwd_values $source $clock $input_edge $input_edge $bound $judged]
          if {$a eq "" || $b eq ""} {set local {}; break}
          lappend local [expr {$a-$b}]
        }
        if {![llength $local]} {puts "OT_FORWARDED UNMEASURED $corner $bit $full $edge pre-CTS";continue}
        lassign $local early late
        if {![ot_ce_finite $early] || ![ot_ce_finite $late] || $early < 0 || $early > $late} {error "OT_FORWARDED: invalid local early/late transfer $full $edge"}
        dict lappend groups [list $bit $input_edge] [list [expr {$early+$clo}] [expr {$late+$chi}]]
        puts "OT_FORWARDED SINK $corner $bit $full clock=$cn root=$root parity=$parity edge=$edge input_edge=$input_edge local=$early..$late child=$clo..$chi"
      }
      dict set seen_pins $full 1; incr hits
    }
    # No source-family sequential clock sink may disappear from the binding census.
    foreach c [all_clocks] {
      set ancestor [get_full_name $c]
      while {$ancestor ne $cn && [dict exists $::ot_cf_master $ancestor]} {set ancestor [dict get $::ot_cf_master $ancestor]}
      if {$ancestor ne $cn} continue
      foreach pin [all_registers -clock $c -clock_pins] {
        set full [get_full_name $pin]
        lassign [ot_ce_fwd_trace $pin] actual_bit ignored
        if {$actual_bit eq $bit && ![dict exists $expected_pins $full]} {error "OT_FORWARDED: unbound true sequential clock sink $full"}
      }
    }
  }
  # Include actual bound check-only pins (not returned by all_registers) and preserve raw/SRAM audits.
  foreach cell [get_cells -quiet -hierarchical *] {
    set master [get_property $cell ref_name]
    if {![dict exists $::ot_ce_counts $master]} continue
    foreach pin [get_pins -quiet -of_objects $cell] {
      set key "$master/[get_property $pin lib_pin_name]"
      if {![dict exists $::ot_ce_refs $key]} continue
      set bit [ot_ce_net_root_port $pin]
      if {[dict exists $::ot_ce_fwd_bindings $bit] && ![dict exists $seen_pins [get_full_name $pin]]} {error "OT_FORWARDED: unbound check-only/raw child clock pin [get_full_name $pin]"}
    }
  }
  foreach bit [dict keys $::ot_ce_fwd_bindings] {ot_ce_fwd_physical_census $bit}
  dict for {key rows} $groups {
    lassign $key bit edge
    set lo [lindex [lindex $rows 0] 0]; set hi [lindex [lindex $rows 0] 1]
    foreach row $rows {set lo [expr {min($lo,[lindex $row 0])}];set hi [expr {max($hi,[lindex $row 1])}]}
    set span [expr {$hi-$lo}]
    if {![ot_ce_finite $lo] || ![ot_ce_finite $hi] || ![ot_ce_finite $span]} {error "OT_FORWARDED: nonfinite child-flop interval"}
    puts "OT_FORWARDED SPREAD $corner $bit input_edge=$edge sinks=[llength $rows] span=$span limit=80 judged=$judged"
    if {$judged && $corner in {tt ff} && $span > 80.0} {error "OT_FORWARDED: $bit/$edge child-flop span $span exceeds80ps"}
  }
  return $hits
}
proc ot_ce_fwd_physical_census {bit} {
  set block [ord::get_db_block];set source [$block findBTerm $bit]
  set pending [list [$source getNet]];set seen {};set found {}
  while {[llength $pending]} {
    set net [lindex $pending end];set pending [lrange $pending 0 end-1]
    if {$net in {"" NULL}} {error "OT_FORWARDED: disconnected clock graph"}
    if {$net in $seen} {error "OT_FORWARDED: cyclic or reconvergent physical clock graph"}
    lappend seen $net
    set drivers {};foreach p [$net getITerms] {if {[$p getIoType] eq "OUTPUT"} {lappend drivers $p}}
    set expected_drivers [expr {$net eq [$source getNet] ? 0 : 1}]
    if {[llength $drivers] != $expected_drivers} {error "OT_FORWARDED: ambiguous/internally-driven physical root net"}
    foreach bt [$net getBTerms] {
      set name [$bt getName]
      if {[$bt getIoType] eq "INPUT"} {
        if {$name ne $bit} {error "OT_FORWARDED: physical input alias $name"}
      } elseif {[$bt getIoType] eq "OUTPUT"} {
        ot_ce_fwd_cts_endpoint $bit [get_ports -quiet $name]
        lappend found $name
      } else {error "OT_FORWARDED: unsupported physical boundary direction"}
    }
    foreach it [$net getITerms] {
      if {[$it getIoType] ne "INPUT"} continue
      set inst [$it getInst];set master [[$inst getMaster] getName]
      set full "[$inst getName]/[[$it getMTerm] getName]"
      if {[dict exists $::ot_ce_counts $master]} {
        set binding [dict get $::ot_ce_fwd_bindings $bit]
        if {![dict exists $binding pins $full] || [dict get $binding pins $full] ne $master || ![dict exists $::ot_ce_refs "$master/[[$it getMTerm] getName]"]} {error "OT_FORWARDED: unbound physical hard-child clock/data pin $full"}
        lappend found $full
        dict for {output proof} $::ot_ce_fwd_native_outputs {
          if {[dict get $proof input] ne $full} continue
          set out [$block findITerm $output]
          if {$out in {"" NULL}} {error "OT_FORWARDED: native output physical pin missing"}
          lappend pending [$out getNet]
        }
        continue
      }
      set inputs {};set outputs {}
      foreach p [$inst getITerms] {
        if {[$p getIoType] eq "INPUT"} {lappend inputs $p}
        if {[$p getIoType] eq "OUTPUT"} {lappend outputs $p}
      }
      # This physical walk sees inactive SRAM clocks too; no timing-path query
      # or get_fanout mode can make an unbound endpoint disappear.
      if {[llength $inputs] != 1 || [llength $outputs] != 1} {error "OT_FORWARDED: unbound physical sequential/SRAM/gating/data endpoint $full"}
      set out [lindex $outputs 0];set op [[$out getMTerm] getName];set ip [[$it getMTerm] getName];set functions {}
      foreach library [get_libs -quiet *] {
        set lc [$library find_liberty_cell $master]
        if {$lc in {"" NULL}} continue
        set lp [$lc find_liberty_port $op]
        if {$lp in {"" NULL}} {error "OT_FORWARDED: missing physical driver Liberty output"}
        dict set functions [string map {" " "" "\t" "" "\n" "" "(" "" ")" ""} [$lp function]] 1
      }
      if {[dict size $functions] != 1 || [lindex [dict keys $functions] 0] ni [list $ip !$ip ~$ip ${ip}']} {error "OT_FORWARDED: physical path is not actual unary BUF/INV $full"}
      set next [$out getNet]
      if {$next in {"" NULL}} {
        puts "OT_FORWARDED PASSIVE_LOAD $full master=$master (native unary BUF/INV output unconnected)"
      } else {lappend pending $next}
    }
  }
  set binding [dict get $::ot_ce_fwd_bindings $bit]
  set expected [concat [dict keys [dict get $binding pins]] [dict keys [dict get $binding outputs]]]
  if {[lsort -unique $found] ne [lsort $expected]} {error "OT_FORWARDED: complete physical pin/BTerm/SRAM census mismatch $bit"}
  return [lsort -unique $found]
}
proc ot_ce_fwd_cts_prepare {} {
  set ::ot_ce_fwd_cts_preflight 1
  try {
    ot_ce_forwarded_visit [ot_ce_corner]
    foreach bit [dict keys $::ot_ce_fwd_bindings] {ot_ce_fwd_physical_census $bit}
  } finally {set ::ot_ce_fwd_cts_preflight 0}
  return [dict keys $::ot_ce_fwd_bindings]
}
proc ot_ce_fwd_cts_endpoint {bit pin} {
  set binding [dict get $::ot_ce_fwd_bindings $bit];set full [get_full_name $pin]
  if {[sta::object_type $pin] eq "Port" || ([sta::object_type $pin] eq "Pin" && [$pin is_top_level_port])} {
    if {![dict exists $binding outputs $full]} {error "OT_FORWARDED: unbound output/nonsequential endpoint $full"}
    set block [ord::get_db_block];set bt [$block findBTerm $full]
    if {$bt in {"" NULL} || [$bt getIoType] ne "OUTPUT"} {error "OT_FORWARDED: output endpoint is not an actual output"}
    set drivers {};foreach it [[$bt getNet] getITerms] {if {[$it getIoType] eq "OUTPUT"} {lappend drivers $it}}
    if {[llength $drivers] != 1} {error "OT_FORWARDED: ambiguous clock-output driver"}
    set it [lindex $drivers 0];set actual "[[$it getInst] getName]/[[$it getMTerm] getName]"
    if {$actual ne [dict get $binding outputs $full] || ![dict exists $::ot_ce_fwd_native_outputs $actual]} {error "OT_FORWARDED: output lacks matching actual native source"}
    set pin [get_pins -quiet $actual]
  } else {
    if {![dict exists $binding pins $full]} {error "OT_FORWARDED: unbound true sequential/SRAM/data endpoint $full"}
    if {[get_property [get_cells -of_objects $pin] ref_name] ne [dict get $binding pins $full]} {error "OT_FORWARDED: endpoint master mismatch"}
    set key "[get_property [get_cells -of_objects $pin] ref_name]/[get_property $pin lib_pin_name]"
    if {![dict exists $::ot_ce_refs $key]} {error "OT_FORWARDED: endpoint has no actual child clock role"}
  }
  lassign [ot_ce_fwd_trace $pin] actual_bit parity
  if {$actual_bit ne $bit} {error "OT_FORWARDED: endpoint root bit mismatch"}
  set owners [get_property $pin clocks]
  if {[llength $owners] != 1 || [get_full_name [lindex $owners 0]] ne [dict get $binding clock]} {error "OT_FORWARDED: endpoint actual clock mismatch"}
  return 1
}
proc ot_ce_fwd_domain {port} {
  regsub {\[[0-9]+\]$} $port {} base
  set owners {}
  dict for {domain info} $::ot_ce_domains {
    foreach p [dict get $info inputs] {if {$p eq $base || $p eq $port} {lappend owners $domain;break}}
  }
  if {[llength $owners] != 1} {error "OT_FORWARDED: $port lacks one data-domain owner"}
  return [lindex $owners 0]
}
# Actual OpenSTA clock ancestry and physical propagated-clock measurements.
# OpenSTA's Clock wrapper has no master accessor. Its canonical SDC exporter
# resolves inferred masters; evaluate only its generated-clock declarations in
# an isolated safe interpreter, never replay constraints in the live session.
proc ot_cf_record {args} {
  set ni [lsearch -exact $args -name]; set mi [lsearch -exact $args -master_clock]
  set si [lsearch -exact $args -source]
  if {$ni < 0 || $mi < 0 || $si < 0} {error "OT_CLOCK_FAMILY: canonical generated clock lacks resolved name/master/source"}
  set name [lindex $args [expr {$ni+1}]]
  set master [lindex $args [expr {$mi+1}]]; set source [lindex $args [expr {$si+1}]]
  if {[llength $master] != 1 || [llength $source] != 1 || [dict exists $::ot_cf_master $name]} {
    error "OT_CLOCK_FAMILY: ambiguous generated clock $name"
  }
  set parent [get_full_name $master]
  if {[sta::object_type $source] eq "Port"} {set source [sta::get_port_pin $source]}
  set owners {}; foreach c [get_property $source clocks] {lappend owners [get_full_name $c]}
  if {[lsort -unique $owners] ne [list $parent]} {
    error "OT_CLOCK_FAMILY: generated source of $name has owners $owners, expected $parent"
  }
  dict set ::ot_cf_master $name $parent
}
proc ot_cf_refresh {} {
  set ::ot_cf_master {}; set ::ot_cf_active_cache {}; set generated {}
  foreach c [all_clocks] {if {[$c is_generated]} {lappend generated [get_full_name $c]}}
  if {![llength $generated]} {return}
  sta::update_generated_clks
  # Iterating paths alone does not initialize generated source insertion.
  # A native timing search fills the complete root-to-bank physical arrivals.
  find_timing_paths -group_path_count 1
  set fd [file tempfile path ot-clock-family-]; close $fd
  set ip [interp create -safe]
  try {
    write_sdc $path
    foreach cmd {get_ports get_pins get_clocks} {interp alias $ip $cmd {} $cmd}
    interp alias $ip create_generated_clock {} ot_cf_record
    set fd [open $path r]; set text [read $fd]; close $fd
    set command {}
    foreach line [split $text \n] {
      append command $line \n
      if {![info complete $command]} continue
      if {[regexp {^\s*create_generated_clock\s} $command]} {interp eval $ip $command}
      set command {}
    }
    if {[string trim $command] ne ""} {error "OT_CLOCK_FAMILY: incomplete canonical SDC"}
    if {[lsort [dict keys $::ot_cf_master]] ne [lsort $generated]} {error "OT_CLOCK_FAMILY: incomplete generated-clock ancestry"}
    foreach c $generated {ot_cf_root $c}
  } finally {interp delete $ip; file delete -force $path}
}
proc ot_cf_root {name} {
  set seen {}
  while {[dict exists $::ot_cf_master $name]} {
    if {$name in $seen} {error "OT_CLOCK_FAMILY: ancestry cycle $name"}
    lappend seen $name; set name [dict get $::ot_cf_master $name]
  }
  set c [get_clocks -quiet $name]
  if {[llength $c] != 1 || [$c is_generated]} {error "OT_CLOCK_FAMILY: unresolved root $name"}
  return $name
}
proc ot_cf_pins {root} {
  set name [get_full_name $root]
  if {[ot_cf_root $name] ne $name} {error "OT_CLOCK_FAMILY: requested root $name is generated"}
  # Ordinary roots retain the existing all_registers ownership query. In
  # pre-CTS ideal sessions get_property(pin, clocks) can be empty on check-only
  # macro entries; all_registers -clock still proves actual graph membership.
  if {![dict size $::ot_cf_master]} {
    set pins [all_registers -clock_pins -clock $root]; set owners {}
    foreach p $pins {dict set owners [get_full_name $p] $root}
    return [list $pins $owners]
  }
  set pins {}; set owners {}
  foreach c [all_clocks] {
    if {[ot_cf_root [get_full_name $c]] ne $name} continue
    foreach p [all_registers -clock_pins -clock $c] {
      set pn [get_full_name $p]
      set actual {}; foreach owner [get_property $p clocks] {lappend actual [get_full_name $owner]}
      if {[llength [lsort -unique $actual]] != 1} {
        error "OT_CLOCK_FAMILY: ambiguous clock sink $pn ($actual)"
      }
      if {[ot_cf_root [lindex $actual 0]] ne $name} {error "OT_CLOCK_FAMILY: foreign sink $pn"}
      if {[lindex $actual 0] ne [get_full_name $c]} continue
      if {[dict exists $owners $pn]} {error "OT_CLOCK_FAMILY: duplicate sink $pn"}
      dict set owners $pn $c; lappend pins $p
    }
  }
  return [list $pins $owners]
}
proc ot_cf_active {p} {
  set cell [get_cells -of_objects $p]
  set key [list [get_property $cell ref_name] [get_property $p lib_pin_name]]
  if {[dict exists $::ot_cf_active_cache $key]} {return [dict get $::ot_cf_active_cache $key]}
  sta::redirect_string_begin
  set failed [catch {report_edges -from $p} message]
  set report [sta::redirect_string_end]; set on 0; set edges {}
  if {$failed} {error "OT_CLOCK_FAMILY: active-edge query failed [get_full_name $p]: $message"}
  foreach line [split $report \n] {
    if {[regexp {^\S} $line]} {set on [regexp {(Clk|En) to Q} $line]; continue}
    if {$on && [regexp {^\s+([\^v])\s+->} $line -> edge] && $edge ni $edges} {lappend edges $edge}
  }
  if {![llength $edges] && [llength [info commands ord::get_db]]} {
    # Check-only hard entries (notably SRAM write clocks) have no clock-to-Q
    # arc. Only an actual physical BLOCK with unique loaded Liberty clock
    # timing-check edges is supported; missing soft-register arcs still fail.
    set master [[ord::get_db] findMaster [get_property $cell ref_name]]
    if {$master ne "NULL" && [$master isBlock]} {
      set on 0
      foreach line [split $report \n] {
        if {[regexp {^\S} $line]} {set on [regexp { (setup|hold|recovery|removal)$} $line]; continue}
        if {$on && [regexp {^\s+([\^v])\s+->} $line -> edge] && $edge ni $edges} {lappend edges $edge}
      }
    }
  }
  if {[llength $edges] != 1} {error "OT_CLOCK_FAMILY: missing unique active clock edge [get_full_name $p] ($edges)"}
  set active [expr {[lindex $edges 0] eq "^" ? "rise" : "fall"}]
  dict set ::ot_cf_active_cache $key $active
  return $active
}
proc ot_cf_wire {pin clock {scene {}}} {
  if {$scene eq ""} {set scene [get_property [sta::cmd_scene] name]}
  set cn [get_full_name $clock]; set waveform {}
  foreach time [$clock waveform] {lappend waveform [sta::time_sta_ui $time]}
  if {[llength $waveform] != 2} {error "OT_CLOCK_FAMILY: invalid waveform $cn"}
  foreach time $waveform {if {![string is double -strict $time] || [regexp -nocase {inf|nan} $time]} {error "OT_CLOCK_FAMILY: nonfinite waveform $cn"}}
  set transition [ot_cf_active $pin]; set marker [expr {$transition eq "rise" ? "^max" : "vmax"}]
  set values {}
  foreach vertex [$pin vertices] {
    if {$vertex eq "NULL"} continue
    set paths [$vertex path_iterator $transition max]
    while {[$paths has_next]} {
      set path [$paths next]; set tag [$path tag]; set edge [lindex $tag 4]
      if {[lindex $tag 1] ne $scene || [lindex $tag 2] ne $marker || [lindex $tag 3] ne $cn || $edge ni {^ v} || [string first "(clock prop)" $tag] < 0} continue
      set arrival [sta::time_sta_ui [$path arrival]]
      if {![string is double -strict $arrival] || [regexp -nocase {inf|nan} $arrival]} {$paths finish; error "OT_CLOCK_FAMILY: nonfinite clock arrival [get_full_name $pin]"}
      lappend values [expr {$arrival-[lindex $waveform [expr {$edge eq "^" ? 0 : 1}]]}]
    }
    $paths finish
  }
  if {[llength $values] != 1} {error "OT_CLOCK_FAMILY: missing unique physical clock arrival [get_full_name $pin] clock=$cn scene=$scene"}
  return [lindex $values 0]
}

proc ot_ce_clock_wire {pin clock} {
  if {[info exists ::ot_cf_master] && [dict size $::ot_cf_master]} {
    set owners [get_property $pin clocks]
    if {[llength $owners] != 1 || [ot_cf_root [get_full_name $owners]] ne [ot_cf_root [get_full_name $clock]]} {
      error "OT_CLOCK_FAMILY: wrong/ambiguous source ownership [get_full_name $pin]"
    }
    return [ot_cf_wire $pin $owners]
  }
  return [ot_ce_legacy_clock_wire $pin $clock]
}
proc ot_ce_net_root_port {pin} {
  set net [get_nets -quiet -of_objects $pin]
  for {set i 0} {$i < 256 && [llength $net] == 1} {incr i} {
    set ports [get_ports -quiet -of_objects $net]
    if {[llength $ports] == 1} { return [get_full_name [lindex $ports 0]] }
    if {[llength $ports]} { return "" }
    set drv [get_pins -quiet -of_objects $net -filter "direction == output"]
    if {[llength $drv] != 1} { return "" }
    set cell [get_cells -quiet -of_objects $drv]
    if {[llength $cell] != 1 || [dict exists $::ot_ce_counts [get_property $cell ref_name]]} { return "" }
    set ins [get_pins -quiet -of_objects $cell -filter "direction == input"]
    if {[llength $ins] != 1} { return "" }
    set net [get_nets -quiet -of_objects $ins]
  }
  return ""
}

# Constants are proved from actual OpenDB connectivity and the loaded Liberty
# output functions. Cell/port names, case analysis and timing-graph constant
# pruning are never proofs. A cell output is constant when every loaded corner
# gives its master the same Liberty function and that function is a literal, or a
# combinational expression whose every variable is an input pin of the same
# instance on a net with no input port and exactly one driver that is itself
# constant (TIEHI/TIELO prove themselves through their literal function; a
# synthesis buffer/inverter or any gate of constants follows). Registers never
# qualify; unknown or unparsable functions fail closed.
proc ot_ce_constant_net {net seen remaining} {
  if {$remaining <= 0 || $net in {"" NULL}} {return 0}
  foreach port [$net getBTerms] {if {[$port getIoType] ne "OUTPUT"} {return 0}}
  set drivers {}
  foreach pin [$net getITerms] {if {[$pin isOutputSignal]} {lappend drivers $pin}}
  if {[llength $drivers] != 1} {return 0}
  return [ot_ce_constant_iterm [lindex $drivers 0] $seen $remaining]
}
proc ot_ce_constant_iterm {pin seen remaining} {
  if {$remaining <= 0 || ![$pin isOutputSignal]} {return 0}
  set inst [$pin getInst];set name "[$inst getName]/[[$pin getMTerm] getName]"
  if {[dict exists $seen $name]} {return 0}
  if {[info exists ::ot_ce_const_memo] && [dict exists $::ot_ce_const_memo $name]} {return [dict get $::ot_ce_const_memo $name]}
  dict set seen $name 1
  set result [ot_ce_constant_iterm_eval $inst $pin $seen $remaining]
  dict set ::ot_ce_const_memo $name $result
  return $result
}
proc ot_ce_constant_iterm_eval {inst pin seen remaining} {
  if {[info exists ::ot_ce_register_cells] && [dict exists $::ot_ce_register_cells [$inst getName]]} {return 0}
  set master [[$inst getMaster] getName];set output [[$pin getMTerm] getName]
  set functions {};set matched 0
  foreach library [get_libs -quiet *] {
    set cell [$library find_liberty_cell $master]
    if {$cell in {"" NULL}} continue
    set lp [$cell find_liberty_port $output]
    if {$lp in {"" NULL} || [sta::liberty_port_direction $lp] ne "output"} {return 0}
    dict set functions [string map {" " "" "\t" "" "\n" ""} [$lp function]] 1
    incr matched
  }
  if {!$matched || [dict size $functions] != 1} {return 0}
  set function [lindex [dict keys $functions] 0]
  if {$function in {0 1}} {return 1}
  if {$function eq "" || ![regexp {^[A-Za-z0-9_!'*&+|^()]+$} $function]} {return 0}
  set inputs [lsort -unique [regexp -all -inline {[A-Za-z_][A-Za-z0-9_]*} $function]]
  if {![llength $inputs]} {return 0}
  foreach input $inputs {
    set in [$inst findITerm $input]
    if {$in in {"" NULL} || ![$in isInputSignal]} {return 0}
    if {![ot_ce_constant_net [$in getNet] $seen [expr {$remaining-1}]]} {return 0}
  }
  return 1
}
# Timing startpoint -> constant proof. An output-port startpoint is followed to
# its net driver; an input port is never constant.
proc ot_ce_constant_cone {start} {
  set block [ord::get_db_block]
  if {[sta::object_type $start] eq "Port" || ([sta::object_type $start] eq "Pin" && [$start is_top_level_port])} {
    set port [$block findBTerm [get_full_name $start]]
    if {$port in {"" NULL} || [$port getIoType] ne "OUTPUT"} {return 0}
    return [ot_ce_constant_net [$port getNet] {} 64]
  }
  if {[sta::object_type $start] ne "Pin"} {return 0}
  set inst [$block findInst [get_full_name [$start instance]]]
  if {$inst in {"" NULL}} {return 0}
  set pin [$inst findITerm [get_property $start lib_pin_name]]
  if {$pin in {"" NULL}} {return 0}
  return [ot_ce_constant_iterm $pin {} 64]
}
# Classification is immutable during one ownership validation. Memoize only
# in the caller's local dictionary; no STA object/classification survives it.
proc ot_ce_startpoint_class {start purpose memo_name} {
  upvar 1 $memo_name memo
  set name [get_full_name $start]
  set key [list $purpose [sta::object_type $start] $name]
  if {[dict exists $memo $key]} {return [dict get $memo $key]}
  if {$purpose eq "input" && [llength [get_ports -quiet $name]]} {
    set result [list port $name]
  } elseif {$purpose eq "output" && [sta::object_type $start] eq "Pin" && [$start is_top_level_port]} {
    set result [list top_pin $name]
  } else {
    set result [list cell [get_full_name [get_cells -quiet -of_objects $start]]]
  }
  dict set memo $key $result
  return $result
}
# A multi-root leaf contains independent synchronous datapaths. Domain declarations
# are checked against the real synthesized timing graph, not trusted as metadata.
proc ot_ce_leaf_ownership {inputs outputs} {
  ot_cf_refresh
  set expected {}
  dict for {domain info} $::ot_ce_domains {lappend expected [dict get $info clock]}
  for {set i 0} {$i < [llength $::ot_ce_ports]} {incr i} {lappend expected ot_entry_$i}
  set actual {}
  foreach c [all_clocks] {if {![$c is_generated]} {lappend actual [get_full_name $c]}}
  foreach name [lsort -unique $::ot_ce_fwd_root_names] {if {$name ni $expected} {lappend expected $name}}
  if {[lsort $actual] ne [lsort $expected]} {error "OT_MULTI_ROOT: undeclared clock alias or relationship"}
  set cells {}; set clocks {}; set crossing_pairs {}; set domain_roots {}
  foreach root $::ot_ce_ports {
    set domain [dict get $::ot_ce_source_domains $root]
    dict set domain_roots $domain $root
    set clock [get_clocks ot_entry_[lsearch -exact $::ot_ce_ports $root]]
    lassign [ot_cf_pins $clock] ot_ce_family_pins ot_ce_family_owners
    foreach pin $ot_ce_family_pins {
      set cell [get_full_name [get_cells -of_objects $pin]]
      if {[dict exists $cells $cell] && ([dict get $cells $cell] ne $domain || ![dict exists $::ot_ce_counts [get_property [get_cells -of_objects $pin] ref_name]])} {
        error "OT_MULTI_ROOT: duplicate clock ownership $cell"
      }
      dict set cells $cell $domain
    }
  }
  foreach pin [all_registers -clock_pins] {
    set cell [get_full_name [get_cells -of_objects $pin]]
    if {![dict exists $cells $cell] && [dict exists $::ot_ce_fwd_cells $cell]} {dict set cells $cell [dict get $::ot_ce_fwd_cells $cell]}
    if {![dict exists $cells $cell]} { error "OT_MULTI_ROOT: unowned register $cell" }
  }
  set ::ot_ce_register_cells {}
  foreach r [all_registers -cells] {dict set ::ot_ce_register_cells [get_full_name $r] 1}
  set ::ot_ce_const_memo {}
  set startpoint_classes {}
  # OpenSTA's -data_pins population includes asynchronous clear/preset
  # controls. Classify these from the actual loaded Liberty sequential arcs,
  # never from port names or reset_ports. They retain recovery/removal timing;
  # only ordinary synchronous D/control paths require data-domain ownership.
  set async_pins {}
  foreach pin [all_registers -async_pins] {dict set async_pins [get_full_name $pin] 1}
  foreach pin [all_registers -data_pins] {
    if {[dict exists $async_pins [get_full_name $pin]]} continue
    set cell [get_full_name [get_cells -of_objects $pin]]
    set expected [dict get $cells $cell]
    foreach start [get_fanin -flat -startpoints_only -to $pin] {
      lassign [ot_ce_startpoint_class $start input startpoint_classes] source_kind source
      if {$source_kind eq "port"} {
        set name [get_full_name $start]
        if {![dict exists $inputs $name] || [dict get $inputs $name] ne $expected} {
          error "OT_MULTI_ROOT: input $name has wrong domain for $cell"
        }
      } else {
        if {![dict exists $cells $source]} {
          if {[ot_ce_constant_cone $start]} {
            puts "OT_MULTI_ROOT LIBERTY_CONSTANT [get_full_name $start] -> [get_full_name $pin]"
            continue
          }
          error "OT_MULTI_ROOT: unowned data path $source -> $cell"
        }
        set source_domain [dict get $cells $source]
        if {$source_domain ne $expected} {
          if {!$::ot_ce_related_data} {error "OT_MULTI_ROOT: cross-domain data path $source -> $cell requires explicit related profile"}
          dict set crossing_pairs [list $source_domain $expected] 1
        }
      }
    }
  }
  dict for {name domain} $outputs {
    foreach start [get_fanin -flat -startpoints_only -to [get_ports $name]] {
      # A die-strap tie output (contract v1.2 tie_hi/tie_lo), possibly
      # synthesis-buffered, has no clock and no data domain to own; it must be
      # proved constant above. Registers and ports keep their domain checks.
      lassign [ot_ce_startpoint_class $start output startpoint_classes] source_kind source
      if {$source_kind eq "top_pin"} {
        if {[ot_ce_constant_cone $start]} {
          puts "OT_MULTI_ROOT LIBERTY_CONSTANT [get_full_name $start] -> $name"
          continue
        }
        error "OT_MULTI_ROOT: output $name has wrong or unregistered source domain [get_full_name $start]"
      }
      if {![dict exists $cells $source] && [ot_ce_constant_cone $start]} {
        puts "OT_MULTI_ROOT LIBERTY_CONSTANT [get_full_name $start] -> $name"
        continue
      }
      if {![dict exists $cells $source] || [dict get $cells $source] ne $domain} {
        error "OT_MULTI_ROOT: output $name has wrong or unregistered source domain $source"
      }
    }
  }
  dict for {pair unused} $crossing_pairs {
    lassign $pair source_domain target_domain
    set source_root [dict get $domain_roots $source_domain]
    set target_root [dict get $domain_roots $target_domain]
    set from [all_registers -clock ot_entry_[lsearch -exact $::ot_ce_ports $source_root] -clock_pins]
    set to {}
    foreach pin [all_registers -clock ot_entry_[lsearch -exact $::ot_ce_ports $target_root] -data_pins] {
      if {![dict exists $async_pins [get_full_name $pin]]} {lappend to $pin}
    }
    foreach kind {max min} {
      set paths [find_timing_paths -from $from -to $to -path_delay $kind -group_path_count 1 -endpoint_path_count 1]
      if {![llength $paths] && [info exists ::env(OT_HOLD_MM)] && $::env(OT_HOLD_MM) eq "1" &&
          ![info exists ::ot_mm_active]} {
        # Multi-mode route/gate (tools/orfs_hold_mm.tcl): this SDC is being read into mode ss BEFORE any scene is
        # defined, so the unscened default scene has no clocks and no path can be found yet.  The crossing population
        # above is structural (actual fanin) and unchanged; the finite-path proof runs strictly in every single-scene
        # read (non-MM stages, corner_sta / sign-off), which carries the timing claim.
        puts "OT_MULTI_ROOT RELATED_PATH_DEFERRED $source_domain -> $target_domain $kind (multi-mode read before scene definition; strict at sign-off)"
        continue
      }
      if {![llength $paths] || ![ot_ce_finite [get_property [lindex $paths 0] slack]]} {
        error "OT_MULTI_ROOT: related crossing lacks actual finite $kind STA path $source_domain -> $target_domain"
      }
      puts "OT_MULTI_ROOT RELATED_PATH $source_domain -> $target_domain $kind slack=[get_property [lindex $paths 0] slack] (ordinary synchronous timing retained)"
    }
  }
  puts "OT_MULTI_ROOT OWNERSHIP PASS roots=[llength $::ot_ce_cts_roots] registers=[dict size $cells] inputs=[dict size $inputs] outputs=[dict size $outputs] async_control_pins=[dict size $async_pins]"
}

proc ot_ce_corner {} {
  if {[info exists ::ot_ioref_scene] && $::ot_ioref_scene eq "BC"} { return ff }
  if {[info exists ::ot_ce_corner]} { return $::ot_ce_corner }
  # WC is a scene label, not an actual library corner: option-B overlays WC
  # with TT. Bind the reference to actual loaded child Liberty objects.
  set found {}; set clock_cells {}
  # Physical-only taps/endcaps have no Liberty association. The clock corner
  # belongs to actual sequential clock sinks, not every physical instance.
  foreach pin [all_registers -clock_pins] {
    set cell [get_cells -quiet -of_objects $pin]
    if {[llength $cell] != 1 || $cell eq "NULL"} {error "OT_MULTI_ROOT: clock sink lacks one actual sequential cell"}
    dict set clock_cells [get_full_name $cell] $cell
  }
  if {![dict size $clock_cells]} {error "OT_MULTI_ROOT: no actual sequential cells for corner inference"}
  foreach cell [dict values $clock_cells] {
    set master [get_property $cell ref_name]
    set libcells [get_lib_cells -quiet -of_objects $cell]
    if {![llength $libcells] || "NULL" in $libcells} { error "OT_MULTI_ROOT: actual sequential cell $master has no loaded Liberty association" }
    foreach lc $libcells {
      set full [get_full_name $lc]
      if {![regexp -nocase {_(tt|ff|ss)/|_(tt|ff|ss)_} $full -> corner alt]} { error "OT_ENTRIES: unknown actual Liberty corner $full" }
      if {$corner eq ""} {set corner $alt}
      dict set found [string tolower $corner] 1
    }
  }
  if {[dict size $found] == 1} { return [lindex [dict keys $found] 0] }
  # A multi-mode database needs its actual setup corner or BC scene shim.
  if {[info exists ::env(OT_MM_SETUP_CORNER)]} {
    switch -nocase -- $::env(OT_MM_SETUP_CORNER) {
      TC - tt {set corner tt} BC - ff {set corner ff} WC - ss {set corner ss}
      default { error "OT_ENTRIES: unknown actual setup corner" }
    }
    if {[dict exists $found $corner]} { return $corner }
  }
  error "OT_ENTRIES: ambiguous actual loaded child corners [dict keys $found]"
}
# get_property pin arrival_max_rise is a DATA arrival query. On a clock-only
# macro pin it returns an infinity sentinel even with a finite propagated clock
# path. Read propagated clock tags in the current scene and remove the
# source waveform edge time; falling-edge-only registers include that phase.
proc ot_ce_finite {value} {
  return [expr {[string is double -strict $value] && ![regexp -nocase {inf|nan} $value]}]
}
proc ot_ce_legacy_clock_wire {pin clock} {
  set scene [get_property [sta::cmd_scene] name]
  set clock_name [get_full_name $clock]
  set by_transition [dict create rise {} fall {}]
  set waveform {}
  foreach time [$clock waveform] {lappend waveform [sta::time_sta_ui $time]}
  if {[llength $waveform] != 2 || ![ot_ce_finite [lindex $waveform 0]] ||
      ![ot_ce_finite [lindex $waveform 1]]} {
    error "OT_ENTRIES: invalid source clock waveform $clock_name"
  }
  foreach vertex [$pin vertices] {
    if {$vertex eq "NULL"} continue
    foreach transition {rise fall} marker {^ v} {
      set paths [$vertex path_iterator $transition max]
      while {[$paths has_next]} {
        set path [$paths next]
        # Sink transition and source clock edge are distinct (inverting trees).
        # Exclude data, ideal, other-scene and other-clock paths as before.
        set tag [$path tag]
        set edge [lindex $tag 4]
        if {[lindex $tag 1] ne $scene || [lindex $tag 2] ne "${marker}max" ||
            [lindex $tag 3] ne $clock_name || $edge ni {^ v} ||
            [string first "(clock prop)" $tag] < 0} continue
        set arrival [sta::time_sta_ui [$path arrival]]
        if {![ot_ce_finite $arrival]} {
          $paths finish
          error "OT_ENTRIES: nonfinite propagated clock arrival on [get_full_name $pin] scene=$scene clock=$clock_name"
        }
        set phase [lindex $waveform [expr {$edge eq "^" ? 0 : 1}]]
        dict lappend by_transition $transition [expr {$arrival - $phase}]
      }
      $paths finish
    }
  }
  # Preserve the rising pin-transition reference. An inverted/negedge clock
  # may associate it with the falling source edge; remove that actual phase.
  # Fall-only pins remain measurable. Multiple same-transition tags fail.
  set values [dict get $by_transition rise]
  if {![llength $values]} {set values [dict get $by_transition fall]}
  if {[llength $values] != 1} {
    # Synthesis/floorplan have no extracted entry wire. This is solely a finite
    # pre-CTS diagnostic reference; routed gates must measure a clock path.
    if {![llength $values] && [info exists ::ot_ref_pre_cts] && $::ot_ref_pre_cts &&
        (![info exists ::ot_ce_require_wire] || !$::ot_ce_require_wire)} {
      puts "OT_ENTRIES PRE_CTS_ZERO_WIRE [get_full_name $pin] scene=$scene"
      return 0.0
    }
    error "OT_ENTRIES: missing unique finite propagated clock arrival on [get_full_name $pin] scene=$scene clock=$clock_name"
  }
  return [lindex $values 0]
}
# Match the structural IO boundary population in ck_insertion.py and io_ref_routed.sdc.
proc ot_ce_boundary_cells {} {
  set regs {}
  foreach p [all_registers -clock_pins] {
    set n [get_full_name $p]
    dict set regs [regsub {/[^/]+$} $n {}] $n
  }

set bnd {}
set ot_ck_data {}
set ot_ck_async {}
foreach p [all_registers -async_pins] { dict set ot_ck_async [get_full_name $p] 1 }
foreach p [all_registers -data_pins] {
  set n [get_full_name $p]
  if {![dict exists $ot_ck_async $n]} { dict set ot_ck_data $n 1 }
}
set din [all_inputs -no_clocks]
if {[llength $din]} {
  foreach p [get_fanout -from $din -flat -endpoints_only -trace_arcs all] {
    set n [get_full_name $p]
    if {![dict exists $ot_ck_data $n]} continue
    set i [regsub {/[^/]+$} $n {}]
    if {[dict exists $regs $i]} { dict set bnd $i 1 }
  }
}
set dout [all_outputs]
if {[llength $dout]} {
  foreach p [get_fanin -to $dout -flat -startpoints_only -trace_arcs all] {
    set i [regsub {/[^/]+$} [get_full_name $p] {}]
    if {[dict exists $regs $i]} { dict set bnd $i 1 }
  }
}

  return $bnd
}
# Owner 2026-10-17 0dq clock rule for one glue CTS root in the current scene: FAIL iff the pin-flop spread
# (pin_hi - pin_lo over the boundary registers, or every sink when none is at the boundary) exceeds 80 ps at
# TT or FF; SS is sensitivity only.  > 15k sinks and > 300 ps insertion only WARN.
proc ot_ce_clock_rule {corner name sinks all_mean pin_mean pin_lo pin_hi scope} {
  set spread [expr {$pin_hi - $pin_lo}]
  set warn {}
  if {$sinks > 15000} { lappend warn "sinks $sinks > 15000 (guidance)" }
  if {$all_mean > 300 || $pin_mean > 300} {
    lappend warn "insertion all_mean [format %.1f $all_mean] / pin_mean [format %.1f $pin_mean] ps > 300 (guidance)"
  }
  if {[string tolower $corner] in {tt ff} && $spread > 80} {
    set level FAIL
  } elseif {[llength $warn]} {
    set level WARN
  } else {
    set level PASS
  }
  puts "OT_HYBRID CLOCK_RULE $corner $name $level pin_spread=[format %.1f $spread] scope=$scope sinks=$sinks[expr {[llength $warn] ? " WARN: [join $warn {; }]" : ""}]"
  return $level
}

proc ot_ce_boundary_pins {pins boundary_cells} {
  set regs {}; set boundary {}
  foreach pin $pins {dict set regs [regsub {/[^/]+$} [get_full_name $pin] {}] $pin}
  dict for {name unused} $boundary_cells {
    if {[dict exists $regs $name]} {dict set boundary $name [dict get $regs $name]}
  }
  return [dict values $boundary]
}

proc ot_ce_apply {} {
  set corner [ot_ce_corner]
  set clk [get_clocks core_clk]
  if {[llength $clk] != 1} { error "OT_ENTRIES: core_clk missing" }
  # Wires-only parents have no CTS tree to set this flag for us.
  # Ideal clocks silently report zero network arrival despite real entry wires.
  set_propagated_clock [get_clocks ot_entry_*]
  # Before CTS, a standard-cell root is still one unbuffered high-fanout
  # net. Propagating that net invents multi-ns skew and clock-pin slew;
  # its delay is not the tree that CTS will build. Keep only these declared
  # CTS roots ideal during the explicit pre-CTS diagnostic. Raw macro and
  # hardened-child entries retain actual entry-wire propagation. Routed
  # require-wire checks always propagate and measure every physical root.
  if {[info exists ::ot_ref_pre_cts] && $::ot_ref_pre_cts &&
      (![info exists ::ot_ce_require_wire] || !$::ot_ce_require_wire)} {
    foreach name $::ot_ce_cts_roots {
      set clock [get_clocks ot_entry_[lsearch -exact $::ot_ce_ports $name]]
      unset_propagated_clock $clock
      puts "OT_ENTRIES PRE_CTS_IDEAL_CTS_ROOT $name"
    }
  }
  set sources {}; set names {}
  foreach c [get_clocks ot_entry_*] {
    foreach p [get_property $c sources] { lappend sources $p; lappend names [get_full_name $p] }
  }
  if {[lsort $names] ne [lsort $::ot_ce_ports]} { error "OT_ENTRIES: source clock coverage differs from spec" }
  foreach c [get_clocks ot_entry_*] { set_clock_latency -source 0 $c }
  ot_cf_refresh
  sta::worst_slack_cmd max
  set rows {}; set seen {}; set counts {}
  foreach cell [get_cells -quiet -hierarchical *] {
    set master [get_property $cell ref_name]
    if {![dict exists $::ot_ce_counts $master]} continue
    dict incr counts $master
    foreach pin [get_pins -quiet -of_objects $cell] {
      set key "$master/[get_property $pin lib_pin_name]"
      if {![dict exists $::ot_ce_refs $key] || $::ot_ce_landed_cluster} continue
      set ports [get_ports -quiet -of_objects [get_nets -quiet -of_objects $pin]]
      if {[llength $ports] != 1} { error "OT_ENTRIES: [get_full_name $pin] lacks one direct top clock port" }
      set port [lindex $ports 0]; set name [get_full_name $port]
      if {$name ni $::ot_ce_ports || $name in $::ot_ce_cts_roots || [dict exists $seen $name]} { error "OT_ENTRIES: duplicate or undeclared source $name" }
      dict set seen $name 1
      set clock [get_clocks ot_entry_[lsearch -exact $::ot_ce_ports $name]]
      if {[llength $clock] != 1} { error "OT_ENTRIES: $name has no unique related clock" }
      set wire [ot_ce_clock_wire $pin $clock]
      if {![ot_ce_finite $wire]} { error "OT_ENTRIES: nonfinite entry wire clock arrival on [get_full_name $pin]" }
      if {abs($wire) < 1.0e-9 && [info exists ::ot_ce_require_wire] && $::ot_ce_require_wire} {
        # A zero arrival is admissible only if actual source and child pin are
        # physically coincident. Missing parasitics/ideal clocks cannot qualify.
        if {![llength [info commands ord::get_db_block]]} { error "OT_ENTRIES: zero wire lacks physical source/pin proof" }
        set block [ord::get_db_block]
        set bt [$block findBTerm $name]
        set it [$block findITerm [get_full_name $pin]]
        if {$bt eq "NULL" || $it eq "NULL"} { error "OT_ENTRIES: missing physical source/child clock pin" }
        set pb [$bt getBBox]; set ib [$it getBBox]
        set distance [expr {(abs(([$pb xMin]+[$pb xMax])-([$ib xMin]+[$ib xMax])) + abs(([$pb yMin]+[$pb yMax])-([$ib yMin]+[$ib yMax]))) / 2.0 / [$block getDbUnitsPerMicron]}]
        if {$distance > 0.001} { error "OT_ENTRIES: zero clock wire arrival despite $distance um source/pin separation on $name" }
        puts "OT_ENTRIES ZERO_WIRE_PROVEN $name [get_full_name $pin] distance=$distance"
      }
      lassign [dict get $::ot_ce_refs $key $corner] lo mean hi
      set clock [get_clocks ot_entry_[lsearch -exact $::ot_ce_ports $name]]
      if {[llength $clock] != 1} { error "OT_ENTRIES: $name has no unique related clock" }
      set ttmean [lindex [dict get $::ot_ce_refs $key tt] 1]
      set domain [dict get $::ot_ce_source_domains $name]
      set vc [get_clocks [dict get $::ot_ce_domains $domain clock]]
      if {abs([get_property $vc period]-[get_property $clock period])>0.001} { error "OT_ENTRIES: domain/source period mismatch $name" }
      lappend rows [list $port $pin $wire $lo $mean $hi $clock $ttmean $domain]
    }
  }
  dict for {m n} $::ot_ce_counts {
    if {![dict exists $counts $m] || [dict get $counts $m] != $n} { error "OT_ENTRIES: bound child count mismatch $m" }
  }
  # Source latencies are zero for this whole measurement loop, and no STA
  # constraints/netlist change until rows are complete. Query the same bounded
  # boundary population once per apply/current corner, never across calls.
  set boundary_cells {}; set boundary_cells_ready 0
  set ot_ce_landed_hits 0; set ::ot_ce_landed_owner [dict create]
  # Each glue root owns a real CTS tree. Measure every propagated standard-cell
  # clock sink in the current scene; never substitute a declared/common phase.
  foreach name $::ot_ce_cts_roots {
    set clock [get_clocks ot_entry_[lsearch -exact $::ot_ce_ports $name]]
    lassign [ot_cf_pins $clock] pins ot_ce_family_owners
    set ot_ce_pin_seen [dict create]
    foreach pin $pins {dict set ot_ce_pin_seen [get_full_name $pin] 1}
    foreach cell [get_cells -quiet -hierarchical *] {
      set master [get_property $cell ref_name]
      if {![dict exists $::ot_ce_counts $master]} continue
      foreach pin [get_pins -quiet -of_objects $cell] {
        set key "$master/[get_property $pin lib_pin_name]"
        if {![dict exists $::ot_ce_refs $key] || [dict exists $ot_ce_pin_seen [get_full_name $pin]]} continue
        if {![info exists ::ot_ce_check_only] || ![dict exists $::ot_ce_check_only $key]} continue
        if {[ot_ce_net_root_port $pin] ne $name} continue
        lappend pins $pin; dict set ot_ce_pin_seen [get_full_name $pin] 1
        puts "OT_LANDED CHECK_CLOCK_PIN $name [get_full_name $pin] (timing-check-only child clock pin)"
      }
    }
    if {![llength $pins]} { error "OT_HYBRID: glue root $name has no actual sequential clock sinks" }
    set arrivals {}; set measured {}; set total 0.0; set ot_ce_child_ext [dict create]
    foreach pin $pins {
      set cell [get_cells -of_objects $pin]
      set master [get_property $cell ref_name]
      set arrival [ot_ce_clock_wire $pin $clock]
      if {[dict exists $::ot_ce_counts $master]} {
        # landed cluster: a hard child on its region root, judged at its flops (entry wire + routed child insertion)
        set key "$master/[get_property $pin lib_pin_name]"
        if {![dict exists $::ot_ce_refs $key]} { error "OT_LANDED: CTS root $name reaches unbound hard-child pin [get_full_name $pin]" }
        set cname [get_full_name $cell]
        if {[dict exists $::ot_ce_landed_owner $cname] && [dict get $::ot_ce_landed_owner $cname] ne [dict get $::ot_ce_source_domains $name]} {
          error "OT_LANDED: hard child $cname clock pins on different region roots"
        }
        dict set ::ot_ce_landed_owner $cname [dict get $::ot_ce_source_domains $name]
        lassign [dict get $::ot_ce_refs $key $corner] clo cmean chi
        dict set ot_ce_child_ext [get_full_name $pin] [list [expr {$arrival + $clo}] [expr {$arrival + $chi}]]
        puts "OT_LANDED CHILD_SINK $corner $name [get_full_name $pin] wire=$arrival R=$cmean min=[expr {$arrival + $clo}] max=[expr {$arrival + $chi}]"
        set arrival [expr {$arrival + $cmean}]
        incr ot_ce_landed_hits
      }
      lappend arrivals $arrival
      dict set measured [get_full_name $pin] $arrival
      set total [expr {$total + $arrival}]
    }
    set arrivals [lsort -real $arrivals]
    set lo [lindex $arrivals 0]; set hi [lindex $arrivals end]
    set tree_mean [expr {$total / [llength $arrivals]}]
    set mean $tree_mean
    if {[info exists ::ot_ce_require_wire] && $::ot_ce_require_wire && $mean <= 0} {
      error "OT_HYBRID: glue root $name lacks a positive actual propagated CTS insertion"
    }
    if {!$boundary_cells_ready} {
      set boundary_cells [ot_ce_boundary_cells]; set boundary_cells_ready 1
    }
    set boundary [ot_ce_boundary_pins $pins $boundary_cells]
    set scope boundary
    if {![llength $boundary]} { set boundary $pins; set scope all_internal_only }
    set arrivals {}; set total 0.0
    foreach pin $boundary {
      set arrival [dict get $measured [get_full_name $pin]]
      lappend arrivals $arrival; set total [expr {$total + $arrival}]
    }
    set arrivals [lsort -real $arrivals]
    set lo [lindex $arrivals 0]; set hi [lindex $arrivals end]
    set mean [expr {$total / [llength $arrivals]}]
    foreach pin $boundary {
      if {![dict exists $ot_ce_child_ext [get_full_name $pin]]} continue
      lassign [dict get $ot_ce_child_ext [get_full_name $pin]] clo chi
      set lo [expr {min($lo, $clo)}]; set hi [expr {max($hi, $chi)}]
    }
    # Clock rule (owner 2026-10-17 0dq, textbook_lint.clock_rule_eval): FAIL only on the pin-flop (boundary
    # register; child-flop on a region-rooted parent) spread > 80 ps at TT or FF.  > 15k sinks on one root and
    # insertion > 300 ps are guidance (WARN): the neighbour boundary is matched by the source-latency
    # compensation below / a ring crossing and judged by native_pin_audit --relative-to.
    if {[ot_ce_clock_rule $corner $name [llength $pins] $tree_mean $mean $lo $hi $scope] eq "FAIL"} {
      puts "OT_LANDED CLOCK_RULE_SPAN $corner $name: whole-root span over 80 ps; verdict per linked child pair (pre_route_gate root_child_flops)"
    }
    set domain [dict get $::ot_ce_source_domains $name]
    lappend rows [list [get_ports $name] [lindex $pins 0] 0 $lo $mean $hi $clock $mean $domain]
    dict set seen $name 1
    puts "OT_HYBRID CTS_MEASURE $corner $name sinks=[llength $pins] reference_scope=$scope boundary_sinks=[llength $boundary] min=$lo mean=$mean max=$hi all_mean=$tree_mean"
  }
  incr ot_ce_landed_hits [ot_ce_forwarded_visit $corner]
  if {$ot_ce_landed_hits != $::ot_ce_landed_child_pins} { error "OT_LANDED: $ot_ce_landed_hits of $::ot_ce_landed_child_pins bound hard-child clock pins reached from the region roots" }
  if {[dict size $seen] != [llength $::ot_ce_ports]} { error "OT_ENTRIES: incomplete actual child/source coverage" }
  set ref 0
  foreach row $rows { lassign $row p pin wire lo mean hi; set ref [expr {max($ref, $wire + $mean)}] }
  set low {}; set high {}; set lowclocks {}; set highclocks {}; set domain_low {}; set domain_high {}
  foreach row $rows {
    lassign $row p pin wire lo mean hi clock ttmean domain
    # Physical source level includes the entry wire, not just the hard
    # child's internal insertion. Only a TT scene measures the TT wire.
    # Other physical scenes conservatively reserve the deep pair budget;
    # they must not guess TT wire delay from FF/SS or an ideal zero arrival.
    set deep [expr {$ttmean > 300}]
    set level_basis "zero-wire diagnostic"
    if {$corner eq "tt"} {
      set deep [expr {$ttmean + $wire > 300}]
      set level_basis "TT timing-graph entry arrival + child R (physical proof required for route/signoff)"
    } elseif {[info exists ::ot_ce_require_wire] && $::ot_ce_require_wire} {
      set deep 1
      set level_basis "TT wire level not measured in this scene; conservative210ps setup"
    }
    if {$deep} { lappend highclocks $clock } else { lappend lowclocks $clock }
    puts "OT_ENTRIES LEVEL [get_full_name $p] deep=$deep basis=$level_basis"
    set latency [expr {$ref - $wire - $mean}]
    if {![ot_ce_finite $ref] || ![ot_ce_finite $latency]} { error "OT_ENTRIES: nonfinite reference/source latency on [get_full_name $p]" }
    set_clock_latency -source $latency $clock
    lappend low [expr {$ref + $lo - $mean}]; lappend high [expr {$ref + $hi - $mean}]
    dict lappend domain_low $domain [expr {$ref + $lo - $mean}]
    dict lappend domain_high $domain [expr {$ref + $hi - $mean}]
    puts "OT_ENTRIES COMP $corner [get_full_name $p] -> [get_full_name $pin] wire=$wire R=$mean latency=$latency phi=$ref"
  }
  # Every entry is synchronous and related. Reserve die skew on internal hops;
  # no asynchronous groups, false paths or ETM insertion add-back.
  # H1 authoritative pair_check.HOLD_TREE =50ps hold margin+50ps die skew (hold 100, setup 150).
  # Each deep tile has its own earlier trunk tap. The authoritative TREE
  # pair budget uses150ps die skew when either reference exceeds300ps,
  # including deep-to-deep pairs (pair_check.SKEW_DEEP) (setup 210).
  # S-ELEM-PQ 2026-10-15: a register pair on ONE glue CTS root of this tile shares one die tap and one
  # propagated standard-cell tree whose real skew STA already sees, so it is timed like every single-root
  # tile (base uncertainty); the die-skew reserve applies to every pair of DIFFERENT entries and to hard-
  # child entries (dsfd_bf_front_static: the uniform rule put hold 100 / setup 210 on all 12,276 core-root
  # paths -> 15,826 hold endpoints, 119k buffers).
  set ot_ce_glue {}
  foreach name $::ot_ce_cts_roots { lappend ot_ce_glue [get_full_name [get_clocks ot_entry_[lsearch -exact $::ot_ce_ports $name]]] }
  set ot_ce_high {}
  foreach c $highclocks { lappend ot_ce_high [get_full_name $c] }
  set ot_ce_family_clocks {}
  foreach c [all_clocks] {
    if {[ot_cf_root [get_full_name $c]] in [lmap x [get_clocks ot_entry_*] {get_full_name $x}]} {lappend ot_ce_family_clocks $c}
  }
  foreach a $ot_ce_family_clocks {
    foreach b $ot_ce_family_clocks {
      set an [ot_cf_root [get_full_name $a]]; set bn [ot_cf_root [get_full_name $b]]
      if {$an eq $bn && $an in $ot_ce_glue} { continue }
      set_clock_uncertainty -setup [expr {($an in $ot_ce_high || $bn in $ot_ce_high) ? 210 : 150}] -from $a -to $b
      set_clock_uncertainty -hold 100 -from $a -to $b
    }
  }
  # Preserve measured boundary spread: balancing the mean does not erase the
  # earliest/latest physical boundary arrivals or change ETM setup/hold arcs.
  set lmin [lindex [lsort -real $low] 0]; set lmax [lindex [lsort -real $high] end]
  unset_input_delay [all_inputs]; unset_output_delay [all_outputs]
  set sk [expr {[info exists ::env(OT_IO_SKEW)] ? $::env(OT_IO_SKEW) : 90}]
  set hk [expr {[info exists ::env(OT_IO_HOLD_SKEW)] ? $::env(OT_IO_HOLD_SKEW) : 50}]
  set hki [expr {[info exists ::env(OT_IO_IN_HOLD_SKEW)] ? $::env(OT_IO_IN_HOLD_SKEW) : 0}]
  set covered_in {}; set covered_out {}
  dict for {domain info} $::ot_ce_domains {
    if {![dict exists $domain_low $domain]} { error "OT_ENTRIES: domain $domain has no actual child clock pins" }
    set dlmin [lindex [lsort -real [dict get $domain_low $domain]] 0]
    set dlmax [lindex [lsort -real [dict get $domain_high $domain]] end]
    set vc [get_clocks [dict get $info clock]]
    set budget [dict get $info io_budget_ps]
    # Optional composition-derived output budget (domain "io_budget": {"out": f}, f >= 0.2): the outside share of the
    # cycle on this domain's outputs; larger = a TIGHTER launch (flop -> pin) inside the child, never a relaxation.
    set budget_out [expr {[dict exists $info io_budget_out_ps] ? [dict get $info io_budget_out_ps] : $budget}]
    set inputs {}; set outputs {}
    foreach pattern [dict get $info inputs] {
      set match [get_ports -quiet $pattern -filter "direction == input"]
      if {$::ot_ce_leaf_roots && ![llength $match]} {set match [get_ports -quiet [format {%s\[*\]} $pattern] -filter "direction == input"]}
      if {$::ot_ce_leaf_roots && ![llength $match]} {error "OT_MULTI_ROOT: unknown input $pattern"}
      foreach p $match {
        set n [get_full_name $p]
        if {$n in $::ot_ce_ports} continue
        if {[dict exists $covered_in $n]} { error "OT_ENTRIES: input $n has duplicate IO domains" }
        dict set covered_in $n $domain; lappend inputs $p
      }
    }
    foreach pattern [dict get $info outputs] {
      set match [get_ports -quiet $pattern -filter "direction == output"]
      if {$::ot_ce_leaf_roots && ![llength $match]} {set match [get_ports -quiet [format {%s\[*\]} $pattern] -filter "direction == output"]}
      if {$::ot_ce_leaf_roots && ![llength $match]} {error "OT_MULTI_ROOT: unknown output $pattern"}
      foreach p $match {
        set n [get_full_name $p]
        if {[dict exists $covered_out $n]} { error "OT_ENTRIES: output $n has duplicate IO domains" }
        dict set covered_out $n $domain; lappend outputs $p
      }
    }
    if {[llength $inputs]} {
      set_input_delay [expr {$budget+$dlmax+$sk}] -max -clock $vc $inputs
      set_input_delay [expr {$dlmin-$hki}] -min -clock $vc $inputs
    }
    if {[llength $outputs]} {
      set_output_delay [expr {$budget_out-$dlmax+$sk}] -max -clock $vc $outputs
      set_output_delay [expr {-$dlmin-$hk}] -min -clock $vc $outputs
    }
    if {[info exists ::env(OT_IO_INTER)] && $::env(OT_IO_INTER) ne ""} {
      foreach pattern [split $::env(OT_IO_INTER) ","] {
        foreach p [get_ports -quiet $pattern] {
          set n [get_full_name $p]
          if {[dict exists $covered_in $n] && [dict get $covered_in $n] eq $domain} {
            set_input_delay [expr {$budget+$dlmax+150}] -max -clock $vc $p
          }
          if {[dict exists $covered_out $n] && [dict get $covered_out $n] eq $domain} {
            set_output_delay [expr {$budget_out-$dlmax+150}] -max -clock $vc $p
          }
        }
      }
    }
    puts "OT_ENTRIES DOMAIN $domain [get_property $vc period]ps IO[llength $inputs]/[llength $outputs] boundary=$dlmin..$dlmax"
  }
  if {[dict size $covered_in] != [llength [lsort -unique [concat [lmap p [all_inputs -no_clocks] {get_full_name $p}] $::ot_ce_fwd_inputs]]] || [dict size $covered_out] != [llength [all_outputs]]} {
    error "OT_ENTRIES: incomplete actual IO domain coverage (resets must also have a domain)"
  }
  if {$::ot_ce_leaf_roots} { ot_ce_leaf_ownership $covered_in $covered_out }
  puts "OT_ENTRIES COMP DONE $corner [llength $rows] entries phi=$ref boundary=$lmin..$lmax"
}
ot_ce_apply
# ---- PL-KIT landed cluster (top_lp_record.json): 1 landings, multicycle -setup 2 -hold 3
set ot_lp_lands {0}
set ot_lp_miss 0
foreach ot_ln $ot_lp_lands {
  set ot_lf [get_cells -quiet u_lpl_${ot_ln}_w.*]
  set ot_lt [get_cells -quiet u_lpl_${ot_ln}_r.*]
  if {[llength $ot_lf] == 0} { set ot_lf [get_cells -quiet u_lpl_${ot_ln}_w/*] }
  if {[llength $ot_lt] == 0} { set ot_lt [get_cells -quiet u_lpl_${ot_ln}_r/*] }
  if {[llength $ot_lf] == 0 || [llength $ot_lt] == 0} { incr ot_lp_miss; continue }
  set_multicycle_path -setup 2 -from $ot_lf -to $ot_lt
  set_multicycle_path -hold 3 -from $ot_lf -to $ot_lt
}
puts "OT_LP_LAND_SDC [expr {[llength $ot_lp_lands] - $ot_lp_miss}] of [llength $ot_lp_lands] landings constrained"
