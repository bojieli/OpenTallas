import subprocess,pathlib,json
cases=[('positive',c) for c in ['ss','ff','tt']]+[(c,'tt') for c in ['missing_clock','wrong_clock','wrong_root','ambiguous_clock','multi_source','wrong_master','unbound_pin','unbound_output','missing_proof','nonunary','unbound_seq','wrong_polarity','changed_ownership','fall_only_skew']]
results=[]
for case,corner in cases:
 p=subprocess.run(['python3','-u','native_probe.py',case,corner],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 pathlib.Path(f'matrix_{case}_{corner}.log').write_text(p.stdout)
 ok=(p.returncode==0 and 'ACTUAL_NATIVE_FORWARD_PAIR_PASS' in p.stdout) if case=='positive' else (p.returncode!=0)
 r=dict(case=case,corner=corner,rc=p.returncode,expected='accept' if case=='positive' else 'refuse',outcome_matches=ok,tail=p.stdout[-1400:]);results.append(r)
 pathlib.Path('MATRIX_RESULTS.json').write_text(json.dumps(results,indent=2))
 print(case,corner,p.returncode,'EXPECTED' if ok else 'UNEXPECTED',flush=True)
raise SystemExit(0 if all(x['outcome_matches'] for x in results) else 1)
