`timescale 1ns/1ps
// Static successor from actual production decoder; numeric/DYN/fold state retained.
// Source SHA256 4834228027f8606934159214192245f9093505523b4b0afe18488f51af19ea52
module ot_qwen_rom_core_ctrl_static #(
    parameter integer OWN = 2,        // redesign-qwen: this controller's unit (1 ME, 2 SU)
    parameter integer XW = 24,        // other-unit op counter width
    parameter integer XMUT = 0,       // negative controls (split_ctrl.py MUT)
    parameter integer XREG = 0,       // 1: the snapshot comparisons registered (o_cnt next vs the snapshot; 1 edge later)
    parameter integer ICUT = 0,       // qwen-1010/a: registered readiness (ctrl_icut)
    parameter integer PRL = 1,        // qwen-1010/a: program read latency (ctrl_prl)
    parameter integer FQ_HEAD = 0,   // safe-qwen S-A6: registered FIFO head word (decode reads a flop)
                                     // 2 (hardcore-1010 fe-h): two head words written in turn while fewer than 2 are held
                                     // (fill enable from registers only: fq_n, hc), decode reads hq / hq1 by a registered
                                     // pointer.  Same words, same edges as FQ_HEAD 1 (lockstep bench)
    parameter integer INSTR_BITS = 1024,   // must equal ISA_INSTR_BITS (tools/hdc_isa.py)
    parameter integer W    = 16,
    parameter integer G    = 4,
    parameter integer DG   = G,   // qwen-tp8/seq: G of the DYN_TTILES rounds (= G; != G only as a bench negative control)
    parameter integer IL   = 8,
    parameter integer AW   = 24,
    parameter integer NW   = 16,
    parameter integer PAW  = 12,      // program address bits
    // model constants for the DYN offsets
    parameter integer HID  = 128,
    parameter integer HALF = 8,
    parameter integer HD   = 16,
    // KV_HBM = 1: the KV cache lives in HBM behind ot_hdc_kv_stream.  A
    // KV-sourced matrix op then announces its descriptor (kvd_*) when the
    // sequencer reaches it and issues only once the streamer raises kv_ok
    // (its prefetch window covers the op; the engine never stalls).  With
    // KV_HBM = 0 the kvd_* outputs are unused and kv_ok is ignored.
    parameter integer KV_HBM = 0,
    // The stream unit.  SU_VEC = 1: the vector stream unit (ot_hdc_vstream) of
    // SW lanes (a multiple of 8) with the R-ARITH reducer (segments of up to
    // 2^LV vectors); every stream port is SW elements wide.  SU_VEC = 0: the
    // scalar stream unit (ot_hdc_stream, SW must be 1) and its P=8 reducer --
    // the configurations not yet moved (the KV-in-HBM streamer).
    parameter integer SU_VEC = 0,
    parameter integer SW     = 1,
    parameter integer LV     = 4,
    parameter integer KV_FP8 = (SU_VEC != 0),
    parameter integer KV_VEC_WRITE_BRIDGE = 0,
    parameter integer W_HBM = 0,
    // INT8_WEIGHT replaces only matrix ROM products. The embedding stream
    // still reads BF16 until its own INT8 dequantisation path is integrated.
    parameter integer INT8_WEIGHT = 0,
    parameter integer INT8_SCALE_WCS_BASE = 0,
    parameter integer INT8_EMBED = 0,
    // Opt-in Qwen full-vocabulary encoding: two ME row-offset bits live just
    // above the legacy 16-bit field in the otherwise unused ISA tail.
    parameter integer QWEN_FULLSHAPE = 0,
    // ME_STALL = 1: an HBM weight supply may hold the matrix engine for a
    // cycle (bounded within-round continuation).  The engine and its memory
    // write enables are clocked only on edges where me_mem_ok was high during
    // the preceding low phase (ot_hdc_cg), so a held cycle is an exact pause:
    // no element, product or sum order changes.  The supply must hold its
    // engine read-response registers on the same edges (me_clk_en).
    // ME_STALL = 0 ties the enable high: the ROM core is unchanged.
    parameter integer ME_STALL = 0,
    // ME_IDLE_GATE = 1: also stop the engine clock while it is idle and no
    // engine instruction waits in NEXT (unit clock gating).  An idle engine
    // holds only registered, drained outputs; it is re-enabled on the edge an
    // engine instruction reaches NEXT, before its go, so issue timing is
    // unchanged.  0 keeps the engine clock free-running.
    parameter integer ME_IDLE_GATE = 0,
    parameter integer MEREG = 0,      // el1011-q-seq: me_mem_ok announced 2 edges ahead; me_en a register
    parameter integer PCUT = 0,       // el1011-q-seq: exact path cuts (ctrl_pcut)
    parameter integer FKS = 0,        // el1011-q-seq: 1 = argmax-merge compare / index add as kept prefix trees (exact); 2 = negative control (index add carry-in 1)
    parameter integer HRC = 0,        // el1011-q-seq SC (d): FIFO-head read select h_rd as HRC kept copies, each selecting INSTR_BITS / HRC
                                      //   bits of ir (was one flop driving 1,024 mux selects: -75 into kvd_* / me issue); 0 = one; exact
    parameter integer HRCM = 0,       // negative control: copy 0 does not toggle on a load
    parameter integer DPRE = 0,       // TT head h9: decode base+DYN adds computed per FIFO head word (hq / hq1)
                                      // from flops, then a 2:1 select by an h_rd copy (exact, 0 edges; FQ_HEAD 2 only)
    parameter integer DSEL = 0,       // TT head h14 (Q-TTH14 10-17): the DPRE adds' DYN operand dyn[F(D_*)] registered per head
                                      //   word (dq0 / dq1), written on the same edge as hq / hq1 by a kept fill slice (dyn is written
                                      //   only in S_DYN and words fill only in S_RUN, so the register equals dyn[F(D_*)] whenever the
                                      //   word decodes).  Removes the dyn 8:1 select and its wire from the decode add (h13 gate
                                      //   dyn[2] -> 400 ps of repeaters -> obase add, -64.8 ps).  Exact, 0 edges; needs DPRE, HFC > 1,
                                      //   FQ_HEAD 2.  OT_DSEL_MUT: negative control (the registered select reads dyn[idx ^ 1])
    parameter integer HFC = 0,        // Q-COMPUTE-ELEM r2 10-15: FIFO-head FILL as HFC kept slices (exact, 0 cycles). Each slice
                                      //   owns copies of the head-fill state (st==S_RUN, fq_n!=0, hc, h_wr, fq_rd) with the same
                                      //   next state, and writes INSTR_BITS / HFC bits of hq / hq1 (h3 gate: st[1] -> hq_fill ->
                                      //   2,048 enables = 1 ns of buffering, reg->reg -632.6 ps).  0 = one shared fill (as before)
    parameter integer HFCM = 0,       // negative control: slice 0's h_wr copy does not toggle on a fill
    // Q-TTH15 h15 (10-17, coordinator-approved structure; all exact, 0 edges, default 0 = unchanged):
    parameter integer FQWE = 0,       // FIFO write enables as registered one-hot copies we_c[entry][slice] = the exact next state of
                                      //   push && fq_wr == entry (needs HFC > 1, FQ_HEAD >= 2, PRL > 1); fq held in per-entry vectors.
                                      //   h14d: pend2 -> 8 levels -> 1,024-load enable tree -> fq, -116.8 ps.  OT_FQWE_MUT: slice 0 of
                                      //   entry 0 never written (negative control)
    parameter integer OINC = 0,       // o_cnt <= o_cnt1 on skip (o_cnt1 == o_cnt + 1 is kept), o_cnt1 increments through a Kogge-Stone
                                      //   incrementer (h14d: 24-b incrementer as a 12-level OR3 ripple, st -> o_cnt -110.4).
                                      //   OT_OINC_MUT: o_cnt1 increments by 2 (negative control)
    parameter integer DTIL = 0,       // DPRE/DSEL for me_tiles: the DYN / DYN_TTILES operand (incl. the dts 16:1 select) registered per
                                      //   head word at fill, KS add per word, 2:1 select by an h_rd copy (h14d hq -> dsel 16:1 -> 18-b add
                                      //   -103.6).  Needs DSEL, PCUT.  OT_DTIL_MUT: the registered select reads dts[split ^ 1]
    parameter integer AMWC = 0,       // argmax merge: am_wins as 3 kept_hierarchy copies (run_key / run_idx / run_val) besides the original
                                      //   (run_any + the fin outputs).  OT_AMWC_MUT: the run_val copy ignores run_any (negative control)
    parameter integer RRH = 0,        // the HFC / DSEL / FQWE slice state resets from rst_hfc_n[k * 4 / HFC] (4 more kept reset copies of
                                      //   the same function as rst_n) instead of rst_n (h14d recovery g_rrg r[1] fo717 -> hcf_c -47.8)
    parameter integer EMB_CODE_LANES = 64,
    parameter integer EMB_ADDR_BASE = 0, // element address of embedding row 0 in the program
    parameter integer SMIN = 0,
    parameter integer SMAX = 0,
    parameter integer TCUT = 0,
    parameter integer BD = 0,
    parameter integer XVM = 0,
    parameter integer NWS = 0,
    parameter integer TWS = 0,
    parameter integer ORD = 0,
    parameter integer SCALE_LOCAL = 0,
    parameter integer MEM_EXTRA = 0,
    parameter integer ACC_LAT = 5,
    parameter integer TREE_LAT = 3,
    parameter integer MUL_LAT = 5,
    parameter integer FAST_ISSUE = 0,
    parameter integer KV_PREP = 0
) (
    input  wire              clk,
    input  wire              rst_n,
    input  wire              start,
    // Calendar pulses replace INTERNAL issue/fin. Status never gates them.
    input wire fixed_issue, input wire fixed_end,
    input wire [1:0] fixed_unit, input wire fixed_fault,
    output wire accepted_start,
    output wire candidate_v, output wire [PAW-1:0] candidate_pc,
    output wire [1:0] candidate_unit,
    output wire candidate_available, output wire candidate_end_ok,
    input  wire [NW-1:0]     token,
    input  wire [NW-1:0]     pos,
    output reg               done,
    output reg  [NW-1:0]     next_token,
    output reg  [31:0]       next_val,        // its logit (for an argmax combined across packages)
    output reg  [31:0]       cycles,
    output reg               fault,
`ifdef OT_QFD_XPF_MONITOR
    // Real NEXT candidate / issue events for the static compiler schedule monitor.
    output wire dvm_candidate_v, output wire [PAW-1:0] dvm_candidate_pc,
    output wire [1:0] dvm_candidate_unit, output wire dvm_issue,
`endif
    // program ROM
    output reg               prog_re,
    output reg  [PAW-1:0]    prog_addr,
    input  wire [INSTR_BITS-1:0] prog_q,
    // weight ROM
    output wire              wrom_re,
    output wire [AW-1:0]     wrom_addr,
    input  wire [G*W*16-1:0] wrom_q,
    // Separate matrix code and scale banks avoid aliasing the stream's BF16
    // embedding reads. Both are synchronous, with one-cycle read latency.
    output wire              int8_wrom_re,
    output wire [AW-1:0]     int8_wrom_addr,
    output wire              scale_re,
    output wire [(G >> SMIN)-1:0] scale_gre,
    output wire [(G >> SMIN)*AW-1:0] scale_addr,
    input  wire [(G >> SMIN)*W*16-1:0] scale_q,
    // Independent 8-bit embedding bank and one BF16 scale per token row.
    output wire              embed_code_re,
    output wire [AW-1:0]     embed_code_addr,
    input  wire [EMB_CODE_LANES*8-1:0] embed_code_q,
    output wire              embed_scale_re,
    output wire [NW-1:0]     embed_scale_addr,
    input  wire [15:0]       embed_scale_q,
    // constant ROM
    output wire [SW-1:0]     crom_re,
    output wire [SW*AW-1:0]  crom_addr,
    input  wire [SW*64-1:0]  crom_q,
    // KV SRAM
    output wire              kv_re,
    output wire [SW-1:0]     kv_we,
    output wire [SW*AW-1:0]  kv_waddr,
    output wire [SW*32-1:0]  kv_wdata,
    // Optional vector KV bridge drain. The vector stream cannot stall once
    // issued, so the bridge buffers one whole KV-write op and drains before
    // the sequencer starts another stream op or retires the token.
    input  wire              kv_write_drained,
    output wire              kv_write_flush, // finish a partial V sector while SU is idle
    // vector memory: G + 3 element read ports, G + 2 write ports
    output wire [SW-1:0]     va_re,
    output wire [SW*AW-1:0]  va_addr,
    input  wire [SW*32-1:0]  va_q,
    output wire [SW-1:0]     vb_re,
    output wire [SW*AW-1:0]  vb_addr,
    input  wire [SW*32-1:0]  vb_q,
    output wire [SW-1:0]     vc_re,
    output wire [SW*AW-1:0]  vc_addr,
    input  wire [SW*32-1:0]  vc_q,
    output wire [(G >> SMIN)-1:0] vw_me_we,
    output wire [(G >> SMIN)*AW-1:0] vw_me_addr,       // words
    output wire [(G >> SMIN)*W-1:0] vw_me_mask,
    output wire [(G >> SMIN)*W*32-1:0] vw_me_data,
    output wire [SW-1:0]     vw_su_we,
    output wire [SW*AW-1:0]  vw_su_addr,
    output wire [SW*32-1:0]  vw_su_data,
    output wire              vw_rd_we,
    output wire [AW-1:0]     vw_rd_addr,
    output wire [31:0]       vw_rd_data,
    // the engine's per-slot maxima (one masked word; me_rmax)
    output wire              vw_mx_we,
    output wire [AW-1:0]     vw_mx_addr,
    output wire [W-1:0]      vw_mx_mask,
    output wire [W*32-1:0]   vw_mx_data,
    // observation: every matrix-vector result word
    output wire              me_ov,
    // KV-streaming handshake (KV_HBM = 1 only)
    output reg               kvd_v,           // descriptor of the KV op now waiting to issue
    output wire [AW-1:0]     kvd_wbase, kvd_ts, kvd_ks, kvd_js,
    output wire [AW-1:0]     kvd_wcs,
    output wire [3:0]        kvd_split,
    output wire [2:0]        kvd_jsh,
    output wire [NW-1:0]     kvd_tiles, kvd_k, kvd_nout,
    output wire              kvd_kindk,       // positions tile the lanes (scores); else positions are k (weighted sum)
    output wire [NW-1:0]     kvd_pos,
    input  wire              kv_ok,
    // Weight supply handshake. Both comparator modes use this same FIFO/vector
    // controller and chunked program; W_HBM selects only the weight source.
    output wire              wrom_su,
    output reg               wd_v,
    output wire [AW-1:0]     wd_wbase,
    output wire [AW-1:0]     wd_sbase,
    output wire [NW-1:0]     wd_tiles, wd_k, wd_nout,
    // W12 array spine: the vector memory's x chunk port and the tile fabric
    output wire [(1<<SMAX)-1:0]    vx_re,
    output wire [(1<<SMAX)*AW-1:0] vx_addr,
    input  wire [(1<<SMAX)*32-1:0] vx_q,
    output wire              tgo,
    output wire [3*NW+13*AW+13-1:0] tb,
    output wire [(1<<SMAX)*32-1:0] xl_d,
    input  wire [(G >> TCUT)*W*32-1:0] t_lvl,
    input  wire              fab_fault,
    input  wire              w_ok, emb_ok,
    input  wire              me_mem_ok,      // ME_STALL: every engine read presented now is served at the next edge
    output wire              me_clk_en,      // ME_STALL: this edge clocks the engine (pre-edge value)
    // -- partition ports (tools/qwen_missing/emit_partition.py) --
    output wire [1-1:0] po_me_clk,
    output wire [1-1:0] po_me_go,
    input  wire [1-1:0] pi_me_ready,
    input  wire [1-1:0] pi_me_idle,
    output wire [NW-1:0] po_me_i_nout,
    output wire [NW-1:0] po_me_i_tiles,
    output wire [NW-1:0] po_me_i_k,
    output wire [1-1:0] po_me_i_wsrc,
    output wire [AW-1:0] po_me_i_wbase,
    output wire [AW-1:0] po_me_i_ts,
    output wire [AW-1:0] po_me_i_ks,
    output wire [AW-1:0] po_me_i_js,
    output wire [AW-1:0] po_me_i_xbase,
    output wire [AW-1:0] po_me_i_xks,
    output wire [AW-1:0] po_me_i_xjs,
    output wire [AW-1:0] po_me_i_xcs,
    output wire [3-1:0] po_me_i_jsh,
    output wire [4-1:0] po_me_i_split,
    output wire [AW-1:0] po_me_i_wcs,
    output wire [1-1:0] po_me_i_round,
    output wire [AW-1:0] po_me_i_obase,
    output wire [AW-1:0] po_me_i_ots,
    output wire [AW-1:0] po_me_i_ojs,
    output wire [1-1:0] po_me_i_mmode,
    output wire [1-1:0] po_me_i_oen,
    output wire [1-1:0] po_me_i_amax,
    output wire [1-1:0] po_me_i_rmax,
    output wire [AW-1:0] po_me_i_mbase,
    input  wire [1-1:0] pi_me_mx_we,
    input  wire [1-1:0] pi_me_wrom_re,
    input  wire [AW-1:0] pi_me_wrom_addr,
    input  wire [(G >> SMIN)-1:0] pi_me_o_we,
    input  wire [NW-1:0] pi_me_am_idx,
    input  wire [32-1:0] pi_me_am_val,
    input  wire [1-1:0] pi_me_am_any,
    input  wire [16-1:0] pi_me_progress,
    input  wire [1-1:0] pi_me_fault,
    input  wire [1-1:0] pi_su_rt_active,
    input  wire [8-1:0] pi_su_rt_inflight,
    output wire [1-1:0] po_su_go,
    input  wire [1-1:0] pi_su_ready,
    input  wire [1-1:0] pi_su_idle,
    output wire [NW-1:0] po_su_i_nout,
    output wire [NW-1:0] po_su_i_nin,
    output wire [1-1:0] po_su_i_asrc,
    output wire [AW-1:0] po_su_i_abase,
    output wire [AW-1:0] po_su_i_aso,
    output wire [AW-1:0] po_su_i_asi,
    output wire [1-1:0] po_su_i_bsrc,
    output wire [AW-1:0] po_su_i_bbase,
    output wire [AW-1:0] po_su_i_bso,
    output wire [AW-1:0] po_su_i_bsi,
    output wire [1-1:0] po_su_i_csrc,
    output wire [AW-1:0] po_su_i_cbase,
    output wire [AW-1:0] po_su_i_cso,
    output wire [AW-1:0] po_su_i_csi,
    output wire [2-1:0] po_su_i_ma,
    output wire [2-1:0] po_su_i_mb,
    output wire [3-1:0] po_su_i_ad,
    output wire [3-1:0] po_su_i_sfu,
    output wire [1-1:0] po_su_i_mc,
    output wire [1-1:0] po_su_i_md,
    output wire [2-1:0] po_su_i_dst,
    output wire [AW-1:0] po_su_i_dbase,
    output wire [AW-1:0] po_su_i_dso,
    output wire [AW-1:0] po_su_i_dsi,
    output wire [2-1:0] po_su_i_red,
    output wire [1-1:0] po_su_i_redsq,
    output wire [AW-1:0] po_su_i_rbase,
    output wire [AW-1:0] po_su_i_rso,
    output wire [32-1:0] po_su_i_imm1,
    output wire [32-1:0] po_su_i_imm2,
    input  wire [SW-1:0] pi_su_va_re,
    input  wire [SW*AW-1:0] pi_su_va_addr,
    output wire [SW*32-1:0] po_su_va_q,
    input  wire [1-1:0] pi_su_wrom_re,
    input  wire [AW-1:0] pi_su_wrom_addr,
    input  wire [SW-1:0] pi_su_kv_we,
    input  wire [16-1:0] pi_su_progress,
    input  wire [16-1:0] pi_su_progress_rows,
    input  wire [1-1:0] pi_su_fault,
    output wire [1-1:0] po_su_asrc_raw,
    // -- redesign-qwen two-controller ports --
    input  wire [XW-1:0] x_oacc,          // other unit: ops accepted (snapshot)
    input  wire          x_oidle,
    input  wire [15:0]   x_oprog,
    input  wire [15:0]   x_orows,
    input  wire          x_ofin,          // ME side reached END (its fold final): SU side only
    input  wire [NW-1:0] x_fidx,
    input  wire [31:0]   x_fval,
    output wire          o_fin,
    output wire [NW-1:0] o_fidx,
    output wire [31:0]   o_fval,
    input  wire [3:0]    rst_hfc_n    // RRH: reset copies for the head-fill slices (unused when RRH = 0)
);
    // ---- inlined rtl/hdc/ot_hdc_isa.svh ----
// GENERATED by tools/hdc_isa.py -- do not edit.
// Field offsets of one HDC instruction word; see the tool for semantics.
// Included inside a module body.
localparam integer ISA_INSTR_BITS = 1024;
localparam integer O_UNIT = 0;
localparam integer W_UNIT = 2;
localparam integer O_BARRIER = 2;
localparam integer W_BARRIER = 1;
localparam integer O_CHASE = 3;
localparam integer W_CHASE = 1;
localparam integer O_CHASE_N = 4;
localparam integer W_CHASE_N = 16;
localparam integer O_WAIT_ME = 20;
localparam integer W_WAIT_ME = 1;
localparam integer O_WAIT_SU = 21;
localparam integer W_WAIT_SU = 1;
localparam integer O_CHASE_ROWS = 22;
localparam integer W_CHASE_ROWS = 1;
localparam integer O_ME_NOUT = 23;
localparam integer W_ME_NOUT = 16;
localparam integer O_ME_TILES = 39;
localparam integer W_ME_TILES = 16;
localparam integer O_ME_K = 55;
localparam integer W_ME_K = 16;
localparam integer O_ME_WSRC = 71;
localparam integer W_ME_WSRC = 1;
localparam integer O_ME_WBASE = 72;
localparam integer W_ME_WBASE = 24;
localparam integer O_ME_TS = 96;
localparam integer W_ME_TS = 24;
localparam integer O_ME_KS = 120;
localparam integer W_ME_KS = 24;
localparam integer O_ME_JS = 144;
localparam integer W_ME_JS = 24;
localparam integer O_ME_XBASE = 168;
localparam integer W_ME_XBASE = 24;
localparam integer O_ME_ROUND = 192;
localparam integer W_ME_ROUND = 1;
localparam integer O_ME_OBASE = 193;
localparam integer W_ME_OBASE = 24;
localparam integer O_ME_OEN = 217;
localparam integer W_ME_OEN = 1;
localparam integer O_ME_AMAX = 218;
localparam integer W_ME_AMAX = 1;
localparam integer O_ME_D_WBASE = 219;
localparam integer W_ME_D_WBASE = 3;
localparam integer O_ME_D_XBASE = 222;
localparam integer W_ME_D_XBASE = 3;
localparam integer O_ME_D_OBASE = 225;
localparam integer W_ME_D_OBASE = 3;
localparam integer O_ME_D_NOUT = 228;
localparam integer W_ME_D_NOUT = 3;
localparam integer O_ME_D_TILES = 231;
localparam integer W_ME_D_TILES = 3;
localparam integer O_ME_D_K = 234;
localparam integer W_ME_D_K = 3;
localparam integer O_ME_XKS = 237;
localparam integer W_ME_XKS = 24;
localparam integer O_ME_XJS = 261;
localparam integer W_ME_XJS = 24;
localparam integer O_ME_JSH = 285;
localparam integer W_ME_JSH = 3;
localparam integer O_ME_OTS = 288;
localparam integer W_ME_OTS = 24;
localparam integer O_ME_OJS = 312;
localparam integer W_ME_OJS = 24;
localparam integer O_ME_MMODE = 336;
localparam integer W_ME_MMODE = 1;
localparam integer O_ME_SPLIT = 337;
localparam integer W_ME_SPLIT = 4;
localparam integer O_ME_XCS = 341;
localparam integer W_ME_XCS = 24;
localparam integer O_ME_WCS = 365;
localparam integer W_ME_WCS = 24;
localparam integer O_ME_RMAX = 389;
localparam integer W_ME_RMAX = 1;
localparam integer O_ME_MBASE = 390;
localparam integer W_ME_MBASE = 24;
localparam integer O_SU_NOUT = 414;
localparam integer W_SU_NOUT = 16;
localparam integer O_SU_NIN = 430;
localparam integer W_SU_NIN = 16;
localparam integer O_SU_D_NIN = 446;
localparam integer W_SU_D_NIN = 3;
localparam integer O_A_SRC = 449;
localparam integer W_A_SRC = 1;
localparam integer O_A_BASE = 450;
localparam integer W_A_BASE = 24;
localparam integer O_A_SO = 474;
localparam integer W_A_SO = 24;
localparam integer O_A_SI = 498;
localparam integer W_A_SI = 24;
localparam integer O_A_D = 522;
localparam integer W_A_D = 3;
localparam integer O_B_SRC = 525;
localparam integer W_B_SRC = 1;
localparam integer O_B_BASE = 526;
localparam integer W_B_BASE = 24;
localparam integer O_B_SO = 550;
localparam integer W_B_SO = 24;
localparam integer O_B_SI = 574;
localparam integer W_B_SI = 24;
localparam integer O_B_D = 598;
localparam integer W_B_D = 3;
localparam integer O_C_SRC = 601;
localparam integer W_C_SRC = 1;
localparam integer O_C_BASE = 602;
localparam integer W_C_BASE = 24;
localparam integer O_C_SO = 626;
localparam integer W_C_SO = 24;
localparam integer O_C_SI = 650;
localparam integer W_C_SI = 24;
localparam integer O_C_D = 674;
localparam integer W_C_D = 3;
localparam integer O_MA = 677;
localparam integer W_MA = 2;
localparam integer O_MB = 679;
localparam integer W_MB = 2;
localparam integer O_AD = 681;
localparam integer W_AD = 3;
localparam integer O_SFU = 684;
localparam integer W_SFU = 3;
localparam integer O_MC = 687;
localparam integer W_MC = 1;
localparam integer O_MD = 688;
localparam integer W_MD = 1;
localparam integer O_DST = 689;
localparam integer W_DST = 2;
localparam integer O_D_BASE = 691;
localparam integer W_D_BASE = 24;
localparam integer O_D_SO = 715;
localparam integer W_D_SO = 24;
localparam integer O_D_SI = 739;
localparam integer W_D_SI = 24;
localparam integer O_D_D = 763;
localparam integer W_D_D = 3;
localparam integer O_RED = 766;
localparam integer W_RED = 2;
localparam integer O_R_BASE = 768;
localparam integer W_R_BASE = 24;
localparam integer O_R_SO = 792;
localparam integer W_R_SO = 24;
localparam integer O_RED_SQ = 816;
localparam integer W_RED_SQ = 1;
localparam integer O_IMM1 = 817;
localparam integer W_IMM1 = 32;
localparam integer O_IMM2 = 849;
localparam integer W_IMM2 = 32;
localparam integer O_ME_ROW0 = 881;
localparam integer W_ME_ROW0 = 16;
localparam integer O_ME_AMC = 897;
localparam integer W_ME_AMC = 1;

    localparam integer LW = $clog2(W);
    localparam integer LT = $clog2(W * IL);

    // -- sequencer ----------------------------------------------------------------
    localparam [1:0] S_IDLE = 0, S_DYN = 1, S_RUN = 2;
    localparam integer NFQ = 4;           // program words held or in flight
    reg [1:0]  st;
    reg [PAW-1:0] pc;                     // index of the instruction in NEXT
    reg [PAW-1:0] fpc;                    // next word to fetch
    reg [NW-1:0] tok_r, pos_r;
    reg [AW-1:0] dyn [0:7];
    wire [NW-1:0] dyn_tiles_zero, dyn_tiles_split;
    wire dyn_tiles_invalid;
    reg [INSTR_BITS-1:0] fq [0:NFQ-1];
    wire [INSTR_BITS-1:0] fqv [0:NFQ-1];  // h15 FQWE: the FIFO words as read (= fq when FQWE = 0)
    wire [16*NW-1:0] dts_all;             // h15 DTIL: the 16 registered DYN_TTILES rounds (g_dtab)
    reg  [NW-1:0] tq0, tq1;               // h15 DTIL: the me_tiles DYN operand of hq / hq1
    reg [1:0]  fq_rd, fq_wr;
    reg [2:0]  fq_n;
    reg        pend1;                     // a program read whose word arrives this cycle
    reg        pend2;                     // PRL 2: ... the cycle after
    reg  [INSTR_BITS-1:0] hq;            // FQ_HEAD: registered head word
    reg                   hq_v;
    reg  [INSTR_BITS-1:0] hq1;           // FQ_HEAD 2: second head word
    reg  [10*AW-1:0]      dq0;           // DSEL (flat, no memory inference): dyn[F(D_*)] of hq, per DPRE field (nout k wbase xbase obase su_nin a b c d)
    reg  [10*AW-1:0]      dq1;           // DSEL: ... of hq1
    reg                   h_rd, h_wr;    // FQ_HEAD 2: head read / write pointers
    reg  [1:0]            hc;            // FQ_HEAD 2: head words held
    wire                  hv = (FQ_HEAD >= 2) ? (hc != 2'd0) : hq_v;
    wire [INSTR_BITS-1:0] ir_h2;
    localparam integer HRN = (HRC > 1) ? HRC : 1;
    (* keep *) reg [HRN-1:0] h_rd_c;      // SC (d) copies (next state: after `load` below)
    generate if (HRC > 1 && FQ_HEAD >= 2) begin : g_hrc
        //: SC (d): h_rd copies, same next state as h_rd (reset, start, toggle on load), each driving its slice's selects
        genvar hb;
        for (hb = 0; hb < INSTR_BITS; hb = hb + 1) begin : g_b
            assign ir_h2[hb] = h_rd_c[(hb * HRC) / INSTR_BITS] ? hq1[hb] : hq[hb];
        end
    end else begin : g_hr1
        assign ir_h2 = h_rd ? hq1 : hq;
    end endgenerate
    wire [INSTR_BITS-1:0] ir = (FQ_HEAD >= 2) ? ir_h2 : (FQ_HEAD != 0) ? hq : fqv[fq_rd]; // FIFO head: the word decode reads
    reg        nx_v;                      // NEXT holds a decoded instruction
    wire       me_go, su_go;
    wire       me_ready, me_idle, su_ready, su_idle;
    wire       me_fault, su_fault;
    wire [NW-1:0] am_idx;
    wire [31:0] am_val;
    wire       am_any;

    `define F(name) ir[O_``name +: W_``name]
    ot_hdc_dyn_ttiles #(.W(W),.G(DG),.NW(NW)) u_dyn_tiles_zero (
        .pos(pos_r),.split_log2(4'd0),.rounds(dyn_tiles_zero),.invalid_split());
    ot_hdc_dyn_ttiles #(.W(W),.G(DG),.NW(NW)) u_dyn_tiles_split (
        .pos(pos_r),.split_log2(`F(ME_SPLIT)),.rounds(dyn_tiles_split_c),
        .invalid_split(dyn_tiles_invalid_c));
    wire [NW-1:0] dyn_tiles_split_c; wire dyn_tiles_invalid_c;
    generate if (PCUT != 0) begin : g_dtab
        wire [16*NW-1:0] dts; wire [15:0] dti;
        genvar ds;
        for (ds = 0; ds < 16; ds = ds + 1) begin : g_ds
            wire [NW-1:0] r_w; wire i_w; reg [NW-1:0] r_q; reg i_q;
            ot_hdc_dyn_ttiles #(.W(W),.G(DG),.NW(NW)) u_t (.pos(pos_r),.split_log2(4'(ds)),.rounds(r_w),.invalid_split(i_w));
            always @(posedge clk) if (st == S_DYN) begin r_q <= r_w; i_q <= i_w; end
            assign dts[ds*NW +: NW] = r_q; assign dti[ds] = i_q;
        end
        wire [3:0] dsel = 4'(`F(ME_SPLIT)) + ((PCUT == 4) ? 4'd1 : 4'd0);
        assign dyn_tiles_split = dts[dsel*NW +: NW];
        assign dyn_tiles_invalid = dti[dsel];
        assign dts_all = dts;
    end else begin : g_dcomb
        assign dyn_tiles_split = dyn_tiles_split_c; assign dyn_tiles_invalid = dyn_tiles_invalid_c;
        assign dts_all = '0;
    end endgenerate
    wire dyn_tiles_bad_instruction = load && `F(ME_D_TILES) == 3'd6 && dyn_tiles_invalid;

    // decoded, DYN-adjusted fields
    reg [1:0]    d_unit;
    reg          d_barrier;
    reg [NW-1:0] me_nout, me_tiles, me_k;
    reg          me_wsrc, me_round, me_oen, me_amax, me_mmode, d_chase, d_wait_me, d_wait_su, me_rmax, me_amc;
    reg [NW-1:0] me_row0;
    reg [AW-1:0] me_mbase;
    reg [15:0]   d_chase_n;
    reg [AW-1:0] me_wbase, me_ts, me_ks, me_js, me_xbase, me_obase, me_xks, me_xjs, me_ots, me_ojs;
    reg [2:0]    me_jsh;
    reg [3:0]    me_split;
    reg [AW-1:0] me_xcs, me_wcs;
    reg [NW-1:0] su_nout, su_nin;
    reg          a_src, b_src, c_src, mc;
    reg [AW-1:0] a_base, a_so, a_si, b_base, b_so, b_si, c_base, c_so, c_si;
    reg [AW-1:0] d_base, d_so, d_si, r_base, r_so;
    reg [1:0]    ma, mb, dst, red;
    reg [2:0]    sfu;
    reg          redsq, md;
    reg [2:0]    ad;
    reg [31:0]   imm1, imm2;

    wire [15:0] su_progress, me_progress, su_rows;
    reg          d_chase_rows;
    reg          me_kindk;
    wire me_en;
    wire unit_ready = (d_unit == 2'd1) ? (me_ready && me_en) :
                      (su_ready && (!KV_VEC_WRITE_BRIDGE || (su_idle && kv_write_drained)));
    //: KV_HBM: a KV op waits for the streamer; never on the cycle its
    //: descriptor is announced, when kv_ok may still describe the previous op.
    wire kv_gate = (KV_HBM == 0) || !(d_unit == 2'd1 && me_wsrc) || (kv_ok && !kvd_v);
    wire w_gate = (W_HBM == 0) || ((d_unit == 2'd1) ?
                  (me_wsrc || (w_ok && !wd_v)) : (!a_src || emb_ok));
    //: the units' idle and progress are registered and cleared on the edge
    //: that accepts an op, so a go needs no guard term here
    wire drained = me_idle && su_idle && (!KV_VEC_WRITE_BRIDGE || kv_write_drained);
    assign kv_write_flush = su_idle && !(|kv_we);
    //: A chasing op waits only until the OTHER unit's latest op has made
    //: chase_n progress.
    // redesign-qwen two controllers: own / other unit, the other side's snapshot, the dependency hold
    reg  [XW-1:0] o_cnt;                       // other-unit instructions passed so far
    wire own = (d_unit == OWN[1:0]);
    wire oth = (d_unit != 2'd0) && !own;
    wire [XW-1:0] o_dif = x_oacc - o_cnt;
    wire osync_c = (o_dif == {XW{1'b0}});      // the other unit accepted exactly its earlier ops
    wire opast_c = !osync_c && !o_dif[XW-1];   // ... and the one at NEXT
    //: XREG: compare the snapshot with the NEXT edge's count, registered (the snapshot only climbs toward the count while
    //: a dependent instruction waits, so a one-edge-old snapshot is conservative)
    reg osync_r, opast_r;
    wire osync = (XREG != 0) ? osync_r : osync_c;
    wire opast = (XREG != 0) ? opast_r : opast_c;
    wire own_idle = (OWN == 1) ? me_idle : su_idle;
    wire o_drained = osync && x_oidle;
    wire x_drained = own_idle && o_drained && (!KV_VEC_WRITE_BRIDGE || kv_write_drained);
    wire [15:0] x_och = (OWN == 1) ? (d_chase_rows ? x_orows : x_oprog) : x_oprog;
    wire chased = osync && ((PCUT != 0) ? uge16(x_och, d_chase_n) : (x_och >= d_chase_n));
    wire wait_o = (OWN == 1) ? d_wait_su : d_wait_me;
    wire wait_u = (OWN == 1) ? d_wait_me : d_wait_su;
    wire xdep_ok = (XMUT == 1 && OWN == 1) ? 1'b1 :
                   (d_barrier ? x_drained : ((!d_chase || chased) && (!wait_u || own_idle) && (!wait_o || o_drained)));
    wire odep = (XMUT == 2) ? 1'b0 : (d_barrier || d_chase || ((OWN == 1) ? d_wait_me : d_wait_su));
    wire skip = (st == S_RUN) && nx_v && oth;
    //: issue NEXT this cycle; the unit latches its fields on this edge
`ifdef OT_QFD_XPF_MONITOR
    assign dvm_candidate_v = (st == S_RUN) && nx_v && own;
    assign dvm_candidate_pc = pc;
    assign dvm_candidate_unit = d_unit;
    assign dvm_issue = issue;
`endif
    wire issue_live = (st == S_RUN) && nx_v && own && xdep_ok
                 && unit_ready && kv_gate && w_gate;
    reg ready_q;
    wire issue = fixed_issue;
    assign me_go = issue && (fixed_unit == 2'd1);
    assign su_go = issue && (fixed_unit == 2'd2);
    wire fin = fixed_end;
    assign accepted_start=start&&(st==S_IDLE);
    assign candidate_v=(st==S_RUN)&&nx_v&&(own||d_unit==0);
    assign candidate_pc=pc;
    assign candidate_unit=d_unit;
    assign candidate_available=issue_live;
    assign candidate_end_ok=(st==S_RUN)&&nx_v&&(d_unit==0)&&x_drained&&((OWN==1)||x_ofin);
    reg fin_seen;                              // this controller reached END in this run
    always @(posedge clk or negedge rst_n)
        if (!rst_n) fin_seen <= 1'b0;
        else if (start && st == S_IDLE) fin_seen <= 1'b0;
        else if (fin) fin_seen <= 1'b1;
    assign o_fin = fin_seen;
    reg [XW-1:0] o_cnt1;                       // o_cnt + 1, kept in step
    generate if (OINC != 0) begin : g_oinc
        //: h15 OINC: o_cnt takes o_cnt1 (== o_cnt + 1) on a skip; o_cnt1 adds one through a Kogge-Stone incrementer
        wire [XW-1:0] o_inc; wire o_inc_co;
`ifdef OT_OINC_MUT
        ot_hdc_ksadd_k #(.W(XW)) u_oinc (.a(o_cnt1), .b({{(XW-1){1'b0}}, 1'b1}), .cin(1'b1), .s(o_inc), .cout(o_inc_co));
`else
        ot_hdc_ksadd_k #(.W(XW)) u_oinc (.a(o_cnt1), .b({XW{1'b0}}), .cin(1'b1), .s(o_inc), .cout(o_inc_co));
`endif
        always @(posedge clk or negedge rst_n)
            if (!rst_n) o_cnt <= {XW{1'b0}};
            else if (skip) o_cnt <= o_cnt1;
        always @(posedge clk or negedge rst_n)
            if (!rst_n) o_cnt1 <= {{(XW-1){1'b0}}, 1'b1};
            else if (skip) o_cnt1 <= o_inc;
`ifndef SYNTHESIS
`ifndef OT_OINC_MUT
        always @(posedge clk) if (rst_n && o_cnt1 !== o_cnt + 1'b1) $fatal(1, "OINC o_cnt1 != o_cnt + 1");
`endif
`endif
    end else begin : g_oinc0
        always @(posedge clk or negedge rst_n)
            if (!rst_n) o_cnt <= {XW{1'b0}};
            else if (skip) o_cnt <= o_cnt + 1'b1;
        always @(posedge clk or negedge rst_n)
            if (!rst_n) o_cnt1 <= {{(XW-1){1'b0}}, 1'b1};
            else if (skip) o_cnt1 <= o_cnt1 + 1'b1;
    end endgenerate
    wire [XW-1:0] o_dif0 = x_oacc - o_cnt, o_dif1 = x_oacc - o_cnt1;
    wire o_eq0 = (PCUT != 0) ? (x_oacc == ((PCUT == 2) ? o_cnt1 : o_cnt)) : (o_dif0 == {XW{1'b0}});
    wire o_eq1 = (PCUT != 0) ? (x_oacc == ((PCUT == 2) ? o_cnt : o_cnt1)) : (o_dif1 == {XW{1'b0}});
    // PCUT: unsigned a >= b as a log-depth prefix tree (no carry chain); PCUT 3 = strict > (negative control)
    function automatic uge16(input [15:0] a, input [15:0] b);
        reg [15:0] g, e; integer k, sp;
        begin
            g = a & ~b; e = ~(a ^ b);
            for (sp = 1; sp < 16; sp = sp * 2)
                for (k = 15; k >= 0; k = k - 1)
                    if ((k % (2 * sp)) == (2 * sp - 1)) begin g[k] = g[k] | (e[k] & g[k - sp]); e[k] = e[k] & e[k - sp]; end
            uge16 = g[15] | ((PCUT == 3) ? 1'b0 : e[15]);
        end
    endfunction
    wire o_pa0 = !o_eq0 && !o_dif0[XW-1], o_pa1 = !o_eq1 && !o_dif1[XW-1];
    wire [XW-1:0] o_dif_n = x_oacc - (o_cnt + {{(XW-1){1'b0}}, skip});
    always @(posedge clk or negedge rst_n)
        if (!rst_n) begin osync_r <= 1'b1; opast_r <= 1'b0; end
        else begin osync_r <= skip ? o_eq1 : o_eq0; opast_r <= skip ? o_pa1 : o_pa0; end
    //: decode the FIFO head into NEXT when NEXT is empty or issuing
    wire load = (st == S_RUN) && ((FQ_HEAD != 0) ? hv : (fq_n != 0)) && (!nx_v || issue || skip);
    generate if (HRC > 1 && FQ_HEAD >= 2) begin : g_hrcs
        always @(posedge clk or negedge rst_n)
            if (!rst_n) h_rd_c <= {HRN{1'b0}};
            else if (st == S_IDLE && start) h_rd_c <= {HRN{1'b0}};
            else if (st == S_RUN && load) h_rd_c <= ~h_rd_c ^ ((HRCM != 0) ? {{(HRN-1){1'b0}}, 1'b1} : {HRN{1'b0}});
    end else begin : g_hrcn
        always @(posedge clk) h_rd_c <= {HRN{1'b0}};
    end endgenerate
    // FQ_HEAD: the FIFO pops into hq when hq is empty or being loaded into NEXT
    wire hq_fill = (FQ_HEAD >= 2) ? ((st == S_RUN) && (fq_n != 0) && (hc != ((FQ_HEAD == 3) ? 2'd3 : 2'd2))) :
                  (FQ_HEAD != 0) && (st == S_RUN) && (fq_n != 0) && (!hq_v || load);
    wire fq_pop = (FQ_HEAD != 0) ? hq_fill : load;
    wire push = (st == S_RUN) && ((PRL > 1) ? pend2 : pend1);
    // FIFO-head fill slices (HFC).  The original single-fill writes are kept verbatim in g_hf1.
    localparam integer HFN = (HFC > 1 && FQ_HEAD >= 2) ? HFC : 1;
    generate if (HFC > 1 && FQ_HEAD >= 2) begin : g_hfc
        // next state of the fill terms, exactly as the main sequencer block computes them
        wire [1:0] st_nx = (st == S_IDLE) ? (start ? S_DYN : S_IDLE) : (st == S_DYN) ? S_RUN :
                           (st == S_RUN) ? (fin ? S_IDLE : S_RUN) : S_IDLE;
        wire [2:0] fqn_nx = (st == S_IDLE) ? (start ? 3'd0 : fq_n) :
                            (st == S_RUN) ? (fq_n + (push ? 3'd1 : 3'd0) - (fq_pop ? 3'd1 : 3'd0)) : fq_n;
        wire [1:0] hc_nx = (st == S_IDLE) ? (start ? 2'd0 : hc) :
                           (st == S_RUN) ? (hc + (hq_fill ? 2'd1 : 2'd0) - (load ? 2'd1 : 2'd0)) : hc;
        wire hwr_nx = (st == S_IDLE) ? (start ? 1'b0 : h_wr) : (st == S_RUN) ? (hq_fill ? !h_wr : h_wr) : h_wr;
        wire [1:0] fqrd_nx = (st == S_IDLE) ? (start ? 2'd0 : fq_rd) : (st == S_RUN) ? (fq_rd + (fq_pop ? 2'd1 : 2'd0)) : fq_rd;
        localparam [1:0] HCF = (FQ_HEAD == 3) ? 2'd3 : 2'd2;
        genvar k, hb;
        for (k = 0; k < HFC; k = k + 1) begin : g_k
            (* keep *) reg run_c, fqnz_c, hcf_c, hwr_c;
            (* keep *) reg [1:0] fqrd_c;
            wire rst_k = (RRH != 0) ? rst_hfc_n[(k * 4) / HFC] : rst_n;
            always @(posedge clk or negedge rst_k)
                if (!rst_k) begin run_c <= 1'b0; fqnz_c <= 1'b0; hcf_c <= 1'b1; hwr_c <= 1'b0; fqrd_c <= 2'd0; end
                else begin
                    run_c <= (st_nx == S_RUN); fqnz_c <= (fqn_nx != 3'd0); hcf_c <= (hc_nx != HCF);
                    hwr_c <= (HFCM != 0 && k == 0) ? h_wr : hwr_nx; fqrd_c <= fqrd_nx;
                end
            wire fill_c = run_c && fqnz_c && hcf_c;
            for (hb = (k * INSTR_BITS) / HFC; hb < ((k + 1) * INSTR_BITS) / HFC; hb = hb + 1) begin : g_b
                always @(posedge clk) begin
                    if (fill_c && !hwr_c) hq[hb] <= fqv[fqrd_c][hb];
                    if (fill_c && hwr_c) hq1[hb] <= fqv[fqrd_c][hb];
                end
            end
`ifndef SYNTHESIS
            always @(posedge clk) if (rst_n && HFCM == 0 &&
                (fill_c !== hq_fill || hwr_c !== h_wr || fqrd_c !== fq_rd))
                $fatal(1, "HFC slice %0d diverged from the head-fill state", k);
`endif
        end
        if (DSEL != 0) begin : g_dsel
`ifdef OT_DSEL_MUT
            localparam [2:0] DSX = 3'd1;
`else
            localparam [2:0] DSX = 3'd0;
`endif
            // one more kept fill slice (same next state as the HFC slices) writing the registered DYN selects
            (* keep *) reg run_d, fqnz_d, hcf_d, hwr_d;
            (* keep *) reg [1:0] fqrd_d;
            wire rst_d = (RRH != 0) ? rst_hfc_n[3] : rst_n;
            always @(posedge clk or negedge rst_d)
                if (!rst_d) begin run_d <= 1'b0; fqnz_d <= 1'b0; hcf_d <= 1'b1; hwr_d <= 1'b0; fqrd_d <= 2'd0; end
                else begin
                    run_d <= (st_nx == S_RUN); fqnz_d <= (fqn_nx != 3'd0); hcf_d <= (hc_nx != HCF);
                    hwr_d <= hwr_nx; fqrd_d <= fqrd_nx;
                end
            wire fill_d = run_d && fqnz_d && hcf_d;
            wire [3*10-1:0] dix = {fqv[fqrd_d][O_D_D +: 3], fqv[fqrd_d][O_C_D +: 3], fqv[fqrd_d][O_B_D +: 3],
                                   fqv[fqrd_d][O_A_D +: 3], fqv[fqrd_d][O_SU_D_NIN +: 3], fqv[fqrd_d][O_ME_D_OBASE +: 3],
                                   fqv[fqrd_d][O_ME_D_XBASE +: 3], fqv[fqrd_d][O_ME_D_WBASE +: 3], fqv[fqrd_d][O_ME_D_K +: 3],
                                   fqv[fqrd_d][O_ME_D_NOUT +: 3]};
            genvar df;
            for (df = 0; df < 10; df = df + 1) begin : g_f
                always @(posedge clk) begin
                    if (fill_d && !hwr_d) dq0[AW*df +: AW] <= dyn[dix[3*df +: 3] ^ DSX];
                    if (fill_d && hwr_d) dq1[AW*df +: AW] <= dyn[dix[3*df +: 3] ^ DSX];
                end
            end
`ifndef SYNTHESIS
            always @(posedge clk) if (rst_n && (fill_d !== hq_fill || hwr_d !== h_wr || fqrd_d !== fq_rd))
                $fatal(1, "DSEL fill slice diverged from the head-fill state");
`endif
            if (DTIL != 0) begin : g_dtil
                //: h15 DTIL: the me_tiles operand (DYN_TTILES 6: the registered dts round of the word's split; else dyn) with
                //: the word, by the DSEL fill slice (dyn / dts change only in S_DYN, words fill only in S_RUN)
`ifdef OT_DTIL_MUT
                localparam [3:0] DTX = 4'd1;
`else
                localparam [3:0] DTX = 4'd0;
`endif
                wire [2:0] td = fqv[fqrd_d][O_ME_D_TILES +: 3];
                wire [3:0] tsp = (4'(fqv[fqrd_d][O_ME_SPLIT +: W_ME_SPLIT]) + ((PCUT == 4) ? 4'd1 : 4'd0)) ^ DTX;
                wire [AW-1:0] tdyn = dyn[td];
                wire [NW-1:0] top = (td == 3'd6) ? dts_all[tsp*NW +: NW] : tdyn[NW-1:0];
                always @(posedge clk) begin
                    if (fill_d && !hwr_d) tq0 <= top;
                    if (fill_d && hwr_d) tq1 <= top;
                end
            end
        end
        if (FQWE != 0) begin : g_fqwe
            //: h15 FQWE: we_c[e][k] = the exact next state of push && fq_wr == e (PRL 2: push = S_RUN && pend2)
            wire pend2_nx = pend1 && (st != S_IDLE);
            wire [1:0] fqwr_nx = (st == S_IDLE) ? (start ? 2'd0 : fq_wr) : (st == S_RUN) ? (fq_wr + (push ? 2'd1 : 2'd0)) : fq_wr;
            wire push_nx = (st_nx == S_RUN) && pend2_nx;
            genvar e;
            for (e = 0; e < NFQ; e = e + 1) begin : g_e
                reg [INSTR_BITS-1:0] v;
                assign fqv[e] = v;
                for (k = 0; k < HFC; k = k + 1) begin : g_w
                    localparam integer LO = (k * INSTR_BITS) / HFC, HI = ((k + 1) * INSTR_BITS) / HFC;
                    wire rst_w = (RRH != 0) ? rst_hfc_n[(k * 4) / HFC] : rst_n;
                    (* keep *) reg we;
                    always @(posedge clk or negedge rst_w)
                        if (!rst_w) we <= 1'b0;
`ifdef OT_FQWE_MUT
                        else we <= push_nx && (fqwr_nx == e) && !(e == 0 && k == 0);
`else
                        else we <= push_nx && (fqwr_nx == e);
`endif
                    always @(posedge clk) if (we) v[HI-1:LO] <= prog_q[HI-1:LO];
`ifndef SYNTHESIS
`ifndef OT_FQWE_MUT
                    always @(posedge clk) if (rst_n && we !== (push && fq_wr == e))
                        $fatal(1, "FQWE enable %0d/%0d diverged from push && fq_wr", e, k);
`endif
`endif
                end
            end
        end else begin : g_fqm
            genvar e;
            for (e = 0; e < NFQ; e = e + 1) begin : g_e
                assign fqv[e] = fq[e];
            end
        end
    end else begin : g_hf1
        genvar e;
        for (e = 0; e < NFQ; e = e + 1) begin : g_e
            assign fqv[e] = fq[e];
        end
        always @(posedge clk) begin
            if (FQ_HEAD >= 2) begin
                if (st == S_RUN && hq_fill && !h_wr) hq <= fq[fq_rd];
                if (st == S_RUN && hq_fill && h_wr) hq1 <= fq[fq_rd];
            end else if (st == S_RUN && hq_fill) hq <= fq[fq_rd];
        end
    end endgenerate
    // ICUT: the readiness of the op at NEXT after this edge, against the status predicted after this edge
    wire own_ready = (OWN == 1) ? me_ready : su_ready;
    wire own_idle_n = own_idle && !issue;
    wire own_ready_n = own_ready && !issue;
    wire kd_n = kv_write_drained && !(issue && OWN == 2);
    wire osync_n = skip ? o_eq1 : o_eq0;
    wire o_drained_n = osync_n && x_oidle;
    function automatic rdy_x(input [1:0] u, input bar, input ch, input chr, input [15:0] chn, input wme, input wsu);
        reg chd, wo, wu, xd;
        begin
            chd = osync_n && ((OWN == 1 && chr) ? ((PCUT != 0) ? uge16(x_orows, chn) : (x_orows >= chn))
                                                : ((PCUT != 0) ? uge16(x_oprog, chn) : (x_oprog >= chn)));
            wo = (OWN == 1) ? wsu : wme;
            wu = (OWN == 1) ? wme : wsu;
            xd = (XMUT == 1 && OWN == 1) ? 1'b1 :
                 (bar ? (own_idle_n && o_drained_n && (!KV_VEC_WRITE_BRIDGE || kd_n)) :
                        ((!ch || chd) && (!wu || own_idle_n) && (!wo || o_drained_n)));
            rdy_x = (u == OWN[1:0]) && xd &&
                    ((OWN == 1) ? own_ready_n : (own_ready_n && (!KV_VEC_WRITE_BRIDGE || (own_idle_n && kd_n))));
        end
    endfunction
    generate if (ICUT != 0) begin : g_icut
`ifdef OT_ICUT_MUT_NOPRED
        // mutant: the own unit's status NOT predicted (it still reads ready / idle after its own go)
        wire r_load = rdy_x(`F(UNIT), `F(BARRIER), `F(CHASE), `F(CHASE_ROWS), `F(CHASE_N), `F(WAIT_ME), `F(WAIT_SU)) ||
                      ((`F(UNIT) == OWN[1:0]) && issue);
`else
        wire r_load = rdy_x(`F(UNIT), `F(BARRIER), `F(CHASE), `F(CHASE_ROWS), `F(CHASE_N), `F(WAIT_ME), `F(WAIT_SU));
`endif
        wire r_hold = rdy_x(d_unit, d_barrier, d_chase, d_chase_rows, d_chase_n, d_wait_me, d_wait_su);
        always @(posedge clk or negedge rst_n)
            if (!rst_n) ready_q <= 1'b0;
            else ready_q <= load ? r_load : r_hold;
`ifndef SYNTHESIS
        always @(posedge clk) if (1'b0) begin
            $display("ICUT_ILLEGAL_ISSUE t=%0t own=%0d", $time, OWN);
`ifndef OT_ICUT_NONFATAL
            $fatal(1, "ICUT issue without the live issue condition");
`endif
        end
`endif
    end else begin : g_noicut
        always @(posedge clk) ready_q <= 1'b0;
    end endgenerate

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st <= S_IDLE; pc <= 0; fpc <= 0; done <= 1'b0; prog_re <= 1'b0; pend1 <= 1'b0; pend2 <= 1'b0;
            fq_rd <= 0; fq_wr <= 0; fq_n <= 0; nx_v <= 1'b0; hq_v <= 1'b0; hc <= 2'd0; h_rd <= 1'b0; h_wr <= 1'b0;
            cycles <= 0; next_token <= 0;
        end else begin
            if (st != S_IDLE) cycles <= cycles + 1;
            pend1 <= prog_re && (st != S_IDLE);
            pend2 <= (PRL > 1) && pend1 && (st != S_IDLE);
            prog_re <= 1'b0;
            case (st)
                S_IDLE: if (start) begin
                    tok_r <= token; pos_r <= pos; pc <= 0; fpc <= 0; done <= 1'b0; cycles <= 0;
                    fq_rd <= 0; fq_wr <= 0; fq_n <= 0; nx_v <= 1'b0; pend1 <= 1'b0; pend2 <= 1'b0; hq_v <= 1'b0;
                    hc <= 2'd0; h_rd <= 1'b0; h_wr <= 1'b0;
                    st <= S_DYN;
                end
                S_DYN: st <= S_RUN;
                S_RUN: begin
                    // fetch: one word a cycle while fewer than NFQ are held or in flight
                    if ({1'b0, fq_n} + ((FQ_HEAD >= 2) ? hc : (FQ_HEAD != 0) ? {1'b0, hq_v} : 2'd0) + prog_re + pend1 + ((PRL > 1) ? pend2 : 1'b0) < NFQ) begin
                        prog_re <= 1'b1; prog_addr <= fpc; fpc <= fpc + 1'b1;
                    end
                    if (push) begin if (FQWE == 0) fq[fq_wr] <= prog_q; fq_wr <= fq_wr + 1'b1; end
                    if (fq_pop) fq_rd <= fq_rd + 1'b1;
                    fq_n <= fq_n + (push ? 3'd1 : 3'd0) - (fq_pop ? 3'd1 : 3'd0);
                    if (FQ_HEAD >= 2) begin
                        // hq / hq1 data writes: g_hfc / g_hf1 below (unchanged condition when HFC <= 1)
                        if (hq_fill) h_wr <= !h_wr;
                        if (load) h_rd <= !h_rd;
                        hc <= hc + (hq_fill ? 2'd1 : 2'd0) - (load ? 2'd1 : 2'd0);
                    end else if (hq_fill) begin hq_v <= 1'b1; end
                    else if (load && FQ_HEAD != 0) hq_v <= 1'b0;
                    if (issue || skip) pc <= pc + 1'b1;
                    if (load) nx_v <= 1'b1;
                    else if (issue || skip) nx_v <= 1'b0;
                    if (fin) begin
                        done <= 1'b1; next_token <= (OWN == 2) ? x_fidx : fin_idx; next_val <= (OWN == 2) ? x_fval : fin_val; st <= S_IDLE; nx_v <= 1'b0;
                        prog_re <= 1'b0;
                    end
                end
                default: st <= S_IDLE;
            endcase
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin kvd_v <= 1'b0; wd_v <= 1'b0; end
        else begin
            kvd_v <= load && ir[O_UNIT +: W_UNIT] == 2'd1 && ir[O_ME_WSRC];
            wd_v <= (W_HBM != 0) && load && ir[O_UNIT +: W_UNIT] == 2'd1 && !ir[O_ME_WSRC];
        end
    end
    assign kvd_wbase = me_wbase; assign kvd_ts = me_ts; assign kvd_ks = me_ks; assign kvd_js = me_js;
    assign kvd_wcs = me_wcs; assign kvd_split = me_split;
    assign kvd_jsh = me_jsh; assign kvd_tiles = me_tiles; assign kvd_k = me_k; assign kvd_nout = me_nout;
    assign kvd_kindk = me_kindk; assign kvd_pos = pos_r;
    assign wd_wbase = me_wbase; assign wd_tiles = me_tiles; assign wd_k = me_k;
    assign wd_sbase = (INT8_WEIGHT != 0 && INT8_SCALE_WCS_BASE != 0) ? me_wcs : me_wbase;
    assign wd_nout = me_nout; // useful BF16 row scales to preload from HBM

    // The chunked weight program divides lm_head into bounded streams. Fold
    // each completed chunk's argmax before issuing the next one. The final
    // chunk remains in u_me and is included exactly once at END.
    function automatic [31:0] okey(input [31:0] v);
        okey = v[31] ? ~v : {1'b1, v[30:0]};
    endfunction
    reg run_any;
    reg [31:0] run_key,run_val;
    reg [NW-1:0] run_idx,last_row0;
    wire am_gt;                  // okey(am_val) > run_key
    wire [NW-1:0] am_sum;        // am_idx + last_row0
    generate if (FKS != 0) begin : g_fks
        // FKS (el1011-q-seq, exact): the argmax merge's compare and index add as kept Kogge-Stone prefix trees (they were
        // a 32-b compare + 18-b MAJ ripple straight into the m_fidx / m_fval output station); a > b = carry out of a + ~b
        wire [31:0] gt_s; wire [NW-1:0] sm_s; wire sm_co;
        ot_hdc_ksadd_k #(.W(32)) u_gt (.a(okey(am_val)), .b(~run_key), .cin(1'b0), .s(gt_s), .cout(am_gt));
        ot_hdc_ksadd_k #(.W(NW)) u_sm (.a(am_idx), .b(last_row0), .cin((FKS == 2) ? 1'b1 : 1'b0), .s(am_sum), .cout(sm_co));
    end else begin : g_fbeh
        assign am_gt = okey(am_val) > run_key;
        assign am_sum = am_idx + last_row0;
    end endgenerate
    wire am_wins = am_any && (!run_any || am_gt);
    wire [2:0] am_wins_c;        // h15 AMWC: kept copies for run_key / run_idx / run_val (else = am_wins)
    generate if (AMWC != 0) begin : g_amwc
        genvar ac;
        for (ac = 0; ac < 3; ac = ac + 1) begin : g_c
`ifdef OT_AMWC_MUT
            ot_qhs_amwin u_w (.am_val(am_val), .run_key(run_key), .am_any(am_any), .run_any((ac == 2) ? 1'b0 : run_any), .win(am_wins_c[ac]));
`else
            ot_qhs_amwin u_w (.am_val(am_val), .run_key(run_key), .am_any(am_any), .run_any(run_any), .win(am_wins_c[ac]));
`endif
        end
    end else begin : g_amw1
        assign am_wins_c = {3{am_wins}};
    end endgenerate
    wire [NW-1:0] fin_idx = am_wins ? am_sum : run_idx;
    wire [31:0] fin_val = am_wins ? am_val : run_val;
    assign o_fidx = fin_idx; assign o_fval = fin_val;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin run_any<=1'b0; last_row0<=0; end
        else if (start && st==S_IDLE) begin run_any<=1'b0; last_row0<=0; end
        else if (me_go && me_amax) begin
            last_row0<=me_row0;
            if (!me_amc) run_any<=1'b0;
            else begin
                if (am_wins) run_any<=1'b1;
                if (am_wins_c[0]) run_key<=okey(am_val);
                if (am_wins_c[1]) run_idx<=am_sum;
                if (am_wins_c[2]) run_val<=am_val;
            end
        end
    end

    // DYN offsets derived once per token.
    always @(posedge clk) if (st == S_DYN) begin
        dyn[0] <= 0;
        dyn[1] <= tok_r * HID;
        dyn[2] <= pos_r * HALF;
        dyn[3] <= (pos_r >> LW) * (HD * W) + (pos_r & (W - 1));
        dyn[4] <= pos_r * HD;
        dyn[5] <= pos_r + 1;
        dyn[6] <= dyn_tiles_zero;                 // rounds of G position tiles (split 0)
        dyn[7] <= 0;
    end

    // DPRE (h9): per-head-word decode adds (log-depth Kogge-Stone, ot_hdc_ksadd_k: yosys maps `+` as a ripple),
    // selected after the add (removes the h_rd -> ir mux from the add cone).
    `define FW(w,name) w[O_``name +: W_``name]
`ifdef OT_DPRE_MUT
    localparam integer DPRE_X = 1;   // negative control: the per-word adds pick the wrong head word
`else
    localparam integer DPRE_X = 0;
`endif
    wire [$bits(me_nout)-1:0] pa0_me_nout = `FW(hq,ME_NOUT), pb0_me_nout = (DSEL != 0) ? dq0[AW*0 +: $bits(me_nout)] : dyn[`FW(hq,ME_D_NOUT)], pre0_me_nout;
    wire [$bits(me_nout)-1:0] pa1_me_nout = `FW(hq1,ME_NOUT), pb1_me_nout = (DSEL != 0) ? dq1[AW*0 +: $bits(me_nout)] : dyn[`FW(hq1,ME_D_NOUT)], pre1_me_nout;
    wire [$bits(me_nout)-1:0] dec_me_nout = (DPRE != 0 && FQ_HEAD >= 2) ? (((((HRC > 1) ? h_rd_c[1%HRN] : h_rd)) ^ (DPRE_X != 0)) ? pre1_me_nout : pre0_me_nout)
                                                 : `F(ME_NOUT) + dyn[`F(ME_D_NOUT)];
    wire [$bits(me_k)-1:0] pa0_me_k = `FW(hq,ME_K), pb0_me_k = (DSEL != 0) ? dq0[AW*1 +: $bits(me_k)] : dyn[`FW(hq,ME_D_K)], pre0_me_k;
    wire [$bits(me_k)-1:0] pa1_me_k = `FW(hq1,ME_K), pb1_me_k = (DSEL != 0) ? dq1[AW*1 +: $bits(me_k)] : dyn[`FW(hq1,ME_D_K)], pre1_me_k;
    wire [$bits(me_k)-1:0] dec_me_k = (DPRE != 0 && FQ_HEAD >= 2) ? (((((HRC > 1) ? h_rd_c[4%HRN] : h_rd)) ^ (DPRE_X != 0)) ? pre1_me_k : pre0_me_k)
                                                 : `F(ME_K) + dyn[`F(ME_D_K)];
    wire [$bits(me_wbase)-1:0] pa0_me_wbase = `FW(hq,ME_WBASE), pb0_me_wbase = (DSEL != 0) ? dq0[AW*2 +: $bits(me_wbase)] : dyn[`FW(hq,ME_D_WBASE)], pre0_me_wbase;
    wire [$bits(me_wbase)-1:0] pa1_me_wbase = `FW(hq1,ME_WBASE), pb1_me_wbase = (DSEL != 0) ? dq1[AW*2 +: $bits(me_wbase)] : dyn[`FW(hq1,ME_D_WBASE)], pre1_me_wbase;
    wire [$bits(me_wbase)-1:0] dec_me_wbase = (DPRE != 0 && FQ_HEAD >= 2) ? (((((HRC > 1) ? h_rd_c[7%HRN] : h_rd)) ^ (DPRE_X != 0)) ? pre1_me_wbase : pre0_me_wbase)
                                                 : `F(ME_WBASE) + dyn[`F(ME_D_WBASE)];
    wire [$bits(me_xbase)-1:0] pa0_me_xbase = `FW(hq,ME_XBASE), pb0_me_xbase = (DSEL != 0) ? dq0[AW*3 +: $bits(me_xbase)] : dyn[`FW(hq,ME_D_XBASE)], pre0_me_xbase;
    wire [$bits(me_xbase)-1:0] pa1_me_xbase = `FW(hq1,ME_XBASE), pb1_me_xbase = (DSEL != 0) ? dq1[AW*3 +: $bits(me_xbase)] : dyn[`FW(hq1,ME_D_XBASE)], pre1_me_xbase;
    wire [$bits(me_xbase)-1:0] dec_me_xbase = (DPRE != 0 && FQ_HEAD >= 2) ? (((((HRC > 1) ? h_rd_c[10%HRN] : h_rd)) ^ (DPRE_X != 0)) ? pre1_me_xbase : pre0_me_xbase)
                                                 : `F(ME_XBASE) + dyn[`F(ME_D_XBASE)];
    wire [$bits(me_obase)-1:0] pa0_me_obase = `FW(hq,ME_OBASE), pb0_me_obase = (DSEL != 0) ? dq0[AW*4 +: $bits(me_obase)] : dyn[`FW(hq,ME_D_OBASE)], pre0_me_obase;
    wire [$bits(me_obase)-1:0] pa1_me_obase = `FW(hq1,ME_OBASE), pb1_me_obase = (DSEL != 0) ? dq1[AW*4 +: $bits(me_obase)] : dyn[`FW(hq1,ME_D_OBASE)], pre1_me_obase;
    wire [$bits(me_obase)-1:0] dec_me_obase = (DPRE != 0 && FQ_HEAD >= 2) ? (((((HRC > 1) ? h_rd_c[13%HRN] : h_rd)) ^ (DPRE_X != 0)) ? pre1_me_obase : pre0_me_obase)
                                                 : `F(ME_OBASE) + dyn[`F(ME_D_OBASE)];
    wire [$bits(su_nin)-1:0] pa0_su_nin = `FW(hq,SU_NIN), pb0_su_nin = (DSEL != 0) ? dq0[AW*5 +: $bits(su_nin)] : dyn[`FW(hq,SU_D_NIN)], pre0_su_nin;
    wire [$bits(su_nin)-1:0] pa1_su_nin = `FW(hq1,SU_NIN), pb1_su_nin = (DSEL != 0) ? dq1[AW*5 +: $bits(su_nin)] : dyn[`FW(hq1,SU_D_NIN)], pre1_su_nin;
    wire [$bits(su_nin)-1:0] dec_su_nin = (DPRE != 0 && FQ_HEAD >= 2) ? (((((HRC > 1) ? h_rd_c[16%HRN] : h_rd)) ^ (DPRE_X != 0)) ? pre1_su_nin : pre0_su_nin)
                                                 : `F(SU_NIN) + dyn[`F(SU_D_NIN)];
    wire [$bits(a_base)-1:0] pa0_a_base = `FW(hq,A_BASE), pb0_a_base = (DSEL != 0) ? dq0[AW*6 +: $bits(a_base)] : dyn[`FW(hq,A_D)], pre0_a_base;
    wire [$bits(a_base)-1:0] pa1_a_base = `FW(hq1,A_BASE), pb1_a_base = (DSEL != 0) ? dq1[AW*6 +: $bits(a_base)] : dyn[`FW(hq1,A_D)], pre1_a_base;
    wire [$bits(a_base)-1:0] dec_a_base = (DPRE != 0 && FQ_HEAD >= 2) ? (((((HRC > 1) ? h_rd_c[19%HRN] : h_rd)) ^ (DPRE_X != 0)) ? pre1_a_base : pre0_a_base)
                                                 : `F(A_BASE) + dyn[`F(A_D)];
    wire [$bits(b_base)-1:0] pa0_b_base = `FW(hq,B_BASE), pb0_b_base = (DSEL != 0) ? dq0[AW*7 +: $bits(b_base)] : dyn[`FW(hq,B_D)], pre0_b_base;
    wire [$bits(b_base)-1:0] pa1_b_base = `FW(hq1,B_BASE), pb1_b_base = (DSEL != 0) ? dq1[AW*7 +: $bits(b_base)] : dyn[`FW(hq1,B_D)], pre1_b_base;
    wire [$bits(b_base)-1:0] dec_b_base = (DPRE != 0 && FQ_HEAD >= 2) ? (((((HRC > 1) ? h_rd_c[22%HRN] : h_rd)) ^ (DPRE_X != 0)) ? pre1_b_base : pre0_b_base)
                                                 : `F(B_BASE) + dyn[`F(B_D)];
    wire [$bits(c_base)-1:0] pa0_c_base = `FW(hq,C_BASE), pb0_c_base = (DSEL != 0) ? dq0[AW*8 +: $bits(c_base)] : dyn[`FW(hq,C_D)], pre0_c_base;
    wire [$bits(c_base)-1:0] pa1_c_base = `FW(hq1,C_BASE), pb1_c_base = (DSEL != 0) ? dq1[AW*8 +: $bits(c_base)] : dyn[`FW(hq1,C_D)], pre1_c_base;
    wire [$bits(c_base)-1:0] dec_c_base = (DPRE != 0 && FQ_HEAD >= 2) ? (((((HRC > 1) ? h_rd_c[25%HRN] : h_rd)) ^ (DPRE_X != 0)) ? pre1_c_base : pre0_c_base)
                                                 : `F(C_BASE) + dyn[`F(C_D)];
    wire [$bits(d_base)-1:0] pa0_d_base = `FW(hq,D_BASE), pb0_d_base = (DSEL != 0) ? dq0[AW*9 +: $bits(d_base)] : dyn[`FW(hq,D_D)], pre0_d_base;
    wire [$bits(d_base)-1:0] pa1_d_base = `FW(hq1,D_BASE), pb1_d_base = (DSEL != 0) ? dq1[AW*9 +: $bits(d_base)] : dyn[`FW(hq1,D_D)], pre1_d_base;
    wire [$bits(d_base)-1:0] dec_d_base = (DPRE != 0 && FQ_HEAD >= 2) ? (((((HRC > 1) ? h_rd_c[28%HRN] : h_rd)) ^ (DPRE_X != 0)) ? pre1_d_base : pre0_d_base)
                                                 : `F(D_BASE) + dyn[`F(D_D)];

    // h15 DTIL: me_tiles per head word (operand tq0 / tq1 registered at fill), KS add, then the h_rd copy selects
    wire [NW-1:0] pa0_me_tiles = `FW(hq,ME_TILES), pa1_me_tiles = `FW(hq1,ME_TILES), pre0_me_tiles, pre1_me_tiles;
    wire [NW-1:0] dec_me_tiles = (((HRC > 1) ? h_rd_c[30%HRN] : h_rd) ^ (DPRE_X != 0)) ? pre1_me_tiles : pre0_me_tiles;
    generate if (DTIL != 0) begin : g_dtilk
        ot_hdc_ksadd_k #(.W(NW)) u_pre0_me_tiles (.a(pa0_me_tiles), .b(tq0), .cin(1'b0), .s(pre0_me_tiles), .cout());
        ot_hdc_ksadd_k #(.W(NW)) u_pre1_me_tiles (.a(pa1_me_tiles), .b(tq1), .cin(1'b0), .s(pre1_me_tiles), .cout());
`ifndef SYNTHESIS
`ifndef OT_DTIL_MUT
        wire [NW-1:0] me_tiles_ref = `F(ME_TILES) + ((`F(ME_D_TILES) == 3'd6) ? dyn_tiles_split : dyn[`F(ME_D_TILES)]);
        always @(posedge clk) if (rst_n && load && st == S_RUN && dec_me_tiles !== me_tiles_ref)
            $fatal(1, "DTIL me_tiles %0h != %0h", dec_me_tiles, me_tiles_ref);
`endif
`endif
    end else begin : g_dtil0
        assign pre0_me_tiles = '0; assign pre1_me_tiles = '0;
    end endgenerate
    generate if (DPRE != 0) begin : g_dpre
        ot_hdc_ksadd_k #(.W($bits(me_nout))) u_pre0_me_nout (.a(pa0_me_nout), .b(pb0_me_nout), .cin(1'b0), .s(pre0_me_nout), .cout());
        ot_hdc_ksadd_k #(.W($bits(me_nout))) u_pre1_me_nout (.a(pa1_me_nout), .b(pb1_me_nout), .cin(1'b0), .s(pre1_me_nout), .cout());
        ot_hdc_ksadd_k #(.W($bits(me_k))) u_pre0_me_k (.a(pa0_me_k), .b(pb0_me_k), .cin(1'b0), .s(pre0_me_k), .cout());
        ot_hdc_ksadd_k #(.W($bits(me_k))) u_pre1_me_k (.a(pa1_me_k), .b(pb1_me_k), .cin(1'b0), .s(pre1_me_k), .cout());
        ot_hdc_ksadd_k #(.W($bits(me_wbase))) u_pre0_me_wbase (.a(pa0_me_wbase), .b(pb0_me_wbase), .cin(1'b0), .s(pre0_me_wbase), .cout());
        ot_hdc_ksadd_k #(.W($bits(me_wbase))) u_pre1_me_wbase (.a(pa1_me_wbase), .b(pb1_me_wbase), .cin(1'b0), .s(pre1_me_wbase), .cout());
        ot_hdc_ksadd_k #(.W($bits(me_xbase))) u_pre0_me_xbase (.a(pa0_me_xbase), .b(pb0_me_xbase), .cin(1'b0), .s(pre0_me_xbase), .cout());
        ot_hdc_ksadd_k #(.W($bits(me_xbase))) u_pre1_me_xbase (.a(pa1_me_xbase), .b(pb1_me_xbase), .cin(1'b0), .s(pre1_me_xbase), .cout());
        ot_hdc_ksadd_k #(.W($bits(me_obase))) u_pre0_me_obase (.a(pa0_me_obase), .b(pb0_me_obase), .cin(1'b0), .s(pre0_me_obase), .cout());
        ot_hdc_ksadd_k #(.W($bits(me_obase))) u_pre1_me_obase (.a(pa1_me_obase), .b(pb1_me_obase), .cin(1'b0), .s(pre1_me_obase), .cout());
        ot_hdc_ksadd_k #(.W($bits(su_nin))) u_pre0_su_nin (.a(pa0_su_nin), .b(pb0_su_nin), .cin(1'b0), .s(pre0_su_nin), .cout());
        ot_hdc_ksadd_k #(.W($bits(su_nin))) u_pre1_su_nin (.a(pa1_su_nin), .b(pb1_su_nin), .cin(1'b0), .s(pre1_su_nin), .cout());
        ot_hdc_ksadd_k #(.W($bits(a_base))) u_pre0_a_base (.a(pa0_a_base), .b(pb0_a_base), .cin(1'b0), .s(pre0_a_base), .cout());
        ot_hdc_ksadd_k #(.W($bits(a_base))) u_pre1_a_base (.a(pa1_a_base), .b(pb1_a_base), .cin(1'b0), .s(pre1_a_base), .cout());
        ot_hdc_ksadd_k #(.W($bits(b_base))) u_pre0_b_base (.a(pa0_b_base), .b(pb0_b_base), .cin(1'b0), .s(pre0_b_base), .cout());
        ot_hdc_ksadd_k #(.W($bits(b_base))) u_pre1_b_base (.a(pa1_b_base), .b(pb1_b_base), .cin(1'b0), .s(pre1_b_base), .cout());
        ot_hdc_ksadd_k #(.W($bits(c_base))) u_pre0_c_base (.a(pa0_c_base), .b(pb0_c_base), .cin(1'b0), .s(pre0_c_base), .cout());
        ot_hdc_ksadd_k #(.W($bits(c_base))) u_pre1_c_base (.a(pa1_c_base), .b(pb1_c_base), .cin(1'b0), .s(pre1_c_base), .cout());
        ot_hdc_ksadd_k #(.W($bits(d_base))) u_pre0_d_base (.a(pa0_d_base), .b(pb0_d_base), .cin(1'b0), .s(pre0_d_base), .cout());
        ot_hdc_ksadd_k #(.W($bits(d_base))) u_pre1_d_base (.a(pa1_d_base), .b(pb1_d_base), .cin(1'b0), .s(pre1_d_base), .cout());
    end else begin : g_dpre0
        assign pre0_me_nout = '0;
        assign pre1_me_nout = '0;
        assign pre0_me_k = '0;
        assign pre1_me_k = '0;
        assign pre0_me_wbase = '0;
        assign pre1_me_wbase = '0;
        assign pre0_me_xbase = '0;
        assign pre1_me_xbase = '0;
        assign pre0_me_obase = '0;
        assign pre1_me_obase = '0;
        assign pre0_su_nin = '0;
        assign pre1_su_nin = '0;
        assign pre0_a_base = '0;
        assign pre1_a_base = '0;
        assign pre0_b_base = '0;
        assign pre1_b_base = '0;
        assign pre0_c_base = '0;
        assign pre1_c_base = '0;
        assign pre0_d_base = '0;
        assign pre1_d_base = '0;
    end endgenerate
    // Decode: every base and count may add one DYN value.
    always @(posedge clk) if (load) begin
        d_unit <= `F(UNIT); d_barrier <= `F(BARRIER);
        me_nout <= dec_me_nout;
        //: DYN_TTILES counts exact rounds of G/S position tiles (S = 2^split)
        me_tiles <= (DTIL != 0) ? dec_me_tiles : `F(ME_TILES) + ((`F(ME_D_TILES) == 3'd6) ? dyn_tiles_split
                                                               : dyn[`F(ME_D_TILES)]);
        me_k <= dec_me_k;
        me_kindk <= (`F(ME_D_TILES) == 3'd6);        // DYN_TTILES: rounds of position tiles
        me_wsrc <= `F(ME_WSRC); me_round <= `F(ME_ROUND); me_oen <= `F(ME_OEN); me_amax <= `F(ME_AMAX);
        me_amc <= `F(ME_AMC);
        me_row0 <= `F(ME_ROW0) |
                   ((QWEN_FULLSHAPE != 0) ?
                    ({{(NW-2){1'b0}}, ir[O_ME_ROW0+W_ME_ROW0+W_ME_AMC +: 2]} << 16) : '0);
        me_wbase <= dec_me_wbase;
        me_ts <= `F(ME_TS); me_ks <= `F(ME_KS); me_js <= `F(ME_JS);
        me_xbase <= dec_me_xbase;
        me_obase <= dec_me_obase;
        me_xks <= `F(ME_XKS); me_xjs <= `F(ME_XJS); me_jsh <= `F(ME_JSH);
        me_ots <= `F(ME_OTS); me_ojs <= `F(ME_OJS); me_mmode <= `F(ME_MMODE);
        d_chase <= `F(CHASE); d_chase_n <= `F(CHASE_N); d_wait_me <= `F(WAIT_ME); d_wait_su <= `F(WAIT_SU);
        d_chase_rows <= `F(CHASE_ROWS);
        me_split <= `F(ME_SPLIT); me_xcs <= `F(ME_XCS); me_wcs <= `F(ME_WCS);
        me_rmax <= `F(ME_RMAX); me_mbase <= `F(ME_MBASE);
        su_nout <= `F(SU_NOUT);
        su_nin <= dec_su_nin;
        a_src <= `F(A_SRC); a_base <= dec_a_base; a_so <= `F(A_SO); a_si <= `F(A_SI);
        b_src <= `F(B_SRC); b_base <= dec_b_base; b_so <= `F(B_SO); b_si <= `F(B_SI);
        c_src <= `F(C_SRC); c_base <= dec_c_base; c_so <= `F(C_SO); c_si <= `F(C_SI);
        ma <= `F(MA); mb <= `F(MB); ad <= `F(AD); sfu <= `F(SFU); mc <= `F(MC); md <= `F(MD);
        dst <= `F(DST); d_base <= dec_d_base; d_so <= `F(D_SO); d_si <= `F(D_SI);
        red <= `F(RED); redsq <= `F(RED_SQ); r_base <= `F(R_BASE); r_so <= `F(R_SO);
        imm1 <= `F(IMM1); imm2 <= `F(IMM2);
    end
    `undef F
    `undef FW

    // -- units ----------------------------------------------------------------------
    wire me_wrom_re, su_wrom_re;
    wire [AW-1:0] me_wrom_addr, su_wrom_addr;
    wire [SW-1:0] su_va_re;
    wire [SW*AW-1:0] su_va_addr;
    wire [SW*32-1:0] su_va_q;
    reg embed_active, embed_scale_pending;
    reg [15:0] embed_scale_hold;
    reg [SW-1:0] embed_sel;
    reg [SW*$clog2(EMB_CODE_LANES)-1:0] embed_lanes;
    wire [SW-1:0] embed_faults;
    assign embed_scale_re = (INT8_EMBED != 0) && start && st == S_IDLE;
    assign embed_scale_addr = token;
    assign embed_code_re = (INT8_EMBED != 0) && (|(su_va_re & {SW{embed_active}}));
    // The stream's element address is AW bits; token*HID wraps for vocab
    // rows >= 2^(AW-log2(HID)). Recover the in-row offset from those low
    // bits, then form the code-word address from the full NW-bit token.
    assign embed_code_addr = (QWEN_FULLSHAPE != 0) ?
        ((tok_r * (HID / EMB_CODE_LANES)) +
         (((su_va_addr[0 +: AW] - EMB_ADDR_BASE) & (HID - 1)) /
          EMB_CODE_LANES)) :
        ((su_va_addr[0 +: AW] - EMB_ADDR_BASE) >> $clog2(EMB_CODE_LANES));
    assign va_re = su_va_re & ~({SW{(INT8_EMBED != 0) && embed_active}});
    assign va_addr = su_va_addr;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            embed_active <= 1'b0;
            embed_scale_pending <= 1'b0;
            embed_sel <= 0;
        end else begin
            if (su_go) embed_active <= (INT8_EMBED != 0) && a_src;
            embed_scale_pending <= embed_scale_re;
            embed_sel <= su_va_re & {SW{(INT8_EMBED != 0) && embed_active}};
        end
    end
    always @(posedge clk) begin
        if (embed_scale_pending) embed_scale_hold <= embed_scale_q;
    end
    genvar el;
    generate if (INT8_EMBED != 0) begin : g_int8_embed
    for (el = 0; el < SW; el = el + 1) begin : g_embed_decode
        localparam integer ELI = $clog2(EMB_CODE_LANES);
        always @(posedge clk) embed_lanes[el*ELI +: ELI] <= su_va_addr[el*AW +: ELI];
        wire [31:0] decoded;
        wire bad;
        ot_hdc_qwen_int8_embed_decode u_decode (
            .code(embed_code_q[8*embed_lanes[el*ELI +: ELI] +: 8]),
            .scale(embed_scale_hold), .value(decoded), .fault(bad));
        assign su_va_q[el*32 +: 32] = embed_sel[el] ? decoded : va_q[el*32 +: 32];
        assign embed_faults[el] = embed_sel[el] && bad;
    end
    end else begin : g_plain_embed
        assign su_va_q = va_q;
        assign embed_faults = 0;
    end endgenerate
    // -- engine clock enable (ME_STALL) ------------------------------------------
    //: rst_n forces the enable so the gated registers see reset edges (see
    //: ot_hdc_cg).  The enable is combinational from the supply's view of the
    //: engine's registered requests; it never depends on me_go.
    wire me_wake = (st == S_RUN) && nx_v && (d_unit == 2'd1);
    wire me_clk_en_w;
    // Normal production clocks every assigned edge; no supply/status clock gate.
    assign me_en=1'b1;
    assign me_clk_en_w=1'b1;
    assign me_clk_en = me_clk_en_w;   // MEREG 3: the kept pin copy en_o
    wire me_clk;
    generate if (1'b0) begin : g_me_cg
        ot_hdc_cg u_me_cg (.clk(clk), .en(me_en), .gclk(me_clk));
    end else begin : g_me_clk
        assign me_clk = clk;
    end endgenerate
    wire [(G >> SMIN)-1:0] me_o_we;
    wire         me_mx_we;
    //: a held engine keeps its write strobes high; write once per engine edge
    assign vw_me_we = me_o_we & {(G >> SMIN){me_en}};
    assign vw_mx_we = me_mx_we & me_en;
    // ---- matrix engine spine (die master qfd_sp_tree_top): ports ----
    assign po_me_clk = me_clk;
    assign po_me_go = me_go;
    assign me_ready = pi_me_ready;
    assign me_idle = pi_me_idle;
    assign po_me_i_nout = me_nout;
    assign po_me_i_tiles = me_tiles;
    assign po_me_i_k = me_k;
    assign po_me_i_wsrc = me_wsrc;
    assign po_me_i_wbase = me_wbase;
    assign po_me_i_ts = me_ts;
    assign po_me_i_ks = me_ks;
    assign po_me_i_js = me_js;
    assign po_me_i_xbase = me_xbase;
    assign po_me_i_xks = me_xks;
    assign po_me_i_xjs = me_xjs;
    assign po_me_i_xcs = me_xcs;
    assign po_me_i_jsh = me_jsh;
    assign po_me_i_split = me_split;
    assign po_me_i_wcs = me_wcs;
    assign po_me_i_round = me_round;
    assign po_me_i_obase = me_obase;
    assign po_me_i_ots = me_ots;
    assign po_me_i_ojs = me_ojs;
    assign po_me_i_mmode = me_mmode;
    assign po_me_i_oen = me_oen;
    assign po_me_i_amax = me_amax;
    assign po_me_i_rmax = me_rmax;
    assign po_me_i_mbase = me_mbase;
    assign me_mx_we = pi_me_mx_we;
    assign vw_mx_addr = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign vw_mx_mask = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign vw_mx_data = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign me_wrom_re = pi_me_wrom_re;
    assign me_wrom_addr = pi_me_wrom_addr;
    assign scale_re = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign scale_gre = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign scale_addr = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign kv_re = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign vx_re = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign vx_addr = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign tgo = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign tb = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign xl_d = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign me_ov = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign me_o_we = pi_me_o_we;
    assign vw_me_addr = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign vw_me_mask = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign vw_me_data = '0;   // driven by the spine in ot_qwen_rom_core_part
    assign am_idx = pi_me_am_idx;
    assign am_val = pi_me_am_val;
    assign am_any = pi_me_am_any;
    assign me_progress = pi_me_progress;
    assign me_fault = pi_me_fault;

    wire       su_active;             // observation (test benches)
    wire [7:0] su_inflight;
    // ---- vector stream unit (die master qfd_sp_su64_sfu): ports (SU_VEC = 1 only) ----
    assign po_su_asrc_raw = a_src;   // split-exact: the embedding selector travels with the go
    assign su_active = pi_su_rt_active;
    assign su_inflight = pi_su_rt_inflight;
    assign po_su_go = su_go;
    assign su_ready = pi_su_ready;
    assign su_idle = pi_su_idle;
    assign po_su_i_nout = su_nout;
    assign po_su_i_nin = su_nin;
    assign po_su_i_asrc = (INT8_EMBED != 0) ? 1'b0 : a_src;
    assign po_su_i_abase = a_base;
    assign po_su_i_aso = a_so;
    assign po_su_i_asi = a_si;
    assign po_su_i_bsrc = b_src;
    assign po_su_i_bbase = b_base;
    assign po_su_i_bso = b_so;
    assign po_su_i_bsi = b_si;
    assign po_su_i_csrc = c_src;
    assign po_su_i_cbase = c_base;
    assign po_su_i_cso = c_so;
    assign po_su_i_csi = c_si;
    assign po_su_i_ma = ma;
    assign po_su_i_mb = mb;
    assign po_su_i_ad = ad;
    assign po_su_i_sfu = sfu;
    assign po_su_i_mc = mc;
    assign po_su_i_md = md;
    assign po_su_i_dst = dst;
    assign po_su_i_dbase = d_base;
    assign po_su_i_dso = d_so;
    assign po_su_i_dsi = d_si;
    assign po_su_i_red = red;
    assign po_su_i_redsq = redsq;
    assign po_su_i_rbase = r_base;
    assign po_su_i_rso = r_so;
    assign po_su_i_imm1 = imm1;
    assign po_su_i_imm2 = imm2;
    assign su_va_re = pi_su_va_re;
    assign su_va_addr = pi_su_va_addr;
    assign po_su_va_q = su_va_q;
    assign vb_re = '0;   // driven by the stream unit in ot_qwen_rom_core_part
    assign vb_addr = '0;   // driven by the stream unit in ot_qwen_rom_core_part
    assign vc_re = '0;   // driven by the stream unit in ot_qwen_rom_core_part
    assign vc_addr = '0;   // driven by the stream unit in ot_qwen_rom_core_part
    assign su_wrom_re = pi_su_wrom_re;
    assign su_wrom_addr = pi_su_wrom_addr;
    assign crom_re = '0;   // driven by the stream unit in ot_qwen_rom_core_part
    assign crom_addr = '0;   // driven by the stream unit in ot_qwen_rom_core_part
    assign vw_su_we = '0;   // driven by the stream unit in ot_qwen_rom_core_part
    assign vw_su_addr = '0;   // driven by the stream unit in ot_qwen_rom_core_part
    assign vw_su_data = '0;   // driven by the stream unit in ot_qwen_rom_core_part
    assign kv_we = pi_su_kv_we;   // also read by the controller (kv_write_flush)
    assign kv_waddr = '0;   // driven by the stream unit in ot_qwen_rom_core_part
    assign kv_wdata = '0;   // driven by the stream unit in ot_qwen_rom_core_part
    assign vw_rd_we = '0;   // driven by the stream unit in ot_qwen_rom_core_part
    assign vw_rd_addr = '0;   // driven by the stream unit in ot_qwen_rom_core_part
    assign vw_rd_data = '0;   // driven by the stream unit in ot_qwen_rom_core_part
    assign su_progress = pi_su_progress;
    assign su_rows = pi_su_progress_rows;
    assign su_fault = pi_su_fault;

    // The embedding read is the only stream use of the weight ROM; a barrier
    // keeps it apart from matrix-vector reads.
    assign wrom_re = ((INT8_WEIGHT != 0) ? 1'b0 : me_wrom_re) |
                     ((INT8_EMBED != 0) ? 1'b0 : su_wrom_re);
    assign int8_wrom_re = (INT8_WEIGHT != 0) ? me_wrom_re : 1'b0;
    assign int8_wrom_addr = me_wrom_addr;
    assign wrom_su = su_wrom_re;
    assign wrom_addr = su_wrom_re ? su_wrom_addr : me_wrom_addr;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) fault <= 1'b0;
        else if (start && st == S_IDLE) fault <= 1'b0;
        else if (fixed_fault || me_fault || su_fault || (|embed_faults) || dyn_tiles_bad_instruction) fault <= 1'b1;
    end
endmodule

// h15 AMWC (Q-TTH15 10-17): one kept copy of the argmax-merge win decision am_any && (!run_any || okey(am_val) > run_key)
// (keep_hierarchy stops opt_merge / ABC folding the copies into one; fixed width: Yosys asserts on parameterised
// keep_hierarchy modules).  a > b = carry out of a + ~b (Kogge-Stone).
(* keep_hierarchy *)
module ot_qhs_amwin (input wire [31:0] am_val, input wire [31:0] run_key, input wire am_any, input wire run_any, output wire win);
    wire [31:0] k = am_val[31] ? ~am_val : {1'b1, am_val[30:0]};
    wire [31:0] s; wire gt;
    ot_hdc_ksadd_k #(.W(32)) u_gt (.a(k), .b(~run_key), .cin(1'b0), .s(s), .cout(gt));
    assign win = am_any && (!run_any || gt);
endmodule
