#!/bin/bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
source ./kv_flags.env
export OT_KV_PARAM_DIAG=1 OT_BIND_DIAGNOSTIC=1
python3 strict_index.py
