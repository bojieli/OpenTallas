// Generated behavioral source by tools/qwen_static_kv/gen_dcal_bc4.py; originals untouched.
`timescale 1ns/1ps
// KV-DCAL-BOOTCFG 2026-10-19 (Qwen KV MU release die): the KV link end's calendar sequencer with the BOOT cfg merged in.
//
// Why: on the KV die the link end (qkd_d2ds) calendar cfg port has one producer, boot image target 11
// (qkd_static_kv_boot_dispatch LINKCFG=1, 66 words: TX/RX entries 0..31, then the TX and RX segment-1 bases = the
// ADMISSION segment).  But ot_qwen_d2d_cal_seq also writes the segment-1 base register at RUNTIME: at every epoch
// (e = 1, 2) back to SEG2, and after the admission run (E_SW, E_SW + 1) to SEG1 (the token run).  With the sequencer's
// cfg outputs load-less, every token run on the KV end replayed the admission segment.
//
// This tile = the qkd_d2d_cal_seq_pin input capture (reload / epoch_go / halt captured once, 2-edge reset release) around
// qkd_d2d_cal_seq (MU image, ot_qwen_d2d_cal_seq_dies_mu.sv; ot_qwen_d2d_cal_seq.sv unchanged) PLUS the boot cfg inputs
// bcfg_* (the dispatcher's link_cfg_*, pin-registered), and ONE output register stage on every output:
//   cfg_*   = the boot write when one arrives, else the sequencer's own writes AFTER its init stream (the inner init's
//             66 image writes are suppressed: boot target 11 loads the tables, so no compile-time table reaches the link)
//   others  = the sequencer's outputs, one edge later
// The inner sequencer counts its epoch anchor from EP_SKEW - 2 (pin version: EP_SKEW - 1), so with the output stage every
// epoch-anchored output (cal_start / cal_seg / layer / tok_start / adm_done / the runtime base writes) leaves on exactly
// the edge qkd_d2d_cal_seq_pin drives it (bench: cycle-equal to the pin tile).  The runtime base write keeps its 2-edge
// lead on the token start (the calendar's cfg settle rule).  One edge later than the pin tile: reset- and halt-relative
// outputs (init, cal_ready, halt stop; boot constants / exceptional paths) and the events counted from the strobe edge
// itself rather than the anchor (adm_done fall, the e = 1, 2 SEG2 restore writes; >= 60 edges before the admission).
//
// Sticky faults (folded into `fault`, registered; never stretch the schedule):
//   COL   a boot write and a sequencer write on the same edge
//   RUN   a boot write while a calendar runs (token programme running, or the admission run until adm_done)
//   STALE a boot base word (addr 6'b100000, TX then RX) != this tile's SEG2 constants (stale boot image vs the image
//         the sequencer's runtime base writes come from)
//   EARLY a calendar start before both boot base words arrived (since reset / the last reload)
//   (+ the sequencer's own faults)
// Static schedule: no ready / credit / backpressure.  MUT (bench only, 0 = shipped): 1 = sequencer writes never reach
// cfg_* (today's die: the base switch is lost).
module qkd_d2d_cal_seq_pin_bc4 #(parameter integer GO_OFS = 0, parameter [20*36-1:0] START_ADJ = '0,
                                parameter integer EP_SKEW = 3, parameter integer MUT = 0) (
    input  wire        ck, rst_n, reload, epoch_go, halt,
    input  wire        bcfg_tx_we, bcfg_rx_we,
    input  wire [5:0]  bcfg_addr,
    input  wire [31:0] bcfg_data,
    output reg         cfg_tx_we, cfg_rx_we,
    output reg  [5:0]  cfg_addr,
    output reg  [31:0] cfg_data,
    output reg         cal_start, cal_seg, cal_ready, running,
    output reg  [5:0]  layer,
    output reg         adm_done, tok_start,
    output reg         fault);
    `include "d2d_cal_image_mu.svh"
    initial if (EP_SKEW != 3 || GO_OFS != 0 || START_ADJ != '0 || MUT < 0 || MUT > 1)
        $fatal(1, "BC4 unsupported ordinary top profile");
    initial if (EP_SKEW < 2) $error("EP_SKEW >= 2 needed (input capture + output stage)");
    // ---- input capture (as qkd_d2d_cal_seq_pin) + the boot cfg pin registers

    reg reload_q, epoch_go_q, halt_q;
    reg b_tx_q, b_rx_q;
    reg [5:0] b_addr_q;
    reg [31:0] b_data_q;
    // Own the exact frozen generated landing: SYNCHRONOUS assertion and release.
    (* keep = 1, dont_touch = 1 *) reg land0;
    (* keep = 1, dont_touch = 1 *) reg [3:0] land1;
    always @(posedge ck) begin land0 <= rst_n; land1 <= {4{land0}}; end
    (* keep = 1, dont_touch = 1 *) reg rel0;
    (* keep = 1, dont_touch = 1 *) reg [18:0] rel1;
    always @(posedge ck or negedge land1[3])
        if (!land1[3]) rel0 <= 0; else rel0 <= 1;
    genvar r;
    generate for (r=0;r<19;r=r+1) begin: release_copies
        always @(posedge ck or negedge land1[3])
            if (!land1[3]) rel1[r] <= 0; else rel1[r] <= rel0;
    end endgenerate
    (* keep = 1, dont_touch = 1 *) reg b_tx_copy0;
    (* keep = 1, dont_touch = 1 *) reg b_rx_copy0;
    (* keep = 1, dont_touch = 1 *) reg b_tx_copy1;
    (* keep = 1, dont_touch = 1 *) reg b_rx_copy1;
    (* keep = 1, dont_touch = 1 *) reg b_tx_copy2;
    (* keep = 1, dont_touch = 1 *) reg b_rx_copy2;
    (* keep = 1, dont_touch = 1 *) reg b_tx_copy3;
    (* keep = 1, dont_touch = 1 *) reg b_rx_copy3;
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) reload_q <= 0; else reload_q <= reload;
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) epoch_go_q <= 0; else epoch_go_q <= epoch_go;
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) halt_q <= 1; else halt_q <= halt;
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) b_tx_q <= 0; else b_tx_q <= bcfg_tx_we;
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) b_rx_q <= 0; else b_rx_q <= bcfg_rx_we;
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) b_addr_q[0] <= 0; else b_addr_q[0] <= bcfg_addr[0];
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) b_addr_q[1] <= 0; else b_addr_q[1] <= bcfg_addr[1];
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) b_addr_q[2] <= 0; else b_addr_q[2] <= bcfg_addr[2];
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) b_addr_q[3] <= 0; else b_addr_q[3] <= bcfg_addr[3];
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) b_addr_q[4] <= 0; else b_addr_q[4] <= bcfg_addr[4];
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) b_addr_q[5] <= 0; else b_addr_q[5] <= bcfg_addr[5];
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) b_data_q[0] <= 0; else b_data_q[0] <= bcfg_data[0];
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) b_data_q[1] <= 0; else b_data_q[1] <= bcfg_data[1];
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) b_data_q[2] <= 0; else b_data_q[2] <= bcfg_data[2];
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) b_data_q[3] <= 0; else b_data_q[3] <= bcfg_data[3];
    always @(posedge ck or negedge land1[0])
        if (!land1[0]) b_data_q[4] <= 0; else b_data_q[4] <= bcfg_data[4];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[5] <= 0; else b_data_q[5] <= bcfg_data[5];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[6] <= 0; else b_data_q[6] <= bcfg_data[6];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[7] <= 0; else b_data_q[7] <= bcfg_data[7];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[8] <= 0; else b_data_q[8] <= bcfg_data[8];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[9] <= 0; else b_data_q[9] <= bcfg_data[9];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[10] <= 0; else b_data_q[10] <= bcfg_data[10];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[11] <= 0; else b_data_q[11] <= bcfg_data[11];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[12] <= 0; else b_data_q[12] <= bcfg_data[12];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[13] <= 0; else b_data_q[13] <= bcfg_data[13];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[14] <= 0; else b_data_q[14] <= bcfg_data[14];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[15] <= 0; else b_data_q[15] <= bcfg_data[15];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[16] <= 0; else b_data_q[16] <= bcfg_data[16];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[17] <= 0; else b_data_q[17] <= bcfg_data[17];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[18] <= 0; else b_data_q[18] <= bcfg_data[18];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[19] <= 0; else b_data_q[19] <= bcfg_data[19];
    always @(posedge ck or negedge land1[1])
        if (!land1[1]) b_data_q[20] <= 0; else b_data_q[20] <= bcfg_data[20];
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_data_q[21] <= 0; else b_data_q[21] <= bcfg_data[21];
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_data_q[22] <= 0; else b_data_q[22] <= bcfg_data[22];
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_data_q[23] <= 0; else b_data_q[23] <= bcfg_data[23];
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_data_q[24] <= 0; else b_data_q[24] <= bcfg_data[24];
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_data_q[25] <= 0; else b_data_q[25] <= bcfg_data[25];
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_data_q[26] <= 0; else b_data_q[26] <= bcfg_data[26];
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_data_q[27] <= 0; else b_data_q[27] <= bcfg_data[27];
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_data_q[28] <= 0; else b_data_q[28] <= bcfg_data[28];
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_data_q[29] <= 0; else b_data_q[29] <= bcfg_data[29];
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_data_q[30] <= 0; else b_data_q[30] <= bcfg_data[30];
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_data_q[31] <= 0; else b_data_q[31] <= bcfg_data[31];
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_tx_copy0 <= 0; else b_tx_copy0 <= bcfg_tx_we;
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_rx_copy0 <= 0; else b_rx_copy0 <= bcfg_rx_we;
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_tx_copy1 <= 0; else b_tx_copy1 <= bcfg_tx_we;
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_rx_copy1 <= 0; else b_rx_copy1 <= bcfg_rx_we;
    always @(posedge ck or negedge land1[2])
        if (!land1[2]) b_tx_copy2 <= 0; else b_tx_copy2 <= bcfg_tx_we;
    always @(posedge ck or negedge land1[3])
        if (!land1[3]) b_rx_copy2 <= 0; else b_rx_copy2 <= bcfg_rx_we;
    always @(posedge ck or negedge land1[3])
        if (!land1[3]) b_tx_copy3 <= 0; else b_tx_copy3 <= bcfg_tx_we;
    always @(posedge ck or negedge land1[3])
        if (!land1[3]) b_rx_copy3 <= 0; else b_rx_copy3 <= bcfg_rx_we;
    wire s_tx, s_rx, s_cs, s_seg, s_rdy, s_run, s_adm, s_tok, s_fault;
    wire [5:0] s_addr, s_layer;
    wire [31:0] s_data;
    ot_qwen_d2d_cal_seq_bc4 #(.GO_OFS(GO_OFS), .TX_IMG(D2D_CAL_K_TX_IMG), .RX_IMG(D2D_CAL_K_RX_IMG),
        .TX_SEG1(D2D_CAL_K_TX_SEG1), .RX_SEG1(D2D_CAL_K_RX_SEG1), .START(D2D_CAL_START + START_ADJ),
        .ADM(1), .TX_SEG2(D2D_CAL_K_TX_SEG2), .RX_SEG2(D2D_CAL_K_RX_SEG2), .ADM_OFS(D2D_ADM_OFS), .ADM_LEN(D2D_ADM_LEN),
        .AUTO(1), .FIRST_OFS(D2D_FIRST_TOKEN), .PERIOD(D2D_TOKEN_PERIOD), .EP_SKEW(EP_SKEW - 2)) u_seq (
        .ck(ck), .rst_bank_n({1'b0,rel1[14:0]}), .reload(reload_q), .tok_go(1'b0), .epoch_go(epoch_go_q), .halt(halt_q), .cfg_tx_we(s_tx),
        .cfg_rx_we(s_rx), .cfg_addr(s_addr), .cfg_data(s_data), .cal_start(s_cs), .cal_seg(s_seg),
        .cal_ready(s_rdy), .running(s_run), .layer(s_layer), .adm_done(s_adm), .tok_start(s_tok), .fault(s_fault));
    // ---- merge: the sequencer's own writes only after its init stream.  The init's last write and cal_ready rise on the
    // same edge, so "after init" = cal_ready now AND one edge ago (a reload drops cal_ready with its first init write).
    (* keep = 1, dont_touch = 1 *) reg rdy_copy0;
    wire s_we_part0 = (MUT == 1) ? 1'b0 : ((s_tx || s_rx) && s_rdy && rdy_copy0);
    (* keep = 1, dont_touch = 1 *) reg rdy_copy1;
    wire s_we_part1 = (MUT == 1) ? 1'b0 : ((s_tx || s_rx) && s_rdy && rdy_copy1);
    (* keep = 1, dont_touch = 1 *) reg rdy_copy2;
    wire s_we_part2 = (MUT == 1) ? 1'b0 : ((s_tx || s_rx) && s_rdy && rdy_copy2);
    wire b_we_part3 = b_tx_copy3 || b_rx_copy3;
    wire b_we_part0 = b_tx_copy0 || b_rx_copy0;
    wire b_we_part1 = b_tx_copy1 || b_rx_copy1;
    wire b_we_part2 = b_tx_copy2 || b_rx_copy2;
    reg rdy_q, adm_act, btx_seen, brx_seen;
    reg f_col, f_run, f_stale, f_early;      // fault cause (bench observability; `fault` is their OR with the sequencer's)
    wire s_we = (MUT == 1) ? 1'b0 : ((s_tx || s_rx) && s_rdy && rdy_q);
    wire b_we = b_tx_q || b_rx_q;
    wire b_base = b_we && (b_addr_q == 6'b100000);
    wire n_col = b_we && s_we;
    wire n_run = b_we && (s_run || adm_act);
    wire n_stale = b_base && (b_tx_q ? (b_data_q != D2D_CAL_K_TX_SEG2) : (b_data_q != D2D_CAL_K_RX_SEG2));
    wire n_early = s_cs && !(btx_seen && brx_seen);
    reg [0:0] cfg_tx_we_next;
    reg [0:0] cfg_rx_we_next;
    reg [5:0] cfg_addr_next;
    reg [31:0] cfg_data_next;
    reg [0:0] cal_start_next;
    reg [0:0] cal_seg_next;
    reg [0:0] cal_ready_next;
    reg [0:0] running_next;
    reg [5:0] layer_next;
    reg [0:0] adm_done_next;
    reg [0:0] tok_start_next;
    reg [0:0] rdy_q_next;
    reg [0:0] adm_act_next;
    reg [0:0] btx_seen_next;
    reg [0:0] brx_seen_next;
    reg [0:0] f_col_next;
    reg [0:0] f_run_next;
    reg [0:0] f_stale_next;
    reg [0:0] f_early_next;
    reg [0:0] fault_next;
    reg [0:0] rdy_copy0_next;
    reg [0:0] rdy_copy1_next;
    reg [0:0] rdy_copy2_next;
    reg [0:0] cfg_tx_we_part0;
    reg [0:0] cfg_rx_we_part0;
    reg [5:0] cfg_addr_part0;
    reg [31:0] cfg_data_part0;
    reg [31:0] cfg_data_part1;
    reg [31:0] cfg_data_part2;
    reg [31:0] cfg_data_part3;
    reg [0:0] cal_start_part0;
    reg [0:0] cal_seg_part0;
    reg [0:0] cal_ready_part0;
    reg [0:0] running_part0;
    reg [5:0] layer_part0;
    reg [0:0] adm_done_part0;
    reg [0:0] tok_start_part0;
    reg [0:0] rdy_q_part0;
    reg [0:0] adm_act_part0;
    reg [0:0] btx_seen_part0;
    reg [0:0] brx_seen_part0;
    reg [0:0] f_col_part0;
    reg [0:0] f_run_part0;
    reg [0:0] f_stale_part0;
    reg [0:0] f_early_part0;
    reg [0:0] fault_part0;
    always @* begin
        cfg_tx_we_part0 = cfg_tx_we;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part0) begin
                cfg_tx_we_part0 = b_tx_q; ; ; ;
            end else begin
                cfg_tx_we_part0 = s_we_part0 && s_tx; ;
                if (s_we_part0) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        cfg_tx_we_next[0:0] = cfg_tx_we_part0[0:0];
    end
    always @* begin
        cfg_rx_we_part0 = cfg_rx_we;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part1) begin
                ; cfg_rx_we_part0 = b_rx_q; ; ;
            end else begin
                ; cfg_rx_we_part0 = s_we_part1 && s_rx;
                if (s_we_part1) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        cfg_rx_we_next[0:0] = cfg_rx_we_part0[0:0];
    end
    always @* begin
        cfg_addr_part0 = cfg_addr;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part2) begin
                ; ; cfg_addr_part0 = b_addr_q; ;
            end else begin
                ; ;
                if (s_we_part2) begin cfg_addr_part0 = s_addr; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        cfg_addr_next[5:0] = cfg_addr_part0[5:0];
    end
    always @* begin
        cfg_data_part0 = cfg_data;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part3) begin
                ; ; ; cfg_data_part0 = b_data_q;
            end else begin
                ; ;
                if (s_we_part0) begin ; cfg_data_part0 = s_data; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        cfg_data_next[7:0] = cfg_data_part0[7:0];
    end
    always @* begin
        cfg_data_part1 = cfg_data;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part0) begin
                ; ; ; cfg_data_part1 = b_data_q;
            end else begin
                ; ;
                if (s_we_part1) begin ; cfg_data_part1 = s_data; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        cfg_data_next[15:8] = cfg_data_part1[15:8];
    end
    always @* begin
        cfg_data_part2 = cfg_data;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part1) begin
                ; ; ; cfg_data_part2 = b_data_q;
            end else begin
                ; ;
                if (s_we_part2) begin ; cfg_data_part2 = s_data; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        cfg_data_next[23:16] = cfg_data_part2[23:16];
    end
    always @* begin
        cfg_data_part3 = cfg_data;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part2) begin
                ; ; ; cfg_data_part3 = b_data_q;
            end else begin
                ; ;
                if (s_we_part0) begin ; cfg_data_part3 = s_data; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        cfg_data_next[31:24] = cfg_data_part3[31:24];
    end
    always @* begin
        cal_start_part0 = cal_start;
            cal_start_part0 = s_cs; ; ; ; ;
            ; ;
            ;
            if (b_we_part0) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part1) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        cal_start_next[0:0] = cal_start_part0[0:0];
    end
    always @* begin
        cal_seg_part0 = cal_seg;
            ; cal_seg_part0 = s_seg; ; ; ;
            ; ;
            ;
            if (b_we_part1) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part2) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        cal_seg_next[0:0] = cal_seg_part0[0:0];
    end
    always @* begin
        cal_ready_part0 = cal_ready;
            ; ; cal_ready_part0 = s_rdy; ; ;
            ; ;
            ;
            if (b_we_part2) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part0) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        cal_ready_next[0:0] = cal_ready_part0[0:0];
    end
    always @* begin
        running_part0 = running;
            ; ; ; running_part0 = s_run; ;
            ; ;
            ;
            if (b_we_part3) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part1) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        running_next[0:0] = running_part0[0:0];
    end
    always @* begin
        layer_part0 = layer;
            ; ; ; ; layer_part0 = s_layer;
            ; ;
            ;
            if (b_we_part0) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part2) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        layer_next[5:0] = layer_part0[5:0];
    end
    always @* begin
        adm_done_part0 = adm_done;
            ; ; ; ; ;
            adm_done_part0 = s_adm; ;
            ;
            if (b_we_part1) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part0) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        adm_done_next[0:0] = adm_done_part0[0:0];
    end
    always @* begin
        tok_start_part0 = tok_start;
            ; ; ; ; ;
            ; tok_start_part0 = s_tok;
            ;
            if (b_we_part2) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part1) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        tok_start_next[0:0] = tok_start_part0[0:0];
    end
    always @* begin
        rdy_q_part0 = rdy_q;
            ; ; ; ; ;
            ; ;
            rdy_q_part0 = s_rdy;
            if (b_we_part3) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part2) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        rdy_q_next[0:0] = rdy_q_part0[0:0];
    end
    always @* begin
        adm_act_part0 = adm_act;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part0) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part0) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) adm_act_part0 = 1'b1;
            else if (s_adm || halt_q) adm_act_part0 = 1'b0;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        adm_act_next[0:0] = adm_act_part0[0:0];
    end
    always @* begin
        btx_seen_part0 = btx_seen;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part1) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part1) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin btx_seen_part0 = 1'b0; ; end
            else begin
                if (b_base && b_tx_q) btx_seen_part0 = 1'b1;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        btx_seen_next[0:0] = btx_seen_part0[0:0];
    end
    always @* begin
        brx_seen_part0 = brx_seen;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part2) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part2) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; brx_seen_part0 = 1'b0; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) brx_seen_part0 = 1'b1;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        brx_seen_next[0:0] = brx_seen_part0[0:0];
    end
    always @* begin
        f_col_part0 = f_col;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part3) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part0) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) f_col_part0 = 1'b1;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        f_col_next[0:0] = f_col_part0[0:0];
    end
    always @* begin
        f_run_part0 = f_run;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part0) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part1) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) f_run_part0 = 1'b1;
            if (n_stale) ;
            if (n_early) ;
            ;
        
        f_run_next[0:0] = f_run_part0[0:0];
    end
    always @* begin
        f_stale_part0 = f_stale;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part1) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part2) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) f_stale_part0 = 1'b1;
            if (n_early) ;
            ;
        
        f_stale_next[0:0] = f_stale_part0[0:0];
    end
    always @* begin
        f_early_part0 = f_early;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part2) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part0) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) f_early_part0 = 1'b1;
            ;
        
        f_early_next[0:0] = f_early_part0[0:0];
    end
    always @* begin
        fault_part0 = fault;
            ; ; ; ; ;
            ; ;
            ;
            if (b_we_part3) begin
                ; ; ; ;
            end else begin
                ; ;
                if (s_we_part1) begin ; ; end
            end
            // admission run: from its start (layer 63) until adm_done; the token programme is the sequencer's `running`
            if (s_cs && s_seg && s_layer == 6'h3f) ;
            else if (s_adm || halt_q) ;
            if (reload_q) begin ; ; end
            else begin
                if (b_base && b_tx_q) ;
                if (b_base && b_rx_q) ;
            end
            if (n_col) ;
            if (n_run) ;
            if (n_stale) ;
            if (n_early) ;
            fault_part0 = fault || s_fault || n_col || n_run || n_stale || n_early;
        
        fault_next[0:0] = fault_part0[0:0];
    end
    always @* rdy_copy0_next = rdy_q_next;
    always @* rdy_copy1_next = rdy_q_next;
    always @* rdy_copy2_next = rdy_q_next;
    always @(posedge ck or negedge rel1[15])
        if (!rel1[15]) cfg_tx_we <= 0;
        else cfg_tx_we <= cfg_tx_we_next;
    always @(posedge ck or negedge rel1[15])
        if (!rel1[15]) cfg_rx_we <= 0;
        else cfg_rx_we <= cfg_rx_we_next;
    always @(posedge ck or negedge rel1[15])
        if (!rel1[15]) cfg_addr[5:0] <= ((6'(0)) >> 0);
        else cfg_addr[5:0] <= cfg_addr_next[5:0];
    always @(posedge ck or negedge rel1[15])
        if (!rel1[15]) cfg_data[7:0] <= ((32'(0)) >> 0);
        else cfg_data[7:0] <= cfg_data_next[7:0];
    always @(posedge ck or negedge rel1[16])
        if (!rel1[16]) cfg_data[23:8] <= ((32'(0)) >> 8);
        else cfg_data[23:8] <= cfg_data_next[23:8];
    always @(posedge ck or negedge rel1[17])
        if (!rel1[17]) cfg_data[31:24] <= ((32'(0)) >> 24);
        else cfg_data[31:24] <= cfg_data_next[31:24];
    always @(posedge ck or negedge rel1[17])
        if (!rel1[17]) cal_start <= 0;
        else cal_start <= cal_start_next;
    always @(posedge ck or negedge rel1[17])
        if (!rel1[17]) cal_seg <= 0;
        else cal_seg <= cal_seg_next;
    always @(posedge ck or negedge rel1[17])
        if (!rel1[17]) cal_ready <= 0;
        else cal_ready <= cal_ready_next;
    always @(posedge ck or negedge rel1[17])
        if (!rel1[17]) running <= 0;
        else running <= running_next;
    always @(posedge ck or negedge rel1[17])
        if (!rel1[17]) layer[3:0] <= ((6'(0)) >> 0);
        else layer[3:0] <= layer_next[3:0];
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) layer[5:4] <= ((6'(0)) >> 4);
        else layer[5:4] <= layer_next[5:4];
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) adm_done <= 0;
        else adm_done <= adm_done_next;
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) tok_start <= 0;
        else tok_start <= tok_start_next;
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) rdy_q <= 0;
        else rdy_q <= rdy_q_next;
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) adm_act <= 0;
        else adm_act <= adm_act_next;
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) btx_seen <= 0;
        else btx_seen <= btx_seen_next;
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) brx_seen <= 0;
        else brx_seen <= brx_seen_next;
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) f_col <= 0;
        else f_col <= f_col_next;
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) f_run <= 0;
        else f_run <= f_run_next;
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) f_stale <= 0;
        else f_stale <= f_stale_next;
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) f_early <= 0;
        else f_early <= f_early_next;
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) fault <= 0;
        else fault <= fault_next;
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) rdy_copy0 <= 0;
        else rdy_copy0 <= rdy_copy0_next;
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) rdy_copy1 <= 0;
        else rdy_copy1 <= rdy_copy1_next;
    always @(posedge ck or negedge rel1[18])
        if (!rel1[18]) rdy_copy2 <= 0;
        else rdy_copy2 <= rdy_copy2_next;
endmodule
