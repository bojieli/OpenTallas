import sys,os,subprocess,json,hashlib
from pathlib import Path
S=Path('/srv/opentallas-scratch/claude/qwen-kvsys/wt-kvs14r-54e9d9c39-gen9d5p');D=Path.cwd();B=D/'port_bind_v2'
sys.path.insert(0,str(S/'tools/qwen_kv_die'));import kv_static_die as K
files=[D/'case_kv/qkd_kv_relays.sv',S/'rtl/qwen_sys/kv_rly_std_20261016/qkd_rlys.sv',S/'rtl/qwen_sys/kv_fwd_lane_20261018/qkd_rlysh.sv',S/'rtl/qwen_split/qfd_fwd_lane.sv',S/'rtl/hdc/ot_hdc_cg.sv',S/K.RTL_FILE,B/'kv_hard_models.sv',B/'kv_relays_dir.sv',S/'physical/qwen_kv_die_phy/ot_qkvd_ucie_x64_phy/ot_qkvd_ucie_x64_phy_bb.v',S/'physical/qwen_missing_phy/ot_qfd_serdes_112g_x12_phy/ot_qfd_serdes_112g_x12_phy_bb.v']
files += [S/b['file'] for b in K.bindings().values() if b['module'].endswith('_fl')]
files += [S/'rtl/lib/ot_rst_relay.sv',S/'rtl/lib/ot_pin_land.sv']
cmd=['python3',str(S/'tools/die_port_bind.py'),str(B/'die_bound.v'),'--rtl-root','rtl','--lib-root','physical/qkd_astk_strip/macros','--strap-file',str(B/'straps.json'),'--out',str(B/'diagnostic_source_index.json')]
for f in sorted(set(files)):cmd += ['--rtl-file',str(f)]
for f in ['rtl/hdc/ot_hdc_fp32_add_lat.sv','rtl/hdc/ot_hdc_fp32_mul_lat.sv','physical/qwen_kv_die_phy/ot_qkvd_ucie_x64_phy/ot_qkvd_ucie_x64_phy_bb.v','physical/qwen_missing_phy/ot_qfd_serdes_112g_x12_phy/ot_qfd_serdes_112g_x12_phy_bb.v']:cmd+=['--prefer',f]
for m in ['qkd_hbm3e_phy_pc','qkd_ckbump','qkd_fwdbump','ot_qkvd_ucie_x64_phy','ot_qkvd_ucie_x64_phy_model','ot_qfd_serdes_112g_x12_phy','qkd_pll_analog_model']:cmd+=['--allow-model',m]
(B/'diagnostic_index_command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (B/'diagnostic_source_index.log').open('w') as f:rc=subprocess.run(cmd,cwd=S,stdout=f,stderr=subprocess.STDOUT).returncode
j=json.loads((B/'diagnostic_source_index.json').read_text());print('DIAGNOSTIC_INDEX',rc,'keys',list(j),flush=True)
identity=dict(qualified=False,native_qualified=False,bind_verdict='FAIL',purpose='Actual bound graph/source origin witness only; NO unused output pad claims; original guard refused dynamic private-spare output',source_commit='54e9d9c39',health_ledger_producer='17b71c479',index_exit=rc,source_files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},artifacts={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [B/'die_bound.v',B/'diagnostic_source_index.json',B/'diagnostic_source_index.log',B/'output_pads.log']})
(B/'diagnostic_index_identity.json').write_text(json.dumps(identity,indent=2)+'\n')
raise SystemExit(0 if rc!=0 else 1)
