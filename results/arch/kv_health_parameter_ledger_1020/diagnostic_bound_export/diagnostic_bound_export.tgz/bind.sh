#!/bin/bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
source ./kv_flags.env
export OT_KV_PARAM_DIAG=1 OT_BIND_DIAGNOSTIC=1
S=/srv/opentallas-scratch/claude/qwen-kvsys/wt-kvs14r-54e9d9c39-gen9d5p
D="$PWD"
cd "$S"
bash tools/qwen_kv_die/kv_port_bind_v2.sh "$D/case_kv/die.v" "$D/port_bind_v2" "$D/case_kv/qkd_kv_relays.sv" "$D/expand.json"
