import json,hashlib,subprocess,gzip,sys,re
from pathlib import Path
D=Path.cwd();S=Path('/srv/opentallas-scratch/claude/qwen-kvsys/wt-kvs14r-54e9d9c39-gen9d5p');B=D/'port_bind_v2';pb=json.loads((B/'diagnostic_source_index.json').read_text());assert pb['verdict']=='FAIL'
flat=D/'diagnostic_rtl';flat.mkdir(exist_ok=True)
files=sorted(set([v['rtl'] for v in pb['masters'].values()]+pb.get('rtl_files',[])));ident={}
for f in files:
 p=Path(f);p=p if p.is_absolute() else S/p;assert p.is_file(),p
 q=flat/p.name;data=p.read_bytes()
 if q.exists():assert q.read_bytes()==data,('basenamecollision',q,p)
 else:q.write_bytes(data)
 ident[str(p)]=hashlib.sha256(data).hexdigest()
tool=D/'export_tools/tools/qwen_layerbench/netlist_relay_stages.py';out=D/'relay_stages_diagnostic.json.gz'
cmd=['python3',str(tool),'--die-v',str(B/'die_bound.v'),'--port-bind',str(B/'diagnostic_source_index.json'),'--design','qwen_kv','--commit','54e9d9c39','--src-prefix',str(S)+'/', '--local-rtl',str(flat),'--local-rtl',str(B),'--local-rtl',str(D/'case_kv'),'--plan-id','d5p54e9-health17b71-DIAGNOSTIC-ONLY','--lanes',str(D/'fwd_lanes.json'),'--out',str(out)]
(D/'diagnostic_export_command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (D/'diagnostic_export.log').open('w') as f:rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
if rc:raise SystemExit(rc)
with gzip.open(out,'rt') as f:doc=json.load(f)
doc.update(native_qualified=False,physical_qualified=False,bind_verdict='FAIL',qualification='DIAGNOSTIC_ONLY_SOURCE_ORIGIN_WITNESS',diagnostic_source_index_sha256=hashlib.sha256((B/'diagnostic_source_index.json').read_bytes()).hexdigest())
with gzip.open(out,'wt') as f:json.dump(doc,f,separators=(',',':'));f.write('\n')
sys.path.insert(0,str(D/'export_tools/tools'));import die_relay_stages as R
assert not R.validate(doc),R.validate(doc)
receipt=dict(qualified=False,native_qualified=False,bind_verdict='FAIL',source_commit='54e9d9c39',health_ledger_producer='17b71c479',purpose='Actualboundgraph/sourceorigin only; NO productionphase/package/release/adoption authority',table=str(out),table_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),bus_count=doc['bus_count'],problem_count=doc['problem_count'],digest=doc['digest'],inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [B/'die_bound.v',B/'diagnostic_source_index.json',D/'fwd_lanes.json',D/'expand.json',D/'case_kv/die.v.params.json']},rtl_sha256=ident,tools={str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (D/'export_tools').rglob('*.py')})
(D/'diagnostic_export_identity.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ['qualified','bind_verdict','table','table_sha256','bus_count','problem_count','digest']}),flush=True)
