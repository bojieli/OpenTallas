(* blackbox *) module AO21x1_ASAP7_75t_R(Y, A1, A2, B);
output Y;
input A1, A2, B;
endmodule
(* blackbox *) module AO221x1_ASAP7_75t_R(Y, A1, A2, B1, B2, C);
output Y;
input A1, A2, B1, B2, C;
endmodule
(* blackbox *) module AO222x2_ASAP7_75t_R(Y, A1, A2, B1, B2, C1, C2);
output Y;
input A1, A2, B1, B2, C1, C2;
endmodule
(* blackbox *) module AO22x1_ASAP7_75t_R(Y, A1, A2, B1, B2);
output Y;
input A1, A2, B1, B2;
endmodule
(* blackbox *) module AO31x2_ASAP7_75t_R(Y, A1, A2, A3, B);
output Y;
input A1, A2, A3, B;
endmodule
(* blackbox *) module AO32x1_ASAP7_75t_R(Y, A1, A2, A3, B1, B2);
output Y;
input A1, A2, A3, B1, B2;
endmodule
(* blackbox *) module AO33x2_ASAP7_75t_R(Y, A1, A2, A3, B1, B2, B3);
output Y;
input A1, A2, A3, B1, B2, B3;
endmodule
(* blackbox *) module AOI211x1_ASAP7_75t_R(Y, A1, A2, B, C);
output Y;
input A1, A2, B, C;
endmodule
(* blackbox *) module AOI21x1_ASAP7_75t_R(Y, A1, A2, B);
output Y;
input A1, A2, B;
endmodule
(* blackbox *) module AOI221x1_ASAP7_75t_R(Y, A1, A2, B1, B2, C);
output Y;
input A1, A2, B1, B2, C;
endmodule
(* blackbox *) module AOI22x1_ASAP7_75t_R(Y, A1, A2, B1, B2);
output Y;
input A1, A2, B1, B2;
endmodule
(* blackbox *) module BUFx2_ASAP7_75t_R(Y, A);
output Y;
input A;
endmodule
(* blackbox *) module BUFx3_ASAP7_75t_R(Y, A);
output Y;
input A;
endmodule
(* blackbox *) module INVx1_ASAP7_75t_R(Y, A);
output Y;
input A;
endmodule
(* blackbox *) module OA211x2_ASAP7_75t_R(Y, A1, A2, B, C);
output Y;
input A1, A2, B, C;
endmodule
(* blackbox *) module OA21x2_ASAP7_75t_R(Y, A1, A2, B);
output Y;
input A1, A2, B;
endmodule
(* blackbox *) module OA222x2_ASAP7_75t_R(Y, A1, A2, B1, B2, C1, C2);
output Y;
input A1, A2, B1, B2, C1, C2;
endmodule
(* blackbox *) module OA22x2_ASAP7_75t_R(Y, A1, A2, B1, B2);
output Y;
input A1, A2, B1, B2;
endmodule
(* blackbox *) module OA31x2_ASAP7_75t_R(Y, A1, A2, A3, B1);
output Y;
input A1, A2, A3, B1;
endmodule
(* blackbox *) module OAI21x1_ASAP7_75t_R(Y, A1, A2, B);
output Y;
input A1, A2, B;
endmodule
(* blackbox *) module OAI22x1_ASAP7_75t_R(Y, A1, A2, B1, B2);
output Y;
input A1, A2, B1, B2;
endmodule
(* blackbox *) module AND2x2_ASAP7_75t_R(Y, A, B);
output Y;
input A, B;
endmodule
(* blackbox *) module AND3x1_ASAP7_75t_R(Y, A, B, C);
output Y;
input A, B, C;
endmodule
(* blackbox *) module AND4x1_ASAP7_75t_R(Y, A, B, C, D);
output Y;
input A, B, C, D;
endmodule
(* blackbox *) module AND5x1_ASAP7_75t_R(Y, A, B, C, D, E);
output Y;
input A, B, C, D, E;
endmodule
(* blackbox *) module MAJx2_ASAP7_75t_R(Y, A, B, C);
output Y;
input A, B, C;
endmodule
(* blackbox *) module NAND2x1_ASAP7_75t_R(Y, A, B);
output Y;
input A, B;
endmodule
(* blackbox *) module NAND3x1_ASAP7_75t_R(Y, A, B, C);
output Y;
input A, B, C;
endmodule
(* blackbox *) module NOR2x1_ASAP7_75t_R(Y, A, B);
output Y;
input A, B;
endmodule
(* blackbox *) module NOR3x1_ASAP7_75t_R(Y, A, B, C);
output Y;
input A, B, C;
endmodule
(* blackbox *) module OR2x2_ASAP7_75t_R(Y, A, B);
output Y;
input A, B;
endmodule
(* blackbox *) module OR3x1_ASAP7_75t_R(Y, A, B, C);
output Y;
input A, B, C;
endmodule
(* blackbox *) module OR4x1_ASAP7_75t_R(Y, A, B, C, D);
output Y;
input A, B, C, D;
endmodule
(* blackbox *) module OR5x1_ASAP7_75t_R(Y, A, B, C, D, E);
output Y;
input A, B, C, D, E;
endmodule
(* blackbox *) module TIEHIx1_ASAP7_75t_R(H);
output H;
endmodule
(* blackbox *) module TIELOx1_ASAP7_75t_R(L);
output L;
endmodule
(* blackbox *) module XNOR2x1_ASAP7_75t_R(Y, A, B);
output Y;
input A, B;
endmodule
(* blackbox *) module XNOR2x2_ASAP7_75t_R(Y, A, B);
output Y;
input A, B;
endmodule
(* blackbox *) module XOR2x2_ASAP7_75t_R(Y, A, B);
output Y;
input A, B;
endmodule
(* blackbox *) module DFFASRHQNx1_ASAP7_75t_R(QN, D, RESETN, SETN, CLK);
output QN;
input D, RESETN, SETN, CLK;
endmodule
(* blackbox *) module DFFHQNx1_ASAP7_75t_R(QN, D, CLK);
output QN;
input D, CLK;
endmodule
(* blackbox *) module DFFHQNx2_ASAP7_75t_R(QN, D, CLK);
output QN;
input D, CLK;
endmodule
(* blackbox *) module DFFHQNx3_ASAP7_75t_R(QN, D, CLK);
output QN;
input D, CLK;
endmodule
(* blackbox *) module DFFHQx4_ASAP7_75t_R(Q, D, CLK);
output Q;
input D, CLK;
endmodule
(* blackbox *) module DFFLQNx1_ASAP7_75t_R(QN, D, CLK);
output QN;
input D, CLK;
endmodule
(* blackbox *) module DFFLQNx2_ASAP7_75t_R(QN, D, CLK);
output QN;
input D, CLK;
endmodule
(* blackbox *) module DFFLQNx3_ASAP7_75t_R(QN, D, CLK);
output QN;
input D, CLK;
endmodule
(* blackbox *) module DFFLQx4_ASAP7_75t_R(Q, D, CLK);
output Q;
input D, CLK;
endmodule
(* blackbox *) module DHLx1_ASAP7_75t_R(Q, D, CLK);
output Q;
input D, CLK;
endmodule
(* blackbox *) module DHLx2_ASAP7_75t_R(Q, D, CLK);
output Q;
input D, CLK;
endmodule
(* blackbox *) module DHLx3_ASAP7_75t_R(Q, D, CLK);
output Q;
input D, CLK;
endmodule
(* blackbox *) module DLLx1_ASAP7_75t_R(Q, D, CLK);
output Q;
input D, CLK;
endmodule
(* blackbox *) module DLLx2_ASAP7_75t_R(Q, D, CLK);
output Q;
input D, CLK;
endmodule
(* blackbox *) module DLLx3_ASAP7_75t_R(Q, D, CLK);
output Q;
input D, CLK;
endmodule
(* blackbox *) module ICGx1_ASAP7_75t_R(GCLK, ENA, SE, CLK);
output GCLK;
input ENA, SE, CLK;
endmodule
(* blackbox *) module ICGx2_ASAP7_75t_R(GCLK, ENA, SE, CLK);
output GCLK;
input ENA, SE, CLK;
endmodule
(* blackbox *) module ICGx2p67DC_ASAP7_75t_R(GCLK, ENA, SE, CLK);
output GCLK;
input ENA, SE, CLK;
endmodule
(* blackbox *) module ICGx3_ASAP7_75t_R(GCLK, ENA, SE, CLK);
output GCLK;
input ENA, SE, CLK;
endmodule
(* blackbox *) module ICGx4DC_ASAP7_75t_R(GCLK, ENA, SE, CLK);
output GCLK;
input ENA, SE, CLK;
endmodule
(* blackbox *) module ICGx4_ASAP7_75t_R(GCLK, ENA, SE, CLK);
output GCLK;
input ENA, SE, CLK;
endmodule
(* blackbox *) module ICGx5_ASAP7_75t_R(GCLK, ENA, SE, CLK);
output GCLK;
input ENA, SE, CLK;
endmodule
(* blackbox *) module ICGx5p33DC_ASAP7_75t_R(GCLK, ENA, SE, CLK);
output GCLK;
input ENA, SE, CLK;
endmodule
(* blackbox *) module ICGx6p67DC_ASAP7_75t_R(GCLK, ENA, SE, CLK);
output GCLK;
input ENA, SE, CLK;
endmodule
(* blackbox *) module ICGx8DC_ASAP7_75t_R(GCLK, ENA, SE, CLK);
output GCLK;
input ENA, SE, CLK;
endmodule
(* blackbox *) module SDFHx1_ASAP7_75t_R(QN, D, SE, SI, CLK);
output QN;
input D, SE, SI, CLK;
endmodule
(* blackbox *) module SDFHx2_ASAP7_75t_R(QN, D, SE, SI, CLK);
output QN;
input D, SE, SI, CLK;
endmodule
(* blackbox *) module SDFHx3_ASAP7_75t_R(QN, D, SE, SI, CLK);
output QN;
input D, SE, SI, CLK;
endmodule
(* blackbox *) module SDFHx4_ASAP7_75t_R(QN, D, SE, SI, CLK);
output QN;
input D, SE, SI, CLK;
endmodule
(* blackbox *) module SDFLx1_ASAP7_75t_R(QN, D, SE, SI, CLK);
output QN;
input D, SE, SI, CLK;
endmodule
(* blackbox *) module SDFLx2_ASAP7_75t_R(QN, D, SE, SI, CLK);
output QN;
input D, SE, SI, CLK;
endmodule
(* blackbox *) module SDFLx3_ASAP7_75t_R(QN, D, SE, SI, CLK);
output QN;
input D, SE, SI, CLK;
endmodule
(* blackbox *) module SDFLx4_ASAP7_75t_R(QN, D, SE, SI, CLK);
output QN;
input D, SE, SI, CLK;
endmodule