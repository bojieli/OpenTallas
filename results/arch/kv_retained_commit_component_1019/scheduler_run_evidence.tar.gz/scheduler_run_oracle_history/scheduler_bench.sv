`timescale 1ns/1ps
// External-interface component bench. No hierarchical force, deposit or setup.
module scheduler_bench;
  reg clk=0; always #5 clk=~clk;
  reg rst_n=0,raw_por_n=0,warm_rst_n=0,pll_locked_i=0;
  reg health_bad_i=0,health_armed_i=0,health_cutoff_i=0;
  reg execution_restart_i=0,role_fault_i=0,owner_drained_i=0;
  wire[79:0] rc_identity;
  wire[79:0] health_identity_i=rc_identity;
  wire rc_bad,rc_armed,rc_retained_owned,rc_poison,rc_failure_pending,rc_report_once;
  wire[17:0]rc_mirror_pos,rc_mirror_tok,rc_mirror_ngen;
  wire[1:0]rc_mirror_state;
  wire rc_word0_offer,rc_response_confirmed;
  reg s_awvalid=0,s_wvalid=0,s_bready=1,s_arvalid=0,s_rready=1;
  reg[11:0]s_awaddr=0,s_araddr=0; reg[31:0]s_wdata=0;reg[3:0]s_wstrb=15;
  wire s_awready,s_wready,s_bvalid,s_arready,s_rvalid;wire[31:0]s_rdata;wire[1:0]s_bresp,s_rresp;
  wire m_arvalid,m_rready,m_awvalid,m_wvalid,m_bready,m_wlast;
  wire[63:0]m_araddr,m_awaddr,m_wdata;wire[7:0]m_arlen,m_awlen,m_wstrb;wire[2:0]m_arsize,m_awsize;
  reg m_arready=1,m_rvalid=0,m_rlast=1,m_awready=1,m_wready=1,m_bvalid=0;
  reg[63:0]m_rdata=0;reg[1:0]m_rresp=0,m_bresp=0;
  wire irq,pb_we,pb_re;wire[13:0]pb_waddr,pb_raddr;wire[17:0]pb_wdata;reg[17:0]pb_q=0;
  wire eng_start,eng_slot,eng_clr_req;wire[17:0]eng_token,eng_pos;wire[23:0]kv_base;
  reg eng_done=0,eng_fault=0,eng_clr_ack=0;reg[17:0]eng_next_token=0;reg[31:0]eng_cycles=3;
  wire arr_rst_n;wire[7:0]cfg_users;wire[17:0]cfg_prompt_len,cfg_gen_len;
  wire cq_commit_v;wire[15:0]cq_client_tag;wire[7:0]cq_slot;wire[17:0]cq_pos,cq_token;wire[1:0]cq_kind;wire[3:0]cq_status;
  wire step_issue_v,step_retire_v,step_retire_cq;wire[15:0]step_client_tag,step_retire_client_tag;
  wire[7:0]step_slot,step_retire_slot;wire[17:0]step_pos,step_retire_pos,step_retire_token;wire host_idle,host_observer_fault;
  ot_host_if_pb2_observed_rc #(.ENABLE_RETAINED_COMMIT(1),.HEALTH_CUTOFF_EDGES(12),.STEP_RESPONSE_DEADLINE_EDGES(8),.COMPONENT_FIXTURE(1),
    .NSLOT(1),.ENG_CTX(1),.MODE(0),.MU_OUT(0),.NW(18),.PLB(13),.CTX_MAX(8192),.FMT(1)) dut (
    .clk(clk),.rst_n(rst_n),.raw_por_n(raw_por_n),.warm_rst_n(warm_rst_n),.pll_locked_i(pll_locked_i),
    .health_bad_i(health_bad_i),.health_armed_i(health_armed_i),.health_identity_i(health_identity_i),.health_cutoff_i(health_cutoff_i),
    .execution_restart_i(execution_restart_i),.role_fault_i(role_fault_i),.owner_drained_i(owner_drained_i),
    .rc_bad(rc_bad),.rc_armed(rc_armed),.rc_retained_owned(rc_retained_owned),.rc_poison(rc_poison),.rc_failure_pending(rc_failure_pending),.rc_report_once(rc_report_once),
    .rc_mirror_pos(rc_mirror_pos),.rc_mirror_tok(rc_mirror_tok),.rc_mirror_ngen(rc_mirror_ngen),.rc_mirror_state(rc_mirror_state),.rc_identity(rc_identity),.rc_word0_offer(rc_word0_offer),.rc_response_confirmed(rc_response_confirmed),
    .s_awvalid(s_awvalid),.s_awready(s_awready),.s_awaddr(s_awaddr),.s_wvalid(s_wvalid),.s_wready(s_wready),.s_wdata(s_wdata),.s_wstrb(s_wstrb),.s_bvalid(s_bvalid),.s_bready(s_bready),.s_bresp(s_bresp),
    .s_arvalid(s_arvalid),.s_arready(s_arready),.s_araddr(s_araddr),.s_rvalid(s_rvalid),.s_rready(s_rready),.s_rdata(s_rdata),.s_rresp(s_rresp),
    .m_arvalid(m_arvalid),.m_arready(m_arready),.m_araddr(m_araddr),.m_arlen(m_arlen),.m_arsize(m_arsize),.m_rvalid(m_rvalid),.m_rready(m_rready),.m_rdata(m_rdata),.m_rresp(m_rresp),.m_rlast(m_rlast),
    .m_awvalid(m_awvalid),.m_awready(m_awready),.m_awaddr(m_awaddr),.m_awlen(m_awlen),.m_awsize(m_awsize),.m_wvalid(m_wvalid),.m_wready(m_wready),.m_wdata(m_wdata),.m_wstrb(m_wstrb),.m_wlast(m_wlast),.m_bvalid(m_bvalid),.m_bready(m_bready),.m_bresp(m_bresp),
    .irq(irq),.pb_we(pb_we),.pb_waddr(pb_waddr),.pb_wdata(pb_wdata),.pb_re(pb_re),.pb_raddr(pb_raddr),.pb_q(pb_q),
    .eng_start(eng_start),.eng_token(eng_token),.eng_pos(eng_pos),.eng_slot(eng_slot),.kv_base(kv_base),.eng_done(eng_done),.eng_next_token(eng_next_token),.eng_cycles(eng_cycles),.eng_fault(eng_fault),.eng_clr_req(eng_clr_req),.eng_clr_ack(eng_clr_ack),
    .arr_rst_n(arr_rst_n),.cfg_users(cfg_users),.cfg_prompt_len(cfg_prompt_len),.cfg_gen_len(cfg_gen_len),.pr_re(1'b0),.pr_user(8'd0),.pr_pos(18'd0),.tok_valid(1'b0),.tok_user(8'd0),.tok_pos(18'd0),.tok_id(18'd0),.users_done(8'd0),.arr_fault(1'b0),
    .cq_commit_v(cq_commit_v),.cq_client_tag(cq_client_tag),.cq_slot(cq_slot),.cq_pos(cq_pos),.cq_token(cq_token),.cq_kind(cq_kind),.cq_status(cq_status),
    .step_issue_v(step_issue_v),.step_client_tag(step_client_tag),.step_slot(step_slot),.step_pos(step_pos),.step_retire_v(step_retire_v),.step_retire_cq(step_retire_cq),.step_retire_client_tag(step_retire_client_tag),.step_retire_slot(step_retire_slot),.step_retire_pos(step_retire_pos),.step_retire_token(step_retire_token),.host_idle(host_idle),.host_observer_fault(host_observer_fault));
  reg[17:0]pbmem[0:16383];
  integer retires=0;
  integer edge_n=0,issues=0,raw_dones=0,commits=0,writes=0,engine_wait=0,health_age=0;
  reg read_pending=0,aw_seen=0,w_seen=0; reg[63:0]read_addr,write_addr,write_data;
  reg stalled_aw=0,stalled_w=0;reg[63:0]held_aw,held_w;reg[7:0]held_strb;
  integer case_id=0;integer prompt_len=1;integer engine_delay=3;
  reg engine_enable=1,auto_cutoff=1;reg[63:0]last_word0=0;
  function automatic[63:0] memread(input[63:0]a);
    case(a)
      64'h1000:memread=(64'd1<<48)|(64'(prompt_len)<<32)|(64'h1234<<16)|64'h101;
      64'h1008:memread=64'h3000;
      64'h1010:memread=0;
      64'h1018:memread=64'h0003ffff0003ffff;
      default:memread=64'h0000002b0000002a;
    endcase
  endfunction
  // Real synchronous external prompt RAM and independent engine/DMA responder.
  always @(posedge clk) begin
    edge_n<=edge_n+1;
    if(edge_n>2000)$fatal(1,"SCHED_TIMEOUT case=%0d issues=%0d writes=%0d bad=%0b armed=%0b",case_id,issues,writes,rc_bad,rc_armed);
    if(pb_we)pbmem[pb_waddr]<=pb_wdata;
    if(pb_re)pb_q<=pbmem[pb_raddr];
    eng_clr_ack<=eng_clr_req;
    m_rvalid<=read_pending;
    if(read_pending)m_rdata<=memread(read_addr);
    read_pending<=m_arvalid&&m_arready;
    if(m_arvalid&&m_arready)read_addr<=m_araddr;
    m_bvalid<=0;
    if(m_awvalid&&m_awready)begin aw_seen<=1;write_addr<=m_awaddr;end
    if(m_wvalid&&m_wready)begin w_seen<=1;write_data<=m_wdata;end
    if(aw_seen&&w_seen&&!m_bvalid)begin
      m_bvalid<=1;aw_seen<=0;w_seen<=0;writes<=writes+1;
      if(write_addr[3:0]==0)begin last_word0<=write_data;$display("WORD0 edge=%0d data=%h",edge_n,write_data);end
    end
    if(stalled_aw&&(!m_awvalid||m_awaddr!==held_aw))$fatal(1,"SCHED_AW_STABILITY");
    if(stalled_w&&(!m_wvalid||m_wdata!==held_w||m_wstrb!==held_strb))$fatal(1,"SCHED_W_STABILITY");
    stalled_aw<=m_awvalid&&!m_awready;held_aw<=m_awaddr;
    stalled_w<=m_wvalid&&!m_wready;held_w<=m_wdata;held_strb<=m_wstrb;
    eng_done<=0;
    if(eng_start)begin
      issues<=issues+1;
      if(eng_pos!==18'(issues)||eng_token!==18'(42+issues))$fatal(1,"SCHED_ENGINE_INPUT pos=%0d tok=%0d issue=%0d",eng_pos,eng_token,issues);
      engine_wait<=engine_delay;eng_next_token<=18'(43+issues);
      $display("ISSUE edge=%0d pos=%0d identity=%h",edge_n,eng_pos,rc_identity);
    end else if(engine_wait>0&&engine_enable)begin
      engine_wait<=engine_wait-1;
      if(engine_wait==1)begin eng_done<=1;raw_dones<=raw_dones+1;end
    end
    if(step_retire_v)retires<=retires+1;
    if(cq_commit_v)begin commits<=commits+1;$display("COMMIT edge=%0d status=%0d pos=%0d token=%0d",edge_n,cq_status,cq_pos,cq_token);end
    if(eng_start)begin health_age<=1;health_cutoff_i<=0;end
    else if(health_age>0)begin
      health_age<=health_age+1;
      // Conditional health arrival precedes the fixed H=12 evaluation edge.
      if(auto_cutoff&&health_age>=10)health_cutoff_i<=1;
    end

  end
  task automatic tick(input integer n);repeat(n)@(negedge clk);endtask
  task automatic csr(input[11:0]a,input[31:0]d);
    @(negedge clk);s_awaddr=a;s_wdata=d;s_awvalid=1;s_wvalid=1;
    do @(posedge clk);while(!(s_awready&&s_wready));
    @(negedge clk);s_awvalid=0;s_wvalid=0;
    while(!s_bvalid)@(negedge clk);tick(1);
  endtask
  task automatic setup_request;
    csr('h010,'h1000);csr('h018,3);csr('h024,'h2000);csr('h02c,3);csr('h008,1);csr('h01c,1);
  endtask
  task automatic await_issue;while(issues==0)tick(1);endtask
  initial begin
    if(!$value$plusargs("CASE=%d",case_id))case_id=0;
    tick(4);raw_por_n=1;warm_rst_n=1;pll_locked_i=1;rst_n=1;health_armed_i=1;tick(4);
    if(case_id==1)prompt_len=2;
    if(case_id==2||case_id==3)begin m_awready=0;m_wready=0;end
    if(case_id==5)engine_enable=0;
    setup_request();await_issue();
    case(case_id)
      0:begin while(commits==0)tick(1);if(rc_mirror_pos!=1||rc_mirror_tok!=43||rc_mirror_ngen!=1||!rc_response_confirmed||rc_bad||last_word0[7:4]!=2||last_word0[2:1]!=2)$fatal(1,"SCHED_HEALTHY");end
      1:begin health_bad_i=1;tick(1);health_bad_i=0;tick(40);if(!rc_bad||issues!=1||raw_dones!=1||retires!=1)$fatal(1,"SCHED_RAWDONE_CLEANUP");end
      2:begin
        while(!m_awvalid||!m_wvalid)tick(1);
        health_bad_i=1;warm_rst_n=0;tick(3);health_bad_i=0;warm_rst_n=1;
        if(!rc_bad||!rc_retained_owned)$fatal(1,"SCHED_RETAIN_WARM");
        tick(4);m_awready=1;m_wready=1;tick(30);
      end
      3:begin
        // Cutoff fixture must finish independently from CQ/DMA readiness.
        while(!health_cutoff_i)tick(1);tick(3);
        if(!rc_armed||writes!=0)$fatal(1,"SCHED_CUTOFF_NO_DMA");
        m_awready=1;m_wready=1;while(commits==0)tick(1);
      end
      4:begin
        // Fault arrives on the very edge where CQ word zero is first offered.
        while(!rc_word0_offer)tick(1);health_bad_i=1;tick(1);health_bad_i=0;tick(30);
        if(!rc_bad||last_word0[7:4]!=7||last_word0[2:1]!=3)$fatal(1,"SCHED_WORD0_FAULT data=%h",last_word0);
      end
      5:begin
        tick(14);if(!rc_bad)$fatal(1,"SCHED_DEADLINE");
        engine_enable=1;tick(30);if(raw_dones!=1||issues!=1||retires!=1)$fatal(1,"SCHED_LATE_DONE_CLEANUP");
      end
      default:$fatal(1,"SCHED_UNKNOWN_CASE");
    endcase
    $display("SCHED_PASS case=%0d edges=%0d issues=%0d rawdone=%0d commits=%0d writes=%0d",case_id,edge_n,issues,raw_dones,commits,writes);$finish;
  end
endmodule
