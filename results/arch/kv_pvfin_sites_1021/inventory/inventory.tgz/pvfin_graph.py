import json,math,hashlib
from pathlib import Path
b=Path.cwd();raw=b/'pad_attempts.json';a=json.loads(raw.read_text());r=a[1];w,h,cap=r['w'],r['h'],r['cap'];prev=r['prev'];sink=r['sink']
near=[i for i in r['insts'] if i['x']<6500 and i['x']+i['w']>5800 and i['y']<13200 and i['y']+i['h']>12800]
for n,x,y,kw,kh in r['keepouts']:near.append(dict(n=n,m='keepout',x=x,y=y,w=kw,h=kh))
def overlaps(x,y,i):
 g=4.32 if i['m'].startswith('qkd_rly_') else 21.6
 return min(x+w+g,i['x']+i['w'])-max(x-g,i['x'])>.001 and min(y+h+g,i['y']+i['h'])-max(y-g,i['y'])>.001
sites=[]
for row in range(3):
 for col in range(3):
  x=6104.16+64.8*col;y=12858.24+90.72*row
  hits=[dict(n=i['n'],m=i['m'],x=i['x'],y=i['y'],w=i['w'],h=i['h'])for i in near if overlaps(x,y,i)]
  sites.append(dict(x=x,y=y,w=w,h=h,conflicts=hits))
# Search actual free gridded sites in the north approach; report free sites, not a false closure proof.
free=[]
for xi in range(535,601):
 for yi in range(1188,1223):
  x=math.ceil((xi*10.8)/2.16-1e-7)*2.16;y=math.ceil((yi*10.8)/2.16-1e-7)*2.16
  if not any(overlaps(x,y,i)for i in near):free.append((x,y))
def span(a,b):return abs(a[0]+w-b[0])+abs(a[1]+h/2-b[1]-h/2)
def clash(a,b):return abs(a[0]-b[0])<w+4.32-.001 and abs(a[1]-b[1])<h+4.32-.001
adj=[[j for j,q in enumerate(free)if i!=j and span(p,q)<=cap and not clash(p,q)]for i,p in enumerate(free)]
start=[i for i,p in enumerate(free)if abs(prev[0]-p[0])+abs(prev[1]-p[1]-h/2)<=cap]
end={i for i,p in enumerate(free)if abs(p[0]+w-sink[0])+abs(p[1]+h/2-sink[1])<=cap}
visits=0;answer=None
# Bounded diagnosis: candidate search cap is computational, never a physical waiver.
def dfs(path):
 global visits,answer
 visits+=1
 if len(path)==9:
  if path[-1]in end:answer=path;return True
  return False
 if visits>200000:return False
 nxt=sorted(adj[path[-1]],key=lambda j:(j not in end,len(adj[j])))
 for j in nxt:
  if j in path or any(clash(free[j],free[k])for k in path):continue
  if dfs(path+[j]):return True
 return False
for i in sorted(start,key=lambda j:len(adj[j])):
 if dfs([i]):break
 if visits>200000:break
out=dict(scope='actual19580-frame staged PVFIN approach inventory; bounded graph search',source_sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),attempt=1,prev=prev,sink=sink,w=w,h=h,cap=cap,staged_instances=len(r['insts']),reserved_sites=sites,free_grid_sites=len(free),visits=visits,path=[free[i]for i in answer]if answer else None,static_conflicts=sum(any(x['m']=='keepout' or not x['m'].startswith('qkd_rly_')for x in p['conflicts'])for p in sites))
(b/'pvfin_graph_receipt.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items()if k!='reserved_sites'},indent=2));print('conflicts',[(p['x'],p['y'],[(i['n'],i['m'])for i in p['conflicts']])for p in sites])
