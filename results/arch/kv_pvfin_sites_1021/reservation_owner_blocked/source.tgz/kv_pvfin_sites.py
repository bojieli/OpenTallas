"""Opt-in exclusive PVFIN north padding homes; no calendar or RTL change.

Homes are temporary placement obstacles until the actual pvw_1.pr -> pvfin
alignment member owns them. They are removed before its real relay cells are
placed, so no fictitious keepout or cell survives in the rendered die.
"""
import os

PREFIX = 'pvfin_p1_home_'


def reserve(K, m):
    if os.environ.get('OT_KV_PVFIN_NORTH_SITES', '0') != '1' or 'pvfin_p1_homes' in m:
        return
    if (os.environ.get('OT_KV_CTL_CENTRAL') != '1' or os.environ.get('OT_KV_RLY_STD') != '1'
            or os.environ.get('OT_KV_PVFIN_ALIGN', '1') != '1'):
        raise ValueError('PVFIN north sites require central CTL and actual standard relay frames')
    by = {i.name: i for i in m['insts']}
    if 'pvfin' not in by:
        raise ValueError('PVFIN north sites require actual PVFIN instance')
    import kv_bundle_eq as EQ
    w, h = EQ._frame(K, 'ks_pvp1', 534)
    f = by['pvfin']
    slots = [dict(x=K.up(f.x + 69.552 + 64.8*c, K.GX),
                  y=K.up(f.y + 282.72 + 90.72*r, K.GY), w=w, h=h)
             for r in range(3) for c in range(3)]
    static = [i for i in m['insts'] if i.kind != 'relay']
    for q, s in enumerate(slots):
        if not EQ._free(m, static, s['x'], s['y'], w, h):
            raise ValueError(f'PVFIN north home {q} intersects actual static geometry')
    m['pvfin_p1_homes'] = dict(sites=slots, owner=['pvw_1', 'pr', 'pvfin'], state='reserved')
    m.setdefault('keepouts', []).extend((PREFIX+str(q), s['x'], s['y'], w, h) for q,s in enumerate(slots))


def release(m, bundle, member):
    rec = m.get('pvfin_p1_homes')
    if not rec or bundle != 'PV.fin_start' or tuple(member) != tuple(rec['owner']):
        return None
    m['keepouts'] = [k for k in m.get('keepouts', []) if not k[0].startswith(PREFIX)]
    rec['state'] = 'released_to_real_owner'
    return rec['sites']


def blocks(m, x, y, w, h):
    """Pin-repair has a separate occupancy implementation; honor these homes there too."""
    return any(n.startswith(PREFIX) and min(x+w+21.6,kx+kw)-max(x-21.6,kx)>.001
               and min(y+h+21.6,ky+kh)-max(y-21.6,ky)>.001
               for n,kx,ky,kw,kh in m.get('keepouts', []))


def place(K, m, staged, prev, sink, n, w, h, cap, sites):
    """Exact finite site graph: every frame, wire and orientation is checked."""
    if n > len(sites):
        return None
    import kv_bundle_eq as EQ
    near = list(m['insts']) + staged + [K.F.Inst(n,'keepout',x,y,kw,kh,'R0')
                                       for n,x,y,kw,kh in m.get('keepouts', [])]
    slots = [s for s in sites if abs(s['w']-w)<.001 and abs(s['h']-h)<.001
             and EQ._free(m,near,s['x'],s['y'],w,h)]
    def walk(path, point):
        if len(path)==n:
            return path if abs(point[0]-sink[0])+abs(point[1]-sink[1])<=cap else None
        for q,s in enumerate(slots):
            if q in path:
                continue
            a=(s['x'],s['y']+h/2);b=(s['x']+w,s['y']+h/2)
            if abs(a[0]-point[0])+abs(a[1]-point[1])>cap:
                continue
            # Explicitly check every selected pair, even when site pitch changes.
            if any(not EQ._free(m,[K.F.Inst('','',slots[j]['x'],slots[j]['y'],w-K.SHAVE,h-K.SHAVE,'R0',kind='relay')],s['x'],s['y'],w,h)for j in path):
                continue
            got=walk(path+[q],b)
            if got is not None:
                return got
        return None
    path=walk([],prev)
    if path is None:
        return None
    m['pvfin_p1_homes']['placement'] = dict(count=n,prev=list(prev),sink=list(sink),cap=cap,
                                          sites=[dict(slots[q])for q in path])
    return [K.F.Inst('','',slots[q]['x'],slots[q]['y'],w-K.SHAVE,h-K.SHAVE,'R0',kind='relay',region='relay')for q in path]
