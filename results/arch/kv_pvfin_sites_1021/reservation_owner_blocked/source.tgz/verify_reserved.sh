#!/bin/bash
set -euo pipefail
source /home/ubuntu/ot-scratch/claude/codex-kv-closure-0037/d25y4_flags.env
export OT_KV_KRS_TOP_CH_ES6=432 OT_KV_PVRS_ACTUAL_FIRST=1 OT_KV_EMB_WIN=595 OT_KV_WRITER_DIE=1 OT_KV_DOMSPLIT=1 OT_KV_GRP_SAFE2=1 OT_KV_GRP_S6C=1 OT_KV_NATIVE_SLOTS=1 OT_KV_CTL_CENTRAL=1 OT_KV_PVT_HUB_CLEAR=259.2 OT_KV_SN_LIFT=604.8
export OT_KV_PVFIN_NORTH_SITES=1
python3 verify_reserved.py > geometry.log 2>&1
