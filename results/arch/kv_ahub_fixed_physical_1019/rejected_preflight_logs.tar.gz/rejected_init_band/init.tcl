read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7_tech_1x_201209.lef
read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7sc7p5t_28_R_1x_220121a.lef
read_lef zh.lef
read_lef recip.lef
read_liberty cells.lib
read_liberty zh_tt.lib
read_liberty recip_tt.lib
read_verilog tied.v
link_design qkd_ahub_static_dw_safe_native
initialize_floorplan -die_area {0 0 734.4 540} -core_area {21.6 226.8 712.8 231.66} -site asap7sc7p5t
source /OpenROAD-flow-scripts/flow/platforms/asap7/openRoad/make_tracks.tcl
write_db init.odb
exit
