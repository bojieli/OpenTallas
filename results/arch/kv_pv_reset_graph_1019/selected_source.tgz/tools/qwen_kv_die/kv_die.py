#!/usr/bin/env python3
"""kv-die 2026-10-09 (OWNER DECISION ~04:00 PT, option 1a): the Qwen3-8B KV die (die generator `qwen_kv`).

One KV die per ROM die.  Long axis N-S; its N edge abuts the r22k ROM die's S edge under spine column M, where the two
UCIe macros face each other; the four HBM3E stacks sit beside its E and W edges (two a side), as they sat beside the
r21c ROM die.  Per side, outward to inward, the r21c HBM band re-placed with the SAME masters and pins
(tools/qwen_kv_die/r21c_band.json, dumped from the r21c generator):

    PHY (ot_hbm3e_phy 833.5 x 12,000.1) | controller (qkd_ctrl / qkd_ctrl_n = qfd_ctrl) | 32 per-PC CDC (qkd_cdc = qfd_cdc) |
    KV landing qkd_land (qfd_kvc successor: CDC core sides -> the stack's row engines, the KV merges, the KVN posted
    write, the embedding strip) | the stack's attention group:
        [ 4 row engines qkd_reng | stack aggregator qkd_astk | 4 row engines ]   (engine long faces abut the
        aggregator; RE-CUT D (results/arch/qwen_kv_die_20261009/recut.json): q in as a 519-b beat broadcast, P.V levels
        1-3 in the engine, one level-3 node a group out in 4,096-b beats -- ot_qwen_nearhbm_row_engine_d ports)

and a centre column: N edge -- UCIe macro (MX: bumps N, FDI S) / qkd_d2d (ot_qkvd_d2d) / qkd_seq (ot_qkvd_kv_seq) /
qkd_embgw (ot_qfd_emb_gw) / qkd_pll (PLL + reset sequencer, forwarded clock to the ROM die); die centre -- qkd_ahub
(ot_qwen_nearhbm_attn_hub_p); S edge -- the host SerDes macro (ot_qfd_serdes_112g_x12_phy) + qkd_host.
Relay stations at <= 430.56 um on every die wire that is not an abutment (same rule as the r21 ROM die).

    python3 tools/qwen_kv_die/kv_die.py plan --out results/arch/qwen_kv_die_20261009/kv_die      (record + DEF/V)
"""
import argparse
import copy
import hashlib
import json
import re
import math
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
import qwen_rom_fulldie as F     # noqa: E402  (Inst, Master, lattice, phy_pins, pin_rects, write_netlist)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import kv_elastic_boundary       # noqa: E402
import kv_strips as KS           # noqa: E402  (v1.2 strip compositions: land / astk RTL bindings + clock entries)

GX, GY, SHAVE = F.GX, F.GY, F.SHAVE
F.MINW_PINS = True               # M6 / M7 face pins at 0.032 (die_kv7 PA DRT-0073: 0.024 is sub-minimum)
up = F.up
TPL_PATH = ROOT / 'tools' / 'qwen_kv_die' / 'r21c_band.json'
MARGIN = 21.6
R = 8                           # row engines a stack (near-HBM gate R = 8: 1,824 cycles at ctx 8192)
# re-cut H (adopted 10-09, recut_h.json): the row engine is 5 hard tiles in a column, bottom -> top head 0, head 1 (both MX),
# control, head 2, head 3; the control tile's two S1b copies leave on its S (heads 0 / 1) and N (heads 2 / 3) faces, every
# head's node beat leaves on its E face into the aggregator.  Frames (variant c, routes qkd_rhead_c / qkd_ectl_c): the head
# 152,960 um2 cells (route qkd_rhead_b floorplan) at 0.52 on 648 wide -- 648 so the far head of a pair (one head tile
# away from the control tile) stays inside the wire reach; the control tile 24,507 um2 synthesized (route qkd_ectl_a), its
# height set by its E face (634 + 425 pins).
HEAD = (648.0, 453.6)
ECTL = (648.0, 129.6)            # E face: si 634 + so 425 pins on M4 at 2-track pitch (101.7 um) + margins
ENG_H = 4 * HEAD[1] + ECTL[1] + 4 * GY
RENG = (HEAD[0], ENG_H)         # the engine column slot
# tile offsets inside an engine column (bottom -> top): head 0, head 1, control, head 2, head 3
TILE_Y = dict(h0=0.0, h1=HEAD[1] + GY, c=2 * (HEAD[1] + GY), h2=2 * (HEAD[1] + GY) + ECTL[1] + GY,
              h3=3 * (HEAD[1] + GY) + ECTL[1] + GY)
ASTK_W = 220.32                  # stack aggregator (re-cut D) MEASURED: 8 exp quads 314 k + Z tree 99 k + P.V tree (levels 4-7) 288 k
                                # + node staging / q broadcast ~73 k um2 cells at 0.50 + score / e memories as SRAM macros (786 k b,
                                # ~0.19 mm2) over the 4-engine height 7,992 um (synth4; was 777.6 ASSUMED)
# v1.2 (split): the landing strip stands one 216-um channel E of the CDC column (+ the 2.4-um CDC overhang of x_land): the
# write-queue controller (172.8 wide) sits in it at the stack middle, so its chains to the write leaves in the CDC column
# stay short (behind a 12-mm landing strip they went round its end: 600-700 um hops, 38 stages); elsewhere it is the relay
# channel of the CDC-column chains (relay spots with their 21.6-um keep-outs); CDC co / cf -> landing <= ~220 um
LAND_CHAN = 2.4 + 216.0
LAND_W = 172.8                  # KV landing column: 8 x 32 crossbar, 8 KV merges, emb strip (ASSUMED; r21c qfd_kvc 96.7)
UCIE = ('ot_qkvd_ucie_x64_phy', 777.6, 777.6)
SERDES = ('ot_qfd_serdes_112g_x12_phy', 2320.056, 1563.57)  # actual native host RXD512 / FDI1043 profile
FRAMES = dict(qkd_ckbump=(43.2, 43.2), qkd_d2d=(777.6, 518.4), qkd_seq=(777.6, 518.4), qkd_embgw=(388.8, 388.8), qkd_pll=(324.0, 324.0),
              qkd_ahub=(648.0, 648.0), qkd_host=(777.6, 518.4))
RELAY_PITCH = 430.56
TREE_LAST = 200.0               # v1.4.2: a reset / boot tree chain ends <= this from its cluster leader
RST_REGION_IGNORE = 255          # v1.4.3 qkd_rst_region IGNORE: a region's chain depth limit (the host holds reset >= this + 4)
# KVPLAN 1815: regional reset roots + post-expansion local trees (kv_rst_regional.py); region box (um)
RST_REGIONAL = __import__('os').environ.get('OT_KV_RST_REGIONAL', '0') == '1'
RST_PIN_REG = __import__('os').environ.get('OT_KV_RST_PIN_REG', '1') == '1'   # KV-KITS/NATIVE 10-18: default ON (qkd_rst_region_pr CLOSED native PASS; ec1 view fails native capture 239.9 on its unregistered dly straps); 0 = legacy plans
RST_REGION_BOX = float(__import__('os').environ.get('OT_KV_RST_REGION_BOX', '4800'))
# KVPLAN 1815 (OT_KV_PHY_REG=1): REGISTERED PHY BOUNDARY -- a relay chain that starts or ends at a hard PHY macro
# (HBM PHY, host SerDes, UCIe) puts its first / last register within PHY_REACH um of the PHY pin (kvs12b TT: real -> phy
# host_fdi -211.6 ps on a 485-um last hop), so the PHY-side wire is short and the long wire is a planned relay hop
PHY_REG = __import__('os').environ.get('OT_KV_PHY_REG', '0') == '1'
PHY_REACH = float(__import__('os').environ.get('OT_KV_PHY_REACH', '150'))
# KVPLAN3 0230 (Q-KV decision 10-17 after DIE-CLOCK kv_rt3: 299 failing c <-> stack seam pairs = 267 reset-forest stations
# clocked on n_clk_core_c whose last hop feeds a stack tile's rst_n + 32 pvin / pvrq seam hops; kvs13k TT reset -> head
# stin rst_n -159 ps over 72 um): OT_KV_SEAM=1 -- (1) every reset-tree relay is clocked from the core tree of the tiles it
# FEEDS (its leader's clk_core_<region>), so a stack region's whole reset chain + local tree (kv_rst_regional inherits the
# region root's ck) runs on that stack's root; (2) the ONE hop of a chain that crosses core trees (tree: HOST -> first
# station; data chain: last relay -> a load on another tree, e.g. pvin -> fork, pvrq -> V port) is held to SEAM_REACH so
# the regional skew (~200 ps c <-> stack at kv_rt3) sits on a short wire; no added edge.  The seam list is recorded
# (m['clock_seams']) for the die STA / DIE-CLOCK neighbour check.  Default off: plans unchanged.
SEAM = __import__('os').environ.get('OT_KV_SEAM', '0') == '1'
SEAM_REACH = float(__import__('os').environ.get('OT_KV_SEAM_REACH', '150'))
# data-chain seams (pvin -> fork, pvrq -> V port, ...): OT_KV_SEAM_DATA_REACH um (0 = recorded only, normal reach).  The
# 150-um last hop into the fork column does not plan (d0 plan: pvin_WS_2 no spot 220 um from its fork); Q-KV's forwarded
# c <-> stack link station (+1 edge) needs a forwarded-clock relay master -- open
SEAM_DATA_REACH = float(__import__('os').environ.get('OT_KV_SEAM_DATA_REACH', '0'))
PHY_MASTERS = ('qkd_hbm3e_phy_pc', 'ot_qfd_serdes_112g_x12_phy', 'ot_qkvd_ucie_x64_phy')
# KVPLAN2 2215 (OT_KV_REACH_FIX=1, kvs13k radius@401: non-PV families over the measured KV reach 446):
#   head kp_k / kp_t / gf_t 457-468 -> head plans re-assigned at 400 (results/arch/qwen_kv_die/head_reach400: lane t in
#     slot perm[t] matching the closed ktree's E->W kp_in groups, ktree x 540 / score x 388.8; same leaves / cycles);
#   cdco 476 -> the landing's c<k>i word level with the CLOSED CDC view's co pins (was the CDC frame centre + 40);
#   wcf 552 -> c_fault (1 b, sticky fault, observation delay only) rides planned relays (class kv_oneway, stages
#     recorded in relay_stages like kf / lkf); the closed CDC's cf pin is mid S face, 460 um from the landing face.
#   tg / tge / th 511-524 are the v1.4.3d three-row stage band (OT_KV_V143D=1), not this flag.
REACH_FIX = __import__('os').environ.get('OT_KV_REACH_FIX', '0') == '1'
CDC_VIEW_LEF = 'physical/ref_tile/qkd_cdc_wleaf_ref/views/qkd_cdc_wleaf/qkd_cdc_wleaf.lef'
# KVPLAN 1815 (Q-KV 10-16, kvs13c2 TT: every top class a 528-b replica hop at the 445 plan limit): planned hop limit per
# relay WIDTH class -- a wide word's bits spread over the replica row (<= 82 um) and the far frame face, so its plan hop
# is shorter.  OT_KV_REACH_W = 'maxbits:um,...' (ascending); unset = no width class (legacy plans unchanged)
REACH_W = sorted((int(k), float(v)) for k, v in (t.split(':') for t in
                 __import__('os').environ.get('OT_KV_REACH_W', '').split(',') if t))


def width_reach(bits):
    for mb, um in REACH_W:
        if bits <= mb:
            return um
    return REACH_W[-1][1] if REACH_W else 1e9
RELAY_FLUSH = 128               # kv_relays.RELAY_FLUSH: reset release >= this many core cycles after the clock runs
PIN_REACH = 450.0               # qwen-1010/b: pin-to-pin register hop target (SS reach 504 um)
REACH_TARGET = 470.0            # every register-to-register segment (nearest frame points) <= this (SS reach 504 um)
# Q-KV 2026-10-16 (COORDINATOR STANDARD, owner 'close at a safe margin'): OT_KV_REACH=<um> sets every planned register hop
# limit to that value (0.9 x measured relay self-reach: rlys_296 446 um -> 400).  PIN_REACH / REACH_TARGET / RELAY_TARGET /
# HOP_REACH all clamp to it.  Default unset = the legacy 445/450/470 plan (diagnostic history only).
KV_REACH = float(__import__('os').environ.get('OT_KV_REACH', '0') or 0)
if KV_REACH > 0:
    PIN_REACH = min(PIN_REACH, KV_REACH)
    REACH_TARGET = min(REACH_TARGET, KV_REACH)
FIRST_REACH = dict(wencoded=300.0)   # v1.3: first relay of the write-queue controller's group words (ctl_bin f<g>, late launch)
RELAY_TARGET = 320.0            # placement pitch: keeps every segment (nearest frame points) under the 504 um SS reach
if KV_REACH > 0:
    RELAY_TARGET = min(RELAY_TARGET, 0.72 * KV_REACH)   # same pitch/reach ratio as 320/445
GRID = 43.2                     # relay routing grid (um)
CHAN = 129.6                    # routing / relay channel beside every column (um)
STACKS = ('WS', 'WN', 'ES', 'EN')
W = 528
FDI_UCIE = 1 + 1 + 548 + 1 + 548
FDI_SERDES = 1 + 1 + 1043 + 1 + 1043
# re-cut H control tile <-> aggregator: start, T, cyc8, q beat {valid, beat, 512 b}, exp_done, er_data, node credit
ENG_IN = 1 + 14 + 3 + 1 + 6 + 512 + 32 + 64 + 1
# er, sc, lmax, node beat tags {valid, beat, g, gam}, k/v_done, fault (the 4,096-b node data leaves from the head tiles)
ENG_OUT = 1 + 12 + 1 + 12 + 128 + 256 + 2 + 1 + 4 + 1 + 4 + 1 + 1 + 1
HEAD_NB = 1024                  # a head's slice of a node beat (HD 32 / LFB)
T_PAIR = 4 + 1024 + 12 + 1 + 6 + 512   # S1b copy to a head pair: control, row, decision word, q beat
T_E = 16                        # a head's e word
T_RET = 32 + 1 + 1              # a head's scaled score + scale fault + lane fault
ABUT = {'stack_local', 'phy_dfi', 'd2d_fdi', 'hbm_cdc', 'cdc_core'}    # abutted / band buses: no relays
RTL = dict(qkd_ctrl='qfd_ctrl element (rtl/qwen_sys/emb_hbm_20261008/ot_qwen_ctrl_pc_emb.sv + per-PC leaves; '
                    'ot_qfd_emb_pcport KVW 2: KV writes carry the HBM ECC side-band, data = the CDC completion h_cv / h_cdata; '
                    'kc: stream-command word -> ot_async_fifo -> hclk ot_qkvd_kcmd_tap chain -> the 32 ot_qwen_ctrl_pc_head cmd ports)',
           qkd_cdc='rtl/hdc/kv/ot_qwen_stream4_cdc_pc.sv ot_qwen_stream4_cdc_pc (route r11a)',
           qkd_land='qfd_kvc successor (landing crossbar) + ot_qkvd_kv_seq KV-merge slices + ot_qfd_emb_strip',
           qkd_ectl='rtl/hdc/nearhbm/ot_qwen_nearhbm_attn_stack_h.sv ot_qwen_nearhbm_ectl_h (re-cut H control tile)',
           qkd_rhead='rtl/hdc/nearhbm/ot_qwen_nearhbm_attn_stack_h.sv ot_qwen_nearhbm_head_h (re-cut H head tile, hid strap)',
           qkd_astk='rtl/hdc/nearhbm/ot_qwen_nearhbm_attn_stack_d.sv ot_qwen_nearhbm_attn_stack_d minus its engines',
           qkd_astk_n='as qkd_astk (N stacks: hub words on the S face)',
           qkd_land_n='as qkd_land (N stacks: pin plan level with the N-stack peers)',
           qkd_ctrl_n='as qkd_ctrl (N stacks: the kc stream-command port on the N face)',
           qkd_ahub='rtl/hdc/nearhbm/ot_qwen_nearhbm_attn_hub_p.sv ot_qwen_nearhbm_attn_hub_p',
           qkd_seq='rtl/qwen_sys/kv_die_20261009/ot_qkvd_kv_seq.sv ot_qkvd_kv_seq',
           qkd_d2d='rtl/qwen_sys/kv_die_20261009/ot_qkvd_kv_end.sv ot_qkvd_kv_end (ot_qkvd_d2d NT 3 / NR 4)',
           qkd_embgw='rtl/qwen_sys/emb_hbm_20261008/ot_qfd_emb_gw.sv ot_qfd_emb_gw',
           qkd_host='qfd_io_host successor (ingest stream: hing_qfd) + SerDes adapter ot_qfd_link_adapter',
           qkd_pll='vendor PLL abstract + ot_qwen_sys_rst_seq (ASSUMED frame)')


# die port -> RTL ports of the bound module (strict_ports: every RTL port is in exactly one die port or is classed)
BINDINGS = dict(
    qkd_ectl=dict(module='ot_qwen_nearhbm_ectl_h', file='rtl/hdc/nearhbm/ot_qwen_nearhbm_attn_stack_h.sv',
                  ports=dict(si=['start_in', 'T_in', 'cyc8_in', 'q_valid_in', 'q_beat_in', 'q_data_in', 'exp_done',
                                 'er_data', 'nb_cr'],
                             so=['er_valid', 'er_addr', 'sc_valid', 'sc_addr', 'sc_data', 'lmax', 'lmax_any', 'nb_valid',
                                 'nb_beat', 'nb_g', 'nb_gam', 'k_done', 'v_done', 'fault'],
                             rq=['req_valid', 'req_v', 'req_g', 'req_t'], rs=['rsp_valid_in', 'rsp_data_in'],
                             t0=['t0_c', 't0_row', 't0_lt', 't0_qv', 't0_qb', 't0_qd'],
                             t1=['t1_c', 't1_row', 't1_lt', 't1_qv', 't1_qb', 't1_qd'],
                             e0=['t0_e'], e2=['t1_e'], s0=['ts0_sc', 'ts0_sf', 'ts0_gf'], s2=['ts1_sc', 'ts1_sf', 'ts1_gf'],
                             ck=['clk'], rst_n=['rst_n']),
                  sliced=dict(e1='e0', e3='e2', s1='s0', s3='s2'),
                  classed={'ev_k_first': 'debug', 'ev_v_first': 'debug'}),
    qkd_rhead=dict(module='ot_qwen_nearhbm_head_h', file='rtl/hdc/nearhbm/ot_qwen_nearhbm_attn_stack_h.sv',
                   ports=dict(ti=['c_in', 'row_in', 'lt_in', 'q_valid_in', 'q_beat_in', 'q_data_in'], e=['e_in'],
                              s=['sc_d', 'sc_f', 'g_f'], nb=['nb_d'], ck=['clk'], rst_n=['rst_n']),
                   classed={'hid': 'by_design: die-top strap (tie cells), the head index of this tile'}),
    qkd_ahub=dict(module='ot_qwen_nearhbm_attn_hub_p', file='rtl/hdc/nearhbm/ot_qwen_nearhbm_attn_hub_p.sv',
                  ports=dict(ap_WS=['si_valid', 'si_type', 'si_g', 'si_hh', 'si_k', 'si_any', 'si_data', 'pi_valid',
                                    'pi_g', 'pi_beat', 'pi_data'],
                             am_WS=['mo_valid', 'mo_g', 'mo_hh', 'mo_data'],
                             ao=['out_valid', 'out_g', 'out_beat', 'out_data'], hs=['start'], hf=['fault'],
                             ck=['clk'], rst_n=['rst_n']),
                  sliced=dict(ap_WN='ap_WS', ap_ES='ap_WS', ap_EN='ap_WS', am_WN='am_WS', am_ES='am_WS', am_EN='am_WS'),
                  classed={'ev': 'debug', 'native_reciprocal': 'debug: native-service observation output (unread on the die)',
                           'native_rz_ok': 'debug: native-service observation output (unread on the die)'}),
    qkd_seq=dict(module='ot_qkvd_kv_seq', file='rtl/qwen_sys/kv_die_20261009/ot_qkvd_kv_seq.sv',
                 ports=dict(rf=['c_v', 'c_d', 'c_cr'], tf=['u_v', 'u_d', 'u_cr'],
                            aq_WS=['a_start', 'a_T', 'a_layer', 'a_q_valid', 'a_q_beat', 'a_q_data'],
                            ar=['a_out_valid', 'a_out_g', 'a_out_beat', 'a_out_data'], hf=['a_hub_fault'],
                            af_WS=['a_stk_fault'], mf_WS=['m_fault'],
                            kvn_WS=['kvw_v', 'kvw_vg', 'kvw_t', 'kvw_layer', 'kvw_d', 'kvw_cr'], kc_WS=['kc_v', 'kc_d'],
                            gq=['emb_req_v', 'emb_req_d', 'emb_req_cr'], gr=['emb_q_v', 'emb_q_d', 'emb_q_cr'],
                            hc=['hc_v', 'hc_d', 'hc_cr'], tk=['tok_v', 'tok_d', 'tok_cr'], hs=['a_start'],
                            d2df=['d2d_fault', 'd2d_cause'], kst=['fault', 'fault_cause'], ck=['clk'], rst_n=['rst_n']),
                 sliced=dict(aq_WN='aq_WS', aq_ES='aq_WS', aq_EN='aq_WS', af_WN='af_WS', af_ES='af_WS', af_EN='af_WS',
                             mf_WN='mf_WS', mf_ES='mf_WS', mf_EN='mf_WS', kvn_WN='kvn_WS', kvn_ES='kvn_WS',
                             kvn_EN='kvn_WS', kc_WN='kc_WS', kc_ES='kc_WS', kc_EN='kc_WS'),
                 classed={}),
    qkd_d2d=dict(module='ot_qkvd_kv_end', file='rtl/qwen_sys/kv_die_20261009/ot_qkvd_kv_end.sv',
                 ports=dict(rf=['r_v', 'r_d', 'r_cr'], tf=['t_v', 't_d', 't_cr'],
                            fdi=['tx_up', 'tx_v', 'tx_flit', 'rx_v', 'rx_flit'], flt=['fault', 'fault_cause'],
                            ck=['clk'], rst_n=['rst_n']),
                 classed={}),
)
# qwen-split/kvsys 2026-10-14 (owner 06:45 PT: Qwen two-die split, compute die + KV/SYSTEM die): build(split=True) is the
# KV/system die v1 (contract results/arch/qwen_split_1014/CONTRACT_KVSYS.md, link results/arch/qwen_split_1014/LINK.md):
#   - the head slot is the CLOSED hierarchical head cluster ot_qwen_nearhbm_head_hs 734.4 x 855.36 (route qkh_head_hs_ref-q13b);
#     the engine column (4 heads + ectl) grows to 3,551 um and the stack group to 14.3 mm, so each stack band (PHY / ctrl /
#     CDC / landing, 12.1 mm) is centred on a 14.3-mm stack pitch and the die grows N-S (both long edges stay HBM shoreline)
#   - the N-edge centre column ends the die link: ucie (UCIe x64 macro) | qkd_d2d (ot_qkvd_kv_end SPL 1, 777.6 x 518.4 kit
#     qkd_d2d_p2_ref) | qkd_lnk (ot_qkvd_split_kvlink, abutted) and the sequencer qkd_seq (merged-die cluster, 604.8 x 475.2)
#     talks to qkd_lnk on lx / lr (x3 / sd / kvd in, ar / ds / pw out) instead of the old rf / tf words
#   - qkd_embgw = the closed view outline 172.8 x 216; its SU face (EMBQ / EMBD) ends on qkd_lnk (gq / gr)
#   - qkd_ahub = the hard-reciprocal hub kit outline 1175.04 x 760.32 (qkd_ahub_ref-q13b)
SPLIT_HEAD = (734.4, 855.36)
# kvsys contract v1.1 (2026-10-14 PM, die lead): the head is the NATIVE wires-only parent ot_qkh_head_native (Codex decision
# 09:04: 16 closed lane8 + ktree stand; front / 16 stations / score are new hardened leaves; 35 separate child clock entries).
# Its slot is re-cut SHORT so the far head of each pair is one head height + 2.16 from its control tile with the bits
# x-aligned: 492.48 + 2 x 2.16 = 496.8 um <= 500 (no die relay, no latency change).  1080 x 492.48: a 3 x 6 lane_b grid
# (129.6^2, column pitch 172.8, row pitch 151.2, rows from y 54) + the front band (y 0..54, front 648 x 21.6 under the
# control tile's t span) + 16 stations (<= 32.4 x 32.4) in the 43.2 column gaps + ktree (cell + gap = 172.8 >= 151.2) and
# score in the two free cells (top margin 6.48): 0.5319 mm2 for ~0.31 mm2 of leaves.  Die-assigned pins are mirror-legal (horizontal faces M4
# only, vertical faces M5 only, clocks M4 W face), so heads below the control tile are MX and face it with their input
# face again (TP4 orientation rule); the control tile is centred in the wider column.
SPLIT_HEAD_V11 = (1080.0, 492.48)
# per-child clock entries (die ports, each its own CTS sink, delivered at phi - R of that child): die port -> RTL port
# head r2 (d7c8b1909, kvsys-elements 11:39): the lane station is split into stin (front -> lane) and stout (lane -> ktree /
# astk) leaves, each its own root: 51 entries = front, ktree, score, 16 stin, 16 stout, 16 lane8
HEAD_CLK_R2 = (['ck_f', 'ck_k', 'ck_s'] + [f'ck_i{i}' for i in range(16)] + [f'ck_o{i}' for i in range(16)] +
               [f'ck_l{i}' for i in range(16)])
# v1.2: head r4 (Codex, main b5103f681 / plan results/arch/qwen_split_1014/head_native_r4_codex_1014/plan.json): the front
# is four row-quarter leaves and every lane has stin | stk (KP D2) | nb1 | nb2 (NB D2 as two D1 leaves) + its lane8:
# 86 entries = 4 front + ktree + score + 16 x (stin, stk, nb1, nb2, lane); same data ports / cycles as r2 (exact head
# reference PASS 3,515, mutants FAIL).  Die port -> RTL: ck_f<q> -> ck_front[q], ck_k -> ck_kt, ck_s -> ck_score,
# ck_i<l> -> ck_stin[l], ck_t<l> -> ck_stk[l], ck_a<l> -> ck_nb1[l], ck_b<l> -> ck_nb2[l], ck_l<l> -> ck_lane[l]
HEAD_R4_PLAN = 'results/arch/qwen_split_1014/head_native_r4_codex_1014/plan.json'
if REACH_FIX:
    HEAD_R4_PLAN = 'results/arch/qwen_kv_die/head_reach400/head_r4_plan.json'
# v1.4.3 G3S2 (KV die lead 2026-10-15, results/arch/qwen_split_1014/kvsys_v1_4_3_design/design.json): every head's ingress
# ECTL t/e -> G -> T1 -> T2 -> fronts on the CLOSED qkh_head_gather_stage (die master qkd_hgs, 324 x 21.6, S->N), score
# head -> S1 -> S2 -> ECTL on the CLOSED qkh_head_sstage (qkd_hss, 21.6 x 21.6, W->E): +3 / +2 edges (ECTL HXK 5).  The
# near head of each pair (h1 / h2) is qkd_rhead_ft = r4 + the FAR head's T1 / S2 in a feed-through channel (plan
# HEAD_FT_PLAN, lane rows >= 1 moved up 16.2 um); near-pair stages sit in a band on each ECTL face, the far head's T2 / S1
# in a band between the near and the far head.  Groups keep their v1.4.2 bottom and grow up (N stacks into the top slack,
# S stacks into the middle): die outline unchanged.
V143 = dict(on=False)
HEAD_FT_PLAN = 'results/arch/qwen_split_1014/kvsys_v1_4_3_design/head_ft_plan.json'
if REACH_FIX:
    HEAD_FT_PLAN = 'results/arch/qwen_kv_die/head_reach400/head_ft_plan.json'
SPLIT_HEAD_FT = (1080.0, 508.68)
# v1.4.3b (owner rule 20:45, visual inspection of v1.4.3: 6.48-um slivers between stacked stage rows, one 324-um column
# carrying every word): rows at 43.2 pitch (21.6-um gaps >= the 20-um sliver rule), T1n moved off the G column
# OT_KV_V143B=1 selects it; default = v1.4.3 as run in kvs9-v143 (28.08 pitch, 6.48-um gaps, T1n in the G column).
# v1.4.3b status 2026-10-15 21:00: the +2.18 mm/stack it needs does not fit the relay allocator in any tried anchoring
# (middle closes: no route astk_WN -> seq; top apron: HOST tree corners at y ~24.0 mm; taller pitch 432-864: slice chains
# corner at x 1501) -> needs a smaller band (T1n into the near head's channel) or a die height step with the HOST apron.
V143B = __import__('os').environ.get('OT_KV_V143B', '0') == '1'
# v1.4.3c (Q-KVSYS-DIE 2026-10-15 22:50, OT_KV_V143C=1): SIDE-BY-SIDE band.  The two G stages of a pair sit next to each
# other in ONE row under the ECTL (G_near x 54, G_far x 405: 27-um gap), T1n | T2n | S1n | S2n in a second row (T1n at the
# head column's edge x -216, T2n 135, S1n 480.6, S2n 540), rows at 43.2 pitch = 21.6-um gaps everywhere (>= the 20-um
# sliver rule) and the band SHRINKS (2 rows instead of 4: 111.24 / 108.0 vs 119.88 / 118.8; LO keeps the 1.08 GY residue).  The words no longer stack
# in one 324-um column (window screen hot spots of v1.4.3: tp x2 + tg in the G column).  Measured matched-bit worst hops
# (actual closed LEF pins, tools/qwen_kv_die/v143_feasibility.py primitives): ECTL->G_n 469.3, ECTL->G_f 479.2,
# G_n->T1n 291.6, T1n->T2n 372.6, T2n->near fronts 479.6, G_f->T1f 432.0, score->S1n 215.7, S1n->S2n 37.1, S2n->ECTL 110.9
# (all <= 500; v1.4.3: 285.9 / 314.0 / 34.6 / 125.3 / 436.4 / 337.0).  Far T2f / S1f band (5.4-um gaps) unchanged.
V143C = __import__('os').environ.get('OT_KV_V143C', '0') == '1'
# v1.4.3d (Q-KVSYS-HOP 2026-10-16, OT_KV_V143D=1, needs OT_KV_V143C=1): THREE-ROW band (one more 43.2-um row a side).
# kvs11-v143c TT failed real->real on the G3S2 stage hops (ECTL a/b -> G multicast -72.45 / -47.99, G_far -> FT -60.78 /
# -42.59, T2 -> front q -51.55, T1 -> T2 -14.16; 6,983 violators): in two rows no placement gets every hop under the
# calibrated realized reach (exhaustive search over all four 324-um stages x 10.8-um x / row on the realized kvs11 pins
# and bit order: best = 481 um 2-pin, 307 um ECTL-multicast HPWL).  Three rows: worst 2-pin 367 um (T2 -> front),
# G_far -> FT 259, G_near -> T1 356, ECTL -> {G_n, G_f} HPWL 200 (kvs11: 524 / 524 / 292 / 372).  Same leaves, same
# cycles; the band grows 43.2 um a side.  Search: results/arch/qwen_kv_hop_1016.
V143D = V143C and __import__('os').environ.get('OT_KV_V143D', '0') == '1'
V143_ROW = 43.2 if (V143B or V143C) else 28.08
V143_GAP = 21.6 if (V143B or V143C) else 6.48
V143_BAND_LO, V143_BAND_HI = (195.48, 194.4) if V143B else ((111.24, 108.0) if V143C else (119.88, 118.8))
if V143D:
    V143_BAND_LO, V143_BAND_HI = V143_BAND_LO + V143_ROW, V143_BAND_HI + V143_ROW
V143_NF_LO, V143_NF_HI = (64.8, 65.88) if V143B else (32.4, 33.48)
V143_X = (dict(g=226.8, t1n=-54.0, t2n=108.0, t2f=108.0, s1n=486.0, s2n=556.2, s1f=486.0) if V143B else
          dict(g=226.8, t1n=226.8, t2n=108.0, t2f=108.0, s1n=437.4, s2n=556.2, s1f=437.4))   # ECTL-local x (R0 ECTL)
V143_CENTER = __import__('os').environ.get('OT_KV_V143_CENTER', '0') == '1'   # 1: v1.4.2 centring (the die grows)
V143_N_UP = float(__import__('os').environ.get('OT_KV_V143_NUP', '1404.0'))                             # N groups' top may rise this far into the empty top (the rest grows down)
V143_FT = dict(ftg=(356.4, 191.7), fts=(685.8, 191.7))                                       # near head-local (R0)
HGS, HSS = (324.0, 21.6), (21.6, 21.6)
# ---- v1.4.4 (Q-KVSYS-PV 2026-10-16, OT_KV_V144=1 on top of OT_KV_V143C=1): the PV16 WIDE PAIRS (owner 10-15: PV 16
# rows/cycle, KV die +8.3 mm2 approved).  Two wires-only groups ot_qwen_tp8_pv_wide_pair (PAIR 0 = WS+ES, PAIR 1 = WN+EN)
# whose 289 children (256 x ot_qwen_tp8_pv_slice_t, 32 x ot_qwen_tp8_pv_join_t, 1 x ot_qwen_tp8_pv_wide_ctl) are placed
# BY THE DIE (kv_expand) from their CLOSED views (qkd_pv_slice r4, qkd_pv_join r4, qkd_pv_ctl_rstpin_r5); every leaf port
# is registered at its pin (RTL).  Envelope per pair = the matched-pin column array of the element owner's screen
# (659a1f1fd: 3 x 3 column block, join centre, 21.6-um gaps, 561.6-um square, worst matched-bit Manhattan 248.76 um;
# 2 x 16 blocks = 1,144.8 x 9,309.6) + a 21.6 gap + one CONTROL / COLLECTION STRIP of 216 um (the 43.2-um control tile and
# the roots of the command / start / reset distribution and the column-flag collection; the trunks' stations sit in the
# two 259.2-um side relay channels, PV_TREE below).  Centred in the 1,693.46-um centre column: >= 259.2 relay channel on
# both sides.  The frames are hard keep-outs for the relay allocator (no relay frame inside an envelope).
V144 = __import__('os').environ.get('OT_KV_V144', '0') == '1'
# KVDIE 2026-10-16 (kvs13d, coordinator): OT_KV_V144_R6=1 binds the CLOSED qkd_pv16_vport r6 (DQ 0 / RT 8; the V word's epoch
# travels with it: in<g>_epoch -> out_epoch -> the pair's in_epoch[16k +: 16]) behind the epoch-carrying pair face
# qkd_pvw_die_e, and EQUALISES the die relay edges W = WP + O of all 16 ports to OT_KV_PV_W (default 59, the r6 bench's
# measured W) by extra registered stages on the 15-bit request word (cheapest side) -> RL = 4 + W + DQ + RT, pair
# FIRST_INPUT_AGE = RL + 1 (OT_KV_PV_AGE overrides the pair parameter; default = the bound ctl view's 20 until a closed
# FIRST_INPUT_AGE = RL + 1 ctl view exists -- recorded in plan pv144.vport_timing.age).
V144_R6 = V144 and __import__('os').environ.get('OT_KV_V144_R6', '0') == '1'
PV_W = int(__import__('os').environ.get('OT_KV_PV_W', '59'))
PV_AGE = int(__import__('os').environ.get('OT_KV_PV_AGE', '20'))
# KVDIE 2026-10-16 kvs13e (Q-KVSYS lead: the 2,089-b host_fdi d2d_kv/host -> S-edge SerDes ran 33.5 mm, 70.7 Mbit.um):
# OT_KV_SERDES_N=1 puts the host SerDes PHY on the N edge beside the HOST root (east of the PLL, W-face FDI pins facing
# the root), so the FDI is local; the S band it leaves goes to the south PV pair.  OT_KV_PV_PINY=1 puts each PV pair's
# vin<k> / vrq<k> face pins level with V port k's home (not all at the array middle).
SERDES_N = __import__('os').environ.get('OT_KV_SERDES_N', '0') == '1'
PV_PINY = __import__('os').environ.get('OT_KV_PV_PINY', '0') == '1'
# 'ahub' (default): the attention hub moves SOUTH by the north shortfall (rounded up to the 43.2-um band lattice) while the
# south envelope still fits; any remainder grows the die height (north band = embgw and everything above it rises).
# 'grow': the hub stays, the die height grows by the whole shortfall (the coordinator's decision-2 baseline).
V144_MODE = __import__('os').environ.get('OT_KV_V144_MODE', 'ahub')
# centre-column widening (um, a multiple of 2 x 43.2): the relay traffic of the old 1,145-um spine (688 relays: HOST slice
# chains, S-stack af / mf / aq / kc / emf / emr, ares / hs / hf, the SerDes FDI) moves into the two side channels
V144_DW = float(__import__('os').environ.get('OT_KV_V144_DW', '0'))
SN_LIFT = float(__import__('os').environ.get('OT_KV_SN_LIFT', '0'))
CTL_BAND = float(__import__('os').environ.get('OT_KV_CTL_BAND', '0'))
if CTL_BAND and abs(CTL_BAND / 43.2 - round(CTL_BAND / 43.2)) > 1e-6:
    raise ValueError(f'OT_KV_CTL_BAND={CTL_BAND}: must be a multiple of 43.2 um')
if SN_LIFT and abs(SN_LIFT / 43.2 - round(SN_LIFT / 43.2)) > 1e-6:
    raise ValueError(f'OT_KV_SN_LIFT={SN_LIFT}: must be a multiple of 43.2 um (band lattice)')
# free relay apron between the north envelope's top and the gateway / sequencer / HOST band (the chains leaving the
# north band fan out there before entering the side channels; v1.4.4 trial without it cornered the HOST trees)
V144_APRON = float(__import__('os').environ.get('OT_KV_V144_APRON', '0'))
V144_AHUB_MAX = float(__import__('os').environ.get('OT_KV_V144_AHUB_MAX', '1e9'))   # cap on the hub's south shift
PV_TILE, PV_GAP, PV_CTL = 172.8, 21.6, 43.2
PV_BLK = 3 * PV_TILE + 2 * PV_GAP                 # 561.6: one column = 8 slices around its join
PV_ARR = (2 * PV_BLK + PV_GAP, 16 * PV_BLK + 15 * PV_GAP)   # 1,144.8 x 9,309.6
# control strip: the 43.2-um control tile + 21.6-um clearances (the command / start / reset trunks and the column-flag
# collection run in the side relay channels, PV_TREE); OT_KV_V144_STRIP overrides (the 10-16 WIP reserved 216)
PV_STRIP = float(__import__('os').environ.get('OT_KV_V144_STRIP', '86.4'))
PVW = (PV_ARR[0], round(PV_ARR[1] + PV_GAP + PV_STRIP, 6))   # 1,144.8 x 9,547.2
# KVPLAN 1815 (OT_KV_PV_T=1, needs OT_KV_V144_R6=1; Q-KV 10-16 ack +68 mm2): the TRUNKED PV16 pair successor qkd_pvw_die_t
# (tools/qwen_kv_die/pv_trunk_gen.py): every in-pair wire inside reach by registered relay-standard stations.  The V word of
# port k reaches the pair as a 31-b header vh<k> (-> the control tile at the strip) and eight 128-b chunks vc<k>_<g>, each
# entering the W (ports 0-3) / E (ports 4-7) face at its GS group's middle channel; chunk g must arrive DELTA_g die relay
# edges after its header (padded here).  Frame size / face pins / leaf homes: the generator's plan.json.
PV_T = __import__('os').environ.get('OT_KV_PV_T', '0') == '1'
PVFORK = (108.0, 58.32)          # qkd_pvfork frame: 4 x qkd_rlys_296 in a row (+ 4.32-um halos)
PVFORK_GAP = float(__import__('os').environ.get('OT_KV_PVFORK_GAP', '21.6'))   # fork <-> pair face
# KVPLAN2 2215 (kvs13l plan: 32 chunk chains a side channel, each padded to header + DELTA_g by die relays at ~200-um pitch,
# filled the side channels: no first stage at the forks): the eight 128-b chunks of a port travel as ONE trunk down the pair
# face and TAP off at their GS group -- qkd_pvtap<G> (wires-only: one register stage of closed qkd_rlys_296 replicas) beside
# group G's face pins takes chunks 0..G, hands chunk G to the face (tc, no die relay) and forwards chunks 0..G-1 (to).  The
# DELTA steps (6 edges a group, 1,468.8 um) are the trunk's own stages (5 relays + the tap: 245-um hops); the fork sits
# level with its header pin (pvh 0 stages).  Face pins of the four ports of a group / the header pins: PVT_PIN_DY apart
# (one tap / fork height 58.32 + the 21.6-um clearance).
PVT_PIN_DY = 80.0
PVT_HDR_Y0 = 160.0
PVT_SOFT_SLACK = int(__import__('os').environ.get('OT_KV_PVT_SOFT_SLACK', '1'))   # trunk runs aim this many stages under their share
PVT_FORK_PITCH = float(__import__('os').environ.get('OT_KV_PVT_FORK_PITCH', '80'))   # fork k -> k + 1 at the strip end
# KVPLAN2 2215 WIP (OT_KV_PVT_HDR_CTL=1, off by default: plan-only trials still fail in the fork / tap column): the header /
# request words end on the control tile u_ctl (the kvs13l2 case measured 1.1-1.5-mm unrelayed hops from the side-face pins to
# the tile inside the wires-only frame) through a PVT_HUB_CLEAR relay channel between the hub and the strip
PVT_HDR_CTL = __import__('os').environ.get('OT_KV_PVT_HDR_CTL', '0') == '1'
# KVPLAN3 0230 (OT_KV_PVT_PINS=1; kvs13l3 flags' final plan: pin repair added 64 relays on pvin / pvta / pvtb / pvc ->
# W 59..75, 64 chunks off header + DELTA_g): every fork / tap of one master took its pin faces from ONE instance (the
# masters() auto-pin rule), so an E-side tap had tc on the face AWAY from its pair and an N-pair tap ti / to reversed, and
# the planner measured those ends to the frame's nearest point (401-457-um hops after drawing).  With this flag the forks /
# taps are oriented by side (W: R0 / E: MY; S pair as is, N pair + MX), their ports drawn on fixed canonical faces
# (PVT_PORTS: fraction along the face) and the planner aims at exactly those pins from the first pass.
PVT_PINS = __import__('os').environ.get('OT_KV_PVT_PINS', '0') == '1'
PVT_PORTS = dict(qkd_pvfork=dict(vi=('W', 0.5), vh=('N', 0.5), vta=('S', 0.3), vtb=('S', 0.7)),
                 qkd_pvtap=dict(ti=('N', 0.5), to=('S', 0.5), tc=('E', 0.5)))


def pvt_port(master, port):
    """OT_KV_PVT_PINS: (face, fraction) of a fork / tap port in its canonical (W side, S pair = R0) frame, else None"""
    if not PVT_PINS:
        return None
    k_ = 'qkd_pvtap' if master.startswith('qkd_pvtap') else master
    return PVT_PORTS.get(k_, {}).get(port.lstrip('*'))


def pvt_orient(st):
    return {('W', 'S'): 'R0', ('E', 'S'): 'MY', ('W', 'N'): 'MX', ('E', 'N'): 'R180'}[(st[0], st[1])] if PVT_PINS else 'R0'


def pvt_port_xy(it, port):
    """die point of a fork / tap port under OT_KV_PVT_PINS (the drawn word centre, orientation applied)"""
    fp_ = pvt_port(it.master, port)
    if fp_ is None:
        return None
    f_, fr_ = fp_
    x_, y_ = {'E': (it.w, fr_ * it.h), 'W': (0.0, fr_ * it.h), 'N': (fr_ * it.w, it.h), 'S': (fr_ * it.w, 0.0)}[f_]
    if it.orient in ('MY', 'R180'):
        x_ = it.w - x_
    if it.orient in ('MX', 'R180'):
        y_ = it.h - y_
    return (it.x + x_, it.y + y_)
PVT_HUB_CLEAR = float(__import__('os').environ.get('OT_KV_PVT_HUB_CLEAR', '86.4')) if PVT_HDR_CTL else 21.6


def pvt_hdr_pin(k):
    """canonical (R0) frame point of port k's header / request word: the control tile's N edge, ports 17.28 um apart"""
    c_ = pvt_plan()['cells']['u_ctl']
    return (round(c_[1] + c_[3] / 2 + (k - 3.5) * 17.28, 3), round(c_[2] + c_[4], 3))
PVT_XLANE = __import__('os').environ.get('OT_KV_PVT_XLANE', '1') == '1'   # S <-> N express words on outer side-channel lanes
PVT_OFFS = int(__import__('os').environ.get('OT_KV_PVT_OFFS', '8'))   # PV trunk / chunk stage spot search radius (grid cells)
PVT_A_LANE0 = int(__import__('os').environ.get('OT_KV_PVT_A_LANE0', '2'))   # trunk A's first lane
PVT_ORD = float(__import__('os').environ.get('OT_KV_PVT_ORD', '1'))   # +1: port 0's face pins / taps highest in a group
PVT_TAP_DY = float(__import__('os').environ.get('OT_KV_PVT_TAP_DY', '0'))   # taps level with their face pins (h4 plan); > 0 moves them away from the strip
PVT_LANE = float(__import__('os').environ.get('OT_KV_PVT_LANE', '43.2'))   # a multiple of the 21.6 routing grid: lanes on cell centres   # trunk lane pitch beside the tap column


# two 512-b trunks a port (each relay stage ONE replica: a W-in / E-out stage on a vertical run gives up its width per hop,
# and a 6-edge group step of 1,468.8 um leaves 245 um + width of the 340-um wide-word reach): trunk B = chunks 4..7 (taps at
# groups 7, 6, 5; chunk 4 from tap 5's forward word), trunk A = chunks 0..3 (taps at 3, 2, 1; chunk 0 from tap 1's)
PVT_TAPS = {7: 'b', 6: 'b', 5: 'b', 3: 'a', 2: 'a', 1: 'a'}
PVT_LO = dict(a=0, b=4)


def pvtap_n(g):
    """chunks a tap at group g receives (its own + the lower ones of its trunk)"""
    return g - PVT_LO[PVT_TAPS[g]] + 1


def pvtap_frame(g):
    n_ = -(-128 * pvtap_n(g) // 296)          # qkd_rlys_296 replicas
    return (round(4.32 + 25.92 * n_, 4), PVFORK[1])


def pvt_exact(bid, stages):
    """KVPLAN2 2215: die relay stages a chunk's face hop (tap.tc / tap.to -> the pair's face pin) must have so chunk g
    lands header + DELTA_g edges after the header (each tap one edge).  The trunk runs (fork -> top tap, tap -> tap) aim one
    stage under their share (pvt_soft: a crowded run that made one stage more than owed failed exactness); whatever the
    trunk to chunk g's tap is short of header + DELTA_g is made up on the chunk's own face hop."""
    D_ = {int(k_): v_ for k_, v_ in pvt_plan()['chunk_delta_vs_header'].items()}
    st_, k_, g_ = bid.split('_')[1], bid.split('_')[2], int(bid.split('_')[3])
    sk_ = f'{st_}_{k_}'
    if bid.startswith(('pvta_', 'pvtb_')):
        return None                  # trunk runs: soft targets (pvt_soft), never an exact count
    tr_, top_ = ('a', 3) if g_ <= 3 else ('b', 7)
    run_ = sum(stages[f'pvt{tr_}_{sk_}_{j_}'] + 1 for j_ in range(top_, max(g_, top_ - 2) - 1, -1))
    need_ = stages[f'pvh_{sk_}'] + D_[g_] - run_
    if need_ < 0:
        raise ValueError(f'kv die PV_T: chunk {sk_}_{g_} trunk {run_} edges > header + DELTA_g {stages[f"pvh_{sk_}"] + D_[g_]}')
    return need_


PV_T_PLAN = 'results/arch/qwen_kv_die/pv_trunk_t/plan.json'
# KVR-VIEWS 10-19 (OT_KV_RS_HD = auto | r | f, tools/qwen_kv_die/rs_hd_select.py): the pair's result-trunk header.  auto binds
# qkd_pv_rs_hd_f rev f2 (qkd_pvw_die_t_f.sv, RS_D 50: rs_* consumers +1 edge = PV_RS_D_DELTA) only once its CLOSED view
# carries a committed native PASS receipt; until then qkd_pv_rs_hd_r (RS_D 49, CLOSED native FAIL) stays the stand-in.
PV_RS_HD = None
if PV_T:
    import importlib.util as _ilu
    _rsh_spec = _ilu.spec_from_file_location('rs_hd_select', Path(__file__).resolve().parent / 'rs_hd_select.py')
    _RSH = _ilu.module_from_spec(_rsh_spec)
    _rsh_spec.loader.exec_module(_RSH)
    PV_RS_HD = _RSH.select()
    if PV_RS_HD['rs_hd'] == 'f':
        PV_T_PLAN = 'results/arch/qwen_kv_die/pv_trunk_t/plan_f.json'
        print(f"kv_die: OT_KV_RS_HD -> qkd_pv_rs_hd_f ({PV_RS_HD['why']}): RS_D {PV_RS_HD['rs_d']}, every rs_* consumer "
              f"(pvfin p0/p1 ages, token-pass schedule) must take +{PV_RS_HD['rs_d_delta']} edge (kv_die.PV_RS_D_DELTA)", file=sys.stderr)
PV_T_FILE = PV_RS_HD['file'] if PV_RS_HD else 'rtl/qwen_sys/split_20261014/qkd_pvw_die_t.sv'
PV_RS_D_DELTA = PV_RS_HD['rs_d_delta'] if PV_RS_HD else 0
_PVT = {}


def pvt_plan():
    if not _PVT:
        _PVT.update(json.loads((Path(__file__).resolve().parents[2] / PV_T_PLAN).read_text()))
    return _PVT


if PV_T:
    PVW = tuple(pvt_plan()['frame_um'])
# KV-RTRUNK 10-17: the trunked pair's plan carries the 512-b result trunks (pv_trunk_gen default): port bundle pr (534 b)
PV_RS = PV_T and 'result_trunk' in pvt_plan()
PV_CLEAR = 21.6                                   # envelope <-> hub / gateway / SerDes clearance (sliver rule >= 20 um)
PV_GRANT_Y0 = 1844.346                            # pv_wide_grant.json pvw_0 (kept when the full height fits under the hub)
# element owner screen (results/arch/qwen_attention_rate_1015/pv_parent_2330/screen.json, gap 21.6): bank l -> (x, y, orient)
# kvs13g REAL CASE FAIL (10-16 14:49): ot_mts 'ot_qwen_tp8_pv_slice_t R180 x has no legal origin on this track grid' --
# the closed slice view's pins are not track-legal under an X flip, so no bank may use MY / R180 (bank 3 R180 -> MX,
# bank 6 MY -> R0; same homes, y-flip only, as banks 2/4/5 already are).
PV_BANK = {0: (0.0, 0.0, 'R0'), 1: (194.4, 0.0, 'R0'), 2: (0.0, 194.4, 'MX'), 3: (0.0, 388.8, 'MX'),
           4: (194.4, 388.8, 'MX'), 5: (388.8, 388.8, 'MX'), 6: (388.8, 0.0, 'R0'), 7: (388.8, 194.4, 'R0')}
PV_JOIN = (194.4, 194.4, 'R0')
V144S = dict(resolved=False, grow=0.0, ahub_dy=0.0)
# Q-VMWB 2026-10-16 (main 551d29b2c): the 16 V ports qkd_pv16_vport (86.4 x 172.8, pin-registered, CLOSED kit
# qkd_pv16_vport_r1; static 2:1 select of the return rings of landing groups {k, 0} / {k, 1}).  Homes (die lead): the 4
# ports of a stack in the landing-inner relay channel (landing | engine group, 343.7 um) at the group end that faces the
# S|N corridor (S stacks: top, N stacks: bottom), port k nearest the corridor last -> the V words leave on the corridor
# toward the side channel of the centre column.  Reserved as relay KEEP-OUTS now; instantiated (and wired ring -> port ->
# pair) once Q-VMWB's landing ring faces and pin file land (OT_KV_V144_VPORT_PINS = that file).
PV_VPORT = (86.4, 172.8)
PVW_CLK = [f'ck_c{s}' for s in range(33)]        # die port ck_c<s> -> col_clk[s] (s = 32: the control tile)


def pv_col_rc(s):
    """column s = 8 H + GS (head H, dims 16 GS..16 GS+15) -> (block column c, block row r) of the 2 x 16 array: the four
    columns of one GS (they share its 8 x 128-b V chunks) form one 2 x 2 group, the eight of one head H share e[H]"""
    h_, gs_ = divmod(s, 8)
    return h_ & 1, 2 * gs_ + (h_ >> 1)


def pv_plan():
    """canonical (R0, strip at the top) child homes of one wires-only PV pair: yosys flattened cell name -> (x, y, w, h,
    orient).  The die places pvw_0 R0 (strip faces the hub above it) and pvw_1 MX (strip faces the hub below it)."""
    pl = {}
    for s in range(32):
        c, r_ = pv_col_rc(s)
        bx, by_ = c * (PV_BLK + PV_GAP), r_ * (PV_BLK + PV_GAP)
        for l_, (x_, y_, o_) in PV_BANK.items():
            pl[f'g_col[{s}].u_col.g_bank[{l_}].u_bank'] = (round(bx + x_, 4), round(by_ + y_, 4), PV_TILE, PV_TILE, o_)
        pl[f'g_col[{s}].u_col.u_join'] = (round(bx + PV_JOIN[0], 4), round(by_ + PV_JOIN[1], 4), PV_TILE, PV_TILE, PV_JOIN[2])
    pl['u_ctl'] = (round((PVW[0] - PV_CTL) / 2, 4), round(PV_ARR[1] + PV_GAP + (PV_STRIP - PV_CTL) / 2, 4), PV_CTL, PV_CTL, 'R0')
    return pl


def pv_tree(m):
    """the PV pair's command / start / reset distribution as a registered trunk in each side relay channel (stations
    <= PIN_REACH apart, one tap per block row), balanced to the farthest row: the depth the pair successor RTL and the
    compiler must carry (pair RTL today broadcasts cmd in ONE edge over 9.3 mm -- element-owner item)."""
    out = {}
    for it in m['insts']:
        if not it.master.startswith('qkd_pvw'):
            continue
        strip_y = it.y + (it.h - PV_STRIP / 2 if it.orient == 'R0' else PV_STRIP / 2)
        rows = []
        for r_ in range(16):
            yc = r_ * (PV_BLK + PV_GAP) + PV_BLK / 2
            yd = it.y + (yc if it.orient == 'R0' else it.h - yc)
            rows.append(abs(yd - strip_y) + PV_BLK / 2)   # trunk run + the tap across half a block
        st = [math.ceil(d_ / PIN_REACH) for d_ in rows]
        out[it.name] = dict(row_distance_um=[round(d_, 1) for d_ in rows], stations_per_row=st, balanced_depth=max(st),
                            trunks='W and E side channel, 60-b cmd + start / context / epoch + reset, one tap per block row',
                            collection='col_valid / col_fault 2 b per column back on the same trunks (depth = balanced_depth)')
    return out
def _pv_ctl_view_age():
    """kvs13d: the bound PV ctl leaf view's FIRST_INPUT_AGE (its kit spec) vs the die's pair parameter"""
    kit = __import__('os').environ.get('OT_KV_PV_CTL_KIT', 'qkd_pv_ctl_rstpin_r5')
    sp = Path(__file__).resolve().parents[2] / 'physical/ref_tile' / kit / 'spec.json'
    age = json.loads(sp.read_text())['params'].get('FIRST_INPUT_AGE') if sp.exists() else None
    return dict(kit=kit, view_age=age, die_age=PV_AGE, match=age == PV_AGE,
                status='OK' if age == PV_AGE else 'VIEW_PARAM_MISMATCH: diagnostic only until a closed ctl view at the die age')


# KVJ-F 2026-10-17 (rtl/test/qwen_static_kv/tb_static_landing_vport.sv, tools/qwen_static_kv/run_landing_vport.sh): the
# MEASURED RT of the static landing segment (qkd_static_kv_landing_seg / _seg_h) joined to qkd_pv16_vport with no relay is 9
# = the seg's vreq pin capture (1) + its VREQ latency 8; the r5/r6 contract's 'landing 8 + relays' is one edge short (RT 8
# faults every slot).  With r relay stages on the V get + rsp words: RT = VPORT_RT_SEG + r.
VPORT_RT_SEG = 9


def pv_vport_timing(m):
    """measured relay edges of every V port's die words (Q-VMWB r5 contract: WP = pair req pin -> vport pr, RT = vport vq
    register -> rsp at its in pins = landing 8 + request + return relays, O = vport out pins -> pair vin pins; the pair sees its
    word RL = 4 + WP + DQ + RT + O edges after its request, one value for all 16 ports, DQ >= 0 the port's own wait)"""
    st_ = m.get('relay_stages', {})
    names = {i.name for i in m['insts']}
    rows = {}
    for st in STACKS:
        for k in range(4):
            vp = f'vport_{st}_{k}'
            r_ = dict(WP=st_.get(f'pvrq_{st}_{k}'),
                      O=(st_.get(f'pvin_{st}_{k}', 0) + 1 + st_.get(f'pvh_{st}_{k}', 0)) if PV_T else st_.get(f'pvin_{st}_{k}'))
            if f'slg_{st}_{2 * k}' in names:
                r_['RT'] = VPORT_RT_SEG + max(st_.get(f'pvvq_{st}_{k}_{g}', 0) + st_.get(f'pvrs_{st}_{k}_{g}', 0) for g in (0, 1))
            rows[vp] = r_
    wp_ = [r_['WP'] for r_ in rows.values() if r_['WP'] is not None]
    o_ = [r_['O'] for r_ in rows.values() if r_['O'] is not None]
    rt_ = [r_['RT'] for r_ in rows.values() if r_.get('RT') is not None] or [VPORT_RT_SEG]
    worst = max((r_['WP'] or 0) + (r_['O'] or 0) + r_.get('RT', VPORT_RT_SEG) for r_ in rows.values())
    return dict(ports=rows, WP_range=[min(wp_), max(wp_)] if wp_ else None, O_range=[min(o_), max(o_)] if o_ else None,
                RT_range=[min(rt_), max(rt_)], RT_assumed_landing_only=not any('RT' in r_ for r_ in rows.values()),
                worst_WP_plus_O_plus_RT=worst, RL_needed_DQ0=4 + worst, kit=dict(RL=19, WP=2, RT=8),
                note='all 16 ports must see the same RL: shorter ports take DQ = RL - 4 - WP - RT - O (per-port value); '
                     'the r5 kit DQ formula omits O (vport -> pair relays)',
                **(dict(r6=dict(W_target=PV_W, W=sorted({(r_['WP'] or 0) + (r_['O'] or 0) for r_ in rows.values()}),
                                W_equal=len({(r_['WP'] or 0) + (r_['O'] or 0) for r_ in rows.values()}) == 1,
                                RL=4 + PV_W + 0 + VPORT_RT_SEG, age_needed=4 + PV_W + 0 + VPORT_RT_SEG + 1, age_bound=PV_AGE,
                                age_ok=PV_AGE == 4 + PV_W + 0 + VPORT_RT_SEG + 1, ctl_view=_pv_ctl_view_age())) if V144_R6 else {}))


HEAD_CLK = ([f'ck_f{q}' for q in range(4)] + ['ck_k', 'ck_s'] +
            [f'ck_{t}{i}' for t in 'itabl' for i in range(16)])
HEAD_CLK_CHILD = dict(**{f'ck_f{q}': f'front{q}' for q in range(4)}, ck_k='ktree', ck_s='score',
                      **{f'ck_{t}{i}': f'{c}{i}' if c in ('stin', 'stk', 'lane') else f'{c}_{i}'
                         for t, c in zip('itabl', ('stin', 'stk', 'nb1', 'nb2', 'lane')) for i in range(16)})
ECTL_CLK = ['ck_a', 'ck_b', 'ck_c']
# v1.2: the attention hub is the wires-only composition ot_qkd_ahub_die (kvsys-elements 33048f31a): the CLOSED core
# (qkd_ahub_core hd2) + 13 hardened tiles (4 ot_nhb_zh, ot_qkh_recip_leaf, 4 ot_nhb_pbst, 4 ot_nhb_pvlg), each its own clock
# entry (die port -> RTL ck_core / ck_zh[i] / ck_recip / ck_pbst[i] / ck_pvlg[i]); am[143:0] = 4 registered per-stack copies
# KV-AHUB hp4 2026-10-17: ONE regional entry ck (RTL QKD_AHUB_ONE_CK; the parent's spine H-tree reaches all 14 children)
AHUB_CLK = ['ck_c']
SPLIT_FRAMES = dict(qkd_seq=(604.8, 475.2), qkd_lnk=(777.6, 129.6), qkd_embgw=(172.8, 216.0), qkd_ahub=(1175.04, 760.32))
# KV-CASE2 10-18 (OT_KV_AHUB_SDW=1, coordinator): the static hub qkd_ahub_static_dw hardened as kit qkd_ahub_sdw
# (claude/kv-ahubdw-1018 22f997d7d): die frame = the kit outline 734.4 x 561.6 (legacy hub kit 1175.04 x 760.32), its die
# pins on the kit's faces / ranges (tools/ref_tile/specs_kvahubdw/qkd_ahub_sdw.json, faces from plan m1); the freed centre
# width closes (centre_w = max(UCIE, hub, d2d) + 4 CHAN).  Open master until the kit's view exists.
AHUB_SDW = __import__('os').environ.get('OT_KV_AHUB_SDW', '0') == '1'
AHUB_SDW_SPEC = 'tools/ref_tile/specs_kvahubdw/qkd_ahub_sdw.json'
if AHUB_SDW:
    SPLIT_FRAMES['qkd_ahub'] = tuple(float(v_) for v_ in __import__('os').environ.get('OT_KV_AHUB_SDW_WH', '734.4,561.6').split(','))
# KVJ-C2 2026-10-17 (D2): the bridge successor ot_qkvd_split_kvlink_se has NO embedding gateway SU face (the boot-only
# gateway qkd_embgw_boot removed r_ea / t_ecr / t_eq): ea_* / eq_* ports, the EMBQ FIFO and the EMBD slot count are gone,
# so the gq / gr die bundles no longer exist (an EMBQ word on the KV end's r[3] class is a sticky fault)
BINDINGS['qkd_lnk'] = dict(module='ot_qkvd_split_kvlink_se', file='rtl/qwen_sys/split_20261014/ot_qkvd_split_kvlink_se.sv',
    ports=dict(rf=['r_v', 'r_d', 'r_cr'], tf=['t_v', 't_d', 't_cr'],
               # bit order = the sequencer cluster's: r_x3_d = {v, tag, d} (d at bit 0), t_ar_d = {v, d 519}
               lx=['x3_d', 'x3_tag', 'x3_v', 'sd', 'kvd', 'ar_cr'], lr=['ar_d', 'ar_v', 'ds', 'pw', 'x3_cr'],
               d2df=['d2d_fault', 'd2d_cause'], flt=['fault'],
               ck=['clk'], rst_n=['rst_n']),
    classed={})
_BASE = dict(HEAD=HEAD, ECTL=ECTL, ENG_H=ENG_H, RENG=RENG, TILE_Y=dict(TILE_Y), FRAMES=dict(FRAMES))


def _ectl_st_frame(split):
    """KV-ECTL4 10-18 (coordinator 0gs (d), 'the KV die may grow'): the ECTL slot takes the hardened frame of
    qkd_ectl3_kiss_st (physical/ref_tile/qkd_ectl3_kiss_st, 725.76 x 261.36: A k3 172.8 x 194.4 | B pg16 | C on the 43.2
    lattice) instead of the 648 x 129.6 A | B | C abutment, and its pins at the kit's exact pin plan (_split_pins).
    Default on with the static die's kiss_st binding (OT_KV_STATIC_DIE=1, OT_KV_ASTK_ST default 1); OT_KV_ECTL_ST_FRAME=0
    keeps the old slot (comparison only)."""
    d = '1' if (split and KSD.ON and KSD.ASTK_ST) else '0'
    return os.environ.get('OT_KV_ECTL_ST_FRAME', d) == '1' and split and KSD.ON and KSD.ASTK_ST


ECTL_ST = (725.76, 261.36)
ECTL_ST_PINS = 'results/arch/qwen_kv_ectl3_kiss_st_1018/qkd_ectl3_kiss_st.tcl'
# die port of qkd_ectlk -> kit pins (bases) of qkd_ectl3_kiss_st
ECTL_ST_PORTS = dict(si=['si'], so=['so'], t0=['t0'], t1=['t1'], e0=['e0'], e1=['e1'], e2=['e2'], e3=['e3'], s0=['s0'],
                     s1=['s1'], s2=['s2'], s3=['s3'], rq=['req_valid', 'req_t', 'req_v', 'req_epoch', 'req_layer'],
                     rs=['rsp_valid', 'rsp_data', 'rsp_t', 'rsp_v', 'rsp_epoch', 'rsp_layer'], kg=['kgo', 'epoch', 'layer'],
                     kf=['fault'], cfg=['cfg'], rst_n=['rst_n'], ck_a=['ck[0]'], ck_b=['ck[1]'], ck_c=['ck[2]'])


def _ectl_st_ports():
    """{die port: ('face', bits, face, layer, centre along the face, pitch tracks)} from the kit's exact io_tcl"""
    pins = {}
    for ln in (ROOT / ECTL_ST_PINS).read_text().splitlines():
        mt = re.match(r'place_pin -pin_name \{(\S+)\} -layer (\S+) -location \{([\d.]+) ([\d.]+)\}', ln)
        if not mt:
            continue
        n, lay, x, y = mt.group(1), mt.group(2), float(mt.group(3)), float(mt.group(4))
        face = 'S' if y < 0.1 else 'N' if y > ECTL_ST[1] - 0.1 else 'W' if x < 0.1 else 'E'
        pins[n] = (face, lay, x if face in 'NS' else y)
    out = {}
    for dp, bases in ECTL_ST_PORTS.items():
        sel = [v for n, v in pins.items() if n in bases or re.sub(r'\[\d+\]$', '', n) in bases]
        if not sel:
            raise ValueError(f'kv_die: ECTL_ST port {dp}: no kit pin {bases} in {ECTL_ST_PINS}')
        faces = {v[0] for v in sel}
        if len(faces) != 1:
            raise ValueError(f'kv_die: ECTL_ST port {dp} spans faces {faces}')
        lays = sorted({v[1] for v in sel}, key=lambda L: -sum(1 for v in sel if v[1] == L))
        a = [v[2] for v in sel]
        span = max(a) - min(a)
        pitch = max(1, int(round(span / (len(sel) * (0.064 if lays[0] == 'M6' else 0.048))))) if len(sel) > 1 else 1
        out[dp] = ('face', len(sel), faces.pop(), lays[0], round((max(a) + min(a)) / 2, 3), pitch)
    return out


def _set_geometry(split, reserve_static_memory=False, reserve_native_astk=False):
    """module geometry for the plain KV die (split False) or the split KV/system die (split True)"""
    global HEAD, ENG_H, RENG, TILE_Y, FRAMES, LAND_W, ASTK_W, ECTL
    ECTL = ECTL_ST if _ectl_st_frame(split) else _BASE['ECTL']
    if ECTL[0] > (SPLIT_HEAD_V11 if split else _BASE['HEAD'])[0]:
        raise ValueError(f'kv_die: ECTL frame {ECTL} wider than the head column')
    if reserve_static_memory and not split:
        raise ValueError('native static memory reservation requires split KV/system die')
    if reserve_native_astk and not split:
        raise ValueError("native ASTK reservation requires split KV/system die")
    ASTK_W = 328.32 if reserve_native_astk else 220.32
    LAND_W = 237.6 if reserve_static_memory else 172.8
    HEAD = SPLIT_HEAD_V11 if split else _BASE['HEAD']
    ENG_H = 4 * HEAD[1] + ECTL[1] + 4 * GY
    RENG = (HEAD[0], ENG_H)
    TILE_Y = dict(h0=0.0, h1=HEAD[1] + GY, c=2 * (HEAD[1] + GY), h2=2 * (HEAD[1] + GY) + ECTL[1] + GY,
                  h3=3 * (HEAD[1] + GY) + ECTL[1] + GY)
    V143['eng_h_v142'] = ENG_H
    if split and V143['on']:
        # v1.4.3: far head | NF band | near head (ft) | ECTL band | ECTL | ECTL band | near head (ft) | NF band | far head
        hf = SPLIT_HEAD_FT[1]
        TILE_Y = dict(h0=0.0, h1=HEAD[1] + V143_NF_LO)
        TILE_Y['c'] = TILE_Y['h1'] + hf + V143_BAND_LO
        TILE_Y['h2'] = TILE_Y['c'] + ECTL[1] + V143_BAND_HI
        TILE_Y['h3'] = TILE_Y['h2'] + hf + V143_NF_HI
        ENG_H = TILE_Y['h3'] + HEAD[1]
        RENG = (HEAD[0], ENG_H)
        for k_, v_ in TILE_Y.items():
            assert abs(v_ / GY - round(v_ / GY)) < 1e-6, f'v1.4.3 tile {k_} off the {GY}-um grid: {v_}'
    FRAMES = dict(_BASE['FRAMES'], **(SPLIT_FRAMES if split else {}))
    for k_ in _BASE_BINDINGS_LATE:
        _BASE_BINDINGS.setdefault(k_, BINDINGS[k_])
    for k_, v_ in (SPLIT_BINDINGS if split else _BASE_BINDINGS).items():
        BINDINGS[k_] = v_
    if not split:
        for k_ in SPLIT_ONLY_BINDINGS:
            BINDINGS.pop(k_, None)


# split die masters bind to the RTL the split actually instantiates (NO STUBS, owner 08:05 PT): the hierarchical head
# cluster, the merged-die sequencer cluster qkd_seq (native HEADS 1 / Q_FP32 1 profile = its parameters)
_BASE_BINDINGS = {k: BINDINGS[k] for k in ('qkd_rhead', 'qkd_seq', 'qkd_ectl', 'qkd_ahub')}
_BASE_BINDINGS_LATE = ('qkd_kvwq_ctl_bin', 'qkd_kvwq_leaf_s_w129_m')     # defined further down; captured at first _set_geometry call
SPLIT_BINDINGS = dict(
    # v1.1: the native head (wires-only parent of 35 hardened children, each its own clock entry)
    qkd_rhead=dict(module='ot_qkh_head_native_r4', file='rtl/qwen_sys/split_20261014/ot_qkh_head_native_r4.sv',
                   parameters=dict(Q_FP32=1),
                   ports=dict(ti=['c_in', 'row_in', 'lt_in', 'q_valid_in', 'q_beat_in', 'q_data_in'], e=['e_in'],
                              s=['sc_d', 'sc_f', 'g_f'], nb=['nb_d'], ck_f0=['ck_front'], ck_k=['ck_kt'], ck_s=['ck_score'],
                              ck_i0=['ck_stin'], ck_t0=['ck_stk'], ck_a0=['ck_nb1'], ck_b0=['ck_nb2'], ck_l0=['ck_lane'],
                              rst_n=['rst_n']),
                   sliced={**{f'ck_f{q}': 'ck_f0' for q in range(1, 4)},
                           **{f'ck_{t}{i}': f'ck_{t}0' for t in 'itabl' for i in range(1, 16)}},
                   classed={'hid': 'by_design: die-top strap (tie cells), the head index of this tile'}),
    # v1.1: the three native TP8 control leaves A / B / C behind the wires-only qkd_ectl3_s, ck[0..2] = die ck_a / ck_b / ck_c
    # v1.2: the DIRECT-seam parent (Codex 5f3e5767f / 00f42ca01: no B feed-through flops; C launches straight to A over B;
    # exact 3,705 / 4,137 PASS, A/B/C mutants FAIL) = the structural fix of the tp3 views' native-audit FAIL; same ports
    qkd_ectl=dict(module='qkd_ectl3_epoch_direct_s', file='rtl/qwen_sys/split_20261014/qkd_ectl3_epoch_direct_s.sv',
                  ports=dict(si=['si'], so=['so'], t0=['t0'], t1=['t1'], e0=['e0'], e1=['e1'], e2=['e2'], e3=['e3'],
                             s0=['s0'], s1=['s1'], s2=['s2'], s3=['s3'], rq=['rq'], rs=['rs'], ck_a=['ck'], rst_n=['rst_n']),
                  sliced=dict(ck_b='ck_a', ck_c='ck_a'),
                  classed={'cfg': 'by_design: die-top strap {engine 3, stack 2} (tie cells) per slot'}),
    # v1.1: the write-queue controller is the CLOSED strip-form slot qkd_kvwq_ctl_bin (route qkd_kvwq_ctl_bin-sl3-8a9ae6449,
    # 172.8 x 129.6, pin-registered): f0..f3 are the 293-b encoded group words the die carries (v1 bound the old 298-b die
    # form with 5 lane bits tied = the port-bind MISMATCH)
    qkd_kvwq_ctl_bin=dict(module='qkd_kvwq_ctl_bin', file='rtl/physical/ot_qwen_kv_slot_wrappers.sv',
                          ports=dict(kvn=['kvn_d', 'kvn_cr'], f0=['f0'], f1=['f1'], f2=['f2'], f3=['f3'], r0=['r0'],
                                     r1=['r1'], r2=['r2'], r3=['r3'], fault=['fault'], ck=['ck'], rst_n=['rst_n']),
                          classed={'durable': 'by_design (v1.2): the write-retire word {rw_v, rw_id}, unread on the KV/system '
                                              'die (flow control = the kvn credit; no consumer RTL)'}),
    # v1.1: the write leaf is the CLOSED slot qkd_kvwq_leaf_s_w129_m (route qkd_kvwq_leaf_s_w129_m-sl1-4df79ee4f, view with
    # insertion.json); same bit order as ot_qkvd_kv_wq_leaf's split fields
    qkd_kvwq_leaf_s_w129_m=dict(module='qkd_kvwq_leaf_s_w129_m', file='rtl/qwen_sys/kv_die_20261009/qkd_kvwq_leaf_slot.sv',
                                ports=dict(c=['c'], n=['n'], dn=['dn'], dp=['dp'], w=['w'], wr=['wr'], ck=['ck'],
                                           rst_n=['rst_n'], lane=['lane']), classed={}),
    qkd_seq=dict(module='qkd_seq', file='rtl/physical/ot_qwen_kv_centre_slots.sv', parameters=dict(HEADS=1, Q_FP32=1),
                 ports=dict(lx=['r_x3_d', 'r_sd', 'r_kvd', 't_ar_cr'], lr=['t_ar_d', 't_ds', 't_pw', 'r_x3_cr'],
                            **{f'aq_{q}': [f'aq_{q}'] for q in STACKS}, **{f'kvn_{q}': [f'kvn_{q}_d', f'kvn_{q}_cr'] for q in STACKS},
                            **{f'kc_{q}': [f'kc_{q}'] for q in STACKS}, **{f'af_{q}': [f'af_{q}'] for q in STACKS},
                            **{f'mf_{q}': [f'mf_{q}'] for q in STACKS},
                            ar=['ar'], hf=['hf'], hs=['hs'], hc=['hc'], tk=['tk'], kst=['kst'], ck=['ck'], rst_n=['rst_n']),
                 classed={}),
    qkd_ahub=dict(module='ot_qkd_ahub_die', file='rtl/hdc/nearhbm/ot_qkd_ahub_core.sv',
                  ports=dict(ap_WS=['si_valid', 'si_type', 'si_g', 'si_hh', 'si_k', 'si_any', 'si_data', 'pi_valid',
                                    'pi_g', 'pi_beat', 'pi_data'],
                             am_WS=['am'], ao=['out_valid', 'out_g', 'out_beat', 'out_data'], hs=['start'], hf=['fault'],
                             ck_c=['ck'], rst_n=['rst_n']),
                  sliced=dict(ap_WN='ap_WS', ap_ES='ap_WS', ap_EN='ap_WS', am_WN='am_WS', am_ES='am_WS', am_EN='am_WS'),
                  classed={'ev': 'debug: hub event word (unread on the die)'}))


# v1.2: the strip frames bind the wires-only compositions of their CLOSED leaves (tools/qwen_kv_die/kv_strips.py ->
# rtl/qwen_sys/split_20261014/qkd_strips_s.sv), each leaf its own clock entry
SPLIT_ONLY_BINDINGS = ('qkd_land', 'qkd_land_n', 'qkd_astk', 'qkd_astk_n', 'qkd_embgw', 'qkd_ctrl', 'qkd_ctrl_n')
# v1.4.3 G3S2 masters (bound only when the die instantiates them)
SPLIT_BINDINGS['qkd_rhead_ft'] = dict(SPLIT_BINDINGS['qkd_rhead'], module='ot_qkh_head_native_r4_ft',
    file='rtl/qwen_sys/split_20261014/ot_qkh_head_native_r4_ft.sv',
    ports=dict(SPLIT_BINDINGS['qkd_rhead']['ports'], ft_ti_a=['ft_ti_a'], ft_e_a=['ft_e_a'], ft_ti_b=['ft_ti_b'],
               ft_e_b=['ft_e_b'], ft_s_a=['ft_s_a'], ft_s_b=['ft_s_b'], ck_ft_t=['ck_ft_t'], ck_ft_s=['ck_ft_s']))
SPLIT_BINDINGS['qkd_rst_region'] = dict(module='qkd_rst_region', file='rtl/qwen_sys/split_20261014/qkd_rst_region.sv',
    ports=dict(a=['a'], b=['b'], ck=['ck'], dly=['dly']),
    classed={'por_n': 'by_design: package POR pad (off-chip signal), async assert, synchronised inside the root'})
if RST_PIN_REG:
    SPLIT_BINDINGS['qkd_rst_region'] = dict(SPLIT_BINDINGS['qkd_rst_region'], module='qkd_rst_region_pr',
        file='rtl/qwen_sys/split_20261014/qkd_rst_region_pr.sv')
SPLIT_BINDINGS['qkd_hgs'] = dict(module='qkh_head_gather_stage', file='rtl/qwen_sys/split_20261014/qkh_head_gather_stage.sv',
    ports=dict(ti_a=['ti_a'], e_a=['e_a'], ti_b=['ti_b'], e_b=['e_b'], ck=['ck']), classed={})
# v1.4.4 PV16 wide pairs (die-placed children via kv_expand) behind their wires-only KV-die face qkd_pvw_die (one die word
# per V port each way: vrq<k> pair -> vport k, vin<k> vport k -> pair, so valid / tag / data share ONE relay chain).
# Inputs with no producer RTL on the die yet stay UNCONNECTED (strict bind: declared open, never tied; owners in
# kv_expand.PV_OPEN): start / context_len / epoch (static attention calendar), in_e (ASTK e-read service), in_epoch (V arrival
# epoch: the r5 vport carries none).  Outputs without a die consumer yet: out_* / fault / busy / out_age (finalize face).
for _mn, _pair in (('qkd_pvw_s', 0), ('qkd_pvw_n', 1)):
    SPLIT_BINDINGS[_mn] = dict(module='qkd_pvw_die', file='rtl/qwen_sys/split_20261014/qkd_pvw_die.sv',
        parameters=dict(PAIR=_pair, CTL_RESET_PIN=1, LEAF_RESET_PIN=1, FIRST_INPUT_AGE=PV_AGE if V144_R6 else 20, MUT=0),
        ports=dict(ck_c0=['col_clk'], rst_n=['rst_n'], st=['start', 'context_len', 'epoch'], ie=['in_e'],
                   **({} if V144_R6 else dict(iep=['in_epoch'])),
                   **{f'vin{k}': [f'vin{k}'] for k in range(8)}, **{f'vrq{k}': [f'vrq{k}'] for k in range(8)},
                   po=['out_valid', 'out_leaf', 'out_epoch'], pf=['fault', 'busy', 'out_age']),
        sliced={f'ck_c{s}': 'ck_c0' for s in range(1, 33)}, classed={})
    if V144_R6:
        SPLIT_BINDINGS[_mn].update(module='qkd_pvw_die_e', file='rtl/qwen_sys/split_20261014/qkd_pvw_die_e.sv')
    if PV_T:
        SPLIT_BINDINGS[_mn] = dict(module='qkd_pvw_die_t', file=PV_T_FILE,
            parameters=dict(PAIR=_pair, CTL_RESET_PIN=1, LEAF_RESET_PIN=1, FIRST_INPUT_AGE=PV_AGE, MUT=0, TRUNK_MUT=0, FLAG_D_ADJ=0),
            ports=dict(ck_c0=['col_clk'], rst_n=['rst_n'], st=['start', 'context_len', 'epoch'], ie=['in_e'],
                       **{f'vh{k}': [f'vh{k}'] for k in range(8)}, **{f'vrq{k}': [f'vrq{k}'] for k in range(8)},
                       **{f'vc{k}_{g}': [f'vc{k}_{g}'] for k in range(8) for g in range(8)},
                       po=['out_valid', 'out_leaf', 'out_epoch'], pf=['fault', 'busy', 'out_age'],
                       # KV-RTRUNK 10-17: the pair's 534-b result beat stream (two result trunks -> header) -> pvfin.p0 / p1
                       **(dict(pr=['rs_valid', 'rs_beat', 'rs_epoch', 'rs_data']) if PV_RS else {})),
            sliced={f'ck_c{s}': 'ck_c0' for s in range(1, 33)}, classed={})
# v1.4.4 PV16 V ports (Q-VMWB r5 = the V ISSUER, kit physical/ref_tile/qkd_pv16_vport_r5): pr = the pair's request for this
# port, vq0 / vq1 = V gets to static landing groups {k, 0} / {k, 1}, i0 / i1 = those groups' rsp words, vo -> the pair.
# RL / WP / RT are the kit's (19 / 2 / 8); the die's measured relay depths are recorded in plan pv144.vport_timing.
SPLIT_BINDINGS['qkd_pv16_vport'] = dict(module='qkd_pv16_vport', file='rtl/qwen_sys/static_kv_20261014/qkd_pv16_vport.sv',
    parameters=dict(MUT=0, RL=19, WP=2, RT=8),
    ports=dict(ck=['ck'], rst_n=['rst_n'], pr=['pr_valid', 'pr_t'], vq0=['vq0_valid', 'vq0_t'], vq1=['vq1_valid', 'vq1_t'],
               i0=['in0_valid', 'in0_vflag', 'in0_t', 'in0_d'], i1=['in1_valid', 'in1_vflag', 'in1_t', 'in1_d'],
               vo=['out_valid', 'out_t', 'out_v_lo', 'out_v_hi'], f=['fault']), classed={})
if V144_R6:
    SPLIT_BINDINGS['qkd_pv16_vport'].update(parameters=dict(MUT=0, DQ=0, RT=8), ports=dict(
        ck=['ck'], rst_n=['rst_n'], pr=['pr_valid', 'pr_t'], vq0=['vq0_valid', 'vq0_t'], vq1=['vq1_valid', 'vq1_t'],
        i0=['in0_valid', 'in0_vflag', 'in0_t', 'in0_epoch', 'in0_d'], i1=['in1_valid', 'in1_vflag', 'in1_t', 'in1_epoch', 'in1_d'],
        vo=['out_valid', 'out_t', 'out_epoch', 'out_v_lo', 'out_v_hi'], f=['fault']))
    if PV_T:      # KVPLAN 1815: the V word fork (wires-only frame of 4 relay standards, expanded by kv_expand)
        SPLIT_BINDINGS['qkd_pvfork'] = dict(module='qkd_pvfork', file='rtl/qwen_sys/split_20261014/qkd_pvfork.sv',
            ports=dict(ck=['ck'], vi=['vi'], vh=['vh'], vta=['vta'], vtb=['vtb']), classed={})
        for g_ in (2, 3, 4):         # KVPLAN2 2215: the chunk trunk taps (qkd_pvtap.sv; g_ = chunks in)
            SPLIT_BINDINGS[f'qkd_pvtap{g_}'] = dict(module=f'qkd_pvtap{g_}', file='rtl/qwen_sys/split_20261014/qkd_pvtap.sv',
                ports=dict(ck=['ck'], ti=['ti'], tc=['tc'], to=['to']), classed={})
SPLIT_BINDINGS['qkd_hss'] = dict(module='qkh_head_sstage', file='rtl/qwen_sys/split_20261014/qkh_head_stages.sv',
    ports=dict(s_a=['s_a'], s_b=['s_b'], ck=['ck']), classed={})
SPLIT_PHY = 'qkd_hbm3e_phy_pc'
SPLIT_BINDINGS.update(qkd_ctrl=KS.ctrl_binding(rev=True), qkd_ctrl_n=KS.ctrl_binding())   # v1.3: S stacks = reversed chains (kc at the S = outer end)
SPLIT_BINDINGS.update(qkd_land=KS.land_binding(), qkd_land_n=KS.land_binding(), qkd_astk=KS.astk_binding(),
                      qkd_astk_n=KS.astk_binding())
# v1.2: the embedding gateway binds its CLOSED view's RTL (qkd_embgw sl2): the link words gq / gr and the host words hb / est
# match; emf / emr do NOT (gateway {kind 2, seq 4, data 281, v} 288 + cr / 520 + cr vs the landing engine's 530-b
# {cr, pad 5, tag 11, data 512, v}): an RTL interface defect between two closed views (elements: land_emb 'ifw' re-route
# to the gateway's words, 12:40) -> port bind MISMATCH until one side changes
# KVJ-C2 2026-10-17 (coordinator D2, kv_static_join_plan.md): the gateway is BOOT-ONLY, qkd_embgw_boot (KVJ-C 413776b17,
# lock-step equal to qkd_embgw_splitboot with r_ea idle): r_ea / t_ecr / t_eq are removed, so the gq / gr bundles are
# dropped (not tied); the token's embedding row is read through the 128 PCs (static join, kv_static.py ROLES embgw /
# emb_return_* / emb_join / row_tx) and leaves on the d2d end's port 2
SPLIT_BINDINGS['qkd_embgw'] = dict(
    module='qkd_embgw_boot', file='rtl/qwen_sys/static_embedding_20261014/qkd_embgw_boot.sv', parameters=dict(MUT=0),
    ports=dict(hb=['hb', 'hb_cr'], est=['est'], ck=['ck'], rst_n=['rst_n'],
               # Q-KVSYS-NETLIST 2026-10-16 (strict bit-level bind, opentallas.die_port_bind.v2): each die bundle carries its
               # word one way and the credit for THAT word back (the landing strip's emf / emf_cr out and emr / emr_cr in,
               # the relay direction model's reverse bit).  The gateway's credit FOR emf is emr_<q>_cr ('strip q consumed one
               # gateway word', in) and its credit for emr is emf_<q>_cr ('the gateway took one emr word', out): v1.2 paired
               # each word with the other word's credit -> bit 288 of emf multi-driven (gateway + strip) and bit 520 of emr
               # undriven at the strip end.  Widths unchanged (289 / 521); die.v nets unchanged.
               **{f'emf_{q}': [f'emf_{q}', f'emr_{q}_cr'] for q in STACKS},
               **{f'emr_{q}': [f'emr_{q}', f'emf_{q}_cr'] for q in STACKS}), classed={})


# ---- kvsys v1.4 (2026-10-15, die lead r7): REAL HOST / PLL bindings and the 128 die-placed HOST PC slices ----------------
# The HOST frame qkd_host is replaced by the generated root core qkd_host_root_pt (c460799eb, exact hierarchy move of
# qkd_host_root_integrated) and one qkd_host_pc_slice_die level with every CDC / write-leaf pair, in a 129.6-um slice column
# per side between the landing channel and the landing strip (+ a 21.6-um routing cell: +302.4 um die width).  The PLL frame is the allowed analog
# model qkd_pll_analog_model (no digital reset sequencer: every reset is a root output).  Root inputs without a real die
# producer stay UNCONNECTED (port-bind MISMATCH, never tied): host_bind_census.json, owners named there.
HOST_V14 = dict(on=False)
SLICE_W, SLICE_H = 129.6, 345.6
# one 21.6-um routing cell W of the slice column: the write-queue controller (172.8 in the 216-um landing channel) otherwise
# closes the channel at mid-stack and the N stacks' slot-0 slices have no die route to the root (first v1.4 plan)
SLICE_GAP = 21.6
# KVJ-A 10-17 (0cx COORD decision, kv_static_join_plan item 3): the die's HOST root master is qkd_host_root_admission, the
# successor of qkd_host_root_pt (same generated partition: qkd_host_ingest_chain_pt + the 128 die slices; adds the HOST
# image replay outputs boot_pr / boot_image_* that drive qkd_static_kv_boot_dispatch, static_setup_ready, the native
# ownership admission native_reserved / ownership_valid -> host_admission_open / host_launch_quiet / host_deferred, and the
# exported upstream debt host_upstream_quiet).  Its host_interface_idle is the pt root's host_drained_local (renamed; the
# die port keeps the name host_drained_local, bundle hhdl unchanged).  The new admission ports are joined to the static
# subsystem (kv_static_boot_join.HOST_DIE_JOINS) when kv_die --split instantiates it (item 10); until then they are open.
HOST_RT_FILE = 'rtl/qwen_sys/split_20261014/qkd_host_root_admission.sv'
HOST_RT_MODULE = 'qkd_host_root_admission'
HOST_RT_PT_FILE = 'rtl/qwen_sys/split_20261014/qkd_host_root_pt.sv'     # qkd_host_ingest_chain_pt (child of the admission root)
HOST_RT_RENAMED = dict(host_drained_local='host_interface_idle')          # die port -> admission RTL port
SLICE_DIE_FILE = 'rtl/qwen_sys/split_20261014/qkd_host_pc_slice_die.sv'
# root clock -> PLL family (FIXTURE = tools/qwen_native_host/host_owner.hpp clocks(); INFERRED = no fixture drives it:
# the HOST owner must confirm, recorded in the v1.4 contract)
HOST_CLK_FAMILY = dict(
    **{c: 'core' for c in ('ck_host', 'ck_csr', 'ck_rst', 'ck_ctl', 'ck_prompt', 'ck_rx', 'ck_tx', 'ck_axi', 'ck_ctrl',
                           'ck_hc', 'ck_phy_rx_r', 'ck_phy_tx_w', 'ck_qm_queue', 'ck_qm_ing_w', 'ck_qm_done_r',
                           'ck_qm_core', 'ck_map', 'ck_sum', 'ck_order', 'ck_fence_core', 'ck_guard', 'ck_native')},
    **{c: 'host' for c in ('ck_qm_host', 'ck_qm_ing_r', 'ck_qm_credit', 'ck_qm_done_w', 'ck_fence_host')},
    **{c: 'ingest' for c in ('ck_qm_ingest', 'ck_qm_out', 'ck_qm_bank0', 'ck_qm_bank1')},
    **{c: 'phy' for c in [f'ck_phy{i}' for i in range(8)] + ['ck_pad', 'ck_phy_rx_w', 'ck_phy_tx_r']})
HOST_CLK_INFERRED = dict(
    **{c: 'core' for c in ('ck_program_rx', 'ck_program_loader', 'ck_dispatch', 'ck_retire', 'ck_bootbarrier',
                           'ck_records', 'ck_coordinator_codec', 'ck_coordinator_lifecycle', 'ck_coordinator_post',
                           # COORD 0dd+ D2 (10-17, KVJ-A3 census): ck_peer / ck_root_mux talk to core blocks through direct
                           # same-cycle valid/ready with no synchroniser (root_mux<->coordinator, peer_link.normal_rx ->
                           # program_rx, token request/grant), so they are CORE, not the 1 GHz host family
                           'ck_peer', 'ck_root_mux')})
HOST_GROUPS = dict(chain_f='chf', chain_c='chc', chain_a='cha', chain_fault_i='chx', slice_ack='sak',
                   slice_boot_done='sbd', slice_boot_ok='sbo', slice_boot_fault='sbf')


def host_rt_binding():
    import re as _re
    txt = _re.sub(r'//[^\n]*', '', (ROOT / HOST_RT_FILE).read_text())
    hdr = txt[txt.index('module ' + HOST_RT_MODULE + ' '):]
    hdr = hdr[hdr.index(')(') + 2:hdr.index(');')]
    names = [_re.findall(r'[A-Za-z_][A-Za-z_0-9]*', part.strip())[-1] for part in hdr.split(',') if part.strip()]
    ports, sliced = {}, {}
    for n in names:
        if n in ('ck_phy', 'ck_qm_bank'):
            k_ = 8 if n == 'ck_phy' else 2
            ports[f'{n}0'] = [n]
            sliced.update({f'{n}{i}': f'{n}0' for i in range(1, k_)})
        elif n in HOST_GROUPS:
            g = HOST_GROUPS[n]
            ports[f'{g}0'] = [n]
            sliced.update({f'{g}{i}': f'{g}0' for i in range(1, 4)})
        elif n in ('phy_up', 'phy_rx_v', 'phy_rx_flit', 'phy_tx_v', 'phy_tx_flit', 'hb', 'hb_cr', 'local_tk', 'local_kst'):
            continue
        else:
            ports[n] = [n]
    for die_port, rtl_port in HOST_RT_RENAMED.items():
        ports[die_port] = ports.pop(rtl_port)
    ports.update(fdi=['phy_up', 'phy_tx_v', 'phy_tx_flit', 'phy_rx_v', 'phy_rx_flit'], hb=['hb', 'hb_cr'],
                 tk=['local_tk'], kst=['local_kst'])
    return dict(module=HOST_RT_MODULE, file=HOST_RT_FILE, ports=ports, sliced=sliced,
                parameters=dict(ENABLE_SERVICE=1, ENABLE_NATIVE=1, ENABLE_TOKEN=1, NL=2),   # NL: 2 real link ends (static D2D + host SerDes)
                classed={'die_id': 'by_design: package strap (tie cells), role = 2 PKG + DIE, set at package assembly',
                         'por_n': 'by_design: package POR pad (off-chip signal)'})


def slice_die_binding():
    # KV-FIX3 es2 2026-10-17: one clock entry ck (the four former entries were taps of the same clk_core_<stack> net)
    names = ['ck', 'host_rst_n', 'hbm_rst_n', 'lpc', 'bgi', 'bgo', 'fi',
             'fo', 'ci', 'co', 'ai', 'ao', 'fault_i', 'fault_o', 'land_es', 'land_er', 'ctrl_es', 'ctrl_er',
             'ctrl_completion_v', 'ctrl_completion_we', 'ski', 'sdi', 'soi', 'sfi', 'sko', 'sdo', 'soo', 'sfo']
    return dict(module='qkd_host_pc_slice_die', file=SLICE_DIE_FILE, ports={n: [n] for n in names}, classed={})


def pll_model_binding():
    import kv_host_bindings as KHB
    b = KHB.pll_analog_binding()
    b['classed'] = {'refclk': 'by_design: package reference-clock pad (off-chip signal)',
                    'por_n': 'by_design: package POR pad (off-chip signal)'}
    return b


# v1.4 + Q-LINK (main c43263b31): the static compute <-> KV slot link end qkd_d2d_static (583-b PHY word = 548 payload + 19
# frame + CRC16, compiler-assigned slots, NO credits) replaces qkd_d2d (ot_qkvd_kv_end, credit-based, historical) + qkd_lnk;
# it produces 28 of the root's 31 previously unproduced inputs (results/arch/qwen_split_1014/link_static_1015/
# host_input_producers.json).  Die bundles: svc (27 producer words, the root's port order), lup (link_up, NL = 2 real
# link ends), rec_tx / rec_rx (the HOST record port), lrc (exceptional link reset / recovery clear from the root),
# fdi (the UCIe native 583-b word), fwd_epoch / fwd_link_rst_n (two forwarded bumps to the compute die)
D2DS_FILE = 'rtl/qwen_sys/d2d_static_20261015/ot_qwen_d2d_dies.sv'
D2DS_SVC = ['transport_fault', 'native_links_drained', 'native_link_reset_seen', 'native_retrained', 'abort_drained',
            'native_kv_drained', 'native_vm_drained', 'native_collective_drained', 'native_host_drained',
            'native_collective_busy', 'native_kv_flush', 'native_admit_ready', 'crom_fault', 'execution_active',
            'engine_result_v', 'engine_result_done', 'engine_result_fault', 'engine_result_cause', 'engine_result_tag',
            'engine_result_gen', 'engine_result_token', 'engine_result_value', 'engine_result_cycles']
D2DS_REC_TX = ['record_tx_observed_v', 'record_tx']
D2DS_REC_RX = ['record_send_kind', 'record_witness_slot', 'record_rx_v', 'record_rx']


# QLB-KV 10-18 (QXF-LINK 6ef1a097f F4): TXDP is a REQUIRED parameter of qkd_d2d_static (PR = 1; a zero byte does not
# elaborate: D2D_TXDP_NOT_COMPILED).  The die binds the compiler's KV vector D2D_TXDP_K from the committed calendar image
# (rtl/qwen_sys/d2d_static_20261015/d2d_cal_image.svh, tools/qwen_split/d2d_cal_seq_image.py); OT_KV_D2D_TXDP_K=0x...
# overrides it with the vector layer_compile.py derives for THIS die (RUN/layer_compile/d2d/txdp.svh QKD_D2D_TXDP).
# kv_relay_check.sh gates bound == compiled.
D2D_CAL_IMAGE = 'rtl/qwen_sys/d2d_static_20261015/d2d_cal_image.svh'


def d2d_txdp_k():
    import kv_static as _ks          # one source of the vector (kv_static.d2d_txdp_k)
    return _ks.d2d_txdp_k()


def _ks_ntx():
    import kv_static as _ks          # KV-PLAN5: one source of the TX lane count (kv_static.d2d_ntx_k, closed r7t = 3)
    return _ks.d2d_ntx_k()


def d2ds_binding():
    return dict(module='qkd_d2d_static', file=D2DS_FILE, parameters=dict(NL=2, NTX=_ks_ntx(), TXDP=d2d_txdp_k()),
                ports=dict(ck0=['ck'], rst_n=['rst_n'], fdi=['fdi_tx_up', 'fdi_tx_v', 'fdi_tx_flit', 'fdi_rx_v', 'fdi_rx_flit'],
                           phy_rst_n=['phy_rst_n'], svc=list(D2DS_SVC), lup=['link_up'], rec_tx=list(D2DS_REC_TX),
                           rec_rx=list(D2DS_REC_RX), lrc=['host_link_reset_req', 'host_recovery_clear'],
                           fwd_epoch=['fwd_epoch'], fwd_link_rst_n=['fwd_link_rst_n'], serdes_up=['serdes_up'],
                           status_epoch16=['status_epoch16'], host_drained_local=['host_drained_local'],
                           host_boot_begin=['host_boot_begin'], lpf=['fault']),
                sliced={},
                classed={'por_n': 'by_design: package POR pad (off-chip signal)'})


def _host_rt_v14(b):
    for g, ps in (('svc', D2DS_SVC), ('rec_tx', D2DS_REC_TX), ('rec_rx', D2DS_REC_RX)):
        for p_ in ps:
            b['ports'].pop(p_, None)
        b['ports'][g] = list(ps)
    b['ports'].pop('link_up', None)
    b['ports']['lup'] = ['link_up']
    for p_ in ('host_link_reset_req', 'host_recovery_clear'):
        b['ports'].pop(p_, None)
    b['ports']['lrc'] = ['host_link_reset_req', 'host_recovery_clear']
    return b


# Q-KVSYS-DIE 2026-10-16 (OT_KV_DCAL=1, default off): the KV link calendar sequencer qkd_d2d_cal_seq_pin (CLOSED view
# physical/ref_tile/qkd_d2d_cal_seq_pin_ep3, Q-LINK/Codex 3365a45b8 + fbc4a2e0d) drives the static D2D end's cfg loader /
# cal_start / cal_seg (6 of the 23 strict-bind open inputs); epoch_go <- the end's own fwd_epoch, halt <- epoch_abort,
# reload <- the HOST root's program_begin_v (a new program image begins: the calendar image restarts).  KV AUTO: no tok_go.
DCAL = __import__('os').environ.get('OT_KV_DCAL', '0') == '1'
DCAL_FILE = 'rtl/qwen_sys/d2d_static_20261015/qkd_d2d_cal_seq_pin.sv'
DCAL_CFG = ['cfg_tx_we', 'cfg_rx_we', 'cfg_addr', 'cfg_data', 'cal_start', 'cal_seg']
# DIE-KV-LEAD 10-19 (KV-PLAN5 d2d cfg double-producer finding): the static D2D end's calendar cfg loader (cfg_tx_we /
# cfg_rx_we / cfg_addr / cfg_data) has ONE producer, the boot dispatcher image target 11 (KVJ-SMALL LINKCFG=1, compiled
# from the current d2d_cal_image by kv_static_programme.link_cfg_words; kv_static_boot_join binds it on the link end, so the
# die nets n_ks_kvs_ctl__boot__link_cfg_* reach the d2ds identity pins). The calendar sequencer qkd_dcal drives only the
# run strobes cal_start / cal_seg; its own cfg_* outputs (a compile-time image, stale whenever TXDP changes) are load-less.
DCAL_CS = ['cal_start', 'cal_seg']
DCAL_CFGW = ['cfg_tx_we', 'cfg_rx_we', 'cfg_addr', 'cfg_data']
DCAL_WH = (18.792, 28.08)
# KV-DCAL-BOOTCFG 10-19 (OT_KV_DCAL_BC=1, needs OT_KV_DCAL=1 + OT_KV_STATIC_DIE=1; default off): the boot-only producer above
# lost the sequencer's RUNTIME segment-1 base writes (SEG1 after each admission, SEG2 at each epoch), so every KV token run
# replayed the admission segment.  With DCAL_BC the dcal slot is qkd_d2d_cal_seq_pin_bc (qkd_d2d_cal_seq_bootcfg.sv, kit
# physical/ref_tile/qkd_d2d_cal_seq_pin_bc): the boot dispatcher's link_cfg_* die nets end on its bcfg_* pins
# (kv_static_die re-targets the four ks_kvs_ctl__boot__link_cfg_* buses), and its cfg_* word (the boot write, else the
# sequencer's runtime base write) drives the D2D end's cfg port: one producer per pin, no load-less cfg output.
DCAL_BC = __import__('os').environ.get('OT_KV_DCAL_BC', '0') == '1'
DCAL_BC_FILE = 'rtl/qwen_sys/d2d_static_20261015/qkd_d2d_cal_seq_bootcfg.sv'
DCAL_BC_GROUPS = dict(btx='bcfg_tx_we', brx='bcfg_rx_we', bad='bcfg_addr', bdt='bcfg_data')   # die group -> RTL port
DCAL_BC_LINK = dict(cfg_tx_we='btx', cfg_rx_we='brx', cfg_addr='bad', cfg_data='bdt')         # d2ds cfg port -> dcal group
if DCAL_BC:
    DCAL_FILE = DCAL_BC_FILE
    DCAL_WH = (21.6, 34.56)          # the bc kit outline (+94 flops vs ep3 / _mu; MU-DIE-KV2 notified)


def dcal_binding():
    if DCAL_BC:
        return dict(module='qkd_d2d_cal_seq_pin_bc', file=DCAL_BC_FILE, parameters=dict(EP_SKEW=3, GO_OFS=0, MUT=0),
                    ports=dict(ck=['ck'], rst_n=['rst_n'], cal=list(DCAL_CS), dcfg=list(DCAL_CFGW), ego=['epoch_go'],
                               hlt=['halt'], rld=['reload'], **{g: [p] for g, p in DCAL_BC_GROUPS.items()}),
                    sliced={}, classed={})
    return dict(module='qkd_d2d_cal_seq_pin', file=DCAL_FILE, parameters=dict(EP_SKEW=3, GO_OFS=0),
                ports=dict(ck=['ck'], rst_n=['rst_n'], cal=list(DCAL_CS), dcfg=list(DCAL_CFGW), ego=['epoch_go'], hlt=['halt'],
                           rld=['reload']),
                sliced={}, classed={})


def _d2ds_binding_dcal():
    # always bound (a die without the dcal instance has no cal / eab pins, so the groups are unused): the post-prep
    # chain re-runs the strict bind without the OT_KV_* environment and must see the same bindings
    # (KV-DCAL-BOOTCFG: dcfg only under OT_KV_DCAL_BC, which kvsys_prep records in kv_flags.env for the re-run)
    b = d2ds_binding()
    b['ports'].update(cal=list(DCAL_CS), eab=['epoch_abort'])
    if DCAL_BC:
        b['ports'].update(dcfg=list(DCAL_CFGW))
    return b


BINDINGS.update(qkd_host_rt=_host_rt_v14(host_rt_binding()), qkd_hslice=slice_die_binding(), qkd_pllm=pll_model_binding(),
                qkd_d2ds=_d2ds_binding_dcal())
BINDINGS.update(qkd_dcal=dcal_binding())
RTL.update(qkd_dcal=DCAL_FILE)

# Q-KVSYS PVJOIN 2026-10-16 (OT_KV_KVNC=1, needs OT_KV_DCAL=1, default off): the KV-side compiled KVN context
# qkd_kvn_ctx_cal (rtl/qwen_sys/d2d_static_20261015/qkd_kvn_ctx_cal.sv, kit physical/ref_tile/qkd_kvn_ctx_cal_r2) produces
# the static D2D end's kvn_compiled_identity / kvn_compiled_generation (2 of the 17 strict-bind open inputs,
# bind17_producers.json): identity = {HOST cohort epoch, stage = KV link calendar run index + 1, cohort token / position, 0},
# generation = HOST cohort_gen.  Inputs: the calendar sequencer's cal_start (tap of n_dcal_cfg bit 40 at its source) and
# its run index layer (new 6-bit bus), the HOST root's cohort_tag / cohort_gen.  Bench tools/qwen_kv_die/kvn_ctx_bench.sh.
KVNC = __import__('os').environ.get('OT_KV_KVNC', '0') == '1'
KVNC_FILE = 'rtl/qwen_sys/d2d_static_20261015/qkd_kvn_ctx_cal.sv'
KVNC_WH = (12.96, 19.44)
KVNC_CS_BIT = DCAL_CS.index('cal_start')
assert KVNC_CS_BIT == 0       # LSB-first bit of cal_start in n_dcal_cfg (cal_start / cal_seg only, DIE-KV-LEAD 10-19)
BINDINGS.update(qkd_kvnc=dict(module='qkd_kvn_ctx_cal', file=KVNC_FILE, parameters=dict(MUT=0),
                              ports=dict(ck=['ck'], rst_n=['rst_n'], cs=['cal_start'], lay=['layer'], cht=['cohort_tag'],
                                         chg=['cohort_gen'], kvi=['compiled_identity', 'compiled_generation']),
                              sliced={}, classed={}))
BINDINGS['qkd_dcal']['ports']['lay'] = ['layer']
BINDINGS['qkd_d2ds']['ports']['kvi'] = ['kvn_compiled_identity', 'kvn_compiled_generation']
RTL.update(qkd_kvnc=KVNC_FILE)

# Q-KVSYS PVJOIN 2026-10-16 (OT_KV_SEQ_STATIC=1, needs OT_KV_DCAL=1 + OT_KV_KVNC=1, default off; lead-approved retirement
# of the credit/event sequencer): MASTER SWAP of the die slot `seq` to qkd_seq_static (rtl/qwen_sys/static_kv_20261014/
# qkd_seq_static.sv: static control leaf qkd_seq_core_static + the closed qkd_seq_xs_tp8 / qkd_seq_fan leaves).  Its
# output faces aq_<q> / kvn_<q> / kc_<q> / hs / tk / kst are bit-identical to qkd_seq's; its inputs are the static D2D
# end's attention RX + KVN receiver (one bus srx, so the Q push and its data keep one latency), the layer programme
# (lprg: qkd_static_kv_layer_programme_img, compile-time image, start = DCAL tok_start, authority = HOST root) and the
# end's svc word (a relayed fork branch of hsvc; the HOST cohort reaches lprg as a relayed fork branch of kvnc_cht / chg).  Gone: lx/lr (r_x3_d, r_sd, r_kvd, t_ar_cr, ...) and the host hc load.
SEQST = __import__('os').environ.get('OT_KV_SEQ_STATIC', '0') == '1'
SEQST_FILE = 'rtl/qwen_sys/static_kv_20261014/qkd_seq_static.sv'
LPRG_FILE = 'rtl/qwen_sys/static_kv_20261014/qkd_static_kv_layer_programme_rom.sv'
LPRG_WH = (27.0, 37.8)
SEQST_RX = ['att_rx_v', 'att_rx_kind', 'att_rx_beat', 'kvn_word_valid', 'kvn_word_tag', 'kvn_word_data']
BINDINGS.update(qkd_seq_st=dict(module='qkd_seq_static', file=SEQST_FILE, parameters=dict(MUT=0),
    ports=dict(srx=list(SEQST_RX), lp=['lp_run', 'lp_layer', 'lp_ctx_t'], svc=['svc'],
               **{f'aq_{q}': [f'aq_{q}'] for q in STACKS}, **{f'kvn_{q}': [f'kvn_{q}_d', f'kvn_{q}_cr'] for q in STACKS},
               **{f'kc_{q}': [f'kc_{q}'] for q in STACKS}, **{f'af_{q}': [f'af_{q}'] for q in STACKS},
               **{f'mf_{q}': [f'mf_{q}'] for q in STACKS}, ar=['ar'], hf=['hf'], hs=['hs'], tk=['tk'], kst=['kst'],
               ck=['ck'], rst_n=['rst_n']), sliced={}, classed={}),
                qkd_lprg=dict(module='qkd_static_kv_layer_programme_img', file=LPRG_FILE, parameters=dict(MUT=0),
    ports=dict(ck=['ck'], rst_n=['rst_n'], st=['start'], auth=['token_epoch_valid', 'program_ready', 'program_epoch',
               'program_digest'], cht=['cohort_tag'], chg=['cohort_gen'], lp=['attention_run', 'layer', 'ctx_t']),
    sliced={}, classed={}))
BINDINGS['qkd_dcal']['ports']['tks'] = ['tok_start']
_hb = BINDINGS['qkd_host_rt']['ports']
for _p in ('token_epoch_valid', 'program_ready', 'program_epoch', 'program_digest'):
    _hb.pop(_p, None)
_hb['auth_lp'] = ['token_epoch_valid', 'program_ready', 'program_epoch', 'program_digest']
BINDINGS['qkd_d2ds']['ports']['srx'] = list(SEQST_RX)
RTL.update(qkd_seq_st=SEQST_FILE, qkd_lprg=LPRG_FILE)
RTL.update(qkd_d2ds=D2DS_FILE)
RTL.update(qkd_host_rt=HOST_RT_FILE, qkd_hslice=SLICE_DIE_FILE)
# v1.4.1 HOST-north: the N stacks' slices = the same RTL under a second physical view with swapped chain faces
BINDINGS.update(qkd_hslice_dn=slice_die_binding())
RTL.update(qkd_hslice_dn=SLICE_DIE_FILE)

# KVJ-G2 2026-10-17 (OT_KV_STATIC_DIE=1, default off; kv_static_join_plan item 10): the 669-instance static KV subsystem
# PLACED in this split die (tools/qwen_kv_die/kv_static_die.py): generated wires-only tiles (rtl/qwen_sys/
# static_kv_die_20261017/qkd_kvs_tiles.sv) bound by identity, the ECTL frame re-bound to the fused A + K issuer
# composition qkd_ectl3_kiss_s (master qkd_ectlk), the D2D end's static faces as identity die ports, the V port's
# measured RT 9 (KVJ-F, abutted landing seg); the credit write / landing elements are removed by kv_static_die.inject
import kv_static_die as KSD  # noqa: E402


def _astk_engine(f):
    """KV-PLAN-ECTL: logical engine (astk port index) run by ECTL frame f; identity unless OT_KV_ECTL_PAIR=1, which needs
    the static die (the legacy landing strip's rq<e> / rs<e> pins are engine-indexed hard faces)"""
    if not KSD.ectl_pair():
        return f
    if not KSD.ON:
        raise SystemExit('OT_KV_ECTL_PAIR=1 needs OT_KV_STATIC_DIE=1 (the K links are the static landing groups)')
    return KSD.frame_engine(f)


def _astk_frame(e):
    """the ECTL frame that runs logical engine e (inverse of _astk_engine)"""
    if not KSD.ectl_pair():
        return e
    _astk_engine(0)
    return KSD.ectl_frame(e)
# KV-WIRE2 SEQ (KSD.SEQ_S): qkd_seq_static_s reads only {kvn_word_valid, kvn_word_tag} of the old srx word: they get their
# own d2d bundle skw (trunk seqst_kw -> seq); srx keeps the attention RX word + kvn_word_data for kvs_attn / kvs_ctl
SEQST_KW = []
if KSD.SEQ_S:
    # srx keeps kvn_word_data (the writer's KVN word, kvs_ctl: a fork branch as before; as its own 512-b identity word
    # its first hop from the d2d end found no relay spot under OT_KV_TILE_KITS, plan k1)
    SEQST_RX[:] = ['att_rx_v', 'att_rx_kind', 'att_rx_beat', 'kvn_word_data']
    SEQST_KW[:] = ['kvn_word_valid', 'kvn_word_tag']
    BINDINGS['qkd_d2ds']['ports']['srx'] = list(SEQST_RX)
    BINDINGS['qkd_d2ds']['ports']['skw'] = list(SEQST_KW)
    RTL.update(qkd_seq_st=KSD.SEQ_S_FILE)
KSD.D2D_LISTS = (D2DS_SVC, SEQST_RX, SEQST_KW)
# KV-WIRE2 ASTK (KSD.ASTK_ST): engine faces 413 / 633 b (qkd_ectl3_kiss_st), heads without the node beat (r4_s / r4_ft_s:
# no nb, no ck_a* / ck_b* entries), the strip die face qkd_astk_strip_er_die (clock entry ck_d = RTL ck_er: the element
# libs know ck_<letter><n> entries; no ck_v*)
if KSD.ASTK_ST:
    ENG_IN, ENG_OUT = 633, 413
    HEAD_CLK[:] = [c_ for c_ in HEAD_CLK if not c_.startswith(('ck_a', 'ck_b'))]
    KS.ASTK_CLK[:] = [c_ for c_ in KS.ASTK_CLK if not c_.startswith('ck_v')] + ['ck_d']
    for _mn, _mod in (('qkd_rhead', 'ot_qkh_head_native_r4_s'), ('qkd_rhead_ft', 'ot_qkh_head_native_r4_ft_s')):
        _hb = SPLIT_BINDINGS[_mn]
        SPLIT_BINDINGS[_mn] = dict(_hb, module=_mod, file='rtl/qwen_sys/split_20261014/ot_qkh_head_native_r4_s.sv',
            ports={k_: v_ for k_, v_ in _hb['ports'].items() if k_ not in ('nb', 'ck_a0', 'ck_b0')},
            sliced={k_: v_ for k_, v_ in _hb['sliced'].items() if not k_.startswith(('ck_a', 'ck_b'))})
    for _mn in ('qkd_pvw_s', 'qkd_pvw_n'):      # in_e: W stack lanes (ie) + E stack lanes (iee), 256 b each
        SPLIT_BINDINGS[_mn]['sliced'] = dict(SPLIT_BINDINGS[_mn].get('sliced') or {}, iee='ie')
if KSD.ON:
    SPLIT_BINDINGS.update(KSD.bindings())
    if V144_R6 and not KSD.KB.ON:
        # KVR-DERIVE 10-19 (coordinator): bind exactly the closed kit's RT (the die-derived 9 + relays is checked against
        # it by kv_static_params VPORT_RT, never bound in its place)
        SPLIT_BINDINGS['qkd_pv16_vport']['parameters'] = dict(SPLIT_BINDINGS['qkd_pv16_vport']['parameters'],
                                                               RT=KSD.tile_ages()['VPORT_RT'], DQ=KSD.tile_ages()['VPORT_DQ'])
        if PV_T and KSD.tile_ages()['PV_FIRST_INPUT_AGE'] is not None:     # the pair ctl kit's age (not OT_KV_PV_AGE)
            for _mn in ('qkd_pvw_s', 'qkd_pvw_n'):
                SPLIT_BINDINGS[_mn]['parameters'] = dict(SPLIT_BINDINGS[_mn]['parameters'],
                                                         FIRST_INPUT_AGE=KSD.tile_ages()['PV_FIRST_INPUT_AGE'])
    if KSD.KB.ON:
        # KV-BOOTAGE 10-19: the V ports and the pair control take their static ages from the sealed die cfg (boot image),
        # not from RTL parameters: bind the boot-age successors at their hardware BOUNDS (kv_bootage.BOUNDS) + cfg pins
        _vb = SPLIT_BINDINGS['qkd_pv16_vport']
        SPLIT_BINDINGS['qkd_pv16_vport'] = dict(_vb, module=KSD.KB.SUCC['vport'][1], file=KSD.KB.SUCC['vport'][0],
            parameters=dict(MUT=0, DQ=KSD.KB.BOUNDS['VPORT_DQ'], RT=KSD.KB.BOUNDS['VPORT_RT']),
            ports=dict(_vb['ports'], cfg=['cfg_age']))
        if PV_T:
            for _mn in ('qkd_pvw_s', 'qkd_pvw_n'):
                _pb = SPLIT_BINDINGS[_mn]
                SPLIT_BINDINGS[_mn] = dict(_pb, module='qkd_pvw_die_tb', file=KSD.KB.pvw_file(_pb['file']),
                    parameters=dict(_pb['parameters'], FIRST_INPUT_AGE=KSD.KB.BOUNDS['PV_FIRST_INPUT_AGE']),
                    ports=dict(_pb['ports'], cfa=['cfg_age']))
    for _p in ('att_tx_v', 'att_tx_payload', 'emb_tx_v', 'emb_tx_payload', 'kv_drained_local', 'kv_flush_local',
               'kv_active_local', 'rx_payload', 'att_tx_slot', 'att_tx_kind', 'att_tx_beat', 'emb_tx_slot',
               'kvn_word_identity', 'kvn_word_generation'):
        BINDINGS['qkd_d2ds']['ports'][_p] = [_p]
    RTL.update({k_: KSD.RTL_FILE for k_ in KSD.KIND_MASTER.values()}, qkd_ectlk=KSD.bindings()['qkd_ectlk']['file'])
    if KSD.PVFIN:      # KV-PLAN-FIN: the stream PV final join element pvfin
        RTL.update(qkd_pvfin=KSD.PVFIN_FILE)
    if KSD.BOOT:       # KV-WIRE2 / RTL-BUILD-KV BOOT (note s5.1): the gateway successor; emf / emr gone, boot word bw -> kvs_ctl
        SPLIT_BINDINGS['qkd_embgw'] = dict(module=KSD.BOOT_GW[1], file=KSD.BOOT_GW[0], parameters=dict(KSD.BOOT_GW[2]),
            ports=dict(hb=['hb', 'hb_cr'], est=['est'], bw=['bw'], ck=['ck'], rst_n=['rst_n']), classed={})
        RTL.update(qkd_embgw=KSD.BOOT_GW[0])
    if KSD.AHUB_STATIC:    # KV-INTEG/AHUB: the static hub element (one clock entry; kv_static_die AHUB binding)
        AHUB_CLK[:] = ['ck_c']
        RTL.update(qkd_ahub=f'{KSD.AHUB_FILE} qkd_ahub_static_dw')
    if KSD.AFAULT:     # RTL-BUILD-KV/FAULT P7: the pair fault rides its own 1-b die word to the attention fault root
        for _mn in ('qkd_pvw_s', 'qkd_pvw_n'):
            _pp = SPLIT_BINDINGS[_mn]['ports']
            if _pp.get('pf') == ['fault', 'busy', 'out_age']:
                _pp['pf'], _pp['pa'] = ['fault'], ['busy', 'out_age']
                SPLIT_BINDINGS[_mn]['classed'] = dict(SPLIT_BINDINGS[_mn].get('classed') or {},
                                                      pa='debug: pair busy / out age (unread on the die)')


# not exact-cut yet (frames sized, RTL partition owed): reported, not strict
FRAME_ONLY = dict(qkd_astk='ot_qwen_nearhbm_attn_stack_d minus its engines (re-cut D: q beat broadcast, node staging, '
                           'P.V levels 4-7; recut.json)',
                  qkd_astk_n='as qkd_astk, N-stack pin plan (hub words on the S face)',
                  qkd_land='qfd_kvc crossbar successor + ot_qkvd_kv_merge (rtl/qwen_sys/kv_die_20261009) + ot_qfd_emb_strip',
                  qkd_embgw='ot_qfd_emb_gw + the gateway link side (r21c hub link FIFOs)',
                  qkd_host='qfd_io_host successor (hing_qfd ingest) + ot_qfd_link_adapter', qkd_pll='vendor PLL + '
                  'ot_qwen_sys_rst_seq', qkd_ctrl='qfd_ctrl (r21c element; pcport KVW 2: KV write side-band from the CDC completion; kc: the stream-command '
                  'word from qkd_seq -> async FIFO -> hclk ot_qkvd_kcmd_tap chain -> the 32 per-PC heads)',
                  qkd_ctrl_n='as qkd_ctrl, N-stack pin plan (kc on the N face)',
                  qkd_ckbump='clock / reset bump pair to the ROM die (pad cell, no logic: by design)')


WQ_FILE = 'rtl/qwen_sys/kv_die_20261009/ot_qkvd_kv_wq_tiles.sv'
BINDINGS['qkd_kvwq_leaf'] = dict(module='ot_qkvd_kv_wq_leaf', file=WQ_FILE,
    ports=dict(c=['c_v', 'c_d', 'c_sec', 'c_lane', 'c_tag'], n=['n_v', 'n_d', 'n_sec', 'n_lane', 'n_tag'],
               dn=['dn_v', 'dn_bad'], dp=['dp_v', 'dp_bad'], w=['w_v', 'w_sec', 'w_data', 'w_tag'],
               wr=['w_room', 'wd_v', 'wd_tag'], ck=['clk'], rst_n=['rst_n'], lane=['lane']), classed={})
BINDINGS['qkd_kvwq_ctl'] = dict(module='ot_qkvd_kv_wq_ctl', file=WQ_FILE,
    ports=dict(kvn=['kvw_v', 'kvw_vg', 'kvw_t', 'kvw_layer', 'kvw_d', 'kvw_cr'],
               f0=['f_v', 'f_d', 'f_sec', 'f_lane', 'f_tag'], r0=['r_v', 'r_bad'],
               durable=['rw_v', 'rw_id'], fault=['fault'], ck=['clk'], rst_n=['rst_n']),
    sliced=dict(f1='f0', f2='f0', f3='f0', r1='r0', r2='r0', r3='r0'), classed={})
BINDINGS['qkd_cdc_wleaf'] = dict(module='ot_qwen_stream4_cdc_pc', file='rtl/hdc/kv/ot_qwen_stream4_cdc_pc.sv',
    ports=dict(ho=['h_cred', 'h_wv', 'h_wsec', 'h_cv', 'h_csec', 'h_cdata', 'h_ctag', 'h_fault'],
               hi=['h_lv', 'h_lsec', 'h_lrow', 'h_ldata', 'h_hand', 'h_wcon', 'h_av', 'h_atag'],
               co=['l_v', 'l_sec', 'l_row', 'l_data', 'l_pop'], wi=['w_v', 'w_sec', 'w_data', 'w_tag'],
               wr=['w_room', 'wd_v', 'wd_tag'], cf=['c_fault'], clk=['clk'], hclk=['hclk'],
               c_arst_n=['c_arst_n'], h_arst_n=['h_arst_n']), classed={})

BINDINGS['qkd_kvwq_ctl_bin'] = copy.deepcopy(BINDINGS['qkd_kvwq_ctl'])
BINDINGS['qkd_kvwq_ctl_bin'].update(module='ot_qkvd_kv_wq_ctl_binary',
    file='rtl/qwen_sys/kv_die_20261009/ot_qkvd_kv_wq_ctl_binary.sv', parameters=dict(FLANE_BINARY=1))

BINDINGS['qkd_kvwq_leaf_s'] = copy.deepcopy(BINDINGS['qkd_kvwq_leaf'])
BINDINGS['qkd_kvwq_leaf_s_w129'] = copy.deepcopy(BINDINGS['qkd_kvwq_leaf'])
BINDINGS['qkd_kvwq_ctl_bin_h'] = copy.deepcopy(BINDINGS['qkd_kvwq_ctl_bin'])
BINDINGS['qkd_kvwq_ctl_bin_h']['parameters'] = dict(FLANE_BINARY=1, HEAD_PIPE=1)
BINDINGS['qkd_kvwq_leaf_s_w129_m'] = copy.deepcopy(BINDINGS['qkd_kvwq_leaf_s_w129'])

# el1013-qwen-kvstrips 2026-10-13 (coordinator-accepted slot change): the controller strip qkd_ctrl / qkd_ctrl_n is 32
# die slots of ONE hardened master qkd_ctrl_pc (PC k at strip y = 378 k, pc[4:0] strapped) + one qkd_ctrl_kc leaf at the
# N end (strip y = 12,096); the PHY is re-pinned per PC (po / pi face the leaf).  The masters' ports ARE the die buses;
# STRIP_FIELDS gives each bus's fields LSB first (the benches generate their offsets from it).
STRIP_FILE = 'rtl/qwen_sys/kv_die_20261009/qkd_ctrl_strip.sv'
STRIP_FIELDS = dict(
    qkd_ctrl_pc=dict(
        ci=[('h_cred', 3), ('h_wv', 1), ('h_wsec', 24), ('h_cv', 1), ('h_csec', 24), ('h_cdata', 256), ('h_ctag', 9),
            ('h_fault', 1)],                                                   # = qkd_cdc_wleaf ho
        co=[('h_lv', 1), ('h_lsec', 17), ('h_lrow', 8), ('h_ldata', 256), ('h_hand', 1), ('h_wcon', 1), ('h_av', 1),
            ('h_atag', 9)],                                                    # = qkd_cdc_wleaf hi
        es=[('s_v', 1), ('w_d', 256), ('s_row', 19), ('s_col', 5), ('s_bank', 5), ('s_we', 1), ('w_v', 1)],
        er=[('e_v', 1), ('e_data', 256), ('e_ce', 1), ('e_ue', 1), ('s_credit', 1), ('fault_core', 1)],
        po=[('row_v', 1), ('row_op', 3), ('row_bank', 5), ('row_row', 19), ('col_v', 1), ('col_we', 1),
            ('col_bank', 5), ('col_col', 5), ('wd', 288)],
        pi=[('r_v', 1), ('r_d', 288)], ki=[('k_v', 1), ('k_d', 32)], ko=[('k_v', 1), ('k_d', 32)]),
    qkd_ctrl_kc=dict(kc=[('kc_v', 1), ('kc_d', 32)], ko=[('k_v', 1), ('k_d', 32)]))
assert [f for f, _ in STRIP_FIELDS['qkd_ctrl_pc']['ci']] == BINDINGS['qkd_cdc_wleaf']['ports']['ho']
assert [f for f, _ in STRIP_FIELDS['qkd_ctrl_pc']['co']] == BINDINGS['qkd_cdc_wleaf']['ports']['hi']
BINDINGS['qkd_ctrl_pc'] = dict(module='qkd_ctrl_pc', file=STRIP_FILE,
    ports=dict(ci=['ci'], co=['co'], es=['es'], er=['er'], po=['po'], pi=['pi'], ki=['ki'], ko=['ko'], fi=['fi'],
               fo=['fo'], pc=['pc'], pll_hbm=['pll_hbm'], hrst=['hrst'], ck=['ck'], rsi=['rsi']), classed={})
BINDINGS['qkd_ctrl_kc'] = dict(module='qkd_ctrl_kc', file=STRIP_FILE,
    ports=dict(kc=['kc'], ko=['ko'], fi=['fi'], kf=['kf'], pll_hbm=['pll_hbm'], hrst=['hrst'], ck=['ck'],
               rsi=['rsi']), classed={})

# KV landing strip qkd_land / qkd_land_n -> 32 x qkd_land_pc (E half, one a PC slot) + 8 x qkd_land_grp (W half, one a row
# engine beside its four PCs) + 1 x qkd_land_emb (N end).  Strip slot 4 i + q hosts logical PC {q, G(i)} (LAND_GROUP_ORDER:
# i = 0 at the S end; every group then sits beside its engine's rq / rs pins).
LAND_FILE = 'rtl/qwen_sys/kv_die_20261009/qkd_land_strip.sv'
LAND_GROUP_ORDER = (4, 5, 0, 1, 2, 3, 6, 7)
STRIP_FIELDS.update(
    qkd_land_pc=dict(
        li=[('l_v', 1), ('l_sec', 17), ('l_row', 8), ('l_data', 256)], lp=[('l_pop', 1)],          # = qkd_cdc_wleaf co
        gw=[('v', 1), ('layer', 6), ('j', 10), ('data', 256)],
        es=STRIP_FIELDS['qkd_ctrl_pc']['es'], er=STRIP_FIELDS['qkd_ctrl_pc']['er'],
        dni=[('v', 1), ('kind', 1), ('bc', 1), ('pc', 5), ('side', 1), ('s_we', 1), ('w_v', 1), ('s_bank', 5),
             ('s_col', 5), ('s_row', 19), ('w_d', 256), ('tag', 2)],
        upi=[('v', 1), ('side', 1), ('tag', 2), ('e_data', 256), ('e_ce', 1), ('e_ue', 1)]),
    qkd_land_grp=dict(
        rq=[('req_valid', 1), ('req_v', 1), ('req_g', 1), ('req_t', 13)], rs=[('rsp_valid', 1), ('rsp_data', 1024)],
        lt=[('lay_start', 1), ('lay_T', 14), ('lay_idx', 6)],
        kn=[('kvw_v', 1), ('kvw_vg', 2), ('kvw_t', 14), ('kvw_layer', 6), ('kvw_d', 1024)]),
    qkd_land_emb=dict(emf=[('i_v', 1), ('i_d', 523), ('pad', 5), ('o_cr', 1)], emr=[('o_v', 1), ('o_d', 523), ('pad', 5), ('i_cr', 1)]))
assert [f for f, _ in STRIP_FIELDS['qkd_land_pc']['li']] + ['l_pop'] == BINDINGS['qkd_cdc_wleaf']['ports']['co']
assert [f for f, _ in STRIP_FIELDS['qkd_land_grp']['rq']] == BINDINGS['qkd_ectl']['ports']['rq']
BINDINGS['qkd_land_pc'] = dict(module='qkd_land_pc', file=LAND_FILE,
    ports={k: [k] for k in ('li', 'lp', 'cf', 'gw', 'gc', 'es', 'er', 'dni', 'dno', 'upi', 'upo', 'cri', 'cro', 'fi', 'fo',
                            'lpc', 'ck', 'rst_n')}, classed={})
BINDINGS['qkd_land_grp'] = dict(module='qkd_land_grp', file=LAND_FILE,
    ports={k: [k] for k in ('gw0', 'gw1', 'gw2', 'gw3', 'gc0', 'gc1', 'gc2', 'gc3', 'rq', 'rs', 'lt', 'kn', 'fi', 'fo', 'g',
                            's', 'ck', 'rst_n')}, classed={})
BINDINGS['qkd_land_emb'] = dict(module='qkd_land_emb', file=LAND_FILE,
    ports={k: [k] for k in ('emf', 'emr', 'dno', 'upi', 'cri', 'fi', 'gfi', 'mf', 'st', 'ck', 'rst_n')}, classed={})

# el1013-qwen-kvstrips 2026-10-13: the stack aggregator qkd_astk / qkd_astk_n (ot_qwen_nearhbm_attn_stack_h minus its
# engines) -> two 162 um columns of hardened leaves (ASTK_W 324 requested) (rtl/qwen_sys/kv_die_20261009/qkd_astk_leaves.sv; exact bench
# physical/qkd_astk_strip/bench.sh against the golden aggregator; die wiring = rtl/test/qwen_kv_die/
# ot_qwen_nearhbm_attn_stack_k.sv ot_qkd_astk_strip).  Per row (engines 2 r on the W, 2 r + 1 on the E; rows counted from
# the end away from the hub) and column, bottom to top: head 0 A, B; head 1 A, B; ex, ex, ep, ex, ex; head 2 A, B;
# head 3 A, B (A = level-4 tree cell, B = the row's second-level cell); 4 x qkd_astk_zn + qkd_astk_ctl at the hub end.
ASTK_FILE = 'rtl/qwen_sys/kv_die_20261009/qkd_astk_leaves.sv'
ASTK_LEAF = dict(qkd_astk_pv=(162.0, 103.68), qkd_astk_ex=(162.0, 149.04), qkd_astk_ep=(162.0, 345.6), qkd_astk_zn=(86.4, 86.4),
                 qkd_astk_ctl=(324.0, 43.2))
STRIP_FIELDS.update(
    qkd_astk_pv=dict(
        cfg=[('h', 2), ('lvl', 2), ('am', 2), ('bm', 2), ('ym', 2), ('ath', 3), ('bth', 3), ('far', 1), ('tdir', 1)],
        nc=[('v', 1), ('beat', 4), ('g', 1), ('gam', 4)],                    # = qkd_ectl so[421:412]
        li=[('v', 1), ('idx', 4), ('g', 1), ('d', 128)],                     # stream word (lo, each lane of ui / uo / di / do_)
        pi=[('v', 1), ('beat', 5), ('g', 1), ('d', 256)],                    # P.V lane word
        ci=[('start', 1), ('gmax', 5)]),
    qkd_astk_ep=dict(
        qi=[('start', 1), ('T', 14), ('q_valid', 1), ('q_beat', 6), ('q_data', 512), ('kdone', 2), ('m_v', 1), ('m_g', 1),
            ('m_hh', 2), ('m_data', 32)],
        xi=[('fault', 1), ('cnt0', 4), ('cnt1', 4), ('any', 2), ('lmax', 256)],
        zi=[('v', 1), ('tok', 1), ('g', 1), ('k', 4), ('gam', 4), ('sum', 128), ('row', 512)],
        ri=[('v', 1), ('g', 1), ('k', 4), ('gam', 4), ('row', 512)],
        xa=[('v', 1), ('pos', 1), ('s', 32), ('m', 32)] * 4, xe=[('v', 1), ('fault', 1), ('e', 32)] * 4,
        sq=[('engine', 3), ('stack', 2)]),
    qkd_astk_zn=dict(zi=[('v', 1), ('g', 1), ('k', 4), ('slot', 4), ('sum', 128)], zc=[('stack', 2), ('level', 2)],
                     tc=[('start', 1), ('T', 14)]),
    qkd_astk_ctl=dict(
        aq=[('start', 1), ('T', 14), ('layer', 6), ('q_valid', 1), ('q_beat', 6), ('q_data', 512)],
        lt=[('start', 1), ('T', 14), ('layer', 6)], am=[('v', 1), ('g', 1), ('hh', 2), ('data', 32)],
        ap=[('so_valid', 1), ('so_type', 2), ('so_g', 1), ('so_hh', 2), ('so_k', 4), ('so_any', 1), ('so_data', 32),
            ('pv_done', 2), ('pv_valid', 1), ('pv_g', 1), ('pv_beat', 6), ('pv_data', 512)]))
STRIP_FIELDS['qkd_astk_ep']['zo'] = STRIP_FIELDS['qkd_astk_ep']['zi']
STRIP_FIELDS['qkd_astk_ep']['xo'] = STRIP_FIELDS['qkd_astk_ep']['xi']
STRIP_FIELDS['qkd_astk_ctl']['qo'] = STRIP_FIELDS['qkd_astk_ep']['qi']
STRIP_FIELDS['qkd_astk_ctl']['xi'] = STRIP_FIELDS['qkd_astk_ep']['xi']
_ASTK_LANES = ('ui', 'uo', 'di', 'do_', 'pi', 'po', 'ci', 'co', 'kui', 'kuo', 'kdi', 'kdo', 'tui', 'tuo', 'tdi', 'tdo', 'fi', 'fo')
BINDINGS['qkd_astk_pv'] = dict(module='qkd_astk_pv', file=ASTK_FILE,
    ports={k: [k] for k in ('cfg', 'wa', 'wb', 'nc', 'nd', 'nco', 'ndo', 'cra', 'crb', 'li', 'lo', 'lci', 'lco', 'ck', 'rst_n')
           + _ASTK_LANES}, classed={})
BINDINGS['qkd_astk_ex'] = dict(module='qkd_astk_ex', file=ASTK_FILE,
    ports={k: [k] for k in ('xa', 'xe', 'ck', 'rst_n') + _ASTK_LANES}, classed={})
BINDINGS['qkd_astk_ep'] = dict(module='qkd_astk_ep', file=ASTK_FILE,
    ports={k: [k] for k in ('sq', 'so', 'si', 'qi', 'xi', 'xo', 'zi', 'zo', 'ri', 'xa', 'xe', 'cr', 'ck', 'rst_n') + _ASTK_LANES},
    classed={})
BINDINGS['qkd_astk_zn'] = dict(module='qkd_astk_zn', file=ASTK_FILE,
    ports={k: [k] for k in ('zc', 'tc', 'zi', 'zo', 'fi', 'fo', 'ck', 'rst_n')}, classed={})
BINDINGS['qkd_astk_ctl'] = dict(module='qkd_astk_ctl', file=ASTK_FILE,
    ports={k: [k] for k in ('st', 'aq', 'lt', 'am', 'ap', 'af', 'qo', 'xi', 'co', 'px', 'py', 'zi', 'fx', 'fy', 'fz', 'ck', 'rst_n')},
    classed={})
assert sum(w for _, w in STRIP_FIELDS['qkd_astk_ep']['qi']) == 572 and sum(w for _, w in STRIP_FIELDS['qkd_astk_ep']['zi']) == 651
assert sum(w for _, w in STRIP_FIELDS['qkd_astk_ctl']['ap']) == 565 and sum(w for _, w in STRIP_FIELDS['qkd_astk_ctl']['aq']) == 540
assert [f for f, _ in STRIP_FIELDS['qkd_astk_pv']['nc']] == ['v', 'beat', 'g', 'gam']


def astk_cfg(h, lvl=0, am=0, bm=0, ym=0, ath=0, bth=0, far=0, tdir=0):
    """qkd_astk_pv strap word (STRIP_FIELDS order, LSB first)."""
    return h | lvl << 2 | am << 4 | bm << 6 | ym << 8 | ath << 10 | bth << 13 | far << 16 | tdir << 17


def astk_plan(stack=0):
    """The strip's leaf instances in its own frame (y from the end away from the hub; N stacks: the strip is placed MX).
    Rows of (name, master, column, y, straps).  Column x = 0 (W, X cells: kk mod 4 < 2) / 162 (E, Y cells)."""
    out = []
    ph, eh, xh = ASTK_LEAF['qkd_astk_pv'][1], ASTK_LEAF['qkd_astk_ep'][1], ASTK_LEAF['qkd_astk_ex'][1]
    row_h = ENG_H + GY                       # an engine row
    used = 8 * ph + eh + 4 * xh
    assert used <= row_h, (used, row_h)
    gap = (row_h - used) / 12                # the die's relay stations stand in the gaps
    for r in range(4):
        for c in range(2):
            y = r * row_h + gap / 2
            eng = 2 * r + c

            def put(name, master, straps):
                nonlocal y
                out.append((name, master, c, round(y, 3), straps))
                y += ASTK_LEAF[master][1] + gap
            lvl_b, am_b, bm_b, ym_b = ((1, 0, 2, 1), (2, 1, 2, 1), (1, 0, 2, 2), (3, 1, 0, 0))[r]
            ath_b, bth_b = ((0, 2), (0, 4), (4, 6), (0, 0))[r]
            for hp in range(4):
                if hp == 2:
                    put(f'ex_{eng}_0', 'qkd_astk_ex', {}); put(f'ex_{eng}_1', 'qkd_astk_ex', {})
                    put(f'ep_{eng}', 'qkd_astk_ep', dict(sq=stack << 3 | eng))
                    put(f'ex_{eng}_2', 'qkd_astk_ex', {}); put(f'ex_{eng}_3', 'qkd_astk_ex', {})
                put(f'pva_{r}_{hp}_{"xy"[c]}', 'qkd_astk_pv',
                    dict(cfg=astk_cfg(hp, ym=2 if r in (1, 3) else 0, ath=2 * r, bth=2 * r + 1, far=int(hp in (0, 3)))))
                put(f'pvb_{r}_{hp}_{"xy"[c]}', 'qkd_astk_pv', dict(cfg=astk_cfg(hp, lvl_b, am_b, bm_b, ym_b, ath_b, bth_b)))
    top = 4 * row_h                          # the hub end: 237.6 um beyond the four engine rows (slot change request)
    zh = ASTK_LEAF['qkd_astk_zn'][1]
    for z in range(4):
        out.append((f'zn_{z}', 'qkd_astk_zn', z % 2, round(top + zh * (z // 2), 3), dict(zc=z << 2 | stack)))
    out.append(('ctl', 'qkd_astk_ctl', 0, round(top + 2 * zh, 3), dict(st=stack)))
    return out



def _write_tiles(m, add):
    """Opt-in candidate.  Closed ctl/leaf tiles; the explicit OR encoder remains unclosed.

    Preserve the 129.6-um attention-side relay channel.  A separate control/relay
    strip beside the leaves avoids cutting the landing placeholder; its width
    is the first tested width at which this generator routes every candidate bus.
    """
    by = {i.name: i for i in m['insts']}
    for st in STACKS:
        side = st[0]
        for pc in range(32):
            cdc = by[f'cdc_{st}_{pc}']
            cdc.master = 'qkd_cdc_wleaf'
            if m['geo'].get('kv_wq_leaf_s'):
                # The actual CDC LEF is183.72 square, not the old183.048 frame.
                # Shift the column88.56um to fit the lowest leaf inside the die.
                if side == 'E':
                    cdc.x -= 183.72-cdc.w # grow inward, preserve controller-side gap
                if m['geo'].get('split'):
                    # kvs1 real case: the bound qkd_cdc_wleaf view (183.6, its own pin residues) snapped 0.216 um toward the
                    # controller strip, which then snapped onto the PHY: keep 2.16 um of slack on the controller side
                    cdc.x += 2.16 if side == 'W' else -2.16
                cdc.w = cdc.h = 183.72
                cdc.y += 88.56
                lw = 129.6 if m['geo'].get('kv_wq_wide') else 86.4
                x = up(cdc.x + (cdc.w-lw)/2, GX)
                y = cdc.y - 183.6 - GY
                add(f'wleaf_{st}_{pc}', 'qkd_kvwq_leaf_s_w129_m' if m['geo'].get('kv_wq_mirror') else 'qkd_kvwq_leaf_s_w129' if m['geo'].get('kv_wq_wide') else 'qkd_kvwq_leaf_s', x, y, lw, 183.6,
                    'MX' if side == 'W' else 'R180', 'kv_write_leaf', 'strip')
            else:
                x = m['geo']['x_land'] if side == 'W' else m['die']['w'] - m['geo']['x_land'] - 86.4
                add(f'wleaf_{st}_{pc}', 'qkd_kvwq_leaf', x, cdc.y, 86.4-SHAVE, 183.6-SHAVE,
                    'R0' if side == 'W' else 'MY', 'kv_write_leaf', 'strip')
        land = by[f'land_{st}']
        offset = CHAN if m['geo'].get('kv_wq_leaf_s') else 86.4 + GX
        cw, ch = (216.0,648.0) if m['geo'].get('kv_wq_head') else ((172.8, 129.6) if m['geo'].get('split') else (172.8,518.4))
        cm = 'qkd_kvwq_ctl_bin_h' if m['geo'].get('kv_wq_head') else ('qkd_kvwq_ctl_bin' if m['geo'].get('kv_wq_binary') else 'qkd_kvwq_ctl')
        if m['geo'].get('split'):
            offset = 2.4 + 21.6                    # v1.2: in the CDC | landing channel (centred, 21.6 um each side)
        x = m['geo']['x_land'] + offset if side == 'W' else m['die']['w'] - m['geo']['x_land'] - offset - cw
        y = up(land.y + (land.h - ch)/2, GY)
        add(f'wctl_{st}', cm, x, y, cw-SHAVE, ch-SHAVE,
            'R0' if side == 'W' else 'MY', 'kv_write_ctl', 'strip')
        for g in range(0 if m['geo'].get('kv_wq_binary') else 4):
            ex = x if side == 'W' else x + 172.8 - 43.2
            add(f'wenc_{st}_{g}', 'qkd_kvwq_lane_encoder', ex, y - (g+1)*45.36, 43.2-SHAVE, 43.2-SHAVE,
                'R0' if side == 'W' else 'MY', 'kv_write_encoder_unclosed', 'strip')


def _write_buses(m):
    """Split ci[301:0]: write[289:0], room/done[300:290], fault[301].

    co[282:0], including l_pop, stays with the landing.  Four independent
    registered chains a stack visit PCs 8*g+7 .. 8*g N->S; lane straps pc%8.
    The feed encoder implements the exact three OR4 equations of leaves_top.
    """
    buses = []
    for bid, cl, bits, eps in m['buses']:
        if bid.startswith('cdci_'):
            st, pc = bid[5:].rsplit('_', 1)
            buses.extend([(f'ww_{st}_{pc}', 'cdc_core', 290, [(f'wleaf_{st}_{pc}', 'w'), (f'cdc_{st}_{pc}', 'wi')]),
                          (f'wr_{st}_{pc}', 'cdc_core', 11, [(f'cdc_{st}_{pc}', 'wr'), (f'wleaf_{st}_{pc}', 'wr')]),
                          (f'wcf_{st}_{pc}', 'kv_oneway' if REACH_FIX else 'cdc_core', 1,
                           [(f'cdc_{st}_{pc}', 'cf'), (f'land_{st}', f'cf{pc}')])])
                          # v1.2: the landing strip abuts the CDC column again (kvs2 T1b's 620-um cf hop is gone)
        elif bid.startswith('kvn_'):
            st = bid[4:]
            if m['geo'].get('split'):
                # v1.2: the KV write words enter the landing strip (its 8 groups' KV merge fence needs them: kn) and leave
                # it registered on kvo to the write-queue controller (+1 cycle a way on the posted-write path)
                buses.append((bid, cl, bits, [('seq', f'kvn_{st}'), (f'land_{st}', 'kvn')]))
                buses.append((f'kvo_{st}', cl, bits, [(f'land_{st}', 'kvo'), (f'wctl_{st}', 'kvn')]))
            else:
                buses.append((bid, cl, bits, [('seq', f'kvn_{st}'), (f'wctl_{st}', 'kvn')]))
        else:
            buses.append((bid, cl, bits, eps))
    m['buses'] = buses
    m['wq_straps'] = {}
    for st in STACKS:
        ctl = f'wctl_{st}'
        # v1.2 (split): the write-retire word durable has no consumer on the KV/system die (the landing strip's RTL has
        # no such port; the sequencer's kvn credit carries the flow control): unread, not wired to a frame
        if not m['geo'].get('split'):
            buses.append((f'wdurable_{st}', 'spine_local', 23, [(ctl, 'durable'), (f'land_{st}', 'wdurable')]))
        buses.append((f'wfault_{st}', 'spine_local', 1, [(ctl, 'fault'), (f'land_{st}', 'wfault')]))
        for g in range(4):
            enc = f'wenc_{st}_{g}'
            order = range(8) if m['geo'].get('kv_wq_leaf_s') else range(7, -1, -1)
            chain = [f'wleaf_{st}_{8*g+i}' for i in order]
            if m['geo'].get('kv_wq_binary'):
                buses.append((f'wencoded_{st}_{g}', 'spine_local', 293, [(ctl, f'f{g}'), (chain[0], 'c')]))
            else:
                buses += [(f'wfeed_{st}_{g}', 'spine_local', 298, [(ctl, f'f{g}'), (enc, 'a')]),
                          (f'wencoded_{st}_{g}', 'spine_local', 293, [(enc, 'b'), (chain[0], 'c')])]
            buses.append((f'wret_{st}_{g}', 'spine_local', 2, [(chain[0], 'dp'), (ctl, f'r{g}')]))
            for a, b in zip(chain, chain[1:]):
                buses += [(f'wchain_{a}', 'spine_local', 293, [(a, 'n'), (b, 'c')]),
                          (f'wback_{a}', 'spine_local', 2, [(b, 'dp'), (a, 'dn')])]
            buses.append((f'wtail_{st}_{g}', 'constant', 2, [(chain[-1], 'dn')]))
            for pc in range(8*g, 8*g+8):
                leaf = f'wleaf_{st}_{pc}'
                m['wq_straps'][f'wlane_{st}_{pc}'] = pc % 8
                buses.append((f'wlane_{st}_{pc}', 'constant', 3, [(leaf, 'lane')]))
        # qwen-1010/b 2026-10-10: the leaves and the controller join the stack's own core clock trunk and reset (one net
        # per PLL output; a second net on pll_<st> / rso_<st> was a duplicate port binding in die_top_lint)
        for bname, dstport in ((f'clk_core_{st}', 'ck'), (f'rst_core_{st}', 'rst_n')):
            k_ = next(i for i, b in enumerate(buses) if b[0] == bname)
            bid_, cl_, bits_, eps_ = buses[k_]
            buses[k_] = (bid_, cl_, bits_, list(eps_) + [(f'wleaf_{st}_{pc}', dstport) for pc in range(32)] + [(ctl, dstport)])


def strict_ports(M):
    """every RTL port of every bound master is in exactly one die port (or classed debug / by_design) and every die
    port of the master is bound.  -> dict(ok, failures, rows)."""
    import re as _re
    rows, fails = [], []
    for mst, b in BINDINGS.items():
        if mst not in M:
            continue
        # v1.1: the port-bind tool's header parser (a declaration may list several ports: 'output wire [15:0] e0, e1')
        import die_port_bind_kv as _PB
        _, hdr = _PB.header((ROOT / b['file']).read_text(), b['module'])
        rtl = set(hdr)
        bound = {}
        for dp, ps in b['ports'].items():
            for p in ps:
                bound.setdefault(p, []).append(dp)
        die = set(M[mst].order) if mst in M else set()
        for p in sorted(rtl):
            if p in bound or p in b.get('classed', {}):
                continue
            fails.append(f'{mst}: RTL port {p} has no die port')
        for p in sorted(set(bound) - rtl):
            fails.append(f'{mst}: binding names {p}, not an RTL port of {b["module"]}')
        for dp in sorted(die):
            if dp not in b['ports'] and dp not in b.get('sliced', {}):
                fails.append(f'{mst}: die port {dp} not bound to RTL')
        for dp in sorted(set(b['ports']) - die):
            fails.append(f'{mst}: bound die port {dp} absent from the abstract (no die net)')
        rows.append(dict(master=mst, module=b['module'], rtl_ports=len(rtl), die_ports=len(die),
                         classed=b.get('classed', {})))
    return dict(ok=not fails, failures=fails, rows=rows, frame_only=FRAME_ONLY)


def tpl():
    return json.loads(TPL_PATH.read_text())


def _band(T, side, Wk):
    """r21c band instances of one side, re-placed: (name, master, x, y, w, h, orient, kind, domain)."""
    I = T['insts']
    out = []
    ctrl_s, ctrl_n = I[f'ctrl_{side}S'], I[f'ctrl_{side}N']
    dy = {'S': MARGIN - ctrl_s['y'], 'N': MARGIN + ctrl_s['h'] + GY - ctrl_n['y']}
    xs = 25815.456 - Wk                                  # the r21c die width; the E band keeps its distance to E
    for n, d in I.items():
        if not (n.split('_')[1][0] == side and len(n.split('_')[1]) == 2 or n.split('_')[1] == side + 'S'
                or n.split('_')[1] == side + 'N'):
            continue
        half = n.split('_')[1][1]
        if d['kind'] == 'link_fifo':
            continue
        x = d['x'] if side == 'W' else d['x'] - xs
        master = dict(qfd_ctrl='qkd_ctrl_n' if half == 'N' else 'qkd_ctrl', qfd_cdc='qkd_cdc').get(d['master'], d['master'])
        out.append((n, master, x, d['y'] + dy[half], d['w'], d['h'], d['orient'], d['kind'], d['domain']))
    return out, dy


_PIN_HINT = {}
# Q-KVSYS-HOP 2026-10-16 (OT_KV_HOP=1; default off): hop rules calibrated on the kvs11-v143c GRT/TT run (realized named
# pins, routed wirelength; results/arch/qwen_kv_hop_1016).  (1) A frame port that kv_expand binds to a CLOSED leaf is
# reached at that leaf's realized LEF pin, not the frame face: kvs11 ctrl kc kf -> rly_lkf planned 450 um at the frame
# face, realized 558 um at the kc leaf (TT -196.7 ps).  (2) Late-launch closed views take their first relay nearer:
# ectl_a rq (R 414 ps, insertion spread 63 ps) -> rly_krq passes <= ~380 um, fails at 437-444 um (-63 ps).  (3) Relay
# chains keep every hop <= HOP_REACH (the closed standards' native self-reach: rlys_296 446 um, rlys_528 460 um).
HOP = __import__('os').environ.get('OT_KV_HOP', '0') == '1'
HOP_REACH = 445.0 if KV_REACH <= 0 else min(445.0, KV_REACH)
HOP_FIRST = dict(krq=340.0, krs=340.0)
_LEAF_PIN_CACHE = {}


def _cdc_co_y(cdc):
    """KVPLAN2 (OT_KV_REACH_FIX): die y of the centre of the CLOSED qkd_cdc_wleaf view's co pins (l_* W face, local y
    23.5..103.0 of 183.6) for CDC instance cdc, its orientation applied."""
    if 'co' not in _LEAF_PIN_CACHE:
        ys, h, cur = [], None, None
        co_ = set(BINDINGS['qkd_cdc_wleaf']['ports']['co'])      # the die 'co' word = these view (RTL) ports
        for ln in (Path(__file__).resolve().parents[2] / CDC_VIEW_LEF).read_text().split('\n'):
            t = ln.split()
            if t[:1] == ['SIZE'] and h is None:
                h = float(t[3])
            elif t[:1] == ['PIN']:
                cur = t[1].split('[')[0]
            elif t[:1] == ['RECT'] and cur in co_:
                ys.append((float(t[2]) + float(t[4])) / 2)
            elif t[:1] == ['END'] and len(t) > 1 and t[1].split('[')[0] == cur:
                cur = None
        _LEAF_PIN_CACHE['co'] = ((min(ys) + max(ys)) / 2, h)
    cy, h = _LEAF_PIN_CACHE['co']
    cy = cy * cdc.h / h
    return cdc.y + (cdc.h - cy if cdc.orient in ('MX', 'R180') else cy)


# DIE-KV-REPLACE 10-19 (kvs14r-131a7af2c-base PREP FAIL: lane reach 1 bit, rly_pinfix_af_ES_r74_1 -> seq__g_fan_2__u_fan.af
# 954 um): with the die-placed parent qkd_seq_st (OT_KV_EXPAND) the seq frame's aq / kc / af words end on the closed fan leaf
# qkd_seq_fan_s (32.4 x 108, words on its W face at y ~74, kv_expand.SEQ_S_PLAN homes; fan k = stack STACKS[k]), not on the
# frame pin the abstract drew; the pin repair placed the last relay at the frame's W corner, 950 um from the E fan.
SEQ_FAN_PIN_Y = 73.9
SEQ_FAN_HOMES = ((43.2, 259.2, 'R0'), (43.2, 129.6, 'R0'), (518.4, 259.2, 'MY'), (518.4, 129.6, 'MY'))   # = kv_expand.SEQ_S_PLAN g_fan[k]


def _seq_fan_pin(it, port):
    import os as _os
    if _os.environ.get('OT_KV_SEQ_FAN_PIN', '0') != '1' or 'qkd_seq_st' not in _os.environ.get('OT_KV_EXPAND', '').split(',') \
            or it.name != 'seq':
        return None
    mt = re.fullmatch(r'(aq|kc|af)_(WS|WN|ES|EN)', port.lstrip('*').split('[')[0])
    if not mt:
        return None
    fx, fy, o = SEQ_FAN_HOMES[STACKS.index(mt.group(2))]
    px = fx + (32.4 if o in ('MY', 'R180') else 0.0)
    py = fy + (108.0 - SEQ_FAN_PIN_Y if o in ('MX', 'R180') else SEQ_FAN_PIN_Y)
    if it.orient in ('MY', 'R180'):
        px = it.w - px
    if it.orient in ('MX', 'R180'):
        py = it.h - py
    return it.x + px, it.y + py


def _leaf_pin(it, port):
    """OT_KV_HOP: realized pin of an expanded frame's closed leaf (kc leaf of the controller strip), else None."""
    sp_ = _seq_fan_pin(it, port)
    if sp_ is not None:
        return sp_
    if not HOP or it.master not in ('qkd_ctrl', 'qkd_ctrl_n'):
        return None
    if 'kc' not in _LEAF_PIN_CACHE:
        lef = Path(__file__).resolve().parents[2] / 'physical/ref_tile/qkd_ctrl_kc/views/qkd_ctrl_kc/qkd_ctrl_kc.lef'
        pins, cur, size = {}, None, None
        for ln in lef.read_text().split('\n'):
            t = ln.split()
            if not t:
                continue
            if t[0] == 'SIZE':
                size = (float(t[1]), float(t[3]))
            elif t[0] == 'PIN':
                cur = t[1].split('[')[0]
            elif t[0] == 'RECT' and cur and cur not in pins:
                x0, y0, x1, y1 = map(float, t[1:5])
                pins[cur] = ((x0 + x1) / 2, (y0 + y1) / 2)
        _LEAF_PIN_CACHE['kc'] = (pins, size)
    pins, (lw, lh) = _LEAF_PIN_CACHE['kc']
    p = pins.get(port.lstrip('*').split('[')[0])
    if p is None:
        return None
    rev = it.master == 'qkd_ctrl'                       # kv_expand._ctrl_plan: u_kc at the strip's outer end
    cx, cy = it.w / 2 - 23.76, (0.0 if rev else it.h - 43.2)
    lx, ly = (p[0], lh - p[1]) if rev else p           # leaf MX in the reversed strip
    fx, fy = cx + lx, cy + ly                           # frame-canonical
    if it.orient in ('MY', 'R180'):
        fx = it.w - fx
    if it.orient in ('MX', 'R180'):
        fy = it.h - fy
    return it.x + fx, it.y + fy


# KV-LANDSLOT 10-18 (OT_KV_LANDSLOT=1, needs OT_KV_RLY_STD=1 + OT_KV_SEAM=1; default off = unchanged): the last relay
# station of every data run crossing core clock trees gets the LANDING frame (qkd_rly_<W>_land, kv_rly_std.LAND
# outlines), abutted to the receiving block face (kv_land_slot.py); kv_fwd_lanes.py binds qkd_landsh*_<S> there
LANDSLOT = os.environ.get('OT_KV_LANDSLOT', '0') == '1'


def build(*args, **kwargs):
    """the plan (_build_plan) + the landing-frame reservation (OT_KV_LANDSLOT)"""
    m = _build_plan(*args, **kwargs)
    # QXF-SEAMK 10-18 (TOKEN-XDIE-QWEN F6, OT_KV_BUNDLE_EQ default 1 on the static die): every static record bundle at the
    # d2d end (rx / tx slot / tx / emb / KVN writer word) reaches its consumer whole -- the shorter members get pad relays
    # at their sink end, after the pin repair (the last pass that adds stages) and before the landing slots
    import kv_bundle_eq
    if KSD.ON and kv_bundle_eq.on() and kwargs.get('split', len(args) > 7 and args[7]):
        m = kv_bundle_eq.equalize(sys.modules[__name__], m)
        # HKV-DIE 10-19: the seq KVN-arrival check, aligned after the record bundles (it composes K.rx_record)
        if os.environ.get('OT_KV_SEQ_KVN_ALIGN', '1') == '1':
            _sb = kv_bundle_eq.seq_kvn_bundle(m, {i.name: i for i in m['insts']}, KSD.ATTN_LAND)
            if _sb:
                m = kv_bundle_eq.equalize(sys.modules[__name__], m, bundles=_sb)
        print('kv die BUNDLE_EQ: ' + ', '.join(f"{n_} {r_.get('stages', r_.get('skipped'))}"
                                               for n_, r_ in m['bundle_eq']['bundles'].items())
              + f" ({len(m['bundle_eq']['added'])} pad relays)", file=sys.stderr)
    # KV-ECTL4 10-18 (coordinator 0gs (d)): one K round trip (KSD.ECTLK_RESPONSE_LAT) for every ECTL frame -- the frame's
    # hardened children carry RESPONSE_LAT / ROW_RETURN_LAT / QK_ISSUE_AGE as RTL parameters; pads on the 38-b request chain
    import kv_k_rt_eq
    if KSD.ON and kv_k_rt_eq.on() and kwargs.get('split', len(args) > 7 and args[7]):
        m = kv_k_rt_eq.equalize(sys.modules[__name__], m)
        r_ = m['k_rt_eq']
        print(f"kv die K_RT_EQ: target {r_['target']} (QK_ISSUE_AGE {r_['qk_issue_age']}), natural "
              f"{r_['natural_min']}..{r_['natural_max']}, {len(r_['added'])} pad relays", file=sys.stderr)
    if KSD.ON and kv_k_rt_eq.vport_side_eq_on() and kwargs.get('split', len(args) > 7 and args[7]):
        m = kv_k_rt_eq.equalize_vport_sides(sys.modules[__name__], m)      # KVR-DERIVE: one RT per V port
        r_ = m['vport_side_eq']
        print(f"kv die VPORT_SIDE_EQ: RT {sorted(set(r_['RT'].values()))} (tile {KSD.tile_ages()['VPORT_RT']}), "
              f"{len(r_['added'])} pad relays", file=sys.stderr)
    if KSD.ON and KSD.PVFIN and kv_k_rt_eq.pvfin_align_on() and kwargs.get('split', len(args) > 7 and args[7]):
        m = kv_k_rt_eq.equalize_pv_start(sys.modules[__name__], m)
        m = kv_k_rt_eq.equalize_pvfin_start(sys.modules[__name__], m)     # KV-PVFST: pvfin start word on the PV streams
        r_ = m.get('pvfin_align') or {}
        print(f"kv die PVFIN_ALIGN: align {r_.get('before')} -> {r_.get('after')}, pads {r_.get('pads')}",
              file=sys.stderr)
    if LANDSLOT and kwargs.get('split', len(args) > 7 and args[7]):
        if os.environ.get('OT_KV_RLY_STD', '0') != '1' or not SEAM:
            raise ValueError('OT_KV_LANDSLOT=1 needs OT_KV_RLY_STD=1 and OT_KV_SEAM=1 (landing slots are relay-standard rows '
                             'on the driver-tree chains)')
        import kv_land_slot
        m = kv_land_slot.reserve(sys.modules[__name__], m, gap=float(os.environ.get('OT_KV_LAND_GAP', kv_land_slot.LAND_GAP)))
        ls_ = m['land_slots']
        print(f"kv die LANDSLOT: {ls_['crossings']} crossing runs, tiers {ls_['tiers']}, legality {ls_['legality']}",
              file=sys.stderr)
        if ls_['legality']['overlaps'] or ls_['legality']['outside']:
            raise ValueError(f"kv die LANDSLOT: landing frames overlap / outside: {ls_['legality']}")
    return m


def _build_plan(r=R, kv_wq_leaves=False, kv_wq_binary=False, kv_wq_leaf_s=False, kv_wq_head=False, kv_wq_wide=False, kv_wq_mirror=False, split=False, reserve_static_memory=False, reserve_native_astk=False, host_v14=None, host_north=None, host_trees=None, v143=None):
    """qwen-1010/b 2026-10-10: plan actual relay chains from drawn pins."""
    if os.environ.get('OT_KV_STATIC', '0') == '1':
        raise ValueError('OT_KV_STATIC requires the explicit source-pinned --static-graph compiler join; legacy physical graph is forbidden')
    kw = dict(r=r, kv_wq_leaves=kv_wq_leaves, kv_wq_binary=kv_wq_binary, kv_wq_leaf_s=kv_wq_leaf_s, kv_wq_head=kv_wq_head,
              kv_wq_wide=kv_wq_wide, kv_wq_mirror=kv_wq_mirror, split=split)
    if host_v14 is not None:
        HOST_V14['on'] = bool(host_v14)          # v1.4 (die_top_lint --variant ...,host_v14); None keeps the CLI setting
    if host_north is not None:
        HOST_V14['north'] = bool(host_north)    # v1.4.1 (die_top_lint --variant ...,host_north)
    if v143 is not None:
        V143['on'] = bool(v143)                 # v1.4.3 (die_top_lint --variant ...,v143 / kvsys_window --v143)
    if host_trees is not None:
        HOST_V14['trees'] = bool(host_trees)    # v1.4.2 (die_top_lint --variant ...,host_trees): reset / boot relay trees
    _set_geometry(split, reserve_static_memory=reserve_static_memory, reserve_native_astk=reserve_native_astk)
    _PIN_HINT.clear()
    m = _build(**kw)
    best = None
    passes_ = []          # Q-KVSYS-HOP: every planned pass, so a pass whose pin repair fails can fall back to another
    for _ in range(3):                      # re-plan from the drawn pins; keep the pass with the fewest pin-hop violations
        M = masters(m, 1)
        nv = pin_reach(m, M)['violations']
        print(f'kv die: plan pass pin-hop violations {nv}', file=sys.stderr)
        passes_.append((nv, len(passes_), m))
        if best is None or nv < best[0]:
            best = (nv, m)
        if nv == 0:
            break
        by = {i.name: i for i in m['insts']}
        _PIN_HINT.clear()
        for bid, cl, bits, eps in m['buses']:
            for inst, port in eps:
                it_ = by[inst]
                if not it_.master.startswith('qkd_rly') and it_.master in M and port.lstrip('*') in M[it_.master].ports:
                    try:
                        _PIN_HINT[(inst, port.lstrip('*'))] = pin_xy(it_, M[it_.master], port.lstrip('*'))
                    except (TypeError, KeyError):
                        pass
        try:
            m = _build(**kw)
        except ValueError as e_:
            if split and V143['on'] and not kw.get('_narrow'):
                # v1.4.3: the full pin-hinted re-plan corners a reset-tree / slice chain in the grown groups; retry with
                # hints ONLY on the endpoints of the violating hops of the best pass (minimal perturbation)
                bad = pin_reach(best[1], masters(best[1], 1))
                ends = {e_[k_].split('.')[0] for e_ in bad.get('worst', []) for k_ in ('a', 'b')}
                keep = {k_: v_ for k_, v_ in _PIN_HINT.items() if k_[0] in ends}
                _PIN_HINT.clear(); _PIN_HINT.update(keep)
                print(f'kv die: v1.4.3 narrow re-plan ({len(keep)} hinted pins on {len(ends)} instances) after: {e_}', file=sys.stderr)
                try:
                    m = _build(**kw)
                    continue
                except ValueError as e2_:
                    e_ = e2_
            # v1.1: a pin-hinted re-plan pass can corner a relay chain (af_WN at the astk top, head 492.48): keep the best
            # earlier pass (its drawn pins and relay chains are consistent) and record why the re-plan stopped
            best[1].setdefault('geo', {})['replan_stopped'] = str(e_)
            print(f'kv die: re-plan pass stopped: {e_}', file=sys.stderr)
            break
    else:
        M = masters(m, 1)
        nv = pin_reach(m, M)['violations']
        if nv < best[0]:
            best = (nv, m)
    _PIN_HINT.clear()
    if split and best[0]:
        import kv_pin_repair
        snap_ = copy.deepcopy(best[1]) if HOP else None
        repaired = kv_pin_repair.repair(sys.modules[__name__], best[1])
        failures = pin_reach(repaired, masters(repaired, 1))
        if failures['violations'] and HOP:
            # OT_KV_HOP: the best pass's repair can be boxed in (d2d_kv fwd_* pins under the abutted UCIe PHY, first
            # relay 1,208 um west): repair the other planned passes in order of pin-hop violations
            for nv_, _, m_ in sorted(passes_, key=lambda t: t[:2]):
                if m_ is best[1] or (snap_ is not None and m_ is snap_):
                    continue
                r_ = kv_pin_repair.repair(sys.modules[__name__], m_)
                f_ = pin_reach(r_, masters(r_, 1))
                print(f'kv die: OT_KV_HOP fallback pass ({nv_} pin-hop violations) -> {f_["violations"]} after repair', file=sys.stderr)
                if not f_['violations']:
                    return r_
        if failures['violations']:
            if __import__('os').environ.get('OT_KV_FAIL_JSON'):     # KV-PLAN3: per-hop dump for classification
                json.dump(failures, open(__import__('os').environ['OT_KV_FAIL_JSON'], 'w'), indent=1, default=str)
                __import__('pickle').dump(repaired, open(__import__('os').environ['OT_KV_FAIL_JSON'] + '.pkl', 'wb'))
            raise ValueError(f"split KV die has {failures['violations']} unrepaired pin hops: {failures['worst'][:3]}")
        return repaired
    return best[1]


def _build(r=R, kv_wq_leaves=False, kv_wq_binary=False, kv_wq_leaf_s=False, kv_wq_head=False, kv_wq_wide=False, kv_wq_mirror=False, split=False):
    _args = dict(r=r, kv_wq_leaves=kv_wq_leaves, kv_wq_binary=kv_wq_binary, kv_wq_leaf_s=kv_wq_leaf_s, kv_wq_head=kv_wq_head,
                 kv_wq_wide=kv_wq_wide, kv_wq_mirror=kv_wq_mirror, split=split)
    kv_wq_wide = kv_wq_wide or kv_wq_mirror
    kv_wq_leaf_s = kv_wq_leaf_s or kv_wq_head or kv_wq_wide
    kv_wq_binary = kv_wq_binary or kv_wq_leaf_s
    kv_wq_leaves = kv_wq_leaves or kv_wq_binary
    T = tpl()
    I = T['insts']
    stack_h = I['ctrl_WS']['h']
    edge_chan = CHAN if kv_wq_leaf_s else 0.0
    # split: the engine group (4 engine columns of 4 heads + ectl) is taller than the 12.1-mm band: stack pitch sp, the band
    # centred on it (band_shift per half)
    gh_ = 4 * RENG[1] + 3 * GY
    if split and V143['on'] and not V143_CENTER:
        gh_ = 4 * V143['eng_h_v142'] + 3 * GY      # v1.4.3: groups keep the v1.4.2 bottom (no die lift); they grow up
    # 2 x CHAN of relay channel above and below each group: the S | N groups leave a 518-um channel between them (the
    # col-1 engines' KV rows krq / krs and the centre words cross the W / E stack walls there)
    # every shift is a multiple of 43.2 um (= 900 / 675 / 540 tracks of M4-5 / M6-7 / M8-9 and 160 rows): a shifted band
    # keeps the legal origin residues of its hard macros (kvs1 real case: phy_WN MY had no legal origin at a GY shift)
    LAT = 43.2
    sp = (stack_h + up(max(0.0, gh_ + 4 * CHAN - stack_h), LAT)) if split else stack_h
    if split and V143['on'] and V143_CENTER:
        # v1.4.3b: the grown groups leave the HOST tree / slice chains their N-apron and the S|N channel only with a taller
        # stack pitch (die height + 2 x this, measured by the relay allocator)
        sp += up(float(__import__('os').environ.get('OT_KV_V143_EXTRA', '0')), LAT)
    band_shift = {'S': up((sp - stack_h) / 2, LAT), 'N': up((sp - stack_h) / 2, LAT) + (sp - stack_h)}
    # split: the S engine groups reach down to the die edge, where the host SerDes PHY (2,400 wide, wider than the centre
    # column) sits: lift everything above it by d0
    d0 = up(max(0.0, SERDES[2] + GY + 2 * CHAN - (edge_chan + (sp - gh_) / 2)), LAT) if split else 0.0
    band_shift = {k: v + d0 for k, v in band_shift.items()}
    # KV-PLAN2 10-17 (HANDOFF 0cx+5 decision 1): OT_KV_SN_LIFT um (a multiple of 43.2) lifts the whole N half (N stack
    # bands, and with the die middle the hub / PV column by half of it) to grow the S|N seam channel; the die gets taller
    # by whatever the v1.4.4 PV-column growth does not already absorb (recorded in geo.sn_lift)
    band_shift['N'] += SN_LIFT
    Hk = up(2 * (MARGIN+edge_chan) + 2 * sp + GY + d0 + SN_LIFT, GY)
    Hk0 = Hk
    if split and V144:
        Hk = round(Hk + V144S['grow'], 6)   # v1.4.4: the north band (embgw and everything above it) rises with the die top
    if split and SERDES_N:
        # kvs13e: the N-edge SerDes (1,563.6 um tall) needs a relay channel under it above the N head groups
        Hk = round(Hk + float(__import__('os').environ.get('OT_KV_SERDES_N_GROW', '648')), 6)
    # x layout (W half; E mirrors)
    x_land = I['cdc_WS_0']['x'] + I['cdc_WS_0']['w'] + GX
    leaf_shift = ((518.4 if kv_wq_head else 432.0) + GX if kv_wq_leaf_s else 518.4 + GX) if kv_wq_leaves else 0.0
    x_grp = up(x_land + leaf_shift + LAND_W + CHAN, GX)
    slice_w = SLICE_W + SLICE_GAP if (split and HOST_V14['on']) else 0.0     # v1.4: the HOST slice column (CDC column | landing channel)
    x_grp += slice_w
    grp_w = 2 * RENG[0] + ASTK_W + 2 * GX
    centre_w = max(UCIE[1], FRAMES["qkd_ahub"][0]) + 4 * CHAN   # re-cut H engines are 1,953 um: the centre relay channel needs 2 x 259 (was 2 x 130)
    if split:
        centre_w = max(UCIE[1], FRAMES['qkd_ahub'][0], FRAMES['qkd_d2d'][0]) + 4 * CHAN
        if V144:
            centre_w += V144_DW       # v1.4.4: wider side relay channels beside the PV envelopes (the spine is gone)
    Wk = up(2 * (x_grp + grp_w) + centre_w, 2 * GX)
    m = dict(die=dict(w=Wk, h=Hk), insts=[], buses=[], regions=[], geo={})
    ins = m['insts']

    def add(name, master, x, y, w, h, orient='R0', kind='', region='', domain='stream_1p2'):
        it = F.Inst(name, master, round(x, 4), round(y, 4), w, h, orient, kind=kind, region=region, domain=domain)
        ins.append(it)
        return it
    band_dy = {}
    for side in ('W', 'E'):
        rows, dy = _band(T, side, Wk)
        band_dy[side] = {half:offset+edge_chan for half,offset in dy.items()}
        for n, mst, x, y, w, h, o, k, dom in rows:
            half = 'N' if y + h / 2 > MARGIN + stack_h + GY / 2 else 'S'
            add(n, mst, x, y+edge_chan+band_shift[half], w, h, o, k, 'phy' if k == 'phy' else ('ctrl' if k == 'ctrl' else 'strip'), dom)
    if split:
        for it_ in ins:
            if it_.master == 'ot_hbm3e_phy':
                it_.master = SPLIT_PHY     # v1.2: the PHY-only abstract with per-PC DFI words (no controller inside)
    ystack = {'S': MARGIN+edge_chan+band_shift['S'], 'N': MARGIN+edge_chan + stack_h + GY+band_shift['N']}
    xc = Wk / 2
    for st in STACKS:
        side, half = st[0], st[1]
        y0 = ystack[half]
        lx = x_land + leaf_shift if side == 'W' else Wk - x_land - leaf_shift - LAND_W
        if split:
            # v1.2: the landing strip abuts the CDC column (CDC co / cf and the controller strip's es / er are one hop of
            # <= 200 um; kvs2 T1 was a 450-620 um CDC -> landing hop); the write-queue controller moves beyond it
            lx = x_land + slice_w + LAND_CHAN if side == 'W' else Wk - x_land - slice_w - LAND_CHAN - LAND_W
        add(f'land_{st}', 'qkd_land_n' if st[1] == 'N' else 'qkd_land', lx, y0, LAND_W - SHAVE, stack_h - SHAVE, 'MY' if side == 'W' else 'R0',
            'land', 'strip')
        gx = x_grp if side == 'W' else Wk - x_grp - grp_w
        gh = 4 * RENG[1] + 3 * GY
        gy = up(y0 + (stack_h - gh) / 2, GY)
        if split and V143['on'] and not V143_CENTER:
            # v1.4.3b: S groups keep their v1.4.2 bottom (the SerDes corridor) and grow up into the middle; N groups rise
            # into the empty top by <= V143_N_UP and grow the rest down
            gh_old = 4 * V143['eng_h_v142'] + 3 * GY
            gy = up(y0 + (stack_h - gh_old) / 2, GY)
            if st[1] == 'N':
                gy = (up(gy + gh_old + min(V143_N_UP, gh - gh_old) - gh, GY) if V143B else gy + gh_old - gh)
        grp_y = locals().setdefault('grp_y', {})
        grp_y[st] = (gy, gy + gh)
        # qwen-1010/b 2026-10-10 (KV11 die STA: land -> ectl rs hops of ~3 mm between pins): every stack group is the
        # MIRROR of the WS group about the die's vertical axis (E stacks: aggregator MY, engines 0-3 in the column next
        # to the landing on both sides), so a shared master's pin is level with the same peer in every stack; the N
        # stacks' aggregator is its own master qkd_astk_n (hub words ap / am on the S face, toward the hub)
        add(f'astk_{st}', 'qkd_astk_n' if st[1] == 'N' else 'qkd_astk', gx + RENG[0] + GX, gy, ASTK_W - SHAVE,
            gh + (237.6 if ASTK_W > 324 else 0.0) - SHAVE,
            'MY' if side == 'E' else 'R0', 'attn_stack', 'attn')
        for e in range(r):
            col = (e // 4) if side == 'W' else 1 - e // 4      # physical column: 0 = the landing side on the W stacks
            ex = gx if col == 0 else gx + RENG[0] + ASTK_W + 2 * GX
            ey = gy + (e % 4) * (RENG[1] + GY)
            o_up, o_dn = ('R0', 'MX') if col == 0 else ('MY', 'R180')
            # split (kvs1 real case: 'qkd_rhead MX y has no legal origin'): the closed head_hs view has horizontal pins on
            # M4 AND M6, which no y-mirrored origin can put on both track grids -> v1 places every head unflipped in y
            # (R0 / MY); the heads below the control tile then face it with their N (output) face: element-queue item
            # (MY is illegal too: its vertical pins sit on M3 and M5): every split head is R0, so the col-1 heads' nb (E face)
            # faces away from the aggregator
            # v1.1: the native head frame's die-assigned pins are mirror-legal -> the TP4 orientations again
            hd_dn, hd_up = (o_dn, o_up)
            exo = up((HEAD[0] - ECTL[0]) / 2, GX) if split else 0.0     # control tile centred in the wider column
            for h in range(4):
                ft_ = split and V143['on'] and h in (1, 2)
                add(f'head_{st}_{e}_{h}', 'qkd_rhead_ft' if ft_ else 'qkd_rhead', ex, ey + TILE_Y[f'h{h}'], HEAD[0] - SHAVE,
                    (SPLIT_HEAD_FT[1] if ft_ else HEAD[1]) - SHAVE, hd_dn if h < 2 else hd_up, 'row_engine', 'attn')
            add(f'ectl_{st}_{e}', 'qkd_ectl', ex + exo, ey + TILE_Y['c'], ECTL[0] - SHAVE, ECTL[1] - SHAVE,
                o_up, 'row_engine', 'attn')
            if split and V143['on']:
                _v143_stages(add, f'{st}_{e}', ex + exo, ey, col)
    # centre column: N edge stack, hub, S edge host
    uy = Hk - MARGIN - UCIE[2]
    add('ucie_rom', UCIE[0], xc - UCIE[1] / 2, uy, UCIE[1] - SHAVE, UCIE[2] - SHAVE, 'MX', 'phy_d2d', 'io')
    dw, dh = FRAMES['qkd_d2d']
    add('d2d_kv', 'qkd_d2ds' if slice_w else 'qkd_d2d', xc - dw / 2, up(uy - GY - dh, GY), dw - SHAVE, dh - SHAVE, 'R0', 'd2d', 'io')
    sw, sh = FRAMES['qkd_seq']
    sy = up(uy - 2 * GY - dh - sh, GY)
    if split:
        # qkd_lnk abuts the KV end (its rf / tf faces = the KV end's r / t faces); the sequencer below it
        lw_, lh_ = FRAMES['qkd_lnk']
        ly = up(uy - GY - dh, GY) - GY - lh_
        add('lnk', 'qkd_lnk', xc - lw_ / 2, up(ly - GY, GY), lw_ - SHAVE, lh_ - SHAVE, 'R0', 'd2d', 'io')
        sy = up(ly - 2 * GY - sh - 4 * CHAN, GY)
    hy_north = None
    if split and HOST_V14['on'] and HOST_V14.get('north'):
        # v1.4.1 HOST-north: the root core one relay channel below the D2D end, the sequencer / gateway one more relay
        # channel pair below it (the root's 32 slice-chain words + SerDes FDI + D2D service words need an apron)
        th_ = FRAMES['qkd_host'][1]
        hy_north = up(uy - GY - dh, GY) - CHAN - th_
        hy_north -= hy_north % GY
        # KV-PLAN3 10-17: OT_KV_CTL_BAND um (multiple of 43.2) widens the sequencer <-> HOST-root gap that holds the static
        # control tile kvs_ctl: with 2 CHAN the tile left ~43-um slots either side and the stack roots' 299-b embedding
        # returns (hroot.o_emb -> kvs_emb) found no relay spot crossing it (q1814_432: (6512, 25801))
        sy = min(sy, hy_north - 2 * CHAN - CTL_BAND - sh)
        sy -= sy % GY
    add('seq', 'qkd_seq', xc - sw / 2, sy, sw - SHAVE, sh - SHAVE, 'R0', 'seq', 'ctl')
    gw_, gh_ = FRAMES['qkd_embgw']
    add('embgw', 'qkd_embgw', xc - gw_ / 2, up(sy - GY - gh_, GY), gw_ - SHAVE, gh_ - SHAVE, 'R0', 'embgw', 'ctl')
    cw_, ch_ = FRAMES['qkd_ckbump']
    add('ckb_kv', 'qkd_ckbump', xc - UCIE[1] / 2 - cw_ - 10 * GX, Hk - MARGIN - ch_, cw_ - SHAVE, ch_ - SHAVE, 'R0', 'bump', 'io')
    pw, ph = FRAMES['qkd_pll']
    add('pll', 'qkd_pllm' if slice_w else 'qkd_pll', xc + UCIE[1] / 2 + GX * 10, Hk - MARGIN - ph, pw - SHAVE, ph - SHAVE, 'R0', 'pll', 'io')
    hw, hh = FRAMES['qkd_ahub']
    add('ahub', 'qkd_ahub', xc - hw / 2, up(Hk0 / 2 - hh / 2, GY) - (V144S['ahub_dy'] if split and V144 else 0.0),
        hw - SHAVE, hh - SHAVE, 'R0', 'attn_hub', 'attn')
    if split and SERDES_N:
        _pl = next(i for i in ins if i.name == ('ckb_kv' if __import__('os').environ.get('OT_KV_SERDES_N_SIDE', 'E') == 'W' else 'pll'))
        _sx = (_pl.x - 10 * GX - SERDES[1]) if _pl.name == 'ckb_kv' else (_pl.x + _pl.w + 10 * GX)
        add('serdes_host', SERDES[0], up(_sx, GX), Hk - MARGIN - SERDES[2], SERDES[1] - SHAVE,
            SERDES[2] - SHAVE, 'R0', 'phy_host', 'io', 'link_serdes')
    else:
        add('serdes_host', SERDES[0], xc - SERDES[1] / 2, MARGIN, SERDES[1] - SHAVE, SERDES[2] - SHAVE, 'R0', 'phy_host',
            'io', 'link_serdes')
    tw, th = FRAMES['qkd_host']
    if slice_w and HOST_V14.get('north'):
        # v1.4.1 (owner/coordinator 10-15): the HOST root core sits directly below the static D2D end, in the slot the
        # removed bridge qkd_lnk left above the sequencer.  The compiled token loop HOST <-> D2D (svc / lup / rec_tx /
        # rec_rx / lrc) and HOST <-> seq (hc / tk) become local; the SerDes FDI (elastic host link, owner 0az: flow
        # control kept at the host interface) carries the long haul to the S-edge PHY instead.
        add('host', 'qkd_host_rt', xc - tw / 2, hy_north, tw - SHAVE, th - SHAVE, 'R0', 'host', 'io')
    else:
        add('host', 'qkd_host_rt' if slice_w else 'qkd_host', xc - tw / 2, MARGIN + SERDES[2] + GY, tw - SHAVE, th - SHAVE, 'R0', 'host', 'io')
    pv_geo, m_keep = None, []
    if split and V144:
        if not V143['on'] or not V143C:
            raise ValueError('v1.4.4 (OT_KV_V144=1) is defined on the v1.4.3c geometry: needs --v143 and OT_KV_V143C=1')
        byc = {i.name: i for i in ins}
        ah_, eg_, sd_ = byc['ahub'], byc['embgw'], byc['serdes_host']
        hc_ = PVT_HUB_CLEAR if PV_T else PV_CLEAR      # KVPLAN2 2215: a relay channel between the hub and each pair's strip
        n_lo, n_hi = ah_.y + ah_.h + hc_, eg_.y - max(PV_CLEAR, V144_APRON)
        s_lo, s_hi = (MARGIN if SERDES_N else sd_.y + sd_.h) + PV_CLEAR, ah_.y - hc_
        if not V144S['resolved']:
            # measured shortfall of the north home -> hub shift south (while the south envelope fits) + die growth
            short = PVW[1] - (n_hi - n_lo)
            dy_, gr_ = 0.0, 0.0
            short_s = PVW[1] - (s_hi - s_lo)
            if PV_T and short_s > 0:
                # KVPLAN 1815: the trunked pair is taller than the south room too: the hub moves NORTH by the south
                # shortfall and the die grows by both shortfalls (the north band rises with it)
                dy_ = -up(short_s, LAT)
                gr_ = up(max(0.0, short) - dy_, LAT)
                V144S.update(resolved=True, ahub_dy=round(dy_, 6), grow=round(gr_, 6), north_short_um=round(short, 3),
                             south_short_um=round(short_s, 3), mode='pv_t_grow_both')
                return _build(**_args)
            if short > 0:
                if V144_MODE == 'ahub':
                    spare_s = (s_hi - s_lo) - PVW[1]
                    dy_ = min(up(short, LAT), math.floor(max(0.0, spare_s) / LAT + 1e-9) * LAT,
                              math.floor(V144_AHUB_MAX / LAT + 1e-9) * LAT)
                gr_ = up(max(0.0, short - dy_), LAT)
            V144S.update(resolved=True, ahub_dy=round(dy_, 6), grow=round(gr_, 6), north_short_um=round(short, 3),
                         mode=V144_MODE)
            if dy_ or gr_:
                return _build(**_args)
        x_ = up(xc - PVW[0] / 2, GX)
        # the S envelope sits at the TOP of its room (strip at the hub): every um of spare goes to the band under it, where
        # the HOST FDI and the S-band chains cross from the side channels to the SerDes / gateway pins
        y_s = math.floor((s_hi - PVW[1]) / GY + 1e-9) * GY
        y_n = up(n_lo, GY)
        if y_s < s_lo - 1e-6 or y_n + PVW[1] > n_hi + 1e-6:
            raise ValueError(f'v1.4.4 PV envelope does not fit: south {s_lo:.1f}..{s_hi:.1f}, north {n_lo:.1f}..{n_hi:.1f}, '
                             f'need {PVW[1]} (state {V144S})')
        add('pvw_0', 'qkd_pvw_s', x_, y_s, PVW[0] - SHAVE, PVW[1] - SHAVE, 'R0', 'pv_pair', 'attn')
        add('pvw_1', 'qkd_pvw_n', x_, y_n, PVW[0] - SHAVE, PVW[1] - SHAVE, 'MX', 'pv_pair', 'attn')
        lft = max(i.x + i.w for i in ins if i.x + i.w < xc - PVW[0] / 2 and i.y < Hk - 2000 and i.y > 2000
                  and not i.name.startswith(('pvw', 'ahub')))
        rgt = min(i.x for i in ins if i.x > xc + PVW[0] / 2 and i.y < Hk - 2000 and i.y > 2000
                  and not i.name.startswith(('pvw', 'ahub')))
        pv_geo = dict(mode=V144S.get('mode'), north_shortfall_um=V144S.get('north_short_um'), ahub_dy_um=V144S['ahub_dy'],
                      die_growth_um=V144S['grow'], centre_widening_um=V144_DW,
                      die_area_delta_mm2=round((Wk * Hk - (Wk - V144_DW) * (Hk - V144S['grow'])) / 1e6, 4),
                      envelope_um=list(PVW), array_um=list(PV_ARR), strip_um=PV_STRIP,
                      pvw_0=dict(xy=[x_, y_s], orient='R0', stacks=['WS', 'ES'], band_under_um=round(y_s - (byc['serdes_host'].y + byc['serdes_host'].h), 3),
                                 south_room_um=[round(s_lo, 3), round(s_hi, 3)]),
                      pvw_1=dict(xy=[x_, y_n], orient='MX', stacks=['WN', 'EN'], north_room_um=[round(n_lo, 3), round(n_hi, 3)]),
                      centre_column_um=[round(lft, 3), round(rgt, 3), round(rgt - lft, 3)],
                      side_channel_um=[round(x_ - lft, 3), round(rgt - x_ - PVW[0], 3)],
                      spare_over_259_2_um=[round(x_ - lft - 2 * CHAN, 3), round(rgt - x_ - PVW[0] - 2 * CHAN, 3)])
        if PV_T:
            # KVPLAN 1815: the 16 V word forks (qkd_pvfork, one register stage of 4 closed qkd_rlys_296): one 1055-b chain
            # vport -> fork beside its pair's control strip, then the header and 8 GS chunks fan out from there
            fw_, fh_ = PVFORK
            for pi_, (pn_, py_, por_) in enumerate((('pvw_0', y_s, 'R0'), ('pvw_1', y_n, 'MX'))):
                sts_ = ('WS', 'ES') if pi_ == 0 else ('WN', 'EN')
                for st in sts_:
                    for k in range(4):
                        # KVPLAN2 2215: PVFORK_GAP (default PV_CLEAR 21.6) to the pair face and between forks -- an
                        # 86.4-um slit (716c347f4) let shortest paths squeeze between the pair and the forks where no relay
                        # fits (kvs13l plan: emr_ES / kvn_ES / aq_ES / ap_ES 'no spot' at the fork column)
                        fx_ = up(x_ - PVFORK_GAP - fw_, GX) if st[0] == 'W' else up(x_ + PVW[0] + PVFORK_GAP, GX)
                        # KVPLAN2 2215: fork k level with its header pin (strip end), the taps level with their group's
                        # face pins, all in one column PVFORK_GAP off the face
                        yh_ = PVW[1] - PVT_HDR_Y0 - PVT_FORK_PITCH * k
                        fy_ = py_ + (yh_ if por_ == 'R0' else PVW[1] - yh_) - fh_ / 2
                        add(f'pvfork_{st}_{k}', 'qkd_pvfork', fx_, up(fy_, GY), fw_ - SHAVE, fh_ - SHAVE, pvt_orient(st), 'relay', 'attn')
                        for g in PVT_TAPS:
                            tw_, th_ = pvtap_frame(g)
                            tx_ = up(x_ - PVFORK_GAP - tw_, GX) if st[0] == 'W' else up(x_ + PVW[0] + PVFORK_GAP, GX)
                            # port 0 highest: equal fork -> tap 7 runs; every tap PVT_TAP_DY below its face pin (away from the
                            # strip: room between the fork column and group 7's taps for the four first stages)
                            yc_ = pvt_plan()['face_pins']['vc'][f'vc{k}_{g}'][1] + PVT_ORD * (1.5 - k) * PVT_PIN_DY - PVT_TAP_DY
                            ty_ = py_ + (yc_ if por_ == 'R0' else PVW[1] - yc_) - th_ / 2
                            add(f'pvtap_{st}_{k}_{g}', f'qkd_pvtap{pvtap_n(g)}', tx_, up(ty_, GY), tw_ - SHAVE, th_ - SHAVE, pvt_orient(st), 'relay', 'attn')
        # the 16 V ports qkd_pv16_vport (Q-VMWB r5, the V issuer): port k of stack st serves landing groups {k, 0} / {k, 1}
        # (vport_wiring.txt: groups 2k / 2k + 1, adjacent strip slots, LAND_GROUP_ORDER) -> its home is the landing-inner
        # channel (landing | engine group) level with the middle of ITS two groups, so the V get / rsp words (RT) cross
        # only the channel; the pair request / V word (WP / output) run the corridor + side channel to the centre.
        # Static landing groups slg_<st>_<g> (OT_KV_STATIC, Q-KVSYS-DIE) give the group centres when present.
        homes = {}
        for st in STACKS:
            ld_ = byc[f'land_{st}']
            if st[0] == 'W':
                c0 = ld_.x + ld_.w
                c1 = min(i.x for i in ins if i.name.startswith(f'head_{st}_'))
            else:
                c1 = ld_.x
                c0 = max(i.x + i.w for i in ins if i.name.startswith(f'head_{st}_'))
            vx = up(c0 + (c1 - c0 - PV_VPORT[0]) / 2, GX)
            for k_ in range(4):
                ys_ = []
                for g_ in (2 * k_, 2 * k_ + 1):
                    sg_ = byc.get(f'slg_{st}_{g_}')
                    ys_.append(sg_.y + sg_.h / 2 if sg_ is not None else
                               ld_.y + KS.PC_PITCH * (4 * LAND_GROUP_ORDER.index(g_) + 2))
                vy = up(sum(ys_) / 2 - PV_VPORT[1] / 2, GY)
                nm_ = f'vport_{st}_{k_}'
                add(nm_, 'qkd_pv16_vport', vx, vy, PV_VPORT[0] - SHAVE, PV_VPORT[1] - SHAVE, 'R0' if st[0] == 'W' else 'MY',
                    'vport', 'attn')
                homes[nm_] = dict(xy=[round(vx, 4), round(vy, 4)], size=list(PV_VPORT), channel_um=[round(c0, 3), round(c1, 3)],
                                  groups=[2 * k_, 2 * k_ + 1], group_y_um=[round(y_, 3) for y_ in ys_],
                                  pair=STACKS.index(st) % 2, pair_port=k_ + (4 if st[0] == 'E' else 0))
        pv_geo['vport_homes'] = homes
        pv_geo['vport_status'] = ('INSTANTIATED qkd_pv16_vport (r5 RTL): pr / vo wired to the pair; vq / i faces wired to '
                                  'slg_<st>_<g> only under OT_KV_STATIC (static landing); else DECLARED OPEN (the credit '
                                  'qkd_land_strip has no V get / rsp_t face; never fed from its legacy rs)')
    # v1.2 candidate lanes are OFF by default (kvs2 T2 try: window fine H 1.37 -> 1.25, coarse 1.32 -> 1.17 H but 0.80 -> 1.10 V,
    # lx 1 -> 2 stages, one re-plan reach miss): OT_KV_LANES=1 turns them on for the next revision's work
    m['geo'] = dict(grp_y=grp_y, split=split, land_width_um=LAND_W, static_memory_reservation=LAND_W > 172.8, lanes=bool(split and __import__('os').environ.get('OT_KV_LANES', '2') in ('1', '2')), stack_pitch=sp, band_shift=band_shift, x_land=x_land, x_grp=x_grp, grp_w=grp_w, centre_w=centre_w, stack_h=stack_h, band_dy=band_dy,
                    ystack=ystack, slice_w=slice_w, host_v14=bool(slice_w), r=r, kv_wq_leaves=kv_wq_leaves, kv_wq_binary=kv_wq_binary, kv_wq_leaf_s=kv_wq_leaf_s, leaf_shift=leaf_shift, edge_channel=edge_chan, kv_wq_head=kv_wq_head, kv_wq_wide=kv_wq_wide, kv_wq_mirror=kv_wq_mirror)
    if pv_geo:
        m['geo']['pv144'] = pv_geo
    if SN_LIFT:
        m['geo']['sn_lift'] = dict(lift_um=SN_LIFT, die_h_um=Hk, die_w_um=Wk)
    m['keepouts'] = m_keep
    if kv_wq_leaves:
        _write_tiles(m, add)
    if slice_w:
        _host_slices(m, add)
    _buses(m, T, r)
    if kv_wq_leaves:
        _write_buses(m)
    if slice_w:
        _host_v14_buses(m)
    if KSD.ON and split:
        KSD.inject(m, sys.modules[__name__])     # KVJ-G2: the static subsystem replaces the credit write / landing
    _relays(m)
    m['regions'] = _regions(m)
    m['die']['mm2'] = round(Wk * Hk / 1e6, 3)
    return m


def _v143_stages(add, se, cx, ey, col):
    """v1.4.3 G3S2 die-level stage instances of one row engine (ECTL at x cx, y ey + TILE_Y['c']; col 1 = MY column).
    ECTL-local x of V143_X; lower side (pair 0, heads 0 / 1 below) rows k = 1..4 at 28.08 pitch under the ECTL, upper
    side (pair 1) mirrored above it; the far head's T2 / S1 in the band at the far head's front face."""
    cy = ey + TILE_Y['c']
    def put(name, mst, xl, y, lower):
        w, h = HGS if mst == 'qkd_hgs' else HSS
        x = cx + (ECTL[0] - xl - w if col == 1 else xl)
        o = ('R180' if col == 1 else 'MX') if lower else ('MY' if col == 1 else 'R0')
        add(f'hst_{se}_{name}', mst, round(x, 4), round(y, 4), w - SHAVE, h - SHAVE, o, 'head_stage', 'attn')
    for lower, near, far in ((True, 1, 0), (False, 2, 3)):
        row = (lambda k: cy - V143_ROW * k) if lower else (lambda k: cy + ECTL[1] + V143_GAP + V143_ROW * (k - 1))
        if V143D:
            put(f'{near}_g', 'qkd_hgs', 172.8, row(1), lower)
            put(f'{far}_g', 'qkd_hgs', 183.6, row(2), lower)
            put(f'{near}_t1', 'qkd_hgs', -162.0, row(2), lower)
            put(f'{near}_t2', 'qkd_hgs', 32.4, row(3), lower)
            put(f'{near}_s1', 'qkd_hss', 480.6, row(3), lower)
            put(f'{near}_s2', 'qkd_hss', 540.0, row(3), lower)
        elif V143C:
            put(f'{near}_g', 'qkd_hgs', 54.0, row(1), lower)
            put(f'{far}_g', 'qkd_hgs', 405.0, row(1), lower)
            put(f'{near}_t1', 'qkd_hgs', -216.0, row(2), lower)
            put(f'{near}_t2', 'qkd_hgs', 135.0, row(2), lower)
            put(f'{near}_s1', 'qkd_hss', 480.6, row(2), lower)
            put(f'{near}_s2', 'qkd_hss', 540.0, row(2), lower)
        else:
            put(f'{near}_g', 'qkd_hgs', V143_X['g'], row(1), lower)
            put(f'{far}_g', 'qkd_hgs', V143_X['g'], row(2), lower)
            put(f'{near}_t1', 'qkd_hgs', V143_X['t1n'], row(3), lower)
            put(f'{near}_s2', 'qkd_hss', V143_X['s2n'], row(3), lower)
            put(f'{near}_t2', 'qkd_hgs', V143_X['t2n'], row(4), lower)
            put(f'{near}_s1', 'qkd_hss', V143_X['s1n'], row(4), lower)
        if lower:
            yf = ey + HEAD[1] + (21.6 if V143B else 5.4)              # far head 0 top + gap
        else:
            yf = ey + TILE_Y['h2'] + SPLIT_HEAD_FT[1] + (21.6 if V143B else 5.4)   # near head 2 top + gap
        put(f'{far}_t2', 'qkd_hgs', V143_X['t2f'], yf, lower)
        put(f'{far}_s1', 'qkd_hss', V143_X['s1f'], yf, lower)


def _v143_buses(add, st, e, c_):
    """v1.4.3 G3S2 head data path of one row engine (replaces tp / te / ts): ECTL t{pr} -> G (both heads of the pair) ->
    T1 -> T2 -> head ti / e; head s -> S1 -> S2 -> ECTL s{h}; the far head's T1 / S2 are its near head's ft leaves."""
    se = f'{st}_{e}'
    hs = lambda h, x: f'hst_{se}_{h}_{x}'
    hd = lambda h: f'head_{st}_{e}_{h}'
    for pr, near, far in ((0, 1, 0), (1, 2, 3)):
        add((f'tp_{se}_{pr}', 'stack_local', T_PAIR, [(c_, f't{pr}'), (hs(near, 'g'), 'ti_a'), (hs(far, 'g'), 'ti_a')]))
        for h in (near, far):
            nf_ = h == far
            t1_in = (hd(near), 'ft_ti_a') if nf_ else (hs(h, 't1'), 'ti_a')
            t1e_in = (hd(near), 'ft_e_a') if nf_ else (hs(h, 't1'), 'e_a')
            t1_out = (hd(near), 'ft_ti_b') if nf_ else (hs(h, 't1'), 'ti_b')
            t1e_out = (hd(near), 'ft_e_b') if nf_ else (hs(h, 't1'), 'e_b')
            add((f'te_{se}_{h}', 'stack_local', T_E, [(c_, f'e{h}'), (hs(h, 'g'), 'e_a')]))
            add((f'tg_{se}_{h}', 'stack_local', T_PAIR, [(hs(h, 'g'), 'ti_b'), t1_in]))
            add((f'tge_{se}_{h}', 'stack_local', T_E, [(hs(h, 'g'), 'e_b'), t1e_in]))
            add((f'tt_{se}_{h}', 'stack_local', T_PAIR, [t1_out, (hs(h, 't2'), 'ti_a')]))
            add((f'tte_{se}_{h}', 'stack_local', T_E, [t1e_out, (hs(h, 't2'), 'e_a')]))
            add((f'th_{se}_{h}', 'stack_local', T_PAIR, [(hs(h, 't2'), 'ti_b'), (hd(h), 'ti')]))
            add((f'the_{se}_{h}', 'stack_local', T_E, [(hs(h, 't2'), 'e_b'), (hd(h), 'e')]))
            add((f'ts_{se}_{h}', 'stack_local', T_RET, [(hd(h), 's'), (hs(h, 's1'), 's_a')]))
            s2_in = (hd(near), 'ft_s_a') if nf_ else (hs(h, 's2'), 's_a')
            s2_out = (hd(near), 'ft_s_b') if nf_ else (hs(h, 's2'), 's_b')
            add((f'tss_{se}_{h}', 'stack_local', T_RET, [(hs(h, 's1'), 's_b'), s2_in]))
            add((f'tsr_{se}_{h}', 'stack_local', T_RET, [s2_out, (c_, f's{h}')]))


def _pv144_buses(m, add):
    """v1.4.4: V port <-> PV pair words (one relay chain a word) and, with the static landing (slg_<st>_<g>, OT_KV_STATIC),
    V port <-> landing group V get / rsp.  Port k of stack st = pair (STACKS index % 2) port wp = k + 4 (E stacks)."""
    names = {i.name for i in m['insts']}
    for st in STACKS:
        pv_ = f'pvw_{STACKS.index(st) % 2}'
        for k in range(4):
            vp, wp = f'vport_{st}_{k}', k + (4 if st[0] == 'E' else 0)
            add((f'pvrq_{st}_{k}', 'kv_oneway', 15, [(pv_, f'vrq{wp}'), (vp, 'pr')]))
            if PV_T:
                fk_ = f'pvfork_{st}_{k}'
                add((f'pvin_{st}_{k}', 'kv_oneway', 1055, [(vp, 'vo'), (fk_, 'vi')]))
                add((f'pvh_{st}_{k}', 'kv_oneway', 31, [(fk_, 'vh'), (pv_, f'vh{wp}')]))
                tp_ = lambda g_: f'pvtap_{st}_{k}_{g_}'      # noqa: E731
                for tr_, top_ in (('b', 7), ('a', 3)):
                    add((f'pvt{tr_}_{st}_{k}_{top_}', 'kv_oneway', 512, [(fk_, f'vt{tr_}'), (tp_(top_), 'ti')]))
                    for g in (top_ - 1, top_ - 2):
                        add((f'pvt{tr_}_{st}_{k}_{g}', 'kv_oneway', 128 * pvtap_n(g), [(tp_(g + 1), 'to'), (tp_(g), 'ti')]))
                for g in PVT_TAPS:
                    add((f'pvc_{st}_{k}_{g}', 'kv_oneway', 128, [(tp_(g), 'tc'), (pv_, f'vc{wp}_{g}')]))
                for g in (4, 0):
                    add((f'pvc_{st}_{k}_{g}', 'kv_oneway', 128, [(tp_(g + 1), 'to'), (pv_, f'vc{wp}_{g}')]))
            else:
                add((f'pvin_{st}_{k}', 'kv_oneway', 1055 if V144_R6 else 1039, [(vp, 'vo'), (pv_, f'vin{wp}')]))
            for g in (0, 1):
                sg = f'slg_{st}_{2 * k + g}'
                if sg not in names:
                    continue          # credit landing: vq / i stay declared open (never fed from the legacy rs)
                add((f'pvvq_{st}_{k}_{g}', 'kv_oneway', 15, [(vp, f'vq{g}'), (sg, 'vreq')]))
                for i_, (bid, cl, bits, eps) in enumerate(m['buses']):
                    if eps and eps[0] == (sg, 'rsp'):
                        m['buses'][i_] = (bid, cl, bits, list(eps) + [(vp, f'i{g}')])   # rsp: K consumer + this port
                        break
                else:
                    add((f'pvrs_{st}_{k}_{g}', 'kv_oneway', 1056 if V144_R6 else 1040, [(sg, 'rsp'), (vp, f'i{g}')]))


def _buses(m, T, r):
    B = m['buses']
    names = {i.name for i in m['insts']}
    # r21c band buses (dfi, PHY <-> controller <-> CDC, CDC core sides <-> landing, HBM clocks / resets), renamed
    for bid, cl, bits, eps in T['buses']:
        ne = [(('land_' + i.split('_')[1]) if i.startswith('lfifo_') else i, p) for i, p in eps]
        if m['geo'].get('split') and cl == 'phy_dfi':
            continue          # v1.2: per-PC DFI words (below) between the controller strip's leaves and the PHY abstract
        if all(i in names for i, _ in ne):
            B.append((bid, cl, bits, ne))
    add = B.append
    cdcs = {st: [i.name for i in m['insts'] if i.name.startswith(f'cdc_{st}_')] for st in STACKS}
    # clocks (PLL core trunks a stack group + the centre) and resets
    for st in STACKS:
        sp_ = m['geo'].get('split')
        grp = ([(f'land_{st}', c_) for c_ in KS.LAND_CLK] + [(f'astk_{st}', c_) for c_ in KS.ASTK_CLK] if sp_ else
               [(f'land_{st}', 'ck'), (f'astk_{st}', 'ck')]) + \
              [(f'ectl_{st}_{e}', c_) for e in range(r) for c_ in (ECTL_CLK if sp_ else ['ck'])] + \
              [(f'head_{st}_{e}_{h}', c_) for e in range(r) for h in range(4) for c_ in (HEAD_CLK if sp_ else ['ck'])] + \
              ([(f'head_{st}_{e}_{h}', c_) for e in range(r) for h in (1, 2) for c_ in ('ck_ft_t', 'ck_ft_s')] +
               [(i.name, 'ck') for i in m['insts'] if i.name.startswith(f'hst_{st}_')] if sp_ and V143['on'] else []) + \
              [(c, 'clk') for c in cdcs[st]] + \
              [(i.name, 'ck') for i in m['insts'] if i.name.startswith(f'vport_{st}_')]   # v1.4.4 V ports: stack clock / reset
        add((f'clk_core_{st}', 'clock_trunk', 1, [('pll', f'pll_{st}')] + grp +
             [(f'ctrl_{st}', 'ck')]))   # qwen-1010/b: the kc stream-command FIFO's write side (reset: rsi, below)
        add((f'rst_core_{st}', 'reset', 1, [('pll', f'rso_{st}'), (f'ctrl_{st}', 'rsi')] +
             [(n, 'rst_n') for n in dict.fromkeys(n for n, _ in grp) if not n.startswith(('cdc_', 'hst_'))]))   # v1.4.3 stages: no reset   # the CDC core resets come from land.crst (r21c rst_kv)
    cen = ['d2d_kv', 'seq', 'embgw', 'ahub', 'host'] + (['lnk'] if m['geo'].get('split') else [])
    # v1.4.4: the two PV pairs = centre-clock groups, one entry per column (col_clk[s] -> its 9 tiles) + the control tile
    cen += [i.name for i in m['insts'] if i.master.startswith('qkd_pvw')]
    if m['geo'].get('pv144'):
        _pv144_buses(m, add)
    add(('clk_core_c', 'clock_trunk', 1, [('pll', 'pll_c')] +
         [(n, c_) for n in cen for c_ in (AHUB_CLK if (n == 'ahub' and m['geo'].get('split')) else
                                         PVW_CLK if n.startswith('pvw_') else ['ck'])] +
         [('ucie_rom', 'clk'), ('serdes_host', 'clk')] +
         [(i.name, 'ck') for i in m['insts'] if i.master == 'qkd_pvfork' or i.master.startswith('qkd_pvtap')]))   # KVPLAN 1815: the V word forks (no reset)
    add(('rst_core_c', 'reset', 1, [('pll', 'rso_c')] + [(n, 'rst_n') for n in cen] +
         [('ucie_rom', 'rst_n'), ('serdes_host', 'rst_n')]))
    add(('pll_fwd', 'clock_trunk', 1, [('pll', 'pll_fwd'), ('ckb_kv', 'pll_ck')]))       # to the clock bump pair
    add(('rst_fwd', 'reset', 1, [('pll', 'rso_fwd'), ('ckb_kv', 'rs')]))
    # the link
    add(('d2d_fdi', 'd2d_fdi', FDI_UCIE, [('d2d_kv', 'fdi'), ('ucie_rom', 'fdi')]))
    split = m['geo'].get('split')
    lend = 'lnk' if split else 'seq'
    add(('d2d_dn', 'd2d_face', 4 * (W + 1) + 4, [('d2d_kv', 'rf'), (lend, 'rf')]))       # CTL Q KVN EMBQ + credits back
    add(('d2d_up', 'd2d_face', 3 * (W + 1) + 3, [(lend, 'tf'), ('d2d_kv', 'tf')]))       # RES EMBD HCTL/SCTL + credits back
    if split:
        # LINK.md: the bridge <-> sequencer ROM-side faces (x3 {v, tag 11, d 512}, sd 56, kvd 44, ar credit) and back (ar
        # {v, 519}, ds 187, pw 75, x3 credit)
        add(('lx', 'spine_local', 1 + 11 + 512 + 56 + 44 + 1, [('lnk', 'lx'), ('seq', 'lx')]))
        add(('lr', 'spine_local', 1 + 519 + 187 + 75 + 1, [('seq', 'lr'), ('lnk', 'lr')]))
    if split:
        # Q-KVSYS-NETLIST 2026-10-16 (strict bit-level bind): the landing / attention strips' stack index st[1:0] (the
        # gateway contract: 'the landing strip's stack strap st must be the same index' = STACKS order) was a 'classed'
        # port with no die net -> an UNCONNECTED functional input of qkd_land_strip_s / qkd_astk_strip_s.  It is a die-top
        # strap like the slices' lpc: one 2-b constant net a strip, tie cells at its pin (die_constant_cells.tcl).
        ties_ = m.setdefault('host_ties', {})
        for st in STACKS:
            for f_ in ('land', 'astk'):
                add((f'stid_{f_}_{st}', 'constant', 2, [(f'{f_}_{st}', 'st')]))
                ties_[f'stid_{f_}_{st}'] = (2, STACKS.index(st))
    # attention
    for st in STACKS:
        add((f'aq_{st}', 'spine_local', 1 + 14 + 6 + 1 + 6 + 512, [('seq', f'aq_{st}'), (f'astk_{st}', 'aq')]))
        add((f'lt_{st}', 'spine_local', 1 + 14 + 6, [(f'astk_{st}', 'lt'), (f'land_{st}', 'lt')]))   # layer start / T / index -> the KV merge fence
        add((f'ap_{st}', 'spine_local', 42 + 521, [(f'astk_{st}', 'ap'), ('ahub', f'ap_{st}')]))
        add((f'am_{st}', 'spine_local', 36, [('ahub', f'am_{st}'), (f'astk_{st}', 'am')]))
        for e in range(r):
            c_ = f'ectl_{st}_{e}'
            ae = _astk_engine(e)          # OT_KV_ECTL_PAIR: frame e runs logical engine ae (astk port ae, strap sq = ae)
            add((f'eq_{st}_{e}', 'stack_local', ENG_IN, [(f'astk_{st}', f'e{ae}o'), (c_, 'si')]))
            add((f'el_{st}_{e}', 'stack_local', ENG_OUT, [(c_, 'so'), (f'astk_{st}', f'e{ae}i')]))
            if m['geo'].get('split') and V143['on']:
                _v143_buses(add, st, e, c_)
            else:
                for pr in range(2):           # S1b copy -> the pair's two heads (one net, two loads)
                    add((f'tp_{st}_{e}_{pr}', 'stack_local', T_PAIR, [(c_, f't{pr}')] +
                         [(f'head_{st}_{e}_{h}', 'ti') for h in (2 * pr, 2 * pr + 1)]))
            for h in range(4):
                hd_ = f'head_{st}_{e}_{h}'
                if not (m['geo'].get('split') and V143['on']):
                    add((f'te_{st}_{e}_{h}', 'stack_local', T_E, [(c_, f'e{h}'), (hd_, 'e')]))
                    add((f'ts_{st}_{e}_{h}', 'stack_local', T_RET, [(hd_, 's'), (c_, f's{h}')]))
                if not KSD.ASTK_ST:     # KV-WIRE2 ASTK: the static heads have no node beat
                    add((f'nb_{st}_{e}_{h}', 'stack_local', HEAD_NB, [(hd_, 'nb'), (f'astk_{st}', f'f{ae}{h}')]))
            add((f'krq_{st}_{e}', 'spine_local', KS.W_RQ if split else 16, [(c_, 'rq'), (f'land_{st}', f'rq{e}')]))
            add((f'krs_{st}_{e}', 'spine_local', 1 + 1024, [(f'land_{st}', f'rs{e}'), (c_, 'rs')]))
        add((f'kvn_{st}', 'kvn', 1024 + 2 + 14 + 6 + 1 + 1, [('seq', f'kvn_{st}'), (f'land_{st}', 'kvn')]))
        # qwen-1010/b 2026-10-11: stream-command net -- the descriptor issuer in qkd_seq (ot_qkvd_kv_desc, KDESC 1) posts
        # DESC / GO words ~320 hclk ahead of each layer's go; one registered copy per stack runs on relays (core clock) to
        # the stack's controller element, whose W-face kc port enters the async FIFO and the hclk tap chain to the 32
        # per-PC heads (ot_qkvd_kcmd_tap).  No ready: the issuer bounds its outstanding layers.
        add((f'kc_{st}', 'kv_oneway', 1 + 32, [('seq', f'kc_{st}'), (f'ctrl_{st}', 'kc')]))
        if not KSD.BOOT:      # BOOT: qkd_embgw_boot_s has no strip links (note s5.1)
            add((f'emf_{st}', 'kvn', KS.W_EMF if split else W + 2, [('embgw', f'emf_{st}'), (f'land_{st}', 'emf')]))
            add((f'emr_{st}', 'kvn', KS.W_EMR if split else W + 2, [(f'land_{st}', 'emr'), ('embgw', f'emr_{st}')]))
        if not m['geo'].get('split'):
            add((f'ing_{st}', 'kvn', W + 2, [('host', f'ing_{st}'), (f'land_{st}', 'ing')]))
        else:
            # v1.2: the landing strip <-> controller strip words (per PC: the embedding engine's static command es and
            # its return er, across the CDC column = one abutted hop) and the controller strip's fault into the
            # landing's PC fault chain (kvs RTL: tools/qwen_kv_die/kv_strips.py).  'ing' (host -> landing) is gone:
            # no RTL on either side; the host's embedding words reach the gateway on hb (qkd_embgw RTL)
            for k_ in range(32):
                add((f'les_{st}_{k_}', 'stack_local', 288, [(f'land_{st}', f'es{k_}'), (f'ctrl_{st}', f'es{k_}')]))
                add((f'ler_{st}_{k_}', 'stack_local', 261, [(f'ctrl_{st}', f'er{k_}'), (f'land_{st}', f'er{k_}')]))
            # v1.3: S stacks abut at the S ends (kc leaf <-> land pc0); N stacks run the kc leaf's fault (strip N end) to
            # the landing's pc0 (S end) on relays (a fault level: latency is not a protocol term)
            add((f'lkf_{st}', 'stack_local' if st.endswith('S') else 'kv_oneway', 1,
                 [(f'ctrl_{st}', 'kf'), (f'land_{st}', 'kf')]))
    add(('ares', 'spine_local', 1 + 1 + 6 + 512, [('ahub', 'ao'), ('seq', 'ar')]))
    add(('hs', 'spine_local', 1, [('seq', 'hs'), ('ahub', 'hs')]))                  # layer start to the hub
    add(('d2df', 'spine_local', 6, [('d2d_kv', 'flt'), (lend, 'd2df')]))            # link-end fault + cause
    add(('kst', 'spine_local', 10, [('seq', 'kst'), ('host', 'kst')]))               # KV-die status to the host
    if split:
        # v1.2: the host's embedding words to the gateway (qkd_embgw hb 283 + hb_cr back) and its status word est
        add(('hb', 'kvn', 283 + 1, [('host', 'hb'), ('embgw', 'hb')]))
        add(('est', 'spine_local', 13, [('embgw', 'est'), ('host', 'est')]))
        # v1.2: the controller strip is 32 qkd_ctrl_pc + qkd_ctrl_kc (CLOSED leaves): every leaf its own core and HBM
        # clock entry; the HBM clock / reset are driven by the PLL / reset-sequencer frame (r21c's controller element
        # held the HBM PLL: the leaves only take pll_hbm / hrst); the PHY abstract qkd_hbm3e_phy_pc takes each PC's DFI
        # words po / pi (the controller is our RTL, not inside the PHY model)
        for st in STACKS:
            ctl_ = f'ctrl_{st}'
            for i_, (bid_, cl_, bits_, eps_) in enumerate(B):
                if (ctl_, 'ck') in eps_:
                    eps_ = [e for e in eps_ if e != (ctl_, 'ck')] + [(ctl_, c_) for c_ in KS.CTRL_CLK]
                if bid_ == f'clk_hbm_{st}':
                    eps_ = [('pll', f'pll_hbm_{st}')] + [e for e in eps_ if e != (ctl_, 'pll_hbm')] + \
                           [(ctl_, c_) for c_ in KS.CTRL_HCLK]
                if bid_ == f'rst_hbm_{st}':
                    eps_ = [('pll', f'rso_hbm_{st}')] + list(eps_)
                B[i_] = (bid_, cl_, bits_, eps_)
            for k_ in range(32):
                add((f'dpo_{st}_{k_}', 'phy_dfi', KS.W_PO, [(ctl_, f'po{k_}'), (f'phy_{st}', f'po{k_}')]))
                add((f'dpi_{st}_{k_}', 'phy_dfi', KS.W_PI, [(f'phy_{st}', f'pi{k_}'), (ctl_, f'pi{k_}')]))
        # v1.2: the CDC core-side resets come from the stack's core reset tree (the landing strip's leaves have no
        # crst output: r21c's land.crst was a frame port)
        for st in STACKS:
            kk = next(i for i, b in enumerate(B) if b[0] == f'rst_kv_{st}')
            cdc_eps = [e for e in B[kk][3] if e[0].startswith('cdc_')]
            del B[kk]
            kc_ = next(i for i, b in enumerate(B) if b[0] == f'rst_core_{st}')
            B[kc_] = (B[kc_][0], B[kc_][1], B[kc_][2], list(B[kc_][3]) + cdc_eps)
    add(('hf', 'spine_local', 1, [('ahub', 'hf'), ('seq', 'hf')]))                  # hub fault
    for st in STACKS:
        add((f'af_{st}', 'spine_local', 1, [(f'astk_{st}', 'af'), ('seq', f'af_{st}')]))
        add((f'mf_{st}', 'spine_local', 1, [(f'land_{st}', 'mf'), ('seq', f'mf_{st}')]))
    if split:   # KVJ-C2: no EMBQ / EMBD bundles (boot-only gateway, bridge successor without the SU face)
        add(('lflt', 'spine_local', 1, [('lnk', 'flt'), ('host', 'lflt')]))          # link + bridge fault -> host status (LINK.md open item 1)
    else:
        add(('gq', 'kvn', W + 2, [('seq', 'gq'), ('embgw', 'gq')]))
        add(('gr', 'kvn', W + 2, [('embgw', 'gr'), ('seq', 'gr')]))
    add(('hc', 'kv_oneway' if split else 'kvn', 182 if split else W + 2, [('host', 'hc'), ('seq', 'hc')]))
    add(('tk', 'kv_oneway' if split else 'kvn', 93 if split else W + 2, [('seq', 'tk'), ('host', 'tk')]))
    # v1.4.1 HOST-north: the SerDes FDI is no longer abutted -> a relayed long-haul word (per-bit direction model)
    add(('host_fdi', 'spine_local' if HOST_V14.get('north') and m['geo'].get('host_v14') else 'd2d_fdi', FDI_SERDES,
         [('host', 'fdi'), ('serdes_host', 'fdi')]))


def _host_slices(m, add):
    """v1.4: one qkd_host_pc_slice_die per PC in the slice column, level with its CDC / write-leaf pair (W: R0, E: MY)."""
    by = {i.name: i for i in m['insts']}
    Wd, xl = m['die']['w'], m['geo']['x_land']
    # the slice column sits between the landing channel and the landing strip (the channel keeps the write-leaf chain and
    # the write-queue controller): slice -> landing abuts, slice -> controller strip crosses CDC column + channel (~402 um,
    # the v1.3 landing -> controller es / er hop), CDC -> landing words cross 129.6 um more (cdc_core hop ~350 um)
    xw = math.floor(round((xl + LAND_CHAN + SLICE_GAP) / GX, 6)) * GX     # snapped DOWN: never into the landing strip
    for st in STACKS:
        for k in range(32):
            c_, w_ = by[f'cdc_{st}_{k}'], by[f'wleaf_{st}_{k}']
            y0, y1 = min(c_.y, w_.y), max(c_.y + c_.h, w_.y + w_.h)
            y = up(y0 + (y1 - y0 - SLICE_H) / 2, GY)
            x = xw if st[0] == 'W' else Wd - xw - (SLICE_W - SHAVE)
            # v1.4.1 HOST-north: the N stacks' chain runs slot 31 -> 0 (downward).  A y-mirrored slice would move its
            # es / er pins off the strips' levels (first try: 128 hes hops of 675 um), so the N stacks use a second
            # physical view qkd_hslice_dn of the SAME RTL (qkd_host_pc_slice_die) whose chain faces are swapped
            dn = HOST_V14.get('north') and st[1] == 'N'
            add(f'hsl_{st}_{k}', 'qkd_hslice_dn' if dn else 'qkd_hslice', x, y, SLICE_W - SHAVE, SLICE_H - SHAVE,
                'R0' if st[0] == 'W' else 'MY', 'host_slice', 'strip')


def host_lpc(k):
    """logical PC of landing strip slot k (kv_strips: slot 4 i + q hosts lpc 8 q + G(i))"""
    return 8 * (k % 4) + LAND_GROUP_ORDER[k // 4]


def _host_v14_buses(m):
    """v1.4: the HOST root core / slices / PLL-model / reset wiring (see HOST_V14 above).  Root resets replace the frame
    PLL's rso_* outputs (the analog model has none); the landing <-> controller es / er words pass through the slices."""
    B = m['buses']
    names = {i.name for i in m['insts']}
    die_l, hbm_l, link_l = [], [], []
    link_inst = {'ucie_rom', 'serdes_host', 'd2d_kv', 'lnk'}
    keep = []
    for bid, cl, bits, eps in B:
        if bid.startswith(('les_', 'ler_')) or bid == 'lflt':
            continue                                  # re-made through the slices / lnk.flt -> typed transport-fault collector (owed)
        eps = [e for e in eps if not (e[0] == 'host' and e[1] in ('ck', 'rst_n'))]
        if eps and eps[0][0] == 'pll' and eps[0][1].startswith('rso'):
            loads = eps[1:]
            if eps[0][1].startswith('rso_hbm'):
                hbm_l += loads
            else:
                die_l += [e for e in loads if e[0] not in link_inst]
                link_l += [e for e in loads if e[0] in link_inst]
            continue
        if bid.startswith('lkf_'):
            cl = 'kv_oneway'          # the landing moved 151.2 um away: the controller fault level kf rides relays (553 um)
        keep.append((bid, cl, bits, eps))
    B[:] = keep
    add = B.append
    _d2ds_swap(m)
    ties = m.setdefault('host_ties', {})
    sl = lambda st, k: f'hsl_{st}_{k}'  # noqa: E731
    slices = [sl(st, k) for st in STACKS for k in range(32)]
    add(('rst_die', 'reset', 1, [('host', 'die_rst_n')] + list(dict.fromkeys(die_l))))
    add(('rst_hbm', 'reset', 1, [('host', 'hbm_rst_n')] + list(dict.fromkeys(hbm_l)) + [(s, 'hbm_rst_n') for s in slices]))
    link_l = [e for e in link_l if e[0] != 'lnk' and e != ('ucie_rom', 'rst_n')]     # ucie rst_n = the d2d end's phy_rst_n
    add(('rst_link', 'reset', 1, [('host', 'link_rst_n')] + list(dict.fromkeys(link_l)) +
         ([('dcal', 'rst_n')] if DCAL and any(i.name == 'dcal' for i in m['insts']) else []) +
         ([('kvnc', 'rst_n')] if KVNC and any(i.name == 'kvnc' for i in m['insts']) else []) +
         ([('lprg', 'rst_n')] if SEQST and any(i.name == 'lprg' for i in m['insts']) else [])))
    add(('rst_host', 'reset', 1, [('host', 'host_rst_n')] + [(s, 'host_rst_n') for s in slices]))
    # v1.4.1 HOST-north: the N stacks' chain head is their slot 31 (their top = the HOST row) and the chain runs slot 31 ->
    # slot 0; the S stacks keep slot 0 (die bottom: reached down the free centre column; the slice column has no free
    # crossing at the S | N middle, and its W / E gap is the N chains' corridor).  The slice status / station words are
    # placed by the logical PC lpc (OR-merged, position-free), so the order is a die wiring choice; the fixed per-slot chain
    # latency is chain position p (+1) cycles, p = 31 - k on the N stacks, recorded in the contract's compiler stages.
    orders = {st: (list(range(31, -1, -1)) if (HOST_V14.get('north') and st[1] == 'N') else list(range(32))) for st in STACKS}
    m['geo']['slice_chain_order'] = {st: o[0] for st, o in orders.items()}
    add(('hboot', 'reset', 1, [('host', 'boot_go')] + [(sl(st, orders[st][0]), 'bgi') for st in STACKS] +
         [('d2d_kv', 'host_boot_begin')]))
    add(('pll_lock', 'spine_local', 1, [('pll', 'locked'), ('host', 'pll_locked')]))
    fam = dict(HOST_CLK_FAMILY, **HOST_CLK_INFERRED)
    for i_, (bid, cl, bits, eps) in enumerate(B):
        if bid == 'clk_core_c':
            B[i_] = (bid, cl, bits, eps + [('host', c) for c, f in sorted(fam.items()) if f == 'core'])
        for st in STACKS:
            if bid == f'clk_core_{st}':
                B[i_] = (bid, cl, bits, list(B[i_][3]) + [(sl(st, k), c) for k in range(32)
                                                          for c in ('ck',)])
    for f_ in ('host', 'ingest', 'phy'):
        add((f'clk_{f_}', 'clock_trunk', 1, [('pll', f'pll_{f_}')] + [('host', c) for c, f in sorted(fam.items()) if f == f_]))
    for si, st in enumerate(STACKS):
        order = orders[st]
        for k in range(32):
            s = sl(st, k)
            add((f'les_{st}_{k}', 'stack_local', 288, [(f'land_{st}', f'es{k}'), (s, 'land_es')]))
            add((f'hes_{st}_{k}', 'stack_local', 288, [(s, 'ctrl_es'), (f'ctrl_{st}', f'es{k}')]))
            add((f'ler_{st}_{k}', 'stack_local', 261, [(f'ctrl_{st}', f'er{k}'), (s, 'ctrl_er')]))
            add((f'hler_{st}_{k}', 'stack_local', 261, [(s, 'land_er'), (f'land_{st}', f'er{k}')]))
            add((f'hlpc_{st}_{k}', 'constant', 5, [(s, 'lpc')]))
            # BOOT (note s5.7): the slice's lpc names the logical PC its controller holds = the kvpc pc strap k
            ties[f'hlpc_{st}_{k}'] = (5, k if KSD.BOOT else host_lpc(k))
            p_ = order.index(k)
            if p_ < 31:
                n_ = sl(st, order[p_ + 1])
                add((f'hf_{st}_{k}', 'stack_local', 291, [(s, 'fo'), (n_, 'fi')]))
                add((f'hbg_{st}_{k}', 'stack_local', 1, [(s, 'bgo'), (n_, 'bgi')]))
                for o, i in (('co', 'ci'), ('ao', 'ai'), ('fault_o', 'fault_i'), ('sko', 'ski'), ('sdo', 'sdi'),
                             ('soo', 'soi'), ('sfo', 'sfi')):
                    add((f'h{o}_{st}_{k}', 'stack_local', 1 if o == 'fault_o' else 32, [(n_, o), (s, i)]))
            else:
                for i, w_ in (('ci', 32), ('ai', 32), ('fault_i', 1), ('ski', 32), ('sdi', 32), ('soi', 32), ('sfi', 32)):
                    add((f'ht{i}_{st}', 'constant', w_, [(s, i)]))          # chain terminator (source parent assigns 0)
                    ties[f'ht{i}_{st}'] = (w_, 0)
        s0 = sl(st, order[0])
        add((f'hchf_{st}', 'kv_oneway', 291, [('host', f'chf{si}'), (s0, 'fi')]))
        for o, rp, w_ in (('co', 'chc', 32), ('ao', 'cha', 32), ('fault_o', 'chx', 1), ('sko', 'sak', 32), ('sdo', 'sbd', 32),
                          ('soo', 'sbo', 32), ('sfo', 'sbf', 32)):
            add((f'h{rp}_{st}', 'kv_oneway', w_, [(s0, o), ('host', f'{rp}{si}')]))


def _d2ds_swap(m):
    """v1.4 + Q-LINK: qkd_d2d_static replaces the credit link end (qkd_d2d) and the bridge qkd_lnk.  The sequencer's
    lx / lr and the gateway's gq / gr lose their bridge (their static adapters are owed: unconnected = MISMATCH, never
    tied); the d2d end's attention record / KVN faces, cfg loader port, cal_start, status epoch and KV-local drains have
    no producer yet (named in the v1.4 contract)."""
    B = m['buses']
    m['insts'][:] = [i for i in m['insts'] if i.name != 'lnk']
    out = []
    for bid, cl, bits, eps in B:
        if bid in ('d2d_dn', 'd2d_up', 'lx', 'lr', 'gq', 'gr', 'd2df'):
            continue
        eps = [e for e in eps if e[0] != 'lnk' and e != ('d2d_kv', 'ck') and e != ('ucie_rom', 'rst_n')]
        if bid == 'clk_core_c':
            eps = eps + [('d2d_kv', 'ck0')]          # Q-LINK r2b 496b4daa1: one clock root ck (no ck_bank)
        if bid == 'd2d_fdi':
            bits = 1 + 1 + 583 + 1 + 583             # the native UCIe word (kv_native_phy splits the PHY side)
        out.append((bid, cl, bits, eps))
    B[:] = out
    add = B.append
    add(('rst_phyd2d', 'reset', 1, [('d2d_kv', 'phy_rst_n'), ('ucie_rom', 'rst_n')]))
    add(('hsvc', 'spine_local', 8 + 3 + 4 + 9 + 1 + 1 + 1 + 4 + 59 + 2 + 18 + 32 + 32, [('d2d_kv', 'svc'), ('host', 'svc')]))
    add(('hlup', 'spine_local', 2, [('d2d_kv', 'lup'), ('host', 'lup')]))
    add(('hrec_tx', 'spine_local', 1 + 548, [('host', 'rec_tx'), ('d2d_kv', 'rec_tx')]))
    add(('hrec_rx', 'spine_local', 2 + 1 + 1 + 548, [('d2d_kv', 'rec_rx'), ('host', 'rec_rx')]))
    add(('hlrc', 'spine_local', 2, [('host', 'lrc'), ('d2d_kv', 'lrc')]))
    # v1.4.1 (Q-LINK r3 answers 09:17): status_epoch16 <- root token_epoch (TAG59 epoch16), host_drained_local <- root
    # host_drained_local (exported host interface idle); host_boot_begin rides the root boot_go tree (hboot, below)
    add(('hsep', 'spine_local', 16, [('host', 'token_epoch'), ('d2d_kv', 'status_epoch16')]))
    add(('hhdl', 'spine_local', 1, [('host', 'host_drained_local'), ('d2d_kv', 'host_drained_local')]))
    # v1.4.2 (HOST owner = KV die lead): the root's typed die-local physical fault is the static D2D end's sticky fault
    # (root places it on bit die_id); the root's engine admission is the link's native_admit_ready inside the root RTL
    add(('hlpf', 'spine_local', 1, [('d2d_kv', 'lpf'), ('host', 'link_physical_fault')]))
    by = {i.name: i for i in m['insts']}
    ck_ = by['ckb_kv']
    for j, (n_, p_) in enumerate((('fwb_ep', 'fwd_epoch'), ('fwb_rs', 'fwd_link_rst_n'))):
        it = F.Inst(n_, 'qkd_fwdbump', round(ck_.x - (j + 1) * (43.2 + 4 * GX), 4), ck_.y, ck_.w, ck_.h, 'R0', kind='bump',
                    region='io', domain='stream_1p2')
        m['insts'].append(it)
        add((f'h{p_}', 'kv_oneway', 1, [('d2d_kv', p_), (n_, 'a')]))
    m.setdefault('extra_conns', {})['d2d_kv'] = ['.serdes_up(n_host_fdi[0])']     # SerDes tx_up (fdi bit 0) also feeds link_up[1]
    if DCAL:
        # OT_KV_DCAL: the calendar sequencer sits one channel E of the D2D frame, level with the frame centre (the relays
        # are planned after, around it); its cfg / cal word is a 42-bit abutting-distance spine_local bus
        d_ = by['d2d_kv']
        w_, h_ = up(DCAL_WH[0] + SHAVE, GX), up(DCAL_WH[1] + SHAVE, GY)       # frame on the grid, >= the real view
        it = F.Inst('dcal', 'qkd_dcal', up(d_.x + d_.w + 21.6, GX), up(d_.y + d_.h / 2 - h_ / 2, GY), w_ - SHAVE, h_ - SHAVE,
                    'R0', kind='ctl', region='io')
        m['insts'].append(it)
        add(('dcal_cfg', 'spine_local', len(DCAL_CS), [('dcal', 'cal'), ('d2d_kv', 'cal')]))
        if DCAL_BC:      # KV-DCAL-BOOTCFG: the merged cfg word (boot + runtime base writes) -> the D2D end's cfg port
            add(('dcal_dcfg', 'spine_local', 1 + 1 + 6 + 32, [('dcal', 'dcfg'), ('d2d_kv', 'dcfg')]))
        add(('dcal_hlt', 'spine_local', 1, [('d2d_kv', 'eab'), ('dcal', 'hlt')]))
        add(('dcal_rld', 'kv_oneway', 1, [('host', 'program_begin_v'), ('dcal', 'rld')]))
        for i_, (bid, cl, bits, eps) in enumerate(B):
            if bid == 'clk_core_c':
                B[i_] = (bid, cl, bits, list(eps) + [('dcal', 'ck')])
        # epoch_go taps the end's fwd_epoch die net at its source (the bump chain keeps its relays and its one driver)
        m.setdefault('extra_conns', {})['dcal'] = ['.ego(n_hfwd_epoch)']
        if KVNC:
            # OT_KV_KVNC: the KVN context leaf sits directly below the sequencer (same x, one channel S); cal_start taps the
            # sequencer's cfg/cal word at its source, layer is a 6-bit abutting bus, the HOST cohort rides kv_oneway relays,
            # the 61-bit expectation is an abutting-distance bus into the D2D end (it settles >= 645 edges before any KVN word)
            dc_ = it
            kw_, kh_ = up(KVNC_WH[0] + SHAVE, GX), up(KVNC_WH[1] + SHAVE, GY)
            kt = F.Inst('kvnc', 'qkd_kvnc', dc_.x, up(dc_.y - 21.6 - kh_, GY), kw_ - SHAVE, kh_ - SHAVE, 'R0', kind='ctl', region='io')
            m['insts'].append(kt)
            add(('kvnc_lay', 'spine_local', 6, [('dcal', 'lay'), ('kvnc', 'lay')]))
            add(('kvnc_cht', 'kv_oneway', 59, [('host', 'cohort_tag'), ('kvnc', 'cht')]))
            add(('kvnc_chg', 'kv_oneway', 2, [('host', 'cohort_gen'), ('kvnc', 'chg')]))
            add(('kvnc_kvi', 'spine_local', 59 + 2, [('kvnc', 'kvi'), ('d2d_kv', 'kvi')]))
            for i_, (bid, cl, bits, eps) in enumerate(B):
                if bid == 'clk_core_c':
                    B[i_] = (bid, cl, bits, list(eps) + [('kvnc', 'ck')])
            m['extra_conns']['kvnc'] = [f'.cs(n_dcal_cfg[{KVNC_CS_BIT}])']
            if SEQST:
                # OT_KV_SEQ_STATIC: master swap of slot `seq`; the layer programme sits one channel W of the HOST root,
                # level with its centre (HOST authority on abutting buses; tok_start rides kv_oneway relays from DCAL)
                sq_ = by['seq']
                sq_.master = 'qkd_seq_st'
                ho_ = by['host']
                lw_, lh_ = up(LPRG_WH[0] + SHAVE, GX), up(LPRG_WH[1] + SHAVE, GY)
                lp_ = F.Inst('lprg', 'qkd_lprg', up(ho_.x - 21.6 - lw_, GX), up(ho_.y + ho_.h / 2 - lh_ / 2, GY), lw_ - SHAVE,
                             lh_ - SHAVE, 'R0', kind='ctl', region='io')
                m['insts'].append(lp_)
                for i_, (bid, cl, bits, eps) in enumerate(B):
                    if bid == 'hc':
                        B[i_] = (bid, cl, bits, [e for e in eps if e != ('seq', 'hc')])
                    if bid == 'clk_core_c':
                        B[i_] = (bid, cl, bits, list(B[i_][3]) + [('lprg', 'ck')])
                # relayed fork branches (no long unrelayed fan-out): the HOST cohort to lprg, the D2D end's svc word to seq
                fk_ = m.setdefault('forks', {})
                fk_['kvnc_cht'] = [('lprg', 'cht')]
                fk_['kvnc_chg'] = [('lprg', 'chg')]
                fk_['hsvc'] = [('seq', 'svc')]
                B[:] = [b_ for b_ in B if not (b_[0] == 'hc' and len(b_[3]) < 2)]     # host hc has no load left
                add(('lprg_st', 'kv_oneway', 1, [('dcal', 'tks'), ('lprg', 'st')]))
                add(('lprg_auth', 'spine_local', 1 + 1 + 16 + 64, [('host', 'auth_lp'), ('lprg', 'auth')]))
                add(('seqst_lp', 'kv_oneway', 1 + 6 + 14, [('lprg', 'lp'), ('seq', 'lp')]))
                if KSD.SEQ_S:     # KV-WIRE2: the KVN arrival word only (seqst_rx is created by kv_static_die.inject)
                    add(('seqst_kw', 'kv_oneway', 1 + 11, [('d2d_kv', 'skw'), ('seq', 'skw')]))
                else:
                    add(('seqst_rx', 'kv_oneway', 1 + 4 + 5 + 1 + 11 + 512, [('d2d_kv', 'srx'), ('seq', 'srx')]))


def _centre(it, port=None):
    return it.x + it.w / 2, it.y + it.h / 2


def _relays(m):
    """Registered relay stations every <= RELAY_PITCH on every non-abutted point-to-point bus.  The path is a shortest
    route on a GRID-um grid that avoids every block frame except the two endpoints (BFS from the driver's nearest edge
    point to the load's), so a word between the centre column and a landing column runs through the free rows above /
    below the attention groups and the channels beside them; relays sit on the path at <= RELAY_PITCH (a free spot
    within two grid cells).  Clock / reset trees (CTS / reset tree) and multi-endpoint buses are not relayed."""
    from collections import deque
    by = {i.name: i for i in m['insts']}
    Wd, Hd = m['die']['w'], m['die']['h']
    # The south-face leaf fits inside the CDC-column gap.  A43.2um occupancy
    # cell falsely merges that gap with the adjacent control tile; half-grid
    # routing represents its actual free channels without moving a pin.
    G = GRID/2 if (m['geo'].get('kv_wq_leaf_s') or m['geo'].get('relay_half_grid')) else GRID   # KVJ-G2: static die keeps the half grid
    nx, ny = int(Wd // G) + 1, int(Hd // G) + 1
    owner = {}
    for it in m['insts']:
        for gx in range(int(it.x // G), int((it.x + it.w) // G) + 1):
            for gy in range(int(it.y // G), int((it.y + it.h) // G) + 1):
                owner.setdefault((gx, gy), set()).add(it.name)
    # v1.4.4: reserved homes without an instance yet (the PV V ports) are hard keep-outs like a block frame
    for kn_, kx_, ky_, kw_, kh_ in m.get('keepouts', []):
        by[kn_] = F.Inst(kn_, 'keepout', kx_, ky_, kw_, kh_, 'R0')
        for gx in range(int(kx_ // G), int((kx_ + kw_) // G) + 1):
            for gy in range(int(ky_ // G), int((ky_ + kh_) // G) + 1):
                owner.setdefault((gx, gy), set()).add(kn_)
    occ = [(i.x, i.y, i.x + i.w, i.y + i.h) for i in m['insts']]
    rocc = {}
    ckdom = {}                     # KVPLAN3 0230 (OT_KV_SEAM): instance -> its core clock trunk (clk_core_<c|st>)
    for bid_, cl_, _b, eps_ in m['buses']:
        if cl_ == 'clock_trunk' and bid_.startswith('clk_core_'):
            for inst_, _p in eps_[1:]:
                ckdom.setdefault(inst_, bid_)
    seams = m.setdefault('clock_seams', [])
    SP = dict(on=False)        # v1.1: set for a chain's retry: route around cells other chains' relays hold

    def free(x, y, w, h, gap=4.32, bgap=21.6):
        # keep-outs: 4.32 um to other relays, 21.6 um to block frames (the die placer snaps every origin to its
        # master's legal track / row lattice: a 16 k-pin row engine moved 15.1 um, so a relay must not hug a block)
        if x - gap < 0 or y - gap < 0 or x + w + gap > Wd or y + h + gap > Hd:
            return False
        for gx in range(int((x - bgap) // G) - 1, int((x + w + bgap) // G) + 2):
            for gy in range(int((y - bgap) // G) - 1, int((y + h + bgap) // G) + 2):
                for q in rocc.get((gx, gy), ()):
                    if q[0] < x + w + gap and x - gap < q[2] and q[1] < y + h + gap and y - gap < q[3]:
                        return False
                for n in owner.get((gx, gy), ()):
                    it = by[n]
                    if it.x < x + w + bgap and x - bgap < it.x + it.w and it.y < y + h + bgap and y - bgap < it.y + it.h:
                        return False
        return True

    def ring(it):
        """free grid cells touching the frame from outside (where its pins meet the die routing)."""
        x0, y0 = int(it.x // G) - 1, int(it.y // G) - 1
        x1, y1 = int((it.x + it.w) // G) + 1, int((it.y + it.h) // G) + 1
        cells = [(x, y) for x in range(x0, x1 + 1) for y in (y0, y1)] + \
                [(x, y) for y in range(y0 + 1, y1) for x in (x0, x1)]
        return [c for c in cells if 0 <= c[0] < nx and 0 <= c[1] < ny and not owner.get(c)]

    def near_pin(cells, inst, port):
        # qwen-1010/b: with a drawn pin (second pass), the chain leaves / enters at the ring cells nearest that pin
        pt = _PIN_HINT.get((inst, port.lstrip('*')))
        if pt is None and inst in by:
            # KVDIE 2026-10-16 (kvs13d prep: kc_ES path ended mid-strip, 12.4 mm from the kc leaf pin): under OT_KV_HOP the
            # route aims at the closed leaf's realized pin it is timed to, as the relay reach already does
            pt = _leaf_pin(by[inst], port)
        if pt is None or not cells:
            return cells
        dist = lambda c: abs((c[0] + 0.5) * G - pt[0]) + abs((c[1] + 0.5) * G - pt[1])  # noqa: E731
        d0 = min(dist(c) for c in cells)
        return [c for c in cells if dist(c) <= d0 + 2 * G]

    def route(a, b, pa='', pb=''):
        wps_ = KSD.waypoints(m, a, pa, b, pb) if (KSD.ON and m['geo'].get('static_die')) else None
        # DIE-KV-REPLACE 10-19: the top engine's K response word runs through its OWN relay band (see _krs_top_lane),
        # on the first placement and on every retry
        wps_ = _krs_top_lane(m, bid) or wps_
        if wps_:
            # KVJ-G2b: a static-die long word (ctl -> S-stack chain root / fan) runs through its planned waypoints (the
            # PV-side channel, the stack seam row, the stack's control channel) instead of the shortest corridor, which is
            # the stack's K / V channel whose relay spots the group <-> V port / ECTL words need
            try:
                cells_ = []
                for k_, (wx_, wy_) in enumerate(wps_):
                    cy_ = int(wy_ // G)
                    c_ = None
                    for dx_ in range(0, 40):
                        for sgn in (1, -1):
                            q_ = (int(wx_ // G) + sgn * dx_, cy_)
                            if 0 <= q_[0] < nx and 0 <= q_[1] < ny and not owner.get(q_) and not (SP['on'] and q_ in rocc):
                                c_ = q_
                                break
                        if c_:
                            break
                    if c_ is None:
                        raise ValueError('no waypoint cell')
                    cells_.append(c_)
                pth_ = route_(a, 'wp0', near_pin(ring(by[a]), a, pa), {cells_[0]})
                for k_ in range(1, len(cells_)):
                    pth_ += route_(f'wp{k_ - 1}', f'wp{k_}', [cells_[k_ - 1]], {cells_[k_]})[1:]
                pth_ += route_(f'wp{len(cells_) - 1}', b, [cells_[-1]], set(near_pin(ring(by[b]), b, pb)))[1:]
                return pth_
            except ValueError as e_:
                print(f'kv die KVJ-G2b: {a}.{pa} -> {b}.{pb} waypoint route failed ({e_}); shortest path', file=sys.stderr)
        try:
            return route_(a, b, near_pin(ring(by[a]), a, pa), set(near_pin(ring(by[b]), b, pb)))
        except ValueError:
            return route_(a, b, ring(by[a]), set(ring(by[b])))      # pin cells enclosed: any free ring cell

    def route_via(a, b, pa, pb, lane_y, lane_x=None):
        """v1.2: an N-half KV-row chain (kvn / krs / krq / kc / emf / emr / ing) runs through its own lane row of the free
        band above the N engine groups instead of every chain hugging the group edge (kvs2 T2: one corridor at the N
        group top, GRT detours, kvn / emf / krs relay hops TT -155 / -108 / -90 ps)"""
        xa = by[a].x + by[a].w / 2
        xb = by[b].x + by[b].w / 2
        wy = int(lane_y // G)
        w_ = None
        xm = (xa + xb) / 2 if lane_x is None else lane_x
        for dx_ in range(0, 400):
            for sgn in (1, -1):
                wx = int(xm // G) + sgn * dx_
                if 0 <= wx < nx and 0 <= wy < ny and not owner.get((wx, wy)) and (wx, wy) not in rocc:
                    w_ = (wx, wy)
                    break
            if w_:
                break
        if w_ is None:
            raise ValueError('no lane cell')
        p1 = route_(a, f'lane{lane_y}', near_pin(ring(by[a]), a, pa), {w_})
        p2 = route_(f'lane{lane_y}', b, [w_], set(near_pin(ring(by[b]), b, pb)))
        return p1 + p2[1:]

    def route_(a, b, src, dst):
        if not src or not dst:
            raise ValueError(f'kv die: {a} or {b} has no free cell around it')
        prev = {c: None for c in src}
        dq = deque(src)
        hit = None
        while dq:
            c = dq.popleft()
            if c in dst:
                hit = c
                break
            for d in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                q = (c[0] + d[0], c[1] + d[1])
                # v1.1 (split): on a chain's retry it does not run through cells another chain's relays already hold, so
                # it leaves the corridor where the relay spots ran out (head 492.48: af_WN / aq_WS at the N group top)
                # v1.2: never along the die-edge cell ring (no relay fits there: kc_ES ran 24 mm up and down the E edge
                # past the PHY to the controller strip's N-end PHY gap once the landing strip closed its old channel)
                if q not in prev and 1 <= q[0] < nx - 1 and 1 <= q[1] < ny - 1 and not owner.get(q) and \
                        not (SP['on'] and q in rocc) and \
                        not (SP.get('dil') and any((q[0] + i_, q[1] + j_) in rocc for i_ in range(-SP['dil'], SP['dil'] + 1)
                                                   for j_ in range(-SP['dil'], SP['dil'] + 1))):
                    prev[q] = c
                    dq.append(q)
        if hit is None:
            raise ValueError(f'kv die: no route {a} -> {b} (src {len(src)} cells, dst {len(dst)} cells, avoid relays {SP["on"]}, '
                             f'src0 {sorted(src)[:3]}, dst0 {sorted(dst)[:3]})')
        path, c = [], hit
        while c is not None:
            path.append(((c[0] + 0.5) * G, (c[1] + 0.5) * G))
            c = prev[c]
        return path[::-1]
    nb, stages, lengths = [], {}, {}
    rly_ends = {}                                  # relay inst -> (driver inst, load inst) of the bus it stages
    rly_dom = {}                                   # KV-DOMSPLIT: relay inst -> launching pin domain of its chain
    order_ = list(m['buses'])
    # v1.4.2 (kvs7c TT: host boot_go -550 ns on one 25.8-mm net, die_rst_n -4.8 ns / hbm_rst_n -1.9 ns: the die top has
    # no buffering, so a die-wide fan-out net cannot be one wire): every HOST reset / boot fan-out net becomes a
    # REGISTERED DISTRIBUTION TREE of die relays (one flop a hop, <= PIN_REACH, all on the HOST's core trunk).  Loads are
    # clustered in three levels (TREE_BOX um boxes); each cluster's chain ends <= TREE_LAST um from its leader load and its
    # last relay drives the cluster's <= TREE_FAN loads (leaf) or the next level's chains.  Depth per load is a fixed,
    # recorded compiler/boot constant (m['tree_depth']); reset release waits >= RELAY_FLUSH core cycles (kv_relays).
    tree_meta = {}                                 # segment bid -> dict(root, children=[...], members=[...])
    region_roots = bool(m['geo'].get('split') and V143['on'])
    if PV_T:
        # KVPLAN 1815: the trunked pair's chunk / header face pins (plan.json, canonical R0) are the chain targets from the
        # first pass: a chunk chain must run along the side channel to its GS group's channel, not end at the frame edge
        P_ = pvt_plan()
        for it_ in m['insts']:
            if not it_.master.startswith('qkd_pvw'):
                continue
            def die_xy_(cx, cy, it=it_):
                fx_ = it.w - cx if it.orient in ('MY', 'R180') else cx
                fy_ = it.h - cy if it.orient in ('MX', 'R180') else cy
                return (it.x + fx_, it.y + fy_)
            for k_ in range(8):
                for g_ in range(8):
                    f_, yc_ = P_['face_pins']['vc'][f'vc{k_}_{g_}']
                    _PIN_HINT[(it_.name, f'vc{k_}_{g_}')] = die_xy_(0.0 if f_ == 'W' else it_.w, yc_ + PVT_ORD * (1.5 - (k_ % 4)) * PVT_PIN_DY)
                # header / request: KVPLAN2 2215 -- they end on the control tile u_ctl at the strip (the frame is wires-only:
                # a side-face pin left a 1.1-1.5-mm unrelayed hop to the tile); the chains reach it through the
                # PVT_HUB_CLEAR channel between the hub and the strip
                if PVT_HDR_CTL:
                    hx_, hy_ = pvt_hdr_pin(k_)
                    _PIN_HINT[(it_.name, f'vh{k_}')] = die_xy_(hx_, hy_)
                    _PIN_HINT[(it_.name, f'vrq{k_}')] = die_xy_(hx_ + 8.64, hy_)
                else:
                    yh_ = it_.h - PVT_HDR_Y0 - PVT_PIN_DY * (k_ % 4)
                    _PIN_HINT[(it_.name, f'vh{k_}')] = die_xy_(0.0 if k_ < 4 else it_.w, yh_)
                    _PIN_HINT[(it_.name, f'vrq{k_}')] = die_xy_(0.0 if k_ < 4 else it_.w, yh_ - 30.0)
    if PV_T and PVT_PINS:
        for it_ in m['insts']:
            if it_.master == 'qkd_pvfork' or it_.master.startswith('qkd_pvtap'):
                for p_ in PVT_PORTS['qkd_pvfork' if it_.master == 'qkd_pvfork' else 'qkd_pvtap']:
                    _PIN_HINT[(it_.name, p_)] = pvt_port_xy(it_, p_)
            elif it_.master == 'qkd_pv16_vport':
                # the V port's vo / pr words: _split_pins draws them on its N face at x 43.2 / 72.0 (canonical R0); aim
                # at them from pass 1 (f3 plan: pvin first hops / pvrq last hops 420-637 um after drawing -> pin repair
                # stages that broke WP + O = PV_W)
                for p_, cx_ in (('vo', 43.2), ('pr', 72.0)):
                    x_, y_ = cx_, it_.h
                    if it_.orient in ('MY', 'R180'):
                        x_ = it_.w - x_
                    if it_.orient in ('MX', 'R180'):
                        y_ = it_.h - y_
                    _PIN_HINT[(it_.name, p_)] = (it_.x + x_, it_.y + y_)
    if KSD.ON and KSD.ASTK_ST and ECTL == ECTL_ST:
        # KVR-PLACE 10-19: the ASTK strip's e-read / calendar / V-header words have FIXED faces (KSD._pin_face: the S|N
        # seam end); without a drawn pin (first pass) the chain left from the frame's nearest edge, so when the pin-hinted
        # re-plans stopped, the kept first pass had pve_<st> leaving the strip's FAR end (10.9-mm unrepaired hop to the
        # drawn N-face erd, local plan r2/r3).  Aim at the face centre from the first pass on (a drawn pin replaces it).
        for it_ in m['insts']:
            if it_.master not in ('qkd_astk', 'qkd_astk_n'):
                continue
            for p_ in ['erd', 'cal'] + [f'vh{k_}' for k_ in range(8)]:
                f_ = KSD._pin_face(it_.master, p_)
                if f_ is None:
                    continue
                if it_.orient in ('MX', 'R180') and f_ in 'NS':
                    f_ = 'S' if f_ == 'N' else 'N'
                if it_.orient in ('MY', 'R180') and f_ in 'WE':
                    f_ = 'E' if f_ == 'W' else 'W'
                _PIN_HINT.setdefault((it_.name, p_), dict(
                    N=(it_.x + it_.w / 2, it_.y + it_.h), S=(it_.x + it_.w / 2, it_.y),
                    W=(it_.x, it_.y + it_.h / 2), E=(it_.x + it_.w, it_.y + it_.h / 2))[f_])
    if HOST_V14.get('trees') and 'serdes_host' in by:
        # v1.4.2 (kvs7c TT -7.6 ns, 1,044 endpoints: rly_host_fdi_55 -> serdes_host tx_flit 2.2 mm): the hard SerDes PHY's
        # FDI pins are on its W face (LEF ot_qfd_serdes_112g_x12_phy: tx_flit y 600.19..650.21, rx_flit 650.30..700.32,
        # x 0), not the frame edge the chain used to aim at -- the chain now ends at the pins
        s_ = by['serdes_host']
        if s_.orient != 'R0':
            raise ValueError('serdes_host FDI pin hint assumes R0')
        _PIN_HINT[('serdes_host', 'fdi')] = (s_.x, s_.y + 650.26)
    if HOST_V14.get('trees'):
        m['tree_depth'] = {}
        TREE_BOX, TREE_FAN = (4800.0, 1600.0, 240.0), 12
        if RST_REGIONAL:
            # KVPLAN 1815 (OT_KV_RST_REGIONAL=1): the die plans ONLY the express chain HOST -> regional reset root per
            # REGION-um box (the qkd_rst_region of v1.4.3); the root's whole region is one fan-out net here and
            # kv_rst_regional.py (after kv_expand) re-plans it as a local registered tree through the free space of the
            # FLATTENED die (the frame-level level-1/2 chains detoured around packed head columns: rst_die_t2_8 67 hops)
            TREE_BOX, TREE_FAN = (RST_REGION_BOX,), 0
        keep_ = []

        def ctr(e):
            pt = _PIN_HINT.get((e[0], e[1].lstrip('*')))
            if pt is not None:
                return pt
            it_ = by[e[0]]
            return (it_.x + it_.w / 2, it_.y + it_.h / 2)

        def clusters(loads, box, fan):
            cel = {}
            for e in loads:
                x_, y_ = ctr(e)
                cel.setdefault((int(x_ // box), int(y_ // box)), []).append(e)
            out_ = []
            for k_ in sorted(cel):
                grp = sorted(cel[k_], key=lambda e: (ctr(e)[1], ctr(e)[0], e))
                for i_ in range(0, len(grp), fan or len(grp)):
                    g_ = grp[i_:i_ + (fan or len(grp))]
                    cx_ = sum(ctr(e)[0] for e in g_) / len(g_)
                    cy_ = sum(ctr(e)[1] for e in g_) / len(g_)
                    lead = min(g_, key=lambda e: (abs(ctr(e)[0] - cx_) + abs(ctr(e)[1] - cy_), e))
                    out_.append((lead, g_))
            return out_

        def tree(root, name, loads, lvl):
            # one segment bus per cluster at this level: (source filled in when the parent chain is placed) -> leader
            segs = []
            for j_, (lead, g_) in enumerate(clusters(loads, TREE_BOX[lvl], TREE_FAN if lvl == len(TREE_BOX) - 1 else 0)):
                sid = f'{name}{j_}'
                meta = dict(root=root, rdrv='host', lead=lead, children=[], members=[], level=lvl)
                if lvl == len(TREE_BOX) - 1:
                    meta['members'] = [e for e in g_ if e != lead]
                else:
                    meta['children'] = tree(root, sid + '_', g_, lvl + 1)
                tree_meta[sid] = meta
                segs.append(sid)
            return segs
        for bid, cl, bits, eps in order_:
            if cl == 'reset' and bits == 1 and len(eps) >= 2 and eps[0][0] == 'host':
                tops = tree(bid, f'{bid}_t', list(dict.fromkeys(eps[1:])), 0)
                for sid in tops:
                    tree_meta[sid]['src'] = eps[0]
                    keep_.append((sid, 'kv_oneway', 1, [eps[0], tree_meta[sid]['lead']]))
            else:
                keep_.append((bid, cl, bits, eps))
        # 1-bit tree hops take the spots the data chains leave (placed last, wide relay-spot search from the start)
        order_ = [b_ for b_ in keep_ if b_[0] not in tree_meta] + [b_ for b_ in keep_ if b_[0] in tree_meta]
        m['tree_roots'] = sorted({v['root'] for v in tree_meta.values()})
    if m['geo'].get('split'):
        # the link bridge <-> sequencer words (lx / lr = the measured link cost's K_ST) take their relay spots first, so
        # other chains' relays never push them from one stage to two
        order_.sort(key=lambda b_: b_[0] not in ('lx', 'lr'))
        if V144:
            # v1.4.4: the PV pairs fill the centre column; the 2,089-b HOST FDI (north root -> south SerDes, ~22 mm) takes its
            # side-channel relay spots right after lx / lr, before the stack chains fill the 274-um side channels
            pri_ = [p_ for p_ in __import__('os').environ.get('OT_KV_V144_RLY_FIRST', 'krs_').split(',') if p_]
            order_.sort(key=lambda b_: (b_[0] not in ('lx', 'lr'), b_[0] != 'host_fdi',
                                        not any(b_[0].startswith(p_) for p_ in pri_)))
            if V144_R6:   # kvs13d: every V port's return word is planned first; its request word is then padded to W
                order_.sort(key=lambda b_: (b_[0].startswith('pvrq_'), b_[0].startswith(('pvta_', 'pvtb_', 'pvc_'))))
                if PV_T:
                    # KVPLAN2 2215: the header and the exact-stage PV trunks / chunks claim their lanes beside the pair
                    # face right after lx / lr / host_fdi (every other chain's stage count is free; theirs is fixed)
                    pvx_ = tuple(__import__('os').environ.get('OT_KV_PVT_FIRST', 'pvh_,pvta_,pvtb_,pvc_').split(','))
                    order_.sort(key=lambda b_: (b_[0] not in ('lx', 'lr'), b_[0] != 'host_fdi', not b_[0].startswith(pvx_)))
                    # KVR-PLACE 10-19: the top engines' K response words (krs_<st>_7, own relay band: _krs_top_lane) take
                    # their spots right after the exact-stage PV chains, before every other stack chain fills the
                    # group <-> slg channel their first leg climbs (local plan r2: the pin-hinted re-plan passes stopped
                    # at krs_ES_7 stage 4 in that channel, leaving the unhinted pass with 10.9-mm pve hops)
                    if _krs_top_lane(m, 'krs_WS_7') is not None:
                        top_ = [b_ for b_ in order_ if _krs_top_lane(m, b_[0]) is not None]
                        rest_ = [b_ for b_ in order_ if _krs_top_lane(m, b_[0]) is None]
                        j_ = max([i_ + 1 for i_, b_ in enumerate(rest_) if b_[0] in ('lx', 'lr', 'host_fdi')
                                  or b_[0].startswith(pvx_)] or [0])
                        order_ = rest_[:j_] + top_ + rest_[j_:]
    # Q-KVSYS PVJOIN 2026-10-16 (fork buses): m['forks'] = {bid: [load endpoints]} -- loads that leave a bus's driver as a
    # RELAYED BRANCH of their own (bus f'{bid}__f{i}', class kv_oneway) instead of one long unrelayed fan-out wire.  The
    # trunk keeps the bus's own class / relays; after planning, the branch's first segment joins the trunk's source net
    # (the driver pin drives the trunk's first hop and every branch's first hop) and its stage count is recorded.
    forks_ = {}
    fork_names = {b_[0] for b_ in order_}
    for bid_f, loads_f in (m.get('forks') or {}).items():
        trunks_f = [e_ for e_ in order_ if e_[0] == bid_f]
        if len(trunks_f) != 1:
            raise ValueError(f'kv die fork {bid_f}: exactly one trunk required')
        _, class_f, bits_f, ends_f = trunks_f[0]
        if class_f in ('clock_trunk', 'reset', 'constant') or class_f in ABUT or len(ends_f) != 2:
            raise ValueError(f'kv die fork {bid_f}: only point-to-point data trunks may fork')
        src_f = ends_f[0]
        if len(set(loads_f)) != len(loads_f) or any(e_ in ends_f for e_ in loads_f):
            raise ValueError(f'kv die fork {bid_f}: duplicate load or driver alias')
        for i_f, ld_f in enumerate(loads_f):
            nm_f = f'{bid_f}__f{i_f}'
            if nm_f in fork_names:
                raise ValueError(f'kv die fork {nm_f}: bus name collision')
            fork_names.add(nm_f)
            forks_[nm_f] = bid_f
            br_ = (nm_f, 'kv_oneway', bits_f, [src_f, ld_f])
            if __import__('os').environ.get('OT_KV_FORK_PRIO', '1' if _ectl_st_frame(True) else '0') == '1':
                # DIE-KV-REPLACE 10-19: a fork branch is planned right after its trunk (it keeps the trunk's priority:
                # pvh_<st>_<k>__f0 -> astk vh<k> was planned LAST and found the group-top corner full on the grown ECTL)
                j_ = max(i_ for i_, e_ in enumerate(order_) if e_[0] == bid_f or e_[0].startswith(bid_f + '__f'))
                order_.insert(j_ + 1, br_)
            else:
                order_.append(br_)
    for bid, cl, bits, eps in order_:
        if cl in ABUT or cl in ('clock_trunk', 'reset', 'constant') or len(eps) != 2:
            nb.append((bid, cl, bits, eps))
            stages[bid] = 0
            continue
        (a, pa), (b, pb) = eps
        path = None
        lane = _kv_lane(m, bid) if m['geo'].get('lanes') else None
        if lane is not None:
            try:
                path = route_via(a, b, pa, pb, lane)
            except ValueError:
                path = None

        if path is None and bid == 'host_fdi' and HOST_V14.get('north') and not SERDES_N:
            # v1.4.1 HOST-north (kvs7 window: coarse H 1.11 -> 1.27 / V 0.94 -> 1.15 where the 2,089-b FDI left the root
            # westward into the kvn_WN / krs_WN corridor): the FDI goes down the EAST centre channel
            try:
                hb_ = by['host']
                path = route_via(a, b, pa, pb, hb_.y - 2 * CHAN, lane_x=hb_.x + hb_.w + CHAN)
                if HOST_V14.get('trees'):
                    # v1.4.2: the target is now the SerDes W-face FDI pins; keep the E centre channel all the way down
                    # (a shortest path from the lane cell turned west into the kvn_WN / krs_WN corridor: window H 1.47):
                    # host -> E lane cell below the host -> E lane cell above the SerDes -> W-face pins
                    sb_ = by['serdes_host']
                    lx_ = hb_.x + hb_.w + CHAN
                    if 'pvw_1' in by:
                        # v1.4.4: the PV pairs hold the centre column: the FDI runs down the middle of the EAST side channel
                        pv_ = by['pvw_1']
                        lx_ = pv_.x + pv_.w + m['geo']['pv144']['side_channel_um'][1] / 2

                    def lane_cell(x_, y_):
                        wy_ = int(y_ // G)
                        for dx_ in range(0, 400):
                            for sgn in (1, -1):
                                wx_ = int(x_ // G) + sgn * dx_
                                if 0 <= wx_ < nx and 0 <= wy_ < ny and not owner.get((wx_, wy_)) and (wx_, wy_) not in rocc:
                                    return (wx_, wy_)
                        raise ValueError('no lane cell')
                    w1, w2 = lane_cell(lx_, hb_.y - 2 * CHAN), lane_cell(lx_, sb_.y + sb_.h + 2 * CHAN)
                    q1 = route_(a, 'fdi_w1', near_pin(ring(by[a]), a, pa), {w1})
                    q2 = route_('fdi_w1', 'fdi_w2', [w1], {w2})
                    q3 = route_('fdi_w2', b, [w2], set(near_pin(ring(by[b]), b, pb)))
                    path = q1 + q2[1:] + q3[1:]
            except ValueError as e_:
                if V144:
                    print(f'kv die v1.4.4: host_fdi east-lane route failed ({e_}); shortest path', file=sys.stderr)
                path = None
        mx_ = re.match(r'(aq|emr|emf|kvn|kc)_([WE])S$', bid) if (PV_T and PVT_XLANE) else None
        if path is None and mx_ and 'pvw_0' in by:
            # KVPLAN2 2215: the S-stack <-> north-centre express words cross the corridor in the OUTER (head-side) part of
            # their side channel, 3 mm either side of the hub, clear of the forks / group-7 taps that sit at both pairs'
            # strip ends next to the pair faces (aq_ES / emr / kvn / emf ran out of spots there)
            try:
                lo_, hi_ = m['geo']['pv144']['centre_column_um'][:2]
                j_ = ('aq', 'emr', 'emf', 'kvn', 'kc').index(mx_.group(1))
                lx_ = lo_ + 21.6 + 45.0 + 43.2 * j_ if mx_.group(2) == 'W' else hi_ - 21.6 - 45.0 - 43.2 * j_
                hy_ = by['ahub'].y + by['ahub'].h / 2

                def xcell_(x_, y_):
                    wy_ = int(y_ // G)
                    for dx_ in range(0, 12):
                        for sgn in (1, -1):
                            wx_ = int(x_ // G) + sgn * dx_
                            if 0 <= wx_ < nx and 0 <= wy_ < ny and not owner.get((wx_, wy_)):
                                return (wx_, wy_)
                    raise ValueError('no lane cell')
                ya_, yb_ = by[a].y + by[a].h / 2, by[b].y + by[b].h / 2
                w1, w2 = xcell_(lx_, hy_ + (3000.0 if ya_ > hy_ else -3000.0)), xcell_(lx_, hy_ + (3000.0 if yb_ > hy_ else -3000.0))
                q1 = route_(a, 'xl1', near_pin(ring(by[a]), a, pa), {w1})
                q2 = route_('xl1', 'xl2', [w1], {w2})
                q3 = route_('xl2', b, [w2], set(near_pin(ring(by[b]), b, pb)))
                path = q1 + q2[1:] + q3[1:]
            except ValueError as e_:
                print(f'kv die PV_T: {bid} express lane failed ({e_}); shortest path', file=sys.stderr)
                path = None
        if path is None and PV_T and bid.startswith('pvta_') and bid.endswith('_3'):
            # KVPLAN2 2215: trunk A's long fork -> tap 3 runs (past trunk B's groups 7..4) take their own vertical lanes
            # beside the tap column (port k on lane 4 + k, PVT_LANE apart); the short tap -> tap segments (one group step,
            # 6 edges: no reach slack for a lane jog out and back) run straight down the column
            try:
                tap_ = by[a]
                k_ = int(bid.split('_')[2])
                pvp_ = by[f'pvw_{STACKS.index(bid.split("_")[1]) % 2}']
                west_ = tap_.x < pvp_.x
                # trunk A's fork -> tap 3 run passes trunk B's groups (lanes 4..7); below group 4 trunk B has ended and
                # trunk A's tap -> tap segments take the near lanes 0..3 (a far lane's jog out and back costs ~2 x its
                # offset of the 6-edge group step's reach slack)
                far_ = bid.startswith('pvta_') and bid.endswith('_3')
                off_ = PVFORK_GAP + pvtap_frame(7)[0] + 21.6 + 4.32 + 15.0 + PVT_LANE * (k_ + (PVT_A_LANE0 if far_ else 0))
                lx_ = pvp_.x - off_ if west_ else pvp_.x + pvp_.w + off_
                yb_ = by[b].y + by[b].h / 2
                pin_ = _PIN_HINT.get((b, pb.lstrip('*')))
                if pin_ is not None:
                    yb_ = pin_[1]

                def vcell_(x_, y_):
                    wy_ = int(y_ // G)
                    for dx_ in range(0, 12):
                        for sgn in (1, -1):
                            wx_ = int(x_ // G) + sgn * dx_
                            if 0 <= wx_ < nx and 0 <= wy_ < ny and not owner.get((wx_, wy_)):
                                return (wx_, wy_)
                    raise ValueError('no lane cell')
                w1, w2 = vcell_(lx_, tap_.y + tap_.h / 2), vcell_(lx_, yb_)
                q1 = route_(a, 'pvt_l1', near_pin(ring(by[a]), a, pa), {w1})
                q2 = route_('pvt_l1', 'pvt_l2', [w1], {w2})
                q3 = route_('pvt_l2', b, [w2], set(near_pin(ring(by[b]), b, pb)))
                path = q1 + q2[1:] + q3[1:]
            except ValueError as e_:
                print(f'kv die PV_T: {bid} lane route failed ({e_}); shortest path', file=sys.stderr)
                path = None
        if path is None:
            path = route(a, b, pa, pb)
        L = (len(path) + 1) * G            # + the cell from each frame edge to the ring
        lengths[bid] = round(L, 1)
        span = bits * 0.048 + 4.0
        fw, fh = (52.68, 30.24) if bits <= 512 else (52.68, up(span, GY))
        mst = f'qkd_rly_{bits}'
        TG = (2.16, 10.8) if bid in tree_meta else (4.32, 21.6)
        if bid in tree_meta:
            # v1.4.2: a reset / boot tree hop is ONE flop: its own 10.8-um relay master qkd_rly_t1 (same RTL rule: one flop a
            # bit, no reset), so it fits the 43.2-um channels between the stack-column blocks the 52.68-um frame cannot
            fw, fh, mst = 10.8, 10.8, 'qkd_rly_t1'
            if __import__('os').environ.get('OT_KV_RLY_STD', '0') == '1':
                import kv_rly_std as RS      # Q-KVSYS-RLY: the tree hop binds one qkd_rlys_1 (12.96 um: PG / pin access)
                fw, fh = RS.STD[1][0] + SHAVE, RS.STD[1][1] + SHAVE
        elif __import__('os').environ.get('OT_KV_RLY_STD', '0') == '1':
            # Q-KVSYS-RLY 2026-10-16 (owner 'fewer distinct tiles', VIS-ROM QKV-04): the frame is the ROW of relay-standard
            # replicas (qkd_rlys_1 / 36 / 296 / 528, M4 pins <= 6.94 /um, face <= 82.08 um) that kv_rly_std.py binds
            # in the netlist pass; default off = the per-width frames above, unchanged
            import kv_rly_std as RS
            fw, fh, _ = RS.layout(bits, RS.frame_rev(bid))
            # the pre-expansion frame abstract still draws the whole word on one M4 face (pitch 1): a word over
            # 82.08 um of M4 (qkd_rly_2089 only) keeps today's frame height around the 82.08-um replica row
            fw, fh = fw + SHAVE, max(fh + SHAVE, span if bits > 512 else 0.0)
            fh = up(fh, GY) if fh > RS.STD[528][1] + SHAVE else fh

        def near_d(r0, r1):
            # nearest-point Manhattan distance between two rectangles (x0, y0, x1, y1)
            dx_ = max(0.0, r0[0] - r1[2], r1[0] - r0[2])
            dy_ = max(0.0, r0[1] - r1[3], r1[1] - r0[3])
            return dx_ + dy_
        rect = lambda it: (it.x, it.y, it.x + it.w, it.y + it.h)  # noqa: E731
        # qwen-1010/b 2026-10-10: hops are measured PIN TO PIN (relay in-pin a on its W face, out-pin b on its E face;
        # an engine control tile's rq / rs on its fixed face; any other end = its frame, whose word is drawn level with
        # this peer by _land_level_pins) -- the frame-to-frame measure let 600-700 um pin hops through
        def fixed_pin(inst, port):
            if bid in tree_meta and inst in by and max(by[inst].w, by[inst].h) > 2 * PIN_REACH:
                return None       # v1.4.2 tree: a big frame's area reset pin is reached at the frame (over-macro last hop)
            lp_ = _leaf_pin(by[inst], port) if inst in by else None
            if lp_ is not None:
                return lp_
            if (inst, port.lstrip('*')) in _PIN_HINT:
                return _PIN_HINT[(inst, port.lstrip('*'))]
            it_ = by[inst]
            if it_.master == 'qkd_ectl' and port.lstrip('*') in ('rq', 'rs'):
                x_ = it_.x + (it_.w if it_.orient in ('MY', 'R180') else 0.0)
                return (x_, it_.y + it_.h / 2)
            return None

        def d_ep(pt, inst, port):
            fp = fixed_pin(inst, port)
            if fp is not None:
                return abs(pt[0] - fp[0]) + abs(pt[1] - fp[1])
            it_ = by[inst]
            return near_d((pt[0], pt[1], pt[0], pt[1]), rect(it_))
        prev_pt, prev_ep, k, idx0 = None, (a, pa), 0, 0
        offs = [(0, 0)] + [(i * G, j * G) for r_ in (range(1,7) if (m['geo'].get('kv_wq_leaf_s') or m['geo'].get('relay_half_grid')) else (1,2,3)) for i in range(-r_, r_ + 1) for j in range(-r_, r_ + 1)
                           if max(abs(i), abs(j)) == r_]

        def remaining():
            if prev_pt is None:
                fa, fb = fixed_pin(a, pa), fixed_pin(b, pb)
                if fa is not None:
                    return d_ep(fa, b, pb)
                if fb is not None:
                    return d_ep(fb, a, pa)
                return near_d(rect(by[a]), rect(by[b]))
            return d_ep(prev_pt, b, pb)
        st_ = dict(prev_pt=None, prev_ep=(a, pa), k=0, idx0=0, path=path, wide=bid in tree_meta)
        if V144_R6 and bid.startswith('pvrq_'):
            # kvs13d: WP = PV_W - O; spread over the path (hop <= length / (WP + 1)), the rest padded at the V port end
            st_['min_k'] = max(0, PV_W - (stages.get('pvin_' + bid[5:], 0) + 1 + stages.get('pvh_' + bid[5:], 0) if PV_T
                                          else stages.get('pvin_' + bid[5:], 0)))
            st_['wide'] = True
        if PV_T and bid.startswith(('pvc_', 'pvta_', 'pvtb_')):
            # the chunk lands DELTA_g edges after its header (the pair's in-array V path is 7 + NS stages shorter than
            # its command path for group g): KVPLAN2 2215 trunk + taps, the stages each bus owes (pvt_exact), spread along
            # its route by the per-stage pitch in reach_()
            ex_ = pvt_exact(bid, stages)
            if ex_ is not None:
                st_['min_k'] = ex_
                st_['exact_k'] = ex_
            elif bid.startswith(('pvta_', 'pvtb_')):
                # a trunk run aims at one stage under its share (fork -> top tap: header + DELTA_top - 1; tap -> tap: the
                # group step's 6 edges = 5 relays + the tap) so a crowded run still lands within it; the shortfall goes
                # to the chunk face hops
                D_ = pvt_plan()['chunk_delta_vs_header']
                g_ = int(bid.rsplit('_', 1)[1])
                sk_ = bid.split('_', 1)[1].rsplit('_', 1)[0]
                own_ = (stages[f'pvh_{sk_}'] + int(D_[str(g_)]) - 1) if g_ in (3, 7) else \
                    (int(D_[str(g_)]) - int(D_[str(g_ + 1)]) - 1)
                st_['soft_k'] = own_ - PVT_SOFT_SLACK
                st_['max_k'] = own_          # more stages than its share: re-place with a longer pitch
            st_['wide'] = True
            if bid.startswith('pvta_') and bid.endswith('_3'):
                st_['offmax'] = 2 * G   # the laned run: first try on its own lane (the retries widen to PIN_REACH / 2)
        offs_wide = [(0, 0)] + [(i * G, j * G) for r_ in range(1, 11) for i in range(-r_, r_ + 1) for j in range(-r_, r_ + 1)
                                if max(abs(i), abs(j)) == r_]
        if PV_T and bid.startswith(('pvc_', 'pvta_', 'pvtb_')):
            # KVPLAN2 2215: an exact-stage PV trunk / chunk stage may sit up to PVT_OFFS grid cells off its lane (the free half of
            # the side channel beside the lanes) -- each hop is still checked against the reach
            # KVR-PLACE 10-19: with the grown ECTL frame + native ASTK envelope the chunk lanes beside the pair face fill
            # (pvc_WS_3_7 no spot at radius 8 = 173 um) while the outer half of the ~900-um side channel stays empty:
            # default radius 16 (346 um, still inside the side channel; every hop is reach-checked) unless OT_KV_PVT_OFFS
            po_ = PVT_OFFS if 'OT_KV_PVT_OFFS' in os.environ else (16 if ECTL == ECTL_ST else PVT_OFFS)
            offs_wide = [(0, 0)] + [(i * G, j * G) for r_ in range(1, po_ + 1) for i in range(-r_, r_ + 1)
                                    for j in range(-r_, r_ + 1) if max(abs(i), abs(j)) == r_]
        if bid in tree_meta:      # v1.4.2: a 1-bit tree hop may sit up to 24 grid cells off its path
            offs_wide = [(0, 0)] + [(i * G, j * G) for r_ in range(1, 25) for i in range(-r_, r_ + 1)
                                    for j in range(-r_, r_ + 1) if max(abs(i), abs(j)) == r_]
        def ctr_dbg(i_, p_):
            q_ = by[i_]
            return (round(q_.x), round(q_.y), round(q_.w), round(q_.h), _PIN_HINT.get((i_, p_.lstrip('*'))))
        mark = (len(nb), len(m['insts']))
        cells_added = []

        def remaining_():
            if st_['prev_pt'] is None:
                fa, fb = fixed_pin(a, pa), fixed_pin(b, pb)
                if fa is not None:
                    return d_ep(fa, b, pb)
                if fb is not None:
                    return d_ep(fb, a, pa)
                return near_d(rect(by[a]), rect(by[b]))
            return d_ep(st_['prev_pt'], b, pb)

        phy_a = PHY_REG and by[a].master in PHY_MASTERS
        phy_b = PHY_REG and by[b].master in PHY_MASTERS
        # KVPLAN3 0230 (OT_KV_SEAM): which hop of this chain crosses core clock trees.  A tree hop's relays run on the
        # leader's tree, so its seam is the FIRST hop (HOST / parent -> first station); a data chain's relays run on its
        # driver's tree, so its seam is the LAST hop (last relay -> load)
        src_dom = ckdom.get(tree_meta[bid].get('rdrv', a) if bid in tree_meta else a)
        dst_dom = ckdom.get(b)
        seam_first = SEAM and bid in tree_meta and src_dom and dst_dom and src_dom != dst_dom
        seam_last = SEAM and bid not in tree_meta and src_dom and dst_dom and src_dom != dst_dom

        def end_reach_():
            # the chain stops once the load end is within this of its last register
            if bid in tree_meta:
                return TREE_LAST
            if seam_last and SEAM_DATA_REACH > 0:
                return min(SEAM_DATA_REACH, PHY_REACH if phy_b else SEAM_DATA_REACH, reach_())
            return min(PHY_REACH, reach_()) if phy_b else reach_()

        def reach_():
            # the PV pair words keep the plain reach (their in-array distribution is the PV pair successor's; the width
            # class moved pvin's planned end off the r6 W-equalised face pins: kvt13k-a 3 unrepaired 1.2-4.2 mm hops)
            tgt_ = st_['exact_k'] if st_.get('exact_k') is not None else st_.get('soft_k')
            if tgt_ is not None and st_['k'] < tgt_:
                # KVPLAN2 2215 (kvs13l plan: pvc_WS_0_0 ran 85 stages for exact 49 and stranded off its path): the pitch is
                # re-derived at every stage from the path still to go over the stages still owed (+ one relay width a
                # hop: a W-in / E-out relay on a vertical run gives up fw of Manhattan reach), so a stage that lands short
                # of the even pitch is made up by the next ones instead of accumulating
                n_ = tgt_ - st_['k']
                rem_ = max(0.0, (len(st_['path']) - 1 - st_['idx0']) * G) + G
                if rem_ < 150.0 * n_:
                    # pure padding on a short route (a chunk's face hop): full reach, the stages fold around the end
                    return min(reach0_(), width_reach(bits))
                return min(reach0_(), width_reach(bits), max(2 * G, (rem_ / n_ + fw) * st_.get('pscale', 1.0)))
            if tgt_ is not None:
                return min(reach0_(), width_reach(bits))
            if st_.get('hop_override'):
                return min(reach0_(), st_['hop_override'])
            return min(reach0_(), width_reach(bits)) if bid not in tree_meta and not bid.startswith('pv') else reach0_()

        def reach0_():
            if seam_first and st_['prev_pt'] is None:
                return min(SEAM_REACH, HOP_REACH if HOP else PIN_REACH)
            if phy_a and st_['prev_pt'] is None:
                return min(PHY_REACH, HOP_REACH if HOP else PIN_REACH)
            # v1.3 (kvs5L TT -17.19: CLOSED ctl_bin launches f<g> late, 413 um to its first relay): a bus whose driver is a
            # closed view with a late launch takes its FIRST relay within FIRST_REACH of that pin; later hops keep PIN_REACH
            if HOP:
                fr_ = FIRST_REACH.get(bid.rsplit('_', 2)[0], HOP_FIRST.get(bid.split('_')[0], HOP_REACH))
                return min(fr_, HOP_REACH) if st_['prev_pt'] is None else HOP_REACH
            if st_['prev_pt'] is None:
                return FIRST_REACH.get(bid.rsplit('_', 2)[0], PIN_REACH)
            return PIN_REACH

        def chain_():
            path_ = st_['path']
            while remaining_() > end_reach_() or st_['k'] < st_.get('min_k', 0):
                got = None
                prev_pt_, idx0_ = st_['prev_pt'], st_['idx0']
                rch = reach_()
                # the farthest path point (from the previous chain point) with a free spot within reach
                idxs = list(range(min(len(path_) - 1, idx0_ + int(rch // G) + 2), idx0_, -1))
                pad_ = st_['k'] < st_.get('min_k', 0) and remaining_() <= reach_()
                if pad_:
                    # kvs13d request padding: the word already reaches the V port; further registered stages go on free
                    # spots along the last reach of its path, each within reach of the previous stage AND of the V port
                    idxs = list(range(len(path_) - 1, max(-1, len(path_) - 2 - int(rch // G)), -1))
                at_end = bid in tree_meta and not idxs
                if at_end:
                    idxs = [len(path_) - 1]          # at the path end: spots around the leader itself
                elif not idxs and PV_T and bid.startswith(('pvta_', 'pvtb_', 'pvc_')):
                    idxs = [len(path_) - 1]          # KVPLAN2 2215: a stage that sat off the path end -- spots at the end
                for idx in idxs:
                    px, py = path_[idx]
                    best_ = None
                    for dx_, dy_ in (offs_wide if st_.get('wide') else offs):
                        if st_.get('offmax') and abs(dx_) + abs(dy_) > st_['offmax']:
                            continue      # Q-KVSYS-HOP retry: a spot stays near its path point (no stranded off-path hop)
                        qx, qy = up(px + dx_ - fw / 2, GX), up(py + dy_ - fh / 2, GY)
                        pin_a = (qx, qy + fh / 2)
                        dd = d_ep(pin_a, a, pa) if prev_pt_ is None else abs(pin_a[0] - prev_pt_[0]) + abs(pin_a[1] - prev_pt_[1])
                        if dd <= rch and free(qx, qy, fw, fh, *TG):
                            if pad_ and (d_ep((qx + fw, qy + fh / 2), b, pb) > rch or (qx, qy) == tuple(st_.get('last_xy', ()))):
                                continue
                            if not at_end:
                                got = (qx, qy, idx)
                                break
                            # a tree hop: of the free spots at this path point, the one nearest the leader (progress)
                            r_ = d_ep((qx + fw, qy + fh / 2), b, pb)
                            if at_end and prev_pt_ is not None and r_ >= remaining_() - 1.0:
                                continue
                            if best_ is None or r_ < best_[0]:
                                best_ = (r_, qx, qy, idx)
                    if best_ is not None:
                        got = best_[1:]
                    if got:
                        break
                if got is None and phy_b and bid not in tree_meta and remaining_() <= reach_():
                    m.setdefault('phy_short', []).append((bid, round(remaining_(), 1)))   # no free spot nearer the PHY
                    break
                if got is None and bid in tree_meta and remaining_() <= reach_():
                    m.setdefault('tree_short', []).append((bid, round(remaining_(), 1)))   # no spot nearer the leader
                    break
                if got is None:
                    raise ValueError(f'kv die relays: no spot for {bid} stage {st_["k"]} after path index {idx0_}'
                                     f' at {path_[idx0_] if idx0_ < len(path_) else None} (ends {a}.{pa} -> {b}.{pb};'
                                     f' path {len(path_)} cells, remaining {remaining_():.0f} um, wide {st_.get("wide")}, src {ctr_dbg(a, pa)} dst {ctr_dbg(b, pb)})')
                nm = f'rly_{bid}_{st_["k"]}'
                it = F.Inst(nm, mst, got[0], got[1], fw - SHAVE, fh - SHAVE, 'R0', kind='relay', region='relay')
                m['insts'].append(it)
                by[nm] = it                       # v1.4.2: a tree's next-level chain starts at this relay
                rly_ends[nm] = (tree_meta[bid]['rdrv'] if bid in tree_meta else a, b)   # tree: the HOST's trunk
                if KSD.DOMSPLIT and bid not in tree_meta:
                    import kv_pin_repair as _kpr
                    rly_dom[nm] = _kpr.launch_domain(by, (a, pa), (b, pb))
                if SEAM and bid in tree_meta:
                    rly_ends[nm] = (b, b)          # KVPLAN3 0230: a reset station runs on the tree of the tiles it feeds
                for gx in range(int(it.x // G), int((it.x + fw) // G) + 1):
                    for gy in range(int(it.y // G), int((it.y + fh) // G) + 1):
                        r_ = (it.x, it.y, it.x + fw, it.y + fh)
                        rocc.setdefault((gx, gy), []).append(r_)
                        cells_added.append(((gx, gy), r_))
                nb.append((f'{bid}__r{st_["k"]}' if st_['k'] else bid, cl, bits, [st_['prev_ep'], (nm, 'a')]))
                st_.update(prev_ep=(nm, 'b'), prev_pt=(it.x + it.w, it.y + it.h / 2), idx0=got[2], k=st_['k'] + 1)

        def rollback_():
            for it_ in m['insts'][mark[1]:]:
                rly_ends.pop(it_.name, None)
            del m['insts'][mark[1]:]
            del nb[mark[0]:]
            for cell, r_ in cells_added:
                rocc[cell].remove(r_)
            cells_added.clear()
            st_.update(prev_pt=None, prev_ep=(a, pa), k=0, idx0=0)
        # Q-KVSYS-HOP 2026-10-16 (OT_KV_RLY_STD=1 case: rst_die_t0_6 stage 19 found no spot): the std relay rows
        # (up to 118.8 x 106 um) fill the channels, and the wide (24-cell) spot search strands a chain off its path, so a
        # chain that fails BOTH attempts gets up to three more (below).  Reached only where the planner raised before:
        # every case that built is unchanged.
        for attempt in (0, 1, 2, 3):
            try:
                chain_()
                # KVPLAN2 2215: an exact-stage PV chain that landed one or two stages off re-places on the same route
                # with a longer / shorter pitch (crowding shortens hops; the count is a static schedule constant)
                for _ in range(6):
                    if st_.get('max_k') is not None:
                        if st_['k'] <= st_['max_k']:
                            break
                        sc_ = st_.get('pscale', 1.0) * 1.12
                    elif st_.get('exact_k') is None or st_['k'] == st_['exact_k']:
                        break
                    else:
                        sc_ = st_.get('pscale', 1.0) * (1.12 if st_['k'] > st_['exact_k'] else 0.9)
                    rollback_()
                    st_['pscale'] = sc_
                    chain_()
                break
            except ValueError as e_att_:
                if _krs_top_lane(m, bid) is not None:
                    print(f'kv die KRS_TOP_LANE: {bid} attempt {attempt} failed: {str(e_att_)[:300]}', file=sys.stderr)
                if attempt == 3 or not m['geo'].get('split') or (attempt and bid not in tree_meta
                                                                    and __import__('os').environ.get('OT_KV_RLY_STD', '0') != '1'):
                    raise
                if attempt:
                    # retries 2-4: route 1 / 2 / 0 cells clear of placed relays, and every spot within PIN_REACH / 2 of
                    # its path point (an off-path hop up to 24 cells away stranded rst_die_t0_6 500 um from its path)
                    rollback_()
                    st_['wide'] = True
                    st_['offmax'] = PIN_REACH / 2
                    SP['on'] = True
                    SP['dil'] = (1, 2, 0)[attempt - 1]
                    try:
                        st_['path'] = route(a, b, pa, pb)
                    except ValueError:
                        SP['dil'] = 0
                        try:
                            st_['path'] = route(a, b, pa, pb)
                        except ValueError:
                            SP['on'] = False       # as the v1.4.2 tree retry: the relay-avoiding route can be closed
                            st_['path'] = route(a, b, pa, pb)
                    finally:
                        SP['on'] = False
                        SP['dil'] = 0
                    continue
                # v1.1 (split): the chain ran out of relay spots in a corridor other chains fill: re-route it around
                # every cell those chains' relays hold and place it again
                rollback_()
                st_['wide'] = True        # and look for a relay spot up to 10 grid cells off the path (was 6)
                SP['on'] = True
                try:
                    st_['path'] = route(a, b, pa, pb)
                except ValueError:
                    if bid not in tree_meta and __import__('os').environ.get('OT_KV_RLY_STD', '0') != '1':
                        raise
                    # v1.4.2 tree hop: the relay-avoiding route can be closed; keep the plain one.  KVPLAN3 0230 (HDR_CTL
                    # plan: pvin_ES_3 fork ring enclosed by the trunks' first stages -> 'no route' raised out of the
                    # retry loop): under OT_KV_RLY_STD every chain has retries 2-4, so a closed relay-avoiding route
                    # falls back to the plain one and the next attempt re-routes with a dilation
                    SP['on'] = False
                    st_['path'] = route(a, b, pa, pb)
                finally:
                    SP['on'] = False
        n = st_['k']
        if (seam_first or seam_last) and n:
            seams.append(dict(bus=bid, hop='first' if seam_first else 'last', src=src_dom, dst=dst_dom, stages=n,
                              reach=SEAM_REACH if seam_first else (SEAM_DATA_REACH or None)))
        if st_.get('exact_k') is not None and n != st_['exact_k']:
            m.setdefault('pvt_chunk_mismatch', []).append(dict(bus=bid, stages=n, need=st_['exact_k'], route_um=lengths.get(bid),
                                                               a=f'{a}.{pa}', b=f'{b}.{pb}'))
        stages[bid] = n
        if bid in tree_meta:
            tm = tree_meta[bid]
            src_ = st_['prev_ep'] if n else (a, pa)
            tm['depth'] = tm.get('pdepth', 0) + n
            if region_roots and tm.get('level') == 0 and tm['root'].startswith('rst_') and n:
                # v1.4.3 regional reset root (coordinator 2026-10-15): the last stage of this region's chain becomes a
                # qkd_rst_region (POR-held local reset, chain ignored until flushed, release calendar dly = D - d_r);
                # the region's local tree depth restarts at the root, the chain depth d_r is compensated by the strap
                rr_ = f'rly_{bid}_{n - 1}'
                by[rr_].master = 'qkd_rst_region'
                m.setdefault('reset_regions', []).append(dict(root=tm['root'], inst=rr_, d=n, lead=list(tm['lead'])))
                tm['depth'] = 0
            for e in tm['members']:
                nb.append((f'{bid}__m', 'reset', 1, [src_, e]))
                m['tree_depth'][(tm['root'], e)] = tm['depth']
            for c_ in tm['children']:
                tree_meta[c_]['src'] = src_
                tree_meta[c_]['pdepth'] = tm['depth']
                order_.append((c_, 'kv_oneway', 1, [src_, tree_meta[c_]['lead']]))
            if tm['children']:
                continue          # an inner node's leader is only an aim point: it takes its reset in its own leaf cluster
            m['tree_depth'][(tm['root'], tm['lead'])] = tm['depth']
        if n == 0:
            nb.append((bid, cl, bits, eps))
            continue
        nb.append((f'{bid}__r{n}', cl, bits, [st_['prev_ep'], (b, pb)]))
    # el1011-q-kvd 2026-10-12 (region-DRT pilot, results/physical/die_region_drt_1012/README.md): a relay is a register
    # stage on the core clock, but its ck was on no bus, so the auto-pin pass never drew it -> qkd_rly_* LEF/odb masters
    # had only a/b, the element lib (pins from the LEF) carried no arcs, and the die STA could not time a single relay hop.
    # Each relay now joins the core clock trunk of the instance that drives its bus (else its load's, else the centre).
    if tree_meta:
        # one net a driver: a relay / root pin feeding several next-level chains, its own leader and members
        def is_tree(b_):
            return re.sub(r'__(r\d+|m)$', '', b_) in tree_meta
        merged, order_d = {}, []
        rest = []
        for bid_, cl_, bits_, eps_ in nb:
            if not is_tree(bid_):
                rest.append((bid_, cl_, bits_, eps_))
                continue
            d_ = eps_[0]
            if d_ not in merged:
                merged[d_] = [bid_, list(eps_[1:])]
                order_d.append(d_)
            else:
                merged[d_][1] += [e for e in eps_[1:] if e not in merged[d_][1]]
        for d_ in order_d:
            bid_, loads_ = merged[d_]
            # a relay -> relay hop keeps the chain class (pin reach / CDC checks); a fan-out is a reset net
            # (the HBM PHY model's rst_n is an AREA pin at the strip centre: its last hop is an over-the-macro M8/M9 wire
            # no relay can shorten -> a reset net, timed by the die STA, not a pin-reach hop)
            # same for any frame larger than two hops (astk / ctrl / landing strips: area rst_n inside the frame, whose
            # expanded leaves take it from the frame edge)
            hard = any(by[i_].master == SPLIT_PHY or max(by[i_].w, by[i_].h) > 2 * PIN_REACH for i_, _ in loads_)
            rest.append((bid_, 'kv_oneway' if len(loads_) == 1 and not hard else 'reset', 1, [d_] + loads_))
        nb = rest
        dep = {}
        for (root_, e), d_ in m['tree_depth'].items():
            dep[root_] = max(dep.get(root_, 0), d_)
        m['tree_depth_max'] = dep
        if max(dep.values()) >= RELAY_FLUSH:
            raise ValueError(f'kv die reset trees: depth {dep} >= RELAY_FLUSH {RELAY_FLUSH}; deepest '
                             f'{sorted(m["tree_depth"].items(), key=lambda kv: -kv[1])[:4]}')
        if m.get('reset_regions'):
            # v1.4.3: per reset root, D = its deepest region chain; every region root is strapped dly = D - d_r so all
            # its regions release on host release + D + 2 (each load L later: tree_depth, now the LOCAL depth)
            dmax = {}
            for r_ in m['reset_regions']:
                dmax[r_['root']] = max(dmax.get(r_['root'], 0), r_['d'])
            ties_ = m.setdefault('host_ties', {})
            for r_ in m['reset_regions']:
                if r_['d'] > RST_REGION_IGNORE:
                    raise ValueError(f"kv die reset region {r_['inst']}: chain depth {r_['d']} > IGNORE {RST_REGION_IGNORE}")
                r_['dly'] = dmax[r_['root']] - r_['d']
                cb_ = f"rdly_{r_['inst']}"
                nb.append((cb_, 'constant', 8, [(r_['inst'], 'dly')]))
                ties_[cb_] = (8, r_['dly'])
            m['reset_region_calendar'] = dict(D=dmax, release='host release + D + 2 + local depth', ignore=RST_REGION_IGNORE,
                hold=RELAY_FLUSH, host_min_hold_cycles=RST_REGION_IGNORE + 4, regions=len(m['reset_regions']))
        m['tree_depth'] = {f'{r_}:{e[0]}.{e[1]}': d_ for (r_, e), d_ in sorted(m['tree_depth'].items())}
    if forks_:
        # a branch's first segment (named exactly f'{bid}__f{i}', driven by the trunk's driver) joins the trunk's source net
        idx_ = {e_[0]: i_ for i_, e_ in enumerate(nb)}
        drop_ = set()
        for nm_f, bid_f in forks_.items():
            if nm_f not in idx_ or bid_f not in idx_:
                raise ValueError(f'kv die fork {nm_f}: segment or trunk {bid_f} missing')
            bf_, cf_, wf_, ef_ = nb[idx_[nm_f]]
            bt_, ct_, wt_, et_ = nb[idx_[bid_f]]
            if wf_ != wt_:
                raise ValueError(f'kv die fork {nm_f}: width {wf_} != trunk width {wt_}')
            if ef_[0] != et_[0]:
                raise ValueError(f'kv die fork {nm_f}: driver {ef_[0]} != trunk driver {et_[0]}')
            nb[idx_[bid_f]] = (bt_, ct_, wt_, list(et_) + [e_ for e_ in ef_[1:] if e_ not in et_])
            drop_.add(idx_[nm_f])
        nb = [e_ for i_, e_ in enumerate(nb) if i_ not in drop_]
        m['fork_stages'] = {nm_f: stages.get(nm_f, 0) for nm_f in forks_}
    trunk = {}
    for i, (bid_, cl_, _b, eps_) in enumerate(nb):
        if cl_ == 'clock_trunk' and bid_.startswith('clk_core_'):
            for inst_, _p in eps_[1:]:
                trunk.setdefault(inst_, i)
    adds = {}
    m['relay_domain_split'] = dict(hbm=sorted(n_ for n_ in rly_ends if rly_dom.get(n_) == 'hbm'),
                                   mixed=sorted(n_ for n_ in rly_ends if rly_dom.get(n_) == 'mixed')) if KSD.DOMSPLIT else None
    htrunk = {}                    # KV-DOMSPLIT: instance -> its HBM clock trunk (clk_hbm_<region>)
    if KSD.DOMSPLIT:
        for i, (bid_, cl_, _b, eps_) in enumerate(nb):
            if cl_ == 'clock_trunk' and bid_.startswith('clk_hbm_'):
                for inst_, _p in eps_[1:]:
                    htrunk.setdefault(inst_, i)
    for nm_, (drv, rcv) in rly_ends.items():
        if rly_dom.get(nm_) == 'hbm':
            # KV-DOMSPLIT 10-19: an HBM-launched word (the split group <-> PC hck halves) is relayed on the HBM clock trunk
            # of its driver (else its load): the crossing stays at the consumer's synchroniser, never inside the chain
            i = htrunk.get(drv, htrunk.get(rcv))
            if i is None:
                raise ValueError(f'kv die relays (DOMSPLIT): HBM-launched relay {nm_} ({drv} -> {rcv}) has no clk_hbm_* trunk')
        else:
            i = trunk.get(drv, trunk.get(rcv, next(j for j, e in enumerate(nb) if e[0] == 'clk_core_c')))
        adds.setdefault(i, []).append((nm_, 'ck'))
    for i, extra in adds.items():
        bid_, cl_, bits_, eps_ = nb[i]
        nb[i] = (bid_, cl_, bits_, list(eps_) + extra)
    m['buses'] = nb
    m['relay_stages'] = stages
    m['route_um'] = lengths
    if m.get('pvt_chunk_mismatch'):
        bad_ = sorted(m['pvt_chunk_mismatch'], key=lambda r_: -(r_['stages'] - r_['need']))
        raise ValueError(f'kv die PV_T: {len(bad_)} chunk chains miss header + DELTA_g (the pair absorbs a fixed skew): '
                         f'{bad_[:6]}')


_LANES = {}


def _krs_top_lane(m, bid):
    """DIE-KV-REPLACE / KVR-PLACE 10-19: waypoints (die um, in order driver -> load) of a FAR-column engine's K response
    word krs_<st>_<g> (g 4..7: the ECTL sits across the stack's ASTK column from its slg) that crosses the ASTK column
    through the S|N seam or over the N column top, or None.  With the grown 725.76 x 261.36 ECTL frame (KV-ECTL5 /
    coordinator: keep the frame) each engine group is 4 x 131.76 um taller and, with the native ASTK envelope, the ASTK
    column stands 237 um above the S group top; the shortest paths of these 1,062-b words hug the column end, the one
    relay row every other chain crossing it already fills (prep e5g1..8, local plans r1..r5: no spot krs_ES_7 / krs_WN_7,
    krs_EN_5 re-routed over the N top = 73 stages, K round trip 106 > 80).  Each word gets its OWN relay row (lane):
      S stacks, slg above the column top (g 6, 7):   ASTK top + 173 (g 7) / + 346 (g 6)      (lower half of the seam)
      N stacks, slg below the column bottom (g 4, 5): ASTK bottom - 173 (g 4) / - 346 (g 5)  (upper half of the seam)
      N stacks, slg above the column top (g 6, 7):   ASTK top + OT_KV_KRS_TOP_DY (432, g 7) / + DY - 216 (g 6)
    then down / up its own column of the far channel (OT_KV_KRS_TOP_CH um outward of the ECTL's rs face, 648 for g 7 / 4,
    864 for g 6 / 5) to the rs pin's row.  S stacks g 4 / 5 (slg below the die-edge end of the column) keep the shortest
    path.  OT_KV_KRS_TOP_LANE=0 turns it off; default on with the grown ECTL frame."""
    import os as _os
    if _os.environ.get('OT_KV_KRS_TOP_LANE', '1' if ECTL == ECTL_ST else '0') != '1':
        return None
    mt = re.fullmatch(r'krs_(WS|WN|ES|EN)_([4-7])(?:__f\d+)?', bid or '')
    g = m['geo'].get('grp_y', {})
    if not mt or mt.group(1) not in g:
        return None
    st, e = mt.group(1), int(mt.group(2))
    dy = float(_os.environ.get('OT_KV_KRS_TOP_DY', '432'))
    dch = float(_os.environ.get('OT_KV_KRS_TOP_CH', '648'))
    by = {i.name: i for i in m['insts']}
    ak, ec = by.get(f'astk_{st}'), by.get(f'ectl_{st}_{e}')
    if ak is None or ec is None:
        return None
    if st[1] == 'S':
        if e < 6:
            return None
        ly = ak.y + ak.h + (173.0 if e == 7 else 346.0)
    elif e < 6:
        ly = ak.y - (173.0 if e == 4 else 346.0)
    else:
        ly = max(g[st][1], ak.y + ak.h) + (dy if e == 7 else dy - 216.0)
    rs_x = ec.x + (ec.w if ec.orient in ('MY', 'R180') else 0.0)
    off = dch if e in (4, 7) else dch + 216.0
    cx = rs_x + (off if rs_x > ak.x + ak.w / 2 else -off)
    ry = ec.y + ec.h / 2
    return [(ak.x + ak.w / 2, ly), (cx, ly), (cx, ry)]


def _kv_lane(m, bid):
    """v1.2 lane row (y um) of an N-half KV-row chain of the split die, or None.  Lanes start 64.8 um above the N engine
    groups and step 64.8 um up to two channels below the die edge; the chains are dealt round-robin over them.  The S
    half keeps the shortest paths (its chains leave the centre column between the groups); aq / lt / lx / lr too."""
    # v1.2: OT_KV_LANES=2 lanes only the sequencer-centred chains (kvn / kc / emf / emr): kvs3L's krq / krs lanes cost up to
    # +18 / +16 relay stages on the engine <-> landing KV rows (relay_depth_changes.json), which are local words
    import os as _os
    # v1.2 DEFAULT (kvs5L vs kvs5: TT relay->relay 0 violators / +14.8 vs 59 / -66.7, no depth change): '2'; '0' = off
    rx_ = r'(kvn|kc|emf|emr)_(WN|EN)(?:_|$)' if _os.environ.get('OT_KV_LANES', '2') == '2' else \
        r'(kvn|krs|krq|kc|emf|emr|ing)_(WN|EN)(?:_|$)'
    mt = re.match(rx_, bid)
    g = m['geo'].get('grp_y', {})
    if not mt or not g:
        return None
    y0 = max(v[1] for k, v in g.items() if k[1] == 'N') + 64.8
    n = max(1, int((m['die']['h'] - 2 * CHAN - y0) // 64.8))
    key = id(m)
    j = _LANES.get(key, 0)
    _LANES[key] = j + 1
    return y0 + (j % n) * 64.8


def _regions(m):
    regs = []
    for it in m['insts']:
        if it.kind in ('phy', 'ctrl', 'land', 'phy_d2d', 'phy_host'):
            regs.append(dict(name=f'r_{it.name}', kind=it.kind, rect=[it.x, it.y, it.x + it.w, it.y + it.h]))
    return regs


# ------------------------------------------------------------------------------------------------ masters
def masters(m, k=1, port_bits=None):
    T = tpl()
    by = {i.name: i for i in m['insts']}
    used = {}
    for bid, cl, bits, eps in m['buses']:
        for inst, port in eps:
            used.setdefault(by[inst].master, {})[port.lstrip('*')] = max(bits, used.get(by[inst].master, {}).get(port.lstrip('*'), 0))
    if m['geo'].get('kv_wq_binary') and not m['geo'].get('split'):
        # Physical eight-bit lane port survives; only its low3 pins enter the bus.
        for g in range(4):
            used['qkd_kvwq_ctl_bin_h' if m['geo'].get('kv_wq_head') else 'qkd_kvwq_ctl_bin'][f'f{g}'] = 298
    M = {}
    tmap = dict(qkd_ctrl='qfd_ctrl', qkd_ctrl_n='qfd_ctrl', qkd_cdc='qfd_cdc', qkd_land='qfd_kvc', qkd_land_n='qfd_kvc')
    if m['geo'].get('kv_wq_leaves'):
        tmap['qkd_cdc_wleaf'] = 'qfd_cdc'     # ot_hbm3e_phy: the real LEF (k = 1)
    for name, src in tmap.items():
        if m['geo'].get('static_die') and not any(i_.master == name for i_ in m['insts']):
            continue          # KVJ-G2: superseded by the static subsystem (no instance left)
        t = T['masters'][src]
        if name in ('qkd_land', 'qkd_land_n'):
            mm = F.Master(name, LAND_W - SHAVE, m['geo']['stack_h'] - SHAVE, 7, 'KV landing (qfd_kvc successor)')
            land = by['land_WN' if name == 'qkd_land_n' else 'land_WS']
            for p in t['order']:
                if p in used.get(name, {}):
                    sp = list(t['ports'][p])
                    mt = __import__('re').fullmatch(r'c(\d+)([io])', p)
                    if mt and sp[0] == 'face':
                        cdc = by[f'cdc_{land.name[5:]}_{mt.group(1)}']   # this landing's own CDC column
                        sp[4] = cdc.y + cdc.h / 2 - land.y + (40.0 if mt.group(2) == 'i' else -40.0)
                        if REACH_FIX and mt.group(2) == 'i':
                            sp[4] = _cdc_co_y(cdc) - land.y     # KVPLAN2: level with the closed view's co pins
                    if sp[0] == 'face' and sp[1] * 0.096 + 4.0 < (mm.w if sp[2] in 'NS' else mm.h):
                        sp[5] = 2          # 2-track pitch where the face has room (emf[221] DRT-0073 at 1 track)
                    mm.ports[p] = tuple(sp)
                    mm.order.append(p)
        else:
            w, h = (183.72,183.72) if name == 'qkd_cdc_wleaf' and m['geo'].get('kv_wq_leaf_s') else (t['w'],t['h'])
            mm = F.Master(name, w, h, t['obs_top'], t['note'])
            for p in (dict.fromkeys(t['order']) if name == 'qkd_cdc_wleaf' else t['order']):
                if m['geo'].get('split') and name in ('qkd_ctrl', 'qkd_ctrl_n') and p not in used.get(name, {}):
                    continue      # v1.2: the strip composition has no r21c 'phy' bundle / 'ck' / 'pll_hbm' frame ports
                if name == 'qkd_cdc_wleaf' and p == 'ci':
                    sp = t['ports'][p]
                    for pn, lo, width in [('wi', 0, 290), ('wr', 290, 11), ('cf', 301, 1)]:
                        part = list(sp)
                        part[1] = width
                        # Pin centres retain the original 302-bit ci order and pitch.
                        part[4] = sp[4] + (lo + (width-1)/2 - (302-1)/2)*0.048*sp[5]
                        mm.ports[pn] = tuple(part)
                        mm.order.append(pn)
                else:
                    mm.ports[p] = tuple(t['ports'][p])
                    mm.order.append(p)
            if name in ('qkd_ctrl', 'qkd_ctrl_n') and 'kc' in used.get(name, {}):
                # the stream-command word enters the controller column's OUTER end (S face on the S stacks, N face on
                # the N stacks = qkd_ctrl_n, the only difference between the two masters): the W face abuts the CDC
                # column, the E face the PHY and the inner end the other band, so the outer edge channel is the one
                # face a relay chain reaches
                mm.ports['kc'] = ('face', 33, 'N' if name == 'qkd_ctrl_n' else 'S', 'M5', round(t['w'] / 2, 4), 1)
                mm.order.append('kc')
        M[name] = mm
    sizes = {i.master: (i.w, i.h) for i in m['insts']}
    for mst, (w, h) in sizes.items():
        if mst == 'ot_hbm3e_phy' and k == 1:
            continue
        if mst in (UCIE[0], SERDES[0]):
            mm = F.Master(mst, w, h, 5, 'licensed PHY abstract (real LEF)')
            for p_, bits_ in sorted(used.get(mst, {}).items()):
                if mst == SERDES[0] and p_ == 'fdi' and HOST_V14.get('trees'):
                    # v1.4.2: the real LEF's FDI (tx_flit / rx_flit) is on the W face, y 600.19..700.34
                    mm.face(p_, bits_, 'W', 'M4', 650.26, 1)
                    continue
                mm.face(p_, bits_, 'N', 'M5', w / 2 if p_ == 'fdi' else 6.0 + 2.0 * len(mm.order), 1)
            M[mst] = mm
            continue
        if mst == SPLIT_PHY:
            # v1.2: HBM3E PHY-only abstract (analog model; its digital layer = qkd_ctrl_pc): outline and M1-M4 blockage of
            # the v2_ew PHY abstract, per-PC DFI words on the controller face (pins: _strip_face_pins)
            M[mst] = F.Master(mst, w, h, 4, 'HBM3E PHY abstract, PHY only: per-PC DFI po (in) / pi (out) on the controller face')
            continue
        if mst not in M:
            M[mst] = F.Master(mst, w, h, 7 if not mst.startswith(('qkd_rly', 'qkd_rst_region')) else 3, RTL.get(mst, mst))
    # auto pins: every used port not yet on its master goes to the face nearest its peer, spread along the face
    peer = {}
    for bid, cl, bits, eps in m['buses']:
        if len(eps) == 2:
            for (i0, p0), (i1, p1) in ((eps[0], eps[1]), (eps[1], eps[0])):
                peer.setdefault((by[i0].master, p0.lstrip('*')), []).append(by[i1])
    face_load = {}
    for mst, ports in sorted(used.items()):
        if mst not in M:
            continue
        mm = M[mst]
        inst0 = next(i for i in m['insts'] if i.master == mst)
        for p, bits in sorted(ports.items()):
            if p in mm.ports:
                continue
            if mst == 'qkd_rhead' and p in ('ck', 'rst_n'):
                # the MX head's clock / reset are W-face M4 pins (as its route, cfg qkd_rhead_c): with M8 area pins
                # the mirrored origin needs H = 12 mod 30 nm, which no 2.16-um frame - 0.024 meets (die_kv9: 'site grid
                # never meets the legal residues mod 240'); M4 alone needs H = 0 mod 6 nm (453.576 is)
                mm.face(p, 1, 'W', 'M4', mm.h / 2 + (8.0 if p == 'ck' else -8.0), 1)
                continue
            if mst in ('qkd_kvwq_leaf_s_w129', 'qkd_kvwq_leaf_s_w129_m') and p in ('ck', 'rst_n'):
                # qwen-1010/b 2026-10-11 (die_kv15 real case: 'leaf_s_w129_m MX y: site grid never meets the legal residues
                # mod 240' with M8 area pins): the closed leaf's clock / reset are E-face M4 pins at y 86-97 (its route
                # cfg), so the MX origin only meets the M4 / M5 grids, as the rhead's W-face M4 clock does
                mm.face(p, 1, 'E', 'M4', 88.0 if p == 'ck' else 95.0, 1)
                continue
            if bits == 1 and (p in ('ck', 'clk', 'rst_n', 'rsi', 'c_arst_n', 'rs') or p.startswith(('pll', 'rso'))) and not (
                    KSD.ON and KSD.KITS and mst in KSD.KIT_FACE):     # KITS-B: kit tiles draw clock / reset on a face
                j = len([q for q in mm.order if mm.ports[q][0] == 'area'])
                mm.area(p, 1, min(mm.w - 1.0, max(1.0, mm.w / 2 + ((j % 12) - 6) * 1.6)),
                        min(mm.h - 1.0, max(1.0, mm.h / 2 + (j // 12 - 5) * 1.6)), 1)
                continue
            if mst.startswith('qkd_rly'):
                mm.face(p, bits, 'W' if p == 'a' else 'E', 'M4', mm.h / 2, 1)   # wide relays: frame height = the word
                continue
            if pvt_port(mst, p) is not None:
                f_, fr_ = pvt_port(mst, p)    # KVPLAN3 0230 (OT_KV_PVT_PINS): fork / tap ports on fixed canonical faces
                mm.face(p, bits, f_, 'M4' if f_ in 'EW' else 'M5', round(fr_ * (mm.h if f_ in 'EW' else mm.w), 4), 1)
                continue
            pe = peer.get((mst, p), [inst0])[0]
            dxp, dyp = pe.x + pe.w / 2 - (inst0.x + inst0.w / 2), pe.y + pe.h / 2 - (inst0.y + inst0.h / 2)
            if inst0.orient in ('MY', 'R180'):
                dxp = -dxp
            if inst0.orient in ('MX', 'R180'):
                dyp = -dyp
            face = ('E' if dxp > 0 else 'W') if abs(dxp) >= abs(dyp) else ('N' if dyp > 0 else 'S')
            if mst in ('qkd_kvwq_leaf_s','qkd_kvwq_leaf_s_w129','qkd_kvwq_leaf_s_w129_m'):
                # MX places the S write face against the CDC S face, with the
                # chain direction S->N after the flip (PC0..7).
                face = dict(c='N', n='S', dn='S', dp='N', w='S', wr='S', lane='E').get(p, 'E')
            if mst == 'qkd_ectl':
                # the tile column: si / so to the aggregator (E), the pair-0 copy / returns S, pair-1 N, KV rows W
                face = {'si': 'E', 'so': 'E', 't0': 'S', 'e0': 'S', 'e1': 'S', 's0': 'S', 's1': 'S',
                        't1': 'N', 'e2': 'N', 'e3': 'N', 's2': 'N', 's3': 'N'}.get(p, 'W')
            if mst in ('qkd_rhead', 'qkd_rhead_ft'):
                face = 'E' if p == 'nb' else 'S'  # the S face faces the control tile (heads 0 / 1 are MX)
                if p in ('ft_ti_b', 'ft_e_b', 'ft_s_a'):
                    face = 'N'                    # v1.4.3 feed-through: toward the far head's band
            if mst == 'qkd_hgs':
                face = 'S' if p in ('ti_a', 'e_a') else 'N' if p in ('ti_b', 'e_b') else 'W'
            if mst == 'qkd_hss':
                face = 'W' if p == 's_a' else 'E' if p == 's_b' else 'S'
            if KSD.ON and KSD.pin_face(mst, p):
                face = KSD.pin_face(mst, p)     # KVJ-G2: static tile faces (K / V channel vs control channel)
            if HOP and mst in ('qkd_d2d', 'qkd_d2ds') and face in _covered_faces(m, inst0, peer=pe):
                # OT_KV_HOP: a face covered by an abutting block (the UCIe PHY on the D2D frame's N face) has no die
                # routing: the fwd_epoch / fwd_link_rst_n words were drawn there, 1,208 um from their first relay
                face = ('E' if dxp > 0 else 'W') if face in 'NS' else ('N' if dyp > 0 else 'S')
            if mst in ('qkd_land', 'qkd_land_n') and face in 'NS':
                # the landing is a 172.8 um x 12 mm column: its short faces cannot hold its words (die_kv7: 3,186
                # overlapping pin shapes, PA DRT-0073); every word leaves on the long face toward its peer
                face = 'E' if dxp > 0 else 'W'
            if mst in ('qkd_astk', 'qkd_astk_n') and p[0] in 'ef' and p[1].isdigit():
                face = 'W' if _astk_frame(int(p[1])) < 4 else 'E'     # the face toward the frame running engine p[1]
            layer = 'M4' if face in ('E', 'W') else 'M5'
            # the control tile's horizontal pins all on M4: with M4 + M6 its legal origins sit on an 8.64-um lattice
            # (lcm 48 / 64 / 270 nm) that the 2.16-um tile gaps cannot absorb (die_kv10: no legal origin for ectl_WS_3)
            # the head tile is placed MX / R180 below the control tile: a mirrored master's horizontal pins must be
            # mirror-legal on every layer at once (origin = 2 off - H mod pitch per layer).  M4 (off 12 / 48) and M8 (116 /
            # 80) agree mod 16, M6 (16 / 64) agrees with neither (die_kv8: 'qkd_rhead MX y has no legal origin') -> the
            # head's node beat on M4, its clock / reset area pins on M8, nothing on M6 (the astk faces it on M4)
            L = mm.h if face in ('E', 'W') else mm.w
            fl = face_load.setdefault((mst, face), [])
            # re-cut D faces are narrow enough for 2-track pitch (1-track first bits had no access point next to the
            # die PDN, DRT-0073 on astk e0i[0] / reng so[0])
            mm.face(p, bits, face, layer, 0.0, 2 if (mst in ('qkd_ectl', 'qkd_rhead', 'qkd_astk', 'qkd_astk_n') or (mst in ('qkd_land', 'qkd_land_n') and face in 'NS')) else 1)
            fl.append(p)
        # spread the face pins of each face evenly (centres)
        for face in ('N', 'S', 'E', 'W'):
            fl = face_load.get((mst, face), [])
            if not fl:
                continue
            if KSD.ON:
                fl = KSD.face_order(mst, face, fl)     # KV-PLAN3: static tiles' along-face order
            L = mm.h if face in ('E', 'W') else mm.w
            tot = sum(mm.ports[p][1] for p in fl)
            pos = 2.0
            for p in fl:
                span = (L - 4.0) * mm.ports[p][1] / tot
                sp = list(mm.ports[p])
                sp[4] = pos + span / 2
                if mst in ('qkd_astk', 'qkd_astk_n') and p[0] in 'ef' and p[1].isdigit():
                    e = _astk_frame(int(p[1]))       # level with the frame that runs this engine (OT_KV_ECTL_PAIR)
                    t_ = 'c' if p[0] == 'e' else f'h{p[2]}'
                    sp[4] = (e % 4) * (RENG[1] + GY) + TILE_Y[t_] + (ECTL[1] if t_ == 'c' else HEAD[1]) / 2   # level with its tile
                    if t_ == 'c':            # facing the control tile's si (below) / so (above)
                        sp[4] += (1 if p[-1] == 'i' else -1) * (ECTL[1] - 4.0) * (425 if p[-1] == 'o' else 634) / (2 * 1059)
                if mst == 'qkd_ectl' and p in ('si', 'so'):
                    # one face, one layer: si below so, each centred on its share of the face
                    sp[4] = ECTL[1] / 2 + (-1 if p == 'si' else 1) * (ECTL[1] - 4.0) * (425 if p == 'si' else 634) / (2 * 1059)
                mm.ports[p] = tuple(sp)
                pos += span
        if m['geo'].get('split'):
            _strip_face_pins(mst, mm)
        if mst in ('qkd_hslice', 'qkd_hslice_dn'):
            _slice_pins(m, mm, down=mst == 'qkd_hslice_dn')
        if mst in LEVEL_PIN_MASTERS:
            _land_level_pins(m, mm, inst0, face_load, by)
        if REACH_FIX and mst in ('qkd_land', 'qkd_land_n'):
            _reach_fix_slide(mst, mm)
    if m['geo'].get('split'):
        _split_pins(M, m)
    if 'qkd_d2ds' in M and 'serdes_up' not in M['qkd_d2ds'].ports:
        M['qkd_d2ds'].area('serdes_up', 1, round(M['qkd_d2ds'].w / 2, 3), round(M['qkd_d2ds'].h / 2 - 9.6, 3), 1)   # v1.4 extra_conns tap
    if 'qkd_dcal' in M and 'ego' not in M['qkd_dcal'].ports:
        M['qkd_dcal'].face('ego', 1, 'W', 'M4', round(M['qkd_dcal'].h / 2, 3), 1)      # OT_KV_DCAL extra_conns tap
    if 'qkd_kvnc' in M and 'cs' not in M['qkd_kvnc'].ports:
        M['qkd_kvnc'].face('cs', 1, 'N', 'M5', round(M['qkd_kvnc'].w / 2, 3), 1)      # OT_KV_KVNC extra_conns tap (sequencer above)
    for mst in list(M):
        if mst not in used and mst not in sizes:
            M.pop(mst)
    for name, ports in m.get('assigned_ports', {}).items():
        if name in M:
            M[name].ports.update({p: tuple(v) for p, v in ports.items() if p in M[name].ports})
    return M


# kvsys v1.1: die-assigned pins of the native head frame and the three-leaf control frame (top-down, owner 10-13).
# t0 / t1 (S1b copy to a head pair, 1,559 b) leave the control tile on M5 at 6-track pitch over x 8.5..457.5 of its S / N
# face; every head's ti lands on its control-facing face at the SAME x (the control tile is centred in the column, offset
# EXO), so a far head's bits run straight over its near neighbour on M9 (one head height + gap, <= 504 um, no relay).
ECTL_T_CX = 233.0
ECTL_E_X = (470.0, 471.6)          # e0 / e1 (S face) and e2 / e3 (N face): a pair's two e words side by side
ECTL_S_X = (490.0, 493.4)          # s0 / s1, s2 / s3
ECTL_CK_X = (127.44, 382.32, 578.88)   # leaf A / B / C centres (254.88 | 254.88 | 138.24 x 129.6)


def _split_pins(M, m=None):
    # KV-CASE 10-18: the static die re-binds every ECTL frame to qkd_ectlk (kv_static_die: ECTL A + static K issuer, same
    # 648 x 129.6 frame, same t / e / s faces).  This block was keyed on 'qkd_ectl' only, so with OT_KV_STATIC_DIE=1 the
    # ECTL t / e / s pins AND every head / feed-through head pin below fell back to the auto face spread (head ft_e_a at
    # x 38 instead of over the T1 leaf: 576 stack-local hops up to 966 um, kvs14a case).  Both ECTL masters take the
    # die-assigned positions; the head frames take theirs whenever either ECTL master is present.
    ectls_ = [n_ for n_ in ('qkd_ectl', 'qkd_ectlk') if n_ in M]
    for ectl_ in ectls_:
        mm = M[ectl_]
        for f, (tp, es) in (('S', ('t0', (('e0', 'e1'), ('s0', 's1')))), ('N', ('t1', (('e2', 'e3'), ('s2', 's3'))))):
            if tp in mm.ports:
                mm.ports[tp] = ('face', mm.ports[tp][1], f, 'M5', ECTL_T_CX, 6)
            for pair, xs in zip(es, (ECTL_E_X, ECTL_S_X)):
                for p_, x_ in zip(pair, xs):
                    if p_ in mm.ports:
                        mm.ports[p_] = ('face', mm.ports[p_][1], f, 'M5', x_, 2)
        for c_, x_ in zip(ECTL_CK_X, ECTL_CLK):
            if x_ in mm.ports:
                mm.ports[x_] = ('area', 1, c_, ECTL[1] / 2, 1)
        if 'rst_n' in mm.ports:
            mm.ports['rst_n'] = ('area', 1, ECTL[0] / 2, ECTL[1] / 2 + 8.0, 1)
        if ectl_ == 'qkd_ectlk' and ECTL == ECTL_ST:
            # KV-ECTL4: the hardened qkd_ectl3_kiss_st frame's exact pins (kit io_tcl), every port it has
            for p_, v_ in _ectl_st_ports().items():
                if p_ in mm.ports:
                    if mm.ports[p_][1] != v_[1]:
                        raise ValueError(f'kv_die: qkd_ectlk {p_} {mm.ports[p_][1]} b vs kit {v_[1]} b')
                    mm.ports[p_] = v_
    if ectls_:
        exo = up((HEAD[0] - ECTL[0]) / 2, GX)
        if 'qkd_rhead' in M:
            hm = M['qkd_rhead']
            for p_, x_, pt_ in (('ti', exo + ECTL_T_CX, 6), ('e', exo + sum(ECTL_E_X) / 2, 2), ('s', exo + sum(ECTL_S_X) / 2, 2)):
                if p_ in hm.ports:
                    hm.ports[p_] = ('face', hm.ports[p_][1], 'S', 'M5', x_, pt_)
            if 'nb' in hm.ports:
                hm.ports['nb'] = ('face', hm.ports['nb'][1], 'E', 'M4', HEAD[1] / 2, 2)
            # v1.2 (head r4): the 86 clock entries (+ reset) are W-face M4 pins (an M8 area pin breaks the MX head's
            # mirror-legal origin: kvs4 real case 'qkd_rhead MX y: site grid never meets the legal residues mod 240'),
            # each level with the centre of the child it clocks (Codex r4 plan, canonical R0 = control face S), de-
            # overlapped at >= 1.2 um; one CTS sink per child, delivered at phi - R of that child
            ch = json.loads((ROOT / HEAD_R4_PLAN).read_text())['children']
            want = sorted((ch[HEAD_CLK_CHILD[p_]][1] + ch[HEAD_CLK_CHILD[p_]][3] / 2, p_) for p_ in HEAD_CLK if p_ in hm.ports)
            ys_, last = {}, 2.0 - 1.2
            for y_, p_ in want:
                last = max(y_, last + 1.2)
                ys_[p_] = last
            top = HEAD[1] - 12.0
            if ys_ and max(ys_.values()) > top:          # pack downward from the top when the run overflows the face
                for p_ in sorted(ys_, key=ys_.get, reverse=True):
                    ys_[p_] = min(ys_[p_], top)
                    top = ys_[p_] - 1.2
            for p_, y_ in ys_.items():
                hm.ports[p_] = ('face', 1, 'W', 'M4', round(y_, 3), 1)
            if 'rst_n' in hm.ports:
                hm.ports['rst_n'] = ('face', 1, 'W', 'M4', 440.0, 1)
        if 'qkd_rhead_ft' in M:
            # v1.4.3 near head: the r4 head pins (children from HEAD_FT_PLAN: lane rows >= 1 sit 16.2 um higher) + the
            # far neighbour's feed-through: ft_ti_a / ft_e_a on the S (control) face and ft_ti_b / ft_e_b on the N face
            # straight over the T1 leaf's pins (V143_FT ftg, pins 13.5 + 0.192 i), ft_s_a N / ft_s_b S over the S2 leaf
            hm = M['qkd_rhead_ft']
            for p_, x_, pt_ in (('ti', exo + ECTL_T_CX, 6), ('e', exo + sum(ECTL_E_X) / 2, 2), ('s', exo + sum(ECTL_S_X) / 2, 2)):
                if p_ in hm.ports:
                    hm.ports[p_] = ('face', hm.ports[p_][1], 'S', 'M5', x_, pt_)
            if 'nb' in hm.ports:
                hm.ports['nb'] = ('face', hm.ports['nb'][1], 'E', 'M4', SPLIT_HEAD_FT[1] / 2, 2)
            gx_, sx_ = V143_FT['ftg'][0], V143_FT['fts'][0]
            for p_, f_, x_, pt_ in (('ft_ti_a', 'S', gx_ + 13.5 + 0.096 * 1558, 4), ('ft_ti_b', 'N', gx_ + 13.5 + 0.096 * 1558, 4),
                                    ('ft_e_a', 'S', gx_ + 314.27, 4), ('ft_e_b', 'N', gx_ + 314.27, 4),
                                    ('ft_s_a', 'N', sx_ + 10.8, 2), ('ft_s_b', 'S', sx_ + 10.8, 2)):
                if p_ in hm.ports:
                    hm.ports[p_] = ('face', hm.ports[p_][1], f_, 'M5', round(x_, 3), pt_)
            ch = json.loads((ROOT / HEAD_FT_PLAN).read_text())['children']
            ch = dict(ch, ftg=[*V143_FT['ftg'], *HGS], fts=[*V143_FT['fts'], *HSS])
            cmap = dict(HEAD_CLK_CHILD, ck_ft_t='ftg', ck_ft_s='fts')
            want = sorted((ch[cmap[p_]][1] + ch[cmap[p_]][3] / 2, p_) for p_ in HEAD_CLK + ['ck_ft_t', 'ck_ft_s'] if p_ in hm.ports)
            ys_, last = {}, 2.0 - 1.2
            for y_, p_ in want:
                last = max(y_, last + 1.2)
                ys_[p_] = last
            top = SPLIT_HEAD_FT[1] - 12.0
            if ys_ and max(ys_.values()) > top:
                for p_ in sorted(ys_, key=ys_.get, reverse=True):
                    ys_[p_] = min(ys_[p_], top)
                    top = ys_[p_] - 1.2
            for p_, y_ in ys_.items():
                hm.ports[p_] = ('face', 1, 'W', 'M4', round(y_, 3), 1)
            if 'rst_n' in hm.ports:
                hm.ports['rst_n'] = ('face', 1, 'W', 'M4', 456.0, 1)
    # v1.4.3 closed stage views: the die abstract takes the real LEF pin centres (gather: ti 13.5 + 0.192 i S -> N on
    # M5, e at 312.8..315.7, clock W M4 y 10.8; sstage: s_a W / s_b E on M4, clock S M5 x 9)
    if 'qkd_hgs' in M:
        hm = M['qkd_hgs']
        for p_, f_, x_, pt_ in (('ti_a', 'S', 13.5 + 0.096 * 1558, 4), ('ti_b', 'N', 13.5 + 0.096 * 1558, 4),
                                ('e_a', 'S', 314.27, 4), ('e_b', 'N', 314.27, 4)):
            if p_ in hm.ports:
                hm.ports[p_] = ('face', hm.ports[p_][1], f_, 'M5', round(x_, 3), pt_)
        if 'ck' in hm.ports:
            hm.ports['ck'] = ('face', 1, 'W', 'M4', 10.81, 1)
    if 'qkd_hss' in M:
        hm = M['qkd_hss']
        for p_, f_, y_ in (('s_a', 'W', 10.0), ('s_b', 'E', 11.535)):
            if p_ in hm.ports:
                hm.ports[p_] = ('face', hm.ports[p_][1], f_, 'M4', y_, 2)
        if 'ck' in hm.ports:
            hm.ports['ck'] = ('face', 1, 'S', 'M5', 8.99, 1)
    # v1.2: the strip compositions' leaf clock entries = area pins at each leaf (land: PC leaf k beside its CDC on the E
    # half, group i at the middle of its four PCs on the W half, the embedding engine at the N end; astk: astk_plan)
    for mn in ('qkd_land', 'qkd_land_n'):
        if mn in M:
            hm = M[mn]
            pos = {**{f'ck_p{k}': (hm.w * 0.75, STRIP_PC_PITCH * k + 190.08 + 86.4) for k in range(32)},
                   **{f'ck_g{i}': (hm.w * 0.25, STRIP_PC_PITCH * (4 * i + 2)) for i in range(8)},
                   'ck_e': (hm.w / 2, hm.h - 40.0), 'ck_r': (hm.w / 2, STRIP_PC_PITCH * 16 + 120.0)}
            for p_, (x_, y_) in pos.items():
                if p_ in hm.ports:
                    hm.ports[p_] = ('area', 1, round(x_, 3), round(y_, 3), 1)
    for mn in ('qkd_ctrl', 'qkd_ctrl_n'):
        if mn in M:
            hm = M[mn]
            pos = {**{f'ck_p{k}': (hm.w / 2 - 20.0, STRIP_PC_PITCH * k + 190.08 + 86.4) for k in range(32)},
                   **{f'hk_p{k}': (hm.w / 2 + 20.0, STRIP_PC_PITCH * k + 190.08 + 86.4) for k in range(32)},
                   'ck_k': (hm.w / 2 - 10.0, 12096.0 + 21.6), 'hk_k': (hm.w / 2 + 10.0, 12096.0 + 21.6)}
            for p_, (x_, y_) in pos.items():
                if p_ in hm.ports:
                    hm.ports[p_] = ('area', 1, round(x_, 3), round(min(y_, hm.h - 2.0), 3), 1)
    for mn in ('qkd_astk', 'qkd_astk_n'):
        if mn in M:
            hm = M[mn]
            pos = {}
            for name, mst_, col, y_, _ in astk_plan():
                h_ = ASTK_LEAF[mst_][1]
                x_ = hm.w * (0.25 if col == 0 else 0.75)
                if mst_ == 'qkd_astk_pv':
                    r_, hp_, c_ = int(name[4]), int(name[6]), 'xy'.index(name[8])
                    key = f'ck_v{16 * r_ + 8 * c_ + 2 * hp_ + (name[2] == "b")}'
                elif mst_ == 'qkd_astk_ex':
                    e_, j_ = map(int, name[3:].split('_'))
                    key = f'ck_x{4 * e_ + j_}'
                elif mst_ == 'qkd_astk_ep':
                    key = f'ck_e{int(name[3:])}'
                elif mst_ == 'qkd_astk_zn':
                    key = f'ck_z{int(name[3:])}'
                else:
                    key = 'ck_c'
                pos[key] = (x_, min(hm.h - 2.0, y_ + h_ / 2))
            pos['ck_r'] = (hm.w / 2, hm.h / 2 + 3.2)
            pos['ck_d'] = (hm.w / 2, hm.h / 2 - 3.2)     # KV-WIRE2 ASTK: the e-read tap (strip middle)
            for p_, (x_, y_) in pos.items():
                if p_ in hm.ports:
                    hm.ports[p_] = ('area', 1, round(x_, 3), round(y_, 3), 1)
    # v1.2: the hub composition's 14 clock entries = area pins in one row across the slot (one CTS sink each; the
    # elements' child sub-slot plan moves each to its child's clock pin)
    if 'qkd_ahub' in M:
        hm = M['qkd_ahub']
        for j_, p_ in enumerate(AHUB_CLK):
            if p_ in hm.ports:
                hm.ports[p_] = ('area', 1, round(hm.w * (j_ + 1) / (len(AHUB_CLK) + 1), 3), hm.h / 2, 1)
    if AHUB_SDW and 'qkd_ahub' in M and __import__('os').environ.get('OT_KV_AHUB_SDW_PINS', '1') == '1':
        # OT_KV_AHUB_SDW: die port -> the kit pins it binds (kv_static_die qkd_ahub binding); each die word on the kit's
        # face at the centre of the kit pins' range union
        hm, sp_ = M['qkd_ahub'], json.loads((ROOT / AHUB_SDW_SPEC).read_text())
        face_ = {k_: f_ for f_, ks_ in sp_['pins'].items() for k_ in ks_}
        rg_ = sp_['pin_ranges']
        die_ = dict(hs=['hs_start', 'hs_ep', 'hs_layer', 'hs_ctx', 'hs_cal_lo', 'hs_cal_r'], fr=['fr_valid', 'fr_epoch', 'fr_rz'],
                    hf=['hf'], ck_c=['ck'], rst_n=['rst_n'],
                    **{f'ap_{st}': [f'ap{k_}'] for k_, st in enumerate(KSD.STACKS)},
                    **{f'am_{st}': [f'am{k_}'] for k_, st in enumerate(KSD.STACKS)})
        for dp_, ks_ in die_.items():
            if dp_ not in hm.ports:
                continue
            fs_ = {face_[k_] for k_ in ks_}
            if len(fs_) != 1:
                raise ValueError(f'OT_KV_AHUB_SDW: die port {dp_} spans kit faces {fs_}')
            f_ = fs_.pop()
            lo_, hi_ = min(rg_[k_][0] for k_ in ks_), max(rg_[k_][1] for k_ in ks_)
            if dp_ == 'hs':                      # hs_cal_lo / hs_cal_r sit apart (410-475): the word's main range
                lo_, hi_ = rg_['hs_start']
            hm.ports[dp_] = ('face', hm.ports[dp_][1], f_, 'M5' if f_ in 'NS' else 'M4', round((lo_ + hi_) / 2, 3),
                             1 if dp_ in ('ck_c', 'rst_n') else 2)
    # v1.4.4: the PV pair's 33 clock entries sit on their children (ck_c<s>: column s's join centre, ck_c32: the control
    # tile), rst_n on the control tile (canonical R0 frame, strip at the top; the die places pvw_1 MX)
    if 'qkd_pvw_n' in M and PV_T and os.environ.get('OT_KV_PVWN_MX_PINS', '1') == '1':
        F.MX_AREA.add('qkd_pvw_n')      # KV-CLOCK 10-18: pvw_1 is placed MX (its ck_c* M8 area pins on the mirrored grid)
    for mn in ('qkd_pvw_s', 'qkd_pvw_n'):
        if mn in M and PV_T:
            # KVPLAN 1815: the trunked pair's face pins from its plan (canonical R0: strip / control tile at the top)
            hm, P_ = M[mn], pvt_plan()
            cells, fw_, fh_ = P_['cells'], P_['frame_um'][0], P_['frame_um'][1]
            ctx_ = P_['face_pins']['strip']['x']
            for s_ in range(33):
                c_ = cells['u_ctl' if s_ == 32 else f'u_s{s_}_j']
                if f'ck_c{s_}' in hm.ports:
                    hm.ports[f'ck_c{s_}'] = ('area', 1, round(c_[1] + c_[3] / 2, 3), round(c_[2] + c_[4] / 2, 3), 1)
            top = dict(rst_n=-150.0, st=-120.0, ie=60.0, iee=90.0)     # iee: KV-WIRE2 ASTK E-stack e lanes
            for p_, dx_ in top.items():
                if p_ in hm.ports:
                    hm.ports[p_] = ('face', hm.ports[p_][1], 'N', 'M5', round(ctx_ + dx_, 3), 1)
            if 'pr' in hm.ports and 'result_trunk' in P_:      # KV-RTRUNK: over the trunks' header in the strip
                hm.ports['pr'] = ('face', hm.ports['pr'][1], 'N', 'M5', P_['result_trunk']['face_pin']['x'], 1)
            for k_ in range(8):          # header / request: strip N face over the control tile (PVT_HDR_CTL) / side face
                hx_ = pvt_hdr_pin(k_)[0]
                yh_ = fh_ - PVT_HDR_Y0 - PVT_PIN_DY * (k_ % 4)
                for p_, x_, y_ in ((f'vh{k_}', hx_, yh_), (f'vrq{k_}', hx_ + 8.64, yh_ - 30.0)):
                    if p_ in hm.ports:
                        hm.ports[p_] = (('face', hm.ports[p_][1], 'N', 'M5', round(x_, 3), 1) if PVT_HDR_CTL else
                                        ('face', hm.ports[p_][1], 'W' if k_ < 4 else 'E', 'M4', round(y_, 3), 1))
            for k_ in range(8):
                for g_ in range(8):
                    p_ = f'vc{k_}_{g_}'
                    if p_ in hm.ports:
                        f_, yc_ = P_['face_pins']['vc'][p_]
                        hm.ports[p_] = ('face', hm.ports[p_][1], f_, 'M4', round(yc_ + PVT_ORD * (1.5 - (k_ % 4)) * PVT_PIN_DY, 3), 1)
            continue
        if mn in M:
            hm, pl = M[mn], pv_plan()
            for s in range(33):
                x_, y_, w_, h_, _ = pl['u_ctl' if s == 32 else f'g_col[{s}].u_col.u_join']
                if f'ck_c{s}' in hm.ports:
                    hm.ports[f'ck_c{s}'] = ('area', 1, round(x_ + w_ / 2, 3), round(y_ + h_ / 2, 3), 1)
            if 'rst_n' in hm.ports:
                x_, y_, w_, h_, _ = pl['u_ctl']
                hm.ports['rst_n'] = ('area', 1, round(x_ + w_ / 2 + 6.4, 3), round(y_ + h_ / 2, 3), 1)
            # V port words: stack PAIR ports 0-3 on the W face, stack PAIR + 2 ports 4-7 on the E face, level with the MIDDLE
            # of the column array (measured 10-16: worst port 30 relay edges vs 53 with the pins at the control-strip end; the
            # side-channel chains reach the middle from the S band and from the corridor alike).  The pair's array-wide
            # 128-b chunk / cmd distribution from there is the element owner's.
            vh_ = (m or {}).get('geo', {}).get('pv144', {}).get('vport_homes', {}) if PV_PINY else {}
            pi_ = {i.name: i for i in m['insts']} if PV_PINY and m is not None else {}
            for k_ in range(8):
                f_, yc_ = ('W' if k_ < 4 else 'E'), PV_ARR[1] / 2 + ((k_ % 4) - 1.5) * 130.0
                if vh_:
                    # kvs13e: level with V port k of this pair (W ports k of stack PAIR, E ports of stack PAIR + 2); the
                    # canonical frame is R0 (pvw_0) / MX (pvw_1: die y flips)
                    pw_ = pi_['pvw_0' if mn == 'qkd_pvw_s' else 'pvw_1']
                    hv_ = next(h for h in vh_.values() if h['pair'] == (0 if mn == 'qkd_pvw_s' else 1) and h['pair_port'] == k_)
                    dy_ = hv_['xy'][1] + PV_VPORT[1] / 2 - pw_.y
                    dy_ = dy_ if pw_.orient == 'R0' else pw_.h - dy_
                    yc_ = min(max(dy_, 200.0), pw_.h - 300.0)
                if f'vin{k_}' in hm.ports:
                    hm.ports[f'vin{k_}'] = ('face', hm.ports[f'vin{k_}'][1], f_, 'M4', round(yc_, 3), 1)
                if f'vrq{k_}' in hm.ports:
                    hm.ports[f'vrq{k_}'] = ('face', hm.ports[f'vrq{k_}'][1], f_, 'M4', round(yc_ + 40.0, 3), 1)
    # v1.4.4 V ports (Q-VMWB r5 pin faces, canonical R0): W = in0 + vq0, E = in1 + vq1, N = vo (out_valid / out_t / out_v)
    # + pr + ck, S = rst_n + fault
    if 'qkd_pv16_vport' in M:
        vm_ = M['qkd_pv16_vport']
        for p_, f_, c_ in (('i0', 'W', 86.4), ('vq0', 'W', 160.0), ('i1', 'E', 86.4), ('vq1', 'E', 160.0), ('vo', 'N', 43.2),
                           ('pr', 'N', 72.0), ('rst_n', 'S', 20.0), ('f', 'S', 60.0)):
            if p_ in vm_.ports:
                vm_.ports[p_] = ('face', vm_.ports[p_][1], f_, 'M4' if f_ in 'WE' else 'M5', c_, 1)
        if 'ck' in vm_.ports:
            vm_.ports['ck'] = ('area', 1, vm_.w / 2 - 6.4, vm_.h / 2, 1)
    # the link bridge abuts the KV end: its rf / tf faces take the KV end's bit positions (v1 drew them ~220 um apart:
    # the 1.47 fine window of the d2d | lnk face); lx / lr leave its S face over the sequencer's lx / lr pins
    if m is not None and 'qkd_lnk' in M and 'qkd_d2d' in M:
        by = {i.name: i for i in m['insts']}
        ln, dd = M['qkd_lnk'], M['qkd_d2d']
        il, idd = by.get('lnk'), by.get('d2d_kv')
        for p_ in ('rf', 'tf'):
            if p_ in ln.ports and p_ in dd.ports and il is not None and idd is not None:
                sp = dd.ports[p_]
                ln.ports[p_] = ('face', ln.ports[p_][1], 'N', sp[3], sp[4] + idd.x - il.x, sp[5])
        sq = M.get('qkd_seq')
        isq = by.get('seq')
        if sq is not None and isq is not None and il is not None:
            # v1.2: the sequencer's link words leave its N face straight under the bridge (lr at x 250, lx at x 380, M5),
            # so the 522-um gap takes exactly one relay each way (K_ST 1 of the measured link cost) whatever the other
            # chains do (with level pins lx drifted to the W face and took 2 stages)
            for p_, x_ in (('lr', 250.0), ('lx', 380.0)):
                if p_ in sq.ports:
                    sq.ports[p_] = ('face', sq.ports[p_][1], 'N', 'M5', x_, 1)
            for p_ in ('lx', 'lr'):
                if p_ in ln.ports and p_ in sq.ports and sq.ports[p_][0] == 'face' and sq.ports[p_][2] == 'N':
                    ln.ports[p_] = ('face', ln.ports[p_][1], 'S', 'M5', sq.ports[p_][4] + isq.x - il.x, sq.ports[p_][5])


def real_pin_bindings(m):
    """Read actual LEF shapes, mapped per RTL bit. Missing views stay explicit.

    The CDC geometry view is historical evidence only; importing its pins does
    not assert that an appropriate die-context timing model exists.
    """
    if not m['geo'].get('kv_wq_leaf_s'):
        return {}, {}
    import re
    import die_top_lint as DTL
    paths = dict(qkd_cdc_wleaf='physical/qwen_die_masters/views/qfd_cdc_eco_h1/qfd_cdc.lef',
                 qkd_kvwq_leaf_s='physical/qwen_die_masters/views/qkd_kvwq_leaf_s/qkd_kvwq_leaf_s.lef',
                 qkd_kvwq_ctl_bin='physical/qwen_die_masters/views/qkd_kvwq_ctl_bin_a/qkd_kvwq_ctl_bin_a.lef')
    if m['geo'].get('kv_wq_head'):
        paths['qkd_kvwq_ctl_bin_h'] = 'physical/qwen_die_masters/views/qkd_kvwq_ctl_bin_h/qkd_kvwq_ctl_bin_h.lef'
        del paths['qkd_kvwq_ctl_bin']
    if m['geo'].get('kv_wq_wide'):
        paths['qkd_kvwq_leaf_s_w129'] = 'physical/qwen_die_masters/views/qkd_kvwq_leaf_s_w129/qkd_kvwq_leaf_s_w129.lef'
        del paths['qkd_kvwq_leaf_s']
    if m['geo'].get('kv_wq_mirror'):
        paths = {('qkd_kvwq_leaf_s_w129_m' if k=='qkd_kvwq_leaf_s_w129' else k):v.replace('qkd_kvwq_leaf_s_w129/','qkd_kvwq_leaf_s_w129_m/').replace('qkd_kvwq_leaf_s_w129.lef','qkd_kvwq_leaf_s_w129_m.lef') for k,v in paths.items()}
    if m['geo'].get('split'):
        paths.pop('qkd_kvwq_ctl_bin', None)     # v1.1: the sl3 strip-form view, bound by bind_views (not this old-form import)
        paths['qkd_kvwq_leaf_s_w129_m'] = ('physical/ref_tile/qkd_kvwq_leaf_s_w129_m/views/qkd_kvwq_leaf_s_w129_m/'
                                          'qkd_kvwq_leaf_s_w129_m.lef')
    rows, status = {}, {}
    for mst, rel in paths.items():
        path = ROOT/rel
        if not path.exists():
            status[mst] = dict(path=rel, ready=False, reason='own routed view not yet present')
            continue
        text = path.read_text()
        size = re.search(r'\bSIZE\s+([\d.]+)\s+BY\s+([\d.]+)', text)
        raw = {}
        for pin in re.finditer(r'\bPIN\s+(\S+)(.*?)\bEND\s+\1\s', text, re.S):
            shapes = []
            for layer, a,b,c,d in re.findall(r'LAYER\s+(\w+)\s*;\s*RECT\s+([\d.eE+-]+)\s+([\d.eE+-]+)\s+([\d.eE+-]+)\s+([\d.eE+-]+)\s*;', pin[2]):
                shapes.append((layer, tuple(map(float, (a,b,c,d)))))
            raw[pin[1]] = shapes
        binding = BINDINGS[mst]
        ports = DTL.parse_module(binding['file'], binding['module'], dict(TAGW=9,HD=128,QD=4,FLANE_BINARY=1))['ports']
        def expand(names):
            out = []
            for name in names:
                width = ports[name][1]
                out += [name] if width == 1 else [f'{name}[{i}]' for i in range(width)]
            return out
        groups = {dp:expand(names) for dp,names in binding['ports'].items()}
        if mst in ('qkd_kvwq_ctl_bin','qkd_kvwq_ctl_bin_h'):
            for g in range(4):
                groups[f'f{g}'] = [f'f_v[{g}]'] + [f'f_d[{256*g+i}]' for i in range(256)] + \
                    [f'f_sec[{24*g+i}]' for i in range(24)] + [f'f_lane[{8*g+i}]' for i in range(8)] + \
                    [f'f_tag[{9*g+i}]' for i in range(9)]
                groups[f'r{g}'] = [f'r_v[{g}]', f'r_bad[{g}]']
        mapped = []
        for dp, names in groups.items():
            for i, name in enumerate(names):
                if name not in raw:
                    raise ValueError(f'{mst}: actual LEF missing RTL pin {name}')
                mapped += [(f'{dp}[{i}]', layer, rect, name) for layer, rect in raw[name]]
        status[mst] = dict(path=rel, ready=True, sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                           size_um=list(map(float,size.groups())), named_pins=len(raw), mapped_shapes=len(mapped),
                           timing_gate='not implied by pin import')
        rows[mst] = mapped
    return rows, status


def cdc_write_pin_reach(m, rows):
    """Per-bit physical Manhattan distance, with the actual instance mirrors."""
    if 'qkd_cdc_wleaf' not in rows or not any(k in rows for k in ('qkd_kvwq_leaf_s','qkd_kvwq_leaf_s_w129','qkd_kvwq_leaf_s_w129_m')):
        return dict(ready=False, reason='actual CDC and south-face leaf pins both required')
    by = {i.name:i for i in m['insts']}
    def locations(it, port):
        out = {}
        for pin, layer, rect, rtl in rows[it.master]:
            if not pin.startswith(port+'['):
                continue
            x=(rect[0]+rect[2])/2; y=(rect[1]+rect[3])/2
            if it.orient in ('MY','R180'): x=it.w-x
            if it.orient in ('MX','R180'): y=it.h-y
            out.setdefault(pin,[]).append((it.x+x,it.y+y))
        return out
    distances=[]
    for st in STACKS:
        for pc in range(32):
            leaf=by[f'wleaf_{st}_{pc}']; cdc=by[f'cdc_{st}_{pc}']
            for lp,cp,width in [('w','wi',290),('wr','wr',11)]:
                a=locations(leaf,lp); b=locations(cdc,cp)
                for bit in range(width):
                    near=min(abs(x-u)+abs(y-v) for x,y in a[f'{lp}[{bit}]'] for u,v in b[f'{cp}[{bit}]'])
                    distances.append(dict(stack=st,pc=pc,port=lp,bit=bit,um=round(near,3)))
    worst=max(distances,key=lambda x:x['um'])
    return dict(ready=True, bits=len(distances), worst=worst, max_um=worst['um'],
                over_100um=sum(x['um']>100 for x in distances), over_SS_504um=sum(x['um']>504 for x in distances))


LEVEL_PIN_MASTERS = ('qkd_land', 'qkd_land_n', 'qkd_astk', 'qkd_astk_n', 'qkd_seq', 'qkd_ahub', 'qkd_embgw', 'qkd_host',
                     'qkd_d2d')


STRIP_ES_Y, STRIP_ER_Y, STRIP_KF_Y, STRIP_PC_PITCH = 60.0, 240.0, 21.6, 378.0
PHY_STRIP_DY = 71.28           # the PHY band starts 71.28 um above its controller strip's end (r21c band)


def _strip_face_pins(mst, mm):
    """v1.2: the landing <-> controller strip words of PC k (es<k> / er<k>) leave both strips level with PC k (local y
    378 k + 60 / + 240, clear of the CDC words c<k>i / c<k>o) on the faces that face each other across the CDC column;
    the controller strip's fault kf at y 6,150"""
    if mst not in ('qkd_land', 'qkd_land_n', 'qkd_ctrl', 'qkd_ctrl_n', SPLIT_PHY):
        return
    for p, sp in list(mm.ports.items()):
        mt = re.fullmatch(r'(po|pi)(\d+)', p)
        if sp[0] == 'face' and mt:
            y = STRIP_PC_PITCH * int(mt.group(2)) + (200.0 if mt.group(1) == 'po' else 236.0)
            if mst == SPLIT_PHY:
                mm.ports[p] = ('face', sp[1], 'W', 'M4', y - PHY_STRIP_DY, 1)
            else:
                mm.ports[p] = ('face', sp[1], 'E', 'M4', y, 1)
    if mst == SPLIT_PHY:
        return
    for p, sp in list(mm.ports.items()):
        if sp[0] != 'face':
            continue
        mt = re.fullmatch(r'(es|er)(\d+)', p)
        if mt:
            y = STRIP_PC_PITCH * int(mt.group(2)) + (STRIP_ES_Y if mt.group(1) == 'es' else STRIP_ER_Y)
        elif p == 'kf':
            # v1.3 (die-placed controller leaves): kf leaves the controller strip at its kc leaf = the strip's OUTER end
            # (S stacks: qkd_ctrl_strip_sr, kc leaf at the S end; N stacks: kc leaf at the N end) and enters the landing
            # strip's PC fault chain at pc0 = its S end; a mid-strip pin (v1.2 y 6,150) became a 6-mm unrelayed wire
            if mst == 'qkd_ctrl_n':
                mm.ports[p] = ('face', sp[1], 'N', 'M5', round(mm.w / 2 + 21.6, 4), 1)
                continue
            y = STRIP_KF_Y
        else:
            continue
        if HOP and mt and mst in _HOP_STRIP_DY:
            # OT_KV_HOP: the controller strip's es / er words sit where its closed pc leaf's pins are (2 tracks, the
            # leaf's bit order), as the HOST slices' controller faces (_slice_pins) -- same measured kvs11 offsets
            mm.ports[p] = ('face', sp[1], 'W', 'M4', round(y + _HOP_STRIP_DY[mst][mt.group(1)], 3), 2)
            if mst == 'qkd_ctrl':
                F.PIN_REVERSE.add((mst, p))
            continue
        mm.ports[p] = ('face', sp[1], 'E' if mst.startswith('qkd_land') else 'W', 'M4', y, 1)


def _reach_fix_slide(name, mm):
    """KVPLAN3 0230 (OT_KV_REACH_FIX; kvs13l3 real case DRT-0073 'no access point for land_*/c0i[0]'): a c<k>i word moved
    level with the closed CDC's co pins landed ON the er<k> word of the same face (c0i[0] = er0[35], M4 y 235.44).  After
    every face word of the landing master is drawn (_strip_face_pins / level pins), each c<k>i slides along its face to
    the nearest span clear of every other word on that face (1-um gap)."""
    def span_(q):
        hw_ = (q[1] - 1) / 2 * 0.048 * q[5]
        return q[4] - hw_, q[4] + hw_
    for p in list(mm.ports):
        mt = re.fullmatch(r'c(\d+)i', p)
        if not mt or mm.ports[p][0] != 'face':
            continue
        sp = list(mm.ports[p])
        others = [span_(q) for p2, q in mm.ports.items() if p2 != p and q[0] == 'face' and q[2] == sp[2]]
        lim = mm.w if sp[2] in 'NS' else mm.h
        for d_ in sorted((i * 0.48 for i in range(-4000, 4001)), key=abs):
            q_ = list(sp)
            q_[4] = round(sp[4] + d_, 4)
            a_, b_ = span_(q_)
            if a_ >= 1.0 and b_ <= lim - 1.0 and all(b_ + 1.0 <= o0 or a_ - 1.0 >= o1 for o0, o1 in others):
                sp = q_
                break
        else:
            raise ValueError(f'{name}.{p}: no clear span on face {sp[2]}')
        if abs(sp[4] - mm.ports[p][4]) > 0.01:
            print(f'kv die REACH_FIX: {name}.{p} slid {sp[4] - mm.ports[p][4]:+.2f} um clear of the other {sp[2]}-face words',
                  file=sys.stderr)
        mm.ports[p] = tuple(sp)


_HOP_STRIP_DY = dict(qkd_ctrl=dict(er=-50.9, es=159.4), qkd_ctrl_n=dict(er=-28.9, es=120.5))


def _slice_pins(m, mm, down=False):
    """HOST slice v1.4.2: preserve every port, spread buses below 0.60 face cut.

    Clock roots stay separate physical entries, all on the actual per-stack
    core833.334 trunk.  No area pins above the M5 leaf cap.  The N view reverses
    only the two chain faces; control/landing faces keep the same coordinates.
    """
    w = {p: sp[1] for p, sp in mm.ports.items()}
    mm.ports.clear()
    mm.order.clear()
    # OT_KV_HOP (kvs11 TT: ctrl_pc er -> slice ctrl_er -97.0 ps, 869 violators; slice ctrl_es -> ctrl_pc es -38.1): the
    # slice's controller-face words were at 6 M4 tracks a bit while the closed pc leaf's er / es are at 2, and the S
    # strips' pc leaves are MX (bit order descending): realized dy grew to 101 (er) / 215 um (es) on a 423.5-um dx hop.
    # Under the flag they take the leaf's 2-track pitch and order, centred on the leaf's words (measured kvs11 offsets of
    # the middle bit, identical for all 32 PCs of a stack): every bit's dy <= ~14 um
    hop_ = dict(qkd_hslice={'ctrl_' + k: v for k, v in _HOP_STRIP_DY['qkd_ctrl'].items()},
                qkd_hslice_dn={'ctrl_' + k: v for k, v in _HOP_STRIP_DY['qkd_ctrl_n'].items()}) if HOP else {}
    for p, face, centre in (('ctrl_es', 'W', STRIP_ES_Y - 12.96), ('ctrl_er', 'W', STRIP_ER_Y - 12.96),
                            ('land_es', 'E', STRIP_ES_Y - 12.96), ('land_er', 'E', STRIP_ER_Y - 12.96)):
        if p in w and KSD.BOOT and p.startswith('land_'):
            # KV-WIRE2 BOOT (note s5.6): the landing words come from the slice's own PC (kvpc, W of the slice) on the
            # controller face, clear of the ctrl words (HOP centres 163..221 um): les at 80, hler at 290 um, 2 tracks a bit
            mm.face(p, w[p], 'W', 'M4', 80.0 if p == 'land_es' else 290.0, 2)
            continue
        if p in w:
            if p in hop_.get(mm.name, {}):
                mm.face(p, w[p], face, 'M4', round(centre + hop_[mm.name][p], 3), 2)
                if not down:
                    F.PIN_REVERSE.add((mm.name, p))
                continue
            mm.face(p, w[p], face, 'M4', round(centre, 3), 6)
    south = ['fi', 'co', 'ao', 'fault_o', 'sko', 'sdo', 'soo', 'sfo', 'bgi']
    north = ['fo', 'ci', 'ai', 'fault_i', 'ski', 'sdi', 'soi', 'sfi', 'bgo']
    for face, lst in ((('N', south), ('S', north)) if down else (('S', south), ('N', north))):
        lst = [p for p in lst if p in w]
        # Four M5 tracks per bit = 0.50 local two-track demand, old two-track
        # packed bands were 1.00.  Keep a two-micron channel between buses.
        span = [w[p] * F.TRK['M5'][1] * 4 for p in lst]
        pos = (mm.w - sum(span) - 2.0 * (len(lst) - 1)) / 2
        if pos < 4.0:
            raise ValueError(f'{mm.name}: slice chain face needs a larger slot')
        for p, size in zip(lst, span):
            mm.face(p, w[p], face, 'M5', round(pos + size / 2, 3), 4)
            pos += size + 2.0
    centres = dict(ck=('W', -5),
                   host_rst_n=('W', -15), hbm_rst_n=('W', 15),
                   ctrl_completion_v=('E', -15), ctrl_completion_we=('E', 15),
                   lpc=('W', 0))
    rest = sorted(p for p in w if p not in mm.ports)
    unknown = set(rest) - centres.keys()
    if unknown:
        raise ValueError(f'{mm.name}: no face grant for slice ports {sorted(unknown)}')
    # KVDIE 2026-10-16 (kvs13c real case DRT-0073: under OT_KV_HOP the dn slice's ctrl_es band moved onto host_rst_n,
    # ctrl_es[41] and host_rst_n[0] on one M4 track): a single-bit face pin steps clear of every bus band on its face
    busy = []
    for q_, (kind_, *r_) in mm.ports.items():
        if kind_ == 'face' and len(r_) >= 5 and r_[2] == 'M4':
            wid_, f_, _, c_, t_ = r_[0], r_[1], r_[2], r_[3], r_[4]
            half_ = wid_ * F.TRK['M4'][1] * t_ / 2
            busy.append((f_, c_ - half_ - 1.0, c_ + half_ + 1.0))
    for p in rest:
        face, offset = centres[p]
        y_ = mm.h / 2 + offset
        if HOP:
            step_ = 4 * F.TRK['M4'][1]
            for _ in range(2000):
                hit_ = [b_ for b_ in busy if b_[0] == face and b_[1] <= y_ <= b_[2]]
                if not hit_:
                    break
                y_ = hit_[0][2] + step_ if offset >= 0 else hit_[0][1] - step_
        mm.face(p, w[p], face, 'M4', round(y_, 3), 4)
        if HOP:
            busy.append((face, y_ - 1.0, y_ + 1.0))


def _covered_faces(m, it, gap=4.32, peer=None):
    """OT_KV_HOP: faces of instance it (in its own frame) that another block abuts over more than half their length."""
    out = set()
    for o in m['insts']:
        if o is it or o is peer or o.kind == 'relay':
            continue
        ox = min(it.x + it.w, o.x + o.w) - max(it.x, o.x)
        oy = min(it.y + it.h, o.y + o.h) - max(it.y, o.y)
        if ox > it.w / 2 and 0 <= o.y - (it.y + it.h) <= gap:
            out.add('N')
        if ox > it.w / 2 and 0 <= it.y - (o.y + o.h) <= gap:
            out.add('S')
        if oy > it.h / 2 and 0 <= o.x - (it.x + it.w) <= gap:
            out.add('E')
        if oy > it.h / 2 and 0 <= it.x - (o.x + o.w) <= gap:
            out.add('W')
    if it.orient in ('MY', 'R180'):
        out = {dict(E='W', W='E').get(f, f) for f in out}
    if it.orient in ('MX', 'R180'):
        out = {dict(N='S', S='N').get(f, f) for f in out}
    return out


def _land_level_pins(m, mm, inst0, face_load, by):
    """qwen-1010/b 2026-10-10 (KV11 die STA TT -38.6 ns: land_ES/rs4 -> ectl_ES_4/rs, a 'neighbour' hop whose landing pin
    sat ~mm away along the 12-mm landing face).  Every word of a placeholder master (LEVEL_PIN_MASTERS) that is not a
    fixed-position port (CDC column ports, the aggregator's tile-level e / f ports) is drawn LEVEL WITH ITS OWN PEER
    (the tile, or the first relay of its chain) on the face that faces it, then de-overlapped against the fixed ports
    and each other (nearest free slot).  The pin-to-pin hop is then the frame gap the relay planner measured."""
    own = {}
    for bid, cl, bits, eps in m['buses']:
        if len(eps) == 2:
            for (i0, p0), (i1, p1) in ((eps[0], eps[1]), (eps[1], eps[0])):
                if i0 == inst0.name:
                    own[p0.lstrip('*')] = by[i1]
    pitch_um = 0.048
    fixed_rx = re.compile(r'^(c\d+[io]|[ef]\d.*|es\d+|er\d+|kf)$')
    for face in ('E', 'W', 'N', 'S'):
        L = mm.h if face in 'EW' else mm.w
        fl = face_load.get((mm.name, face), [])
        fixed, mov = [], []
        for p, sp in mm.ports.items():
            if sp[0] != 'face' or sp[2] != face:
                continue
            span = sp[1] * pitch_um * sp[5]
            (mov if (p in fl and p in own and not fixed_rx.match(p)) else fixed).append((p, span))
        occ = [(mm.ports[p][4] - sp_ / 2 - 1.0, mm.ports[p][4] + sp_ / 2 + 1.0) for p, sp_ in fixed]
        want = []
        for p, span in mov:
            pe = own[p]
            if face in 'EW':
                c = pe.y + pe.h / 2 - inst0.y
                if inst0.orient in ('MX', 'R180'):
                    c = inst0.h - c
            else:
                c = pe.x + pe.w / 2 - inst0.x
                if inst0.orient in ('MY', 'R180'):
                    c = inst0.w - c
            want.append((min(max(c, span / 2 + 2.0), L - span / 2 - 2.0), p, span))
        for y, p, span in sorted(want):
            for k in range(0, 80000):
                for cand in ((y + 0.5 * k, y - 0.5 * k) if k else (y,)):
                    lo, hi = cand - span / 2 - 1.0, cand + span / 2 + 1.0
                    if lo < 1.0 or hi > L - 1.0:
                        continue
                    if all(hi <= a or lo >= b for a, b in occ):
                        sp = list(mm.ports[p])
                        sp[4] = cand
                        mm.ports[p] = tuple(sp)
                        occ.append((lo, hi))
                        break
                else:
                    continue
                break
            else:
                raise ValueError(f'kv die: no {mm.name} face {face} slot for {p}')


def pin_xy(it, mm, port):
    """qwen-1010/b: absolute centre of a face / area port of instance it (master mm), with the orientation applied."""
    sp = mm.ports[port]
    if sp[0] == 'face':
        f, c = sp[2], sp[4]
        x, y = {'E': (it.w, c), 'W': (0.0, c), 'N': (c, it.h), 'S': (c, 0.0)}[f]
    else:
        x, y = sp[2], sp[3]
    if it.orient in ('MY', 'R180'):
        x = it.w - x
    if it.orient in ('MX', 'R180'):
        y = it.h - y
    return it.x + x, it.y + y


def pin_reach(m, M, reach=500.0, skip=('clock_trunk', 'reset', 'constant')):
    """qwen-1010/b 2026-10-10: the pin-to-pin register hops of every point-to-point die bus (Manhattan between the two
    drawn pins; the frame-to-frame margin lint cannot see a pin on a far face or far along a long face)."""
    by = {i.name: i for i in m['insts']}
    bad, n = [], 0
    for bid, cl, bits, eps in m['buses']:
        if cl in skip or len(eps) != 2 or cl in ABUT:
            continue
        (a, pa), (b, pb) = eps
        ia, ib = by[a], by[b]
        if ia.master not in M or ib.master not in M or pa.lstrip('*') not in M[ia.master].ports or pb.lstrip('*') not in M[ib.master].ports:
            continue
        n += 1
        try:
            xa, ya = _leaf_pin(ia, pa) or pin_xy(ia, M[ia.master], pa.lstrip('*'))
            xb, yb = _leaf_pin(ib, pb) or pin_xy(ib, M[ib.master], pb.lstrip('*'))
        except (TypeError, KeyError):
            continue
        d = abs(xa - xb) + abs(ya - yb)
        if d > reach:
            bad.append(dict(bus=bid, cls=cl, bits=bits, um=round(d, 1), a=f'{a}.{pa}', b=f'{b}.{pb}'))
    bad.sort(key=lambda r: -r['um'])
    return dict(hops=n, reach_um=reach, violations=len(bad), worst=bad[:40], all=bad)


def assigned_pin_reach(m, M, reach=500.0, classes=('stack_local',)):
    """Measure every assigned bit, including unequal face pitches and mirroring.

    Pin centres describe a bus only when both ends have identical pitch/order.
    HOST slice face spreading deliberately changes those spans, so using one
    centre for a wide word would conceal its worst physical bit.
    """
    by = {i.name: i for i in m['insts']}
    pin_cache = {}
    def bit_positions(inst, port):
        it = by[inst]
        if it.master not in pin_cache:
            groups = {}
            for name, layer, rect in F.pin_rects(M[it.master], 1, {}):
                base = name.split('[')[0]
                groups.setdefault(base, []).append(((rect[0]+rect[2])/2, (rect[1]+rect[3])/2))
            pin_cache[it.master] = groups
        positions = pin_cache[it.master][port.lstrip('*')]
        return [(it.x + (it.w-x if it.orient in ('MY','R180') else x),
                 it.y + (it.h-y if it.orient in ('MX','R180') else y)) for x,y in positions]
    bad, missing, n, checked, worst = [], [], 0, 0, 0.0
    for bid, cl, bits, eps in m['buses']:
        if (classes is not None and cl not in classes) or cl in ('clock_trunk', 'reset', 'constant') or len(eps) < 2:
            continue
        for target in eps[1:]:
            try:
                left, right = bit_positions(*eps[0]), bit_positions(*target)
            except (KeyError, TypeError, ValueError) as error:
                missing.append(dict(bus=bid,error=str(error)))
                continue
            if len(left) != bits or len(right) != bits:
                missing.append(dict(bus=bid,bits=bits,launch_bits=len(left),capture_bits=len(right)))
                continue
            n += 1
            distances = [abs(a[0]-b[0])+abs(a[1]-b[1]) for a,b in zip(left,right)]
            checked += len(distances)
            distance = max(distances)
            worst = max(worst,distance)
            if distance > reach:
                bit = distances.index(distance)
                bad.append(dict(bus=bid,cls=cl,bits=bits,bit=bit,um=round(distance,3),
                    a=f'{eps[0][0]}.{eps[0][1]}[{bit}]', b=f'{target[0]}.{target[1]}[{bit}]'))
    bad.sort(key=lambda row:-row['um'])
    return dict(hops=n,bits_checked=checked,reach_um=reach,violations=len(bad),max_um=round(worst,3),
                worst=bad[:40],unmeasured=len(missing),missing=missing[:20],method='exact generated face rectangles per bit after orientation')


def stack_local_reach(m, M, reach=500.0):
    return assigned_pin_reach(m, M, reach, classes=('stack_local',))


_BASE_PORT_WIDTHS = F.port_widths


def port_widths(m, k=1):
    widths = _BASE_PORT_WIDTHS(m, k)
    if m['geo'].get('kv_wq_binary') and not m['geo'].get('split'):
        if k != 1:
            raise ValueError('binary ctl requires full-width pin mapping')
        for g in range(4):
            widths[('qkd_kvwq_ctl_bin_h' if m['geo'].get('kv_wq_head') else 'qkd_kvwq_ctl_bin', f'f{g}')] = 298
    return widths


def static_instance_params(m):
    """KVR-DERIVE 10-19: per-instance parameters the die binds (strict bind sidecar die.v.params.json): exactly the closed
    tiles' ages (kv_static_die.tile_ages) -- ECTL kiss RESPONSE_LAT / QK_ISSUE_AGE, V port RT / DQ; the plan's derived
    ages are checked against them (kv_static_params), never bound in their place"""
    t = KSD.tile_ages()
    out = {i.name: dict(RESPONSE_LAT=t['ECTL_RESPONSE_LAT'], QK_ISSUE_AGE=t['ECTL_QK_ISSUE_AGE'])
           for i in m['insts'] if i.master == 'qkd_ectlk'}
    out.update({i.name: (dict(RT=KSD.KB.BOUNDS['VPORT_RT'], DQ=KSD.KB.BOUNDS['VPORT_DQ']) if KSD.KB.ON else
                         dict(RT=t['VPORT_RT'], DQ=t['VPORT_DQ'])) for i in m['insts'] if i.master == 'qkd_pv16_vport'})
    m['static_bindings'] = dict(ectl={k_: v for k_, v in out.items() if k_.startswith('ectl_')},
                                vport={k_: v for k_, v in out.items() if k_.startswith('vport_')},
                                pv_ctl_age=KSD.KB.BOUNDS['PV_FIRST_INPUT_AGE'] if KSD.KB.ON else t['PV_FIRST_INPUT_AGE'])
    return out


def write_netlist(m, k, path, top='qkd_die'):
    F.write_netlist(m, k, path, top=top)
    if m['geo'].get('static_die'):
        # KVJ-G2: per-instance parameters (ECTL kiss RESPONSE_LAT from this plan's K request / response relays) as a
        # sidecar the strict bind reads (kv_bound_netlist); die.v stays a parameter-free structural netlist
        Path(str(path) + '.params.json').write_text(json.dumps(static_instance_params(m), indent=1) + '\n')
    if m.get('extra_conns'):
        # v1.4: a port tapping one bit of an existing bundle (the SerDes tx_up of the host FDI word into the D2D end)
        p_ = Path(path)
        tx = p_.read_text()
        for inst_, cs in m['extra_conns'].items():
            mt = re.search(rf'^(  \S+ {inst_} \()(.*)(\);)$', tx, re.M)
            if not mt:
                raise ValueError(f'extra connection: no instance {inst_}')
            tx = tx[:mt.end(2)] + ', ' + ', '.join(cs) + tx[mt.end(2):]
        p_.write_text(tx)
    if m.get('host_ties'):
        # v1.4: per-slice logical-PC straps and the stack chain terminators (the source parent's constants), as tie cells
        p_ = Path(path)
        tx = p_.read_text()
        tx = tx.replace('endmodule', '\n'.join(f"  assign n_{b} = {w}'d{v};" for b, (w, v) in m['host_ties'].items()) +
                        '\nendmodule', 1)
        p_.write_text(tx)
    if not m['geo'].get('kv_wq_leaves'):
        return
    if k != 1:
        raise ValueError('per-PC leaves require full-width nets (k=1)')
    # These constants are die-top straps, not muxes or a second CDC writer.
    p = Path(path)
    txt = p.read_text()
    if m['geo'].get('kv_wq_binary'):
        unused = []
        for st in STACKS:
            for g in range(4):
                net = f'n_wencoded_{st}_{g}'
                u = f'ctl_lane_high5_unused_{st}_{g}'
                unused.append(f'  wire [4:0] {u};')
                before = f'.f{g}({net})'
                after = f'.f{g}({{{net}[292:284], {u}, {net}[283:0]}})'
                if before not in txt:
                    raise ValueError(f'binary ctl group port missing: {st}/{g}')
                txt = txt.replace(before, after, 1)
        txt = txt.replace(f'module {top} ();', f'module {top} ();\n' + '\n'.join(unused), 1)
    ties = [f"  assign n_{bid} = 3'd{lane};" for bid, lane in m['wq_straps'].items()]
    ties += [f"  assign n_wtail_{st}_{g} = 2'b00;" for st in STACKS for g in range(4)]
    txt = txt.replace('endmodule', '\n'.join(ties) + '\nendmodule', 1)
    p.write_text(txt)
    # Explicit nine OR2-equivalent gates a group; no silent 8-bit/3-bit rename.
    # This module is functional composition RTL only.  The die physical abstract
    # remains UNQUALIFIED until this encoder closes at SS/FF in context.
    if m['geo'].get('kv_wq_binary'):
        return
    p.with_name('kv_wq_lane_encoder.sv').write_text("""module qkd_kvwq_lane_encoder(input wire [297:0] a, output wire [292:0] b);
  wire [7:0] oh = a[288:281];
  wire [2:0] lane = {oh[4]|oh[5]|oh[6]|oh[7], oh[2]|oh[3]|oh[6]|oh[7], oh[1]|oh[3]|oh[5]|oh[7]};
  assign b = {a[297:289], lane, a[280:0]};
endmodule
""")


def record(m):
    by_m = {}
    for i in m['insts']:
        r = by_m.setdefault(i.master, dict(n=0, mm2=0.0))
        r['n'] += 1
        r['mm2'] += i.w * i.h / 1e6
    inst_mm2 = sum(r['mm2'] for r in by_m.values())
    die = m['die']
    st = m['relay_stages']
    return dict(schema='opentallas.qwen-kv-die.plan.v1', generator='tools/qwen_kv_die/kv_die.py',
                generator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                template=dict(path=str(TPL_PATH.relative_to(ROOT)), sha256=hashlib.sha256(TPL_PATH.read_bytes()).hexdigest()),
                die_um=[die['w'], die['h']], die_mm2=die['mm2'], instances=len(m['insts']), buses=len(m['buses']),
                instance_mm2=round(inst_mm2, 3), fill=round(inst_mm2 / die['mm2'], 4),
                elastic_boundary=kv_elastic_boundary.inventory(ROOT, m, BINDINGS),
                reset_region_calendar=m.get('reset_region_calendar'), reset_regions=m.get('reset_regions'),
                tree_depth_max=m.get('tree_depth_max'),
                static_memory_reservation=dict(enabled=m['geo'].get('static_memory_reservation',False),
                    land_width_um=LAND_W, status='PLAN_ONLY_ACTUAL_ADAPTER_BINDING_REQUIRED' if m['geo'].get('static_memory_reservation') else 'LEGACY_LANDING_PROFILE'),
                native_astk_reservation=dict(enabled=ASTK_W>324, parent_width_um=ASTK_W,
                    status='PLAN_ONLY_SELECTED_PROFILE_BINDING_REQUIRED' if ASTK_W>324 else 'LEGACY_FRAME'),
                masters={k_: dict(n=v_['n'], mm2=round(v_['mm2'], 4)) for k_, v_ in sorted(by_m.items())},
                ucie=dict(macro=UCIE[0], mm2=round(UCIE[1] * UCIE[2] / 1e6, 4), edge_um=UCIE[1], edge='N (abuts the '
                          'ROM die S edge under spine column M)'),
                relay_stages={k_: v_ for k_, v_ in sorted(st.items()) if v_},
                critical_stages=dict(
                    d2d_to_seq=st.get('d2d_dn', 0), seq_to_astk={s: st.get(f'aq_{s}', 0) for s in STACKS},
                    astk_to_hub={s: st.get(f'ap_{s}', 0) for s in STACKS}, hub_to_astk={s: st.get(f'am_{s}', 0) for s in STACKS},
                    hub_to_seq=st.get('ares', 0), seq_to_d2d=st.get('d2d_up', 0),
                    seq_to_land={s: st.get(f'kvn_{s}', 0) for s in STACKS},
                    gw_to_land={s: st.get(f'emf_{s}', 0) for s in STACKS}, land_to_gw={s: st.get(f'emr_{s}', 0) for s in STACKS},
                    seq_to_gw=st.get('gq', 0), gw_to_seq=st.get('gr', 0)),
                assumed=dict(row_engine_frame=f're-cut H: 4 x qkd_rhead {HEAD[0]} x {HEAD[1]} + qkd_ectl {ECTL[0]} x {ECTL[1]} '
                                              f'(measured cells: head 152,960 um2 placed, control 24,507 um2 synthesized; '
                                              f'routes qkd_rhead_c / qkd_ectl_c)',
                             astk_w=ASTK_W, land_w=LAND_W, frames=FRAMES,
                             note='frames without a routed element are sized from synthesis or stated as ASSUMED'),
                **({'pv144': dict(m['geo']['pv144'], tree=pv_tree(m), vport_timing=pv_vport_timing(m))}
                   if m['geo'].get('pv144') else {}),
                **({'pv_trunk': pv_trunk_record(m)} if PV_T else {}))


def pv_trunk_record(m):
    """KVPLAN 1815: the trunked pair's cost record (area, flops, latency) + the planned chunk / header stages"""
    P_ = pvt_plan()
    st = m.get('relay_stages', {})
    hdr = {b_: v_ for b_, v_ in st.items() if b_.startswith('pvh_')}
    chk = {b_: v_ for b_, v_ in st.items() if b_.startswith(('pvc_', 'pvta_', 'pvtb_'))}
    # KVPLAN2 2215: chunk g's die edges after the fork = its trunk's segments to its tap (+ one edge a tap) + its face hop
    tot = {}
    for b_ in hdr:
        sk_ = b_[4:]
        for tr_, top_ in (('b', 7), ('a', 3)):
            if f'pvt{tr_}_{sk_}_{top_}' not in st:
                continue
            run_ = 0
            for g_ in (top_, top_ - 1, top_ - 2):
                run_ += st[f'pvt{tr_}_{sk_}_{g_}'] + 1
                tot[f'{sk_}_{g_}'] = run_ + st.get(f'pvc_{sk_}_{g_}', 0)
            tot[f'{sk_}_{top_ - 3}'] = run_ + st.get(f'pvc_{sk_}_{top_ - 3}', 0)
    return dict(plan=PV_T_PLAN, frame_um=P_['frame_um'], old_frame_um=[PV_ARR[0], round(PV_ARR[1] + PV_GAP + PV_STRIP, 6)],
                station_flops_per_pair=P_['station_flops'], replica_area_mm2_per_pair=P_['replica_area_mm2'],
                trunk_d=P_['trunk_d'], flag_d=P_['flag_d'], age_spread_edges=P_['age_spread_edges'],
                chunk_delta_vs_header=P_['chunk_delta_vs_header'], header_stages=hdr, chunk_stages=chk, chunk_total_edges=tot,
                chunk_form='two 512-b trunks (chunks 4..7 / 0..3) + qkd_pvtap<n> taps (KVPLAN2 2215)',
                latency_cost=dict(added_edges_per_pv_pass=P_['trunk_d'], ledger='results/arch/accepted_cost_ledger_1013.json '
                                  'qwen_rom PV16.TRUNK (+1,836 cycles / token, 0.731 %)'),
                open_hops=[h for h in P_['worst_hops'] if h['um'] > 400][:4],
                decision='Q-KV 10-16 ~21:30: option (a) accepted, die ~345 mm2 (+68 mm2) for closure')


def pvt_verify(m):
    """KVPLAN3 0230: the FINAL plan's PV schedule (after pin repair, which adds registered stages and updates
    relay_stages): every chunk g lands exactly pvh + DELTA_g die edges after its fork, and every V port's request + V
    word sum WP + O equals PV_W.  A violation is a schedule error, never a diagnostic."""
    if not PV_T:
        return dict(on=False)
    D_ = {int(k_): v_ for k_, v_ in pvt_plan()['chunk_delta_vs_header'].items()}
    st = m.get('relay_stages', {})
    rec = pv_trunk_record(m)
    bad = []
    for k_, v_ in rec['chunk_total_edges'].items():
        sk_, g_ = k_.rsplit('_', 1)
        need_ = st.get(f'pvh_{sk_}', 0) + D_[int(g_)]
        if v_ != need_:
            bad.append(dict(chunk=k_, edges=v_, need=need_))
    vt_ = pv_vport_timing(m).get('r6', {})
    pv_fix = [a_['bus'] for a_ in (m.get('pin_repair') or {}).get('added', []) if a_['bus'].startswith('pv')]
    return dict(on=True, chunks=len(rec['chunk_total_edges']), chunk_mismatch=bad, W=vt_.get('W'), W_equal=vt_.get('W_equal'),
                W_target=vt_.get('W_target'), pv_pin_repair=sorted(set(pv_fix)),
                ok=not bad and vt_.get('W_equal', True) and (not vt_ or vt_.get('W') == [PV_W]))


def check(m):
    ins = m['insts']
    ev = sorted(ins, key=lambda i: i.x)
    act, bad = [], []
    for i in ev:
        act = [a for a in act if a.x + a.w > i.x + 1e-3]
        for a in act:
            if min(a.y + a.h, i.y + i.h) - max(a.y, i.y) > 1e-3 and min(a.x + a.w, i.x + i.w) - max(a.x, i.x) > 1e-3:
                bad.append((a.name, i.name))
        act.append(i)
    out = [i.name for i in ins if i.x < -1e-3 or i.y < -1e-3 or i.x + i.w > m['die']['w'] + 1e-3
           or i.y + i.h > m['die']['h'] + 1e-3]
    return dict(overlaps=len(bad), overlap_examples=bad[:10], outside=len(out), outside_examples=out[:10])


def _case_ties(m, path):
    """the case die.v (written by the base generator) gets this die's constants as assigns (mapped to tie cells by
    die_constant_cells.tcl) and the v1.4 extra bit-tap connections.  2026-10-15 (r7): before this the case left the write
    leaves' lane straps wlane_* / wtail_* (and would leave the HOST slice lpc straps) declared but UNDRIVEN."""
    p_ = Path(path)
    tx = p_.read_text()
    for inst_, cs in m.get('extra_conns', {}).items():
        mt = re.search(rf'^(  \S+ {inst_} \()(.*)(\);)$', tx, re.M)
        if not mt:
            raise ValueError(f'extra connection: no instance {inst_}')
        tx = tx[:mt.end(2)] + ', ' + ', '.join(cs) + tx[mt.end(2):]
    ties = {}
    for b_, lane in (m.get('wq_straps') or {}).items():
        ties[b_] = (3, lane)
    if m['geo'].get('kv_wq_leaves'):
        ties.update({f'wtail_{st}_{g}': (2, 0) for st in STACKS for g in range(4)})
    ties.update(m.get('host_ties') or {})
    lines = []
    for b_, (w_, v_) in ties.items():
        if f'wire [{w_ - 1}:0] n_{b_};' not in tx:
            raise ValueError(f'constant net n_{b_} not in the case netlist')
        if f'assign n_{b_}' not in tx:      # one-bit assigns, as kv_expand's tie nets (die_constant_cells.tcl maps them)
            lines += [f"  assign n_{b_}[{i}] = 1'b{(v_ >> i) & 1};" for i in range(w_)]
    tx = tx.replace('endmodule', '\n'.join(lines) + '\nendmodule', 1) if lines else tx
    p_.write_text(tx)



PDN_PA_BLOCK = """set t0 [clock seconds]
if {[catch {pin_access -verbose 1} err]} { puts "OT_PA FAIL $err"; error $err } else { puts "OT_PA DONE" }
puts "OT_TIME pa_s=[expr {[clock seconds]-$t0}]"
mem pa
"""


def pdn_pin_access_after_pdn(text):
    """Q-KVSYS-DIE 2026-10-15 (kvs8-codex-1338 PDN FAIL 'map::at'): OpenDB dbInst::swapMaster throws std::map::at
    once pin_access has built access points (E4 reproducer on the exact floorplan.odb: 27,810 swaps PASS without pin
    access, the chain's PA-then-swap order fails), so the temporary PDN bbox swap must precede pin access.  The real
    case (run.tcl) already proves pin access before PDN; here pin access runs after pdngen + restore + the VDD/VSS
    PG checks, on the real restored masters with the die straps present, and its OT_PA marker is kept."""
    if text.count(PDN_PA_BLOCK) != 1:
        raise ValueError('KV PDN vehicle changed: pin-access block unresolved')
    text = text.replace(PDN_PA_BLOCK, '')
    anchor = 'write_db /work/floorplan_pdn.odb'
    if text.count(anchor) != 1:
        raise ValueError('KV PDN vehicle changed: write_db anchor unresolved')
    head, tail = text.split(anchor)
    if 'OT_PGCHECK' not in head or 'pdngen' not in head:
        raise ValueError('KV PDN vehicle changed: PG check must precede pin access')
    return head + PDN_PA_BLOCK + anchor + tail


# 2026-10-15 (Q-KVSYS-DIE, kvs8-codex-1338 PDN FAIL "OT_CONST: missing literal M1 rail contact ctrl_EN__u_pc1_1/VDD"):
# the KV core grid had NO M1 / M2 rails, so none of the die-top ASAP7 tie cells (strap constants) had a supply.  Same
# structure as the compute die r8 (tools/qwen_split/die_tie_rows.tcl): rows only around the die-top cells, literal M1 / M2
# followpins on them, stacked M2 -> M9 onto the core M9 stripes (KV core grid: M8 / M9 0.48 @ 10.88, offset 2.0); cells
# under an opposite-net M8 stripe move to the nearest connectable spot.  check_power_grid + die_constant_pg_check decide.
KV_CORE_PG = dict(p8=10.88, w8=0.48, p9=10.88, w9=0.48, off=2.0)
KV_TIE_PG = """
# KV die-top tie cells (die_tie_rows.tcl rebuilt the rows around them): literal rails stacked onto the core M9 stripes
add_pdn_stripe -grid {core} -layer {M1} -width {0.018} -followpins
add_pdn_stripe -grid {core} -layer {M2} -width {0.018} -followpins
add_pdn_connect -grid {core} -layers {M1 M2}
add_pdn_connect -grid {core} -layers {M2 M9}
"""


def kv_tie_rows_hooks(text):
    """run_pdn.tcl: ot_tie_rows right after read_db (before any bbox swap / pdngen), ot_tie_rows_verify after pdngen."""
    if 'ot_tie_rows' in text:
        return text
    a = 'mem read\n'
    b = 'source /work/die_constant_pg_check.tcl'
    if text.count(a) != 1 or text.count(b) != 1:
        raise ValueError('KV PDN vehicle changed: tie-row hooks unresolved')
    g = KV_CORE_PG
    text = text.replace(a, a + f"source /work/die_tie_rows.tcl\not_tie_rows {g['p8']} {g['w8']} {g['p9']} {g['w9']} 12.0 0.6 1.08 "
                        f"{g['off']} {g['off']}\nmem tie_rows\n", 1)
    return text.replace(b, f"ot_tie_rows_verify {g['p8']} {g['w8']}\n" + b, 1)


def case(m, work):
    """the die-level case of the r21 Qwen chain (tools/qwen_rom_fulldie.case_real: elements.lef from these masters,
    phy_ew.lef, die.v, place.tcl, run.tcl legality / on-track / pin access, run_pa.tcl PDN), written by the base
    generator's writer with this die's masters and port widths."""
    if os.environ.get('OT_KV_STATIC', '0') == '1' or m.get('geo', {}).get('kv_static'):
        raise ValueError('static source composition has no qualified physical case/legacy-view alias')
    if m['geo'].get('static_memory_reservation'):
        raise ValueError('static memory shape reservation is plan-only until actual adapter ports/relays replace old landing binding')
    # qwen-1010/b 2026-10-11: the mirror leaf plan is the ADOPTED write queue (ctl_bin + leaf_s_w129(_m) closed, bound
    # in superseded_elements.json); the other leaf candidates stay plan-only
    if m['geo'].get('kv_wq_leaves') and not m['geo'].get('kv_wq_mirror'):
        raise ValueError('per-PC leaf candidate is plan-only until encoder/pin/context gates pass')
    if m['geo'].get('split'):
        assigned = stack_local_reach(m, masters(m, 1))
        lg_ = check(m)                       # KV-CASE2: the case-step record (reach + legality) in case.log
        print(f"kv die: case stack-local exact pin-bit reach {assigned['violations']} overreach / {assigned['unmeasured']} "
              f"unmeasured; legality {lg_['overlaps']} overlaps / {lg_['outside']} outside", file=sys.stderr)
        if assigned['violations'] or assigned['unmeasured']:
            raise ValueError(f"stack-local exact pin-bit reach failed: {assigned['violations']} overreach, "
                             f"{assigned['unmeasured']} unmeasured: {assigned['worst'][:3]}")
    saved = F.masters, F.port_widths
    F.masters, F.port_widths = masters, port_widths
    try:
        man = F.case_real(m, work)
    finally:
        F.masters, F.port_widths = saved
    _case_ties(m, work / 'die.v')
    if KSD.ON and m['geo'].get('static_die'):
        # KVR-DERIVE 10-19: the case's die.v gets the per-instance parameter sidecar too (F.case_real writes die.v with the
        # base writer, which never wrote it: the strict bind fell back to the master defaults)
        (work / 'die.v.params.json').write_text(json.dumps(static_instance_params(m), indent=1) + '\n')
    run = (work / 'run.tcl').read_text()
    # KV uses the base generator's run_pa vehicle, independently of the
    # compute-die run_pdn generator. Preserve its real PG/pin checks and enable
    # the same temporary conservative OBS mechanism around pdngen only.
    pdn_run = (work / 'run_pa.tcl').read_text()
    guarded = """set ot_bbox 0
if {[info exists ::env(OT_PDN_BBOX_OBS)] && $::env(OT_PDN_BBOX_OBS) eq "1"} {
  source /work/pdn_bbox_obs.tcl
  # Preflight the entire actual KV master set before any PDN geometry work.
  ot_pdn_bbox::begin /work
  ot_pdn_bbox::restore
  puts "OT_PDN_BBOX PREFLIGHT PASS actual KV pins, outline, PG, containment and detailed OBS restoration"
  ot_pdn_bbox::begin /work
  set ot_bbox 1
}
try {source /work/pdn.tcl; pdngen} finally {
  if {$ot_bbox} {ot_pdn_bbox::restore}
}
source /work/die_constant_pg_check.tcl"""
    original = 'source /work/pdn.tcl; pdngen; source /work/die_constant_pg_check.tcl'
    if pdn_run.count(original) != 1:
        raise ValueError('KV PDN vehicle changed: guarded PDN hook unresolved')
    pdn_text = pdn_pin_access_after_pdn(pdn_run.replace(original, guarded))
    pdn_text = kv_tie_rows_hooks(pdn_text)
    (work / 'run_pdn.tcl').write_text(pdn_text)
    for helper in ('pdn_bbox_obs.py', 'pdn_bbox_obs.tcl'):
        (work / helper).write_text((ROOT / 'tools/qwen_kv_die/chain' / helper).read_text())
    (work / 'die_tie_rows.tcl').write_text((ROOT / 'tools/qwen_split/die_tie_rows.tcl').read_text())
    (work / 'pdn.tcl').write_text((work / 'pdn.tcl').read_text() + KV_TIE_PG)
    # the HBM PHY macros' own M4 power rails (the KV die's four PHY bands): a macro grid that straps them to M8 / M9,
    # so the PG check sees them connected (die_kv2..4: 1,000 PSM-0038 unconnected M4 shapes over x 20.8 - 853.3 um).
    # qwen-1010/b 2026-10-10: M4 and M8 are both horizontal, so an M4 -> M8 connect only forms where a strap happens to
    # overlay a rail of its own net (die_kv11: VDD PASS by that coincidence, every VSS rail open, PSM-0069).  The grid now
    # crosses the rails with vertical M5 straps (M5 is free over the PHY: OBS M1-M4 only), M4 -> M5 at every crossing,
    # M5 -> M8 stacked onto the CORE grid's M8 (which runs over the PHY).  The grid's own M8 / M9 copy is gone: with it
    # VSS still failed (die_kv12 PSM-0069); without it VSS passes (pgb test on the die_kv11 floorplan).
    (work / 'pdn.tcl').write_text((work / 'pdn.tcl').read_text() + '''
set phy_cells {}
# 2026-10-15 (kvs8-codex-1338 PSM-0039 ucie_rom / serdes_host VDD): the UCIe and host SerDes PHY abstracts carry the same
# single horizontal M4 PG rails as the HBM PHY -> the same M5-strap grid
foreach mst [[ord::get_db] getLibs] { foreach c [$mst getMasters] { foreach pp {ot_hbm3e_phy* OT_PDN_BBOX_ot_hbm3e_phy* ot_qkvd_ucie_x64_phy* OT_PDN_BBOX_ot_qkvd_ucie_x64_phy* ot_qfd_serdes_112g_x12_phy* OT_PDN_BBOX_ot_qfd_serdes_112g_x12_phy*} { if {[string match $pp [$c getName]]} { lappend phy_cells [$c getName] } } } }
set phy_cells [lsort -unique $phy_cells]
if {[llength $phy_cells]} {
  define_pdn_grid -macro -cells $phy_cells -halo {0 0 0 0} -voltage_domains {CORE} -name {phy}
  add_pdn_stripe -grid {phy} -layer {M5} -width {0.12} -pitch {10.88} -offset {1.0}
  add_pdn_connect -grid {phy} -layers {M4 M5}
  add_pdn_connect -grid {phy} -layers {M5 M8}
}
# kv-die it2 (die_iter_1012): bound real element views (exact LEFs) carry their PG pins as full-length horizontal M6
# stripes (layer contract: leaf PG on M6, parent straps one layer up).  M6 and the die's M8 are both horizontal, so the
# die grid never reaches them (it1 die_kvi1: all 132 bound views PSM-0039 unconnected, PSM-0069).  Vertical M7 straps
# over every block master whose VDD pin is on M6: M6 -> M7 at each crossing, M7 -> M8 onto the core grid.
set hv6_cells {}
foreach mst [[ord::get_db] getLibs] { foreach c [$mst getMasters] {
  if {![$c isBlock]} { continue }
  set t [$c findMTerm VDD]
  if {$t eq "NULL"} { continue }
  foreach mp [$t getMPins] { foreach b [$mp getGeometry] {
    if {[$b getTechLayer] ne "NULL" && [[$b getTechLayer] getName] eq "M6"} { lappend hv6_cells [$c getName] } } }
} }
set hv6_cells [lsort -unique $hv6_cells]
puts "OT_HV6 masters [llength $hv6_cells]: $hv6_cells"
if {[llength $hv6_cells]} {
  define_pdn_grid -macro -cells $hv6_cells -halo {0 0 0 0} -voltage_domains {CORE} -name {hv6}
  add_pdn_stripe -grid {hv6} -layer {M7} -width {0.288} -pitch {10.88} -offset {2.0}
  add_pdn_connect -grid {hv6} -layers {M6 M7}
  add_pdn_connect -grid {hv6} -layers {M7 M8}
}
# qwen-split kvs1 (PSM-0039 on all 128 head_hs): cluster views whose PG pins are VERTICAL M7 stripes (no M6 PG) only need the
# M7 -> M8 connect onto the core grid (the core M8 straps cross their M7 stripes)
set hv7_cells {}
foreach mst [[ord::get_db] getLibs] { foreach c [$mst getMasters] {
  if {![$c isBlock] || [lsearch -exact $hv6_cells [$c getName]] >= 0} { continue }
  set t [$c findMTerm VDD]
  if {$t eq "NULL"} { continue }
  foreach mp [$t getMPins] { foreach b [$mp getGeometry] {
    if {[$b getTechLayer] ne "NULL" && [[$b getTechLayer] getName] eq "M7"} { lappend hv7_cells [$c getName] } } }
} }
set hv7_cells [lsort -unique $hv7_cells]
puts "OT_HV7 masters [llength $hv7_cells]: $hv7_cells"
if {[llength $hv7_cells]} {
  define_pdn_grid -macro -cells $hv7_cells -halo {0 0 0 0} -voltage_domains {CORE} -name {hv7}
  add_pdn_connect -grid {hv7} -layers {M7 M8}
}
# qwen-split kvsys v1.1 (kvs1 PSM-0039 on all 128 qkd_cdc_wleaf; the sl1 write leaf too): M5-capped leaf views whose PG pins
# are VERTICAL M5 stripes (no M6 / M7 PG): the core grid's horizontal M8 straps cross them -> a stacked M5 -> M8 connect
# (M6 / M7 are free over an M5-capped leaf)
set hv5_cells {}
foreach mst [[ord::get_db] getLibs] { foreach c [$mst getMasters] {
  if {![$c isBlock] || [lsearch -exact $hv6_cells [$c getName]] >= 0 || [lsearch -exact $hv7_cells [$c getName]] >= 0} { continue }
  if {[string match ot_hbm3e_phy* [$c getName]] || [string match OT_PDN_BBOX_ot_hbm3e_phy* [$c getName]]} { continue }
  set t [$c findMTerm VDD]
  if {$t eq "NULL"} { continue }
  foreach mp [$t getMPins] { foreach b [$mp getGeometry] {
    if {[$b getTechLayer] ne "NULL" && [[$b getTechLayer] getName] eq "M5"} { lappend hv5_cells [$c getName] } } }
} }
set hv5_cells [lsort -unique $hv5_cells]
puts "OT_HV5 masters [llength $hv5_cells]: $hv5_cells"
# 2026-10-15 (Q-KVSYS-DIE, kvs8-codex-1338 PSM-0069: 998+ head nb1 / nb2 leaves VDD unconnected): a SHORT M5-PG leaf (the
# 32.4 x 10.8 node-beat stations: one VDD M5 pin spanning y 2.15..8.65) is crossed by a core M8 VDD strap (10.88 pitch) only
# ~60 % of the time.  Leaves shorter than two core pitches get their own M8 straps at 5.44 (each net inside any 5.4-um pin
# span), stacked M5 -> M8 and M8 -> core M9 (the M9 straps cross every leaf >= 10.88 wide).  Fixture: 3 nb leaves R0/MX,
# without: PSM-0069 VDD + VSS; with: check_power_grid VDD / VSS PASS, 0 M8 VDD/VSS overlaps.
set hv5s_cells {}
foreach n $hv5_cells { foreach mst [[ord::get_db] getLibs] { set c [$mst findMaster $n]
  if {$c ne "NULL" && [$c getHeight] < 21760} { lappend hv5s_cells $n } } }
set hv5s_cells [lsort -unique $hv5s_cells]
set hv5_cells [lmap n $hv5_cells { if {[lsearch -exact $hv5s_cells $n] >= 0} continue; set n }]
puts "OT_HV5S short masters [llength $hv5s_cells]: $hv5s_cells"
if {[llength $hv5_cells]} {
  define_pdn_grid -macro -cells $hv5_cells -halo {0 0 0 0} -voltage_domains {CORE} -name {hv5}
  add_pdn_connect -grid {hv5} -layers {M5 M8}
}
if {[llength $hv5s_cells]} {
  define_pdn_grid -macro -cells $hv5s_cells -halo {0 0 0 0} -voltage_domains {CORE} -name {hv5s}
  add_pdn_stripe -grid {hv5s} -layer {M8} -width {0.48} -pitch {5.44} -offset {2.4}
  add_pdn_connect -grid {hv5s} -layers {M5 M8}
  add_pdn_connect -grid {hv5s} -layers {M8 M9}
}
''')
    # Explicit modeled-PHY candidate revision, before any floorplan ODB exists.
    from phy_pg.apply_case import maybe_apply as _assumed_phy_pg
    phy_access = _assumed_phy_pg(work)
    if phy_access:
        man['assumed_phy_pg_access'] = 'assumed_phy_pg_access.json'
    man.update(die='qwen_kv', die_um=[m['die']['w'], m['die']['h']], generator='tools/qwen_kv_die/kv_die.py')
    (work / 'manifest.json').write_text(json.dumps(man, indent=1))
    if PV_T:      # KVPLAN 1815: the case carries the trunked pair's cost record (area / flops / latency, chunk stages)
        (work / 'pv_trunk_record.json').write_text(json.dumps(pv_trunk_record(m), indent=1) + '\n')
    return man


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('mode', choices=['plan', 'case'])
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--r', type=int, default=R)
    ap.add_argument('--kv-wq-leaves', action='store_true', help='candidate per-PC write leaves; encoder closure still owed')
    ap.add_argument('--kv-wq-leaf-s', action='store_true', help='plan-only south-face leaf plus binary ctl candidate')
    ap.add_argument('--kv-wq-binary', action='store_true', help='plan-only binary ctl candidate; needs its own routed closure')
    ap.add_argument('--kv-wq-head', action='store_true', help='candidate 216x648 binary ctl with one head capture edge')
    ap.add_argument('--kv-wq-wide', action='store_true', help='candidate 129.6um south-face leaf')
    ap.add_argument('--kv-wq-mirror', action='store_true', help='candidate single-layer mirror-legal wide leaf; head capture remains opt-in')
    ap.add_argument('--reserve-static-memory', action='store_true', help='plan-only native151.2umPC SRAM column plus86.4um row-control column; actual adapter binding still required')
    ap.add_argument('--reserve-native-astk', action='store_true', help='plan-only328.32um parent for actual two162um ASTK columns; selected static/native views remain required')
    ap.add_argument('--static-graph', type=Path, help='OT_KV_STATIC=1 only: complete source-pinned compiler join JSON; never imports legacy credit graph')
    ap.add_argument('--split', action='store_true', help='qwen-split 2026-10-14: the KV/SYSTEM die of the two-die split (CONTRACT_KVSYS.md)')
    ap.add_argument('--host-v14', action='store_true', help='kvsys v1.4: real HOST root core + 128 die-placed PC slices + PLL model')
    ap.add_argument('--host-north', action='store_true', help='kvsys v1.4.1: HOST root core directly below the static D2D end')
    ap.add_argument('--host-trees', action='store_true', help='kvsys v1.4.2: HOST reset / boot fan-outs as registered relay trees')
    ap.add_argument('--v143', action='store_true', help='kvsys v1.4.3 G3S2: staged head ingress / score on closed gather / '
                    'sstage views, near-head feed-through frames, anchored group growth (needs --split --host-trees)')
    a = ap.parse_args(argv)
    if os.environ.get('OT_KV_STATIC', '0') == '1':
        import kv_static
        if not a.split:
            ap.error('OT_KV_STATIC requires --split')
        if a.mode == 'case':
            # KVJ-G 10-17: lifted only when the strict port bind is clean (0 unconnected, 0 undriven, 0 functional ties);
            # the owned gap list is tools/qwen_kv_die/kvjg_gap_list.py (lanes/KVJ-G.md)
            ap.error('static physical case held: strict port bind not clean (kvjg_gap_list.py); actual homes/pins/clocks/native '
                     'benches and TT/FF/DRC qualification remain required')
        if not a.static_graph:
            a.out.mkdir(parents=True, exist_ok=True)
            (a.out / 'static_requirements.json').write_text(json.dumps(kv_static.requirements(), indent=2) + '\n')
            ap.error('OT_KV_STATIC requires --static-graph with all actual native producers; requirements emitted, no fallback netlist')
        report = kv_static.emit(a.static_graph, a.out)
        print(json.dumps(dict(status=report['status'], native_qualified=False, physical_qualified=False)))
        return 0
    if a.static_graph:
        ap.error('--static-graph requires explicit OT_KV_STATIC=1')
    if (KSD.ON and a.mode == 'case' and os.environ.get('OT_KV_STATIC_DIE_DIAGNOSTIC', '0') != '1'
            and os.environ.get('OT_KV_STATIC_DIE_STRICT', '0') != '1'):
        # KVJ-G2 10-17: the static-die case stays HELD until the strict port bind is clean (0 unconnected functional inputs,
        # 0 undriven, 0 functional ties); a diagnostic GEN (routing evidence of the static floorplan) must say so.
        # KV-PLAN4 10-18: OT_KV_STATIC_DIE_STRICT=1 lifts the hold for a REAL (non-diagnostic) GEN whose die chain runs the
        # strict bind as a gate (die_chain.sh without OT_BIND_DIAGNOSTIC: bind_launch --strict + port_bind_v2 fail the run).
        # KV-WIRE2 strict bind kvw2-6ad1dbb84/port_bind_v2_b PASS 0/0/0.  The record's open_tile_inputs (pc__*, ctl boot__* /
        # oobs__*) are tile ports joined at die level (plan static_die.die_joins), not die opens.
        ap.error('static die case held: strict port bind not clean (kv_static_die record open_tile_inputs); set '
                 'OT_KV_STATIC_DIE_DIAGNOSTIC=1 for a DIAGNOSTIC (not a die result) GEN')
    if a.host_v14:
        if not a.split:
            ap.error('--host-v14 needs --split')
        HOST_V14['on'] = True
    if a.host_north:
        if not a.host_v14:
            ap.error('--host-north needs --host-v14')
        HOST_V14['north'] = True
    if a.host_trees:
        if not a.host_north:
            ap.error('--host-trees needs --host-north')
        HOST_V14['trees'] = True
    if a.v143:
        if not a.host_trees:
            ap.error('--v143 needs --host-trees')
        V143['on'] = True
    a.kv_wq_wide = a.kv_wq_wide or a.kv_wq_mirror
    a.kv_wq_leaf_s = a.kv_wq_leaf_s or a.kv_wq_head or a.kv_wq_wide
    a.kv_wq_binary = a.kv_wq_binary or a.kv_wq_leaf_s
    a.kv_wq_leaves = a.kv_wq_leaves or a.kv_wq_binary
    if a.mode == 'case' and a.reserve_native_astk:
        if not KSD.ON or not KSD.ASTK_ST or not KSD.ASTK_EXPAND:
            ap.error('native ASTK case requires the actual static ASTK EXPAND profile (OT_KV_ASTK_EXPAND=1)')
        import kv_astk_expand
        kv_astk_expand.require_views(ROOT)
        # HKV-DIE3 10-19 (coordinator: OT_KV_ASTK_EXPAND production, option B): the production calendar is the measured
        # RL3 / stride-4 / distributed e-read law (kv_static_programme.astk_law, HKV-ASTK 62b812e04); its consistency with
        # the bound hub / pvfin (hub export after the publication, pvfin pair skew) is checked fail-closed on the
        # post-station netlist by kv_static_params ATTN_CALENDAR (kv_relay_check / layer_compile), not refused here.
        if str(ROOT) not in sys.path:
            sys.path.insert(0, str(ROOT))
        from tools.qwen_kv_die import kv_static_programme as _KSP
        _KSP.astk_law()
    if a.mode == 'case' and a.kv_wq_leaves and not a.kv_wq_mirror:
        ap.error('per-PC leaf candidate is plan-only: encoder and closed-view pin/context gates remain open')
    m = build(a.r, kv_wq_leaves=a.kv_wq_leaves, kv_wq_binary=a.kv_wq_binary, kv_wq_leaf_s=a.kv_wq_leaf_s, kv_wq_head=a.kv_wq_head, kv_wq_wide=a.kv_wq_wide, kv_wq_mirror=a.kv_wq_mirror, split=a.split, reserve_static_memory=a.reserve_static_memory, reserve_native_astk=a.reserve_native_astk)
    if a.mode == 'case':
        m['buses'] = [(bid, cls, bits, eps) for bid, cls, bits, eps in m['buses']]
        print(json.dumps(case(m, a.out)))
        # QLB-KV 10-18: the case writes its generator-model die-run table too (case_kv/relay_stages.json; kvs14c had none).
        # The relay check still walks the BOUND netlist (kv_relay_check.sh); this table is the cross-check of the model.
        try:
            sys.path.insert(0, str(ROOT / 'tools'))
            from qwen_kv_die import relay_stages_export as _rsx
            import die_relay_stages as _drs
            _doc = _rsx.export_model(m, f'qwen_kv:{a.out.name}', sources=['tools/qwen_kv_die/kv_die.py'])
            _drs.write(a.out / 'relay_stages.json', _doc)
            print(f"kv die relay_stages.json: {_doc['bus_count']} buses, {_doc['problem_count']} problems, digest {_doc['digest']}")
        except Exception as _e:                      # noqa: BLE001
            print(f'kv die relay_stages.json export FAILED: {_e!r}'[:600])
        if m.get('land_slots'):
            (a.out / 'land_slots.json').write_text(json.dumps(m['land_slots'], indent=1, default=str) + '\n')
        if KSD.ON and m['geo'].get('static_die'):   # HKV-DIE2 10-19: stage-derived params are recomputed post-station
            import kv_static_params as KSP            # (kv_static_params.py on the die netlist table; plan values = record)
            static_instance_params(m)
            ml = KSP.model_lite(m)
            (a.out / 'static_model.json').write_text(json.dumps(ml, indent=1, default=str) + '\n')
            # KVR-DERIVE 10-19 (coordinator): the plan's static-schedule ages vs the closed tiles' hard ages and the
            # generator's own bindings -- any mismatch fails the GEN (OT_KV_STATIC_SCHED_STRICT=1, default); =0 records it
            # (STATIC_SCHEDULE FAIL in case.log + static_model.json) and lets a placement-only run continue
            boot_ = None
            if KSD.KB.ON:     # KV-BOOTAGE 10-19: the compiler boot image's age words from THIS plan (case boot_ages.json)
                boot_ = KSD.KB.image_ages(ml['static_schedule']['schedule'], ml['tile_ages'])
                ml['boot_ages'] = boot_
                (a.out / 'boot_ages.json').write_text(json.dumps(boot_, indent=1) + '\n')
            sf = KSP.schedule_check(ml['static_schedule']['schedule'], ml['tile_ages'],
                                    dict(ectl=ml['bindings']['ectl'], vport=ml['bindings']['vport'],
                                         pv_ctl_age=ml['bindings']['pv_ctl_age'], attn=KSD.attn_tile_params()), boot=boot_)
            ml['static_schedule']['fails'] = sf
            (a.out / 'static_model.json').write_text(json.dumps(ml, indent=1, default=str) + '\n')
            print('kv die STATIC_SCHEDULE ' + ('FAIL: ' + '; '.join(f"{f_['id']} {f_['what'][:160]}" for f_ in sf) if sf
                                               else 'PASS'), file=sys.stderr)
            if sf and os.environ.get('OT_KV_STATIC_SCHED_STRICT', '1') == '1':
                raise SystemExit('kv die: STATIC_SCHEDULE FAIL (plan ages vs the closed tiles; static_model.json '
                                 'static_schedule.fails; OT_KV_STATIC_SCHED_STRICT=0 records and continues)')
        return 0
    rec = record(m)
    rec['legality'] = check(m)
    M = masters(m, 1)
    rec['masters_abstract'] = {n: dict(w=round(mm.w, 3), h=round(mm.h, 3), ports=len(mm.order)) for n, mm in M.items()}
    rec['strict_ports'] = strict_ports(M)
    rec['pin_reach'] = pin_reach(m, M)   # qwen-1010/b: pin-to-pin register hops (SS reach 504 um)
    rec['stack_local_reach'] = stack_local_reach(m, M)
    real_rows, real_status = real_pin_bindings(m)
    if KSD.ON and m['geo'].get('static_die'):
        rec['static_die'] = KSD.record(m)
        rec['static_die']['ectl_params'] = KSD.response_lat(m)
    if a.kv_wq_leaf_s and not m['geo'].get('static_die'):
        rec['actual_pin_views'] = real_status
        rec['cdc_write_pin_reach'] = cdc_write_pin_reach(m, real_rows)
    if a.kv_wq_leaves:
        rec['kv_wq_candidate'] = dict(adopted=False, leaves=128, control_tiles=4, encoder_tiles=0 if a.kv_wq_binary else 16,
            encoder='binary low3/high5zero inside successor ctl' if a.kv_wq_binary else '3 OR4 per group; matches ot_qkvd_kv_wq_leaves exactly',
            gate='BLOCKED_BINARY_CTL_PHYSICAL_CLOSURE' if a.kv_wq_binary else 'BLOCKED_ENCODER_PHYSICAL_CLOSURE', chain_order='PC 8*g through 8*g+7 S-to-N' if a.kv_wq_leaf_s else 'PC 8*g+7 through 8*g N-to-S, lane strap PC%8',
            cdc_ci_slices=dict(wi=[0,290], wr=[290,11], cf=[301,1]),
            controller_head_cycles=1 if a.kv_wq_head else 0, chain_hop_cycles=dict(feed=2, done=1), relay_cycles=m['relay_stages'],
            controller_group_slices={g: dict(f_v=[g,1], f_d=[256*g,256], f_sec=[24*g,24],
                                             f_lane=[8*g,8], f_tag=[9*g,9], r_v=[g,1], r_bad=[g,1]) for g in range(4)},
            physical_gate='closed leaf/ctl pin shapes must replace candidate abstracts; optionB TT>=0 FF>=0 DRC0 with SS reach sensitivity',
            encoder_sizing=dict(or4_per_group=0 if a.kv_wq_binary else 3, or2_equivalent_total=0 if a.kv_wq_binary else 144,
                                reserved_frame_mm2=0 if a.kv_wq_binary else round(16*43.2*43.2/1e6,6), measured_cell_area=None))
    a.out.mkdir(parents=True, exist_ok=True)
    try:                                         # ROOT RELAY-SCHEMA 10-16: additive per-bus stage table, never a gate here
        sys.path.insert(0, str(ROOT / 'tools'))
        from qwen_kv_die import relay_stages_export as _rsx
        import die_relay_stages as _drs
        _doc = _rsx.export_model(m, f'qwen_kv:{a.out.name}', sources=['tools/qwen_kv_die/kv_die.py'])
        _drs.write(a.out / 'relay_stages.json', _doc)
        rec['relay_stages_export'] = dict(file='relay_stages.json', digest=_doc['digest'], buses=_doc['bus_count'],
                                          problems=_doc['problem_count'])
    except Exception as _e:                      # noqa: BLE001
        rec['relay_stages_export'] = dict(error=repr(_e)[:500])
    (a.out / 'plan.json').write_text(json.dumps(rec, indent=1, default=str) + '\n')
    if real_rows:
        (a.out/'actual_pin_bindings.json').write_text(json.dumps(real_rows,indent=1)+'\n')
    (a.out / 'insts.json').write_text(json.dumps([i.d() for i in m['insts']]) + '\n')
    write_netlist(m, 1, a.out / 'kv_die.v', top='qkd_die')
    print(json.dumps({k_: rec[k_] for k_ in ('die_um', 'die_mm2', 'instances', 'fill', 'legality')}))
    return 0 if not rec['legality']['overlaps'] and not rec['legality']['outside'] else 1


if __name__ == '__main__':
    sys.exit(main())
