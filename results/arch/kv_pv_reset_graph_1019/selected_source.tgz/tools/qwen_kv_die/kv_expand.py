#!/usr/bin/env python3
"""qwen-split/kvsys v1.3 (2026-10-14, die lead r4): DIE-PLACED LEAVES.  A wires-only parent frame of the KV/system die
case (head, engine control, controller strip, ...) is replaced by its CLOSED leaves, each placed in the die at its
planned sub-slot and bound to its own closed view (exact LEF + TT/FF/SS ETM + insertion.json -> phi - R clock), so the
die STA times every leaf-to-leaf and leaf-to-die path on real views instead of the frame's ASSUMED single-flop ends.

Connectivity is bit-exact: yosys elaborates the parent RTL module (BINDINGS[frame]['module']) with every child as a
black box (ports from the child view's LEF: name, width, direction), and writes the parent's port and cell bit
connections.  Die port bits map to parent RTL port bits by the BINDINGS convention (die port dp -> concatenation of
BINDINGS ports, LSB first; 'sliced' die ports continue the base port after its bits, base first, others sorted), so a
child pin bit lands on (a) the die net bit of the frame's die port it was wired to, (b) a die wire private to the frame
instance (leaf-to-leaf), or (c) a strap: a constant (RTL literal) or a 'classed' strap port (head index, engine/stack
id) = a tie at that leaf's pin, carried on a net local to that one leaf.

    kv_expand.py --run RUN [--only qkd_rhead,qkd_ectl,...]
rewrites RUN/case_kv/{die.v, place.tcl, elements.lef} (originals kept as *.preexp), adds RUN/libs/qfd_etm_<leaf>_<c>.lib
and the leaves to RUN/libs/views.json (expanded_from), writes RUN/expand.json (per frame: leaves, nets, straps, checks).
"""
import argparse
import json
import re
import shutil
import subprocess
import sys
import tempfile
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
sys.path.insert(0, str(ROOT / 'tools' / 'qwen_kv_die'))
import kv_die as K  # noqa: E402
from binding_order import sliced_order
import kv_expand_parameters as EP

CORNERS = ('tt', 'ff', 'ss')
RT = 'physical/ref_tile'
# closed leaf views (module -> view dir); every leaf of an expanded frame must have one
ECTL_H13 = __import__('os').environ.get('OT_KV_ECTL_H13', '0') == '1'
VIEWS = dict(
    ot_qkh_head_frontq_native=f'{RT}/qkh_r4_frontq_1014/views/ot_qkh_head_frontq_native',
    ot_qkh_head_stin_native=f'{RT}/qkh_r3_stin_1014/views/ot_qkh_head_stin_native',
    ot_qkh_head_stk_native=f'{RT}/qkh_r3_stk_1014/views/ot_qkh_head_stk_native',
    ot_qkh_head_nb_native=f'{RT}/qkh_r3_nb_1014/views/ot_qkh_head_nb_native',
    ot_qkh_lane8=f'{RT}/ot_qkh_lane8_m5/views/ot_qkh_lane8',
    ot_qkh_ktree=f'{RT}/ot_qkh_ktree_m5/views/ot_qkh_ktree',
    ot_qkh_head_score4_native=f'{RT}/qkh_r4_score4_1014/views/ot_qkh_head_score4_native',
    qkd_ectl_a_tp8_direct=f'{RT}/qkd_ectl_a_tp8_direct/views/qkd_ectl_a_tp8_direct',
    # Q-ELEM 2026-10-15 22:34 (G3S2 composition: HXK5 silently wrong 512/512, HXK13 exact 53/53): OT_KV_ECTL_H13=1 binds
    # a -> the h5 view (synthesis byte-identical to h13, results/arch/qwen_ectl_h13_2115/ab_reuse.json; the a_h13 view is
    # pending its native capture fix), b -> h5 (identical, native PASS), c -> the CLOSED h13 view (e033dce09). Never c_h5.
    # KVPLAN3 0230 (Q-KVFIX 0130): a -> the CLOSED pg16s view (same synth netlist as h5, native PASS launch 185.5 / capture
    # 161.3 / R 314.5, LEF = the ECTL A pin grant 2638/2638; h5 = native FAIL capture 221.0 rs, R 413.6).
    qkd_ectl_a_tp8_epoch_direct=(f'{RT}/qkd_ectl_a_tp8_epoch_direct_pg16/views/qkd_ectl_a_tp8_epoch_direct' if ECTL_H13 else
                                 f'{RT}/qkd_ectl_a_tp8_direct/views/qkd_ectl_a_tp8_epoch_direct'),
    qkd_ectl_b_tp8_direct=(f'{RT}/qkd_ectl_b_tp8_direct_h5/views/qkd_ectl_b_tp8_direct' if ECTL_H13 else
                           f'{RT}/qkd_ectl_b_tp8_direct/views/qkd_ectl_b_tp8_direct'),
    qkd_ectl_c_tp8_direct=(f'{RT}/qkd_ectl_c_tp8_direct_h13/views/qkd_ectl_c_tp8_direct' if ECTL_H13 else
                           f'{RT}/qkd_ectl_c_tp8_direct/views/qkd_ectl_c_tp8_direct'),
    qkd_ctrl_pc=f'{RT}/qkd_ctrl_pc/views/qkd_ctrl_pc',
    qkd_ctrl_kc=f'{RT}/qkd_ctrl_kc/views/qkd_ctrl_kc',
    # v1.4.3 near-head feed-through leaves (the far head's T1 / S2)
    qkh_head_gather_stage=f'{RT}/qkh_head_gather_stage/views/qkh_head_gather_stage',
    qkh_head_sstage=f'{RT}/qkh_head_sstage/views/qkh_head_sstage',
    # v1.4.4 PV16 wide pair leaves (CLOSED, all reset-pin r5: RESET_PIN 1 = the pair's LEAF_RESET_PIN / CTL_RESET_PIN 1)
    ot_qwen_tp8_pv_slice_t=f'{RT}/qkd_pv_slice_rstpin_r5/views/ot_qwen_tp8_pv_slice_t',
    # KVPLAN3 0230: join re-pin successor r6 (sf[7:4] E face; CLOSED TT +57.72 / FF +14.85, native PASS 214.2 / 167.4)
    ot_qwen_tp8_pv_join_t=f'{RT}/qkd_pv_join_sfe_r6/views/ot_qwen_tp8_pv_join_t',
    # kvs13d: OT_KV_PV_CTL_KIT names the closed ctl kit whose FIRST_INPUT_AGE equals the die's (r5 = 20)
    ot_qwen_tp8_pv_wide_ctl=f"{RT}/{__import__('os').environ.get('OT_KV_PV_CTL_KIT', 'qkd_pv_ctl_rstpin_r5')}/views/ot_qwen_tp8_pv_wide_ctl",
    # KVPLAN 1815 (OT_KV_PV_T): the trunked pair's control tile and its relay-standard stations
    ot_qwen_tp8_pv_wide_ctl_t=f"{RT}/{__import__('os').environ.get('OT_KV_PV_T_CTL_KIT', 'qkd_pv_ctl_t_d54f58')}/views/ot_qwen_tp8_pv_wide_ctl_t",
    **{f'qkd_rlys_{w_}': f'{RT}/qkd_rlys_{w_}/views/qkd_rlys_{w_}' for w_ in (1, 36, 296)},
    # KV-RTRUNK 10-17: the pair's result-trunk leaves (kits physical/ref_tile/qkd_rlyi_258 / qkd_pv_rs_hd; views = their gates)
    qkd_rlyi_258=f'{RT}/qkd_rlyi_258/views/qkd_rlyi_258', qkd_pv_rs_hd=f'{RT}/qkd_pv_rs_hd/views/qkd_pv_rs_hd',
    # KV-KITS/NATIVE 10-18: their native-pin successors (pv_trunk_gen default; r1 views fail native capture on the selects)
    qkd_rlyi_258s=f'{RT}/qkd_rlyi_258s/views/qkd_rlyi_258s', qkd_pv_rs_hd_r=f'{RT}/qkd_pv_rs_hd_r/views/qkd_pv_rs_hd_r',
    # AD3-KV-PARENTS 10-18: the static sequencer qkd_seq_static_s (die slot seq, kv_static_die SEQ_S) is a wires-only parent
    # of 9 CLOSED leaves -> die-placed (the die is its parent), no hardened cluster view
    qkd_seq_core_static_s=f'{RT}/qkd_seq_core_st_s/views/qkd_seq_core_static_s',
    qkd_seq_xs_s=f'{RT}/qkd_seq_xs_s/views/qkd_seq_xs_s', qkd_seq_fan_s=f'{RT}/qkd_seq_fan_s/views/qkd_seq_fan_s',
    # AD3-KV-RSHD 10-18: the header's half-local-select successor (pv_trunk_gen --rs-hd f; _r fails native capture 259.9)
    qkd_pv_rs_hd_f=f'{RT}/qkd_pv_rs_hd_f/views/qkd_pv_rs_hd_f',
    # MU-DIE-KV2 10-19 (OT_KV_BOOT_AGES=1: qkd_pvw_die_tb holds the boot-age pair control): CLOSED qkd_pv_ctl_tb1-b1-cebb296c4
    ot_qwen_tp8_pv_wide_ctl_tb=f"{RT}/{__import__('os').environ.get('OT_KV_PV_TB_CTL_KIT', 'qkd_pv_ctl_tb1')}/views/ot_qwen_tp8_pv_wide_ctl_tb",
)
SR = 'rtl/qwen_sys/split_20261014'
RTL = dict(ot_qkh_head_frontq_native=f'{SR}/ot_qkh_head_native_r4.sv', ot_qkh_head_score4_native=f'{SR}/ot_qkh_head_native_r4.sv',
           ot_qkh_head_stin_native=f'{SR}/ot_qkh_head_native.sv', ot_qkh_head_stk_native=f'{SR}/ot_qkh_head_native_r3.sv',
           ot_qkh_head_nb_native=f'{SR}/ot_qkh_head_native_r3.sv', ot_qkh_lane8='rtl/hdc/nearhbm/ot_qkh_subtiles.sv',
           ot_qkh_ktree='rtl/hdc/nearhbm/ot_qkh_subtiles.sv',
           **{f'qkd_ectl_{x}_tp8_direct': f'{SR}/qkd_ectl_native_direct_tp8.sv' for x in 'abc'},
           qkd_ectl_a_tp8_epoch_direct=f'{SR}/qkd_ectl_a_tp8_epoch_direct.sv',
           qkd_ctrl_pc='rtl/qwen_sys/kv_die_20261009/qkd_ctrl_strip.sv', qkd_ctrl_kc='rtl/qwen_sys/kv_die_20261009/qkd_ctrl_strip.sv',
           qkh_head_gather_stage=f'{SR}/qkh_head_gather_stage.sv', qkh_head_sstage=f'{SR}/qkh_head_stages.sv',
           **{m_: 'rtl/hdc/nearhbm/ot_qwen_tp8_pv_wide_pair.sv' for m_ in
              ('ot_qwen_tp8_pv_slice_t', 'ot_qwen_tp8_pv_join_t', 'ot_qwen_tp8_pv_wide_ctl')},
           ot_qwen_tp8_pv_wide_ctl_t='rtl/hdc/nearhbm/ot_qwen_tp8_pv_wide_ctl_t.sv',
           ot_qwen_tp8_pv_wide_ctl_tb='rtl/hdc/nearhbm/ot_qwen_tp8_pv_wide_ctl_tb.sv',
           **{f'qkd_rlys_{w_}': 'rtl/qwen_sys/kv_rly_std_20261016/qkd_rlys.sv' for w_ in (1, 36, 296)},
           **{m_: 'rtl/qwen_sys/split_20261014/qkd_pv_rtrunk.sv' for m_ in ('qkd_rlyi_258', 'qkd_pv_rs_hd', 'qkd_rlyi_258s', 'qkd_pv_rs_hd_r',
                                                                     'qkd_pv_rs_hd_f')},
           **{m_: 'rtl/qwen_sys/static_kv_20261014/qkd_seq_static_s.sv' for m_ in
              ('qkd_seq_core_static_s', 'qkd_seq_xs_s', 'qkd_seq_fan_s')})
# HKV-DIE3 10-19: child master -> the view master it is bound to (face-landed _fl successors: same ports, the RTL child
# keeps its core name; kv_astk_expand.configure fills it for the selected kv_static_die.FACE_LAND_SEL tiles)
ALIAS = {}
# v1.4.4: wires-only sub-levels of an expanded parent (flattened with the parent; never a die instance)
SUBLEVELS = dict(qkd_pvw_die=(('rtl/hdc/nearhbm/ot_qwen_tp8_pv_wide_pair.sv', 'ot_qwen_tp8_pv_wide_pair'),
                             ('rtl/hdc/nearhbm/ot_qwen_tp8_pv_wide_pair.sv', 'ot_qwen_tp8_pv_col')))
SUBLEVELS['qkd_pvw_die_e'] = SUBLEVELS['qkd_pvw_die']     # kvs13d (OT_KV_V144_R6): the epoch-carrying face, same pair

# v1.4.4: parent inputs with NO producer RTL on the die yet: left UNCONNECTED (never tied; strict port bind MISMATCH),
# each with the element that owes the producer.  Only these ports may stay unbound; any other unbound input still refuses.
PV_OPEN = dict(
    start='KVJ-B: qkd_attn_service_root.start_pv (PV_LEAD = the die relay edges to this pair); join pending (plan item 10)',
    context_len='KVJ-B: qkd_attn_service_root.ctx (held accept-to-accept; same relay chain as start)',
    epoch='KVJ-B: qkd_attn_service_root.ep (held accept-to-accept; same relay chain as start)',
    in_epoch='Q-VMWB: V arrival epoch per port (the r5 vport carries none; landing rsp_epoch not on its vo word)',
    in_e='Q-ATTN-RATE (ASTK): qkd_astk_native_er_service_w 4-wide e read face (not in the die ASTK strip qkd_astk_strip_s)')
FLIP = dict(R0=(0, 0), MX=(0, 1), MY=(1, 0), R180=(1, 1))
ORIENT = {v: k for k, v in FLIP.items()}


# ---- per-frame placement plans: yosys cell name -> (x, y, orient) in the frame's canonical (R0) coordinates -------------
def _head_plan(ft=False):
    pl = json.loads((ROOT / (K.HEAD_FT_PLAN if ft else K.HEAD_R4_PLAN)).read_text())['children']
    if ft:      # v1.4.3: the far neighbour's T1 / S2 in the feed-through channel
        pl = dict(pl, ftg=[*K.V143_FT['ftg'], *K.HGS], fts=[*K.V143_FT['fts'], *K.HSS])

    def name(cell):
        m = re.fullmatch(r'g_front\[(\d+)\]\.u_front', cell)
        if m:
            return f'front{m.group(1)}'
        m = re.fullmatch(r'g_t\[(\d+)\]\.u_(stin|stk|nb1|nb2|l8)', cell)
        if m:
            t, k = m.groups()
            return dict(stin=f'stin{t}', stk=f'stk{t}', nb1=f'nb1_{t}', nb2=f'nb2_{t}', l8=f'lane{t}')[k]
        return dict(u_kt='ktree', u_score='score', u_ftg='ftg', u_fts='fts')[cell]
    return lambda cell, fw, fh: (pl[name(cell)][0], pl[name(cell)][1], 'R0')


def _ectl_plan():
    x = dict(u_a=0.0, u_b=254.88, u_c=509.76)       # contract v1.1 sub-slots A | B | C x 129.6 (pins/qkd_ectl.json)
    return lambda cell, fw, fh: (x[cell], 0.0, 'R0')


def _ctrl_plan(rev):
    # PC k: its PHY-face po word level with the PHY abstract's po<k> (strip y 378 k + 200 = PHY y 378 k + 128.7 + 71.28);
    # view po centre y 38.0 (R0) / 134.8 (MX).  kc leaf at the strip's OUTER end, under the frame's kc pin (x = w / 2).
    def f(cell, fw, fh):
        if cell == 'u_kc':
            return (round(fw / 2 - 23.76, 3), 0.0 if rev else round(fh - 43.2, 3), 'MX' if rev else 'R0')
        k = int(cell[4:])
        return (0.0, round(378.0 * k + (65.2 if rev else 162.0), 3), 'MX' if rev else 'R0')
    return f


def _pvt_plan():
    """KVPLAN 1815: the trunked pair's leaf / station homes from its generator plan (canonical R0); a cell inside the
    bench-only mutant generate block is named g_ok.<cell>"""
    cells = K.pvt_plan()['cells']

    def f(cell, fw, fh):
        c_ = cells[cell.split('.', 1)[1] if cell.startswith('g_ok.') else cell]
        return (c_[1], c_[2], c_[5])
    return f


def _pv_plan():
    pl = K.pv_plan()       # cells under the die face qkd_pvw_die flatten as 'u_pair.<pair cell>'
    return lambda cell, fw, fh: (pl[cell.split('u_pair.', 1)[-1]][0], pl[cell.split('u_pair.', 1)[-1]][1],
                                 pl[cell.split('u_pair.', 1)[-1]][4])


# AD3-KV-PARENTS 10-18: qkd_seq_static_s leaf homes in the seq frame (604.8 x 475.2, canonical R0; 43.2-um lattice): W fans
# (aq_WS / aq_WN faces) at x 43.2, E fans (MY) at x 518.4, the 2 x 2 Q-FIFO block (xs, MX: x_d inputs toward the S prg face)
# in the middle, the core in the centre gap between the xs rows (it drives x_v / qpop to all 4 xs and aqm / kc to all 4 fans).
SEQ_S_PLAN = {'u_core': (302.4, 259.2, 'MX'),
              'g_xs[0].u_xs': (172.8, 129.6, 'MX'), 'g_xs[1].u_xs': (345.6, 129.6, 'MX'),
              'g_xs[2].u_xs': (172.8, 302.4, 'MX'), 'g_xs[3].u_xs': (345.6, 302.4, 'MX'),
              'g_fan[1].u_fan': (43.2, 129.6, 'R0'), 'g_fan[0].u_fan': (43.2, 259.2, 'R0'),
              'g_fan[3].u_fan': (518.4, 129.6, 'MY'), 'g_fan[2].u_fan': (518.4, 259.2, 'MY')}


def frames():
    return dict(
        qkd_seq_st=dict(plan=lambda cell, fw, fh: SEQ_S_PLAN[cell], straps=lambda inst: {}),
        qkd_rhead=dict(plan=_head_plan(), straps=lambda inst: dict(hid=int(inst.rsplit('_', 1)[1]))),
        qkd_rhead_ft=dict(plan=_head_plan(True), straps=lambda inst: dict(hid=int(inst.rsplit('_', 1)[1]))),
        qkd_ectl=dict(plan=_ectl_plan(),
                      straps=lambda inst: dict(cfg=(int(inst.split('_')[2]) << 2) | K.STACKS.index(inst.split('_')[1]))),
        qkd_ctrl=dict(plan=_ctrl_plan(True), straps=lambda inst: {}),
        qkd_ctrl_n=dict(plan=_ctrl_plan(False), straps=lambda inst: {}),
        qkd_pvfork=dict(plan=lambda cell, fw, fh: (4.32 + 25.92 * int(cell.split('u_r')[1]), 5.4, 'R0'), straps=lambda inst: {}),
        **{f'qkd_pvtap{g_}': dict(plan=lambda cell, fw, fh: (4.32 + 25.92 * int(cell.split('u_r')[1]), 5.4, 'R0'),
                                  straps=lambda inst: {}) for g_ in (2, 3, 4)},   # KVPLAN2 2215: chunk trunk taps
        qkd_pvw_s=dict(plan=_pvt_plan() if K.PV_T else _pv_plan(), straps=lambda inst: {}, open_inputs=PV_OPEN),
        qkd_pvw_n=dict(plan=_pvt_plan() if K.PV_T else _pv_plan(), straps=lambda inst: {}, open_inputs=PV_OPEN),
    )


# ---- LEF / RTL helpers --------------------------------------------------------------------------------------------------
def lef_macro(path):
    t = Path(path).read_text()
    m = re.search(r'^MACRO (\S+)\s*$', t, re.M)
    e = re.search(rf'^END {re.escape(m.group(1))}\s*$', t[m.end():], re.M)
    blk = t[m.start():m.end() + e.end()]
    sz = re.search(r'\bSIZE\s+([\d.]+)\s+BY\s+([\d.]+)', blk)
    ports = {}
    for pm in re.finditer(r'^  PIN (\S+)\s*$(.*?)^  END \1\s*$', blk, re.M | re.S):
        n = pm.group(1)
        if n in ('VDD', 'VSS'):
            continue
        d = re.search(r'DIRECTION\s+(\w+)', pm.group(2))
        bm = re.fullmatch(r'(.+)\[(\d+)\]', n)
        base, i = (bm.group(1), int(bm.group(2))) if bm else (n, None)
        r = ports.setdefault(base, dict(dir=(d.group(1).lower() if d else 'input'), bits=set()))
        r['bits'].add(i)
    return m.group(1), blk, (float(sz.group(1)), float(sz.group(2))), ports


def stub_text(mod, ports, params):
    L = [f'(* blackbox *) module {mod} #(' + ', '.join(f'parameter {p} = 0' for p in sorted(params)) + ') ('
         if params else f'(* blackbox *) module {mod} (']
    items = []
    for p, r in sorted(ports.items()):
        d = {'input': 'input', 'output': 'output', 'inout': 'inout'}.get(r['dir'], 'input')
        idx = [i for i in r['bits'] if i is not None]
        rng = f'[{max(idx)}:0] ' if idx else ''
        items.append(f'  {d} wire {rng}{p}')
    return '\n'.join(L) + '\n' + ',\n'.join(items) + '\n);\nendmodule\n'


def module_text(path, mod):
    t = Path(path).read_text()
    m = re.search(rf'^\s*module\s+{re.escape(mod)}\b', t, re.M)
    e = re.search(r'^\s*endmodule\b', t[m.end():], re.M)
    pre = '`timescale 1ns/1ps\n'
    body = t[m.start():m.end() + e.end()]
    # yosys 0.9 has no SV size casts: N'(expr) on a port connection -> (expr) (the port width truncates it the same way)
    body = re.sub(r"\b\d+'\(", '(', body)
    return pre + body + '\n'


def elaborate(mod, file, leaf, parameters=None):
    """yosys JSON of the parent module with every leaf module a black box.  v1.4.4: wires-only SUBLEVELS of the parent
    ((file, module) pairs) are read and flattened into it (cell names 'g_col[s].u_col.u_join'); parent parameters (BINDINGS
    'parameters') are set with chparam."""
    txt = module_text(ROOT / file, mod)
    subs = SUBLEVELS.get(mod, ())
    for sf, sm in subs:
        txt += module_text(ROOT / sf, sm).replace('`timescale 1ns/1ps\n', '')
    params = defaultdict(set)
    for cm in re.finditer(r'\b(\w+)\s*#\s*\((.*?)\)\s*(\w+)\s*\(', txt, re.S):
        if cm.group(1) in leaf:
            params[cm.group(1)] |= set(re.findall(r'\.(\w+)\s*\(', cm.group(2)))
    if subs:      # nested parameter lists '#(.A(x),.B(y))': the lazy match above stops at the first ')'
        for cm in re.finditer(r'\b(\w+)\s*#\s*\(((?:[^()]|\([^()]*\))*)\)\s*(\w+)\s*\(', txt, re.S):
            if cm.group(1) in leaf:
                params[cm.group(1)] |= set(re.findall(r'\.(\w+)\s*\(', cm.group(2)))
    chp = ''.join(f'chparam -set {k_} {int(v_)} {mod}\n' for k_, v_ in sorted((parameters or {}).items())) \
        if parameters else ''
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        (td / 'stubs.v').write_text('\n'.join(stub_text(m_, leaf[m_]['ports'], params[m_]) for m_ in leaf))
        (td / 'parent.sv').write_text(txt)
        (td / 'run.ys').write_text(f'read_verilog -sv {td}/stubs.v\nread_verilog -sv {td}/parent.sv\n{chp}'
                                   f'hierarchy -top {mod}\nproc\n' + ('flatten\ndelete t:$scopeinfo\nopt_expr\n' if subs else '') +
                                   f'opt_clean\nwrite_json {td}/out.json\n')
        r = subprocess.run(['yosys', '-q', '-s', str(td / 'run.ys')], capture_output=True, text=True)
        if r.returncode:
            raise RuntimeError(f'yosys {mod}: {r.stderr[-2000:]}')
        return json.loads((td / 'out.json').read_text())['modules'][mod]


def base_type(t):
    return t.split('\\')[1] if t.startswith('$paramod') else t.lstrip('\\')


# ---- die.v -------------------------------------------------------------------------------------------------------------
def parse_conns(body):
    return [(c.group(1).lstrip('\\').strip(), c.group(2).strip()) for c in
            re.finditer(r'\.(\\?\S+?)\((\{[^}]*\}|[^)]*)\)', body)]


def net_bits(expr, wires):
    """die net expression -> list of bit refs, LSB first"""
    parts = [x.strip() for x in expr.strip('{}').split(',') if x.strip()] if expr.startswith('{') else [expr]
    out = []
    for p in reversed(parts):           # concatenation lists MSB part first
        b = re.fullmatch(r'(\S+)\[(\d+)(?::(\d+))?\]', p)
        if b:
            hi = int(b.group(2))
            lo = int(b.group(3)) if b.group(3) else hi
            out += [f'{b.group(1)}[{i}]' for i in range(lo, hi + 1)]
        else:
            out += [f'{p}[{i}]' for i in range(wires.get(p, 1))]
    return out


def pack(bits):
    """bit refs (LSB first) -> a compact Verilog concatenation (MSB first), runs of one wire as slices"""
    runs = []
    for b in bits:
        m = re.fullmatch(r'(\S+)\[(\d+)\]', b)
        if m and runs and runs[-1][0] == m.group(1) and runs[-1][2] == int(m.group(2)) - 1:
            runs[-1][2] += 1
        elif m:
            runs.append([m.group(1), int(m.group(2)), int(m.group(2))])
        else:
            runs.append([b, None, None])
    parts = []
    for n, lo, hi in reversed(runs):
        parts.append(n if lo is None else (f'{n}[{lo}]' if lo == hi else f'{n}[{hi}:{lo}]'))
    return parts[0] if len(parts) == 1 else '{' + ', '.join(parts) + '}'


def die_to_rtl(master, die_ports, rtl_w):
    """die port -> RTL port bit names (LSB first) per BINDINGS, exactly the bind_views / kv_relays convention"""
    b = K.BINDINGS[master]
    sl = b.get('sliced', {})
    groups = defaultdict(list)
    for dp in die_ports:
        base = dp if dp in b['ports'] else sl.get(dp)
        if base is None:
            raise ValueError(f'{master}: die port {dp} has no binding')
        groups[base].append(dp)
    out = {}
    for base, dps in groups.items():
        seq = []
        for rp in b['ports'][base]:
            seq += [(rp, i) for i in range(rtl_w[rp])]
        order = sliced_order(base, dps)
        k = 0
        for d in order:
            n = die_ports[d]
            out[d] = seq[k:k + n]
            k += n
        if k != len(seq):
            raise ValueError(f'{master}: die ports {order} carry {k} bits, RTL {b["ports"][base]} {len(seq)}')
    return out


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--run', type=Path, required=True)
    ap.add_argument('--only', default='')
    ap.add_argument('--astk-static', action='store_true', help='expand only the actual RL3 static ASTK source, with native leaf views')
    ap.add_argument('--parameter-profiles', type=Path,
                    default=__import__('os').environ.get('OT_KV_PARAMETER_PROFILES'),
                    help='Exact selected child profiles (or OT_KV_PARAMETER_PROFILES)')
    ap.add_argument('--diagnostic-parameter-profiles', action='store_true', help='Source-only preservation; never native qualification',
                    default=__import__('os').environ.get('OT_KV_PARAM_DIAG', '0') == '1')
    a = ap.parse_args(argv)
    if __import__('os').environ.get('OT_KV_STATIC', '0') == '1' or (a.run / 'static_bind.json').exists():
        ap.error('static source graph cannot inherit legacy frame/leaf views; actual static physical bindings/clock homes remain required')
    K._set_geometry(True, reserve_native_astk=a.astk_static)
    case, libs = a.run / 'case_kv', a.run / 'libs'
    FR = frames()
    if a.astk_static:
        # HKV-DIE3 10-19 (production OT_KV_ASTK_EXPAND=1): the ASTK strips expand TOGETHER with the other frames
        import kv_astk_expand as ASTK
        FR = dict(FR, **ASTK.configure(K, VIEWS, RTL, SUBLEVELS, ALIAS))
        ASTK.require_views(ROOT)
    only = [x for x in a.only.split(',') if x] or list(FR)
    param_path = case / 'die.v.params.json'
    child_params = json.loads(param_path.read_text()) if param_path.exists() else {}
    profiles = json.loads(a.parameter_profiles.read_text()) if a.parameter_profiles else {}
    dv = (case / 'die.v').read_text()
    lines = dv.split('\n')
    wires = {}
    for ln in lines:
        m = re.match(r'\s*wire\s+\[(\d+):0\]\s+(\S+);', ln)
        if m:
            wires[m.group(2)] = int(m.group(1)) + 1
        else:
            m = re.match(r'\s*wire\s+(\S+);', ln)
            if m:
                wires[m.group(1)] = 1
    place = (case / 'place.tcl').read_text().split('\n')
    plc = {}
    for i, ln in enumerate(place):
        m = re.search(r'findInst (\S+)\]\s+([\d.]+)\s+([\d.]+)\s+(\w+)', ln)
        if m:
            plc[m.group(1)] = (i, float(m.group(2)), float(m.group(3)), m.group(4))
    elef = (case / 'elements.lef').read_text()
    fsize = {}
    for m in re.finditer(r'^MACRO (\S+)\s*$.*?\bSIZE\s+([\d.]+)\s+BY\s+([\d.]+)', elef, re.M | re.S):
        fsize[m.group(1)] = (float(m.group(2)), float(m.group(3)))
    standin = None
    if K.PV_T and __import__('os').environ.get('OT_KV_PV_T_CTL_STANDIN', '0') == '1' and \
            not (ROOT / VIEWS['ot_qwen_tp8_pv_wide_ctl_t'] / 'ot_qwen_tp8_pv_wide_ctl_t.lef').exists():
        # DIAGNOSTIC ONLY until the ctl_t kit closes: the trunked pair's control tile bound to the CLOSED a72 view of the
        # same tile (identical ports / outline / pins; ctl_t differs by the TRUNK_D / FLAG_D constants and an 8-b wage),
        # macro / cell renamed -- recorded in expand.json 'standin', never a release view
        src = ROOT / f"{RT}/{__import__('os').environ.get('OT_KV_PV_CTL_KIT', 'qkd_pv_ctl_rstpin_a72')}/views/ot_qwen_tp8_pv_wide_ctl"
        dst = (a.run / 'standin' / 'ot_qwen_tp8_pv_wide_ctl_t').resolve()
        dst.mkdir(parents=True, exist_ok=True)
        for f_ in src.iterdir():
            if f_.is_file():
                t_ = f_.read_text() if f_.suffix in ('.lef', '.lib', '.json') else None
                if t_ is None:
                    continue
                t_ = re.sub(r'\bot_qwen_tp8_pv_wide_ctl\b', 'ot_qwen_tp8_pv_wide_ctl_t', t_)
                (dst / f_.name.replace('ot_qwen_tp8_pv_wide_ctl', 'ot_qwen_tp8_pv_wide_ctl_t')).write_text(t_)
        VIEWS['ot_qwen_tp8_pv_wide_ctl_t'] = str(dst)
        standin = dict(module='ot_qwen_tp8_pv_wide_ctl_t', view=str(dst), from_view=str(src.relative_to(ROOT)),
                       status='DIAGNOSTIC_STANDIN: ctl_t kit qkd_pv_ctl_t_d54f58 not closed yet')
    leaf = {}
    for mod, vd in VIEWS.items():
        lef = ROOT / vd / f'{mod}.lef'
        if lef.exists():
            nm, blk, sz, ports = lef_macro(lef)
            for r in ports.values():
                r['w'] = 1 if r['bits'] == {None} else max(r['bits']) + 1
            leaf[nm] = dict(view=vd, lef=blk, size=sz, ports=ports)
    views = json.loads((libs / 'views.json').read_text())
    rep = dict(schema='opentallas.qwen_kvsys_expand.v1', frames={}, parameter_instances={},
               preexpand_die_sha256=EP.sha(case / 'die.v'))
    occupied = set(re.findall(r'^\s+\w+(?:\s*#\s*\((?:[^()]|\([^()]*\))*\))?\s+(\S+)\s*\(', dv, re.M))
    new_lines, add_wires, add_place, drop_inst, used_leaf = [], [], [], set(), set()
    inst_re = re.compile(r'^\s+(\w+) (\S+) \((.*)\);\s*$')
    jcache = {}
    for ln in lines:
        m = inst_re.match(ln)
        if not m or m.group(1) not in only or m.group(1) not in FR:
            new_lines.append(ln)
            continue
        mst, inst, body = m.groups()
        spec = FR[mst]
        b = K.BINDINGS[mst]
        if mst not in jcache:
            jcache[mst] = elaborate(b['module'], b['file'], leaf, b.get('parameters'))
        J = jcache[mst]
        if 'prepare' in spec:
            spec['plan'] = spec['prepare'](J, leaf, *fsize[mst])
        rtl_w = {p: len(v['bits']) for p, v in J['ports'].items()}
        conns = parse_conns(body)
        dpw = {p: len(net_bits(e, wires)) for p, e in conns}
        mp = die_to_rtl(mst, dpw, rtl_w)
        bitnet = {}                                       # yosys bit id -> die bit ref
        for p, e in conns:
            for (rp, i), nb_ in zip(mp[p], net_bits(e, wires)):
                bid = J['ports'][rp]['bits'][i]
                if isinstance(bid, str):
                    continue                              # parent port bit tied inside the parent: nothing to connect
                if bid in bitnet and bitnet[bid] != nb_:
                    raise ValueError(f'{inst}: parent bit {rp}[{i}] on two die nets {bitnet[bid]} / {nb_}')
                bitnet[bid] = nb_
        straps = spec['straps'](inst)
        strap_bits = {}
        for sp, val in straps.items():
            for i, bid in enumerate(J['ports'][sp]['bits']):
                if not isinstance(bid, str):
                    strap_bits[bid] = '1' if (val >> i) & 1 else '0'
        unbound_ports = sorted(p for p in J['ports'] if p not in {rp for v in mp.values() for rp, _ in v} and p not in straps)
        unbound_inputs = [p for p in unbound_ports if J['ports'][p]['direction'] == 'input']
        open_inputs = sorted(p for p in unbound_inputs if p in spec.get('open_inputs', {}))
        unbound_inputs = [p for p in unbound_inputs if p not in spec.get('open_inputs', {})]
        if unbound_inputs:
            raise ValueError(f'{inst}: functional parent inputs without die bindings {unbound_inputs}')
        # internal (leaf-to-leaf) wire names from the parent's netnames
        names = {}
        for nn, nv in sorted(J['netnames'].items(), key=lambda kv: (kv[1].get('hide_name', 0), len(kv[0]))):
            for i, bid in enumerate(nv['bits']):
                if not isinstance(bid, str) and bid not in names:
                    names[bid] = (nn, i, len(nv['bits']))
        iw = {}
        tie_values = {}

        def ref(bid, cell):
            if isinstance(bid, str) or bid in strap_bits:
                v = bid if isinstance(bid, str) else strap_bits[bid]
                if v not in ('0', '1'):
                    raise ValueError(f'{inst}/{cell}: undefined constant {v}')
                tn = f'n_{inst}__{re.sub(r"[^A-Za-z0-9_]", "_", cell)}__tie{v}'
                iw[tn] = 1
                tie_values[tn] = v
                return f'{tn}[0]'
            if bid in bitnet:
                return bitnet[bid]
            nn, i, w = names[bid]
            wn = f'n_{inst}__{re.sub(r"[^A-Za-z0-9_]", "_", nn.lstrip(chr(92)))}'
            iw[wn] = max(iw.get(wn, 0), w)
            return f'{wn}[{i}]'
        fx, fy, fo = plc[inst][1], plc[inst][2], plc[inst][3]
        fw, fh = fsize[mst]
        ff = FLIP[fo]
        nleaf, conn_bits, tie_bits = 0, 0, 0
        drivers = defaultdict(int)
        inputs = set()
        rectangles = []
        for cname, c in J['cells'].items():
            cell = cname.lstrip('\\')
            ct = base_type(c['type'])
            ct = ALIAS.get(ct, ct)            # HKV-DIE3: a child bound to its face-landed successor view (same ports)
            if ct not in leaf:
                raise ValueError(f'{mst}: child {cell} ({ct}) has no closed view (glue is not expanded)')
            used_leaf.add(ct)
            L = leaf[ct]
            cx, cy, co = spec['plan'](cell, fw, fh)
            w_, h_ = L['size']
            # Generated frame outlines shave 24 nm from the nominal contract.
            # Match bind_views' 50 nm outline tolerance while rejecting real spill.
            if min(cx, cy) < -0.001 or cx + w_ > fw + 0.05 or cy + h_ > fh + 0.05:
                raise ValueError(f'{inst}/{cell}: closed leaf outside contract frame')
            rect = (cell, cx, cy, cx + w_, cy + h_)
            for other in rectangles:
                if min(rect[3], other[3]) - max(rect[1], other[1]) > 0.001 and \
                   min(rect[4], other[4]) - max(rect[2], other[2]) > 0.001:
                    raise ValueError(f'{inst}: overlapping closed leaves {cell} / {other[0]}')
            rectangles.append(rect)
            px = fw - cx - w_ if ff[0] else cx
            py = fh - cy - h_ if ff[1] else cy
            cf = FLIP[co]
            orient = ORIENT[(ff[0] ^ cf[0], ff[1] ^ cf[1])]
            cinst = f'{inst}__{re.sub(r"[^A-Za-z0-9_]", "_", cell)}'
            if cinst in occupied or cinst in child_params:
                raise ValueError(f'{cinst}: duplicate instance or stale child parameters')
            occupied.add(cinst)
            literals, profile = EP.preserve(ROOT, base_type(c['type']), c.get('parameters', {}),
                                            RTL[ct], L['view'], profiles, a.diagnostic_parameter_profiles)
            if profile is not None:
                child_params[cinst] = literals
                rep['parameter_instances'][cinst] = dict(module=base_type(c['type']), literals=literals, profile=profile)
            pc = []
            for p, bits in c['connections'].items():
                if p not in L['ports']:
                    raise ValueError(f'{cinst}: RTL port {p} not a pin of view {ct}')
                if L['ports'][p]['w'] != len(bits):
                    raise ValueError(f'{cinst}: port {p} RTL {len(bits)} b vs view {L["ports"][p]["w"]} b')
                refs = [ref(bid, cell) for bid in bits]
                conn_bits += len(bits)
                tie_bits += sum('__tie' in r_ for r_ in refs)
                if L['ports'][p]['dir'] == 'input':
                    inputs.update(bid for bid in bits if not isinstance(bid, str))
                if L['ports'][p]['dir'] == 'output':
                    for bid in bits:
                        if not isinstance(bid, str):
                            drivers[bid] += 1
                pc.append(f'.{p}({pack(refs)})')
            miss = sorted(set(L['ports']) - set(c['connections']))
            if miss:
                raise ValueError(f'{cinst}: view pins without an RTL connection {miss[:6]}')
            new_lines.append(f'  {ct} {cinst} ({", ".join(pc)});')
            add_place.append(f'ot_mts::place [$_blk findInst {cinst}] {fx + px:.3f} {fy + py:.3f} {orient}')
            nleaf += 1
        multi = [bid for bid, n in drivers.items() if n > 1]
        if multi:
            raise ValueError(f'{inst}: {len(multi)} bits with several leaf drivers')
        available = set(drivers) | set(strap_bits) | {bid for p in J['ports'].values()
                    if p['direction'] == 'input' for bid in p['bits'] if not isinstance(bid, str)}
        undriven = sorted(inputs - available)
        if undriven:
            raise ValueError(f'{inst}: {len(undriven)} undriven child-input bits {undriven[:8]}')
        for wn, w in iw.items():
            add_wires.append(f'  wire [{w - 1}:0] {wn};')
            if wn in tie_values:
                add_wires.append(f"  assign {wn} = 1'b{tie_values[wn]};")
        drop_inst.add(inst)
        fr = rep['frames'].setdefault(mst, dict(module=b['module'], instances=0, leaves_per_instance=nleaf,
                                                 internal_wires_per_instance=len(iw), straps=sorted(straps),
                                                 rtl_ports_without_die_port=unbound_ports, leaf_pin_bits=conn_bits,
                                                 tie_pin_bits=tie_bits,
                                                 open_parent_inputs={p: spec['open_inputs'][p] for p in open_inputs},
                                                 connectivity_checks=dict(undriven_inputs=0, multiple_drivers=0,
                                                 unbound_parent_inputs=0, overlaps=0, outside_slot=0)))
        fr['instances'] += 1
    if not drop_inst:
        print('nothing expanded')
        return 1
    # die.v: wires after the module header's existing wires
    k = max(i for i, ln in enumerate(new_lines) if re.match(r'\s*wire\b', ln))
    new_lines[k + 1:k + 1] = add_wires
    for f in ('die.v', 'place.tcl', 'elements.lef'):
        if not (case / f'{f}.preexp').exists():
            shutil.copy(case / f, case / f'{f}.preexp')
    # All validation precedes mutation, including stale parent-sidecar entries.
    for inst in drop_inst:
        child_params.pop(inst, None)
    (case / 'die.v').write_text('\n'.join(new_lines))
    param_path.write_text(json.dumps(child_params, indent=1) + '\n')
    keep = [ln for i, ln in enumerate(place) if not any(i == plc[x][0] for x in drop_inst)]
    j = max(i for i, ln in enumerate(keep) if 'ot_mts::place' in ln)
    keep[j + 1:j + 1] = add_place
    (case / 'place.tcl').write_text('\n'.join(keep))
    # LEF: add each leaf view MACRO once (exact text)
    add_lef = [leaf[m_]['lef'] for m_ in sorted(used_leaf) if not re.search(rf'^MACRO {m_}\s*$', elef, re.M)]
    t = elef.rstrip()
    end = re.search(r'^END LIBRARY\s*$', t, re.M)
    t = (t[:end.start()] + '\n'.join(add_lef) + '\n' + t[end.start():]) if end else t + '\n' + '\n'.join(add_lef) + '\n'
    (case / 'elements.lef').write_text(t + '\n')
    # libs + views
    for m_ in sorted(used_leaf):
        vd = ROOT / leaf[m_]['view']
        for c in CORNERS:
            src = vd / f'{m_}_{c}.lib'
            if not src.exists():
                if c == 'ss':
                    continue
                raise FileNotFoundError(src)
            txt = src.read_text()
            txt = re.sub(r'library\s*\(\s*"?[^")]+"?\s*\)', f'library (qfd_etm_{m_}_{c})', txt, count=1)
            (libs / f'qfd_etm_{m_}_{c}.lib').write_text(txt)
        views['views'][m_] = dict(bound=True, view=leaf[m_]['view'], module=m_, real_um=list(leaf[m_]['size']),
                                  expanded_from=sorted({f for f, r in rep['frames'].items()}), cls='die_placed_leaf')
    views.setdefault('expanded', {}).update({f: r['module'] for f, r in rep['frames'].items()})
    (libs / 'views.json').write_text(json.dumps(views, indent=1) + '\n')
    rep['leaves'] = {m_: dict(view=leaf[m_]['view'], rtl=RTL[m_]) for m_ in sorted(used_leaf)}
    if a.astk_static:
        rep['source_sha256'] = ASTK.provenance(ROOT)
        rep['profile'] = dict(RL=3, Z_STRIDE=4, measured_Z_start_age=1016, fault_join_edges=1)
    if standin:
        rep['standin'] = standin
    rep['instances_removed'] = len(drop_inst)
    rep['instances_added'] = len(add_place)
    (a.run / 'expand.json').write_text(json.dumps(rep, indent=1) + '\n')
    print(json.dumps(dict(removed=len(drop_inst), added=len(add_place), wires=len(add_wires),
                          frames={k_: (v['instances'], v['leaves_per_instance'], v['tie_pin_bits']) for k_, v in rep['frames'].items()})))
    return 0


if __name__ == '__main__':
    sys.exit(main())
