import sys, subprocess; sys.path.insert(0,'tools')
import rtl_chip_v41x_die_smoke as ds, rtl_hdc_v41x_vec_campaign as C
from pathlib import Path
R=Path('.').resolve(); ds.setup("dpi"); core=ds.core
dist=[str(R/f"rtl/chip/{n}.sv") for n in ("ot_v41_vm_dist_bank","ot_v41_vm_dist_group","ot_v41_vm_dist","ot_v41_vm_dist_pipe")]
W=["-Wno-fatal","-Wno-WIDTH","-Wno-UNUSED","-Wno-BLKSEQ","-Wno-IMPORTSTAR","-Wno-MODDUP","-Wno-TIMESCALEMOD","-Wno-VARHIDDEN","-Wno-UNOPTFLAT","-Wno-MULTIDRIVEN"]
def run(tag, cmd):
    r=subprocess.run(cmd,capture_output=True,text=True); e=[l for l in (r.stdout+r.stderr).splitlines() if '%Error' in l]
    print(tag, r.returncode, len(e), "\n".join(e[:4]), flush=True)
die=[str(p) for p in ds.sources("dpi", build=True)]
run("die smoke default", [ds.VERILATOR,"--lint-only",*W,"--top-module","tb_chip_v41x_die_smoke",f"-I{core.SVH.parent}",str(core.VLT),*die,"rtl/test/tb_chip_v41x_die_smoke.sv"])
run("die vmdist H", [ds.VERILATOR,"--lint-only",*W,"-DOT_VM_DIST","--top-module","tb_chip_v41x_die_vmdist","-GVM_DIST=1","-GVM_DIST_H=1",f"-I{core.SVH.parent}",str(core.VLT),*die,*dist,"rtl/test/tb_chip_v41x_die_vmdist.sv"])
C.write_fields_svh()
run("vec default", [C.VERILATOR,"--lint-only",*W,"--top-module","tb_hdc_v41x_vec","-GN=16","-GM=8",f"-I{R/'rtl/test'}",*map(str,C.LIB),*map(str,C.RTL),str(C.TB)])
run("vec H", [C.VERILATOR,"--lint-only",*W,"-DOT_VM_DIST","--top-module","tb_hdc_v41x_vec","-GN=16","-GM=8","-GVM_DIST=1","-GVM_DIST_H=1",f"-I{R/'rtl/test'}",*map(str,C.LIB),*map(str,C.RTL),*dist,str(C.TB)])
