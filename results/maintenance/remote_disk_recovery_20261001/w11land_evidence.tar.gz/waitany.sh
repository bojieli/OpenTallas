#!/bin/bash
# returns when any watched job changes to finished
s0=$(for n in vec; do grep -c "finished rc" /tmp/claude-1000/w11land/$n.gate.log; done; grep -c "^wrote\|Traceback" /tmp/claude-1000/w11land/su.local.log; for f in su_rot_lps7_m5u12 su_grp_r1_m5 su_grp_k4q16_r1 wc_grp_k4q16_r0 wc_grp_k4q16_r1; do grep -c "finished rc" /tmp/claude-1000/w11vm/hard/$f.gate.log; done)
while true; do
  s=$(for n in vec; do grep -c "finished rc" /tmp/claude-1000/w11land/$n.gate.log; done; grep -c "^wrote\|Traceback" /tmp/claude-1000/w11land/su.local.log; for f in su_rot_lps7_m5u12 su_grp_r1_m5 su_grp_k4q16_r1 wc_grp_k4q16_r0 wc_grp_k4q16_r1; do grep -c "finished rc" /tmp/claude-1000/w11vm/hard/$f.gate.log; done)
  [ "$s" != "$s0" ] && break
  sleep 60
done
for n in vec; do echo "$n: $(tail -n1 /tmp/claude-1000/w11land/$n.gate.log | cut -c1-100)"; done
echo "su: $(tail -n1 /tmp/claude-1000/w11land/su.local.log | cut -c1-100)"
for f in su_rot_lps7_m5u12 su_grp_r1_m5 su_grp_k4q16_r1 wc_grp_k4q16_r0 wc_grp_k4q16_r1; do echo "$f: $(tail -n1 /tmp/claude-1000/w11vm/hard/$f.gate.log | cut -c1-80)"; done
