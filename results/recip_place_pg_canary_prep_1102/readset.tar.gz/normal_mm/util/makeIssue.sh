#!/usr/bin/env bash

set -euo pipefail
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

ISSUE_TARGET=$(basename $1)
ISSUE_DEST=$(dirname $1)

echo "Creating issue for target ${ISSUE_TARGET} in ${ISSUE_DEST}"

currentDate=$(date +"%Y-%m-%d_%H-%M")
ISSUE_TAG=${ISSUE_TAG:-"${DESIGN_NICKNAME}_${PLATFORM}_${FLOW_VARIANT}_${currentDate}"}
ISSUE_CP_DESIGN_FILE_VARS="SDC_FILE \
                           VERILOG_FILES \
                           SYNTH_NETLIST_FILES \
                           FOOTPRINT_TCL \
                           FOOTPRINT \
                           SIG_MAP_FILE \
                           IO_CONSTRAINTS \
                           MACRO_PLACEMENT_TCL \
                           MACRO_WRAPPERS \
                           RTLMP_CONFIG_FILE \
                           DFF_LIB_FILE "
ISSUE_CP_PLATFORM_FILE_VARS="LIB_FILES \
                             SC_LEF \
                             TECH_LEF \
                             ADDITIONAL_FILES \
                             ADDITIONAL_LEFS \
                             CLKGATE_MAP_FILE \
                             ADDER_MAP_FILE \
                             LATCH_MAP_FILE \
                             CDL_FILE \
                             MAKE_TRACKS \
                             POST_FLOORPLAN_TCL \
                             TAPCELL_TCL \
                             PDN_CFG \
                             PDN_TCL \
                             POST_PDN_TCL \
                             POST_CTS_TCL \
                             PRE_GLOBAL_ROUTE_TCL \
                             FASTROUTE_TCL \
                             POST_DETAIL_ROUTE_TCL \
                             RCX_RULES \
                             FILL_CONFIG "
ISSUE_CP_FILE_VARS=$ISSUE_CP_DESIGN_FILE_VARS

ISSUE_CP_FILES_PLATFORM=""
if [[ ! -v EXCLUDE_PLATFORM ]]; then
    ISSUE_CP_FILE_VARS+=$ISSUE_CP_PLATFORM_FILE_VARS
    ISSUE_CP_FILES_PLATFORM="$PLATFORM_DIR/*.tcl"
    if ls $PLATFORM_DIR/*.sdc 1> /dev/null 2>&1; then
        ISSUE_CP_FILES_PLATFORM="$ISSUE_CP_FILES_PLATFORM $PLATFORM_DIR/*.sdc"
    fi
    if ls $PLATFORM_DIR/*.cfg 1> /dev/null 2>&1; then
        ISSUE_CP_FILES_PLATFORM="$ISSUE_CP_FILES_PLATFORM $PLATFORM_DIR/*.cfg"
    fi
fi

VARS_BASENAME=${WORK_HOME}/vars-$DESIGN_NICKNAME-$PLATFORM-$FLOW_VARIANT
RUN_ME_SCRIPT=${WORK_HOME}/run-me-$DESIGN_NICKNAME-$PLATFORM-$FLOW_VARIANT.sh

for i in $ISSUE_CP_FILE_VARS ; do
    if [ -v ${i} ]; then
        filename=$i
        ISSUE_CP_FILES+="${!filename} "
    fi
done

ISSUE_CP_FILES+="${ISSUE_CP_FILES_PLATFORM} \
    $UTILS_DIR/def2stream.py \
    ${RUN_ME_SCRIPT} \
    $VARS_BASENAME.sh \
    $VARS_BASENAME.tcl \
    $VARS_BASENAME.gdb"

ISSUE_SCRIPT=${SCRIPTS_DIR}/${ISSUE_TARGET}.tcl
if grep -q -E "synth_preamble|yosys -import" "${ISSUE_SCRIPT}"; then
    IS_YOSYS=1
else
    IS_YOSYS=0
fi

# Source the vars file relative to the run-me script itself, so the
# reproducible works out of the box wherever the tarball is extracted
# (WORK_HOME is an absolute CI path that does not exist elsewhere).
if [ "$IS_YOSYS" -eq 1 ]; then
cat > ${RUN_ME_SCRIPT} <<EOF
#!/usr/bin/env bash
cd "\$(dirname "\$0")"
source ./$(basename ${VARS_BASENAME}).sh
export PYTHON_EXE=\${PYTHON_EXE:-\$(command -v python3)}
yosys ${YOSYS_FLAGS:-} -c \${SCRIPTS_DIR}/${ISSUE_TARGET}.tcl
EOF
else
cat > ${RUN_ME_SCRIPT} <<EOF
#!/usr/bin/env bash
cd "\$(dirname "\$0")"
source ./$(basename ${VARS_BASENAME}).sh
if [[ ! -z \${GDB+x} ]]; then
    gdb --args openroad -no_init -threads ${NUM_CORES:-1} \${SCRIPTS_DIR}/${ISSUE_TARGET}.tcl
else
    openroad -no_init -threads ${NUM_CORES:-1} \${SCRIPTS_DIR}/${ISSUE_TARGET}.tcl
fi
EOF
fi
chmod +x ${RUN_ME_SCRIPT}

rm -f ${VARS_BASENAME}.sh ${VARS_BASENAME}.tcl ${VARS_BASENAME}.gdb || true

$DIR/generate-vars.sh ${VARS_BASENAME}

TAR_NAME=${ISSUE_DEST}/${ISSUE_TARGET}_${ISSUE_TAG}.tar.gz
echo "Archiving issue to ${TAR_NAME}"
# if pigz is installed, use it instead of gzip
if command -v pigz &> /dev/null; then
    COMPRESS=pigz
else
    COMPRESS=gzip
fi

echo "Using $COMPRESS to compress tar file"

# Save all files inside design and platform folders
if [ -v FULL_ISSUE ]; then
    DESIGN_PLATFORM_FILES="$DESIGN_DIR $PLATFORM_DIR"
else
    DESIGN_PLATFORM_FILES="$DESIGN_CONFIG $PLATFORM_DIR/config*.mk"
fi

# Strip the WORK_HOME prefix as well, so files generated outside FLOW_HOME
# (vars, run-me, logs, ... when WORK_HOME points at a CI workspace) land at
# the tarball root instead of recreating the absolute path (e.g. tmp/...).
# Both the literal and the symlink-resolved form may appear in member names.
WORK_ROOT=$(realpath "${WORK_HOME:-.}")
WORK_HOME_TRANSFORMS=(--transform="s|^${ISSUE_TARGET}_${ISSUE_TAG}${WORK_ROOT}//*|${ISSUE_TARGET}_${ISSUE_TAG}/|S")
if [[ "${WORK_HOME:-.}" == /* && "${WORK_HOME%/}" != "${WORK_ROOT}" ]]; then
    WORK_HOME_TRANSFORMS+=(--transform="s|^${ISSUE_TARGET}_${ISSUE_TAG}${WORK_HOME%/}//*|${ISSUE_TARGET}_${ISSUE_TAG}/|S")
fi
tar --use-compress-program=${COMPRESS} \
    --ignore-failed-read -chf ${TAR_NAME} \
    --transform="s|^|${ISSUE_TARGET}_${ISSUE_TAG}/|S" \
    --transform="s|^${ISSUE_TARGET}_${ISSUE_TAG}${FLOW_HOME}/|${ISSUE_TARGET}_${ISSUE_TAG}/|S" \
    "${WORK_HOME_TRANSFORMS[@]}" \
    $DESIGN_PLATFORM_FILES \
    $LOG_DIR \
    $OBJECTS_DIR \
    $REPORTS_DIR \
    $RESULTS_DIR \
    $SCRIPTS_DIR \
    $(for f in $ISSUE_CP_FILES; do echo $f; done | sort | uniq)

if [ -v EXCLUDE_PLATFORM ]; then
    # Remove liberty and lef files from tar file
    gunzip -f ${TAR_NAME}
    tar --list --file ${ISSUE_TARGET}_${ISSUE_TAG}.tar | grep -iE "*.(lib|lef|tlef)$" | xargs -r tar --delete --file ${ISSUE_TARGET}_${ISSUE_TAG}.tar
    gzip ${ISSUE_TARGET}_${ISSUE_TAG}.tar
fi

if [ ! -z ${COPY_ISSUE+x} ]; then
    mkdir -p ${COPY_ISSUE} ;
    cp ${TAR_NAME} ${COPY_ISSUE} ;
fi
