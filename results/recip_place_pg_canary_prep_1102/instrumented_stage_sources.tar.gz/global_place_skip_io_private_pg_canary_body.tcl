source $::env(SCRIPTS_DIR)/load.tcl
erase_non_stage_variables place
load_design 2_floorplan.odb 2_floorplan.sdc
ot_pg_place_canary_begin global_place_skip_io
source_step_tcl PRE GLOBAL_PLACE_SKIP_IO
ot_pg_place_canary_after_pre global_place_skip_io

if { [env_var_exists_and_non_empty FLOORPLAN_DEF] } {
  puts "FLOORPLAN_DEF is set. Skipping global placement without IOs"
} elseif { [all_pins_placed] } {
  puts "All pins are placed. Skipping global placement without IOs"
} else {
  set global_placement_args {}
  append_env_var global_placement_args GPL_RANDOM_SEED -random_seed 1

  log_cmd global_placement -skip_io -density [place_density_with_lb_addon] \
    -pad_left $::env(CELL_PAD_IN_SITES_GLOBAL_PLACEMENT) \
    -pad_right $::env(CELL_PAD_IN_SITES_GLOBAL_PLACEMENT) \
    {*}[env_var_or_empty GLOBAL_PLACEMENT_ARGS] \
    {*}$global_placement_args
}

source_step_tcl POST GLOBAL_PLACE_SKIP_IO
ot_pg_place_canary_finish global_place_skip_io
set ::ot_pg_place_canary_reached_stage {3_1_place_gp_skip_io}

report_design_area

orfs_write_db $::env(RESULTS_DIR)/3_1_place_gp_skip_io.odb
