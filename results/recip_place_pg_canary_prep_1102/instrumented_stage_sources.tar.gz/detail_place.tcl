# PRIVATE diagnostic only; normal flags/source/body retained, no strict admission change.
source /work/pg_place_canary.tcl
unset -nocomplain ::ot_pg_place_canary_reached_stage
set ot_pg_place_canary_body_code [catch {source [file join $::env(SCRIPTS_DIR) detail_place_private_pg_canary_body.tcl]} ot_pg_place_canary_body_result ot_pg_place_canary_body_options]
set ot_pg_place_canary_cleanup_code [catch {ot_pg_place_canary_finish detail_place} ot_pg_place_canary_cleanup_result ot_pg_place_canary_cleanup_options]
if {$ot_pg_place_canary_body_code == 1} {
  if {$ot_pg_place_canary_cleanup_code} {puts stderr "OT_PG_CANARY_CLEANUP_REFUSED $ot_pg_place_canary_cleanup_result"}
  return -options $ot_pg_place_canary_body_options $ot_pg_place_canary_body_result
}
if {$ot_pg_place_canary_cleanup_code == 1} {return -options $ot_pg_place_canary_cleanup_options $ot_pg_place_canary_cleanup_result}
if {$ot_pg_place_canary_cleanup_code != 0} {error "OT_PG_CANARY_NONLOCAL_CLEANUP_REFUSED code=$ot_pg_place_canary_cleanup_code result=$ot_pg_place_canary_cleanup_result"}
if {$ot_pg_place_canary_body_code != 0} {error "OT_PG_CANARY_NONLOCAL_BODY_REFUSED code=$ot_pg_place_canary_body_code result=$ot_pg_place_canary_body_result"}
if {![info exists ::ot_pg_place_canary_reached_stage] || $::ot_pg_place_canary_reached_stage ne {3_5_place_dp}} {error OT_PG_CANARY_STAGE_POST_NOT_REACHED}
