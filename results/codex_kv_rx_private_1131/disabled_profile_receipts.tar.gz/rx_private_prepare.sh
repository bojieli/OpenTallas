#!/bin/bash
set -euo pipefail
source /OpenROAD-flow-scripts/env.sh >/dev/null 2>&1
cd /work
python3 rx_private_prepare.py > prepare.log
 yosys -Q -T -p 'read_json cone.json; opt_expr; write_json folded.json' > fold.log 2>&1
python3 hr_state_outputs_public.py finish folded.json gate.json manifest.json > finish.log
python3 hr_state_outputs_public.py finish folded.json mutant.json manifest.json --mutant > finish_mut.log
# These are native soft-memory flops; this lowering is also used by both sides of the full equivalence harness.
yosys -Q -T -p 'read_json gate.json; memory_share; memory_map; write_verilog -norename qkd_hr_core_rx.v' > emit_materialized.log 2>&1
