#!/bin/bash
set -euo pipefail
cd /srv/opentallas-scratch2/claude/codex-kv-residuals-1101/rx_private_keepdc1131
export PATH=$HOME/.local/opentallas-tools/bin:$PATH
cp /srv/opentallas-scratch2/claude/codex-kv-norecipe-1101/jobs/qkd_hr_core_rx/fp/qkd_hr_core_rx/pre.json native.json
for v in gate mutant emitted; do
 if [ "$v" = emitted ]; then READ='read_verilog qkd_hr_core_rx.v; hierarchy -top qkd_hr_core_rx; proc; flatten; memory_collect'; else READ="read_json $v.json"; fi
 cat > "$v.ys" <<YS
read_json native.json
memory_share
memory_map
rename qkd_hr_core_rx gold
design -stash g
$READ
memory_share
memory_map
rename qkd_hr_core_rx gate
design -copy-from g -as gold gold
equiv_make gold gate eq
hierarchy -top eq
expose -evert eq/t:ot_sram*
async2sync
equiv_simple -seq 2
equiv_induct -seq 2
equiv_status -assert
YS
 set +e
 yosys -Q -T "$v.ys" > "$v.log" 2>&1
 rc=$?
 set -e
 printf '%s\n' "$rc" > "rc_$v"
 if [ "$v" = mutant ]; then test "$rc" = 1; else test "$rc" = 0; fi
done
printf 'post rc=0\nmut rc=1\nemitted_v rc=0\n' > eq_rc.txt
printf 'RX PRIVATE KEEPDC native post0/mutant1/emitted0; mapped/physical still held\n'
