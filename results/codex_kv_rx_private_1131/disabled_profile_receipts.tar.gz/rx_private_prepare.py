from pathlib import Path
import json,hashlib
import hr_face_ports_public as h
import hr_state_outputs_public as s
root=Path('/work');native=Path('/native/pre.json');top='qkd_hr_core_rx'
data=json.loads(native.read_text())
data,rep=h.transform(data,top,all_private_out=True,preserve_port_shape=False)
(root/'all_private.json').write_text(json.dumps(data));(root/'all_private_report.json').write_text(json.dumps(rep,indent=1)+'\n')
cone,manifest=s.stage(data,top,['deferred[0]','fault[0]'])
(root/'cone.json').write_text(json.dumps(cone));(root/'manifest.json').write_text(json.dumps(manifest,indent=1)+'\n')
(root/'PROFILE_HOLD.json').write_text(json.dumps(dict(enabled=False,native_pre_sha256=hashlib.sha256(native.read_bytes()).hexdigest(),mechanisms=['public8d all_private_out: exact same D/clock/reset/init; never Q-to-D extra cycle','existing SYNTH_KEEPDC opt_dff/wreduce only','same two validated pure-state output recuts'],all_private_out=True,preserve_port_shape=False,cycles_added=0,proof='PENDING complete native/post/mutant/emitted proof; no borrowed receipts',mapped='PENDING targeted profile review; no synth launched',physical='FORBIDDEN until normal proof/geometry/review gates',emission='materialize intended soft flop memories with existing Yosys memory_share/memory_map, no hardmacro present'),indent=1)+'\n')
print('all_private addedFF',rep['added_ff_bits'],'ORrecut2; zero cycles; native/proof/mapped/physical held')
