import json,pathlib,copy,math,collections
r=pathlib.Path(__file__).parent;k=r/"kits/qkd_hr_core_rx__259.2x259.2";src=json.load(open(k/"pins.json"));p=copy.deepcopy(src);w=198.72;offset=30.24
for face,pitch in (("N",.144),("W",.336),("S",.336)):
 axis="x" if face in "NS" else "y"; rows=sorted((v for v in p if v["face"]==face),key=lambda v:v[axis]);span=(len(rows)-1)*pitch;start=round((((w-span)/2)-.024)/.048)*.048+.024
 for i,v in enumerate(rows):v[axis]=round(start+i*pitch,6);v["y" if face in "NS" else "x"]=w if face=="N" else 0
for v in p:
 if v["face"]=="E":v["x"]=w;v["y"]=round(v["y"]-offset,6)
 if v["face"]=="interior":v["x"]=round(v["x"]-offset,6);v["y"]=round(v["y"]-offset,6)
assert {(v["bus"],v["bit"],v["layer"],v["face"]) for v in p}=={(v["bus"],v["bit"],v["layer"],v["face"]) for v in src}
assert all(0<=v["x"]<=w and 0<=v["y"]<=w for v in p)
checks={}
for face in "NWSE":
 axis="x" if face in "NS" else "y";v=sorted((v for v in p if v["face"]==face),key=lambda v:v[axis]);coords=[x[axis] for x in v];assert all(abs(((x-.024)/.048)-round((x-.024)/.048))<1e-7 for x in coords);checks[face]=dict(count=len(v),span_um=round(coords[-1]-coords[0],6),minimum_center_pitch_um=min((round(b-a,6) for a,b in zip(coords,coords[1:])),default=None),edge_pin_tangent_width_um=.024)
for a,b in zip(src,p):
 if a["face"]=="interior":assert abs(a["x"]-(b["x"]+offset))<1e-7 and abs(a["y"]-(b["y"]+offset))<1e-7
(r/"compact198_DISABLED_pins.json").write_text(json.dumps(p,indent=1));j=dict(enabled=False,status="PIN_CAPACITY_PREP_ONLY_NOT_PHYSICAL_PASS",die_um=[w,w],centered_bbox_parent_offset_delta_um=[offset,offset],logical_abi="same2137bus-bit-layer-face identities and ordering",interior_clock_reset="global exact positions unchanged after centered parent offset",stdcell_area_um2=8446.75,ordinary_die_free_fill_percent=8446.75/w**2*100,gate_basis="geom_rules.area_metrics D.die minus macros, NOT core",emptybins="UNKNOWN actual placement required",faces=checks,holds=["root plan event approval","actual boundary/clock source review","placed emptybins<=50 and ordinaryfill>=20","normal LOOK/timing/proof gates"]);(r/"compact198_DISABLED_model.json").write_text(json.dumps(j,indent=1));print(json.dumps(j,indent=1))
