read_liberty /OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_SEQ_RVT_TT_nldm_220123.lib
read_liberty /OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_SIMPLE_RVT_TT_nldm_211120.lib.gz
read_verilog /work/toy.v
link_design toy
create_clock -name ck -period 833 [get_ports clk]
set_input_delay -clock ck 0 [get_ports {strap_id dynamic active}]
set_output_delay -clock ck 0 [all_outputs]

puts {SO_PATH_BEGIN CHECK_SETUP}
check_setup -verbose -unconstrained_endpoints -no_clock -loops -generated_clocks -multiple_clock
puts {SO_PATH_END CHECK_SETUP}
exit
