module toy(input clk,input strap_id,input dynamic,input active,output qs,output qm,output qa);
wire mixed;
AND2x2_ASAP7_75t_R g_mix(.A(strap_id),.B(dynamic),.Y(mixed));
DFFHQNx1_ASAP7_75t_R u_static(.D(strap_id),.CLK(clk),.QN(qs));
DFFHQNx1_ASAP7_75t_R u_mixed(.D(mixed),.CLK(clk),.QN(qm));
DFFHQNx1_ASAP7_75t_R u_active(.D(active),.CLK(clk),.QN(qa));
endmodule
