#!/bin/bash
set -e
for c in pure active_unconstrained no_declared no_sdc_falsepath; do
 /OpenROAD-flow-scripts/tools/install/OpenROAD/bin/sta -exit /work/$c/run.tcl > /work/$c/run.log 2>&1
done
