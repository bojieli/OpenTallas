def declared_static_straps(kit, sdc):
    """Only R7-declared straps with the generator's explicit source false-path.

    No wildcard or arbitrary false-path is a strap declaration.  Missing or
    unrecognized constraint syntax retains ordinary coverage gating.
    """
    if not kit:
        return []
    import face_guard
    declared = set(face_guard.kit_strap_list(kit))
    constrained = set()
    for line in sdc.splitlines():
        m = re.fullmatch(r"\s*set_false_path\s+-from\s+\[get_ports\s+\{([^{}]+)\}\]\s*", line)
        if m:
            constrained.update(m.group(1).split())
    return sorted(declared & constrained)

def static_strap_tcl(straps):
    """Observe register data pins fed exclusively by declared static straps.

    The timing network and constraints are unchanged.  Names are emitted only
    after a complete successful structural walk; Python intersects them with
    the actual verbose unconstrained endpoint list.
    """
    if not straps:
        return ""
    import face_guard
    names = " ".join(face_guard.strap_list(straps))
    return r'''# OWNER R7: quasi-static ID/count straps, false-pathed at the parent boundary.
if {[catch {
  set so_ss_roots [dict create]
  foreach so_ss_root {@NAMES@} { dict set so_ss_roots $so_ss_root 1 }
  set so_ss_ports [dict create]
  set so_ss_sources {}
  foreach so_ss_p [all_inputs] {
    set so_ss_name [get_full_name $so_ss_p]
    set so_ss_root $so_ss_name
    regexp {^(.+)\[[0-9]+\]$} $so_ss_name -> so_ss_root
    if {[dict exists $so_ss_roots $so_ss_root]} {
      dict set so_ss_ports $so_ss_name 1
      lappend so_ss_sources $so_ss_p
    }
  }
  set so_ss_data [dict create]
  foreach so_ss_p [all_registers -data_pins] {
    dict set so_ss_data [get_full_name $so_ss_p] 1
  }
  set so_ss_proven [dict create]
  if {[llength $so_ss_sources]} {
    foreach so_ss_p [get_fanout -from $so_ss_sources -flat -endpoints_only -trace_arcs all] {
      set so_ss_name [get_full_name $so_ss_p]
      if {![dict exists $so_ss_data $so_ss_name]} { continue }
      set so_ss_start [get_fanin -to $so_ss_p -flat -startpoints_only -trace_arcs all]
      set so_ss_ok [expr {[llength $so_ss_start] > 0}]
      foreach so_ss_s $so_ss_start {
        if {![dict exists $so_ss_ports [get_full_name $so_ss_s]]} { set so_ss_ok 0; break }
      }
      if {$so_ss_ok} { dict set so_ss_proven $so_ss_name 1 }
    }
  }
} so_ss_error]} {
  puts "SO STATIC_STRAP_ERROR $so_ss_error"
} else {
  foreach so_ss_name [lsort [dict keys $so_ss_proven]] {
    puts "SO_STATIC_STRAP_ENDPOINT $so_ss_name"
  }
}
'''.replace("@NAMES@", names)

def check_setup_counts(text, ft_out=(), static_strap_endpoints=()):
    """counts from check_setup output.  ft_out: declared 12.2a1 die-timed ft outputs -- listed (verbose) unconstrained
    endpoints among them are counted as ft_die_timed, not as unconstrained core IO."""
    c = dict(unconstrained=0, unclocked=0, loops=0, multiple_clock=0, generated=0)
    lines = text.splitlines()
    for i, ln in enumerate(lines):
        m = re.search(r"There (?:are|is) (\d+) unconstrained endpoints?", ln)
        if m:
            c["unconstrained"] = int(m.group(1))
            if ft_out or static_strap_endpoints:
                listed = []
                for x in lines[i + 1:]:
                    if not x.startswith((" ", "\t")) or not x.strip():
                        break
                    listed.append(x.strip())
                ft = sorted(set(listed) & set(ft_out))
                c["unconstrained"] -= len(ft)
                c["ft_die_timed"] = len(ft)
                static = sorted((set(listed) & set(static_strap_endpoints)) - set(ft))
                c["unconstrained"] -= len(static)
                if static:
                    c["static_strap_endpoints"] = len(static)
        m = re.search(r"There (?:are|is) (\d+) register/latch pins? with no clock", ln)
        if m:
            c["unclocked"] = int(m.group(1))
        m = re.search(r"There (?:are|is) (\d+) combinational loops?", ln)
        if m:
            c["loops"] = int(m.group(1))
        m = re.search(r"There (?:are|is) (\d+) pins? with multiple clocks", ln)
        if m:
            c["multiple_clock"] = int(m.group(1))
        m = re.search(r"There (?:are|is) (\d+) generated clocks? that (?:are|is) not connected", ln)
        if m:
            c["generated"] = int(m.group(1))
    return c
