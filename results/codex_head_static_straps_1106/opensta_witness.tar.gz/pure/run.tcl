read_liberty /OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_SEQ_RVT_TT_nldm_220123.lib
read_liberty /OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_SIMPLE_RVT_TT_nldm_211120.lib.gz
read_verilog /work/toy.v
link_design toy
create_clock -name ck -period 833 [get_ports clk]
set_input_delay -clock ck 0 [get_ports {strap_id dynamic active}]
set_output_delay -clock ck 0 [all_outputs]
set_false_path -from [get_ports {strap_id}]
# OWNER R7: quasi-static ID/count straps, false-pathed at the parent boundary.
if {[catch {
  set so_ss_roots [dict create]
  foreach so_ss_root {strap_id} { dict set so_ss_roots $so_ss_root 1 }
  set so_ss_ports [dict create]
  set so_ss_sources {}
  foreach so_ss_p [all_inputs] {
    set so_ss_name [get_full_name $so_ss_p]
    set so_ss_root $so_ss_name
    regexp {^(.+)\[[0-9]+\]$} $so_ss_name -> so_ss_root
    if {[dict exists $so_ss_roots $so_ss_root]} {
      dict set so_ss_ports $so_ss_name 1
      lappend so_ss_sources $so_ss_p
    }
  }
  set so_ss_data [dict create]
  foreach so_ss_p [all_registers -data_pins] {
    dict set so_ss_data [get_full_name $so_ss_p] 1
  }
  set so_ss_proven [dict create]
  if {[llength $so_ss_sources]} {
    foreach so_ss_p [get_fanout -from $so_ss_sources -flat -endpoints_only -trace_arcs all] {
      set so_ss_name [get_full_name $so_ss_p]
      if {![dict exists $so_ss_data $so_ss_name]} { continue }
      set so_ss_start [get_fanin -to $so_ss_p -flat -startpoints_only -trace_arcs all]
      set so_ss_ok [expr {[llength $so_ss_start] > 0}]
      foreach so_ss_s $so_ss_start {
        if {![dict exists $so_ss_ports [get_full_name $so_ss_s]]} { set so_ss_ok 0; break }
      }
      if {$so_ss_ok} { dict set so_ss_proven $so_ss_name 1 }
    }
  }
} so_ss_error]} {
  puts "SO STATIC_STRAP_ERROR $so_ss_error"
} else {
  foreach so_ss_name [lsort [dict keys $so_ss_proven]] {
    puts "SO_STATIC_STRAP_ENDPOINT $so_ss_name"
  }
}

puts {SO_PATH_BEGIN CHECK_SETUP}
check_setup -verbose -unconstrained_endpoints -no_clock -loops -generated_clocks -multiple_clock
puts {SO_PATH_END CHECK_SETUP}
exit
