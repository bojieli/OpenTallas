module native_gb_capture #(parameter integer RSTP=1, GO_BOUNDARY=1)(input wire clk,rst_n,go,input wire[1:0]go_tag,output wire go_e_in,output wire[1:0]go_tag_e_in);
    wire rst_n_e;                      // the element's reset: the pin (RSTP = 0) or the pin relay flop (RSTP = 1)
    if (RSTP != 0) begin : g_rstp
        (* keep, dont_touch = "true" *) reg rst_pf;
        always @(posedge clk) rst_pf <= rst_n;
`ifdef OT_QXPQ_RSTP_MUT_BYPASS
        assign rst_n_e = rst_n;        // MUTANT: relay bypassed (the bench must catch the release edge)
`else
        assign rst_n_e = rst_pf;
`endif
    end else begin : g_nrstp
        assign rst_n_e = rst_n;
    end
    // S81 RF-J IFN (conservative form, input side of the OLAT crossing): rf1s ended at FF -239 on 2342 input endpoints (zero-logic
    // pin -> posedge flop against a 460 ps insertion).  Every data input bit lands in ONE negative-edge flop first: it samples the
    // sender's rising-edge launch half a cycle later, and the existing rising-edge logic reads it at the SAME edge it read the pin
    // (0 cycles at a rising-edge sender; a falling-edge sender would be +1 cycle, the plan senders are rising-edge).  rst_n keeps its
    // RSTP relay.  Setup: ~+200 ps budget at in_max 166.6 / half cycle 416.  Bench: tb_qxpq_go_boundary +define+TB_DUT_IFN=1.
    wire cfg_v_i, go_i, xs_v_i; wire [4:0] cfg_a_i; wire [47:0] cfg_d_i; wire [1:0] go_tag_i; wire [7:0] xs_p_i; wire [2:0] xs_b_i, xs_pos_i;
    wire [255:0] xs_q0_i, xs_q1_i; wire [9:0] xs_e0_i, xs_e1_i;
    if (IFN != 0) begin : g_ifn
        reg cfg_v_n, go_n, xs_v_n; reg [4:0] cfg_a_n; reg [47:0] cfg_d_n; reg [1:0] go_tag_n; reg [7:0] xs_p_n; reg [2:0] xs_b_n, xs_pos_n;
        reg [255:0] xs_q0_n, xs_q1_n; reg [9:0] xs_e0_n, xs_e1_n;
`ifdef OT_QXPQ_IFN_MUT_POS
        always @(posedge clk) begin                  // MUTANT: rising-edge copy = one extra cycle (the bench must catch it)
`else
        always @(negedge clk) begin
`endif
            cfg_v_n <= cfg_v; cfg_a_n <= cfg_a; cfg_d_n <= cfg_d; go_n <= go; go_tag_n <= go_tag; xs_v_n <= xs_v; xs_p_n <= xs_p;
            xs_b_n <= xs_b; xs_q0_n <= xs_q0; xs_e0_n <= xs_e0; xs_q1_n <= xs_q1; xs_e1_n <= xs_e1; xs_pos_n <= xs_pos;
        end
        assign cfg_v_i = cfg_v_n; assign cfg_a_i = cfg_a_n; assign cfg_d_i = cfg_d_n; assign go_i = go_n; assign go_tag_i = go_tag_n;
        assign xs_v_i = xs_v_n; assign xs_p_i = xs_p_n; assign xs_b_i = xs_b_n; assign xs_q0_i = xs_q0_n; assign xs_e0_i = xs_e0_n;
        assign xs_q1_i = xs_q1_n; assign xs_e1_i = xs_e1_n; assign xs_pos_i = xs_pos_n;
    end else begin : g_nifn
        assign cfg_v_i = cfg_v; assign cfg_a_i = cfg_a; assign cfg_d_i = cfg_d; assign go_i = go; assign go_tag_i = go_tag;
        assign xs_v_i = xs_v; assign xs_p_i = xs_p; assign xs_b_i = xs_b; assign xs_q0_i = xs_q0; assign xs_e0_i = xs_e0;
        assign xs_q1_i = xs_q1; assign xs_e1_i = xs_e1; assign xs_pos_i = xs_pos;
    end
    // The historical element uses go_pin in status and clock-gate lookahead.
    // Capture at the outer pin first so the pin itself drives only one D input.
    // Compiler contract: GO_BOUNDARY=1 issues go/tag one edge earlier relative
    // to the existing configuration and x-beat dates (+1 go-path cycle).
    if (GO_BOUNDARY != 0) begin : g_go_boundary
        reg go_q;
        reg [1:0] tag_q;
        always @(posedge clk or negedge rst_n_e)
            if (!rst_n_e) go_q <= 1'b0;
            else go_q <= go_i;
        always @(posedge clk) tag_q <= go_tag_i;
`ifdef OT_QXPQ_GO_MUT_BYPASS
        assign go_e_in = go_i;
`else
        assign go_e_in = go_q;
`endif
        assign go_tag_e_in = tag_q;
    end else begin : g_go_legacy
        assign go_e_in = go_i;
        assign go_tag_e_in = go_tag_i;
    end
    // S81-RF1 OLAT (DIE-S81-51/CLK crossing table class 1, core->parent face, zero-logic hold -96..-228 FF): the
    // element's registered output faces leave through one negative-EDGE flop per bit (DFFLQN, the HBM face-lockup form:
    // same T/2 window as a negative-level lockup latch, but the port stays flop-driven so face_guard sees a register):
    // the pin changes half a cycle after the launching edge, so the parent capture at the same edge sees the old value
    // (hold +T/2 - skew: >= +179 FF near) and the next edge sees the new one (setup T/2 less: >= +35 TT near).  Same
    // cycle at every receiver edge (0 added cycles; bench tb_qxpq_go_boundary +define+TB_DUT_OLAT=1).  OLAT = 0: wires.
    localparam integer OW = 5 + NB * (1 + 32 + 16 + 5 + 5 + 1 + 3);
    wire o_walking, o_bank_free, o_sh_free, o_busy, o_fault;
    wire [NB-1:0] o_pv, o_perr; wire [32*NB-1:0] o_pval; wire [16*NB-1:0] o_prow; wire [5*NB-1:0] o_pseg, o_pnseg;
    wire [3*NB-1:0] o_ppos;
    wire [OW-1:0] o_face = {o_walking, o_bank_free, o_sh_free, o_pv, o_pval, o_prow, o_pseg, o_pnseg, o_perr, o_ppos, o_busy, o_fault};
    wire [OW-1:0] p_face;
    if (OLAT != 0) begin : g_olat
        for (genvar ob = 0; ob < OW; ob = ob + 1) begin : g_bit
            reg q;  // no keep: a kept wire adds a buffer load on the scalar port nets (face_guard shared; RF-A c7b2edc390)
`ifdef OT_QXPQ_OLAT_MUT_POS
            always @(posedge clk) q <= o_face[ob];    // MUTANT: rising-edge copy = one extra cycle (the bench must catch it)
`else
            always @(negedge clk) q <= o_face[ob];
`endif
            assign p_face[ob] = q;
        end
    end else begin : g_nolat
        assign p_face = o_face;
    end
    assign {walking, bank_free, sh_free, pv, pval, prow, pseg, pnseg, perr, ppos, busy, fault} = p_face;

endmodule
