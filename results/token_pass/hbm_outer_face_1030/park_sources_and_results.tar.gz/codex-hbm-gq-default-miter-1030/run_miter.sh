#!/bin/bash
set -euo pipefail
mode=$1
profile=0;face=0;old=old_gq.sv
[ "$mode" != mutant ] || old=old_gq_mutant.sv
V=/home/ubuntu/.local/opentallas-tools/verilator-5.050/bin/verilator
"$V" --binary --timing -O1 -j 4 --output-groups 16 -CFLAGS -O0 -Wno-fatal -Wno-MULTIDRIVEN -Wno-TIMESCALEMOD -Wno-MODDUP --top-module tb_hgi_coll_gq -GOUTER_PROFILE=$profile -GRING_FACES=$face -GLANES=1 -GLT=2 -GLG=0 -GBANK_RT=9 -GVM_RT=3 --Mdir obj_$mode tb.sv -f files.f prepared_native.sv current_native_ring_face.sv source_ring_cut_api.sv native_ring_cut_api.sv $old > build_$mode.log 2>&1
set +e
obj_$mode/Vtb_hgi_coll_gq > run_$mode.log 2>&1
rc=$?
set -e
if [ "$mode" = mutant ];then grep -q GQ_DEFAULT_FULL_OUTPUT_DIFF run_$mode.log;else test $rc -eq 0;grep -q GQ_DEFAULT_FULL_OUTPUT_MITER_PASS run_$mode.log;fi
