#!/bin/bash
set -euo pipefail
mode=$1
case "$mode" in native) profile=0;face=0;; old_calendar) profile=0;face=1;; repaired) profile=1;face=1;; *) exit2;; esac
V=/home/ubuntu/.local/opentallas-tools/verilator-5.050/bin/verilator
"$V" --binary --timing -O1 -j 4 --output-groups 16 -CFLAGS -O0 -Wno-fatal -Wno-MULTIDRIVEN -Wno-TIMESCALEMOD -Wno-MODDUP --top-module tb_hgi_coll_gq -GOUTER_PROFILE=$profile -GRING_FACES=$face -GLANES=1 -GLT=2 -GLG=0 -GBANK_RT=9 -GVM_RT=3 --Mdir obj_$mode tb.sv -f files.f prepared_native.sv current_native_ring_face.sv source_ring_cut_api.sv native_ring_cut_api.sv > build_$mode.log 2>&1
obj_$mode/Vtb_hgi_coll_gq > run_$mode.log 2>&1
if [ "$mode" = old_calendar ]; then
 if grep -q '^COLLQ_FACE_CALLER_PASS ' run_$mode.log; then exit 1; fi
else
 grep -q '^COLLQ_FACE_CALLER_PASS ' run_$mode.log
fi
