#!/bin/bash
set -euo pipefail
mode=$1;mut=0
[ "$mode" != mutant ] || mut=1
V=/home/ubuntu/.local/opentallas-tools/verilator-5.050/bin/verilator
"$V" --binary --timing -O1 -j 4 --output-groups 16 -CFLAGS -O0 -Wno-fatal -Wno-MULTIDRIVEN -Wno-TIMESCALEMOD -Wno-MODDUP --top-module tb_hgi_coll_gq -GOUTER_PROFILE=1 -GRING_FACES=1 -GVM_WARM_MUT=$mut -GLANES=1 -GLT=2 -GLG=0 -GBANK_RT=9 -GVM_RT=3 --Mdir obj_warm_$mode tb.sv -f files.f prepared_native.sv current_native_ring_face.sv source_ring_cut_api.sv native_ring_cut_api.sv native_vm_warm_coupon.sv hfd_vms_bank_native_q0_faces.sv ot_vms_bank_q0_faces_core.sv ot_vms_bank_q0_faces_body.sv ot_vms_ce_counter_pipe.sv ot_sram_1r1w_1024x256_m2_r2c2.v > build_warm_$mode.log 2>&1
set +e
obj_warm_$mode/Vtb_hgi_coll_gq > run_warm_$mode.log 2>&1
rc=$?
set -e
if [ "$mode" = mutant ];then grep -q 'WARM_QUEUED_STALE_MACRO_COMMIT' run_warm_$mode.log;else test $rc -eq 0;grep -q '^WARM_QUEUED_NATIVE_VM_PASS ' run_warm_$mode.log;fi
