#!/usr/bin/env python3
"""Materialize the exact already-tracked native RED sources for this component."""
from pathlib import Path
import hashlib,json,shutil,sys
here=Path(__file__).resolve().parent
root=Path(sys.argv[1]).resolve()
for item in json.loads((here/'external_sources.json').read_text())['sources']:
 source=root/item['repository_path'];target=here/item['packet_path']
 if hashlib.sha256(source.read_bytes()).hexdigest()!=item['sha256']:
  raise SystemExit('source hash differs: '+str(source))
 if target.exists():
  if hashlib.sha256(target.read_bytes()).hexdigest()!=item['sha256']:raise SystemExit('existing packet source differs: '+str(target))
 else:
  target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
 print(item['packet_path'],item['sha256'])
