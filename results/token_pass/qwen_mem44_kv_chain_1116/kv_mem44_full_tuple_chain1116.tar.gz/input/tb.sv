`timescale 1ns/1fs
module tb;
reg ck=0;always #0.4165 ck=~ck;
reg rst_n=0;reg[115:0]cmd=0;reg w16=0,w1=0,tw=0;reg[23:0]w16a=0,w1a=0,twa=0;
reg[511:0]w16d=0;reg[31:0]w1d=0;reg[1023:0]twd=0;reg[1:0]twk=0;reg[2:0]logical_head=0;reg bad_reply=0;
native_su_component #(.PROBE_MIF(1)) dut(.ck(ck),.rst_n(rst_n),.cmd_i(cmd),.hr_i('0),.rs_s('0),.rs_n('0),.l9_i('0),.st_up_i('0),.st_dn_i('0),.sc_up_i('0),.sc_dn_i('0),.ch_up_i('0),.ch_dn_i('0),.ag_up_i('0),.treq_i('0),
.preload16_we(w16),.preload16_addr(w16a),.preload16_data(w16d),.preload1_we(w1||red_we),.preload1_addr(red_we?red_addr:w1a),.preload1_data(red_we?red_return_data:w1d),.install_we(tw),.install_kind(twk),.install_addr(twa),.install_data(twd),.logical_head(logical_head),.bad_reply(bad_reply));
reg[511:0]programs[0:35];reg[31:0]gold[0:4607],xin[0:767],scalars[0:11];reg[1023:0]crom[0:407];
integer cid=0,op=0,active=0,count=0,retires=0,j,k,t,idx,actual_addr,base_addr,expect_count,cy=0,total=0;reg bad_gain=0;reg[127:0]seen;reg bad_red_return=0;

wire red_we,red_rd,red_busy,red_fault;wire[23:0]red_addr;wire[31:0]red_data;
wire[31:0]red_return_data=bad_red_return?(red_data^32'h00800000):red_data;
integer red_groups=0,red_seen=0,red_first=-1,red_last=-1,red_publish=-1,red_store=-1;
wire red_fire=active&&op==0&&dut.L_l_ov[0];
reg[255:0]red_cohort;
always @*begin
 red_cohort=0;
 for(integer h=0;h<8;h=h+1)begin
  if(cid<6&&red_groups<16)red_cohort[32*h+:32]=gold[cid*6*128+8*red_groups+h];
  if(h==logical_head)red_cohort[32*h+:32]=dut.L_l_out[31:0];
 end
end
// Actual native K79 RED; seven companion lanes are explicit independent golden producers.
qfd_dv_s5_red2_leaf native_red(.ck(ck),.rst_n(rst_n),.l_ov({8{red_fire}}),.l_out(red_cohort),
 .l_red0(dut.L_l_red[1:0]),.l_redsq0(dut.L_l_redsq[0]),.l_last0(dut.L_l_last[0]),.l_raddr0(dut.L_l_raddr[23:0]),
 .red_we(red_we),.red_addr(red_addr),.red_data(red_data),.rd_v(red_rd),.busy(red_busy),.fault(red_fault));
always @(posedge ck)begin
 if(rst_n&&red_fault)$fatal(1,"RED_NATIVE_FAULT");
 if(red_fire)begin if(red_first<0)red_first=cy;red_last=cy;red_groups=red_groups+1;end
 if(red_we)begin
  if(w1)$fatal(1,"RED_W1_COLLISION");
  if(red_data!==scalars[2*cid]||red_addr!==24'd928)$fatal(1,"RED_RETURN_VALUE got%08x expected%08x addr%h",red_data,scalars[2*cid],red_addr);
  red_seen=red_seen+1;red_publish=cy;
 end
 if(rst_n&&op==0&&dut.u_suvm.u_vm8q.u_va.mwe[0]&&dut.u_suvm.u_vm8q.u_va.mrow[0]==10'd58)red_store=cy;
end

reg[1:0]ctx_user=0,ctx_generation=0;reg[17:0]ctx_token=0;reg[12:0]ctx_pos=0;reg[15:0]ctx_host_epoch=0;reg[58:0]ctx_host_tag=0;
reg head_prepare_v=0,context_started=0,bad_host_position=0,bad_host_token=0,bad_unprepared_user=0;
wire[15:0]expected_epoch=ctx_user==0?ctx_host_epoch:{14'd0,ctx_user};
wire[58:0]expected_identity={expected_epoch,6'd1,ctx_token,ctx_pos,6'd0};
wire[58:0]host_tag_sent=ctx_host_tag^(bad_host_position?(59'd1<<6):59'd0)^(bad_host_token?(59'd1<<19):59'd0);
reg layer_context_v=0;reg[5:0]command_stage=0;reg[17:0]native_position=0;reg kv_word_slot=0;reg[1:0]kv_word_index=0;
reg[547:0]dd_i;wire fmt_v,fmt_bad,kv_input_bad;wire[10:0]fmt_tag;wire[511:0]fmt_data;wire[7:0]fmt_code;
reg bad_early_slot=0,bad_kind=0,bad_packet_data=0;integer fmt_count=0,ddbase,di;reg[31:0]dval;
reg[511:0]packet_gold[0:23];
native_svc_join svc(.ck(ck),.rst_n(rst_n),.layer_context_v(layer_context_v),.command_stage(command_stage),.native_position(native_position),.native_token(ctx_token),.host_epoch(ctx_host_epoch),.host_tag(host_tag_sent),.host_generation(ctx_generation),.head_prepare_v(head_prepare_v),.head_prepare_user(ctx_user),.head_prepare_token(ctx_token),.head_prepare_position({5'd0,ctx_pos}),.dd_i(dd_i),.kv_word_slot(kv_word_slot),.kv_word_index(kv_word_index),.word_v(fmt_v),.word_tag(fmt_tag),.word_data(fmt_data),.formatter_fault(fmt_bad),.formatter_fault_code(fmt_code),.kv_in_bad(kv_input_bad));
always @*begin
 dd_i=0;ddbase=0;dval=0;
 if(active&&op>=3&&dut.L_kv_we[0])begin
  // Caller DD packing is explicit: 1 actual HEAD result and 7 golden cohort producers.
  // Native typed K/V address -> local dimension; actual svc adapter packs held epoch.
  ddbase=int'(dut.L_kv_waddr[6:0])-int'(logical_head);
  dd_i[547]=1;dd_i[546:545]=(op==5||(bad_kind&&op==3))?2'd2:2'd1;dd_i[544:537]=8'hff;
  for(integer h=0;h<8;h=h+1)begin
   di=ddbase+h;
   dd_i[345+24*h+:24]=24'(di);
   if(ddbase>=0&&di<128)dval=gold[(cid*6+op)*128+(op==4?di-64:di)];
   else dval=0;
   if(h==logical_head)dval=dut.L_kv_wdata[31:0];
   if(bad_packet_data&&op==3&&di==0)dval=dval^32'h00800000;
   dd_i[89+32*h+:32]=dval;
  end
 end
end
always @(posedge ck)begin
 if(rst_n&&context_started&&(svc.u.context_fault||svc.u.mu_fault||svc.u.hp_host_fault))$fatal(1,"TUPLE_CONTEXT_FAULT c%0d context%0b mu%0b hp%0b",cid,svc.u.context_fault,svc.u.mu_fault,svc.u.hp_host_fault);
 if(rst_n&&fmt_bad)$fatal(1,"FORMAT_JOIN_FAULT c%0d code%02x",cid,fmt_code);
 if(rst_n&&kv_input_bad)$fatal(1,"FORMAT_JOIN_INPUT c%0d",cid);
 if(fmt_v)begin
  if(svc.u.formatter_identity!==expected_identity||svc.u.formatter_generation!==ctx_generation||svc.u.u_formatter.pos!==ctx_pos||svc.u.c_user!==ctx_user)$fatal(1,"TUPLE_IDENTITY c%0d user%0d actual_user%0d identity%015h expected%015h generation%0d expected_gen%0d held_pos%0d expected_pos%0d",cid,ctx_user,svc.u.c_user,svc.u.formatter_identity,expected_identity,svc.u.formatter_generation,ctx_generation,svc.u.u_formatter.pos,ctx_pos);
  $display("FORMAT_TUPLE c%0d user%0d epoch%0d stage1 token%0d position%0d generation%0d identity%015h",cid,ctx_user,expected_epoch,ctx_token,ctx_pos,ctx_generation,svc.u.formatter_identity);
  if(fmt_count>=4||fmt_tag!==(11'h200|11'((fmt_count/2)*4+fmt_count%2))||fmt_data!==packet_gold[cid*4+fmt_count])$fatal(1,"FORMAT_JOIN_PAYLOAD c%0d word%0d tag%03h got%0128h expected%0128h",cid,fmt_count,fmt_tag,fmt_data,packet_gold[cid*4+fmt_count]);
  $display("FORMAT_JOIN_WORD c%0d word%0d tag%03h pos%0d exact512",cid,fmt_count,fmt_tag,native_position);fmt_count=fmt_count+1;
 end
end
always @(posedge ck)begin
 cy=cy+1;
 if(active)begin
  if(dut.h0_retire)retires=retires+1;
  if((op<3&&dut.L_vm_we[0])||(op>=3&&dut.L_kv_we[0]))begin
   actual_addr=op<3?dut.L_vm_waddr[23:0]:dut.L_kv_waddr[23:0];
   base_addr=op==0?800:op==1?944:op==2?960:op==3?4194304:op==4?4194368:8388608;idx=actual_addr-base_addr;
   if(idx<0||idx>=128||seen[idx])$fatal(1,"KV_FINISH_ADDRESS c%0d op%0d a%h idx%0d",cid,op,actual_addr,idx);
   if((op<3?dut.L_vm_wdata[31:0]:dut.L_kv_wdata[31:0])!==gold[(cid*6+op)*128+idx])$fatal(1,"KV_FINISH_PAYLOAD c%0d op%0d idx%0d got%08x expected%08x",cid,op,idx,op<3?dut.L_vm_wdata[31:0]:dut.L_kv_wdata[31:0],gold[(cid*6+op)*128+idx]);
   seen[idx]=1;count=count+1;
  end
 end
end
task automatic poke(input integer a,input[31:0]v);begin w1=1;w1a=a;w1d=v;@(negedge ck);w1=0;end endtask
initial begin
 $readmemh("packet_expected.hex",packet_gold);$readmemh("program.hex",programs);$readmemh("expected.hex",gold);$readmemh("input.hex",xin);$readmemh("scalar.hex",scalars);$readmemh("crom.hex",crom);
 bad_reply=$test$plusargs("BAD_REPLY");bad_gain=$test$plusargs("BAD_GAIN");bad_early_slot=$test$plusargs("EARLY_SLOT");bad_kind=$test$plusargs("WRONG_KIND");bad_packet_data=$test$plusargs("WRONG_PACKET_DATA");bad_host_position=$test$plusargs("WRONG_HOST_POSITION");bad_host_token=$test$plusargs("WRONG_HOST_TOKEN");bad_unprepared_user=$test$plusargs("UNPREPARED_USER");bad_red_return=$test$plusargs("BAD_RED_RETURN");
 for(cid=0;cid<6;cid=cid+1)begin
  active=0;cmd=0;w16=0;w1=0;tw=0;rst_n=0;layer_context_v=0;command_stage=0;kv_word_slot=0;fmt_count=0;ctx_user=2'(cid%4);ctx_generation=2'(cid+1);ctx_token=18'(23+cid);ctx_pos=(cid%3==0)?13'd0:(cid%3==1)?13'd16:13'd8191;ctx_host_epoch=16'(9216+4*cid);ctx_host_tag={ctx_host_epoch,6'd0,ctx_token,ctx_pos,6'd0};native_position={(bad_unprepared_user?2'd3:ctx_user),3'd0,ctx_pos};head_prepare_v=0;context_started=0;repeat(64)@(negedge ck);logical_head=cid<3?0:7;red_groups=0;red_seen=0;red_first=-1;red_last=-1;red_publish=-1;red_store=-1;rst_n=1;repeat(512)@(negedge ck);
  for(j=0;j<128;j=j+16)begin w16=1;w16a=800+j;for(k=0;k<16;k=k+1)w16d[32*k+:32]=xin[cid*128+j+k];@(negedge ck);end
  w16=0;poke(400,32'h3f000000);tw=1;twk=3;
  for(j=0;j<3;j=j+1)begin twa=j;twd={programs[cid*6+2*j+1],programs[cid*6+2*j]};@(negedge ck);end
  twk=1;for(j=0;j<68;j=j+1)begin twa=j;twd=crom[cid*68+j];if(bad_gain&&j==56)twd=twd^1024'h800000;@(negedge ck);end
  tw=0;repeat(128)@(negedge ck);if(ctx_user!=0&&!bad_unprepared_user)begin head_prepare_v=1;@(negedge ck);head_prepare_v=0;repeat(20)@(negedge ck);end
  layer_context_v=1;command_stage=1;@(negedge ck);layer_context_v=0;command_stage=0;context_started=1;repeat(32)@(negedge ck);
  for(op=0;op<6;op=op+1)begin
   // Every reduction and RSQ scalar here is real native RTL, not a scalar preload.
   if(op==1)logical_head=0;
   if(op==2)logical_head=cid<3?0:7;
   if(op==5)begin for(j=0;j<128;j=j+16)begin w16=1;w16a=800+j;for(k=0;k<16;k=k+1)w16d[32*k+:32]=xin[cid*128+j+k];@(negedge ck);end w16=0;repeat(32)@(negedge ck);end
   
   count=0;retires=0;seen=0;active=1;cmd=(116'(op)<<4)|116'd3;@(negedge ck);cmd=0;expect_count=op==1?1:(op==3||op==4)?8:16;
   for(t=0;t<768;t=t+1)begin
    kv_word_slot=(op==5&&(t==180||t==185||t==190||t==195))||(bad_early_slot&&op==3&&t==0);
    kv_word_index=op==5?2'((t-180)/5):2'd0;
    @(negedge ck);
    if(count==expect_count&&retires==expect_count&&dut.su_idle&&dut.u_suvm.u_su8.ready&&dut.u_suvm.u_su8.inflight==0&&(op!=5||t>=224))break;
   end
   kv_word_slot=0;
   if(op==5&&fmt_count!=4)$fatal(1,"FORMAT_JOIN_COUNT c%0d words%0d",cid,fmt_count);
   if(count!=expect_count||retires!=expect_count||dut.su_fault||dut.vm_fault)$fatal(1,"KV_FINISH_COUNT c%0d op%0d words%0d retire%0d fault%0b/%0b",cid,op,count,retires,dut.su_fault,dut.vm_fault);
   $display("KV_FINISH_CASE c%0d op%0d head%0d words%0d cycles%0d",cid,op,logical_head,count,t);total=total+count;
   if(op==0)begin
    for(t=0;t<512;t=t+1)begin @(negedge ck);if(red_seen==1&&!red_busy&&red_store>0)break;end
    if(red_seen!=1||red_groups!=16||red_store<0)$fatal(1,"RED_JOIN_COMPLETION groups%0d returns%0d store%0d",red_groups,red_seen,red_store);
    $display("RED_JOIN c%0d groups%0d first_input%0d last_input%0d W1_accept%0d macro_store%0d first_to_accept%0d last_to_accept%0d accept_to_store%0d",cid,red_groups,red_first,red_last,red_publish,red_store,red_publish-red_first,red_publish-red_last,red_store-red_publish);
   end
   active=0;repeat(32)@(negedge ck);
  end
 end
 $display("KV_MEM44_FULL_TUPLE_CHAIN_PASS cases6 programmes36 words%0d SYNTHETIC_ACTIVATIONS CHECKPOINT_GAINS ACTUAL_NATIVE_RED_WITH7_GOLDEN_COMPANION_LANES",total);$finish;
end
endmodule
