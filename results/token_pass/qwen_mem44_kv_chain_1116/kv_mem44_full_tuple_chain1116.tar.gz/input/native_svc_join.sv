`timescale 1ns/1ps
module native_svc_join(input wire ck,rst_n,layer_context_v,input wire[5:0]command_stage,input wire[17:0]native_position,native_token,input wire[15:0]host_epoch,input wire[58:0]host_tag,input wire[1:0]host_generation,input wire head_prepare_v,input wire[1:0]head_prepare_user,input wire[17:0]head_prepare_token,head_prepare_position,input wire[547:0]dd_i,input wire kv_word_slot,input wire[1:0]kv_word_index,output wire word_v,output wire[10:0]word_tag,output wire[511:0]word_data,output wire formatter_fault,output wire[7:0]formatter_fault_code,output wire kv_in_bad);
 wire[523:0]x3;wire[58:0]x3i;wire[1:0]x3g;wire txv;wire[547:0]txp;wire hdv;wire[58:0]hdt;wire[1:0]hdg;wire[519:0]dr;
 wire ecre,esre;wire[23:0]eca;wire[17:0]esa;wire cpl;wire[58:0]cpt;wire[94:0]ret;wire flt;
 qfd_native59_svc_obs1 #(.HEAD_PREP(1),.NU(4),.ROPE(1),.USER_BIND(1),.MCTX(1),.EMB_RELAY(1),.RECV_INPUTS(0),.LOCAL32(0),.NATIVE_LOCAL_KV_ADDR(1)) u(
  .ck(ck),.rst_n(rst_n),.host_epoch_valid(1'b1),.host_fused_capability(1'b1),.host_epoch(host_epoch),.host_tag(host_tag),.host_generation(host_generation),
  .layer_context_v(layer_context_v),.command_stage(command_stage),.head_prepare_v(head_prepare_v),.head_prepare_user(head_prepare_user),.head_prepare_token(head_prepare_token),.head_prepare_position(head_prepare_position),
  .native_token(native_token),.native_position(native_position),.native_cmd(380'd0),.dd_i(dd_i),.kv_word_slot(kv_word_slot),.kv_word_index(kv_word_index),.kv_x3_slot(1'b0),
  .x3(x3),.x3_identity(x3i),.x3_generation(x3g),.qb_v(1'b0),.qb_beat(5'd0),.qb_row(512'd0),.qb_full(1'b0),.qb_committed(1'b0),.qb_bad(1'b0),
  .tx_user(2'd0),.rx_user(2'd0),.tx_slot(1'b0),.tx_slot_kind(4'd0),.tx_slot_beat(5'd0),.native_tx_v(txv),.native_tx_payload(txp),
  .head_descriptor_v(hdv),.head_descriptor_tag(hdt),.head_descriptor_generation(hdg),
  .native_rx_v(1'b0),.native_rx_payload(548'd0),.rx_slot(1'b0),.rx_slot_kind(4'd0),.rx_slot_beat(5'd0),
  .dr_o(dr),.emb_code_re(ecre),.emb_code_addr(eca),.emb_scale_re(esre),.emb_scale_addr(esa),.emb_code_q(512'd0),.emb_scale_q(16'd0),
  .visibility_slot(1'b0),.complete_slot(1'b0),.completed(cpl),.completed_tag(cpt),.native_ret(ret),.fault(flt));
assign word_v=u.kvn_v,word_tag=u.kvn_tag,word_data=u.kvn_data,formatter_fault=u.formatter_fault,formatter_fault_code=u.formatter_fault_code,kv_in_bad=u.kv_in_bad;
endmodule
