from pathlib import Path
import json,shutil,importlib.util,hashlib,sys,struct,math
import numpy as np
B=Path(__file__).resolve().parent;O=Path(sys.argv[1]);O.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('G',B/'hdc_golden.py');G=importlib.util.module_from_spec(spec);spec.loader.exec_module(G)
stage_path=B/'kv_finish_stage1_source1116.json';S=json.loads(stage_path.read_text())['stage']['slices']
f=lambda w,l,n:(w>>l)&((1<<n)-1)
pg=[];expected=[];initial=[];scalars=[];crom=[];cases=[]
for logical in [0,7]:
 for pos in [0,16,8191]:
  cid=len(cases);s=S[8];ws={2*r['addr']+h:(int(r['payload_hex'],16)>>(512*h))&((1<<457)-1)for r in s['prog_users'][0]for h in [0,1]}
  progs=[ws[i]for i in range(4,9)]+[int(S[10]['prog_users'][0][2]['payload_hex'],16)&((1<<457)-1)];pg.extend(f'{w:0128x}'for w in progs)
  x=np.array([(-1 if i%7==0 else 1)*2.**((i*3+pos)%5-2)for i in range(128)],dtype=np.float32)
  y=G.mul(x,np.float32(.5));r=G.reduce_chunked(G.mul(y,y));rsq=G.rsqrt(G.add(G.mul(r,np.float32(1/128)),G.from_bits(np.uint32(0x358637bd))))
  cr={r['addr']:int(r['payload_hex'],16)for r in s['crom']};gains=np.array([G.from_bits(np.uint32(f(cr[56+i//16],(i%16)*64,32)))for i in range(128)],dtype=np.float32)
  norm=G.mul(G.mul(y,rsq),gains);cos,sin,h=G.rope_tables(pos,128,1000000);kv=G.to_fp8(G.rope(norm,cos,sin,h));vv=G.to_fp8(y)
  for op in range(6):
   vals=y if op==0 else np.array([rsq])if op==1 else norm if op==2 else kv[:64]if op==3 else kv[64:]if op==4 else vv
   expected.extend(f'{int(G.bits(vals[i]))if i<len(vals)else 0:08x}'for i in range(128))
  initial.extend(f'{int(G.bits(v)):08x}'for v in x);scalars.extend([f'{int(G.bits(r)):08x}',f'{int(G.bits(rsq)):08x}'])
  for j in range(4):cr[64+j]=sum((int(G.bits(cos[16*j+i]))|(int(G.bits(sin[16*j+i]))<<32))<<(64*i)for i in range(16))
  crom.extend(f'{cr.get(j,0):0256x}'for j in range(68));cases.append(dict(case=cid,logical_head=logical,position=pos))
for name,data in [('program.hex',pg),('expected.hex',expected),('input.hex',initial),('scalar.hex',scalars),('crom.hex',crom)]: (O/name).write_text('\n'.join(data)+'\n')

# Independent E4M3 real-value definition maps golden roundedFP32 to payloadbytes.
inv={}
for byte in range(256):
 exponent=(byte>>3)&15;mantissa=byte&7
 if exponent==15 and mantissa==7:continue
 val=math.ldexp(mantissa,-9)if exponent==0 else math.ldexp(1+mantissa/8,exponent-7)
 if byte&128:val=-val
 inv[struct.unpack('<I',struct.pack('<f',val))[0]]=byte
E=[int(v,16)for v in expected];words=[]
for c in range(6):
 vals=E[(c*6+3)*128:(c*6+3)*128+64]+E[(c*6+4)*128:(c*6+4)*128+64]+E[(c*6+5)*128:(c*6+5)*128+128]
 for j in range(4):words.append(f'{sum(inv[v]<<(8*i)for i,v in enumerate(vals[64*j:64*j+64])):0128x}')
(O/'packet_expected.hex').write_text('\n'.join(words)+'\n')
print(O)
