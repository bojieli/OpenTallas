#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
V=$HOME/.local/opentallas-tools/bin/verilator
/usr/bin/time -v -o build.time "$V" --binary --timing -j 1 -O0 -finline --output-groups 64 -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD -Wno-MULTIDRIVEN -Wno-UNOPTFLAT -Wno-WIDTH --x-assign 0 --x-initial 0 -CFLAGS '-O0 -w -fno-var-tracking' --top-module tb -f source.f --Mdir obj >build.log 2>&1
/usr/bin/time -v -o run.time ./obj/Vtb >run.log 2>&1
grep -q KV_MEM44_FULL_TUPLE_CHAIN_PASS run.log
for mutant in BAD_REPLY BAD_GAIN EARLY_SLOT WRONG_KIND WRONG_PACKET_DATA BAD_RED_RETURN WRONG_HOST_POSITION WRONG_HOST_TOKEN UNPREPARED_USER;do
 set +e
 ./obj/Vtb +"$mutant" >"${mutant}.log" 2>&1
 rc=$?
 set -e
 test "$rc" != 0
 grep -Eq 'KV_FINISH_PAYLOAD|KV_FINISH_COUNT|KV_FINISH_ADDRESS|FORMAT_JOIN_PAYLOAD|FORMAT_JOIN_FAULT|FORMAT_JOIN_INPUT|FORMAT_JOIN_COUNT|TUPLE_CONTEXT_FAULT|TUPLE_IDENTITY' "${mutant}.log"
done
echo KV_MEM44_FINISH_MUTANTS_CAUGHT
