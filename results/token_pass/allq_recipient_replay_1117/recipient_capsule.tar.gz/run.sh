#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
bash build.sh
for side in 0 1;do
 ./obj/Vtb_pv_so_ingress_hden +side=$side > run_side$side.log 2>&1
 grep -q PVSO_RECIPIENT_PASS run_side$side.log
 ./obj/Vtb_pv_so_ingress_hden +side=$side +window_mut=1 > run_side${side}_overlap.log 2>&1
 grep -q PVSO_CAUGHT run_side${side}_overlap.log
done
