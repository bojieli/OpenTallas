#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
V=$HOME/.local/opentallas-tools/verilator-5.050/bin/verilator
"$V" --binary --timing -j 4 -Wno-fatal -Wno-WIDTH --top-module tb_pv_so_ingress_hden -Mdir "$PWD/obj" rtl/dsrom_sys/s81_dv/pv_so/*.sv rtl/dsrom_sys/s81_ctrl/ot_s81_svc_job.sv physical/asap7_memory_macros_v2/ot_sram_1r1w_32x64_m1/ot_sram_1r1w_32x64_m1.v tb.sv > build.log 2>&1
