`timescale 1ns/1ps
// ---------------------------------------------------------------------------
// ot_v41_bf16_lanes: the optional BF16 path of the V4.1 ROM-array element (W10; model: BF16 lanes on
// 2,048 of the busiest die's 13,798 macros).
//
// Golden mv / matvec_c under R-ARITH chunk8 (tools/hdc_golden_v41.py): products w * bf16(x) in binary32 (a
// BF16 x BF16 product is exact), each golden chunk of 8 consecutive products summed sequentially from +0,
// chunk sums combined by the padded pairwise tree.  A BF16 unit is a lane group of 16 consecutive golden
// chunks (128 elements); word b of a unit carries element b of each chunk (lane l <- chunk 16h + l), so
// each of the 16 lanes runs its own chunk chains (NCHB slots, one pipelined FP32 adder).  The 16 chunk sums
// of a unit complete in the same cycle and meet in a 15-adder, 4-level pairwise tree whose root is the
// golden level-4 node of that lane group; it leaves as one base node for the element's segment tree.
// Latency: product 5 (ot_hdc_bmul) + chain 5 + tree 20.
// ---------------------------------------------------------------------------
module ot_v41_bf16_lanes #(
    parameter integer NCHB = 8,
    parameter integer TRW = 2          // tree-id width
) (
    input  wire              clk,
    input  wire              rst_n,
    input  wire              v,
    input  wire [255:0]      w,        // 16 BF16 weights, lane l at [16l +: 16]
    input  wire [255:0]      x,        // 16 BF16 activations, lane l at [16l +: 16]
    input  wire [$clog2(NCHB)-1:0] slot,
    input  wire              first,
    input  wire              last,
    input  wire [TRW-1:0]    tree,
    input  wire              final_i,
    output wire              ov,
    output wire [31:0]       oval,
    output wire [TRW-1:0]    otree,
    output wire              ofinal,
    output wire              oerr,
    output wire              fault
);
    localparam integer HW = $clog2(NCHB);
    localparam integer TW = HW + 2 + TRW + 1;
    wire [TW-1:0] t_in = {slot, first, last, tree, final_i};
    wire [TW-1:0] t_p;
    ot_hdc_delay #(.W(TW), .D(5)) u_pt (.clk(clk), .rst_n(rst_n), .d(t_in), .q(t_p));
    wire [15:0] pv;
    wire [15:0] pf;
    wire [31:0] prod [0:15];
    wire [15:0] cv, cf, cfault;
    wire [31:0] cs [0:15];
    wire [TRW:0] ct [0:15];
    genvar l;
    generate for (l = 0; l < 16; l = l + 1) begin : g_l
        ot_hdc_bmul u_m (.clk(clk), .rst_n(rst_n), .v(v), .a({w[16*l +: 16], 16'd0}), .b({x[16*l +: 16], 16'd0}),
                         .y(prod[l]), .fault(pf[l]));
        reg [4:0] vp;
        always @(posedge clk or negedge rst_n) if (!rst_n) vp <= 5'd0; else vp <= {vp[3:0], v};
        assign pv[l] = vp[4];
        ot_v41_chain #(.NCH(NCHB), .TW(TRW + 1)) u_c (.clk(clk), .rst_n(rst_n), .v(pv[l]),
            .slot(t_p[TW-1 -: HW]), .first(t_p[TRW+2]), .last(t_p[TRW+1]), .term(prod[l]), .term_f(pf[l]),
            .tag(t_p[TRW:0]), .ov(cv[l]), .osum(cs[l]), .of(cf[l]), .otag(ct[l]), .fault(cfault[l]));
    end endgenerate
    // 4-level pairwise tree over the 16 chunk sums (all lanes emit in the same cycle)
    wire [31:0] lvv [0:4][0:15];
    wire [15:0] lve [0:4];
    wire [4:0] lvvld;
    wire [TRW:0] lvt [0:4];
    generate for (l = 0; l < 16; l = l + 1) begin : g_in
        assign lvv[0][l] = cs[l];
        assign lve[0][l] = cf[l];
    end endgenerate
    assign lvvld[0] = cv[0];
    assign lvt[0] = ct[0];
    genvar lv, k;
    generate for (lv = 0; lv < 4; lv = lv + 1) begin : g_lv
        localparam integer NN = 16 >> (lv + 1);
        for (k = 0; k < NN; k = k + 1) begin : g_n
            wire [1:0] e;
            wire vo;
            ot_fp32_add_rne_pipe u_a (.clk(clk), .rst_n(rst_n), .valid_in(lvvld[lv]), .a(lvv[lv][2*k]),
                                      .b(lvv[lv][2*k+1]), .y(lvv[lv+1][k]), .err(e), .valid_out(vo));
            reg [4:0] ep;
            always @(posedge clk) ep <= {ep[3:0], lve[lv][2*k] | lve[lv][2*k+1]};
            assign lve[lv+1][k] = ep[4] | (e != 2'd0);
        end
        for (k = NN; k < 16; k = k + 1) begin : g_z
            assign lvv[lv+1][k] = 32'd0;
            assign lve[lv+1][k] = 1'b0;
        end
        reg [4:0] vp;
        always @(posedge clk or negedge rst_n) if (!rst_n) vp <= 5'd0; else vp <= {vp[3:0], lvvld[lv]};
        assign lvvld[lv+1] = vp[4];
        ot_hdc_delay #(.W(TRW + 1), .D(5)) u_t (.clk(clk), .rst_n(rst_n), .d(lvt[lv]), .q(lvt[lv+1]));
    end endgenerate
    assign ov = lvvld[4];
    assign oval = lvv[4][0];
    assign otree = lvt[4][TRW:1];
    assign ofinal = lvt[4][0];
    assign oerr = lve[4][0];
    assign fault = |cfault;
endmodule
