`timescale 1ns/1ps
// ---------------------------------------------------------------------------
// ot_s81ph_link_ep (CLAUDE S81-PH collective, 2026-10-06): one die's END of a reliable link pair, derived from
// ot_dsrom_link_ct (rtl/dsrom_sys/ot_dsrom_link_ct.sv, unchanged).  Protocol, frame formats, invariants, fault codes
// and the three build-time mutants are ct's.  What changes:
//
//  (E) EXTERNAL CHANNEL.  ct holds sender, receiver and BOTH channel models of one direction.  Here the two
//      ot_dsrom_link_chan instances are replaced by ports, so the instance is the sender of this die's OUTBOUND
//      link plus the receiver of its INBOUND link:  f_tx (forward frames out) / f_rx (the peer's forward frames in),
//      r_tx (this receiver's reverse frames out) / r_rx (the peer receiver's reverse frames in).  Two ep instances
//      cross-wired through channels == two ct instances (one per direction), cycle for cycle
//      (tb_s81ph_link_ep: lockstep against ct).
//  (M) SRAM = 1: replay buffer and receive FIFO in ot_s81ph_mem1r1w (512x128 macros).  ct's replay read is
//      already a registered read (address = next cycle's index, same-cycle write forwarded); the receive FIFO's
//      registered output becomes the macro read register (read enable = drain, address = head).
//  (T) MARGIN-FIRST timing, no behaviour change: forward CRC generated over two cycles (TX_STAGES >= 2: partial
//      CRCs of the two payload halves registered in TX stage 0, XORed into stage 1 -- the CRC is affine in the
//      data); forward CRC check over two cycles (RX_STAGES >= 3); reverse-frame CRC check computed on the input
//      and registered beside the frame; pacer compare precomputed; replay index add as a wrap add (RP a power
//      of two).  The status counters stay (die tops leave them unloaded, synthesis removes them).
// ---------------------------------------------------------------------------
module ot_s81ph_link_ep #(
    parameter integer FLIT_BYTES     = 69,
    parameter integer TX_STAGES      = 2,     // >= 2
    parameter integer CHANNEL_CYCLES = 60,    // used only to derive the ACK timeout (as ct)
    parameter integer CHANNEL_CYCLES_B = CHANNEL_CYCLES,   // CLAUDE S81-PH coll v2: second timeout basis, chosen by the static pin ch_b (one lane tile master serves UCIe and board lanes)
    parameter integer RX_STAGES      = 3,     // >= 3
    parameter integer CREDITS        = 512,
    parameter integer SEQW           = 10,
    parameter integer REPLAY         = 0,
    parameter integer ACK_TIMEOUT    = 0,
    parameter integer MAX_RETRY      = 8,
    parameter integer KEEPALIVE      = 16,
    parameter integer PHY_NUM        = 0,
    parameter integer PHY_DEN        = 1,
    parameter integer SRAM           = 0,
    // RXPIPE (ds-1010 2026-10-10, opt-in; RX_STAGES >= 3): the receive sequence classification is precomputed one stage
    // early against the NEXT expected sequence (exp_seq + this cycle's accept, both arms in parallel, selected at the
    // flop), so c_acc = registered in-order flag && !full: the 10-bit seq subtract / compare no longer sits in front of
    // fill / tail / exp_seq / the landing SRAM write in one cycle (coll lane lcrpe TT -560 exp_seq -> fill).  0 cycles.
    // TOREG (ds-1010 2026-10-10, opt-in): the ACK timeout limit (static ch_b select) is registered and the timer keeps a
    // registered at-limit flag, so timeout = occ && !progress && at_lim (coll lane lcrpg TT -470 = ch_b_q -> limit mux ->
    // timer == limit compare -> retry / rewind across the tile).  0 cycles.
    // MWR (ds-1010/coll-tu 2026-10-11, opt-in): the replay buffer and the receive FIFO use ot_s81ph_mem1r1w WREG = 1
    // (registered write ports beside the macros, read-after-write forwarded inside the wrapper; caller-visible timing
    // unchanged), and the replay forward word rb_fwd_d loads every cycle (it is read only when rb_fwd, i.e. right after an
    // accept, so its accept load enable was redundant): accept no longer drives 553-bit enables or macro pins directly
    // (lane lcrpi: hold stuck -68 at u_rb w_addr_in = nxt_i, a setup-critical register).  0 cycles.
    parameter integer MWR            = `ifdef OT_S81PH_EP_MWR 1 `else 0 `endif,
    parameter integer TOREG          = `ifdef OT_S81PH_EP_TOREG 1 `else 0 `endif,
    parameter integer RXPIPE         = `ifdef OT_S81PH_EP_RXPIPE 1 `else 0 `endif,
    parameter integer PIPE           = 0,     // CLAUDE S81-PH coll lane v3: 1 = sender pipelined (see the PIPE notes below)
                                              // CLAUDE s81-blocks 2026-10-07: 2 = PIPE 1 + (a) the freed-count difference
                                              // d_fr registered in S2 (fr_seen only changes in S2-apply cycles, as una for
                                              // s2dack), (b) rdy_r / rep_r / credits / snd / snd_i computed for accept = 0
                                              // and 1 in parallel and selected by accept at the flop (lane e -489 / w -408)
    // derived frame widths (ports)
    parameter integer FFW_P = SEQW + 1 + FLIT_BYTES * 8 + 32,
    parameter integer RFW_P = 1 + SEQW + $clog2(CREDITS + 1) + 32
) (
    input  wire                     clk,
    input  wire                     rst_n,
    input  wire                     ch_b,      // static: 1 = ACK timeout from CHANNEL_CYCLES_B
    input  wire                     in_valid,
    output wire                     in_ready,
    input  wire [FLIT_BYTES*8-1:0]  in_data,
    input  wire                     in_last,
    output wire                     out_valid,
    input  wire                     out_ready,
    output wire [FLIT_BYTES*8-1:0]  out_data,
    output wire                     out_last,
    // external channels
    output wire                     f_tx_v,
    output wire [FFW_P-1:0]         f_tx,
    input  wire                     f_rx_v,
    input  wire [FFW_P-1:0]         f_rx,
    output wire                     r_tx_v,
    output wire [RFW_P-1:0]         r_tx,
    input  wire                     r_rx_v,
    input  wire [RFW_P-1:0]         r_rx,
    output reg  [31:0]              credit_stalls,
    output reg                      fault,
    output reg  [3:0]               fault_code,
    output reg  [31:0]              st_flits_tx,
    output reg  [31:0]              st_flits_rx_ok,
    output reg  [31:0]              st_crc_err,
    output reg  [31:0]              st_naks,
    output reg  [31:0]              st_replays,
    output reg  [31:0]              st_timeouts,
    output reg  [31:0]              st_retx_flits,
    output reg  [31:0]              st_max_replay_occ
);
    localparam integer W    = FLIT_BYTES * 8;
    localparam integer RP   = (REPLAY == 0) ? CREDITS : REPLAY;
    localparam integer CW   = $clog2(CREDITS + 1);
    localparam integer IW   = (RP > 1) ? $clog2(RP) : 1;
    localparam integer FPW  = SEQW + 1 + W;
    localparam integer FFW  = FPW + 32;
    localparam integer RVW  = 1 + SEQW + CW;
    localparam integer RFW  = RVW + 32;
    localparam integer RTT  = 2 * CHANNEL_CYCLES + TX_STAGES + 2 * PIPE + RX_STAGES + 6;
    localparam integer RTTB = 2 * CHANNEL_CYCLES_B + TX_STAGES + 2 * PIPE + RX_STAGES + 6;
    localparam integer ATO  = (ACK_TIMEOUT == 0) ? (RTT + 2 * KEEPALIVE + 32) : ACK_TIMEOUT;
    localparam integer ATOB = (ACK_TIMEOUT == 0) ? (RTTB + 2 * KEEPALIVE + 32) : ACK_TIMEOUT;
    localparam integer TW   = $clog2(((ATOB > ATO) ? ATOB : ATO) + 2);
    localparam integer RCW  = $clog2(MAX_RETRY + 2);
    localparam integer KW   = $clog2(KEEPALIVE + 1);
    localparam [SEQW-1:0] HALF = {1'b1, {(SEQW-1){1'b0}}};
    localparam [SEQW-1:0] RPS  = RP[SEQW-1:0];
    localparam integer    PW   = (CREDITS > 1) ? $clog2(CREDITS) : 1;
    localparam [31:0]     PLAST32 = CREDITS - 1;
    localparam [31:0]     CRED32  = CREDITS;
    localparam [31:0]     ATO32   = ATO - 1;
    localparam [31:0]     ATOB32  = ATOB - 1;
    localparam [31:0]     MR32    = MAX_RETRY;
    localparam [PW-1:0]   PLAST  = PLAST32[PW-1:0];
    localparam [CW:0]     CRED_W = CRED32[CW:0];
    localparam [TW-1:0]   ATO_WA = ATO32[TW-1:0];
    localparam [TW-1:0]   ATO_WB = ATOB32[TW-1:0];
    reg ch_b_q;                                // static pin, registered
    always @(posedge clk) ch_b_q <= ch_b;
    wire [TW-1:0]         ATO_W  = ch_b_q ? ATO_WB : ATO_WA;
    reg  [TW-1:0]         ato_q;                 // TOREG: registered limit (static after reset)
    always @(posedge clk) ato_q <= ATO_W;
    reg                   at_lim;                // TOREG: timer == limit, registered with the timer
    wire [TW-1:0]         ATO_S  = TOREG ? ato_q : ATO_W;
    localparam [RCW-1:0]  MR_W   = MR32[RCW-1:0];
    localparam integer    HB   = FPW / 2;           // CRC split point

`ifndef SYNTHESIS
    initial begin
        if (TX_STAGES < 2 || RX_STAGES < 3) $fatal(1, "ot_s81ph_link_ep: TX_STAGES >= 2 and RX_STAGES >= 3");
        if (RP < 1 || RP > (1 << (SEQW - 1)) || (1 << IW) != RP) $fatal(1, "ot_s81ph_link_ep: REPLAY must be a power of two <= 2^(SEQW-1)");
        if ((1 << PW) != CREDITS) $fatal(1, "ot_s81ph_link_ep: CREDITS must be a power of two");
        if (FFW != FFW_P || RFW != RFW_P) $fatal(1, "ot_s81ph_link_ep: frame width parameters");
        if (PHY_NUM < 0 || PHY_DEN < 1 || PHY_NUM > FLIT_BYTES * PHY_DEN) $fatal(1, "ot_s81ph_link_ep: PHY_NUM");
    end
`endif

    // RP is a power of two: (x + d) mod RP for x < RP, d <= RP is the IW-bit wrap add (ct: 32-bit add and compare)
    function automatic [IW-1:0] idx_add(input [IW-1:0] x, input [SEQW-1:0] d);
        idx_add = x + d[IW-1:0];
    endfunction

    // ======================================================================== sender
    reg  [SEQW-1:0] una, snd, nxt;
    reg  [IW-1:0]   una_i, snd_i, nxt_i;
    reg  [CW-1:0]   credits;
    reg  [CW-1:0]   fr_seen;
    reg  [TW-1:0]   timer;
    reg  [RCW-1:0]  retry;

    localparam integer PCOST = FLIT_BYTES * PHY_DEN;
    localparam integer PAW   = $clog2(2 * PCOST + PHY_NUM + 1);
    localparam [PAW-1:0] PCOST_W = PCOST[PAW-1:0];
    localparam [PAW-1:0] PNUM_W  = PHY_NUM[PAW-1:0];
    localparam [PAW-1:0] PTH2    = 2 * PCOST - PHY_NUM;        // pace - PCOST + PNUM >= PCOST
    reg  [PAW-1:0]  pace;
    reg             pace_ok_r;
    wire            pace_ok = (PHY_NUM == 0) || pace_ok_r;

    wire [SEQW-1:0] occ = nxt - una;
    // PIPE (coll lane v3, s81ph-dsfd_coll_lane_w-34b3e75dd SS -971: nxt -> occ / ack compare -> una_i add ->
    // replay read address -> SRAM -> CRC -> tp, 30 levels, one cycle):
    //  (1) in_ready and replaying are REGISTERS computed from the next-state values (same function, one flop)
    //  (2) the replay read address is the snd_i register (read data one cycle later), payload registered (stage A
    //      launch, stage B payload), CRC from registers: +2 TX cycles (RTT / ACK timeout include them)
    //  (3) reverse frames: pin register -> pending slot P (newest frame wins; NAK sticky until taken) -> stage S2
    //      (ack / credit differences against una / fr_seen, which only change when S2 applies) -> applied: one
    //      reverse frame applied every other cycle at most; ACKs and freed counts are cumulative, so merging is exact
    //      for the protocol (go-back-N recovers any NAK merged into a newer ACK)
    //  (4) index registers are seq[IW-1:0] (RP a power of two): una_i_n = ack[IW-1:0], no add
    reg             rdy_r, rep_r;
    wire            replaying = PIPE ? rep_r : (snd != nxt);
`ifdef OT_DSROM_LINK_MUT_FREECREDIT
    assign in_ready = PIPE ? rdy_r : ((occ < RPS) && !replaying && pace_ok);
`else
    assign in_ready = PIPE ? rdy_r : ((credits != 0) && (occ < RPS) && !replaying && pace_ok);
`endif
    wire            accept = in_valid && in_ready;
    wire            launch = (replaying && pace_ok) || accept;
    // replay storage: registered read of next cycle's index, same-cycle write forwarded
    wire [W:0]      rb_q;
    reg             rb_fwd;
    reg  [W:0]      rb_fwd_d;
    wire [W-1:0]    rd_data = rb_fwd ? rb_fwd_d[W-1:0] : rb_q[W-1:0];
    wire            rd_last = rb_fwd ? rb_fwd_d[W] : rb_q[W];
    wire [W-1:0]    l_data = replaying ? rd_data : in_data;
    wire            l_last = replaying ? rd_last : in_last;
    wire [FPW-1:0]  l_pay  = {snd, l_last, l_data};
    // PIPE TX stages A (launch, replay select, in word) / B (payload from the registered replay read)
    reg             a_v, a_rep, b_v; reg [SEQW-1:0] a_snd; reg [W:0] a_in; reg [FPW-1:0] b_pay;
    always @(posedge clk or negedge rst_n) if (!rst_n) begin a_v <= 1'b0; b_v <= 1'b0; end else begin a_v <= launch; b_v <= a_v; end
    always @(posedge clk) begin
        a_rep <= replaying; a_snd <= snd; a_in <= {in_last, in_data};
        b_pay <= {a_snd, a_rep ? rb_q : a_in};
    end
    wire [FPW-1:0]  t_pay    = PIPE ? b_pay : l_pay;
    wire            t_launch = PIPE ? b_v : launch;
    // (T) two-cycle forward CRC: partial CRCs of the halves (the CRC is affine: crc(a ^ b) = crc(a) ^ crc(b) ^ crc(0))
    wire [31:0]     l_crc_lo, l_crc_hi, crc_zero;
    ot_link_crc32 #(.W(FPW)) u_tx_crc_lo (.d({{(FPW-HB){1'b0}}, t_pay[HB-1:0]}), .crc(l_crc_lo));
    ot_link_crc32 #(.W(FPW)) u_tx_crc_hi (.d({t_pay[FPW-1:HB], {HB{1'b0}}}), .crc(l_crc_hi));
    ot_link_crc32 #(.W(FPW)) u_crc_zero (.d({FPW{1'b0}}), .crc(crc_zero));

    // reverse-frame receive register; (T) its CRC check is computed on the input and registered beside it
    reg             rr_v;
    reg  [RFW-1:0]  rr_f;
    reg             rr_crc_ok;
    wire [31:0]     r_rx_crc;
    ot_link_crc32 #(.W(RVW)) u_rv_crc_chk (.d(r_rx[RFW-1:32]), .crc(r_rx_crc));
    wire            rr_ok0  = rr_v && rr_crc_ok;
    wire            rr_bad  = rr_v && !rr_crc_ok;
    wire            rr_nak0 = rr_f[RFW-1];
    wire [SEQW-1:0] rr_ack0 = rr_f[RFW-2 -: SEQW];
    wire [CW-1:0]   rr_fr0  = rr_f[32 +: CW];
    // PIPE: pending slot P and decode stage S2
    reg             pv, s2v, pnak, s2nak, s2bad; reg [SEQW-1:0] pack, s2ack, s2dack; reg [CW-1:0] pfr, s2fr, s2dfr;
    wire            p_take = pv && !s2v;
    always @(posedge clk or negedge rst_n)
        if (!rst_n) begin pv <= 1'b0; s2v <= 1'b0; pnak <= 1'b0; end
        else begin
            s2v <= p_take;
            if (rr_ok0) begin pv <= 1'b1; pnak <= rr_nak0 | (pv && !p_take && pnak); end
            else if (p_take) begin pv <= 1'b0; pnak <= 1'b0; end
        end
    always @(posedge clk) begin
        if (rr_ok0) begin pack <= rr_ack0; pfr <= rr_fr0; end
        if (p_take) begin s2ack <= pack; s2fr <= pfr; s2nak <= pnak; s2dack <= pack - una; s2bad <= (pack - una) > occ; s2dfr <= pfr - fr_seen; end
    end
    wire            rr_ok   = PIPE ? s2v : rr_ok0;
    wire            rr_nak  = PIPE ? s2nak : rr_nak0;
    wire [SEQW-1:0] rr_ack  = PIPE ? s2ack : rr_ack0;
    wire [CW-1:0]   rr_fr   = PIPE ? s2fr : rr_fr0;
    wire [SEQW-1:0] d_ack   = PIPE ? s2dack : (rr_ack - una);
    wire [CW-1:0]   d_fr    = (PIPE >= 2) ? s2dfr : (rr_fr - fr_seen);
    wire            ack_bad = rr_ok && (PIPE ? s2bad : (d_ack > occ));
    wire [CW:0]     cred_sum = {1'b0, credits} + {1'b0, d_fr};
`ifdef OT_DSROM_LINK_MUT_FREECREDIT
    wire            fr_bad  = 1'b0;
`else
    wire            fr_bad  = rr_ok && (cred_sum > CRED_W);
`endif
    wire            ack_ok  = rr_ok && !ack_bad;
    wire            progress = ack_ok && (d_ack != 0);
    wire [SEQW-1:0] una_n   = ack_ok ? rr_ack : una;
    wire [IW-1:0]   una_i_n = ack_ok ? rr_ack[IW-1:0] : una_i;   // = una_i + d_ack (indices are seq mod RP)
`ifdef OT_S81PH_EP_TOREG_MUT
    wire            timeout = (occ != 0) && !progress && (TOREG ? 1'b0 : (timer == ATO_W));  // mutant: the registered timeout never fires
`else
    wire            timeout = (occ != 0) && !progress && (TOREG ? at_lim : (timer == ATO_W));
`endif
`ifdef OT_DSROM_LINK_MUT_NOREPLAY
    wire            rewind  = 1'b0;
`else
    wire            rewind  = (ack_ok && rr_nak) || timeout;
`endif
    wire [SEQW-1:0] snd_l   = launch ? snd + 1'b1 : snd;
    wire [IW-1:0]   snd_i_l = launch ? idx_add(snd_i, 1) : snd_i;
    wire [SEQW-1:0] snd_off = snd_l - una;
    wire            retry_exh = rewind && !progress && (retry >= MR_W);
    wire            ack_skip  = ack_ok && (d_ack > snd_off);
    wire [IW-1:0]   snd_i_nx  = (rewind || ack_skip) ? una_i_n : snd_i_l;

    ot_s81ph_mem1r1w #(.W(W + 1), .DEPTH(RP), .SRAM(SRAM), .WREG(MWR)) u_rb (.clk(clk), .rst_n(rst_n),
        .we(accept), .wa(nxt_i), .wd({in_last, in_data}), .re(1'b1), .ra(PIPE ? snd_i : snd_i_nx), .q(rb_q));

    // TX pipe: stage 0 = {payload, partial CRCs}; stage 1 = {payload, CRC}; stages 2.. copies
    reg             tp_v [0:TX_STAGES-1];
    reg  [FFW-1:0]  tp_f [0:TX_STAGES-1];
    reg  [31:0]     tp_lo, tp_hi;
    genvar gi;
    generate for (gi = 0; gi < TX_STAGES; gi = gi + 1) begin : g_tx
        if (gi == 0) begin : g_first
            always @(posedge clk or negedge rst_n)
                if (!rst_n) tp_v[gi] <= 1'b0;
                else begin tp_v[gi] <= t_launch; tp_f[gi] <= {t_pay, 32'd0}; tp_lo <= l_crc_lo; tp_hi <= l_crc_hi; end
        end else if (gi == 1) begin : g_crc
            always @(posedge clk or negedge rst_n)
                if (!rst_n) tp_v[gi] <= 1'b0;
                else begin tp_v[gi] <= tp_v[gi-1]; tp_f[gi] <= {tp_f[gi-1][FFW-1:32], tp_lo ^ tp_hi
`ifndef OT_S81PH_EP_MUT_NOZERO
                    ^ crc_zero
`endif
                    }; end
        end else begin : g_rest
            always @(posedge clk or negedge rst_n)
                if (!rst_n) tp_v[gi] <= 1'b0;
                else begin tp_v[gi] <= tp_v[gi-1]; tp_f[gi] <= tp_f[gi-1]; end
        end
    end endgenerate
    assign f_tx_v = tp_v[TX_STAGES-1];
    assign f_tx   = tp_f[TX_STAGES-1];

    // ======================================================================== receiver
    reg             xp_v [0:RX_STAGES-1];
    reg  [FFW-1:0]  xp_f [0:RX_STAGES-1];
    generate for (gi = 0; gi < RX_STAGES; gi = gi + 1) begin : g_rx
        if (gi == 0) begin : g_first
            always @(posedge clk or negedge rst_n)
                if (!rst_n) xp_v[gi] <= 1'b0;
                else begin xp_v[gi] <= f_rx_v; xp_f[gi] <= f_rx; end
        end else begin : g_rest
            always @(posedge clk or negedge rst_n)
                if (!rst_n) xp_v[gi] <= 1'b0;
                else begin xp_v[gi] <= xp_v[gi-1]; xp_f[gi] <= xp_f[gi-1]; end
        end
    end endgenerate

    wire            c_v    = xp_v[RX_STAGES-1];
    wire [FFW-1:0]  c_f    = xp_f[RX_STAGES-1];
    // (T) CRC of RX stage RX_STAGES-3 in two halves, registered beside stage RX_STAGES-2, compared into the flag
    // registered beside the last stage (ct: one cycle, stage RX_STAGES-2)
    wire [FFW-1:0]  q_f    = xp_f[RX_STAGES-3];
    wire [31:0]     q_lo, q_hi;
    ot_link_crc32 #(.W(FPW)) u_rx_crc_lo (.d({{(FPW-HB){1'b0}}, q_f[32 +: HB]}), .crc(q_lo));
    ot_link_crc32 #(.W(FPW)) u_rx_crc_hi (.d({q_f[FFW-1:32+HB], {HB{1'b0}}}), .crc(q_hi));
    reg  [31:0]     p_lo, p_hi, p_got;
    reg             c_crc_ok_r;
    always @(posedge clk or negedge rst_n)
        if (!rst_n) begin c_crc_ok_r <= 1'b0; p_lo <= 0; p_hi <= 0; p_got <= 0; end
        else begin
            p_lo <= q_lo; p_hi <= q_hi; p_got <= q_f[31:0];
            c_crc_ok_r <= ((p_lo ^ p_hi ^ crc_zero) == p_got);
        end
`ifdef OT_DSROM_LINK_MUT_NOCRC
    wire            c_crc_ok = 1'b1;
`else
    wire            c_crc_ok = c_crc_ok_r;
`endif
    wire [SEQW-1:0] c_seq  = c_f[FFW-1 -: SEQW];
    wire            c_last = c_f[32 + W];
    wire [W-1:0]    c_data = c_f[32 +: W];

    reg  [SEQW-1:0] exp_seq;
    reg             nak_sent, nak_req, dup_req;
    reg  [CW-1:0]   freed;
    reg  [CW-1:0]   fill;
    reg  [PW-1:0]   head, tail;
    reg             out_valid_r;
    wire [W:0]      fifo_q;
    assign out_valid = out_valid_r;
    assign out_data  = fifo_q[W-1:0];
    assign out_last  = fifo_q[W];

    wire [SEQW-1:0] c_diff, c_back;
    wire            c_acc;
    generate if (RXPIPE != 0) begin : g_rxp
        // seq of the flit entering the last RX stage next edge, against exp_seq as it will be after this edge
        wire [SEQW-1:0] n_seq = xp_f[RX_STAGES-2][FFW-1 -: SEQW];
        reg  [SEQW-1:0] d_q;
`ifdef OT_S81PH_EP_RXPIPE_MUT
        always @(posedge clk or negedge rst_n) if (!rst_n) d_q <= 0; else d_q <= n_seq - exp_seq;   // mutant: ignores this cycle's accept
`else
        always @(posedge clk or negedge rst_n) if (!rst_n) d_q <= 0; else d_q <= c_acc ? (n_seq - exp_seq - 1'b1) : (n_seq - exp_seq);
`endif
        assign c_diff = d_q;
        assign c_back = {SEQW{1'b0}} - d_q;
    end else begin : g_rxc
        assign c_diff = c_seq - exp_seq;
        assign c_back = exp_seq - c_seq;
    end endgenerate
    wire            c_good   = c_v && c_crc_ok;
    wire            c_crcerr = c_v && !c_crc_ok;
    wire            c_inord  = c_good && (c_diff == 0);
    wire            c_full   = (fill == CREDITS[CW-1:0]);
    assign          c_acc    = c_inord && !c_full;
    wire            c_ovf    = c_inord && c_full;
    wire            c_ahead  = c_good && (c_diff != 0) && (c_diff < HALF);
    wire            c_behind = c_good && (c_diff >= HALF);
    wire            c_unexpl = (c_ahead && (c_diff >= RPS)) || (c_behind && (c_back > RPS));
    wire            c_nak    = (c_crcerr || c_ahead) && !nak_sent;
    wire            drain    = (fill != 0) && (!out_valid_r || out_ready);

    ot_s81ph_mem1r1w #(.W(W + 1), .DEPTH(CREDITS), .SRAM(SRAM), .WREG(MWR)) u_fifo (.clk(clk), .rst_n(rst_n),
        .we(c_acc), .wa(tail), .wd({c_last, c_data}), .re(drain), .ra(head), .q(fifo_q));

    reg  [SEQW-1:0] tx_ack;
    reg  [CW-1:0]   tx_fr;
    reg  [KW-1:0]   ka;
    wire            rg_need = nak_req || dup_req || (exp_seq != tx_ack) || (freed != tx_fr) || (ka == 0);
    wire [RVW-1:0]  rg_pay  = {nak_req, exp_seq, freed};
    wire [31:0]     rg_crc;
    ot_link_crc32 #(.W(RVW)) u_rv_crc_gen (.d(rg_pay), .crc(rg_crc));
    reg             rg_v;
    reg  [RFW-1:0]  rg_f;
    assign r_tx_v = rg_v;
    assign r_tx   = rg_f;

    // ======================================================================== state
    reg  [3:0] fault_n;
    always @* begin
        fault_n = 4'd0;
        if      (retry_exh)                  fault_n = 4'd1;
        else if (ack_bad)                    fault_n = 4'd2;
        else if (c_ovf)                      fault_n = 4'd3;
        else if (accept && (occ >= RPS))     fault_n = 4'd4;
        else if (fr_bad)                     fault_n = 4'd5;
        else if (c_unexpl)                   fault_n = 4'd6;
    end
    wire pace_ok_launch = (pace >= PTH2);
    wire pace_ok_inc    = ({1'b0, pace} + {1'b0, PNUM_W}) >= {1'b0, PCOST_W};
    wire [SEQW-1:0] nxt_nx = accept ? nxt + 1'b1 : nxt;
    wire [SEQW-1:0] snd_nx = rewind ? una_n : (ack_skip ? rr_ack : snd_l);
`ifdef OT_DSROM_LINK_MUT_FREECREDIT
    wire            cred_ok_nx = 1'b1;
`else
    wire [CW-1:0]   cred_nx = credits - {{(CW-1){1'b0}}, accept} + ((rr_ok && !fr_bad) ? d_fr : {CW{1'b0}});
    wire            cred_ok_nx = cred_nx != 0;
`endif
    wire            pace_ok_nx = (PHY_NUM == 0) ? 1'b1 : (launch ? pace_ok_launch : (!pace_ok ? pace_ok_inc : pace_ok_r));
    wire [SEQW-1:0] occ_nx = nxt_nx - una_n;
    // PIPE 2: the same next-state functions for accept = 0 (_0) and accept = 1 (_1)
    wire            lnch_0 = replaying && pace_ok;
    wire [SEQW-1:0] sndl_0 = lnch_0 ? snd + 1'b1 : snd, sndl_1 = snd + 1'b1;
    wire [IW-1:0]   sndil_0 = lnch_0 ? idx_add(snd_i, 1) : snd_i, sndil_1 = idx_add(snd_i, 1);
    wire            skip_0 = ack_ok && (d_ack > (sndl_0 - una)), skip_1 = ack_ok && (d_ack > (sndl_1 - una));
    wire [SEQW-1:0] sndnx_0 = rewind ? una_n : (skip_0 ? rr_ack : sndl_0);
    wire [SEQW-1:0] sndnx_1 = rewind ? una_n : (skip_1 ? rr_ack : sndl_1);
    wire [IW-1:0]   sndinx_0 = (rewind || skip_0) ? una_i_n : sndil_0;
    wire [IW-1:0]   sndinx_1 = (rewind || skip_1) ? una_i_n : sndil_1;
    wire [SEQW-1:0] nxtnx_1 = nxt + 1'b1;
    wire [CW-1:0]   cred_r  = credits + ((rr_ok && !fr_bad) ? d_fr : {CW{1'b0}});
    wire [CW-1:0]   cred_1  = cred_r - 1'b1;
    wire            pok_0   = (PHY_NUM == 0) ? 1'b1 : (lnch_0 ? pace_ok_launch : (!pace_ok ? pace_ok_inc : pace_ok_r));
    wire            pok_1   = (PHY_NUM == 0) ? 1'b1 : pace_ok_launch;
`ifdef OT_DSROM_LINK_MUT_FREECREDIT
    wire            cok_0 = 1'b1, cok_1 = 1'b1;
`else
    wire            cok_0 = cred_r != 0, cok_1 = cred_1 != 0;
`endif
    wire            rdy_0 = cok_0 && ((nxt - una_n) < RPS) && (sndnx_0 == nxt) && pok_0;
    wire            rdy_1 = cok_1 && ((nxtnx_1 - una_n) < RPS) && (sndnx_1 == nxtnx_1) && pok_1;
    wire            rep_0 = sndnx_0 != nxt, rep_1 = sndnx_1 != nxtnx_1;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            una <= 0; snd <= 0; nxt <= 0; una_i <= 0; snd_i <= 0; nxt_i <= 0; rdy_r <= 1'b1; rep_r <= 1'b0;
            credits <= CREDITS[CW-1:0]; fr_seen <= 0; timer <= 0; at_lim <= 1'b0; retry <= 0;
            pace <= PCOST_W; pace_ok_r <= 1'b1; rb_fwd <= 1'b0; rb_fwd_d <= 0;
            rr_v <= 1'b0; rr_f <= 0; rr_crc_ok <= 1'b0;
            exp_seq <= 0; nak_sent <= 1'b0; nak_req <= 1'b0; dup_req <= 1'b0;
            freed <= 0; fill <= 0; head <= 0; tail <= 0;
            out_valid_r <= 1'b0;
            tx_ack <= 0; tx_fr <= 0; ka <= KEEPALIVE[KW-1:0] - 1'b1;
            rg_v <= 1'b0; rg_f <= 0;
            fault <= 1'b0; fault_code <= 4'd0; credit_stalls <= 0;
            st_flits_tx <= 0; st_flits_rx_ok <= 0; st_crc_err <= 0; st_naks <= 0;
            st_replays <= 0; st_timeouts <= 0; st_retx_flits <= 0; st_max_replay_occ <= 0;
        end else begin
            if (PHY_NUM != 0) begin
                if (launch)        begin pace <= pace - PCOST_W + PNUM_W; pace_ok_r <= pace_ok_launch; end
                else if (!pace_ok) begin pace <= pace + PNUM_W;           pace_ok_r <= pace_ok_inc;    end
            end
            rb_fwd <= accept && (nxt_i == snd_i_nx);
            if (accept || MWR != 0) rb_fwd_d <= {in_last, in_data};
            if (accept) begin
                nxt   <= nxt + 1'b1;
                nxt_i <= idx_add(nxt_i, 1);
            end
            una <= una_n; una_i <= una_i_n;
            if (PIPE >= 2) begin
                rdy_r <= accept ? rdy_1 : rdy_0;
                rep_r <= accept ? rep_1 : rep_0;
                snd   <= accept ? sndnx_1 : sndnx_0;
                snd_i <= accept ? sndinx_1 : sndinx_0;
            end else begin
            rdy_r <= cred_ok_nx && (occ_nx < RPS) && (snd_nx == nxt_nx) && pace_ok_nx;
            rep_r <= snd_nx != nxt_nx;
            if (rewind) begin
                snd <= una_n; snd_i <= una_i_n;
            end else if (ack_skip) begin
                snd <= rr_ack; snd_i <= una_i_n;
            end else begin
                snd <= snd_l; snd_i <= snd_i_l;
            end
            end
`ifdef OT_DSROM_LINK_MUT_FREECREDIT
            credits <= credits;
`else
            if (PIPE >= 2) credits <= accept ? cred_1 : cred_r;
            else credits <= credits - {{(CW-1){1'b0}}, accept} + ((rr_ok && !fr_bad) ? d_fr : {CW{1'b0}});
`endif
            if (rr_ok) fr_seen <= rr_fr;
            if (occ == 0 || progress || rewind) begin timer <= 0; at_lim <= 1'b0; end
            else if (TOREG ? !at_lim : (timer != ATO_W)) begin timer <= timer + 1'b1; at_lim <= (timer + 1'b1 == ATO_S); end
            if (progress) retry <= {{(RCW-1){1'b0}}, rewind};
            else if (rewind && retry <= MR_W) retry <= retry + 1'b1;
            rr_v <= r_rx_v; rr_f <= r_rx; rr_crc_ok <= (r_rx_crc == r_rx[31:0]);

            if (c_acc) begin
                tail <= (tail == PLAST) ? {PW{1'b0}} : tail + 1'b1;
                exp_seq <= exp_seq + 1'b1;
                nak_sent <= 1'b0;
            end else if (c_nak) begin
                nak_sent <= 1'b1;
            end
            if (drain) begin
                head <= (head == PLAST) ? {PW{1'b0}} : head + 1'b1;
                out_valid_r <= 1'b1;
                freed <= freed + 1'b1;
            end else if (out_valid_r && out_ready) begin
                out_valid_r <= 1'b0;
            end
            fill <= fill + {{(CW-1){1'b0}}, c_acc} - {{(CW-1){1'b0}}, drain};

            rg_v <= rg_need;
            rg_f <= {rg_pay, rg_crc};
            if (rg_need) begin
                tx_ack <= exp_seq; tx_fr <= freed; ka <= KEEPALIVE[KW-1:0] - 1'b1;
                nak_req <= 1'b0; dup_req <= 1'b0;
            end else begin
                ka <= ka - 1'b1;
            end
            if (c_nak) nak_req <= 1'b1;
            if (c_behind) dup_req <= 1'b1;

            if (fault_n != 0 && !fault) begin fault <= 1'b1; fault_code <= fault_n; end
            if (in_valid && !in_ready) credit_stalls <= credit_stalls + 1;
            if (launch) st_flits_tx <= st_flits_tx + 1;
            if (launch && replaying) st_retx_flits <= st_retx_flits + 1;
            if (c_acc) st_flits_rx_ok <= st_flits_rx_ok + 1;
            st_crc_err <= st_crc_err + {31'd0, c_crcerr} + {31'd0, rr_bad};
            if (rg_need && nak_req) st_naks <= st_naks + 1;
            if (rewind) st_replays <= st_replays + 1;
            if (timeout) st_timeouts <= st_timeouts + 1;
            if ({{(32-SEQW){1'b0}}, occ} > st_max_replay_occ) st_max_replay_occ <= {{(32-SEQW){1'b0}}, occ};
        end
    end
endmodule
