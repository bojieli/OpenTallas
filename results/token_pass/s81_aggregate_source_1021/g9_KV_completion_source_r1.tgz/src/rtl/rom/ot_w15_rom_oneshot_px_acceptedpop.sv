`timescale 1ns/1ps
// ---------------------------------------------------------------------------
// ot_w15_rom_oneshot_die_px: the one-shot collective engine of a 4-die tensor group
// that spans a PACKAGE PAIR (V4.1 option (b): two 2-die packages; UCIe inside
// a package, the T1 board link between packages -- docs/ARCH_V41_RACK.md,
// R-L9), with three changes to ot_rom_oneshot_die (rtl/rom/
// ot_rom_oneshot_allreduce.sv, left as it is).  Same arithmetic, same bits:
// the all-reduce is still ((p0 + p1) + p2) + p3 in rank order
// (tools/hdc_golden.fold), and the all-gather still delivers index-major, rank
// order.  Gate C7 / O2 lever bench: tools/rtl_v41_collective_levers_campaign.py.
//
// 1. RECEIVE-SIDE RELAY (RELAY = 1).  The one-shot broadcasts every word to
//    BOTH dies of the partner package, so every word crosses the package
//    boundary twice and the T1 links (13 lanes per die pair) carry the whole
//    partial each.  Here word k (index parity p = k mod 2) of a die goes over
//    T1 only to the partner-package die whose in-package index is p; that die
//    pushes it into its own FIFO and relays it, the cycle it lands, over UCIe
//    to its package peer.  Each T1 link carries half the words; UCIe (4.2 TB/s,
//    26x a T1 link) carries the relayed half.  No link gets new bandwidth.
//    The receive FIFOs are split by index parity, so each (source, parity)
//    stream has exactly one writer (direct link, or relay), and credits are
//    kept per (destination, parity): a sender needs a credit for parity p at
//    EVERY destination, and the relayed copy's credit comes back from the die
//    that pops it, over that die's own T1 link to the sender (full mesh).
//    With RELAY = 0 every word goes to every die directly (the original
//    one-shot schedule, on the parity-split FIFOs).
// 2. ADD_LAT = 3 selects ot_hdc_fp32_add_fast (rtl/hdc/ot_hdc_fastfp.sv, the
//    spec's 3-cycle binary32 add, bit-identical to ot_fp32_add_rne_pipe);
//    ADD_LAT = 5 keeps the qualified five-stage pipe.
// 3. GATHER EMISSION GW words wide, no bubble.  The engine pops all N words of
//    an index into its head registers in one cycle (as before); it now emits
//    them GW per cycle (GW = N: the whole index in one beat) and pops the next
//    index in the cycle it emits the last beat of this one.  The original
//    emits one word per cycle and waits a cycle between indices (5 cycles per
//    4 words), which made the KV-rows all-gather engine-bound.
//
// Record: {tag, mode, last, par, data}; par is the word's index parity.
// FAIL CLOSED as before, plus: a head whose parity is not the pop parity, or a
// direct and a relayed record for the same (source, parity) FIFO in one cycle,
// faults (code bit 1).
// ---------------------------------------------------------------------------
module ot_w15_rom_oneshot_die_px_acceptedpop #(
    parameter integer FIX_ACCEPTED_POP = 0, // baseline accepted-transfer accounting fix
    parameter integer N        = 4,
    parameter integer RANK     = 0,
    parameter integer LANES    = 16,
    parameter integer TAGW     = 32,
    parameter integer DEPTH    = 16,           // receive words per source (both parities; power of two, >= 2)
    parameter integer PKG_DIES = 2,
    parameter integer RELAY    = 1,
    parameter integer ADD_LAT  = 3,            // 3: ot_hdc_fp32_add_fast, 5: ot_fp32_add_rne_pipe
    parameter integer PAIRWISE = 0,            // full-shape wo_b: ((r0+r1)+(r2+r3))
    parameter integer GW       = 1,            // gather words emitted per cycle (divides N)
    parameter integer OUT_BP   = 0,            // GW=N gather may hold output until out_ready
    parameter integer FPLAT    = 0,            // 1: ot_hdc_fp32_add_lat #(ADD_LAT) (3..7 stages, bit-identical to the fast add)
    parameter integer FIFO_SRAM = 0,           // 1: receive FIFOs in 1R1W SRAM macros (rtl/link/ot_fifo_sram_fwft.sv)
    parameter integer SRAM_MACRO = 1,          //    macro kind (0 64x512, 1 256x256, 2 128x256); DEPTH/2 <= its words
    // PULL (ds-1010 2026-10-10, opt-in, FIFO_SRAM only): each (source, parity) SRAM FIFO streams its head into a small
    // central landing queue over a registered credit link (ot_link_credit tx DFREE / rx WFREE, PULL_D deep), so the pop
    // decision (ppar -> per-source nonempty -> all_ne -> pop) reads and pops only central flops.  CE split3cra pre-route
    // -794 ps = ppar -> 8 FIFOs spread over the 680 um tile -> all_ne -> pop -> back to every FIFO's 547-bit output
    // buffer enables: ~1,000 ps of wire across the tile in one cycle.  Each FIFO now pops itself (local credit only).
    // +2 cycles a record from FIFO head to the decision; full rate while the landing queue covers the credit loop.
    parameter integer PULL     = 0,
    parameter integer PULL_D   = 4,
    // PCOPY (fe-push-ds-1010 2026-10-10, opt-in, PULL only; 0 = byte-identical): per source r, (* keep *) register copies
    // of the pop-decision state (ppar, s0_v, s0_mode, g_busy, g_cnt, go_v, inflight==0) compute a LOCAL pop_k[r] that
    // drives only source r: its head[r] parity select (547-bit 2:1 mux), its two landing-queue o_ready and its s0_d[r] /
    // s0_t[r] load enables (512 + 35 flops).  The single pop / ppar nets otherwise fan out to ~4 x 1,100 loads spread
    // over the four source groups (hardcore-1010 feasibility (b) for dsfd_coll_ce).  The copies load the same D as the
    // master registers (identical function), so pop_k[r] == pop every cycle; 0 cycles.
    parameter integer PCOPY    = 0,
    // PSL (el1011-ds-coll 2026-10-11, opt-in, PULL+PCOPY only; 1 = byte-identical): PSL kept copies of the pop control
    // per source, one per FW/PSL-bit slice of s0_d, each enabling only its own slice (ce pre-route crplf -1,799 =
    // u_pr.rp -> head mux -> head_mode -> pop -> 4 x 547 s0 enables; PCOPY cut it to 547 loads per copy, PSL to
    // FW/PSL (+ tag on slice 0)).  LQW: the landing queues' WFREE (2 = registered non-empty / write enables).
    parameter integer PSL      = 1,
    parameter integer LQW      = 1,
    // EXTF (el1011-ds-coll 2026-10-11, opt-in, PULL + FIFO_SRAM only; 0 = byte-identical): the REMOTE sources' receive
    // FIFOs live outside the engine (hardened FIFO tiles, dsfd_coll_cef): for g != RANK the landing queue u_pr is fed
    // from xl_v / xl_d and returns xl_cr, push / clash / occupancy of those FIFOs are kept by the FIFO tile, and rx_* /
    // rl_* are unused.  The local source's FIFO stays here (its pushes are this engine's fires).
    parameter integer EXTF     = 0,
    // RHOLD (el1011-ds-coll 2026-10-11, opt-in; 0 = byte-identical): reduce pops wait while red_hold is high (the
    // consumer has no reserved output slot for another reduce word; slow-VM-drain overflow fix), out_rpop = a reduce pop
    parameter integer RHOLD    = 0,
    // LSEAM (s81-cesn 2026-10-13, opt-in, PAIRWISE N 4 ADD_LAT 3 only; 0 = byte-identical): the ONE seam-latency switch of
    // the split lane-slice (dsfd_coll_ces SEAM).  The pairwise FP32 lanes live OUTSIDE the engine in hardened lane leaves
    // (dsfd_coll_cesl): s0_d / red_in leave on ln_v / ln_d into the leaf's pin flops, the sum returns on ln_y / ln_yv /
    // ln_ye / ln_pe and lands in flops here, so the reduce path is 2 * ADD_LAT + 2 cycles (ldl follows).  Nothing counts
    // cycles on that path: inflight (pop_red +1, red_out -1) and the consumer's reserved slots are counts.
    // XF_D: landing depth of the EXTF queues u_pr (their sender is then a relay leaf with XF_D credits).
    parameter integer LSEAM    = 0,
    parameter integer XF_D     = PULL_D,
    parameter integer FW       = 32 * LANES,
    parameter integer PW       = FW + 3 + TAGW, // {tag, mode, last, par, data}
    parameter integer RB       = (N > 1) ? $clog2(N) : 1
) (
    input  wire              clk,
    input  wire              rst_n,
    input  wire              in_valid,
    output wire              in_ready,
    input  wire [FW-1:0]     in_data,
    input  wire              in_last,
    input  wire              in_mode,
    input  wire [TAGW-1:0]   in_tag,
    // transmit: one record, a valid per destination link
    output wire [N-1:0]      tx_valid,
    output wire [PW-1:0]     tx_rec,
    input  wire [N-1:0]      tx_ready,
    input  wire [2*N-1:0]    cr_in,           // [2t + p]: a parity-p credit back from destination t
    // receive, direct link from every remote source
    input  wire [N-1:0]      rx_valid,
    input  wire [N*PW-1:0]   rx_rec,
    output wire [2*N-1:0]    cr_out,          // [2r + p]: a parity-p credit back to source r
    // relay to / from the package peer (one channel per source rank)
    output wire [N-1:0]      rl_tx_valid,
    output wire [N*PW-1:0]   rl_tx_rec,
    input  wire [N-1:0]      rl_rx_valid,
    input  wire [N*PW-1:0]   rl_rx_rec,
    // result
    output wire              out_valid,
    input  wire              out_ready,
    output wire [GW*FW-1:0]  out_data,
    output wire              out_last,
    output wire [RB-1:0]     out_rank,
    output wire              out_err,
    // el1011-ds-coll: unmuxed views of the output (a consumer may register the reduce word without the go_v-steered
    // GW*FW-bit out_data mux in front of it): out_red = a reduce word this cycle, out_rdat its data, out_gdat the
    // gather beat (valid when out_valid && !out_red)
    output wire              out_red,
    output wire [FW-1:0]     out_rdat,
    output wire [GW*FW-1:0]  out_gdat,
    output reg               fault,
    output reg  [2:0]        fault_code,      // [0] arithmetic, [1] tag / mode / parity / relay, [2] FIFO overflow
    // EXTF: landing-queue links of the external FIFOs, [2g + q] = source g parity q (g == RANK unused)
    input  wire              red_hold,
    output wire              out_rpop,
    input  wire [2*N-1:0]    xl_v,
    input  wire [2*N*PW-1:0] xl_d,
    output wire [2*N-1:0]    xl_cr,
    // LSEAM: lane seam (ln_d = {s0_d[3], s0_d[2], s0_d[1], s0_d[0]}; ln_pe = the first-level adders' error, aligned to ln_ye)
    output wire              ln_v,
    output wire [N*FW-1:0]   ln_d,
    input  wire [FW-1:0]     ln_y,
    input  wire [LANES-1:0]  ln_yv,
    input  wire [2*LANES-1:0] ln_ye,
    input  wire [LANES-1:0]  ln_pe
);
    localparam integer PD = DEPTH / 2;                  // words per (source, parity) FIFO
    localparam integer DB = (PD > 1) ? $clog2(PD) : 1;
    localparam integer CB = $clog2(PD + 1);
    localparam integer DL = ((PAIRWISE != 0 && N == 4) ? 2 : (N - 1)) * ADD_LAT + ((LSEAM != 0) ? 2 : 0);
    localparam integer E  = N / GW;                     // gather beats per index
    localparam integer EB = (E > 1) ? $clog2(E) : 1;
    localparam integer MYPKG = RANK / PKG_DIES;
    localparam integer PAR_B = FW;                      // record bit positions
    localparam integer LAST_B = FW + 1;
    localparam integer MODE_B = FW + 2;

    function automatic same_pkg(input integer t);
        same_pkg = (t / PKG_DIES) == MYPKG;
    endfunction

    integer r, p;
    genvar g, q;

    // -- transmit ----------------------------------------------------------------------
    reg          lpar;                                  // index parity of the next local word
    reg [CB-1:0] cr  [0:2*N-1];                         // credits per (destination, parity)
    reg [CB:0]   cnt [0:2*N-1];                         // FIFO occupancy per (source, parity)
    reg [N-1:0]  uses, can_tx;
    always @(*) begin
        for (r = 0; r < N; r = r + 1) begin
            uses[r] = (r != RANK) && (same_pkg(r) || RELAY == 0 || (r % PKG_DIES) == lpar);
            if (r == RANK) can_tx[r] = cnt[2*r + lpar] < PD;
            else can_tx[r] = (cr[2*r + lpar] != 0) && (!uses[r] || tx_ready[r]);
        end
    end
    assign in_ready = &can_tx;
    wire fire = in_valid && in_ready;
    assign tx_valid = fire ? uses : {N{1'b0}};
    assign tx_rec = {in_tag, in_mode, in_last, lpar, in_data};

    // -- receive: every (source, parity) FIFO has one writer ------------------------------
    // (one generate block per FIFO with static selects: a combinational loop writing arrays at a dynamic index
    // elaborates to tens of GB in Verilator at 128 lanes)
    reg           ppar;                                 // index parity of the next pop
    wire [2*N-1:0] push;
    wire [2*N-1:0] clash;
    wire [2*N-1:0] hvf;                                 // head valid per (source, parity) FIFO
    wire [N-1:0]  nonempty;
    wire [PW-1:0] head [0:N-1];
    wire [PW-1:0] hd [0:2*N-1];
    wire          pop;
    (* keep = "true" *) reg [N*PSL-1:0] ppar_k;             // PCOPY: per-source copies (constant 0 otherwise)
    wire [N*PSL-1:0] pop_k;
    generate
        for (g = 0; g < N; g = g + 1) begin : g_src
            wire dpar = rx_rec[g*PW + PAR_B];
            wire rpar = rl_rx_rec[g*PW + PAR_B];
            wire rl_on = (RELAY != 0) && (g != RANK) && ((g / PKG_DIES) != MYPKG);
            for (q = 0; q < 2; q = q + 1) begin : g_par
                localparam integer F = 2 * g + q;
                wire          pd_ = (g == RANK) ? (fire && lpar == q) : ((EXTF == 0) && rx_valid[g] && dpar == q);
                wire          pr_ = rl_on && rl_rx_valid[g] && rpar == q;
                wire [PW-1:0] rec = (g == RANK) ? tx_rec : (pd_ ? rx_rec[g*PW +: PW] : rl_rx_rec[g*PW +: PW]);
                assign push[F] = pd_ || pr_;
                assign clash[F] = pd_ && pr_;
                if (FIFO_SRAM != 0) begin : g_sram
                    if (PULL != 0 && EXTF != 0 && g != RANK) begin : g_xf
                        // external FIFO: only the landing queue is here
                        wire pq_ = (PCOPY != 0) ? (pop_k[g*PSL] && ppar_k[g*PSL] == q) : (pop && ppar == q);
                        ot_link_credit_rx #(.W(PW), .DEPTH(XF_D), .OREG(0), .WFREE(LQW)) u_pr (.clk(clk), .rst_n(rst_n),
                            .l_valid(xl_v[F]), .l_data(xl_d[F*PW +: PW]), .l_credit(xl_cr[F]), .o_valid(hvf[F]), .o_ready(pq_),
                            .o_data(hd[F]), .fault());
                    end else if (PULL != 0) begin : g_pull
                        assign xl_cr[F] = 1'b0;
                        wire fhv, f_rdy, lv, lc; wire [PW-1:0] fhd, ld;
                        // the landing-queue pop: the source's local copy under PCOPY, else the shared pop
                        wire pq_ = (PCOPY != 0) ? (pop_k[g*PSL] && ppar_k[g*PSL] == q) : (pop && ppar == q);
                        ot_fifo_sram_fwft #(.W(PW), .DEPTH(PD), .MACRO(SRAM_MACRO)) u_f (
                            .clk(clk), .rst_n(rst_n), .push(push[F]), .wdata(rec), .pop(fhv && f_rdy),
                            .hv(fhv), .head(fhd), .ovf());
                        ot_link_credit_tx #(.W(PW), .CRED(PULL_D), .DFREE(1)) u_pt (.clk(clk), .rst_n(rst_n),
                            .i_valid(fhv), .i_ready(f_rdy), .i_data(fhd), .l_valid(lv), .l_data(ld), .l_credit(lc));
`ifdef OT_W15_PULL_MUT
                        // bench mutant: the landing queue returns its credit on arrival instead of on pop (overruns)
                        wire lc_m;
                        ot_link_credit_rx #(.W(PW), .DEPTH(PULL_D), .OREG(0), .WFREE(LQW)) u_pr (.clk(clk), .rst_n(rst_n),
                            .l_valid(lv), .l_data(ld), .l_credit(lc_m), .o_valid(hvf[F]), .o_ready(pq_),
                            .o_data(hd[F]), .fault());
                        reg lc_r; always @(posedge clk or negedge rst_n) if (!rst_n) lc_r <= 1'b0; else lc_r <= lv;
                        assign lc = lc_r;
`else
                        ot_link_credit_rx #(.W(PW), .DEPTH(PULL_D), .OREG(0), .WFREE(LQW)) u_pr (.clk(clk), .rst_n(rst_n),
                            .l_valid(lv), .l_data(ld), .l_credit(lc), .o_valid(hvf[F]), .o_ready(pq_),
                            .o_data(hd[F]), .fault());
`endif
                    end else begin : g_direct
                    assign xl_cr[F] = 1'b0;
                    ot_fifo_sram_fwft #(.W(PW), .DEPTH(PD), .MACRO(SRAM_MACRO)) u_f (
                        .clk(clk), .rst_n(rst_n), .push(push[F]), .wdata(rec), .pop(pop && ppar == q),
                        .hv(hvf[F]), .head(hd[F]), .ovf());
                    end
                end else begin : g_flop
                    assign xl_cr[F] = 1'b0;
                    reg [PW-1:0] m [0:PD-1];
                    reg [DB-1:0] wp, rp;
                    always @(posedge clk) if (push[F]) m[wp] <= rec;
                    always @(posedge clk or negedge rst_n)
                        if (!rst_n) begin wp <= 0; rp <= 0; end
                        else begin
                            if (push[F]) wp <= wp + 1'b1;
                            if (pop && ppar == q) rp <= rp + 1'b1;
                        end
                    assign hd[F] = m[rp];
                    assign hvf[F] = cnt[F] != 0;
                end
            end
            assign nonempty[g] = ppar ? hvf[2*g + 1] : hvf[2*g];
            if (PULL != 0 && PCOPY != 0) begin : g_hk
                assign head[g] = ppar_k[g*PSL] ? hd[2*g + 1] : hd[2*g];
            end else begin : g_hm
                assign head[g] = ppar ? hd[2*g + 1] : hd[2*g];
            end
            // a record landing from a partner-package source is relayed to the package peer the cycle it lands
            if (RELAY != 0 && g != RANK && (g / PKG_DIES) != MYPKG) begin : g_on
                assign rl_tx_valid[g] = rx_valid[g];
                assign rl_tx_rec[g*PW +: PW] = rx_rec[g*PW +: PW];
            end else begin : g_off
                assign rl_tx_valid[g] = 1'b0;
                assign rl_tx_rec[g*PW +: PW] = {PW{1'b0}};
            end
        end
    endgenerate
    wire relay_clash = |clash;
    wire head_mode = head[0][MODE_B];
    wire head_last = head[0][LAST_B];

    // -- pop -------------------------------------------------------------------------------
    reg           g_busy;                               // beats 1..E-1 of a gathered index being emitted
    reg  [EB-1:0] g_cnt;
    reg  [15:0]   inflight;
    reg           s0_v, s0_mode, s0_last;
    reg  [FW-1:0] s0_d [0:N-1];
    reg              go_v, go_last;
    wire g_stall = (OUT_BP != 0) && (GW == N) && go_v && !out_ready;
    wire all_ne = &nonempty;
    wire g_first = s0_v && s0_mode;                     // beat 0 of the index in the head registers
    wire g_idle = !g_busy && !g_first;
    // the head registers are free after this cycle when the emitter is idle or emits the index's last beat now
    wire g_free = g_idle || (g_busy && g_cnt == E - 1) || (g_first && E == 1);
    wire rh = (RHOLD != 0) && red_hold;
    wire pop_red = all_ne && g_idle && !head_mode && !rh;
    assign out_rpop = pop && pop_red;
    wire pop_gat = all_ne && head_mode && inflight == 0 && g_free && !(s0_v && !s0_mode);
    assign pop = (pop_red || pop_gat) && !g_stall;
    generate
        for (g = 0; g < N; g = g + 1) begin : g_cr
            for (q = 0; q < 2; q = q + 1) begin : g_p
                if (g == RANK) begin : g_l
                    assign cr_out[2*g + q] = 1'b0;
                end else begin : g_r
                    assign cr_out[2*g + q] = pop && (ppar == q);
                end
            end
        end
    endgenerate

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            lpar <= 1'b0; ppar <= 1'b0;
            for (r = 0; r < 2 * N; r = r + 1) begin
                cr[r] <= PD; cnt[r] <= 0;
            end
        end else begin
            if (fire) lpar <= in_last ? 1'b0 : ~lpar;
            if (pop) ppar <= head_last ? 1'b0 : ~ppar;
            for (r = 0; r < 2 * N; r = r + 1) begin
                if ((r / 2) != RANK)
                    cr[r] <= cr[r] - ((fire && (r % 2) == lpar) ? 1'b1 : 1'b0) + (cr_in[r] ? 1'b1 : 1'b0);
                if (EXTF == 0 || (r / 2) == RANK)       // EXTF: the FIFO tile keeps the remote FIFOs' occupancy
                    cnt[r] <= cnt[r] + (push[r] ? 1'b1 : 1'b0) - ((pop && (r % 2) == ppar) ? 1'b1 : 1'b0);
            end
        end
    end

    // -- head stage -------------------------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s0_v <= 1'b0; s0_mode <= 1'b0; s0_last <= 1'b0;
        end else if (!g_stall) begin
            s0_v <= pop;
            if (pop) begin s0_mode <= head_mode; s0_last <= head_last; end
        end
    end
    reg [TAGW+1:0] s0_t [0:N-1];                        // {tag, mode, par}
    generate if (PULL != 0 && PCOPY != 0 && PSL == 1) begin : g_s0k
        for (g = 0; g < N; g = g + 1) begin : g_r
            always @(posedge clk) if (pop_k[g]) begin
                s0_d[g] <= head[g][FW-1:0];
                s0_t[g] <= {head[g][PW-1 -: TAGW + 1], head[g][PAR_B]};
            end
        end
    end else if (PULL != 0 && PCOPY != 0) begin : g_s0s
        localparam integer SW = FW / PSL;
        integer k2;
        always @(posedge clk)
            for (k2 = 0; k2 < N * PSL; k2 = k2 + 1) if (pop_k[k2]) begin
                s0_d[k2 / PSL][(k2 % PSL) * SW +: SW] <= ppar_k[k2] ? hd[2 * (k2 / PSL) + 1][(k2 % PSL) * SW +: SW]
                                                                     : hd[2 * (k2 / PSL)][(k2 % PSL) * SW +: SW];
                if (k2 % PSL == 0)
                    s0_t[k2 / PSL] <= ppar_k[k2] ? {hd[2 * (k2 / PSL) + 1][PW-1 -: TAGW + 1], hd[2 * (k2 / PSL) + 1][PAR_B]}
                                                 : {hd[2 * (k2 / PSL)][PW-1 -: TAGW + 1], hd[2 * (k2 / PSL)][PAR_B]};
            end
    end else begin : g_s0m
    always @(posedge clk) if (pop) for (r = 0; r < N; r = r + 1) begin
        s0_d[r] <= head[r][FW-1:0];
        s0_t[r] <= {head[r][PW-1 -: TAGW + 1], head[r][PAR_B]};
    end
    end endgenerate
    reg s0_ppar;
    always @(posedge clk) if (pop) s0_ppar <= ppar;
    reg agree;
    always @(*) begin
        agree = (s0_t[0][0] == s0_ppar);
        for (r = 1; r < N; r = r + 1) if (s0_t[r] != s0_t[0]) agree = 1'b0;
    end

    // -- all-reduce ---------------------------------------------------------------------
    // Reduced programs retain the historical rank-linear fold.  Full-shape
    // wo_b uses the golden's aligned chunk-8 subtree: ((r0+r1)+(r2+r3)).
    wire red_in = s0_v && !s0_mode;
    wire [FW-1:0] red_data;
    wire red_out, red_err;
    reg [DL-1:0] ldl;
    always @(posedge clk or negedge rst_n)
        if (!rst_n) ldl <= 0;
        else ldl <= {ldl[DL-2:0], s0_last};
    // Dedicated seam launch flops capture the exact same head and enable as
    // s0_d, in the same cycle. The reset is physically distinct from the internal
    // unreset head register, so synthesis cannot merge the two owners. Payload
    // is consumed only with ln_v; adding reset changes no valid epoch or latency.
`ifdef OT_S81_CES_LNPIN
    generate for (g = 0; g < N; g = g + 1) begin : g_ln_pin
        (* keep = 1 *) reg [FW-1:0] d;
        if (PULL != 0 && PCOPY != 0 && PSL == 1) begin : g_one
            always @(posedge clk or negedge rst_n)
                if (!rst_n) d <= 0;
                else if (pop_k[g]) d <= head[g][FW-1:0];
        end else if (PULL != 0 && PCOPY != 0) begin : g_sliced
            localparam integer SW = FW / PSL;
            genvar sl;
            for (sl = 0; sl < PSL; sl = sl + 1) begin : g_sl
                always @(posedge clk or negedge rst_n)
                    if (!rst_n) d[SW*sl +: SW] <= 0;
                    else if (pop_k[g*PSL+sl])
                        d[SW*sl +: SW] <= ppar_k[g*PSL+sl]
                            ? hd[2*g+1][SW*sl +: SW] : hd[2*g][SW*sl +: SW];
            end
        end else begin : g_shared
            always @(posedge clk or negedge rst_n)
                if (!rst_n) d <= 0;
                else if (pop) d <= head[g][FW-1:0];
        end
`ifndef SYNTHESIS
        always @(negedge clk) if (rst_n && ln_v && d !== s0_d[g])
            $fatal(1, "CES dedicated seam register diverged at valid epoch");
`endif
`ifdef OT_S81_CES_MUT_LNPIN
        assign ln_d[g*FW +: FW] = d ^ {{(FW-1){1'b0}}, 1'b1};
`else
        assign ln_d[g*FW +: FW] = d;
`endif
    end endgenerate
`else
    generate for (g = 0; g < N; g = g + 1) begin : g_lnd
        assign ln_d[g*FW +: FW] = s0_d[g];
    end endgenerate
`endif
    // LSEAM: ln_v leaves its OWN flop (register at the pin): lnv_q == s0_v && !s0_mode on every cycle (same enable, the
    // next value of that product: s0_v <= pop, s0_mode <= head_mode on a pop).  LSEAM 0: the port is unused.
    reg lnv_q;
    always @(posedge clk or negedge rst_n)
        if (!rst_n) lnv_q <= 1'b0;
        else if (!g_stall) lnv_q <= pop && !head_mode;
    assign ln_v = (LSEAM != 0) ? lnv_q : red_in;
`ifndef SYNTHESIS
    always @(posedge clk) if (rst_n && LSEAM != 0 && lnv_q !== red_in) begin
        $display("TB_S81PH_COLL_SYS FAIL lane-seam valid flop differs from s0_v && !s0_mode"); $fatal(1, "LSEAM ln_v"); end
`endif
    generate if (LSEAM != 0) begin : g_seam
        // landing flops of the lane leaves' output flops (pin flop both ends)
        reg [FW-1:0] y_q; reg [LANES-1:0] yv_q, pe_q; reg [2*LANES-1:0] ye_q;
        always @(posedge clk or negedge rst_n) if (!rst_n) yv_q <= 0; else yv_q <= ln_yv;
        always @(posedge clk) begin y_q <= ln_y; ye_q <= ln_ye; pe_q <= ln_pe; end
        assign red_data = y_q;
        assign red_out = yv_q[0];
        assign red_err = (|ye_q) || (|pe_q);
        initial if (!(PAIRWISE != 0 && N == 4 && ADD_LAT == 3 && FPLAT == 0)) $fatal(1, "LSEAM needs PAIRWISE, N 4, ADD_LAT 3");
    end else if (PAIRWISE != 0 && N == 4) begin : g_pairwise
        wire [FW-1:0] ab, cd, y;
        wire [LANES-1:0] av, cv, yv;
        wire [2*LANES-1:0] ae, ce, ye;
        reg [ADD_LAT-1:0] err_delay;
        always @(posedge clk or negedge rst_n)
            if (!rst_n) err_delay <= 0;
            else err_delay <= {err_delay[ADD_LAT-2:0], (|ae) || (|ce)};
        for (g = 0; g < LANES; g = g + 1) begin : g_lane
            if (FPLAT != 0) begin : g_lat
                ot_hdc_fp32_add_lat #(.LAT(ADD_LAT)) u_ab (.clk(clk), .rst_n(rst_n), .valid_in(red_in),
                    .a(s0_d[0][32*g +: 32]), .b(s0_d[1][32*g +: 32]),
                    .y(ab[32*g +: 32]), .err(ae[2*g +: 2]), .valid_out(av[g]));
                ot_hdc_fp32_add_lat #(.LAT(ADD_LAT)) u_cd (.clk(clk), .rst_n(rst_n), .valid_in(red_in),
                    .a(s0_d[2][32*g +: 32]), .b(s0_d[3][32*g +: 32]),
                    .y(cd[32*g +: 32]), .err(ce[2*g +: 2]), .valid_out(cv[g]));
                ot_hdc_fp32_add_lat #(.LAT(ADD_LAT)) u_y (.clk(clk), .rst_n(rst_n), .valid_in(av[g]),
                    .a(ab[32*g +: 32]), .b(cd[32*g +: 32]),
                    .y(y[32*g +: 32]), .err(ye[2*g +: 2]), .valid_out(yv[g]));
            end else if (ADD_LAT == 3) begin : g_fast
                ot_hdc_fp32_add_fast u_ab (.clk(clk), .rst_n(rst_n), .valid_in(red_in),
                    .a(s0_d[0][32*g +: 32]), .b(s0_d[1][32*g +: 32]),
                    .y(ab[32*g +: 32]), .err(ae[2*g +: 2]), .valid_out(av[g]));
                ot_hdc_fp32_add_fast u_cd (.clk(clk), .rst_n(rst_n), .valid_in(red_in),
                    .a(s0_d[2][32*g +: 32]), .b(s0_d[3][32*g +: 32]),
                    .y(cd[32*g +: 32]), .err(ce[2*g +: 2]), .valid_out(cv[g]));
                ot_hdc_fp32_add_fast u_y (.clk(clk), .rst_n(rst_n), .valid_in(av[g]),
                    .a(ab[32*g +: 32]), .b(cd[32*g +: 32]),
                    .y(y[32*g +: 32]), .err(ye[2*g +: 2]), .valid_out(yv[g]));
            end else begin : g_pipe
                ot_fp32_add_rne_pipe u_ab (.clk(clk), .rst_n(rst_n), .valid_in(red_in),
                    .a(s0_d[0][32*g +: 32]), .b(s0_d[1][32*g +: 32]),
                    .y(ab[32*g +: 32]), .err(ae[2*g +: 2]), .valid_out(av[g]));
                ot_fp32_add_rne_pipe u_cd (.clk(clk), .rst_n(rst_n), .valid_in(red_in),
                    .a(s0_d[2][32*g +: 32]), .b(s0_d[3][32*g +: 32]),
                    .y(cd[32*g +: 32]), .err(ce[2*g +: 2]), .valid_out(cv[g]));
                ot_fp32_add_rne_pipe u_y (.clk(clk), .rst_n(rst_n), .valid_in(av[g]),
                    .a(ab[32*g +: 32]), .b(cd[32*g +: 32]),
                    .y(y[32*g +: 32]), .err(ye[2*g +: 2]), .valid_out(yv[g]));
            end
        end
        assign red_data = y;
        assign red_out = yv[0];
        assign red_err = (|ye) || err_delay[ADD_LAT-1];
    end else begin : g_linear
        wire [FW-1:0] sum [0:N-1];
        wire [N-1:0] sv, serr;
        assign sum[0] = s0_d[0];
        assign sv[0] = red_in;
        assign serr[0] = 1'b0;
        for (g = 1; g < N; g = g + 1) begin : g_stage
            wire [FW-1:0] pg;
            if (g == 1) begin : g_nd
                assign pg = s0_d[1];
            end else begin : g_d
                localparam integer D = (g - 1) * ADD_LAT;
                reg [FW*D-1:0] dl;
                if (D == 1) begin : g_d1
                    always @(posedge clk) dl <= s0_d[g];
                end else begin : g_dn
                    always @(posedge clk) dl <= {dl[FW*(D-1)-1:0], s0_d[g]};
                end
                assign pg = dl[FW*D-1 -: FW];
            end
            reg [ADD_LAT-1:0] edl;
            always @(posedge clk or negedge rst_n)
                if (!rst_n) edl <= 0;
                else edl <= {edl[ADD_LAT-2:0], serr[g-1]};
            wire [LANES-1:0] lv;
            wire [2*LANES-1:0] le;
            for (genvar l = 0; l < LANES; l = l + 1) begin : g_lane
                if (FPLAT != 0) begin : g_lat
                    ot_hdc_fp32_add_lat #(.LAT(ADD_LAT)) u_add (
                        .clk(clk), .rst_n(rst_n), .valid_in(sv[g-1]),
                        .a(sum[g-1][32*l +: 32]), .b(pg[32*l +: 32]),
                        .y(sum[g][32*l +: 32]), .err(le[2*l +: 2]), .valid_out(lv[l]));
                end else if (ADD_LAT == 3) begin : g_fast
                    ot_hdc_fp32_add_fast u_add (
                        .clk(clk), .rst_n(rst_n), .valid_in(sv[g-1]),
                        .a(sum[g-1][32*l +: 32]), .b(pg[32*l +: 32]),
                        .y(sum[g][32*l +: 32]), .err(le[2*l +: 2]), .valid_out(lv[l]));
                end else begin : g_pipe
                    ot_fp32_add_rne_pipe u_add (
                        .clk(clk), .rst_n(rst_n), .valid_in(sv[g-1]),
                        .a(sum[g-1][32*l +: 32]), .b(pg[32*l +: 32]),
                        .y(sum[g][32*l +: 32]), .err(le[2*l +: 2]), .valid_out(lv[l]));
                end
            end
            assign sv[g] = lv[0];
            assign serr[g] = (|le) || edl[ADD_LAT-1];
        end
        assign red_data = sum[N-1];
        assign red_out = sv[N-1];
        assign red_err = serr[N-1];
    end endgenerate

    // -- all-gather: GW words per beat, E beats per index, back to back ------------------------------
    reg [GW*FW-1:0]  go_d;
    reg [RB-1:0]     go_rank;
    wire [EB-1:0]    beat = g_busy ? g_cnt : {EB{1'b0}};
    reg  [GW*FW-1:0] beat_d;
    always @(*) begin
        for (r = 0; r < GW; r = r + 1) beat_d[r*FW +: FW] = s0_d[beat * GW + r];
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            g_busy <= 1'b0; g_cnt <= 0; go_v <= 1'b0; go_last <= 1'b0; go_rank <= 0; inflight <= 0;
        end else begin
            if (!g_stall) begin
                go_v <= 1'b0;
                if (g_busy || g_first) begin
                    go_v <= 1'b1;
                    go_d <= beat_d;
                    go_rank <= beat * GW;
                    go_last <= s0_last && beat == E - 1;
                    if (g_busy) begin
                        // the last beat; a new index popped this cycle starts its beat 0 next cycle via g_first
                        if (g_cnt == E - 1) g_busy <= 1'b0;
                        else g_cnt <= g_cnt + 1'b1;
                    end else if (E > 1) begin
                        g_busy <= 1'b1;
                        g_cnt <= 1;
                    end
                end
            end
            inflight <= inflight + ((FIX_ACCEPTED_POP ? (pop && pop_red) : pop_red) ? 1'b1 : 1'b0) - (red_out ? 1'b1 : 1'b0);
        end
    end

    // -- PCOPY: per-source pop copies -----------------------------------------------------------
    generate if (PULL != 0 && PCOPY != 0) begin : g_pcopy
        wire [15:0] infl_nx = inflight + ((FIX_ACCEPTED_POP ? (pop && pop_red) : pop_red) ? 1'b1 : 1'b0) - (red_out ? 1'b1 : 1'b0);
        for (g = 0; g < N * PSL; g = g + 1) begin : g_k
            (* keep = "true" *) reg s0v_k, s0m_k, gb_k, gov_k, iz_k;
            (* keep = "true" *) reg [EB-1:0] gc_k;
            wire ne_k  = ppar_k[g] ? &{hvf[7], hvf[5], hvf[3], hvf[1]} : &{hvf[6], hvf[4], hvf[2], hvf[0]};
            wire hm_k  = ppar_k[g] ? hd[1][MODE_B] : hd[0][MODE_B];
            wire gst_k = (OUT_BP != 0) && (GW == N) && gov_k && !out_ready;
            wire gf_k  = s0v_k && s0m_k;
            wire gi_k  = !gb_k && !gf_k;
            wire gfr_k = gi_k || (gb_k && gc_k == E - 1) || (gf_k && E == 1);
            assign pop_k[g] = ((ne_k && gi_k && !hm_k && !rh) || (ne_k && hm_k && iz_k && gfr_k && !(s0v_k && !s0m_k))) && !gst_k;
            always @(posedge clk or negedge rst_n) begin
                if (!rst_n) begin
                    ppar_k[g] <= 1'b0; s0v_k <= 1'b0; s0m_k <= 1'b0; gb_k <= 1'b0; gc_k <= 0; gov_k <= 1'b0; iz_k <= 1'b1;
                end else begin
`ifdef OT_W15_PCOPY_MUT
                    // bench mutant: source 1's parity copy never returns to 0 at an index's last word
                    if (pop) ppar_k[g] <= (head_last && g != 1) ? 1'b0 : ~ppar_k[g];
`else
                    if (pop) ppar_k[g] <= head_last ? 1'b0 : ~ppar_k[g];
`endif
                    if (!g_stall) begin
                        s0v_k <= pop;
                        if (pop) s0m_k <= head_mode;
                        gov_k <= g_busy || g_first;
                        if (g_busy) begin
                            if (g_cnt == E - 1) gb_k <= 1'b0; else gc_k <= g_cnt + 1'b1;
                        end else if (g_first && E > 1) begin
                            gb_k <= 1'b1; gc_k <= 1;
                        end
                    end
                    iz_k <= (infl_nx == 16'd0);
                end
            end
        end
    end else begin : g_nocopy
        always @(*) ppar_k = {N*PSL{1'b0}};
        assign pop_k = {N*PSL{1'b0}};
    end endgenerate

    assign out_valid = red_out || go_v;
    assign out_data  = go_v ? go_d : {{(GW-1)*FW{1'b0}}, red_data};
    assign out_last  = go_v ? go_last : ldl[DL-1];
    assign out_rank  = go_v ? go_rank : {RB{1'b0}};
    assign out_err   = red_out && red_err;
    assign out_red   = red_out;
    assign out_rdat  = red_data;
    assign out_gdat  = go_d;

    // -- faults -------------------------------------------------------------------------------
    reg ovf;
    always @(*) begin
        ovf = 1'b0;
        for (r = 0; r < 2 * N; r = r + 1) if (cnt[r] > PD) ovf = 1'b1;
    end
    reg clash_q;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            fault <= 1'b0; fault_code <= 3'b0; clash_q <= 1'b0;
        end else begin
            clash_q <= relay_clash;
            if (out_err) begin fault <= 1'b1; fault_code[0] <= 1'b1; end
            if ((s0_v && !agree) || clash_q) begin fault <= 1'b1; fault_code[1] <= 1'b1; end
            if (ovf) begin fault <= 1'b1; fault_code[2] <= 1'b1; end
        end
    end
endmodule
