`timescale 1ns/1ps
// ---------------------------------------------------------------------------
// Low-latency binary32 add and multiply (ot_hdc_qadd / ot_hdc_qmul) for the
// decode core's stream unit and special-function pipelines.
//
// Same arithmetic, bit for bit, as the qualified five-stage pipes they stand in
// for -- rtl/proto/ot_fp32_add_rne_pipe.sv and rtl/hdc/ot_hdc_fp32_mul_pipe.sv:
// IEEE RNE with gradual underflow, every zero result canonical +0, a zero
// multiplier operand giving +0, (+-0)+(+-0) = +0, and a nonfinite operand or an
// overflowing result failing closed through `err` with y = 0.  Equivalence is
// checked cycle by cycle against those pipes (rtl/test/tb_hdc_fastfp_equiv.sv).
//
// What is different is depth.  The five-stage pipes are cut around carry
// chains that the synthesis flow maps to ripple logic (a 31-bit magnitude
// compare, 28-bit adds, a 48-bit product sum, the rounding increment); here
// every carry chain is an explicit Kogge-Stone prefix network, the product is a
// carry-save tree, and the leading-zero count is a tree whose exponent-floor
// clamp is a sentinel bit, so each operation is three register stages.
// ---------------------------------------------------------------------------

// W-bit adder with carry-in, Kogge-Stone prefix carries.
                                              
                          
                          
                            
                          
                            
  
                                                                         
                           
                 
                   
                         
                          
                                            
                   
                   
                                                
                                                 
                                        
               
                   
                   
           
       
                                  
                       
         

// Leading-zero count of a 32-bit word as a tree (n = 32 for zero).
                     
                         
                        
  
                                                                               
                                                                           
                         
                         
                 
                   
              
                           
                   
                            
                                           
                       
                                
                                                       
                                          
                                                                                              
               
                   
                   
           
       
                                             
         

// 24 x 24 unsigned product in two halves, so a pipeline register can sit in
// the middle of the tree: 24 AND rows, Wallace reduction by vector 3:2
// compressors 24 -> 16 -> 11 -> 8 (ot_hdc_mul24_rows), then 8 -> 6 -> 4 -> 3
// -> 2 and a Kogge-Stone final add (ot_hdc_mul24_sum).  Rows are flat vectors,
// row k in bits [48k +: 48]; a compressor writes its sum to row 2i and its
// carry to row 2i+1.
                          
                             
                             
                               
  
                                                                       
                                
             
                                     
                                                                  
           
               
                        
                        
                        
             
            
                                                   
                                                                 
           
                                                  
                                                                                                     
           
                                                  
                                                                                                     
           
                                             
                                                  
                                                                                                       
           
                                               
               
         

                         
                                
                            
  
                                  
                                
             
                                     
                                                                  
           
               
                       
                       
                       
                       
             
            
                                                  
                                                                                                           
           
                                               
                                                  
                                                                                                     
           
               
                                                                      
                                        
                                                             
                     
                                                                                                    
         

// ---------------------------------------------------------------------------
// Binary32 add, LATENCY 3, II 1.  Stage for stage:
//   1  decode; |b| > |a| as one 31-bit prefix compare of the encodings; both
//      exponent differences; the smaller significand aligned with a jam
//   2  the add and the subtract (both prefix adders); the add's one-bit
//      renormalize; the cancellation normalize, its shift the leading-zero
//      count of the difference OR a sentinel at the exponent floor
//   3  round to nearest even (prefix increment), encode, the refusals
// ---------------------------------------------------------------------------
                             
                           
                             
                                
                         
                         
                         
                           
                                
  
                                   
                                        
                                       

                                                                              
                                   
                                   
                                                           
                                                           
                                                     
                                                     
                                                              
                                     
                                     
                                                
                                                                                      
                                                                            
                                                                               
                                                              
               
                      
                                                                                                
                       
                        
                      
                                                                                         
                                                                                         
                                                                             
                                    
                         
                       
                             
             
                                      
                                                  
                      
                                                     
                                                         
               
           
               
                                                                            
                                                             
                                            
                                            

                                             
                      
                       
                      
                      
                        
                                                
                                 
                              
       
                               
                         
                                                   
                               
                                
                                        
                                       
                                       
                                             
       

                                                                              
                                               
                         
                      
                                                                                            
                                                                                             
                         
                                                                           
                                                                                
                                                                          
                                                  
                                     
                                                                                    
                   
                                                                      
                                               
                                 
                              
                                                                                                             
                                                                                                  

                                              
                      
                       
                      
                      
                                                
                                 
                          
       
                               
                                                                                   
                                            
                                             
                                             
       

                                                                              
                                                          
                    
               
                                                                                               
                                                      
                                                   
                                             
                                                                       
                                                   
                                                
                                                                           
                  
                              
                                                              
                                                                  
                                                                   
                                                                                    
           
       
         

// ---------------------------------------------------------------------------
// Binary32 multiply, LATENCY 3, II 1.
//   1  decode; subnormal operands normalized (tree LZC); the exponent sum;
//      the partial products and three carry-save levels (24 -> 8 rows)
//   2  the rest of the tree and the prefix final add; both exponent
//      decisions (leading bit 47 or 46) and the subnormal-result alignment
//      masks, all from the exponent sum alone
//   3  the product's top bit picks the decision; align, round, encode, refuse
// ---------------------------------------------------------------------------
                             
                           
                             
                                
                         
                         
                         
                           
                                
  
                                   
                                        
                                       

                                                                              
                                   
                                   
                                                     
                                                     
                                                              
                                                         
                          
                                                     
                                                     
                                                                            
                                                                          
                                                                                    
                                                                                           
                                                                                    
                                                                                           
                      
                 
                                                                                                

                                                                               
                         
                                                                                           

                                     
                      
                           
                               
                                                
                                 
                              
       
                               
                                    
                                                   
                                 
                        
                          
       

                                                                              
                     
                                                      
                                                                               
                                                                               
                                                          
                                                 
                                                 
                                                       
                                                                         
                                                              
                                 
              
                   
                                            
                                                                 
                                                                 
           
       

                                                         
                      
                                     
                     
                                       
                                                
                                 
                          
       
                               
                                                               
                        
                                     
                                     
                                         
                                                          
       

                                                                              
                           
                                            
                                                    
                                                               
                                                
                                                          
                                               
                                           
                                   
                                   
                                                
                                   
                                   
                    
               
                                                                                                         
                                  
                                                      
                                                    
                                               
                                            
                                       
                                                                                                   
                                                            
                                                
                                                                           
                  
                              
                                                            
                                                                   
                                                                                    
           
       
         

// Fault-reporting wrappers, as ot_hdc_fadd / ot_hdc_fmul but LATENCY 3.
                    
                           
                             
                         
                         
                         
                         
                            
  
                   
            
                                                                                                                    
                                       
         

                    
                           
                             
                         
                         
                         
                         
                            
  
                   
            
                                                                                                                    
                                       
         
