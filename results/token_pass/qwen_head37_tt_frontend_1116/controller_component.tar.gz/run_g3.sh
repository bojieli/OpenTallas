#!/bin/bash
set -uo pipefail
cd "$(dirname "$0")"
sha256sum -c packet_g3.sha256 >input_guard_g3.log 2>&1 || { echo SOURCE_GUARD_FAIL >status_g3;exit 3; }
VL=/home/ubuntu/.local/opentallas-tools/verilator-5.050/bin/verilator
echo "BUILD_START $(date -Is) host=$(hostname -s)" >status_g3
/usr/bin/time -v -o build_g3.time "$VL" --binary --timing -O0 -finline -j 1 --output-groups 16 --x-assign 0 --x-initial 0 -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD -CFLAGS '-O0 -w -fno-var-tracking' -f source.f --top-module tb_head_ctlm37 --Mdir obj >build_g3.log 2>&1
rc=$?;echo "BUILD_RC=$rc $(date -Is)" >>status_g3
[ "$rc" = 0 ] || exit "$rc"
/usr/bin/time -v -o base_g3.time ./obj/Vtb_head_ctlm37 +OT_ROM_DIR=rom >base_g3.log 2>&1
rc=$?;echo "BASE_RC=$rc" >>status_g3
[ "$rc" = 0 ] && grep -q NATIVE_CTLM37_PASS base_g3.log || exit 1
./obj/Vtb_head_ctlm37 +OT_ROM_DIR=rom +MUT_USER >MUT_USER_g3.log 2>&1
rc=$?;echo "MUT_USER=$rc" >>status_g3
[ "$rc" != 0 ] && grep -q CTLM_WRONG_REQUEST MUT_USER_g3.log || exit 2
echo PASS_NATIVE_CTLM37_COMPONENT >>status_g3
