// Unique calendar head-prepare ABI; H16 ME controls are unmodified.
`timescale 1ns/1ps
// =====================================================================================================================
// qfd_tt_ctlm_dv_lpf -- HF-4 (HARD-FIX 0id, 10-18): qfd_tt_ctlm_dv (HARD_HR = 1, MUT = 0) re-cut as a WIRES-ONLY flat
// parent so tools/landed_parent/lp.py can build the landed cluster (landed-regions-standard-1018).  Pure re-partition of
// the same RTL: every register / edge is the one in qfd_tt_ctlm_dv; the lockstep bench tb_qfd_tt_ctlm_dv_lpf proves
// qfd_tt_ctlm_dv == qfd_tt_ctlm_dv_lpf cycle-exactly on every output (mutants FAIL).
// Children (regions in tools/landed_parent/specs/qfd_tt_ctlm_dv_lpf.json):
//   u_gi   core region (W, beside the calendar's 2 x 64x512 SRAMs): pin registers dh / ss5 / ag5 / fab, the static command
//          calendar qfd_dv_cmd_cal, the ME start / token registers, the SU observation, the embedding start.
//   u_hr   hr region (E): the hard TT head leaf ot_qfd_tt_ctlm_static_hr (h16c / h17, ck_head ~355 ps internal insertion).
//   u_go   hr region: XPF loader + static schedule, cp fault, the hr row register, dc / cf / control_stores_ready.
//          (dc needs the head's faults, so it sits with the head: a core-side dc would make a core -> hr -> core loop.)
//   u_thru hr region: wires only.  It makes every core-driven output (cmd, cal_*, emb_*) cross into the hr region like
//          the head's outputs, so the landed parent has ONE output offset (+3 edges on every output, 0 on every input).
// Every input port is landed from the core region (port_regions), so the die presents all inputs on the flat schedule.
// MU-ADOPT-CTLM 10-19: NU (default 4 = the Qwen ROM 4-user calendar) / dh_user as qfd_tt_ctlm_dv (see its NU header);
//   NU = 1 is the single-user cluster.  dh_user lands from the core region like dh (0 edges).
// MU-QW-DIE 10-19: OPSEG / OPSEG_VIAMAP / OPSEG_INST as qfd_tt_ctlm_dv (MU-QW-B1 op-start leaf + coordinator 0ka boot
//   context record in image DW5 / DW6).  OPSEG 1: the leaf qfd_sys_face_mu_dhuser #(OPSEG 1) sits inside u_gi (core
//   region, g_op.u_leaf; ROM ot_rom_4096x72_m8 inside; its own hard tile per MU-LEAF-KIT), observing u_gi's dh pin
//   register and driving u_gi's calendar op start.  OPSEG 0 (default): no leaf, the previous cluster on every edge.
// MU-DQ-CTLMCLK 10-19 (COORD 0ke / 0kg): tl[1087:0] leaves u_gi DIRECTLY (core region: no 1088-b core -> hr landing, its
//   pins on the S face under the core region); every input port is landed from the hr region (spec port_regions: the
//   pin-register band lies in hr's footprint), so ck_core keeps no boundary pin but rst_n (ck_core spread 162/144 fix).
// =====================================================================================================================
module qfd_tt_ctlm_dv_lpf_hp13 #(
    parameter integer XPF_TRANSPORT_EDGES = -1,
    parameter integer LAST_STAGE = 37,
    parameter integer STAGE_ME = 0,
    parameter integer NU = 4,                    // MU-ADOPT-CTLM 10-19: Qwen ROM 4 users (qfd_tt_ctlm_dv NU; 1 = single user)
    parameter integer UVM_STRIDE = 4096,         // = tools/qwen_static_schedule/mu_calendar.py DV_UVM_STRIDE
    parameter integer PIDX_STRIDE = 128,         // = DV_PIDX_STRIDE
    parameter integer UTAG_LSB = 6,              // = DV_UTAG_LSB
    parameter integer CTX_SRC = 0, FCTX = 0,
    parameter [11:0] NCTX_BASE = 12'h010,
    parameter integer INIT_U0 = 0, INIT_FIRST = -1, INIT_CNT = 0,
    parameter integer OPSEG = 0,
    parameter integer OPSEG_EXPANDED = 0,
    parameter integer OPSEG_PINREG = 0,
    parameter OPSEG_VIAMAP1 = "", OPSEG_VIAMAP2 = "",
    parameter OPSEG_INST1 = "qfd_tt_ctlm_opseg_b1", OPSEG_INST2 = "qfd_tt_ctlm_opseg_b2",                 // MU-QW-DIE 10-19: 1 = op-start leaf + boot context (Qwen ROM 4 users)
    parameter OPSEG_VIAMAP = ""       ,
    parameter OPSEG_INST = "qfd_tt_ctlm_opseg",
    parameter integer PRIVATE_CALR = 0,          // QW-F16PROG4: CALR two-ROM calendar + 9-bit table request lane (table_req)
    parameter integer F16WTN = 0,                // QW-F16PROG4: F16 typed witness control (SAFE_PHYS) in u_gi (f16_*)
    parameter integer CAL_MUT = 0                // QW-TLPROD (bench only): u_gi.u_cal MUT (35 = drop the stage-17 REL table load)
) (
    input  wire          ck,
    input  wire          rst_n,
    input  wire [74:0]   pw,
    input  wire [186:0]  dh,
    input  wire          init_u0,                  // explicit static admission INIT selector, aligned to DH stage0
    input  wire [128:0]  ctx_x,
    input  wire          mu_fault,
    input  wire [1:0]    dh_user,                // user of the dh stage start (qfd_sys_face seq_dh_user; tie 0 = user 0)
    input  wire          kok,
    input  wire          kwd,
    input  wire          fab,
    output wire [75:0]   program_obs,
    output wire          control_stores_ready,
    output wire          layer_context_v,
    output wire [17:0]   native_tok,
    output wire [17:0]   native_pos,
    output wire [5:0]    command_stage,
    output wire [75:0]   cal_program_obs,
    output wire [68:0]   cal_descriptor_obs,
    output wire          cal_image_ready,
    output wire [55:0]   dc,
    output wire [379:0]  native_cmd,
    input  wire [94:0]   native_ret,
    output wire [452:0]  hr,
    output wire [115:0]  cmd,
    output wire [1087:0] tl,                     // QLB-C4b slice table words (W5 st_wi), straight from u_gi (core)
    input  wire [106:0]  ss5,
    input  wire [9:0]    ag5,
    output wire          emb_start,
    output wire [17:0]   emb_token,
    output wire [17:0]   emb_position,
    output wire [1:0]    emb_user,
    output wire          cf,
    // QW-F16PROG4 (0 / unused at PRIVATE_CALR = F16WTN = 0; the die binds them, no ties): F16 auth from SYSFACE u_join
    // {begin, all_copies_auth, fusedcap, digest, epoch}; per-slice typed execution events; status; CALR table requests.
    input  wire [82:0]   f16_auth,
    input  wire [37:0]   f16_obs,
    output wire [16:0]   f16_st,
    output wire [8:0]    table_req
);
    wire [16:0]  g_f16_st;
    wire [8:0]   g_treq;
    wire [115:0] g_cmd;
    wire [75:0]  g_cal_program_obs;
    wire [68:0]  g_cal_descriptor_obs;
    wire         g_cal_image_ready, g_emb_start;
    wire [17:0]  g_emb_token, g_emb_position;
    wire [1:0]   g_emb_user;
    wire         s_start;
    wire [5:0]   s_stage;
    wire [48:0]  st;
    wire [1:0]   hu;                             // MU-DQ-D2DUSER: head-start user, core -> hr (landed like st)
    wire [17:0] npos_h, ntok_h;
    wire lcv_h;
    wire [37:0] fctx;
    wire [15:0]  su_obs, x_oprog, x_orows;
    wire [23:0]  su_acc;
    wire         x_oidle;
    wire [1:0]   rom_ret_v;
    wire [61:0]  dcs;
    wire [55:0]  cp;
    wire         me_image_ready, hr_fault;
    wire [15:0]  me_observe;
    wire [379:0] ib_q;
    wire [72:0]  hr_lo;
    wire [379:0] ib_hr;
    qfd_tt_ctlm_dv_gi_hp13 #(.LAST_STAGE(LAST_STAGE), .STAGE_ME(STAGE_ME), .NU(NU), .UVM_STRIDE(UVM_STRIDE),
        .PIDX_STRIDE(PIDX_STRIDE), .UTAG_LSB(UTAG_LSB), .INIT_U0(INIT_U0), .INIT_FIRST(INIT_FIRST), .INIT_CNT(INIT_CNT), .CTX_SRC(CTX_SRC), .FCTX(FCTX), .NCTX_BASE(NCTX_BASE), .OPSEG(OPSEG), .OPSEG_EXPANDED(OPSEG_EXPANDED), .OPSEG_PINREG(OPSEG_PINREG), .OPSEG_VIAMAP1(OPSEG_VIAMAP1), .OPSEG_VIAMAP2(OPSEG_VIAMAP2), .OPSEG_INST1(OPSEG_INST1), .OPSEG_INST2(OPSEG_INST2), .OPSEG_VIAMAP(OPSEG_VIAMAP), .OPSEG_INST(OPSEG_INST),
        .PRIVATE_CALR(PRIVATE_CALR), .F16WTN(F16WTN), .CAL_MUT(CAL_MUT))
        u_gi (.ck(ck), .rst_n(rst_n), .pw(pw), .f16_auth(f16_auth), .f16_obs(f16_obs), .f16_st(g_f16_st), .treq(g_treq), .dh(dh), .dh_user(dh_user), .ctx_x(ctx_x), .init_u0(init_u0), .mu_fault(mu_fault), .ss5(ss5),
        .ag5(ag5), .fab(fab), .cmd(g_cmd), .tl(tl), .cal_program_obs(g_cal_program_obs), .cal_descriptor_obs(g_cal_descriptor_obs),
        .cal_image_ready(g_cal_image_ready), .emb_start(g_emb_start), .emb_token(g_emb_token), .emb_position(g_emb_position), .emb_user(g_emb_user), .s_start(s_start),
        .s_stage(s_stage), .st(st), .hu(hu), .fctx(fctx), .su_obs_o(su_obs), .su_acc_o(su_acc), .x_oprog(x_oprog), .x_orows(x_orows),
        .x_oidle(x_oidle), .rom_ret_v(rom_ret_v), .dcs(dcs));
    ot_qfd_tt_ctlm_static_hr_safe32_native32_1r #(.STAGE_ME(1), .SEGCAL(1)) u_hr (
        .stage_start(s_start), .stage(s_stage),
        .rom_ret_i({rom_ret_v[1], 16'd0, 1'b0, 32'd0, 18'd0, 24'd0, 1'b0, rom_ret_v[0], 1'b1}), .cp_active(1'b0), .cp(cp), .me_image_ready(me_image_ready), .program_obs(program_obs),
        .layer_context_v(lcv_h), .native_tok(ntok_h), .native_pos(npos_h), .rom_cmd(ib_q),
        .command_stage(command_stage), .native_cmd(native_cmd), .me_observe(me_observe),
        .native_ret(native_ret), .ck_head(ck), .rst_n(rst_n),
        .h_start(st[48]), .token(st[47:30]), .pos(st[29:12]), .prog_base(st[11:0]),
        .pw_v(pw[74]), .pw_addr(pw[73:64]), .pw_data(pw[63:0]),
        .x_oacc(su_acc), .x_oidle(x_oidle), .x_oprog(x_oprog), .x_orows(x_orows),
        .kv_ok(kok), .kv_write_drained(kwd), .me_mem_ok(1'b1),
        .m_fin_o(), .m_fidx_o(), .m_fval_o(),
        .kvd_v(), .kvd_wbase(), .kvd_ts(), .kvd_ks(), .kvd_js(), .kvd_wcs(), .kvd_split(), .kvd_jsh(), .kvd_tiles(),
        .kvd_k(), .kvd_nout(), .kvd_kindk(), .kvd_pos(), .me_clk_en(), .c_fault(hr_fault));
    qfd_tt_ctlm_dv_go_hp13 #(.XPF_TRANSPORT_EDGES(XPF_TRANSPORT_EDGES)) u_go (.ck(ck), .rst_n(rst_n), .pw(pw), .st(st),
        .su_obs(su_obs), .me_observe(me_observe), .cp(cp), .me_image_ready(me_image_ready), .hr_fault(hr_fault),
        .dcs(dcs), .hr_lo(hr_lo), .dc(dc), .cf(cf), .control_stores_ready(control_stores_ready));
    qfd_tt_ctlm_dv_thru_hp13 u_thru (.ck(ck), .rst_n(rst_n), .f16_st_i(g_f16_st), .f16_st(f16_st), .treq_i(g_treq), .table_req(table_req), .hu_i(hu), .fctx_i(fctx), .lcv_i(lcv_h), .ntok_i(ntok_h), .layer_context_v(layer_context_v), .native_tok(native_tok), .npos_i(npos_h), .native_pos(native_pos), .cmd_i(g_cmd), .cal_program_obs_i(g_cal_program_obs),
        .cal_descriptor_obs_i(g_cal_descriptor_obs), .cal_image_ready_i(g_cal_image_ready), .emb_start_i(g_emb_start),
        .emb_token_i(g_emb_token), .emb_position_i(g_emb_position), .emb_user_i(g_emb_user), .ib_i(ib_q), .ib_hr(ib_hr), .cmd(cmd), .cal_program_obs(cal_program_obs), .cal_descriptor_obs(cal_descriptor_obs),
        .cal_image_ready(cal_image_ready), .emb_start(emb_start), .emb_token(emb_token), .emb_position(emb_position), .emb_user(emb_user));
    // QW-DIEFIX 10-19: hr[452:73] in the slice layout: u_thru's qfd_dv_hr_pack (zero-logic permutation of the registered
    // ib_q; hr_contract.py follows the child port)
    assign hr = {ib_hr, hr_lo};
endmodule
