#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
V=$HOME/.local/opentallas-tools/verilator-5.050/bin/verilator
/usr/bin/time -v -o build.time "$V" --binary --timing -j 1 -O0 -finline --output-groups 64 -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD -Wno-MULTIDRIVEN -Wno-UNOPTFLAT -Wno-WIDTH --x-assign 0 --x-initial 0 -CFLAGS '-O0 -w -fno-var-tracking' --top-module tb -f source.f --Mdir obj > build.log 2>&1
/usr/bin/time -v -o run.time ./obj/Vtb > run.log 2>&1
grep -q MEM44_ONE_HEAD_PROFILE_PASS run.log
set +e
./obj/Vtb +BAD_REPLY > bad_reply.log 2>&1
rc=$?
set -e
[ "$rc" != 0 ] && grep -Eq 'HEAD_PAYLOAD|PACK_PAYLOAD|HEAD_COUNT|NATIVE_FAULT' bad_reply.log
echo MEM44_REPLY_CONTROL_CAUGHT
