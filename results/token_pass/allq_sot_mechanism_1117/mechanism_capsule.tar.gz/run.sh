#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
V=${VERILATOR:-$HOME/.local/opentallas-tools/verilator-5.050/bin/verilator}
"$V" --binary --timing -j 2 -Wno-fatal -Wno-WIDTH --top-module tb -Mdir obj tb.sv rtl/dsrom_sys/s81_dv/sm_target/*.sv rtl/dsrom_sys/s81_ctrl/ot_s81_svc_job.sv physical/asap7_memory_macros_v2/ot_sram_1r1w_32x64_m1/*.v > build.log 2>&1
./obj/Vtb +dir="$PWD/images/unfenced" +mut=1 > run_unfenced.log 2>&1
./obj/Vtb +dir="$PWD/images/fenced" > run_fenced.log 2>&1
./obj/Vtb +dir="$PWD/images/bridge6" > run_bridge6.log 2>&1
