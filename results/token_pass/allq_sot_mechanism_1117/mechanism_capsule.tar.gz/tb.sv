`timescale 1ns/1fs
module tb;
reg clk=0;always #0.4165 clk=~clk;
reg rst_n=0;integer cyc=0,qi=0,mut=0;
reg[31:0]qc[0:4095],meta[0:31];reg[511:0]qw[0:4095];
string dir;
reg qv=0;reg[511:0]qd=0;reg[32:0]jc=0;
wire[514:0]coreq;wire[1:0]jd;
reg[511:0]endword=0;
wire[513:0]od={endword,retpipe[14],1'b0};
ot_s81_svc_job job(.ck(clk),.rs_n(rst_n),.j_cmd(jc),.j_dn(jd),.q({2'b0,qd,qv}),.core_q(coreq),.ad(1026'd0),.xd(514'd0),.od(od));
reg[514:0]down[0:12];integer z;
// Head7 uses two down/up tree hops; entry q front3 + down10.
always@(posedge clk)begin down[0]<=coreq;for(z=1;z<13;z=z+1)down[z]<=down[z-1];end
wire cv;wire[19:0]owner;wire[7:0]se,so;wire[13:0]obase;
wire[15:0]first,last,rd,ret,gw0,gw1;wire[1:0]route;wire[2:0]sfc;
dsdv_svc_sot decoder(.clk(clk),.rst_n(rst_n),.tile(4'd7),.q_v(down[12][0]),.q_d(down[12][512:1]),
.cfg_v(cv),.cfg_owner(owner),.cfg_se_jid(se),.cfg_so_jid(so),.cfg_obase(obase),.cfg_first(first),.cfg_last(last),.cfg_read(rd),.cfg_retire(ret),.route(route),.gw_first(gw0),.gw_last(gw1),.fault_code(sfc));
reg opv=0,wv=0;reg[3:0]opk=0;reg[7:0]opj=0;reg[13:0]wa=0;reg[15:0]wm=0;reg[511:0]wd=0;reg[11:0]ws=0;
wire gv,retired,rerr,tf;wire[6:0]gi;wire[1023:0]gd;wire[19:0]go,ro;wire gg;wire[11:0]tfc;
dsdv_sm_so_target #(.HEAD(7)) target(.clk(clk),.rst_n(rst_n),.head(4'd7),.cfg_v(cv),.cfg_owner(owner),.cfg_se_jid(se),.cfg_so_jid(so),.cfg_obase(obase),.cfg_first(first),.cfg_last(last),.cfg_read(rd),.cfg_retire(ret),
.op_st(opv),.op_kind(opk),.op_jid(opj),.w_v(wv),.w_a(wa),.w_m(wm),.w_d(wd),.w_st(ws),.g_v(gv),.g_idx(gi),.g_d(gd),.g_owner(go),.g_group(gg),.retired(retired),.retire_error(rerr),.retire_owner(ro),.fault(tf),.fault_code(tfc));
reg[14:0]retpipe=0; // two up-hops10 + JD pulse glue5; real job gate adds its sampled edge
always@(posedge clk)if(!rst_n)retpipe<=0;else retpipe<={retpipe[13:0],retired};
integer beat=0,rows=0,done_edge=-1,lastq=-1,cfg_edge=-1,ret_edge=-1;
function automatic[255:0]payload(input integer r);
reg[255:0]v;begin for(integer l=0;l<16;l=l+1)v[16*l+:16]=16'(r*16+l+1);payload=v;end endfunction
always@(negedge clk)if(rst_n)begin
 opv=0;wv=0;
 if(target.active)begin
  if(target.cyc==2)begin opv=1;opk=4;opj=se;end
  if(target.cyc==4)begin wv=1;wm=16'hffff;ws={se,4'b1000};wd=0;end
  if(target.cyc==6)begin opv=1;opk=5;opj=so;end
  if(target.cyc>=first+2 && target.cyc<first+34)begin
   wv=1;wa=obase+14'(8*rows)+3;wm=16'hff00;ws={so,4'b0100};wd={payload(rows),256'd0};rows=rows+1;
  end
 end
 if(cv)cfg_edge=cyc;
 if(retired)ret_edge=cyc;
 if(gv)begin
  for(integer k=0;k<4;k=k+1)if(gd[256*k+:256]!==payload(beat*4+k))$fatal(1,"SOT_TARGET_PAYLOAD beat%0d row%0d",beat,k);
  beat=beat+1;
 end
 if(qv)lastq=cyc;
 if(jd[0])done_edge=cyc;
 if(cyc>=3700)begin
  if(sfc || tf || rerr || beat!=8 || rows!=32 || done_edge<0)$fatal(1,"MECHANISM_FAIL sfc%h tf%h beat%0d rows%0d done%0d",sfc,tfc,beat,rows,done_edge);
  if(mut)begin if(!jd[1] || done_edge>=lastq)$fatal(1,"UNFENCED_NOT_CAUGHT");$display("LIFETIME_CAUGHT done%0d lastq%0d",done_edge,lastq);end
  else begin if(jd[1] || done_edge<=lastq)$fatal(1,"LIFETIME_NOT_SAFE done%0d lastq%0d fault%b",done_edge,lastq,jd);$display("LIFETIME_PASS rows32 beats8 cfg%0d read%0d retire%0d retired_at%0d done%0d lastq%0d",cfg_edge,rd,ret,ret_edge,done_edge,lastq);end
  $finish;
 end
end
always@(posedge clk)begin
 cyc=cyc+1;qv<=0;jc<=0;
 if(rst_n)begin
  if(cyc==meta[3])jc<={meta[5][0],meta[4]};
  if(qi<meta[0] && cyc==qc[qi])begin qv<=1;qd<=qw[qi];qi=qi+1;end
 end
end
initial begin
 if(!$value$plusargs("dir=%s",dir))$fatal;
 if($value$plusargs("mut=%d",mut));
 $readmemh({dir,"/meta.hex"},meta);$readmemh({dir,"/qcyc.hex"},qc,0,meta[0]-1);$readmemh({dir,"/qwd.hex"},qw,0,meta[0]-1);
 endword[507]=1;endword[502:495]=meta[4][7:0];
 repeat(8)@(negedge clk);rst_n=1;
end
endmodule
