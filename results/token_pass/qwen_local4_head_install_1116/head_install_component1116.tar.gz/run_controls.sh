#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
/usr/bin/time -v -o early45.time ./obj/Vtb_mu_native +OT_ROM_DIR=calendar +OT_QC_TABLE_ROM_DIR=../tables_candidate1116/rank0/masks +CMD_AFTER_TREQ=45 > early45.log 2>&1
grep -q NATIVE_LOCAL4_HEAD_INSTALL_PASS early45.log
set +e
./obj/Vtb_mu_native +OT_ROM_DIR=calendar +OT_QC_TABLE_ROM_DIR=../tables_candidate1116/rank0/masks +CMD_AFTER_TREQ=44 > early44.log 2>&1
rc=$?
set -e
[ "$rc" != 0 ] && grep -q HEAD_CROM_BEFORE_INSTALL early44.log
set +e
./obj/Vtb_mu_native +OT_ROM_DIR=calendar +OT_QC_TABLE_ROM_DIR=../tables_candidate1116/rank0/masks +DROP_TABLE_WRITES > dropped_tw.log 2>&1
rc=$?
set -e
[ "$rc" != 0 ] && grep -q HEAD_PROG_BEFORE_INSTALL dropped_tw.log
cat early45.log early44.log dropped_tw.log
echo LOCAL4_HEAD_INSTALL_CONTROLS_PASS
