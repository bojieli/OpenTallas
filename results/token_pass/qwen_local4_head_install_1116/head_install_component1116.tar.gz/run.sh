#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
V=$HOME/.local/opentallas-tools/verilator-5.050/bin/verilator
/usr/bin/time -v -o build.time "$V" --binary --timing -j 1 -O0 -finline --output-groups 64 -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD -Wno-MULTIDRIVEN -Wno-UNOPTFLAT -Wno-WIDTH --x-assign 0 --x-initial 0 -CFLAGS '-O0 -w -fno-var-tracking' --top-module tb_mu_native -f source.f --Mdir obj > build.log 2>&1
/usr/bin/time -v -o run.time ./obj/Vtb_mu_native +OT_ROM_DIR=calendar +OT_QC_TABLE_ROM_DIR=../tables_candidate1116/rank0/masks > run.log 2>&1
cat run.log
grep -q NATIVE_LOCAL4_HEAD_INSTALL_PASS run.log
