place_macro -macro_name {u.u.g_lf\[0\].u_lh.u_bdc} -location {129.6 1080} -orientation R0
place_macro -macro_name {u.u.g_lf\[0\].u_lh.u_tcc.u_h0} -location {388.8 993.6} -orientation R0
place_macro -macro_name {u.u.g_lf\[0\].u_lh.u_tcc.u_h1} -location {518.4 993.6} -orientation R0
place_macro -macro_name {u.u.g_lf\[0\].u_lh.u_tcc.u_tr} -location {388.8 864} -orientation R0
place_macro -macro_name {u.u.g_lf\[0\].u_lh.u_xs} -location {43.2 864} -orientation R0
place_macro -macro_name {u.u.g_lf\[1\].u_lh.u_bdc} -location {129.6 43.2} -orientation MX
place_macro -macro_name {u.u.g_lf\[1\].u_lh.u_tcc.u_h0} -location {388.8 259.2} -orientation R0
place_macro -macro_name {u.u.g_lf\[1\].u_lh.u_tcc.u_h1} -location {518.4 259.2} -orientation R0
place_macro -macro_name {u.u.g_lf\[1\].u_lh.u_tcc.u_tr} -location {388.8 129.6} -orientation R0
place_macro -macro_name {u.u.g_lf\[1\].u_lh.u_xs} -location {43.2 216.024} -orientation MX
place_macro -macro_name {u.u.u_pte} -location {388.8 432} -orientation R0
place_macro -macro_name {u.u.u_ptw} -location {43.2 432} -orientation R0

