place_macro -macro_name {u.u.g_lf\[0\].u_lh.u_bdc} -location {388.824 1080} -orientation MY
place_macro -macro_name {u.u.g_lf\[0\].u_lh.u_tcc.u_h0} -location {172.824 993.6} -orientation MY
place_macro -macro_name {u.u.g_lf\[0\].u_lh.u_tcc.u_h1} -location {43.224 993.6} -orientation MY
place_macro -macro_name {u.u.g_lf\[0\].u_lh.u_tcc.u_tr} -location {43.224 864} -orientation MY
place_macro -macro_name {u.u.g_lf\[0\].u_lh.u_xs} -location {302.424 864} -orientation MY
place_macro -macro_name {u.u.g_lf\[1\].u_lh.u_bdc} -location {388.824 43.2} -orientation R180
place_macro -macro_name {u.u.g_lf\[1\].u_lh.u_tcc.u_h0} -location {172.824 259.2} -orientation MY
place_macro -macro_name {u.u.g_lf\[1\].u_lh.u_tcc.u_h1} -location {43.224 259.2} -orientation MY
place_macro -macro_name {u.u.g_lf\[1\].u_lh.u_tcc.u_tr} -location {43.224 129.6} -orientation MY
place_macro -macro_name {u.u.g_lf\[1\].u_lh.u_xs} -location {302.424 216.024} -orientation R180
place_macro -macro_name {u.u.u_pte} -location {43.224 432} -orientation MY
place_macro -macro_name {u.u.u_ptw} -location {302.424 432} -orientation MY

