# Written by tools/run_abi3_physical.py --pin-region.
proc ot_pin_plain {name} { return [string map {\\\[ \[ \\\] \]} $name] }
proc ot_pin_base {name} { regsub {\[[0-9]+\]$} [ot_pin_plain $name] {} base; return $base }
proc ot_pin_matches {pattern name} {
  return [expr {[regexp -- $pattern $name] || [regexp -- $pattern [ot_pin_plain $name]] ||
                [regexp -- $pattern [ot_pin_base $name]]}]
}
proc ot_match_pins {pattern} {
  set names {}
  foreach bterm [[ord::get_db_block] getBTerms] {
    set name [$bterm getName]
    if {[ot_pin_matches $pattern $name]} { lappend names $name }
  }
  if {[llength $names] == 0} { error "--pin-region $pattern matches no port" }
  return [lsort -dictionary $names]
}
proc ot_check_bus_complete {patterns} {
  array set hit {}; array set all {}
  foreach bterm [[ord::get_db_block] getBTerms] {
    if {[lsearch -exact {POWER GROUND} [$bterm getSigType]] >= 0} { continue }
    set name [$bterm getName]
    set base [ot_pin_base $name]
    if {$base eq [ot_pin_plain $name]} { continue }
    incr all($base)
    foreach p $patterns { if {[ot_pin_matches $p $name]} { incr hit($base); break } }
  }
  set bad {}
  foreach base [array names hit] { if {$hit($base) != $all($base)} { lappend bad "$base:$hit($base)/$all($base)" } }
  if {[llength $bad] > 0} {
    error "--pin-region leaves bus bits unassigned (bus:assigned/bits): [lrange [lsort $bad] 0 23]"
  }
}
ot_check_bus_complete [list {^(clk|rst_n|md_d|md_k)(\[|$)} {^(f_req_v|f_req_rdy|f_req_addr|f_rsp_v|f_rsp_data|au_tbl_ok|fe_s1_v|fe_s1_base|fe_s1_lstr|fe_s1_l1str|fe_s1_str|fe_s1_dmul|fe_s1_dsel|fe_s1_nsel|fe_s1_n|fe_s1_idx|fe_s1_sp|fe_s1_L|fe_s1_L1|fe_s1_slot|fe_s1_j|fe_s1_tag|fe_s1_last|fe_s1_isI|fe_s1_hi|fe_s1_et|fe_hslot)(\[|$)} {^(be_jl_v|be_jl_entry|be_jl_kernel|be_jl_loff|be_jl_pos|be_js|be_stop|be_qpop|be_lv_v|be_lv_cnt|be_inj_hold|fe_kz|fe_s2a_v|fe_s2a_tag|fe_s2a_hdr|fe_s2a_kind|fe_s2a_rdy0|fe_s2a_L|fe_s2a_L1|fe_s2i_v|fe_s2i_d|fe_s2i_tag|fe_s2i_slot|fe_s2i_sut|fe_s2i_np0)(\[|$)}]
proc ot_check_pin_regions {patterns} {
  set bad {}
  foreach bterm [[ord::get_db_block] getBTerms] {
    if {[lsearch -exact {POWER GROUND} [$bterm getSigType]] >= 0} { continue }
    set name [$bterm getName]
    set n 0
    foreach p $patterns { if {[ot_pin_matches $p $name]} { incr n } }
    if {$n != 1} { lappend bad "$name:$n" }
  }
  if {[llength $bad] > 0} {
    error "--pin-regions-exhaustive: [llength $bad] ports match no region or more than one (port:matches): [lrange $bad 0 23]"
  }
}
ot_check_pin_regions [list {^(clk|rst_n|md_d|md_k)(\[|$)} {^(f_req_v|f_req_rdy|f_req_addr|f_rsp_v|f_rsp_data|au_tbl_ok|fe_s1_v|fe_s1_base|fe_s1_lstr|fe_s1_l1str|fe_s1_str|fe_s1_dmul|fe_s1_dsel|fe_s1_nsel|fe_s1_n|fe_s1_idx|fe_s1_sp|fe_s1_L|fe_s1_L1|fe_s1_slot|fe_s1_j|fe_s1_tag|fe_s1_last|fe_s1_isI|fe_s1_hi|fe_s1_et|fe_hslot)(\[|$)} {^(be_jl_v|be_jl_entry|be_jl_kernel|be_jl_loff|be_jl_pos|be_js|be_stop|be_qpop|be_lv_v|be_lv_cnt|be_inj_hold|fe_kz|fe_s2a_v|fe_s2a_tag|fe_s2a_hdr|fe_s2a_kind|fe_s2a_rdy0|fe_s2a_L|fe_s2a_L1|fe_s2i_v|fe_s2i_d|fe_s2i_tag|fe_s2i_slot|fe_s2i_sut|fe_s2i_np0)(\[|$)}]
set ot_region_pins [ot_match_pins {^(clk|rst_n|md_d|md_k)(\[|$)}]
for {set ot_first 0} {$ot_first < [llength $ot_region_pins]} {incr ot_first 32} {
  set_io_pin_constraint -group -order -region left:* -pin_names [lrange $ot_region_pins $ot_first [expr {$ot_first + 32 - 1}]]
}
set ot_region_pins [ot_match_pins {^(f_req_v|f_req_rdy|f_req_addr|f_rsp_v|f_rsp_data|au_tbl_ok|fe_s1_v|fe_s1_base|fe_s1_lstr|fe_s1_l1str|fe_s1_str|fe_s1_dmul|fe_s1_dsel|fe_s1_nsel|fe_s1_n|fe_s1_idx|fe_s1_sp|fe_s1_L|fe_s1_L1|fe_s1_slot|fe_s1_j|fe_s1_tag|fe_s1_last|fe_s1_isI|fe_s1_hi|fe_s1_et|fe_hslot)(\[|$)}]
for {set ot_first 0} {$ot_first < [llength $ot_region_pins]} {incr ot_first 32} {
  set_io_pin_constraint -group -order -region top:* -pin_names [lrange $ot_region_pins $ot_first [expr {$ot_first + 32 - 1}]]
}
set ot_region_pins [ot_match_pins {^(be_jl_v|be_jl_entry|be_jl_kernel|be_jl_loff|be_jl_pos|be_js|be_stop|be_qpop|be_lv_v|be_lv_cnt|be_inj_hold|fe_kz|fe_s2a_v|fe_s2a_tag|fe_s2a_hdr|fe_s2a_kind|fe_s2a_rdy0|fe_s2a_L|fe_s2a_L1|fe_s2i_v|fe_s2i_d|fe_s2i_tag|fe_s2i_slot|fe_s2i_sut|fe_s2i_np0)(\[|$)}]
for {set ot_first 0} {$ot_first < [llength $ot_region_pins]} {incr ot_first 32} {
  set_io_pin_constraint -group -order -region right:* -pin_names [lrange $ot_region_pins $ot_first [expr {$ot_first + 32 - 1}]]
}
