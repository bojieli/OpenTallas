place_macro -macro_name {g_ring_m.g_64k.u_ring0} -location {22.464 23.76} -orientation R0
place_macro -macro_name {g_ring_m.g_64k.u_ring1} -location {22.464 116.64} -orientation R0

