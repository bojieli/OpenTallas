place_macro -macro_name {g_slice.g_f\[0\].u_yf.g_tile\[0\].genblk1.genblk1.g_m2.u_m} -location {22.464 32.4} -orientation R0
place_macro -macro_name {g_slice.g_f\[10\].u_yf.g_tile\[0\].genblk1.genblk1.g_m2.u_m} -location {252.288 159.84} -orientation R0
place_macro -macro_name {g_slice.g_f\[1\].u_yf.g_tile\[0\].genblk1.genblk1.g_m2.u_m} -location {22.464 95.04} -orientation R0
place_macro -macro_name {g_slice.g_f\[2\].u_yf.g_tile\[0\].genblk1.genblk1.g_m2.u_m} -location {22.464 159.84} -orientation R0
place_macro -macro_name {g_slice.g_f\[3\].u_yf.g_tile\[0\].genblk1.genblk1.g_m2.u_m} -location {22.464 224.64} -orientation R0
place_macro -macro_name {g_slice.g_f\[4\].u_yf.g_tile\[0\].genblk1.genblk1.g_m2.u_m} -location {137.376 32.4} -orientation R0
place_macro -macro_name {g_slice.g_f\[5\].u_yf.g_tile\[0\].genblk1.genblk1.g_m2.u_m} -location {137.376 95.04} -orientation R0
place_macro -macro_name {g_slice.g_f\[6\].u_yf.g_tile\[0\].genblk1.genblk1.g_m2.u_m} -location {137.376 159.84} -orientation R0
place_macro -macro_name {g_slice.g_f\[7\].u_yf.g_tile\[0\].genblk1.genblk1.g_m2.u_m} -location {137.376 224.64} -orientation R0
place_macro -macro_name {g_slice.g_f\[8\].u_yf.g_tile\[0\].genblk1.genblk1.g_m2.u_m} -location {252.288 32.4} -orientation R0
place_macro -macro_name {g_slice.g_f\[9\].u_yf.g_tile\[0\].genblk1.genblk1.g_m2.u_m} -location {252.288 95.04} -orientation R0

