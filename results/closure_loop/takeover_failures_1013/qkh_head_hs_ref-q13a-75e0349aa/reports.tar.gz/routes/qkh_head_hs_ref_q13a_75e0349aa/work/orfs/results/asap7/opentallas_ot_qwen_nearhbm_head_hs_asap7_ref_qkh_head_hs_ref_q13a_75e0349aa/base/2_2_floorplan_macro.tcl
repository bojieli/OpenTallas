place_macro -macro_name {g_t\[0\].u_l8} -location {43.2 43.2} -orientation R0
place_macro -macro_name {g_t\[10\].u_l8} -location {388.8 388.8} -orientation R0
place_macro -macro_name {g_t\[11\].u_l8} -location {561.6 388.8} -orientation R0
place_macro -macro_name {g_t\[12\].u_l8} -location {43.2 561.6} -orientation R0
place_macro -macro_name {g_t\[13\].u_l8} -location {216 561.6} -orientation R0
place_macro -macro_name {g_t\[14\].u_l8} -location {388.8 561.6} -orientation R0
place_macro -macro_name {g_t\[15\].u_l8} -location {561.6 561.6} -orientation R0
place_macro -macro_name {g_t\[1\].u_l8} -location {216 43.2} -orientation R0
place_macro -macro_name {g_t\[2\].u_l8} -location {388.8 43.2} -orientation R0
place_macro -macro_name {g_t\[3\].u_l8} -location {561.6 43.2} -orientation R0
place_macro -macro_name {g_t\[4\].u_l8} -location {43.2 216} -orientation R0
place_macro -macro_name {g_t\[5\].u_l8} -location {216 216} -orientation R0
place_macro -macro_name {g_t\[6\].u_l8} -location {388.8 216} -orientation R0
place_macro -macro_name {g_t\[7\].u_l8} -location {561.6 216} -orientation R0
place_macro -macro_name {g_t\[8\].u_l8} -location {43.2 388.8} -orientation R0
place_macro -macro_name {g_t\[9\].u_l8} -location {216 388.8} -orientation R0
place_macro -macro_name {u_kt} -location {259.2 734.4} -orientation R0

