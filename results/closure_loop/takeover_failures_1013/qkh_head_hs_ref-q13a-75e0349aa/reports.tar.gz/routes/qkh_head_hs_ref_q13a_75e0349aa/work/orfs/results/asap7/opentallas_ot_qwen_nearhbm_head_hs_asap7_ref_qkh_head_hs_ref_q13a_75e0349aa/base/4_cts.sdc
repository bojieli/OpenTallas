###############################################################################
# Created by write_sdc
###############################################################################
current_design ot_qwen_nearhbm_head_hs
###############################################################################
# Timing Constraints
###############################################################################
create_clock -name core_clk -period 770.0000 [get_ports {clk}]
set_clock_uncertainty -setup 60.0000 core_clk
set_clock_uncertainty -hold 25.0000 core_clk
set_propagated_clock [get_clocks {core_clk}]
create_clock -name ot_lb_v_core_clk -period 770.0000 
set_clock_uncertainty -setup 60.0000 ot_lb_v_core_clk
set_clock_latency 1180.5728 [get_clocks {ot_lb_v_core_clk}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {c_in[0]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {c_in[1]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {c_in[2]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {c_in[3]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[0]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[10]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[11]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[12]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[13]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[14]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[15]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[1]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[2]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[3]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[4]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[5]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[6]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[7]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[8]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {e_in[9]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {hid[0]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {hid[1]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {lt_in[0]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {lt_in[10]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {lt_in[11]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {lt_in[1]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {lt_in[2]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {lt_in[3]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {lt_in[4]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {lt_in[5]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {lt_in[6]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {lt_in[7]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {lt_in[8]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {lt_in[9]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_beat_in[0]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_beat_in[1]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_beat_in[2]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_beat_in[3]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_beat_in[4]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_beat_in[5]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[0]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[100]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[101]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[102]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[103]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[104]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[105]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[106]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[107]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[108]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[109]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[10]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[110]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[111]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[112]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[113]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[114]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[115]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[116]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[117]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[118]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[119]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[11]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[120]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[121]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[122]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[123]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[124]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[125]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[126]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[127]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[128]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[129]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[12]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[130]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[131]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[132]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[133]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[134]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[135]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[136]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[137]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[138]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[139]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[13]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[140]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[141]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[142]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[143]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[144]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[145]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[146]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[147]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[148]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[149]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[14]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[150]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[151]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[152]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[153]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[154]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[155]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[156]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[157]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[158]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[159]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[15]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[160]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[161]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[162]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[163]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[164]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[165]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[166]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[167]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[168]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[169]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[16]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[170]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[171]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[172]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[173]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[174]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[175]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[176]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[177]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[178]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[179]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[17]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[180]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[181]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[182]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[183]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[184]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[185]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[186]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[187]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[188]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[189]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[18]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[190]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[191]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[192]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[193]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[194]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[195]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[196]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[197]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[198]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[199]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[19]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[1]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[200]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[201]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[202]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[203]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[204]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[205]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[206]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[207]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[208]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[209]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[20]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[210]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[211]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[212]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[213]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[214]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[215]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[216]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[217]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[218]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[219]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[21]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[220]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[221]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[222]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[223]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[224]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[225]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[226]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[227]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[228]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[229]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[22]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[230]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[231]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[232]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[233]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[234]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[235]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[236]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[237]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[238]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[239]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[23]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[240]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[241]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[242]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[243]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[244]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[245]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[246]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[247]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[248]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[249]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[24]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[250]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[251]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[252]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[253]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[254]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[255]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[256]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[257]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[258]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[259]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[25]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[260]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[261]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[262]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[263]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[264]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[265]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[266]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[267]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[268]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[269]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[26]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[270]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[271]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[272]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[273]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[274]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[275]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[276]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[277]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[278]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[279]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[27]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[280]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[281]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[282]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[283]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[284]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[285]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[286]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[287]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[288]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[289]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[28]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[290]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[291]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[292]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[293]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[294]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[295]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[296]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[297]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[298]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[299]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[29]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[2]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[300]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[301]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[302]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[303]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[304]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[305]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[306]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[307]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[308]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[309]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[30]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[310]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[311]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[312]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[313]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[314]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[315]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[316]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[317]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[318]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[319]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[31]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[320]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[321]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[322]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[323]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[324]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[325]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[326]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[327]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[328]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[329]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[32]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[330]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[331]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[332]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[333]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[334]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[335]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[336]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[337]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[338]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[339]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[33]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[340]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[341]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[342]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[343]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[344]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[345]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[346]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[347]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[348]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[349]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[34]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[350]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[351]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[352]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[353]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[354]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[355]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[356]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[357]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[358]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[359]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[35]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[360]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[361]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[362]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[363]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[364]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[365]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[366]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[367]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[368]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[369]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[36]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[370]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[371]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[372]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[373]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[374]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[375]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[376]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[377]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[378]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[379]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[37]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[380]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[381]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[382]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[383]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[384]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[385]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[386]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[387]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[388]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[389]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[38]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[390]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[391]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[392]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[393]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[394]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[395]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[396]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[397]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[398]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[399]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[39]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[3]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[400]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[401]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[402]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[403]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[404]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[405]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[406]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[407]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[408]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[409]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[40]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[410]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[411]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[412]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[413]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[414]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[415]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[416]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[417]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[418]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[419]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[41]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[420]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[421]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[422]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[423]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[424]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[425]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[426]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[427]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[428]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[429]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[42]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[430]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[431]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[432]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[433]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[434]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[435]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[436]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[437]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[438]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[439]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[43]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[440]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[441]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[442]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[443]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[444]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[445]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[446]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[447]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[448]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[449]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[44]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[450]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[451]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[452]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[453]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[454]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[455]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[456]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[457]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[458]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[459]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[45]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[460]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[461]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[462]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[463]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[464]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[465]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[466]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[467]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[468]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[469]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[46]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[470]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[471]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[472]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[473]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[474]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[475]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[476]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[477]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[478]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[479]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[47]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[480]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[481]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[482]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[483]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[484]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[485]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[486]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[487]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[488]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[489]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[48]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[490]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[491]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[492]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[493]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[494]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[495]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[496]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[497]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[498]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[499]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[49]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[4]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[500]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[501]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[502]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[503]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[504]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[505]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[506]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[507]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[508]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[509]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[50]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[510]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[511]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[51]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[52]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[53]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[54]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[55]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[56]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[57]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[58]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[59]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[5]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[60]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[61]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[62]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[63]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[64]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[65]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[66]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[67]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[68]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[69]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[6]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[70]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[71]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[72]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[73]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[74]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[75]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[76]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[77]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[78]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[79]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[7]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[80]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[81]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[82]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[83]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[84]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[85]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[86]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[87]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[88]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[89]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[8]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[90]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[91]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[92]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[93]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[94]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[95]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[96]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[97]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[98]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[99]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_data_in[9]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {q_valid_in}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[0]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1000]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1001]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1002]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1003]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1004]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1005]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1006]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1007]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1008]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1009]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[100]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1010]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1011]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1012]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1013]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1014]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1015]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1016]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1017]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1018]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1019]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[101]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1020]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1021]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1022]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1023]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[102]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[103]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[104]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[105]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[106]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[107]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[108]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[109]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[10]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[110]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[111]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[112]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[113]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[114]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[115]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[116]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[117]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[118]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[119]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[11]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[120]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[121]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[122]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[123]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[124]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[125]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[126]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[127]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[128]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[129]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[12]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[130]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[131]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[132]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[133]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[134]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[135]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[136]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[137]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[138]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[139]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[13]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[140]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[141]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[142]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[143]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[144]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[145]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[146]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[147]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[148]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[149]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[14]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[150]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[151]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[152]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[153]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[154]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[155]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[156]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[157]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[158]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[159]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[15]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[160]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[161]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[162]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[163]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[164]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[165]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[166]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[167]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[168]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[169]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[16]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[170]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[171]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[172]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[173]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[174]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[175]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[176]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[177]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[178]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[179]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[17]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[180]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[181]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[182]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[183]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[184]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[185]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[186]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[187]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[188]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[189]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[18]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[190]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[191]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[192]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[193]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[194]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[195]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[196]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[197]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[198]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[199]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[19]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[1]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[200]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[201]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[202]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[203]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[204]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[205]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[206]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[207]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[208]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[209]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[20]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[210]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[211]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[212]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[213]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[214]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[215]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[216]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[217]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[218]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[219]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[21]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[220]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[221]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[222]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[223]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[224]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[225]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[226]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[227]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[228]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[229]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[22]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[230]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[231]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[232]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[233]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[234]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[235]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[236]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[237]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[238]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[239]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[23]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[240]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[241]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[242]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[243]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[244]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[245]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[246]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[247]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[248]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[249]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[24]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[250]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[251]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[252]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[253]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[254]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[255]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[256]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[257]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[258]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[259]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[25]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[260]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[261]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[262]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[263]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[264]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[265]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[266]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[267]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[268]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[269]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[26]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[270]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[271]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[272]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[273]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[274]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[275]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[276]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[277]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[278]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[279]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[27]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[280]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[281]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[282]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[283]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[284]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[285]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[286]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[287]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[288]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[289]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[28]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[290]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[291]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[292]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[293]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[294]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[295]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[296]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[297]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[298]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[299]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[29]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[2]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[300]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[301]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[302]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[303]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[304]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[305]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[306]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[307]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[308]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[309]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[30]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[310]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[311]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[312]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[313]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[314]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[315]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[316]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[317]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[318]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[319]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[31]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[320]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[321]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[322]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[323]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[324]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[325]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[326]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[327]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[328]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[329]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[32]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[330]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[331]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[332]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[333]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[334]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[335]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[336]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[337]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[338]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[339]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[33]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[340]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[341]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[342]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[343]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[344]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[345]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[346]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[347]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[348]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[349]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[34]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[350]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[351]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[352]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[353]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[354]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[355]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[356]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[357]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[358]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[359]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[35]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[360]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[361]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[362]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[363]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[364]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[365]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[366]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[367]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[368]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[369]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[36]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[370]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[371]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[372]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[373]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[374]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[375]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[376]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[377]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[378]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[379]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[37]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[380]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[381]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[382]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[383]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[384]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[385]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[386]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[387]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[388]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[389]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[38]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[390]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[391]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[392]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[393]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[394]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[395]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[396]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[397]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[398]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[399]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[39]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[3]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[400]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[401]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[402]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[403]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[404]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[405]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[406]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[407]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[408]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[409]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[40]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[410]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[411]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[412]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[413]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[414]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[415]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[416]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[417]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[418]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[419]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[41]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[420]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[421]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[422]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[423]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[424]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[425]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[426]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[427]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[428]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[429]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[42]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[430]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[431]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[432]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[433]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[434]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[435]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[436]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[437]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[438]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[439]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[43]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[440]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[441]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[442]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[443]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[444]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[445]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[446]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[447]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[448]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[449]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[44]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[450]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[451]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[452]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[453]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[454]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[455]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[456]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[457]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[458]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[459]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[45]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[460]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[461]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[462]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[463]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[464]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[465]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[466]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[467]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[468]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[469]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[46]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[470]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[471]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[472]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[473]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[474]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[475]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[476]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[477]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[478]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[479]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[47]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[480]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[481]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[482]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[483]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[484]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[485]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[486]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[487]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[488]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[489]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[48]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[490]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[491]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[492]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[493]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[494]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[495]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[496]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[497]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[498]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[499]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[49]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[4]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[500]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[501]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[502]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[503]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[504]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[505]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[506]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[507]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[508]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[509]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[50]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[510]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[511]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[512]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[513]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[514]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[515]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[516]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[517]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[518]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[519]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[51]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[520]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[521]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[522]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[523]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[524]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[525]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[526]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[527]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[528]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[529]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[52]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[530]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[531]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[532]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[533]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[534]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[535]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[536]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[537]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[538]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[539]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[53]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[540]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[541]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[542]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[543]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[544]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[545]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[546]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[547]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[548]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[549]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[54]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[550]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[551]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[552]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[553]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[554]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[555]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[556]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[557]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[558]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[559]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[55]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[560]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[561]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[562]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[563]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[564]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[565]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[566]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[567]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[568]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[569]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[56]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[570]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[571]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[572]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[573]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[574]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[575]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[576]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[577]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[578]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[579]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[57]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[580]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[581]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[582]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[583]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[584]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[585]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[586]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[587]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[588]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[589]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[58]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[590]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[591]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[592]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[593]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[594]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[595]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[596]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[597]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[598]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[599]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[59]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[5]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[600]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[601]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[602]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[603]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[604]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[605]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[606]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[607]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[608]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[609]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[60]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[610]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[611]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[612]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[613]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[614]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[615]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[616]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[617]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[618]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[619]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[61]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[620]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[621]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[622]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[623]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[624]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[625]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[626]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[627]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[628]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[629]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[62]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[630]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[631]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[632]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[633]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[634]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[635]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[636]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[637]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[638]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[639]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[63]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[640]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[641]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[642]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[643]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[644]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[645]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[646]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[647]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[648]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[649]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[64]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[650]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[651]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[652]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[653]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[654]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[655]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[656]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[657]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[658]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[659]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[65]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[660]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[661]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[662]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[663]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[664]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[665]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[666]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[667]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[668]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[669]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[66]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[670]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[671]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[672]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[673]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[674]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[675]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[676]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[677]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[678]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[679]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[67]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[680]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[681]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[682]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[683]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[684]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[685]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[686]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[687]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[688]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[689]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[68]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[690]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[691]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[692]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[693]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[694]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[695]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[696]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[697]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[698]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[699]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[69]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[6]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[700]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[701]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[702]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[703]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[704]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[705]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[706]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[707]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[708]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[709]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[70]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[710]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[711]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[712]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[713]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[714]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[715]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[716]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[717]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[718]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[719]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[71]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[720]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[721]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[722]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[723]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[724]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[725]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[726]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[727]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[728]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[729]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[72]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[730]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[731]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[732]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[733]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[734]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[735]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[736]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[737]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[738]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[739]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[73]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[740]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[741]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[742]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[743]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[744]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[745]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[746]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[747]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[748]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[749]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[74]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[750]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[751]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[752]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[753]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[754]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[755]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[756]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[757]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[758]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[759]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[75]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[760]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[761]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[762]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[763]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[764]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[765]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[766]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[767]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[768]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[769]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[76]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[770]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[771]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[772]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[773]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[774]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[775]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[776]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[777]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[778]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[779]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[77]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[780]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[781]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[782]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[783]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[784]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[785]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[786]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[787]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[788]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[789]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[78]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[790]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[791]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[792]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[793]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[794]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[795]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[796]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[797]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[798]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[799]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[79]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[7]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[800]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[801]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[802]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[803]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[804]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[805]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[806]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[807]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[808]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[809]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[80]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[810]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[811]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[812]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[813]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[814]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[815]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[816]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[817]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[818]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[819]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[81]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[820]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[821]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[822]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[823]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[824]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[825]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[826]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[827]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[828]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[829]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[82]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[830]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[831]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[832]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[833]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[834]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[835]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[836]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[837]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[838]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[839]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[83]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[840]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[841]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[842]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[843]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[844]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[845]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[846]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[847]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[848]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[849]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[84]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[850]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[851]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[852]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[853]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[854]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[855]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[856]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[857]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[858]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[859]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[85]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[860]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[861]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[862]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[863]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[864]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[865]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[866]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[867]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[868]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[869]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[86]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[870]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[871]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[872]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[873]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[874]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[875]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[876]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[877]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[878]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[879]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[87]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[880]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[881]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[882]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[883]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[884]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[885]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[886]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[887]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[888]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[889]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[88]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[890]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[891]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[892]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[893]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[894]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[895]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[896]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[897]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[898]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[899]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[89]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[8]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[900]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[901]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[902]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[903]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[904]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[905]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[906]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[907]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[908]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[909]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[90]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[910]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[911]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[912]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[913]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[914]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[915]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[916]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[917]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[918]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[919]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[91]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[920]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[921]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[922]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[923]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[924]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[925]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[926]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[927]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[928]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[929]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[92]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[930]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[931]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[932]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[933]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[934]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[935]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[936]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[937]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[938]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[939]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[93]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[940]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[941]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[942]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[943]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[944]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[945]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[946]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[947]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[948]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[949]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[94]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[950]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[951]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[952]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[953]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[954]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[955]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[956]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[957]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[958]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[959]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[95]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[960]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[961]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[962]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[963]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[964]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[965]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[966]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[967]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[968]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[969]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[96]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[970]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[971]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[972]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[973]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[974]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[975]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[976]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[977]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[978]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[979]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[97]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[980]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[981]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[982]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[983]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[984]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[985]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[986]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[987]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[988]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[989]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[98]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[990]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[991]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[992]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[993]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[994]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[995]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[996]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[997]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[998]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[999]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[99]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {row_in[9]}]
set_input_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {rst_n}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {g_f}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[0]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1000]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1001]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1002]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1003]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1004]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1005]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1006]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1007]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1008]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1009]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[100]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1010]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1011]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1012]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1013]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1014]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1015]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1016]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1017]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1018]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1019]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[101]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1020]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1021]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1022]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1023]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[102]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[103]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[104]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[105]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[106]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[107]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[108]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[109]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[10]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[110]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[111]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[112]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[113]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[114]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[115]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[116]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[117]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[118]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[119]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[11]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[120]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[121]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[122]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[123]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[124]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[125]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[126]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[127]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[128]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[129]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[12]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[130]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[131]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[132]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[133]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[134]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[135]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[136]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[137]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[138]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[139]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[13]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[140]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[141]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[142]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[143]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[144]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[145]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[146]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[147]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[148]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[149]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[14]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[150]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[151]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[152]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[153]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[154]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[155]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[156]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[157]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[158]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[159]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[15]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[160]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[161]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[162]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[163]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[164]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[165]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[166]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[167]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[168]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[169]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[16]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[170]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[171]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[172]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[173]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[174]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[175]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[176]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[177]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[178]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[179]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[17]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[180]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[181]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[182]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[183]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[184]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[185]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[186]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[187]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[188]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[189]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[18]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[190]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[191]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[192]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[193]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[194]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[195]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[196]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[197]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[198]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[199]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[19]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[1]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[200]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[201]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[202]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[203]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[204]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[205]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[206]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[207]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[208]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[209]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[20]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[210]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[211]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[212]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[213]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[214]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[215]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[216]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[217]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[218]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[219]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[21]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[220]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[221]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[222]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[223]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[224]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[225]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[226]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[227]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[228]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[229]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[22]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[230]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[231]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[232]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[233]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[234]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[235]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[236]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[237]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[238]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[239]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[23]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[240]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[241]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[242]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[243]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[244]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[245]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[246]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[247]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[248]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[249]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[24]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[250]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[251]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[252]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[253]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[254]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[255]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[256]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[257]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[258]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[259]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[25]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[260]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[261]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[262]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[263]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[264]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[265]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[266]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[267]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[268]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[269]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[26]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[270]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[271]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[272]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[273]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[274]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[275]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[276]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[277]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[278]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[279]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[27]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[280]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[281]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[282]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[283]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[284]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[285]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[286]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[287]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[288]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[289]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[28]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[290]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[291]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[292]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[293]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[294]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[295]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[296]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[297]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[298]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[299]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[29]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[2]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[300]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[301]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[302]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[303]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[304]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[305]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[306]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[307]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[308]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[309]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[30]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[310]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[311]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[312]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[313]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[314]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[315]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[316]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[317]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[318]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[319]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[31]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[320]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[321]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[322]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[323]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[324]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[325]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[326]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[327]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[328]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[329]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[32]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[330]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[331]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[332]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[333]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[334]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[335]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[336]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[337]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[338]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[339]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[33]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[340]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[341]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[342]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[343]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[344]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[345]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[346]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[347]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[348]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[349]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[34]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[350]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[351]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[352]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[353]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[354]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[355]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[356]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[357]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[358]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[359]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[35]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[360]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[361]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[362]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[363]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[364]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[365]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[366]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[367]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[368]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[369]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[36]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[370]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[371]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[372]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[373]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[374]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[375]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[376]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[377]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[378]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[379]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[37]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[380]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[381]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[382]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[383]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[384]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[385]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[386]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[387]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[388]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[389]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[38]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[390]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[391]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[392]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[393]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[394]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[395]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[396]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[397]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[398]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[399]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[39]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[3]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[400]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[401]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[402]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[403]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[404]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[405]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[406]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[407]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[408]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[409]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[40]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[410]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[411]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[412]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[413]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[414]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[415]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[416]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[417]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[418]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[419]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[41]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[420]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[421]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[422]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[423]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[424]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[425]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[426]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[427]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[428]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[429]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[42]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[430]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[431]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[432]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[433]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[434]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[435]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[436]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[437]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[438]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[439]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[43]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[440]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[441]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[442]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[443]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[444]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[445]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[446]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[447]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[448]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[449]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[44]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[450]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[451]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[452]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[453]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[454]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[455]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[456]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[457]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[458]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[459]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[45]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[460]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[461]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[462]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[463]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[464]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[465]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[466]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[467]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[468]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[469]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[46]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[470]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[471]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[472]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[473]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[474]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[475]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[476]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[477]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[478]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[479]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[47]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[480]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[481]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[482]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[483]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[484]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[485]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[486]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[487]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[488]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[489]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[48]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[490]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[491]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[492]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[493]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[494]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[495]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[496]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[497]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[498]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[499]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[49]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[4]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[500]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[501]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[502]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[503]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[504]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[505]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[506]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[507]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[508]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[509]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[50]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[510]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[511]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[512]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[513]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[514]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[515]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[516]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[517]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[518]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[519]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[51]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[520]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[521]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[522]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[523]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[524]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[525]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[526]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[527]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[528]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[529]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[52]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[530]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[531]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[532]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[533]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[534]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[535]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[536]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[537]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[538]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[539]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[53]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[540]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[541]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[542]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[543]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[544]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[545]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[546]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[547]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[548]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[549]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[54]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[550]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[551]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[552]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[553]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[554]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[555]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[556]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[557]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[558]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[559]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[55]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[560]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[561]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[562]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[563]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[564]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[565]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[566]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[567]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[568]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[569]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[56]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[570]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[571]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[572]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[573]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[574]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[575]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[576]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[577]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[578]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[579]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[57]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[580]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[581]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[582]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[583]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[584]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[585]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[586]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[587]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[588]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[589]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[58]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[590]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[591]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[592]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[593]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[594]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[595]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[596]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[597]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[598]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[599]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[59]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[5]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[600]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[601]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[602]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[603]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[604]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[605]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[606]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[607]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[608]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[609]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[60]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[610]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[611]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[612]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[613]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[614]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[615]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[616]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[617]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[618]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[619]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[61]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[620]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[621]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[622]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[623]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[624]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[625]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[626]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[627]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[628]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[629]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[62]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[630]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[631]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[632]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[633]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[634]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[635]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[636]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[637]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[638]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[639]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[63]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[640]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[641]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[642]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[643]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[644]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[645]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[646]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[647]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[648]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[649]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[64]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[650]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[651]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[652]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[653]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[654]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[655]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[656]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[657]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[658]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[659]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[65]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[660]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[661]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[662]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[663]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[664]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[665]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[666]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[667]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[668]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[669]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[66]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[670]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[671]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[672]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[673]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[674]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[675]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[676]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[677]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[678]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[679]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[67]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[680]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[681]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[682]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[683]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[684]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[685]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[686]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[687]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[688]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[689]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[68]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[690]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[691]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[692]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[693]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[694]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[695]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[696]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[697]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[698]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[699]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[69]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[6]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[700]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[701]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[702]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[703]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[704]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[705]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[706]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[707]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[708]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[709]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[70]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[710]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[711]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[712]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[713]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[714]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[715]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[716]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[717]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[718]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[719]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[71]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[720]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[721]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[722]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[723]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[724]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[725]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[726]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[727]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[728]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[729]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[72]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[730]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[731]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[732]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[733]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[734]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[735]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[736]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[737]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[738]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[739]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[73]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[740]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[741]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[742]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[743]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[744]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[745]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[746]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[747]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[748]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[749]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[74]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[750]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[751]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[752]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[753]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[754]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[755]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[756]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[757]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[758]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[759]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[75]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[760]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[761]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[762]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[763]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[764]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[765]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[766]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[767]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[768]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[769]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[76]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[770]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[771]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[772]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[773]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[774]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[775]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[776]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[777]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[778]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[779]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[77]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[780]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[781]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[782]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[783]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[784]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[785]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[786]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[787]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[788]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[789]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[78]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[790]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[791]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[792]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[793]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[794]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[795]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[796]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[797]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[798]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[799]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[79]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[7]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[800]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[801]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[802]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[803]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[804]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[805]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[806]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[807]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[808]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[809]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[80]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[810]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[811]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[812]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[813]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[814]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[815]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[816]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[817]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[818]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[819]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[81]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[820]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[821]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[822]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[823]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[824]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[825]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[826]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[827]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[828]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[829]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[82]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[830]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[831]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[832]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[833]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[834]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[835]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[836]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[837]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[838]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[839]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[83]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[840]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[841]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[842]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[843]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[844]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[845]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[846]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[847]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[848]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[849]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[84]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[850]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[851]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[852]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[853]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[854]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[855]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[856]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[857]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[858]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[859]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[85]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[860]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[861]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[862]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[863]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[864]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[865]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[866]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[867]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[868]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[869]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[86]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[870]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[871]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[872]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[873]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[874]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[875]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[876]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[877]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[878]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[879]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[87]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[880]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[881]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[882]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[883]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[884]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[885]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[886]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[887]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[888]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[889]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[88]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[890]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[891]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[892]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[893]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[894]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[895]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[896]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[897]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[898]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[899]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[89]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[8]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[900]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[901]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[902]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[903]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[904]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[905]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[906]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[907]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[908]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[909]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[90]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[910]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[911]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[912]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[913]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[914]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[915]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[916]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[917]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[918]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[919]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[91]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[920]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[921]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[922]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[923]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[924]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[925]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[926]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[927]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[928]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[929]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[92]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[930]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[931]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[932]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[933]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[934]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[935]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[936]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[937]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[938]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[939]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[93]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[940]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[941]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[942]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[943]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[944]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[945]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[946]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[947]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[948]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[949]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[94]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[950]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[951]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[952]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[953]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[954]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[955]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[956]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[957]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[958]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[959]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[95]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[960]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[961]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[962]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[963]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[964]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[965]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[966]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[967]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[968]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[969]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[96]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[970]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[971]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[972]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[973]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[974]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[975]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[976]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[977]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[978]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[979]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[97]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[980]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[981]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[982]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[983]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[984]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[985]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[986]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[987]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[988]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[989]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[98]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[990]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[991]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[992]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[993]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[994]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[995]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[996]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[997]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[998]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[999]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[99]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {nb_d[9]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[0]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[10]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[11]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[12]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[13]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[14]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[15]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[16]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[17]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[18]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[19]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[1]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[20]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[21]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[22]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[23]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[24]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[25]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[26]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[27]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[28]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[29]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[2]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[30]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[31]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[3]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[4]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[5]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[6]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[7]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[8]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_d[9]}]
set_output_delay 166.6670 -clock [get_clocks {core_clk}] -add_delay [get_ports {sc_f}]
set_false_path\
    -from [get_clocks {ot_lb_v_core_clk}]\
    -to [list [get_pins {c2[1]$_DFF_PN0_/RESETN}]\
           [get_pins {c2[1]$_DFF_PN0_/SETN}]\
           [get_pins {c2[2]$_DFF_PN0_/RESETN}]\
           [get_pins {c2[2]$_DFF_PN0_/SETN}]\
           [get_pins {c2[3]$_DFF_PN0_/RESETN}]\
           [get_pins {c2[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_rkv/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_rkv/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[0].u_rkv/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[0].u_rkv/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[10].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[10].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[11].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[11].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[12].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[12].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[13].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[13].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[14].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[14].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[15].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[15].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[1].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[1].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[2].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[2].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[3].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[3].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[4].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[4].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[5].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[5].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[6].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[6].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[7].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[7].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[8].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[8].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/q[9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/q[9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][10]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][10]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][11]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][11]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][12]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][12]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][13]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][13]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][14]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][14]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][15]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][15]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][1]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][1]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][2]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][2]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][3]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][3]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][4]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][4]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][5]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][5]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][6]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][6]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][7]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][7]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][8]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][8]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_ric/r[0][9]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_ric/r[0][9]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_rkv/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_rkv/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {g_t[9].u_rkv/r[0][0]$_DFF_PN0_/RESETN}]\
           [get_pins {g_t[9].u_rkv/r[0][0]$_DFF_PN0_/SETN}]\
           [get_pins {lt2[0]$_DFF_PN0_/RESETN}]\
           [get_pins {lt2[0]$_DFF_PN0_/SETN}]\
           [get_pins {lt2[10]$_DFF_PN0_/RESETN}]\
           [get_pins {lt2[10]$_DFF_PN0_/SETN}]\
           [get_pins {lt2[11]$_DFF_PN0_/RESETN}]\
           [get_pins {lt2[11]$_DFF_PN0_/SETN}]\
           [get_pins {lt2[1]$_DFF_PN0_/RESETN}]\
           [get_pins {lt2[1]$_DFF_PN0_/SETN}]\
           [get_pins {lt2[2]$_DFF_PN0_/RESETN}]\
           [get_pins {lt2[2]$_DFF_PN0_/SETN}]\
           [get_pins {lt2[3]$_DFF_PN0_/RESETN}]\
           [get_pins {lt2[3]$_DFF_PN0_/SETN}]\
           [get_pins {lt2[4]$_DFF_PN0_/RESETN}]\
           [get_pins {lt2[4]$_DFF_PN0_/SETN}]\
           [get_pins {lt2[5]$_DFF_PN0_/RESETN}]\
           [get_pins {lt2[5]$_DFF_PN0_/SETN}]\
           [get_pins {lt2[6]$_DFF_PN0_/RESETN}]\
           [get_pins {lt2[6]$_DFF_PN0_/SETN}]\
           [get_pins {lt2[7]$_DFF_PN0_/RESETN}]\
           [get_pins {lt2[7]$_DFF_PN0_/SETN}]\
           [get_pins {lt2[8]$_DFF_PN0_/RESETN}]\
           [get_pins {lt2[8]$_DFF_PN0_/SETN}]\
           [get_pins {lt2[9]$_DFF_PN0_/RESETN}]\
           [get_pins {lt2[9]$_DFF_PN0_/SETN}]\
           [get_pins {qv2$_DFF_PN0_/RESETN}]\
           [get_pins {qv2$_DFF_PN0_/SETN}]\
           [get_pins {u_rof/q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rof/q[0]$_DFF_PN0_/SETN}]\
           [get_pins {u_rof/q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rof/q[1]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[0]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[0]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[10]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[10]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[11]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[11]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[12]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[12]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[13]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[13]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[14]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[14]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[15]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[15]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[16]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[16]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[17]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[17]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[1]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[1]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[2]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[2]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[3]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[3]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[4]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[4]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[5]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[5]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[6]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[6]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[7]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[7]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[8]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[8]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.rst_n[9]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.rst_n[9]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.sync_q[0]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.sync_q[0]$_DFF_PN0_/SETN}]\
           [get_pins {u_rr.sync_q[1]$_DFF_PN0_/RESETN}]\
           [get_pins {u_rr.sync_q[1]$_DFF_PN0_/SETN}]]
###############################################################################
# Environment
###############################################################################
set_input_transition 150.0000 [get_ports {q_valid_in}]
set_input_transition 150.0000 [get_ports {rst_n}]
set_input_transition 150.0000 [get_ports {c_in[3]}]
set_input_transition 150.0000 [get_ports {c_in[2]}]
set_input_transition 150.0000 [get_ports {c_in[1]}]
set_input_transition 150.0000 [get_ports {c_in[0]}]
set_input_transition 150.0000 [get_ports {e_in[15]}]
set_input_transition 150.0000 [get_ports {e_in[14]}]
set_input_transition 150.0000 [get_ports {e_in[13]}]
set_input_transition 150.0000 [get_ports {e_in[12]}]
set_input_transition 150.0000 [get_ports {e_in[11]}]
set_input_transition 150.0000 [get_ports {e_in[10]}]
set_input_transition 150.0000 [get_ports {e_in[9]}]
set_input_transition 150.0000 [get_ports {e_in[8]}]
set_input_transition 150.0000 [get_ports {e_in[7]}]
set_input_transition 150.0000 [get_ports {e_in[6]}]
set_input_transition 150.0000 [get_ports {e_in[5]}]
set_input_transition 150.0000 [get_ports {e_in[4]}]
set_input_transition 150.0000 [get_ports {e_in[3]}]
set_input_transition 150.0000 [get_ports {e_in[2]}]
set_input_transition 150.0000 [get_ports {e_in[1]}]
set_input_transition 150.0000 [get_ports {e_in[0]}]
set_input_transition 150.0000 [get_ports {hid[1]}]
set_input_transition 150.0000 [get_ports {hid[0]}]
set_input_transition 150.0000 [get_ports {lt_in[11]}]
set_input_transition 150.0000 [get_ports {lt_in[10]}]
set_input_transition 150.0000 [get_ports {lt_in[9]}]
set_input_transition 150.0000 [get_ports {lt_in[8]}]
set_input_transition 150.0000 [get_ports {lt_in[7]}]
set_input_transition 150.0000 [get_ports {lt_in[6]}]
set_input_transition 150.0000 [get_ports {lt_in[5]}]
set_input_transition 150.0000 [get_ports {lt_in[4]}]
set_input_transition 150.0000 [get_ports {lt_in[3]}]
set_input_transition 150.0000 [get_ports {lt_in[2]}]
set_input_transition 150.0000 [get_ports {lt_in[1]}]
set_input_transition 150.0000 [get_ports {lt_in[0]}]
set_input_transition 150.0000 [get_ports {q_beat_in[5]}]
set_input_transition 150.0000 [get_ports {q_beat_in[4]}]
set_input_transition 150.0000 [get_ports {q_beat_in[3]}]
set_input_transition 150.0000 [get_ports {q_beat_in[2]}]
set_input_transition 150.0000 [get_ports {q_beat_in[1]}]
set_input_transition 150.0000 [get_ports {q_beat_in[0]}]
set_input_transition 150.0000 [get_ports {q_data_in[511]}]
set_input_transition 150.0000 [get_ports {q_data_in[510]}]
set_input_transition 150.0000 [get_ports {q_data_in[509]}]
set_input_transition 150.0000 [get_ports {q_data_in[508]}]
set_input_transition 150.0000 [get_ports {q_data_in[507]}]
set_input_transition 150.0000 [get_ports {q_data_in[506]}]
set_input_transition 150.0000 [get_ports {q_data_in[505]}]
set_input_transition 150.0000 [get_ports {q_data_in[504]}]
set_input_transition 150.0000 [get_ports {q_data_in[503]}]
set_input_transition 150.0000 [get_ports {q_data_in[502]}]
set_input_transition 150.0000 [get_ports {q_data_in[501]}]
set_input_transition 150.0000 [get_ports {q_data_in[500]}]
set_input_transition 150.0000 [get_ports {q_data_in[499]}]
set_input_transition 150.0000 [get_ports {q_data_in[498]}]
set_input_transition 150.0000 [get_ports {q_data_in[497]}]
set_input_transition 150.0000 [get_ports {q_data_in[496]}]
set_input_transition 150.0000 [get_ports {q_data_in[495]}]
set_input_transition 150.0000 [get_ports {q_data_in[494]}]
set_input_transition 150.0000 [get_ports {q_data_in[493]}]
set_input_transition 150.0000 [get_ports {q_data_in[492]}]
set_input_transition 150.0000 [get_ports {q_data_in[491]}]
set_input_transition 150.0000 [get_ports {q_data_in[490]}]
set_input_transition 150.0000 [get_ports {q_data_in[489]}]
set_input_transition 150.0000 [get_ports {q_data_in[488]}]
set_input_transition 150.0000 [get_ports {q_data_in[487]}]
set_input_transition 150.0000 [get_ports {q_data_in[486]}]
set_input_transition 150.0000 [get_ports {q_data_in[485]}]
set_input_transition 150.0000 [get_ports {q_data_in[484]}]
set_input_transition 150.0000 [get_ports {q_data_in[483]}]
set_input_transition 150.0000 [get_ports {q_data_in[482]}]
set_input_transition 150.0000 [get_ports {q_data_in[481]}]
set_input_transition 150.0000 [get_ports {q_data_in[480]}]
set_input_transition 150.0000 [get_ports {q_data_in[479]}]
set_input_transition 150.0000 [get_ports {q_data_in[478]}]
set_input_transition 150.0000 [get_ports {q_data_in[477]}]
set_input_transition 150.0000 [get_ports {q_data_in[476]}]
set_input_transition 150.0000 [get_ports {q_data_in[475]}]
set_input_transition 150.0000 [get_ports {q_data_in[474]}]
set_input_transition 150.0000 [get_ports {q_data_in[473]}]
set_input_transition 150.0000 [get_ports {q_data_in[472]}]
set_input_transition 150.0000 [get_ports {q_data_in[471]}]
set_input_transition 150.0000 [get_ports {q_data_in[470]}]
set_input_transition 150.0000 [get_ports {q_data_in[469]}]
set_input_transition 150.0000 [get_ports {q_data_in[468]}]
set_input_transition 150.0000 [get_ports {q_data_in[467]}]
set_input_transition 150.0000 [get_ports {q_data_in[466]}]
set_input_transition 150.0000 [get_ports {q_data_in[465]}]
set_input_transition 150.0000 [get_ports {q_data_in[464]}]
set_input_transition 150.0000 [get_ports {q_data_in[463]}]
set_input_transition 150.0000 [get_ports {q_data_in[462]}]
set_input_transition 150.0000 [get_ports {q_data_in[461]}]
set_input_transition 150.0000 [get_ports {q_data_in[460]}]
set_input_transition 150.0000 [get_ports {q_data_in[459]}]
set_input_transition 150.0000 [get_ports {q_data_in[458]}]
set_input_transition 150.0000 [get_ports {q_data_in[457]}]
set_input_transition 150.0000 [get_ports {q_data_in[456]}]
set_input_transition 150.0000 [get_ports {q_data_in[455]}]
set_input_transition 150.0000 [get_ports {q_data_in[454]}]
set_input_transition 150.0000 [get_ports {q_data_in[453]}]
set_input_transition 150.0000 [get_ports {q_data_in[452]}]
set_input_transition 150.0000 [get_ports {q_data_in[451]}]
set_input_transition 150.0000 [get_ports {q_data_in[450]}]
set_input_transition 150.0000 [get_ports {q_data_in[449]}]
set_input_transition 150.0000 [get_ports {q_data_in[448]}]
set_input_transition 150.0000 [get_ports {q_data_in[447]}]
set_input_transition 150.0000 [get_ports {q_data_in[446]}]
set_input_transition 150.0000 [get_ports {q_data_in[445]}]
set_input_transition 150.0000 [get_ports {q_data_in[444]}]
set_input_transition 150.0000 [get_ports {q_data_in[443]}]
set_input_transition 150.0000 [get_ports {q_data_in[442]}]
set_input_transition 150.0000 [get_ports {q_data_in[441]}]
set_input_transition 150.0000 [get_ports {q_data_in[440]}]
set_input_transition 150.0000 [get_ports {q_data_in[439]}]
set_input_transition 150.0000 [get_ports {q_data_in[438]}]
set_input_transition 150.0000 [get_ports {q_data_in[437]}]
set_input_transition 150.0000 [get_ports {q_data_in[436]}]
set_input_transition 150.0000 [get_ports {q_data_in[435]}]
set_input_transition 150.0000 [get_ports {q_data_in[434]}]
set_input_transition 150.0000 [get_ports {q_data_in[433]}]
set_input_transition 150.0000 [get_ports {q_data_in[432]}]
set_input_transition 150.0000 [get_ports {q_data_in[431]}]
set_input_transition 150.0000 [get_ports {q_data_in[430]}]
set_input_transition 150.0000 [get_ports {q_data_in[429]}]
set_input_transition 150.0000 [get_ports {q_data_in[428]}]
set_input_transition 150.0000 [get_ports {q_data_in[427]}]
set_input_transition 150.0000 [get_ports {q_data_in[426]}]
set_input_transition 150.0000 [get_ports {q_data_in[425]}]
set_input_transition 150.0000 [get_ports {q_data_in[424]}]
set_input_transition 150.0000 [get_ports {q_data_in[423]}]
set_input_transition 150.0000 [get_ports {q_data_in[422]}]
set_input_transition 150.0000 [get_ports {q_data_in[421]}]
set_input_transition 150.0000 [get_ports {q_data_in[420]}]
set_input_transition 150.0000 [get_ports {q_data_in[419]}]
set_input_transition 150.0000 [get_ports {q_data_in[418]}]
set_input_transition 150.0000 [get_ports {q_data_in[417]}]
set_input_transition 150.0000 [get_ports {q_data_in[416]}]
set_input_transition 150.0000 [get_ports {q_data_in[415]}]
set_input_transition 150.0000 [get_ports {q_data_in[414]}]
set_input_transition 150.0000 [get_ports {q_data_in[413]}]
set_input_transition 150.0000 [get_ports {q_data_in[412]}]
set_input_transition 150.0000 [get_ports {q_data_in[411]}]
set_input_transition 150.0000 [get_ports {q_data_in[410]}]
set_input_transition 150.0000 [get_ports {q_data_in[409]}]
set_input_transition 150.0000 [get_ports {q_data_in[408]}]
set_input_transition 150.0000 [get_ports {q_data_in[407]}]
set_input_transition 150.0000 [get_ports {q_data_in[406]}]
set_input_transition 150.0000 [get_ports {q_data_in[405]}]
set_input_transition 150.0000 [get_ports {q_data_in[404]}]
set_input_transition 150.0000 [get_ports {q_data_in[403]}]
set_input_transition 150.0000 [get_ports {q_data_in[402]}]
set_input_transition 150.0000 [get_ports {q_data_in[401]}]
set_input_transition 150.0000 [get_ports {q_data_in[400]}]
set_input_transition 150.0000 [get_ports {q_data_in[399]}]
set_input_transition 150.0000 [get_ports {q_data_in[398]}]
set_input_transition 150.0000 [get_ports {q_data_in[397]}]
set_input_transition 150.0000 [get_ports {q_data_in[396]}]
set_input_transition 150.0000 [get_ports {q_data_in[395]}]
set_input_transition 150.0000 [get_ports {q_data_in[394]}]
set_input_transition 150.0000 [get_ports {q_data_in[393]}]
set_input_transition 150.0000 [get_ports {q_data_in[392]}]
set_input_transition 150.0000 [get_ports {q_data_in[391]}]
set_input_transition 150.0000 [get_ports {q_data_in[390]}]
set_input_transition 150.0000 [get_ports {q_data_in[389]}]
set_input_transition 150.0000 [get_ports {q_data_in[388]}]
set_input_transition 150.0000 [get_ports {q_data_in[387]}]
set_input_transition 150.0000 [get_ports {q_data_in[386]}]
set_input_transition 150.0000 [get_ports {q_data_in[385]}]
set_input_transition 150.0000 [get_ports {q_data_in[384]}]
set_input_transition 150.0000 [get_ports {q_data_in[383]}]
set_input_transition 150.0000 [get_ports {q_data_in[382]}]
set_input_transition 150.0000 [get_ports {q_data_in[381]}]
set_input_transition 150.0000 [get_ports {q_data_in[380]}]
set_input_transition 150.0000 [get_ports {q_data_in[379]}]
set_input_transition 150.0000 [get_ports {q_data_in[378]}]
set_input_transition 150.0000 [get_ports {q_data_in[377]}]
set_input_transition 150.0000 [get_ports {q_data_in[376]}]
set_input_transition 150.0000 [get_ports {q_data_in[375]}]
set_input_transition 150.0000 [get_ports {q_data_in[374]}]
set_input_transition 150.0000 [get_ports {q_data_in[373]}]
set_input_transition 150.0000 [get_ports {q_data_in[372]}]
set_input_transition 150.0000 [get_ports {q_data_in[371]}]
set_input_transition 150.0000 [get_ports {q_data_in[370]}]
set_input_transition 150.0000 [get_ports {q_data_in[369]}]
set_input_transition 150.0000 [get_ports {q_data_in[368]}]
set_input_transition 150.0000 [get_ports {q_data_in[367]}]
set_input_transition 150.0000 [get_ports {q_data_in[366]}]
set_input_transition 150.0000 [get_ports {q_data_in[365]}]
set_input_transition 150.0000 [get_ports {q_data_in[364]}]
set_input_transition 150.0000 [get_ports {q_data_in[363]}]
set_input_transition 150.0000 [get_ports {q_data_in[362]}]
set_input_transition 150.0000 [get_ports {q_data_in[361]}]
set_input_transition 150.0000 [get_ports {q_data_in[360]}]
set_input_transition 150.0000 [get_ports {q_data_in[359]}]
set_input_transition 150.0000 [get_ports {q_data_in[358]}]
set_input_transition 150.0000 [get_ports {q_data_in[357]}]
set_input_transition 150.0000 [get_ports {q_data_in[356]}]
set_input_transition 150.0000 [get_ports {q_data_in[355]}]
set_input_transition 150.0000 [get_ports {q_data_in[354]}]
set_input_transition 150.0000 [get_ports {q_data_in[353]}]
set_input_transition 150.0000 [get_ports {q_data_in[352]}]
set_input_transition 150.0000 [get_ports {q_data_in[351]}]
set_input_transition 150.0000 [get_ports {q_data_in[350]}]
set_input_transition 150.0000 [get_ports {q_data_in[349]}]
set_input_transition 150.0000 [get_ports {q_data_in[348]}]
set_input_transition 150.0000 [get_ports {q_data_in[347]}]
set_input_transition 150.0000 [get_ports {q_data_in[346]}]
set_input_transition 150.0000 [get_ports {q_data_in[345]}]
set_input_transition 150.0000 [get_ports {q_data_in[344]}]
set_input_transition 150.0000 [get_ports {q_data_in[343]}]
set_input_transition 150.0000 [get_ports {q_data_in[342]}]
set_input_transition 150.0000 [get_ports {q_data_in[341]}]
set_input_transition 150.0000 [get_ports {q_data_in[340]}]
set_input_transition 150.0000 [get_ports {q_data_in[339]}]
set_input_transition 150.0000 [get_ports {q_data_in[338]}]
set_input_transition 150.0000 [get_ports {q_data_in[337]}]
set_input_transition 150.0000 [get_ports {q_data_in[336]}]
set_input_transition 150.0000 [get_ports {q_data_in[335]}]
set_input_transition 150.0000 [get_ports {q_data_in[334]}]
set_input_transition 150.0000 [get_ports {q_data_in[333]}]
set_input_transition 150.0000 [get_ports {q_data_in[332]}]
set_input_transition 150.0000 [get_ports {q_data_in[331]}]
set_input_transition 150.0000 [get_ports {q_data_in[330]}]
set_input_transition 150.0000 [get_ports {q_data_in[329]}]
set_input_transition 150.0000 [get_ports {q_data_in[328]}]
set_input_transition 150.0000 [get_ports {q_data_in[327]}]
set_input_transition 150.0000 [get_ports {q_data_in[326]}]
set_input_transition 150.0000 [get_ports {q_data_in[325]}]
set_input_transition 150.0000 [get_ports {q_data_in[324]}]
set_input_transition 150.0000 [get_ports {q_data_in[323]}]
set_input_transition 150.0000 [get_ports {q_data_in[322]}]
set_input_transition 150.0000 [get_ports {q_data_in[321]}]
set_input_transition 150.0000 [get_ports {q_data_in[320]}]
set_input_transition 150.0000 [get_ports {q_data_in[319]}]
set_input_transition 150.0000 [get_ports {q_data_in[318]}]
set_input_transition 150.0000 [get_ports {q_data_in[317]}]
set_input_transition 150.0000 [get_ports {q_data_in[316]}]
set_input_transition 150.0000 [get_ports {q_data_in[315]}]
set_input_transition 150.0000 [get_ports {q_data_in[314]}]
set_input_transition 150.0000 [get_ports {q_data_in[313]}]
set_input_transition 150.0000 [get_ports {q_data_in[312]}]
set_input_transition 150.0000 [get_ports {q_data_in[311]}]
set_input_transition 150.0000 [get_ports {q_data_in[310]}]
set_input_transition 150.0000 [get_ports {q_data_in[309]}]
set_input_transition 150.0000 [get_ports {q_data_in[308]}]
set_input_transition 150.0000 [get_ports {q_data_in[307]}]
set_input_transition 150.0000 [get_ports {q_data_in[306]}]
set_input_transition 150.0000 [get_ports {q_data_in[305]}]
set_input_transition 150.0000 [get_ports {q_data_in[304]}]
set_input_transition 150.0000 [get_ports {q_data_in[303]}]
set_input_transition 150.0000 [get_ports {q_data_in[302]}]
set_input_transition 150.0000 [get_ports {q_data_in[301]}]
set_input_transition 150.0000 [get_ports {q_data_in[300]}]
set_input_transition 150.0000 [get_ports {q_data_in[299]}]
set_input_transition 150.0000 [get_ports {q_data_in[298]}]
set_input_transition 150.0000 [get_ports {q_data_in[297]}]
set_input_transition 150.0000 [get_ports {q_data_in[296]}]
set_input_transition 150.0000 [get_ports {q_data_in[295]}]
set_input_transition 150.0000 [get_ports {q_data_in[294]}]
set_input_transition 150.0000 [get_ports {q_data_in[293]}]
set_input_transition 150.0000 [get_ports {q_data_in[292]}]
set_input_transition 150.0000 [get_ports {q_data_in[291]}]
set_input_transition 150.0000 [get_ports {q_data_in[290]}]
set_input_transition 150.0000 [get_ports {q_data_in[289]}]
set_input_transition 150.0000 [get_ports {q_data_in[288]}]
set_input_transition 150.0000 [get_ports {q_data_in[287]}]
set_input_transition 150.0000 [get_ports {q_data_in[286]}]
set_input_transition 150.0000 [get_ports {q_data_in[285]}]
set_input_transition 150.0000 [get_ports {q_data_in[284]}]
set_input_transition 150.0000 [get_ports {q_data_in[283]}]
set_input_transition 150.0000 [get_ports {q_data_in[282]}]
set_input_transition 150.0000 [get_ports {q_data_in[281]}]
set_input_transition 150.0000 [get_ports {q_data_in[280]}]
set_input_transition 150.0000 [get_ports {q_data_in[279]}]
set_input_transition 150.0000 [get_ports {q_data_in[278]}]
set_input_transition 150.0000 [get_ports {q_data_in[277]}]
set_input_transition 150.0000 [get_ports {q_data_in[276]}]
set_input_transition 150.0000 [get_ports {q_data_in[275]}]
set_input_transition 150.0000 [get_ports {q_data_in[274]}]
set_input_transition 150.0000 [get_ports {q_data_in[273]}]
set_input_transition 150.0000 [get_ports {q_data_in[272]}]
set_input_transition 150.0000 [get_ports {q_data_in[271]}]
set_input_transition 150.0000 [get_ports {q_data_in[270]}]
set_input_transition 150.0000 [get_ports {q_data_in[269]}]
set_input_transition 150.0000 [get_ports {q_data_in[268]}]
set_input_transition 150.0000 [get_ports {q_data_in[267]}]
set_input_transition 150.0000 [get_ports {q_data_in[266]}]
set_input_transition 150.0000 [get_ports {q_data_in[265]}]
set_input_transition 150.0000 [get_ports {q_data_in[264]}]
set_input_transition 150.0000 [get_ports {q_data_in[263]}]
set_input_transition 150.0000 [get_ports {q_data_in[262]}]
set_input_transition 150.0000 [get_ports {q_data_in[261]}]
set_input_transition 150.0000 [get_ports {q_data_in[260]}]
set_input_transition 150.0000 [get_ports {q_data_in[259]}]
set_input_transition 150.0000 [get_ports {q_data_in[258]}]
set_input_transition 150.0000 [get_ports {q_data_in[257]}]
set_input_transition 150.0000 [get_ports {q_data_in[256]}]
set_input_transition 150.0000 [get_ports {q_data_in[255]}]
set_input_transition 150.0000 [get_ports {q_data_in[254]}]
set_input_transition 150.0000 [get_ports {q_data_in[253]}]
set_input_transition 150.0000 [get_ports {q_data_in[252]}]
set_input_transition 150.0000 [get_ports {q_data_in[251]}]
set_input_transition 150.0000 [get_ports {q_data_in[250]}]
set_input_transition 150.0000 [get_ports {q_data_in[249]}]
set_input_transition 150.0000 [get_ports {q_data_in[248]}]
set_input_transition 150.0000 [get_ports {q_data_in[247]}]
set_input_transition 150.0000 [get_ports {q_data_in[246]}]
set_input_transition 150.0000 [get_ports {q_data_in[245]}]
set_input_transition 150.0000 [get_ports {q_data_in[244]}]
set_input_transition 150.0000 [get_ports {q_data_in[243]}]
set_input_transition 150.0000 [get_ports {q_data_in[242]}]
set_input_transition 150.0000 [get_ports {q_data_in[241]}]
set_input_transition 150.0000 [get_ports {q_data_in[240]}]
set_input_transition 150.0000 [get_ports {q_data_in[239]}]
set_input_transition 150.0000 [get_ports {q_data_in[238]}]
set_input_transition 150.0000 [get_ports {q_data_in[237]}]
set_input_transition 150.0000 [get_ports {q_data_in[236]}]
set_input_transition 150.0000 [get_ports {q_data_in[235]}]
set_input_transition 150.0000 [get_ports {q_data_in[234]}]
set_input_transition 150.0000 [get_ports {q_data_in[233]}]
set_input_transition 150.0000 [get_ports {q_data_in[232]}]
set_input_transition 150.0000 [get_ports {q_data_in[231]}]
set_input_transition 150.0000 [get_ports {q_data_in[230]}]
set_input_transition 150.0000 [get_ports {q_data_in[229]}]
set_input_transition 150.0000 [get_ports {q_data_in[228]}]
set_input_transition 150.0000 [get_ports {q_data_in[227]}]
set_input_transition 150.0000 [get_ports {q_data_in[226]}]
set_input_transition 150.0000 [get_ports {q_data_in[225]}]
set_input_transition 150.0000 [get_ports {q_data_in[224]}]
set_input_transition 150.0000 [get_ports {q_data_in[223]}]
set_input_transition 150.0000 [get_ports {q_data_in[222]}]
set_input_transition 150.0000 [get_ports {q_data_in[221]}]
set_input_transition 150.0000 [get_ports {q_data_in[220]}]
set_input_transition 150.0000 [get_ports {q_data_in[219]}]
set_input_transition 150.0000 [get_ports {q_data_in[218]}]
set_input_transition 150.0000 [get_ports {q_data_in[217]}]
set_input_transition 150.0000 [get_ports {q_data_in[216]}]
set_input_transition 150.0000 [get_ports {q_data_in[215]}]
set_input_transition 150.0000 [get_ports {q_data_in[214]}]
set_input_transition 150.0000 [get_ports {q_data_in[213]}]
set_input_transition 150.0000 [get_ports {q_data_in[212]}]
set_input_transition 150.0000 [get_ports {q_data_in[211]}]
set_input_transition 150.0000 [get_ports {q_data_in[210]}]
set_input_transition 150.0000 [get_ports {q_data_in[209]}]
set_input_transition 150.0000 [get_ports {q_data_in[208]}]
set_input_transition 150.0000 [get_ports {q_data_in[207]}]
set_input_transition 150.0000 [get_ports {q_data_in[206]}]
set_input_transition 150.0000 [get_ports {q_data_in[205]}]
set_input_transition 150.0000 [get_ports {q_data_in[204]}]
set_input_transition 150.0000 [get_ports {q_data_in[203]}]
set_input_transition 150.0000 [get_ports {q_data_in[202]}]
set_input_transition 150.0000 [get_ports {q_data_in[201]}]
set_input_transition 150.0000 [get_ports {q_data_in[200]}]
set_input_transition 150.0000 [get_ports {q_data_in[199]}]
set_input_transition 150.0000 [get_ports {q_data_in[198]}]
set_input_transition 150.0000 [get_ports {q_data_in[197]}]
set_input_transition 150.0000 [get_ports {q_data_in[196]}]
set_input_transition 150.0000 [get_ports {q_data_in[195]}]
set_input_transition 150.0000 [get_ports {q_data_in[194]}]
set_input_transition 150.0000 [get_ports {q_data_in[193]}]
set_input_transition 150.0000 [get_ports {q_data_in[192]}]
set_input_transition 150.0000 [get_ports {q_data_in[191]}]
set_input_transition 150.0000 [get_ports {q_data_in[190]}]
set_input_transition 150.0000 [get_ports {q_data_in[189]}]
set_input_transition 150.0000 [get_ports {q_data_in[188]}]
set_input_transition 150.0000 [get_ports {q_data_in[187]}]
set_input_transition 150.0000 [get_ports {q_data_in[186]}]
set_input_transition 150.0000 [get_ports {q_data_in[185]}]
set_input_transition 150.0000 [get_ports {q_data_in[184]}]
set_input_transition 150.0000 [get_ports {q_data_in[183]}]
set_input_transition 150.0000 [get_ports {q_data_in[182]}]
set_input_transition 150.0000 [get_ports {q_data_in[181]}]
set_input_transition 150.0000 [get_ports {q_data_in[180]}]
set_input_transition 150.0000 [get_ports {q_data_in[179]}]
set_input_transition 150.0000 [get_ports {q_data_in[178]}]
set_input_transition 150.0000 [get_ports {q_data_in[177]}]
set_input_transition 150.0000 [get_ports {q_data_in[176]}]
set_input_transition 150.0000 [get_ports {q_data_in[175]}]
set_input_transition 150.0000 [get_ports {q_data_in[174]}]
set_input_transition 150.0000 [get_ports {q_data_in[173]}]
set_input_transition 150.0000 [get_ports {q_data_in[172]}]
set_input_transition 150.0000 [get_ports {q_data_in[171]}]
set_input_transition 150.0000 [get_ports {q_data_in[170]}]
set_input_transition 150.0000 [get_ports {q_data_in[169]}]
set_input_transition 150.0000 [get_ports {q_data_in[168]}]
set_input_transition 150.0000 [get_ports {q_data_in[167]}]
set_input_transition 150.0000 [get_ports {q_data_in[166]}]
set_input_transition 150.0000 [get_ports {q_data_in[165]}]
set_input_transition 150.0000 [get_ports {q_data_in[164]}]
set_input_transition 150.0000 [get_ports {q_data_in[163]}]
set_input_transition 150.0000 [get_ports {q_data_in[162]}]
set_input_transition 150.0000 [get_ports {q_data_in[161]}]
set_input_transition 150.0000 [get_ports {q_data_in[160]}]
set_input_transition 150.0000 [get_ports {q_data_in[159]}]
set_input_transition 150.0000 [get_ports {q_data_in[158]}]
set_input_transition 150.0000 [get_ports {q_data_in[157]}]
set_input_transition 150.0000 [get_ports {q_data_in[156]}]
set_input_transition 150.0000 [get_ports {q_data_in[155]}]
set_input_transition 150.0000 [get_ports {q_data_in[154]}]
set_input_transition 150.0000 [get_ports {q_data_in[153]}]
set_input_transition 150.0000 [get_ports {q_data_in[152]}]
set_input_transition 150.0000 [get_ports {q_data_in[151]}]
set_input_transition 150.0000 [get_ports {q_data_in[150]}]
set_input_transition 150.0000 [get_ports {q_data_in[149]}]
set_input_transition 150.0000 [get_ports {q_data_in[148]}]
set_input_transition 150.0000 [get_ports {q_data_in[147]}]
set_input_transition 150.0000 [get_ports {q_data_in[146]}]
set_input_transition 150.0000 [get_ports {q_data_in[145]}]
set_input_transition 150.0000 [get_ports {q_data_in[144]}]
set_input_transition 150.0000 [get_ports {q_data_in[143]}]
set_input_transition 150.0000 [get_ports {q_data_in[142]}]
set_input_transition 150.0000 [get_ports {q_data_in[141]}]
set_input_transition 150.0000 [get_ports {q_data_in[140]}]
set_input_transition 150.0000 [get_ports {q_data_in[139]}]
set_input_transition 150.0000 [get_ports {q_data_in[138]}]
set_input_transition 150.0000 [get_ports {q_data_in[137]}]
set_input_transition 150.0000 [get_ports {q_data_in[136]}]
set_input_transition 150.0000 [get_ports {q_data_in[135]}]
set_input_transition 150.0000 [get_ports {q_data_in[134]}]
set_input_transition 150.0000 [get_ports {q_data_in[133]}]
set_input_transition 150.0000 [get_ports {q_data_in[132]}]
set_input_transition 150.0000 [get_ports {q_data_in[131]}]
set_input_transition 150.0000 [get_ports {q_data_in[130]}]
set_input_transition 150.0000 [get_ports {q_data_in[129]}]
set_input_transition 150.0000 [get_ports {q_data_in[128]}]
set_input_transition 150.0000 [get_ports {q_data_in[127]}]
set_input_transition 150.0000 [get_ports {q_data_in[126]}]
set_input_transition 150.0000 [get_ports {q_data_in[125]}]
set_input_transition 150.0000 [get_ports {q_data_in[124]}]
set_input_transition 150.0000 [get_ports {q_data_in[123]}]
set_input_transition 150.0000 [get_ports {q_data_in[122]}]
set_input_transition 150.0000 [get_ports {q_data_in[121]}]
set_input_transition 150.0000 [get_ports {q_data_in[120]}]
set_input_transition 150.0000 [get_ports {q_data_in[119]}]
set_input_transition 150.0000 [get_ports {q_data_in[118]}]
set_input_transition 150.0000 [get_ports {q_data_in[117]}]
set_input_transition 150.0000 [get_ports {q_data_in[116]}]
set_input_transition 150.0000 [get_ports {q_data_in[115]}]
set_input_transition 150.0000 [get_ports {q_data_in[114]}]
set_input_transition 150.0000 [get_ports {q_data_in[113]}]
set_input_transition 150.0000 [get_ports {q_data_in[112]}]
set_input_transition 150.0000 [get_ports {q_data_in[111]}]
set_input_transition 150.0000 [get_ports {q_data_in[110]}]
set_input_transition 150.0000 [get_ports {q_data_in[109]}]
set_input_transition 150.0000 [get_ports {q_data_in[108]}]
set_input_transition 150.0000 [get_ports {q_data_in[107]}]
set_input_transition 150.0000 [get_ports {q_data_in[106]}]
set_input_transition 150.0000 [get_ports {q_data_in[105]}]
set_input_transition 150.0000 [get_ports {q_data_in[104]}]
set_input_transition 150.0000 [get_ports {q_data_in[103]}]
set_input_transition 150.0000 [get_ports {q_data_in[102]}]
set_input_transition 150.0000 [get_ports {q_data_in[101]}]
set_input_transition 150.0000 [get_ports {q_data_in[100]}]
set_input_transition 150.0000 [get_ports {q_data_in[99]}]
set_input_transition 150.0000 [get_ports {q_data_in[98]}]
set_input_transition 150.0000 [get_ports {q_data_in[97]}]
set_input_transition 150.0000 [get_ports {q_data_in[96]}]
set_input_transition 150.0000 [get_ports {q_data_in[95]}]
set_input_transition 150.0000 [get_ports {q_data_in[94]}]
set_input_transition 150.0000 [get_ports {q_data_in[93]}]
set_input_transition 150.0000 [get_ports {q_data_in[92]}]
set_input_transition 150.0000 [get_ports {q_data_in[91]}]
set_input_transition 150.0000 [get_ports {q_data_in[90]}]
set_input_transition 150.0000 [get_ports {q_data_in[89]}]
set_input_transition 150.0000 [get_ports {q_data_in[88]}]
set_input_transition 150.0000 [get_ports {q_data_in[87]}]
set_input_transition 150.0000 [get_ports {q_data_in[86]}]
set_input_transition 150.0000 [get_ports {q_data_in[85]}]
set_input_transition 150.0000 [get_ports {q_data_in[84]}]
set_input_transition 150.0000 [get_ports {q_data_in[83]}]
set_input_transition 150.0000 [get_ports {q_data_in[82]}]
set_input_transition 150.0000 [get_ports {q_data_in[81]}]
set_input_transition 150.0000 [get_ports {q_data_in[80]}]
set_input_transition 150.0000 [get_ports {q_data_in[79]}]
set_input_transition 150.0000 [get_ports {q_data_in[78]}]
set_input_transition 150.0000 [get_ports {q_data_in[77]}]
set_input_transition 150.0000 [get_ports {q_data_in[76]}]
set_input_transition 150.0000 [get_ports {q_data_in[75]}]
set_input_transition 150.0000 [get_ports {q_data_in[74]}]
set_input_transition 150.0000 [get_ports {q_data_in[73]}]
set_input_transition 150.0000 [get_ports {q_data_in[72]}]
set_input_transition 150.0000 [get_ports {q_data_in[71]}]
set_input_transition 150.0000 [get_ports {q_data_in[70]}]
set_input_transition 150.0000 [get_ports {q_data_in[69]}]
set_input_transition 150.0000 [get_ports {q_data_in[68]}]
set_input_transition 150.0000 [get_ports {q_data_in[67]}]
set_input_transition 150.0000 [get_ports {q_data_in[66]}]
set_input_transition 150.0000 [get_ports {q_data_in[65]}]
set_input_transition 150.0000 [get_ports {q_data_in[64]}]
set_input_transition 150.0000 [get_ports {q_data_in[63]}]
set_input_transition 150.0000 [get_ports {q_data_in[62]}]
set_input_transition 150.0000 [get_ports {q_data_in[61]}]
set_input_transition 150.0000 [get_ports {q_data_in[60]}]
set_input_transition 150.0000 [get_ports {q_data_in[59]}]
set_input_transition 150.0000 [get_ports {q_data_in[58]}]
set_input_transition 150.0000 [get_ports {q_data_in[57]}]
set_input_transition 150.0000 [get_ports {q_data_in[56]}]
set_input_transition 150.0000 [get_ports {q_data_in[55]}]
set_input_transition 150.0000 [get_ports {q_data_in[54]}]
set_input_transition 150.0000 [get_ports {q_data_in[53]}]
set_input_transition 150.0000 [get_ports {q_data_in[52]}]
set_input_transition 150.0000 [get_ports {q_data_in[51]}]
set_input_transition 150.0000 [get_ports {q_data_in[50]}]
set_input_transition 150.0000 [get_ports {q_data_in[49]}]
set_input_transition 150.0000 [get_ports {q_data_in[48]}]
set_input_transition 150.0000 [get_ports {q_data_in[47]}]
set_input_transition 150.0000 [get_ports {q_data_in[46]}]
set_input_transition 150.0000 [get_ports {q_data_in[45]}]
set_input_transition 150.0000 [get_ports {q_data_in[44]}]
set_input_transition 150.0000 [get_ports {q_data_in[43]}]
set_input_transition 150.0000 [get_ports {q_data_in[42]}]
set_input_transition 150.0000 [get_ports {q_data_in[41]}]
set_input_transition 150.0000 [get_ports {q_data_in[40]}]
set_input_transition 150.0000 [get_ports {q_data_in[39]}]
set_input_transition 150.0000 [get_ports {q_data_in[38]}]
set_input_transition 150.0000 [get_ports {q_data_in[37]}]
set_input_transition 150.0000 [get_ports {q_data_in[36]}]
set_input_transition 150.0000 [get_ports {q_data_in[35]}]
set_input_transition 150.0000 [get_ports {q_data_in[34]}]
set_input_transition 150.0000 [get_ports {q_data_in[33]}]
set_input_transition 150.0000 [get_ports {q_data_in[32]}]
set_input_transition 150.0000 [get_ports {q_data_in[31]}]
set_input_transition 150.0000 [get_ports {q_data_in[30]}]
set_input_transition 150.0000 [get_ports {q_data_in[29]}]
set_input_transition 150.0000 [get_ports {q_data_in[28]}]
set_input_transition 150.0000 [get_ports {q_data_in[27]}]
set_input_transition 150.0000 [get_ports {q_data_in[26]}]
set_input_transition 150.0000 [get_ports {q_data_in[25]}]
set_input_transition 150.0000 [get_ports {q_data_in[24]}]
set_input_transition 150.0000 [get_ports {q_data_in[23]}]
set_input_transition 150.0000 [get_ports {q_data_in[22]}]
set_input_transition 150.0000 [get_ports {q_data_in[21]}]
set_input_transition 150.0000 [get_ports {q_data_in[20]}]
set_input_transition 150.0000 [get_ports {q_data_in[19]}]
set_input_transition 150.0000 [get_ports {q_data_in[18]}]
set_input_transition 150.0000 [get_ports {q_data_in[17]}]
set_input_transition 150.0000 [get_ports {q_data_in[16]}]
set_input_transition 150.0000 [get_ports {q_data_in[15]}]
set_input_transition 150.0000 [get_ports {q_data_in[14]}]
set_input_transition 150.0000 [get_ports {q_data_in[13]}]
set_input_transition 150.0000 [get_ports {q_data_in[12]}]
set_input_transition 150.0000 [get_ports {q_data_in[11]}]
set_input_transition 150.0000 [get_ports {q_data_in[10]}]
set_input_transition 150.0000 [get_ports {q_data_in[9]}]
set_input_transition 150.0000 [get_ports {q_data_in[8]}]
set_input_transition 150.0000 [get_ports {q_data_in[7]}]
set_input_transition 150.0000 [get_ports {q_data_in[6]}]
set_input_transition 150.0000 [get_ports {q_data_in[5]}]
set_input_transition 150.0000 [get_ports {q_data_in[4]}]
set_input_transition 150.0000 [get_ports {q_data_in[3]}]
set_input_transition 150.0000 [get_ports {q_data_in[2]}]
set_input_transition 150.0000 [get_ports {q_data_in[1]}]
set_input_transition 150.0000 [get_ports {q_data_in[0]}]
set_input_transition 150.0000 [get_ports {row_in[1023]}]
set_input_transition 150.0000 [get_ports {row_in[1022]}]
set_input_transition 150.0000 [get_ports {row_in[1021]}]
set_input_transition 150.0000 [get_ports {row_in[1020]}]
set_input_transition 150.0000 [get_ports {row_in[1019]}]
set_input_transition 150.0000 [get_ports {row_in[1018]}]
set_input_transition 150.0000 [get_ports {row_in[1017]}]
set_input_transition 150.0000 [get_ports {row_in[1016]}]
set_input_transition 150.0000 [get_ports {row_in[1015]}]
set_input_transition 150.0000 [get_ports {row_in[1014]}]
set_input_transition 150.0000 [get_ports {row_in[1013]}]
set_input_transition 150.0000 [get_ports {row_in[1012]}]
set_input_transition 150.0000 [get_ports {row_in[1011]}]
set_input_transition 150.0000 [get_ports {row_in[1010]}]
set_input_transition 150.0000 [get_ports {row_in[1009]}]
set_input_transition 150.0000 [get_ports {row_in[1008]}]
set_input_transition 150.0000 [get_ports {row_in[1007]}]
set_input_transition 150.0000 [get_ports {row_in[1006]}]
set_input_transition 150.0000 [get_ports {row_in[1005]}]
set_input_transition 150.0000 [get_ports {row_in[1004]}]
set_input_transition 150.0000 [get_ports {row_in[1003]}]
set_input_transition 150.0000 [get_ports {row_in[1002]}]
set_input_transition 150.0000 [get_ports {row_in[1001]}]
set_input_transition 150.0000 [get_ports {row_in[1000]}]
set_input_transition 150.0000 [get_ports {row_in[999]}]
set_input_transition 150.0000 [get_ports {row_in[998]}]
set_input_transition 150.0000 [get_ports {row_in[997]}]
set_input_transition 150.0000 [get_ports {row_in[996]}]
set_input_transition 150.0000 [get_ports {row_in[995]}]
set_input_transition 150.0000 [get_ports {row_in[994]}]
set_input_transition 150.0000 [get_ports {row_in[993]}]
set_input_transition 150.0000 [get_ports {row_in[992]}]
set_input_transition 150.0000 [get_ports {row_in[991]}]
set_input_transition 150.0000 [get_ports {row_in[990]}]
set_input_transition 150.0000 [get_ports {row_in[989]}]
set_input_transition 150.0000 [get_ports {row_in[988]}]
set_input_transition 150.0000 [get_ports {row_in[987]}]
set_input_transition 150.0000 [get_ports {row_in[986]}]
set_input_transition 150.0000 [get_ports {row_in[985]}]
set_input_transition 150.0000 [get_ports {row_in[984]}]
set_input_transition 150.0000 [get_ports {row_in[983]}]
set_input_transition 150.0000 [get_ports {row_in[982]}]
set_input_transition 150.0000 [get_ports {row_in[981]}]
set_input_transition 150.0000 [get_ports {row_in[980]}]
set_input_transition 150.0000 [get_ports {row_in[979]}]
set_input_transition 150.0000 [get_ports {row_in[978]}]
set_input_transition 150.0000 [get_ports {row_in[977]}]
set_input_transition 150.0000 [get_ports {row_in[976]}]
set_input_transition 150.0000 [get_ports {row_in[975]}]
set_input_transition 150.0000 [get_ports {row_in[974]}]
set_input_transition 150.0000 [get_ports {row_in[973]}]
set_input_transition 150.0000 [get_ports {row_in[972]}]
set_input_transition 150.0000 [get_ports {row_in[971]}]
set_input_transition 150.0000 [get_ports {row_in[970]}]
set_input_transition 150.0000 [get_ports {row_in[969]}]
set_input_transition 150.0000 [get_ports {row_in[968]}]
set_input_transition 150.0000 [get_ports {row_in[967]}]
set_input_transition 150.0000 [get_ports {row_in[966]}]
set_input_transition 150.0000 [get_ports {row_in[965]}]
set_input_transition 150.0000 [get_ports {row_in[964]}]
set_input_transition 150.0000 [get_ports {row_in[963]}]
set_input_transition 150.0000 [get_ports {row_in[962]}]
set_input_transition 150.0000 [get_ports {row_in[961]}]
set_input_transition 150.0000 [get_ports {row_in[960]}]
set_input_transition 150.0000 [get_ports {row_in[959]}]
set_input_transition 150.0000 [get_ports {row_in[958]}]
set_input_transition 150.0000 [get_ports {row_in[957]}]
set_input_transition 150.0000 [get_ports {row_in[956]}]
set_input_transition 150.0000 [get_ports {row_in[955]}]
set_input_transition 150.0000 [get_ports {row_in[954]}]
set_input_transition 150.0000 [get_ports {row_in[953]}]
set_input_transition 150.0000 [get_ports {row_in[952]}]
set_input_transition 150.0000 [get_ports {row_in[951]}]
set_input_transition 150.0000 [get_ports {row_in[950]}]
set_input_transition 150.0000 [get_ports {row_in[949]}]
set_input_transition 150.0000 [get_ports {row_in[948]}]
set_input_transition 150.0000 [get_ports {row_in[947]}]
set_input_transition 150.0000 [get_ports {row_in[946]}]
set_input_transition 150.0000 [get_ports {row_in[945]}]
set_input_transition 150.0000 [get_ports {row_in[944]}]
set_input_transition 150.0000 [get_ports {row_in[943]}]
set_input_transition 150.0000 [get_ports {row_in[942]}]
set_input_transition 150.0000 [get_ports {row_in[941]}]
set_input_transition 150.0000 [get_ports {row_in[940]}]
set_input_transition 150.0000 [get_ports {row_in[939]}]
set_input_transition 150.0000 [get_ports {row_in[938]}]
set_input_transition 150.0000 [get_ports {row_in[937]}]
set_input_transition 150.0000 [get_ports {row_in[936]}]
set_input_transition 150.0000 [get_ports {row_in[935]}]
set_input_transition 150.0000 [get_ports {row_in[934]}]
set_input_transition 150.0000 [get_ports {row_in[933]}]
set_input_transition 150.0000 [get_ports {row_in[932]}]
set_input_transition 150.0000 [get_ports {row_in[931]}]
set_input_transition 150.0000 [get_ports {row_in[930]}]
set_input_transition 150.0000 [get_ports {row_in[929]}]
set_input_transition 150.0000 [get_ports {row_in[928]}]
set_input_transition 150.0000 [get_ports {row_in[927]}]
set_input_transition 150.0000 [get_ports {row_in[926]}]
set_input_transition 150.0000 [get_ports {row_in[925]}]
set_input_transition 150.0000 [get_ports {row_in[924]}]
set_input_transition 150.0000 [get_ports {row_in[923]}]
set_input_transition 150.0000 [get_ports {row_in[922]}]
set_input_transition 150.0000 [get_ports {row_in[921]}]
set_input_transition 150.0000 [get_ports {row_in[920]}]
set_input_transition 150.0000 [get_ports {row_in[919]}]
set_input_transition 150.0000 [get_ports {row_in[918]}]
set_input_transition 150.0000 [get_ports {row_in[917]}]
set_input_transition 150.0000 [get_ports {row_in[916]}]
set_input_transition 150.0000 [get_ports {row_in[915]}]
set_input_transition 150.0000 [get_ports {row_in[914]}]
set_input_transition 150.0000 [get_ports {row_in[913]}]
set_input_transition 150.0000 [get_ports {row_in[912]}]
set_input_transition 150.0000 [get_ports {row_in[911]}]
set_input_transition 150.0000 [get_ports {row_in[910]}]
set_input_transition 150.0000 [get_ports {row_in[909]}]
set_input_transition 150.0000 [get_ports {row_in[908]}]
set_input_transition 150.0000 [get_ports {row_in[907]}]
set_input_transition 150.0000 [get_ports {row_in[906]}]
set_input_transition 150.0000 [get_ports {row_in[905]}]
set_input_transition 150.0000 [get_ports {row_in[904]}]
set_input_transition 150.0000 [get_ports {row_in[903]}]
set_input_transition 150.0000 [get_ports {row_in[902]}]
set_input_transition 150.0000 [get_ports {row_in[901]}]
set_input_transition 150.0000 [get_ports {row_in[900]}]
set_input_transition 150.0000 [get_ports {row_in[899]}]
set_input_transition 150.0000 [get_ports {row_in[898]}]
set_input_transition 150.0000 [get_ports {row_in[897]}]
set_input_transition 150.0000 [get_ports {row_in[896]}]
set_input_transition 150.0000 [get_ports {row_in[895]}]
set_input_transition 150.0000 [get_ports {row_in[894]}]
set_input_transition 150.0000 [get_ports {row_in[893]}]
set_input_transition 150.0000 [get_ports {row_in[892]}]
set_input_transition 150.0000 [get_ports {row_in[891]}]
set_input_transition 150.0000 [get_ports {row_in[890]}]
set_input_transition 150.0000 [get_ports {row_in[889]}]
set_input_transition 150.0000 [get_ports {row_in[888]}]
set_input_transition 150.0000 [get_ports {row_in[887]}]
set_input_transition 150.0000 [get_ports {row_in[886]}]
set_input_transition 150.0000 [get_ports {row_in[885]}]
set_input_transition 150.0000 [get_ports {row_in[884]}]
set_input_transition 150.0000 [get_ports {row_in[883]}]
set_input_transition 150.0000 [get_ports {row_in[882]}]
set_input_transition 150.0000 [get_ports {row_in[881]}]
set_input_transition 150.0000 [get_ports {row_in[880]}]
set_input_transition 150.0000 [get_ports {row_in[879]}]
set_input_transition 150.0000 [get_ports {row_in[878]}]
set_input_transition 150.0000 [get_ports {row_in[877]}]
set_input_transition 150.0000 [get_ports {row_in[876]}]
set_input_transition 150.0000 [get_ports {row_in[875]}]
set_input_transition 150.0000 [get_ports {row_in[874]}]
set_input_transition 150.0000 [get_ports {row_in[873]}]
set_input_transition 150.0000 [get_ports {row_in[872]}]
set_input_transition 150.0000 [get_ports {row_in[871]}]
set_input_transition 150.0000 [get_ports {row_in[870]}]
set_input_transition 150.0000 [get_ports {row_in[869]}]
set_input_transition 150.0000 [get_ports {row_in[868]}]
set_input_transition 150.0000 [get_ports {row_in[867]}]
set_input_transition 150.0000 [get_ports {row_in[866]}]
set_input_transition 150.0000 [get_ports {row_in[865]}]
set_input_transition 150.0000 [get_ports {row_in[864]}]
set_input_transition 150.0000 [get_ports {row_in[863]}]
set_input_transition 150.0000 [get_ports {row_in[862]}]
set_input_transition 150.0000 [get_ports {row_in[861]}]
set_input_transition 150.0000 [get_ports {row_in[860]}]
set_input_transition 150.0000 [get_ports {row_in[859]}]
set_input_transition 150.0000 [get_ports {row_in[858]}]
set_input_transition 150.0000 [get_ports {row_in[857]}]
set_input_transition 150.0000 [get_ports {row_in[856]}]
set_input_transition 150.0000 [get_ports {row_in[855]}]
set_input_transition 150.0000 [get_ports {row_in[854]}]
set_input_transition 150.0000 [get_ports {row_in[853]}]
set_input_transition 150.0000 [get_ports {row_in[852]}]
set_input_transition 150.0000 [get_ports {row_in[851]}]
set_input_transition 150.0000 [get_ports {row_in[850]}]
set_input_transition 150.0000 [get_ports {row_in[849]}]
set_input_transition 150.0000 [get_ports {row_in[848]}]
set_input_transition 150.0000 [get_ports {row_in[847]}]
set_input_transition 150.0000 [get_ports {row_in[846]}]
set_input_transition 150.0000 [get_ports {row_in[845]}]
set_input_transition 150.0000 [get_ports {row_in[844]}]
set_input_transition 150.0000 [get_ports {row_in[843]}]
set_input_transition 150.0000 [get_ports {row_in[842]}]
set_input_transition 150.0000 [get_ports {row_in[841]}]
set_input_transition 150.0000 [get_ports {row_in[840]}]
set_input_transition 150.0000 [get_ports {row_in[839]}]
set_input_transition 150.0000 [get_ports {row_in[838]}]
set_input_transition 150.0000 [get_ports {row_in[837]}]
set_input_transition 150.0000 [get_ports {row_in[836]}]
set_input_transition 150.0000 [get_ports {row_in[835]}]
set_input_transition 150.0000 [get_ports {row_in[834]}]
set_input_transition 150.0000 [get_ports {row_in[833]}]
set_input_transition 150.0000 [get_ports {row_in[832]}]
set_input_transition 150.0000 [get_ports {row_in[831]}]
set_input_transition 150.0000 [get_ports {row_in[830]}]
set_input_transition 150.0000 [get_ports {row_in[829]}]
set_input_transition 150.0000 [get_ports {row_in[828]}]
set_input_transition 150.0000 [get_ports {row_in[827]}]
set_input_transition 150.0000 [get_ports {row_in[826]}]
set_input_transition 150.0000 [get_ports {row_in[825]}]
set_input_transition 150.0000 [get_ports {row_in[824]}]
set_input_transition 150.0000 [get_ports {row_in[823]}]
set_input_transition 150.0000 [get_ports {row_in[822]}]
set_input_transition 150.0000 [get_ports {row_in[821]}]
set_input_transition 150.0000 [get_ports {row_in[820]}]
set_input_transition 150.0000 [get_ports {row_in[819]}]
set_input_transition 150.0000 [get_ports {row_in[818]}]
set_input_transition 150.0000 [get_ports {row_in[817]}]
set_input_transition 150.0000 [get_ports {row_in[816]}]
set_input_transition 150.0000 [get_ports {row_in[815]}]
set_input_transition 150.0000 [get_ports {row_in[814]}]
set_input_transition 150.0000 [get_ports {row_in[813]}]
set_input_transition 150.0000 [get_ports {row_in[812]}]
set_input_transition 150.0000 [get_ports {row_in[811]}]
set_input_transition 150.0000 [get_ports {row_in[810]}]
set_input_transition 150.0000 [get_ports {row_in[809]}]
set_input_transition 150.0000 [get_ports {row_in[808]}]
set_input_transition 150.0000 [get_ports {row_in[807]}]
set_input_transition 150.0000 [get_ports {row_in[806]}]
set_input_transition 150.0000 [get_ports {row_in[805]}]
set_input_transition 150.0000 [get_ports {row_in[804]}]
set_input_transition 150.0000 [get_ports {row_in[803]}]
set_input_transition 150.0000 [get_ports {row_in[802]}]
set_input_transition 150.0000 [get_ports {row_in[801]}]
set_input_transition 150.0000 [get_ports {row_in[800]}]
set_input_transition 150.0000 [get_ports {row_in[799]}]
set_input_transition 150.0000 [get_ports {row_in[798]}]
set_input_transition 150.0000 [get_ports {row_in[797]}]
set_input_transition 150.0000 [get_ports {row_in[796]}]
set_input_transition 150.0000 [get_ports {row_in[795]}]
set_input_transition 150.0000 [get_ports {row_in[794]}]
set_input_transition 150.0000 [get_ports {row_in[793]}]
set_input_transition 150.0000 [get_ports {row_in[792]}]
set_input_transition 150.0000 [get_ports {row_in[791]}]
set_input_transition 150.0000 [get_ports {row_in[790]}]
set_input_transition 150.0000 [get_ports {row_in[789]}]
set_input_transition 150.0000 [get_ports {row_in[788]}]
set_input_transition 150.0000 [get_ports {row_in[787]}]
set_input_transition 150.0000 [get_ports {row_in[786]}]
set_input_transition 150.0000 [get_ports {row_in[785]}]
set_input_transition 150.0000 [get_ports {row_in[784]}]
set_input_transition 150.0000 [get_ports {row_in[783]}]
set_input_transition 150.0000 [get_ports {row_in[782]}]
set_input_transition 150.0000 [get_ports {row_in[781]}]
set_input_transition 150.0000 [get_ports {row_in[780]}]
set_input_transition 150.0000 [get_ports {row_in[779]}]
set_input_transition 150.0000 [get_ports {row_in[778]}]
set_input_transition 150.0000 [get_ports {row_in[777]}]
set_input_transition 150.0000 [get_ports {row_in[776]}]
set_input_transition 150.0000 [get_ports {row_in[775]}]
set_input_transition 150.0000 [get_ports {row_in[774]}]
set_input_transition 150.0000 [get_ports {row_in[773]}]
set_input_transition 150.0000 [get_ports {row_in[772]}]
set_input_transition 150.0000 [get_ports {row_in[771]}]
set_input_transition 150.0000 [get_ports {row_in[770]}]
set_input_transition 150.0000 [get_ports {row_in[769]}]
set_input_transition 150.0000 [get_ports {row_in[768]}]
set_input_transition 150.0000 [get_ports {row_in[767]}]
set_input_transition 150.0000 [get_ports {row_in[766]}]
set_input_transition 150.0000 [get_ports {row_in[765]}]
set_input_transition 150.0000 [get_ports {row_in[764]}]
set_input_transition 150.0000 [get_ports {row_in[763]}]
set_input_transition 150.0000 [get_ports {row_in[762]}]
set_input_transition 150.0000 [get_ports {row_in[761]}]
set_input_transition 150.0000 [get_ports {row_in[760]}]
set_input_transition 150.0000 [get_ports {row_in[759]}]
set_input_transition 150.0000 [get_ports {row_in[758]}]
set_input_transition 150.0000 [get_ports {row_in[757]}]
set_input_transition 150.0000 [get_ports {row_in[756]}]
set_input_transition 150.0000 [get_ports {row_in[755]}]
set_input_transition 150.0000 [get_ports {row_in[754]}]
set_input_transition 150.0000 [get_ports {row_in[753]}]
set_input_transition 150.0000 [get_ports {row_in[752]}]
set_input_transition 150.0000 [get_ports {row_in[751]}]
set_input_transition 150.0000 [get_ports {row_in[750]}]
set_input_transition 150.0000 [get_ports {row_in[749]}]
set_input_transition 150.0000 [get_ports {row_in[748]}]
set_input_transition 150.0000 [get_ports {row_in[747]}]
set_input_transition 150.0000 [get_ports {row_in[746]}]
set_input_transition 150.0000 [get_ports {row_in[745]}]
set_input_transition 150.0000 [get_ports {row_in[744]}]
set_input_transition 150.0000 [get_ports {row_in[743]}]
set_input_transition 150.0000 [get_ports {row_in[742]}]
set_input_transition 150.0000 [get_ports {row_in[741]}]
set_input_transition 150.0000 [get_ports {row_in[740]}]
set_input_transition 150.0000 [get_ports {row_in[739]}]
set_input_transition 150.0000 [get_ports {row_in[738]}]
set_input_transition 150.0000 [get_ports {row_in[737]}]
set_input_transition 150.0000 [get_ports {row_in[736]}]
set_input_transition 150.0000 [get_ports {row_in[735]}]
set_input_transition 150.0000 [get_ports {row_in[734]}]
set_input_transition 150.0000 [get_ports {row_in[733]}]
set_input_transition 150.0000 [get_ports {row_in[732]}]
set_input_transition 150.0000 [get_ports {row_in[731]}]
set_input_transition 150.0000 [get_ports {row_in[730]}]
set_input_transition 150.0000 [get_ports {row_in[729]}]
set_input_transition 150.0000 [get_ports {row_in[728]}]
set_input_transition 150.0000 [get_ports {row_in[727]}]
set_input_transition 150.0000 [get_ports {row_in[726]}]
set_input_transition 150.0000 [get_ports {row_in[725]}]
set_input_transition 150.0000 [get_ports {row_in[724]}]
set_input_transition 150.0000 [get_ports {row_in[723]}]
set_input_transition 150.0000 [get_ports {row_in[722]}]
set_input_transition 150.0000 [get_ports {row_in[721]}]
set_input_transition 150.0000 [get_ports {row_in[720]}]
set_input_transition 150.0000 [get_ports {row_in[719]}]
set_input_transition 150.0000 [get_ports {row_in[718]}]
set_input_transition 150.0000 [get_ports {row_in[717]}]
set_input_transition 150.0000 [get_ports {row_in[716]}]
set_input_transition 150.0000 [get_ports {row_in[715]}]
set_input_transition 150.0000 [get_ports {row_in[714]}]
set_input_transition 150.0000 [get_ports {row_in[713]}]
set_input_transition 150.0000 [get_ports {row_in[712]}]
set_input_transition 150.0000 [get_ports {row_in[711]}]
set_input_transition 150.0000 [get_ports {row_in[710]}]
set_input_transition 150.0000 [get_ports {row_in[709]}]
set_input_transition 150.0000 [get_ports {row_in[708]}]
set_input_transition 150.0000 [get_ports {row_in[707]}]
set_input_transition 150.0000 [get_ports {row_in[706]}]
set_input_transition 150.0000 [get_ports {row_in[705]}]
set_input_transition 150.0000 [get_ports {row_in[704]}]
set_input_transition 150.0000 [get_ports {row_in[703]}]
set_input_transition 150.0000 [get_ports {row_in[702]}]
set_input_transition 150.0000 [get_ports {row_in[701]}]
set_input_transition 150.0000 [get_ports {row_in[700]}]
set_input_transition 150.0000 [get_ports {row_in[699]}]
set_input_transition 150.0000 [get_ports {row_in[698]}]
set_input_transition 150.0000 [get_ports {row_in[697]}]
set_input_transition 150.0000 [get_ports {row_in[696]}]
set_input_transition 150.0000 [get_ports {row_in[695]}]
set_input_transition 150.0000 [get_ports {row_in[694]}]
set_input_transition 150.0000 [get_ports {row_in[693]}]
set_input_transition 150.0000 [get_ports {row_in[692]}]
set_input_transition 150.0000 [get_ports {row_in[691]}]
set_input_transition 150.0000 [get_ports {row_in[690]}]
set_input_transition 150.0000 [get_ports {row_in[689]}]
set_input_transition 150.0000 [get_ports {row_in[688]}]
set_input_transition 150.0000 [get_ports {row_in[687]}]
set_input_transition 150.0000 [get_ports {row_in[686]}]
set_input_transition 150.0000 [get_ports {row_in[685]}]
set_input_transition 150.0000 [get_ports {row_in[684]}]
set_input_transition 150.0000 [get_ports {row_in[683]}]
set_input_transition 150.0000 [get_ports {row_in[682]}]
set_input_transition 150.0000 [get_ports {row_in[681]}]
set_input_transition 150.0000 [get_ports {row_in[680]}]
set_input_transition 150.0000 [get_ports {row_in[679]}]
set_input_transition 150.0000 [get_ports {row_in[678]}]
set_input_transition 150.0000 [get_ports {row_in[677]}]
set_input_transition 150.0000 [get_ports {row_in[676]}]
set_input_transition 150.0000 [get_ports {row_in[675]}]
set_input_transition 150.0000 [get_ports {row_in[674]}]
set_input_transition 150.0000 [get_ports {row_in[673]}]
set_input_transition 150.0000 [get_ports {row_in[672]}]
set_input_transition 150.0000 [get_ports {row_in[671]}]
set_input_transition 150.0000 [get_ports {row_in[670]}]
set_input_transition 150.0000 [get_ports {row_in[669]}]
set_input_transition 150.0000 [get_ports {row_in[668]}]
set_input_transition 150.0000 [get_ports {row_in[667]}]
set_input_transition 150.0000 [get_ports {row_in[666]}]
set_input_transition 150.0000 [get_ports {row_in[665]}]
set_input_transition 150.0000 [get_ports {row_in[664]}]
set_input_transition 150.0000 [get_ports {row_in[663]}]
set_input_transition 150.0000 [get_ports {row_in[662]}]
set_input_transition 150.0000 [get_ports {row_in[661]}]
set_input_transition 150.0000 [get_ports {row_in[660]}]
set_input_transition 150.0000 [get_ports {row_in[659]}]
set_input_transition 150.0000 [get_ports {row_in[658]}]
set_input_transition 150.0000 [get_ports {row_in[657]}]
set_input_transition 150.0000 [get_ports {row_in[656]}]
set_input_transition 150.0000 [get_ports {row_in[655]}]
set_input_transition 150.0000 [get_ports {row_in[654]}]
set_input_transition 150.0000 [get_ports {row_in[653]}]
set_input_transition 150.0000 [get_ports {row_in[652]}]
set_input_transition 150.0000 [get_ports {row_in[651]}]
set_input_transition 150.0000 [get_ports {row_in[650]}]
set_input_transition 150.0000 [get_ports {row_in[649]}]
set_input_transition 150.0000 [get_ports {row_in[648]}]
set_input_transition 150.0000 [get_ports {row_in[647]}]
set_input_transition 150.0000 [get_ports {row_in[646]}]
set_input_transition 150.0000 [get_ports {row_in[645]}]
set_input_transition 150.0000 [get_ports {row_in[644]}]
set_input_transition 150.0000 [get_ports {row_in[643]}]
set_input_transition 150.0000 [get_ports {row_in[642]}]
set_input_transition 150.0000 [get_ports {row_in[641]}]
set_input_transition 150.0000 [get_ports {row_in[640]}]
set_input_transition 150.0000 [get_ports {row_in[639]}]
set_input_transition 150.0000 [get_ports {row_in[638]}]
set_input_transition 150.0000 [get_ports {row_in[637]}]
set_input_transition 150.0000 [get_ports {row_in[636]}]
set_input_transition 150.0000 [get_ports {row_in[635]}]
set_input_transition 150.0000 [get_ports {row_in[634]}]
set_input_transition 150.0000 [get_ports {row_in[633]}]
set_input_transition 150.0000 [get_ports {row_in[632]}]
set_input_transition 150.0000 [get_ports {row_in[631]}]
set_input_transition 150.0000 [get_ports {row_in[630]}]
set_input_transition 150.0000 [get_ports {row_in[629]}]
set_input_transition 150.0000 [get_ports {row_in[628]}]
set_input_transition 150.0000 [get_ports {row_in[627]}]
set_input_transition 150.0000 [get_ports {row_in[626]}]
set_input_transition 150.0000 [get_ports {row_in[625]}]
set_input_transition 150.0000 [get_ports {row_in[624]}]
set_input_transition 150.0000 [get_ports {row_in[623]}]
set_input_transition 150.0000 [get_ports {row_in[622]}]
set_input_transition 150.0000 [get_ports {row_in[621]}]
set_input_transition 150.0000 [get_ports {row_in[620]}]
set_input_transition 150.0000 [get_ports {row_in[619]}]
set_input_transition 150.0000 [get_ports {row_in[618]}]
set_input_transition 150.0000 [get_ports {row_in[617]}]
set_input_transition 150.0000 [get_ports {row_in[616]}]
set_input_transition 150.0000 [get_ports {row_in[615]}]
set_input_transition 150.0000 [get_ports {row_in[614]}]
set_input_transition 150.0000 [get_ports {row_in[613]}]
set_input_transition 150.0000 [get_ports {row_in[612]}]
set_input_transition 150.0000 [get_ports {row_in[611]}]
set_input_transition 150.0000 [get_ports {row_in[610]}]
set_input_transition 150.0000 [get_ports {row_in[609]}]
set_input_transition 150.0000 [get_ports {row_in[608]}]
set_input_transition 150.0000 [get_ports {row_in[607]}]
set_input_transition 150.0000 [get_ports {row_in[606]}]
set_input_transition 150.0000 [get_ports {row_in[605]}]
set_input_transition 150.0000 [get_ports {row_in[604]}]
set_input_transition 150.0000 [get_ports {row_in[603]}]
set_input_transition 150.0000 [get_ports {row_in[602]}]
set_input_transition 150.0000 [get_ports {row_in[601]}]
set_input_transition 150.0000 [get_ports {row_in[600]}]
set_input_transition 150.0000 [get_ports {row_in[599]}]
set_input_transition 150.0000 [get_ports {row_in[598]}]
set_input_transition 150.0000 [get_ports {row_in[597]}]
set_input_transition 150.0000 [get_ports {row_in[596]}]
set_input_transition 150.0000 [get_ports {row_in[595]}]
set_input_transition 150.0000 [get_ports {row_in[594]}]
set_input_transition 150.0000 [get_ports {row_in[593]}]
set_input_transition 150.0000 [get_ports {row_in[592]}]
set_input_transition 150.0000 [get_ports {row_in[591]}]
set_input_transition 150.0000 [get_ports {row_in[590]}]
set_input_transition 150.0000 [get_ports {row_in[589]}]
set_input_transition 150.0000 [get_ports {row_in[588]}]
set_input_transition 150.0000 [get_ports {row_in[587]}]
set_input_transition 150.0000 [get_ports {row_in[586]}]
set_input_transition 150.0000 [get_ports {row_in[585]}]
set_input_transition 150.0000 [get_ports {row_in[584]}]
set_input_transition 150.0000 [get_ports {row_in[583]}]
set_input_transition 150.0000 [get_ports {row_in[582]}]
set_input_transition 150.0000 [get_ports {row_in[581]}]
set_input_transition 150.0000 [get_ports {row_in[580]}]
set_input_transition 150.0000 [get_ports {row_in[579]}]
set_input_transition 150.0000 [get_ports {row_in[578]}]
set_input_transition 150.0000 [get_ports {row_in[577]}]
set_input_transition 150.0000 [get_ports {row_in[576]}]
set_input_transition 150.0000 [get_ports {row_in[575]}]
set_input_transition 150.0000 [get_ports {row_in[574]}]
set_input_transition 150.0000 [get_ports {row_in[573]}]
set_input_transition 150.0000 [get_ports {row_in[572]}]
set_input_transition 150.0000 [get_ports {row_in[571]}]
set_input_transition 150.0000 [get_ports {row_in[570]}]
set_input_transition 150.0000 [get_ports {row_in[569]}]
set_input_transition 150.0000 [get_ports {row_in[568]}]
set_input_transition 150.0000 [get_ports {row_in[567]}]
set_input_transition 150.0000 [get_ports {row_in[566]}]
set_input_transition 150.0000 [get_ports {row_in[565]}]
set_input_transition 150.0000 [get_ports {row_in[564]}]
set_input_transition 150.0000 [get_ports {row_in[563]}]
set_input_transition 150.0000 [get_ports {row_in[562]}]
set_input_transition 150.0000 [get_ports {row_in[561]}]
set_input_transition 150.0000 [get_ports {row_in[560]}]
set_input_transition 150.0000 [get_ports {row_in[559]}]
set_input_transition 150.0000 [get_ports {row_in[558]}]
set_input_transition 150.0000 [get_ports {row_in[557]}]
set_input_transition 150.0000 [get_ports {row_in[556]}]
set_input_transition 150.0000 [get_ports {row_in[555]}]
set_input_transition 150.0000 [get_ports {row_in[554]}]
set_input_transition 150.0000 [get_ports {row_in[553]}]
set_input_transition 150.0000 [get_ports {row_in[552]}]
set_input_transition 150.0000 [get_ports {row_in[551]}]
set_input_transition 150.0000 [get_ports {row_in[550]}]
set_input_transition 150.0000 [get_ports {row_in[549]}]
set_input_transition 150.0000 [get_ports {row_in[548]}]
set_input_transition 150.0000 [get_ports {row_in[547]}]
set_input_transition 150.0000 [get_ports {row_in[546]}]
set_input_transition 150.0000 [get_ports {row_in[545]}]
set_input_transition 150.0000 [get_ports {row_in[544]}]
set_input_transition 150.0000 [get_ports {row_in[543]}]
set_input_transition 150.0000 [get_ports {row_in[542]}]
set_input_transition 150.0000 [get_ports {row_in[541]}]
set_input_transition 150.0000 [get_ports {row_in[540]}]
set_input_transition 150.0000 [get_ports {row_in[539]}]
set_input_transition 150.0000 [get_ports {row_in[538]}]
set_input_transition 150.0000 [get_ports {row_in[537]}]
set_input_transition 150.0000 [get_ports {row_in[536]}]
set_input_transition 150.0000 [get_ports {row_in[535]}]
set_input_transition 150.0000 [get_ports {row_in[534]}]
set_input_transition 150.0000 [get_ports {row_in[533]}]
set_input_transition 150.0000 [get_ports {row_in[532]}]
set_input_transition 150.0000 [get_ports {row_in[531]}]
set_input_transition 150.0000 [get_ports {row_in[530]}]
set_input_transition 150.0000 [get_ports {row_in[529]}]
set_input_transition 150.0000 [get_ports {row_in[528]}]
set_input_transition 150.0000 [get_ports {row_in[527]}]
set_input_transition 150.0000 [get_ports {row_in[526]}]
set_input_transition 150.0000 [get_ports {row_in[525]}]
set_input_transition 150.0000 [get_ports {row_in[524]}]
set_input_transition 150.0000 [get_ports {row_in[523]}]
set_input_transition 150.0000 [get_ports {row_in[522]}]
set_input_transition 150.0000 [get_ports {row_in[521]}]
set_input_transition 150.0000 [get_ports {row_in[520]}]
set_input_transition 150.0000 [get_ports {row_in[519]}]
set_input_transition 150.0000 [get_ports {row_in[518]}]
set_input_transition 150.0000 [get_ports {row_in[517]}]
set_input_transition 150.0000 [get_ports {row_in[516]}]
set_input_transition 150.0000 [get_ports {row_in[515]}]
set_input_transition 150.0000 [get_ports {row_in[514]}]
set_input_transition 150.0000 [get_ports {row_in[513]}]
set_input_transition 150.0000 [get_ports {row_in[512]}]
set_input_transition 150.0000 [get_ports {row_in[511]}]
set_input_transition 150.0000 [get_ports {row_in[510]}]
set_input_transition 150.0000 [get_ports {row_in[509]}]
set_input_transition 150.0000 [get_ports {row_in[508]}]
set_input_transition 150.0000 [get_ports {row_in[507]}]
set_input_transition 150.0000 [get_ports {row_in[506]}]
set_input_transition 150.0000 [get_ports {row_in[505]}]
set_input_transition 150.0000 [get_ports {row_in[504]}]
set_input_transition 150.0000 [get_ports {row_in[503]}]
set_input_transition 150.0000 [get_ports {row_in[502]}]
set_input_transition 150.0000 [get_ports {row_in[501]}]
set_input_transition 150.0000 [get_ports {row_in[500]}]
set_input_transition 150.0000 [get_ports {row_in[499]}]
set_input_transition 150.0000 [get_ports {row_in[498]}]
set_input_transition 150.0000 [get_ports {row_in[497]}]
set_input_transition 150.0000 [get_ports {row_in[496]}]
set_input_transition 150.0000 [get_ports {row_in[495]}]
set_input_transition 150.0000 [get_ports {row_in[494]}]
set_input_transition 150.0000 [get_ports {row_in[493]}]
set_input_transition 150.0000 [get_ports {row_in[492]}]
set_input_transition 150.0000 [get_ports {row_in[491]}]
set_input_transition 150.0000 [get_ports {row_in[490]}]
set_input_transition 150.0000 [get_ports {row_in[489]}]
set_input_transition 150.0000 [get_ports {row_in[488]}]
set_input_transition 150.0000 [get_ports {row_in[487]}]
set_input_transition 150.0000 [get_ports {row_in[486]}]
set_input_transition 150.0000 [get_ports {row_in[485]}]
set_input_transition 150.0000 [get_ports {row_in[484]}]
set_input_transition 150.0000 [get_ports {row_in[483]}]
set_input_transition 150.0000 [get_ports {row_in[482]}]
set_input_transition 150.0000 [get_ports {row_in[481]}]
set_input_transition 150.0000 [get_ports {row_in[480]}]
set_input_transition 150.0000 [get_ports {row_in[479]}]
set_input_transition 150.0000 [get_ports {row_in[478]}]
set_input_transition 150.0000 [get_ports {row_in[477]}]
set_input_transition 150.0000 [get_ports {row_in[476]}]
set_input_transition 150.0000 [get_ports {row_in[475]}]
set_input_transition 150.0000 [get_ports {row_in[474]}]
set_input_transition 150.0000 [get_ports {row_in[473]}]
set_input_transition 150.0000 [get_ports {row_in[472]}]
set_input_transition 150.0000 [get_ports {row_in[471]}]
set_input_transition 150.0000 [get_ports {row_in[470]}]
set_input_transition 150.0000 [get_ports {row_in[469]}]
set_input_transition 150.0000 [get_ports {row_in[468]}]
set_input_transition 150.0000 [get_ports {row_in[467]}]
set_input_transition 150.0000 [get_ports {row_in[466]}]
set_input_transition 150.0000 [get_ports {row_in[465]}]
set_input_transition 150.0000 [get_ports {row_in[464]}]
set_input_transition 150.0000 [get_ports {row_in[463]}]
set_input_transition 150.0000 [get_ports {row_in[462]}]
set_input_transition 150.0000 [get_ports {row_in[461]}]
set_input_transition 150.0000 [get_ports {row_in[460]}]
set_input_transition 150.0000 [get_ports {row_in[459]}]
set_input_transition 150.0000 [get_ports {row_in[458]}]
set_input_transition 150.0000 [get_ports {row_in[457]}]
set_input_transition 150.0000 [get_ports {row_in[456]}]
set_input_transition 150.0000 [get_ports {row_in[455]}]
set_input_transition 150.0000 [get_ports {row_in[454]}]
set_input_transition 150.0000 [get_ports {row_in[453]}]
set_input_transition 150.0000 [get_ports {row_in[452]}]
set_input_transition 150.0000 [get_ports {row_in[451]}]
set_input_transition 150.0000 [get_ports {row_in[450]}]
set_input_transition 150.0000 [get_ports {row_in[449]}]
set_input_transition 150.0000 [get_ports {row_in[448]}]
set_input_transition 150.0000 [get_ports {row_in[447]}]
set_input_transition 150.0000 [get_ports {row_in[446]}]
set_input_transition 150.0000 [get_ports {row_in[445]}]
set_input_transition 150.0000 [get_ports {row_in[444]}]
set_input_transition 150.0000 [get_ports {row_in[443]}]
set_input_transition 150.0000 [get_ports {row_in[442]}]
set_input_transition 150.0000 [get_ports {row_in[441]}]
set_input_transition 150.0000 [get_ports {row_in[440]}]
set_input_transition 150.0000 [get_ports {row_in[439]}]
set_input_transition 150.0000 [get_ports {row_in[438]}]
set_input_transition 150.0000 [get_ports {row_in[437]}]
set_input_transition 150.0000 [get_ports {row_in[436]}]
set_input_transition 150.0000 [get_ports {row_in[435]}]
set_input_transition 150.0000 [get_ports {row_in[434]}]
set_input_transition 150.0000 [get_ports {row_in[433]}]
set_input_transition 150.0000 [get_ports {row_in[432]}]
set_input_transition 150.0000 [get_ports {row_in[431]}]
set_input_transition 150.0000 [get_ports {row_in[430]}]
set_input_transition 150.0000 [get_ports {row_in[429]}]
set_input_transition 150.0000 [get_ports {row_in[428]}]
set_input_transition 150.0000 [get_ports {row_in[427]}]
set_input_transition 150.0000 [get_ports {row_in[426]}]
set_input_transition 150.0000 [get_ports {row_in[425]}]
set_input_transition 150.0000 [get_ports {row_in[424]}]
set_input_transition 150.0000 [get_ports {row_in[423]}]
set_input_transition 150.0000 [get_ports {row_in[422]}]
set_input_transition 150.0000 [get_ports {row_in[421]}]
set_input_transition 150.0000 [get_ports {row_in[420]}]
set_input_transition 150.0000 [get_ports {row_in[419]}]
set_input_transition 150.0000 [get_ports {row_in[418]}]
set_input_transition 150.0000 [get_ports {row_in[417]}]
set_input_transition 150.0000 [get_ports {row_in[416]}]
set_input_transition 150.0000 [get_ports {row_in[415]}]
set_input_transition 150.0000 [get_ports {row_in[414]}]
set_input_transition 150.0000 [get_ports {row_in[413]}]
set_input_transition 150.0000 [get_ports {row_in[412]}]
set_input_transition 150.0000 [get_ports {row_in[411]}]
set_input_transition 150.0000 [get_ports {row_in[410]}]
set_input_transition 150.0000 [get_ports {row_in[409]}]
set_input_transition 150.0000 [get_ports {row_in[408]}]
set_input_transition 150.0000 [get_ports {row_in[407]}]
set_input_transition 150.0000 [get_ports {row_in[406]}]
set_input_transition 150.0000 [get_ports {row_in[405]}]
set_input_transition 150.0000 [get_ports {row_in[404]}]
set_input_transition 150.0000 [get_ports {row_in[403]}]
set_input_transition 150.0000 [get_ports {row_in[402]}]
set_input_transition 150.0000 [get_ports {row_in[401]}]
set_input_transition 150.0000 [get_ports {row_in[400]}]
set_input_transition 150.0000 [get_ports {row_in[399]}]
set_input_transition 150.0000 [get_ports {row_in[398]}]
set_input_transition 150.0000 [get_ports {row_in[397]}]
set_input_transition 150.0000 [get_ports {row_in[396]}]
set_input_transition 150.0000 [get_ports {row_in[395]}]
set_input_transition 150.0000 [get_ports {row_in[394]}]
set_input_transition 150.0000 [get_ports {row_in[393]}]
set_input_transition 150.0000 [get_ports {row_in[392]}]
set_input_transition 150.0000 [get_ports {row_in[391]}]
set_input_transition 150.0000 [get_ports {row_in[390]}]
set_input_transition 150.0000 [get_ports {row_in[389]}]
set_input_transition 150.0000 [get_ports {row_in[388]}]
set_input_transition 150.0000 [get_ports {row_in[387]}]
set_input_transition 150.0000 [get_ports {row_in[386]}]
set_input_transition 150.0000 [get_ports {row_in[385]}]
set_input_transition 150.0000 [get_ports {row_in[384]}]
set_input_transition 150.0000 [get_ports {row_in[383]}]
set_input_transition 150.0000 [get_ports {row_in[382]}]
set_input_transition 150.0000 [get_ports {row_in[381]}]
set_input_transition 150.0000 [get_ports {row_in[380]}]
set_input_transition 150.0000 [get_ports {row_in[379]}]
set_input_transition 150.0000 [get_ports {row_in[378]}]
set_input_transition 150.0000 [get_ports {row_in[377]}]
set_input_transition 150.0000 [get_ports {row_in[376]}]
set_input_transition 150.0000 [get_ports {row_in[375]}]
set_input_transition 150.0000 [get_ports {row_in[374]}]
set_input_transition 150.0000 [get_ports {row_in[373]}]
set_input_transition 150.0000 [get_ports {row_in[372]}]
set_input_transition 150.0000 [get_ports {row_in[371]}]
set_input_transition 150.0000 [get_ports {row_in[370]}]
set_input_transition 150.0000 [get_ports {row_in[369]}]
set_input_transition 150.0000 [get_ports {row_in[368]}]
set_input_transition 150.0000 [get_ports {row_in[367]}]
set_input_transition 150.0000 [get_ports {row_in[366]}]
set_input_transition 150.0000 [get_ports {row_in[365]}]
set_input_transition 150.0000 [get_ports {row_in[364]}]
set_input_transition 150.0000 [get_ports {row_in[363]}]
set_input_transition 150.0000 [get_ports {row_in[362]}]
set_input_transition 150.0000 [get_ports {row_in[361]}]
set_input_transition 150.0000 [get_ports {row_in[360]}]
set_input_transition 150.0000 [get_ports {row_in[359]}]
set_input_transition 150.0000 [get_ports {row_in[358]}]
set_input_transition 150.0000 [get_ports {row_in[357]}]
set_input_transition 150.0000 [get_ports {row_in[356]}]
set_input_transition 150.0000 [get_ports {row_in[355]}]
set_input_transition 150.0000 [get_ports {row_in[354]}]
set_input_transition 150.0000 [get_ports {row_in[353]}]
set_input_transition 150.0000 [get_ports {row_in[352]}]
set_input_transition 150.0000 [get_ports {row_in[351]}]
set_input_transition 150.0000 [get_ports {row_in[350]}]
set_input_transition 150.0000 [get_ports {row_in[349]}]
set_input_transition 150.0000 [get_ports {row_in[348]}]
set_input_transition 150.0000 [get_ports {row_in[347]}]
set_input_transition 150.0000 [get_ports {row_in[346]}]
set_input_transition 150.0000 [get_ports {row_in[345]}]
set_input_transition 150.0000 [get_ports {row_in[344]}]
set_input_transition 150.0000 [get_ports {row_in[343]}]
set_input_transition 150.0000 [get_ports {row_in[342]}]
set_input_transition 150.0000 [get_ports {row_in[341]}]
set_input_transition 150.0000 [get_ports {row_in[340]}]
set_input_transition 150.0000 [get_ports {row_in[339]}]
set_input_transition 150.0000 [get_ports {row_in[338]}]
set_input_transition 150.0000 [get_ports {row_in[337]}]
set_input_transition 150.0000 [get_ports {row_in[336]}]
set_input_transition 150.0000 [get_ports {row_in[335]}]
set_input_transition 150.0000 [get_ports {row_in[334]}]
set_input_transition 150.0000 [get_ports {row_in[333]}]
set_input_transition 150.0000 [get_ports {row_in[332]}]
set_input_transition 150.0000 [get_ports {row_in[331]}]
set_input_transition 150.0000 [get_ports {row_in[330]}]
set_input_transition 150.0000 [get_ports {row_in[329]}]
set_input_transition 150.0000 [get_ports {row_in[328]}]
set_input_transition 150.0000 [get_ports {row_in[327]}]
set_input_transition 150.0000 [get_ports {row_in[326]}]
set_input_transition 150.0000 [get_ports {row_in[325]}]
set_input_transition 150.0000 [get_ports {row_in[324]}]
set_input_transition 150.0000 [get_ports {row_in[323]}]
set_input_transition 150.0000 [get_ports {row_in[322]}]
set_input_transition 150.0000 [get_ports {row_in[321]}]
set_input_transition 150.0000 [get_ports {row_in[320]}]
set_input_transition 150.0000 [get_ports {row_in[319]}]
set_input_transition 150.0000 [get_ports {row_in[318]}]
set_input_transition 150.0000 [get_ports {row_in[317]}]
set_input_transition 150.0000 [get_ports {row_in[316]}]
set_input_transition 150.0000 [get_ports {row_in[315]}]
set_input_transition 150.0000 [get_ports {row_in[314]}]
set_input_transition 150.0000 [get_ports {row_in[313]}]
set_input_transition 150.0000 [get_ports {row_in[312]}]
set_input_transition 150.0000 [get_ports {row_in[311]}]
set_input_transition 150.0000 [get_ports {row_in[310]}]
set_input_transition 150.0000 [get_ports {row_in[309]}]
set_input_transition 150.0000 [get_ports {row_in[308]}]
set_input_transition 150.0000 [get_ports {row_in[307]}]
set_input_transition 150.0000 [get_ports {row_in[306]}]
set_input_transition 150.0000 [get_ports {row_in[305]}]
set_input_transition 150.0000 [get_ports {row_in[304]}]
set_input_transition 150.0000 [get_ports {row_in[303]}]
set_input_transition 150.0000 [get_ports {row_in[302]}]
set_input_transition 150.0000 [get_ports {row_in[301]}]
set_input_transition 150.0000 [get_ports {row_in[300]}]
set_input_transition 150.0000 [get_ports {row_in[299]}]
set_input_transition 150.0000 [get_ports {row_in[298]}]
set_input_transition 150.0000 [get_ports {row_in[297]}]
set_input_transition 150.0000 [get_ports {row_in[296]}]
set_input_transition 150.0000 [get_ports {row_in[295]}]
set_input_transition 150.0000 [get_ports {row_in[294]}]
set_input_transition 150.0000 [get_ports {row_in[293]}]
set_input_transition 150.0000 [get_ports {row_in[292]}]
set_input_transition 150.0000 [get_ports {row_in[291]}]
set_input_transition 150.0000 [get_ports {row_in[290]}]
set_input_transition 150.0000 [get_ports {row_in[289]}]
set_input_transition 150.0000 [get_ports {row_in[288]}]
set_input_transition 150.0000 [get_ports {row_in[287]}]
set_input_transition 150.0000 [get_ports {row_in[286]}]
set_input_transition 150.0000 [get_ports {row_in[285]}]
set_input_transition 150.0000 [get_ports {row_in[284]}]
set_input_transition 150.0000 [get_ports {row_in[283]}]
set_input_transition 150.0000 [get_ports {row_in[282]}]
set_input_transition 150.0000 [get_ports {row_in[281]}]
set_input_transition 150.0000 [get_ports {row_in[280]}]
set_input_transition 150.0000 [get_ports {row_in[279]}]
set_input_transition 150.0000 [get_ports {row_in[278]}]
set_input_transition 150.0000 [get_ports {row_in[277]}]
set_input_transition 150.0000 [get_ports {row_in[276]}]
set_input_transition 150.0000 [get_ports {row_in[275]}]
set_input_transition 150.0000 [get_ports {row_in[274]}]
set_input_transition 150.0000 [get_ports {row_in[273]}]
set_input_transition 150.0000 [get_ports {row_in[272]}]
set_input_transition 150.0000 [get_ports {row_in[271]}]
set_input_transition 150.0000 [get_ports {row_in[270]}]
set_input_transition 150.0000 [get_ports {row_in[269]}]
set_input_transition 150.0000 [get_ports {row_in[268]}]
set_input_transition 150.0000 [get_ports {row_in[267]}]
set_input_transition 150.0000 [get_ports {row_in[266]}]
set_input_transition 150.0000 [get_ports {row_in[265]}]
set_input_transition 150.0000 [get_ports {row_in[264]}]
set_input_transition 150.0000 [get_ports {row_in[263]}]
set_input_transition 150.0000 [get_ports {row_in[262]}]
set_input_transition 150.0000 [get_ports {row_in[261]}]
set_input_transition 150.0000 [get_ports {row_in[260]}]
set_input_transition 150.0000 [get_ports {row_in[259]}]
set_input_transition 150.0000 [get_ports {row_in[258]}]
set_input_transition 150.0000 [get_ports {row_in[257]}]
set_input_transition 150.0000 [get_ports {row_in[256]}]
set_input_transition 150.0000 [get_ports {row_in[255]}]
set_input_transition 150.0000 [get_ports {row_in[254]}]
set_input_transition 150.0000 [get_ports {row_in[253]}]
set_input_transition 150.0000 [get_ports {row_in[252]}]
set_input_transition 150.0000 [get_ports {row_in[251]}]
set_input_transition 150.0000 [get_ports {row_in[250]}]
set_input_transition 150.0000 [get_ports {row_in[249]}]
set_input_transition 150.0000 [get_ports {row_in[248]}]
set_input_transition 150.0000 [get_ports {row_in[247]}]
set_input_transition 150.0000 [get_ports {row_in[246]}]
set_input_transition 150.0000 [get_ports {row_in[245]}]
set_input_transition 150.0000 [get_ports {row_in[244]}]
set_input_transition 150.0000 [get_ports {row_in[243]}]
set_input_transition 150.0000 [get_ports {row_in[242]}]
set_input_transition 150.0000 [get_ports {row_in[241]}]
set_input_transition 150.0000 [get_ports {row_in[240]}]
set_input_transition 150.0000 [get_ports {row_in[239]}]
set_input_transition 150.0000 [get_ports {row_in[238]}]
set_input_transition 150.0000 [get_ports {row_in[237]}]
set_input_transition 150.0000 [get_ports {row_in[236]}]
set_input_transition 150.0000 [get_ports {row_in[235]}]
set_input_transition 150.0000 [get_ports {row_in[234]}]
set_input_transition 150.0000 [get_ports {row_in[233]}]
set_input_transition 150.0000 [get_ports {row_in[232]}]
set_input_transition 150.0000 [get_ports {row_in[231]}]
set_input_transition 150.0000 [get_ports {row_in[230]}]
set_input_transition 150.0000 [get_ports {row_in[229]}]
set_input_transition 150.0000 [get_ports {row_in[228]}]
set_input_transition 150.0000 [get_ports {row_in[227]}]
set_input_transition 150.0000 [get_ports {row_in[226]}]
set_input_transition 150.0000 [get_ports {row_in[225]}]
set_input_transition 150.0000 [get_ports {row_in[224]}]
set_input_transition 150.0000 [get_ports {row_in[223]}]
set_input_transition 150.0000 [get_ports {row_in[222]}]
set_input_transition 150.0000 [get_ports {row_in[221]}]
set_input_transition 150.0000 [get_ports {row_in[220]}]
set_input_transition 150.0000 [get_ports {row_in[219]}]
set_input_transition 150.0000 [get_ports {row_in[218]}]
set_input_transition 150.0000 [get_ports {row_in[217]}]
set_input_transition 150.0000 [get_ports {row_in[216]}]
set_input_transition 150.0000 [get_ports {row_in[215]}]
set_input_transition 150.0000 [get_ports {row_in[214]}]
set_input_transition 150.0000 [get_ports {row_in[213]}]
set_input_transition 150.0000 [get_ports {row_in[212]}]
set_input_transition 150.0000 [get_ports {row_in[211]}]
set_input_transition 150.0000 [get_ports {row_in[210]}]
set_input_transition 150.0000 [get_ports {row_in[209]}]
set_input_transition 150.0000 [get_ports {row_in[208]}]
set_input_transition 150.0000 [get_ports {row_in[207]}]
set_input_transition 150.0000 [get_ports {row_in[206]}]
set_input_transition 150.0000 [get_ports {row_in[205]}]
set_input_transition 150.0000 [get_ports {row_in[204]}]
set_input_transition 150.0000 [get_ports {row_in[203]}]
set_input_transition 150.0000 [get_ports {row_in[202]}]
set_input_transition 150.0000 [get_ports {row_in[201]}]
set_input_transition 150.0000 [get_ports {row_in[200]}]
set_input_transition 150.0000 [get_ports {row_in[199]}]
set_input_transition 150.0000 [get_ports {row_in[198]}]
set_input_transition 150.0000 [get_ports {row_in[197]}]
set_input_transition 150.0000 [get_ports {row_in[196]}]
set_input_transition 150.0000 [get_ports {row_in[195]}]
set_input_transition 150.0000 [get_ports {row_in[194]}]
set_input_transition 150.0000 [get_ports {row_in[193]}]
set_input_transition 150.0000 [get_ports {row_in[192]}]
set_input_transition 150.0000 [get_ports {row_in[191]}]
set_input_transition 150.0000 [get_ports {row_in[190]}]
set_input_transition 150.0000 [get_ports {row_in[189]}]
set_input_transition 150.0000 [get_ports {row_in[188]}]
set_input_transition 150.0000 [get_ports {row_in[187]}]
set_input_transition 150.0000 [get_ports {row_in[186]}]
set_input_transition 150.0000 [get_ports {row_in[185]}]
set_input_transition 150.0000 [get_ports {row_in[184]}]
set_input_transition 150.0000 [get_ports {row_in[183]}]
set_input_transition 150.0000 [get_ports {row_in[182]}]
set_input_transition 150.0000 [get_ports {row_in[181]}]
set_input_transition 150.0000 [get_ports {row_in[180]}]
set_input_transition 150.0000 [get_ports {row_in[179]}]
set_input_transition 150.0000 [get_ports {row_in[178]}]
set_input_transition 150.0000 [get_ports {row_in[177]}]
set_input_transition 150.0000 [get_ports {row_in[176]}]
set_input_transition 150.0000 [get_ports {row_in[175]}]
set_input_transition 150.0000 [get_ports {row_in[174]}]
set_input_transition 150.0000 [get_ports {row_in[173]}]
set_input_transition 150.0000 [get_ports {row_in[172]}]
set_input_transition 150.0000 [get_ports {row_in[171]}]
set_input_transition 150.0000 [get_ports {row_in[170]}]
set_input_transition 150.0000 [get_ports {row_in[169]}]
set_input_transition 150.0000 [get_ports {row_in[168]}]
set_input_transition 150.0000 [get_ports {row_in[167]}]
set_input_transition 150.0000 [get_ports {row_in[166]}]
set_input_transition 150.0000 [get_ports {row_in[165]}]
set_input_transition 150.0000 [get_ports {row_in[164]}]
set_input_transition 150.0000 [get_ports {row_in[163]}]
set_input_transition 150.0000 [get_ports {row_in[162]}]
set_input_transition 150.0000 [get_ports {row_in[161]}]
set_input_transition 150.0000 [get_ports {row_in[160]}]
set_input_transition 150.0000 [get_ports {row_in[159]}]
set_input_transition 150.0000 [get_ports {row_in[158]}]
set_input_transition 150.0000 [get_ports {row_in[157]}]
set_input_transition 150.0000 [get_ports {row_in[156]}]
set_input_transition 150.0000 [get_ports {row_in[155]}]
set_input_transition 150.0000 [get_ports {row_in[154]}]
set_input_transition 150.0000 [get_ports {row_in[153]}]
set_input_transition 150.0000 [get_ports {row_in[152]}]
set_input_transition 150.0000 [get_ports {row_in[151]}]
set_input_transition 150.0000 [get_ports {row_in[150]}]
set_input_transition 150.0000 [get_ports {row_in[149]}]
set_input_transition 150.0000 [get_ports {row_in[148]}]
set_input_transition 150.0000 [get_ports {row_in[147]}]
set_input_transition 150.0000 [get_ports {row_in[146]}]
set_input_transition 150.0000 [get_ports {row_in[145]}]
set_input_transition 150.0000 [get_ports {row_in[144]}]
set_input_transition 150.0000 [get_ports {row_in[143]}]
set_input_transition 150.0000 [get_ports {row_in[142]}]
set_input_transition 150.0000 [get_ports {row_in[141]}]
set_input_transition 150.0000 [get_ports {row_in[140]}]
set_input_transition 150.0000 [get_ports {row_in[139]}]
set_input_transition 150.0000 [get_ports {row_in[138]}]
set_input_transition 150.0000 [get_ports {row_in[137]}]
set_input_transition 150.0000 [get_ports {row_in[136]}]
set_input_transition 150.0000 [get_ports {row_in[135]}]
set_input_transition 150.0000 [get_ports {row_in[134]}]
set_input_transition 150.0000 [get_ports {row_in[133]}]
set_input_transition 150.0000 [get_ports {row_in[132]}]
set_input_transition 150.0000 [get_ports {row_in[131]}]
set_input_transition 150.0000 [get_ports {row_in[130]}]
set_input_transition 150.0000 [get_ports {row_in[129]}]
set_input_transition 150.0000 [get_ports {row_in[128]}]
set_input_transition 150.0000 [get_ports {row_in[127]}]
set_input_transition 150.0000 [get_ports {row_in[126]}]
set_input_transition 150.0000 [get_ports {row_in[125]}]
set_input_transition 150.0000 [get_ports {row_in[124]}]
set_input_transition 150.0000 [get_ports {row_in[123]}]
set_input_transition 150.0000 [get_ports {row_in[122]}]
set_input_transition 150.0000 [get_ports {row_in[121]}]
set_input_transition 150.0000 [get_ports {row_in[120]}]
set_input_transition 150.0000 [get_ports {row_in[119]}]
set_input_transition 150.0000 [get_ports {row_in[118]}]
set_input_transition 150.0000 [get_ports {row_in[117]}]
set_input_transition 150.0000 [get_ports {row_in[116]}]
set_input_transition 150.0000 [get_ports {row_in[115]}]
set_input_transition 150.0000 [get_ports {row_in[114]}]
set_input_transition 150.0000 [get_ports {row_in[113]}]
set_input_transition 150.0000 [get_ports {row_in[112]}]
set_input_transition 150.0000 [get_ports {row_in[111]}]
set_input_transition 150.0000 [get_ports {row_in[110]}]
set_input_transition 150.0000 [get_ports {row_in[109]}]
set_input_transition 150.0000 [get_ports {row_in[108]}]
set_input_transition 150.0000 [get_ports {row_in[107]}]
set_input_transition 150.0000 [get_ports {row_in[106]}]
set_input_transition 150.0000 [get_ports {row_in[105]}]
set_input_transition 150.0000 [get_ports {row_in[104]}]
set_input_transition 150.0000 [get_ports {row_in[103]}]
set_input_transition 150.0000 [get_ports {row_in[102]}]
set_input_transition 150.0000 [get_ports {row_in[101]}]
set_input_transition 150.0000 [get_ports {row_in[100]}]
set_input_transition 150.0000 [get_ports {row_in[99]}]
set_input_transition 150.0000 [get_ports {row_in[98]}]
set_input_transition 150.0000 [get_ports {row_in[97]}]
set_input_transition 150.0000 [get_ports {row_in[96]}]
set_input_transition 150.0000 [get_ports {row_in[95]}]
set_input_transition 150.0000 [get_ports {row_in[94]}]
set_input_transition 150.0000 [get_ports {row_in[93]}]
set_input_transition 150.0000 [get_ports {row_in[92]}]
set_input_transition 150.0000 [get_ports {row_in[91]}]
set_input_transition 150.0000 [get_ports {row_in[90]}]
set_input_transition 150.0000 [get_ports {row_in[89]}]
set_input_transition 150.0000 [get_ports {row_in[88]}]
set_input_transition 150.0000 [get_ports {row_in[87]}]
set_input_transition 150.0000 [get_ports {row_in[86]}]
set_input_transition 150.0000 [get_ports {row_in[85]}]
set_input_transition 150.0000 [get_ports {row_in[84]}]
set_input_transition 150.0000 [get_ports {row_in[83]}]
set_input_transition 150.0000 [get_ports {row_in[82]}]
set_input_transition 150.0000 [get_ports {row_in[81]}]
set_input_transition 150.0000 [get_ports {row_in[80]}]
set_input_transition 150.0000 [get_ports {row_in[79]}]
set_input_transition 150.0000 [get_ports {row_in[78]}]
set_input_transition 150.0000 [get_ports {row_in[77]}]
set_input_transition 150.0000 [get_ports {row_in[76]}]
set_input_transition 150.0000 [get_ports {row_in[75]}]
set_input_transition 150.0000 [get_ports {row_in[74]}]
set_input_transition 150.0000 [get_ports {row_in[73]}]
set_input_transition 150.0000 [get_ports {row_in[72]}]
set_input_transition 150.0000 [get_ports {row_in[71]}]
set_input_transition 150.0000 [get_ports {row_in[70]}]
set_input_transition 150.0000 [get_ports {row_in[69]}]
set_input_transition 150.0000 [get_ports {row_in[68]}]
set_input_transition 150.0000 [get_ports {row_in[67]}]
set_input_transition 150.0000 [get_ports {row_in[66]}]
set_input_transition 150.0000 [get_ports {row_in[65]}]
set_input_transition 150.0000 [get_ports {row_in[64]}]
set_input_transition 150.0000 [get_ports {row_in[63]}]
set_input_transition 150.0000 [get_ports {row_in[62]}]
set_input_transition 150.0000 [get_ports {row_in[61]}]
set_input_transition 150.0000 [get_ports {row_in[60]}]
set_input_transition 150.0000 [get_ports {row_in[59]}]
set_input_transition 150.0000 [get_ports {row_in[58]}]
set_input_transition 150.0000 [get_ports {row_in[57]}]
set_input_transition 150.0000 [get_ports {row_in[56]}]
set_input_transition 150.0000 [get_ports {row_in[55]}]
set_input_transition 150.0000 [get_ports {row_in[54]}]
set_input_transition 150.0000 [get_ports {row_in[53]}]
set_input_transition 150.0000 [get_ports {row_in[52]}]
set_input_transition 150.0000 [get_ports {row_in[51]}]
set_input_transition 150.0000 [get_ports {row_in[50]}]
set_input_transition 150.0000 [get_ports {row_in[49]}]
set_input_transition 150.0000 [get_ports {row_in[48]}]
set_input_transition 150.0000 [get_ports {row_in[47]}]
set_input_transition 150.0000 [get_ports {row_in[46]}]
set_input_transition 150.0000 [get_ports {row_in[45]}]
set_input_transition 150.0000 [get_ports {row_in[44]}]
set_input_transition 150.0000 [get_ports {row_in[43]}]
set_input_transition 150.0000 [get_ports {row_in[42]}]
set_input_transition 150.0000 [get_ports {row_in[41]}]
set_input_transition 150.0000 [get_ports {row_in[40]}]
set_input_transition 150.0000 [get_ports {row_in[39]}]
set_input_transition 150.0000 [get_ports {row_in[38]}]
set_input_transition 150.0000 [get_ports {row_in[37]}]
set_input_transition 150.0000 [get_ports {row_in[36]}]
set_input_transition 150.0000 [get_ports {row_in[35]}]
set_input_transition 150.0000 [get_ports {row_in[34]}]
set_input_transition 150.0000 [get_ports {row_in[33]}]
set_input_transition 150.0000 [get_ports {row_in[32]}]
set_input_transition 150.0000 [get_ports {row_in[31]}]
set_input_transition 150.0000 [get_ports {row_in[30]}]
set_input_transition 150.0000 [get_ports {row_in[29]}]
set_input_transition 150.0000 [get_ports {row_in[28]}]
set_input_transition 150.0000 [get_ports {row_in[27]}]
set_input_transition 150.0000 [get_ports {row_in[26]}]
set_input_transition 150.0000 [get_ports {row_in[25]}]
set_input_transition 150.0000 [get_ports {row_in[24]}]
set_input_transition 150.0000 [get_ports {row_in[23]}]
set_input_transition 150.0000 [get_ports {row_in[22]}]
set_input_transition 150.0000 [get_ports {row_in[21]}]
set_input_transition 150.0000 [get_ports {row_in[20]}]
set_input_transition 150.0000 [get_ports {row_in[19]}]
set_input_transition 150.0000 [get_ports {row_in[18]}]
set_input_transition 150.0000 [get_ports {row_in[17]}]
set_input_transition 150.0000 [get_ports {row_in[16]}]
set_input_transition 150.0000 [get_ports {row_in[15]}]
set_input_transition 150.0000 [get_ports {row_in[14]}]
set_input_transition 150.0000 [get_ports {row_in[13]}]
set_input_transition 150.0000 [get_ports {row_in[12]}]
set_input_transition 150.0000 [get_ports {row_in[11]}]
set_input_transition 150.0000 [get_ports {row_in[10]}]
set_input_transition 150.0000 [get_ports {row_in[9]}]
set_input_transition 150.0000 [get_ports {row_in[8]}]
set_input_transition 150.0000 [get_ports {row_in[7]}]
set_input_transition 150.0000 [get_ports {row_in[6]}]
set_input_transition 150.0000 [get_ports {row_in[5]}]
set_input_transition 150.0000 [get_ports {row_in[4]}]
set_input_transition 150.0000 [get_ports {row_in[3]}]
set_input_transition 150.0000 [get_ports {row_in[2]}]
set_input_transition 150.0000 [get_ports {row_in[1]}]
set_input_transition 150.0000 [get_ports {row_in[0]}]
###############################################################################
# Design Rules
###############################################################################
set_max_transition 260.0000 [current_design]
set_max_fanout 32.0000 [current_design]
