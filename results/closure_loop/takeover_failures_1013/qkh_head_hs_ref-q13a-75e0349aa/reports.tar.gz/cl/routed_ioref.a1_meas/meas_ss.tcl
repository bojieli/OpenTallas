
read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7_tech_1x_201209.lef
read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7sc7p5t_28_R_1x_220121a.lef
read_lef /src/physical/ref_tile/qkh_ktree_ref/views/ot_qkh_ktree/ot_qkh_ktree.lef
read_lef /src/physical/ref_tile/qkh_lane8_ref_b/views/ot_qkh_lane8/ot_qkh_lane8.lef
read_liberty /OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_AO_RVT_TT_nldm_211120.lib.gz
read_liberty /OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_INVBUF_RVT_TT_nldm_220122.lib.gz
read_liberty /OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_OA_RVT_TT_nldm_211120.lib.gz
read_liberty /OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_SEQ_RVT_TT_nldm_220123.lib
read_liberty /OpenROAD-flow-scripts/flow/platforms/asap7/lib/NLDM/asap7sc7p5t_SIMPLE_RVT_TT_nldm_211120.lib.gz
read_liberty /src/physical/ref_tile/qkh_ktree_ref/views/ot_qkh_ktree/ot_qkh_ktree_tt.lib
read_liberty /src/physical/ref_tile/qkh_lane8_ref_b/views/ot_qkh_lane8/ot_qkh_lane8_tt.lib
read_db /work/results/asap7/opentallas_ot_qwen_nearhbm_head_hs_asap7_ref_qkh_head_hs_ref_q13a_75e0349aa/base/6_final.odb
read_sdc /work/results/asap7/opentallas_ot_qwen_nearhbm_head_hs_asap7_ref_qkh_head_hs_ref_q13a_75e0349aa/base/6_final.sdc
read_spef /work/results/asap7/opentallas_ot_qwen_nearhbm_head_hs_asap7_ref_qkh_head_hs_ref_q13a_75e0349aa/base/6_final.spef
set_propagated_clock [all_clocks]
read_sdc /work/w18_extra.sdc

read_sdc /meas/app0_io_ref_routed.sdc
puts "OT_REGS [llength [all_registers]]"
if {[llength [all_clocks]]} { puts "OT_REGS_CLOCKED [llength [all_registers -clock [all_clocks]]]" } else { puts "OT_REGS_CLOCKED 0" }
puts "OT_CORNER tt"
puts "OT_WS [sta::worst_slack_cmd max]"
puts "OT_TNS [sta::total_negative_slack_cmd max]"
report_checks -path_delay max -group_path_count 1 -format full_clock_expanded
set n 0; set wd 1e9
foreach p [get_pins -hierarchical */D] { set s [get_property $p slack_max]; if {$s ne "INF"} { if {$s < 0} { incr n }; if {$s < $wd} { set wd $s } } }
puts "OT_VIOL_D_PINS $n"
puts "OT_WS_REG_D $wd"
set wo 1e9
foreach p [all_outputs] { set s [get_property $p slack_max]; if {$s ne "INF" && $s < $wo} { set wo $s } }
puts "OT_WS_OUT $wo"
set pr [find_timing_paths -path_delay max -from [all_registers -clock_pins] -to [all_registers -data_pins] -group_path_count 1]
# find_timing_paths returns one worst path PER GROUP. Select the minimum
# across groups; index 0 can be asynchronous even when core_clk is worse.
set ot_worst INF
foreach ot_path $pr {
    set ot_slack [get_property $ot_path slack]
    if {$ot_worst eq "INF" || $ot_slack < $ot_worst} { set ot_worst $ot_slack }
}
puts "OT_WS_R2R $ot_worst"
set pi [find_timing_paths -path_delay max -from [all_inputs] -to [all_registers -data_pins] -group_path_count 1]
# find_timing_paths returns one worst path PER GROUP. Select the minimum
# across groups; index 0 can be asynchronous even when core_clk is worse.
set ot_worst INF
foreach ot_path $pi {
    set ot_slack [get_property $ot_path slack]
    if {$ot_worst eq "INF" || $ot_slack < $ot_worst} { set ot_worst $ot_slack }
}
puts "OT_WS_I2R $ot_worst"
foreach p [find_timing_paths -path_delay max -group_path_count 5000 -endpoint_path_count 1 -slack_max 0] { puts "OT_PATH [get_full_name [get_property $p startpoint]] [get_full_name [get_property $p endpoint]] [get_property $p slack]" }
exit
