place_macro -macro_name {u_body.u_rb.g_sram.g_t\[0\].u_m} -location {31.536 86.4} -orientation R0
place_macro -macro_name {u_body.u_rb.g_sram.g_t\[1\].u_m} -location {31.536 138.24} -orientation R0
place_macro -macro_name {u_body.u_rb.g_sram.g_t\[2\].u_m} -location {31.536 190.08} -orientation R0
place_macro -macro_name {u_body.u_rb.g_sram.g_t\[3\].u_m} -location {31.536 241.92} -orientation R0
place_macro -macro_name {u_body.u_rb.g_sram.g_t\[4\].u_m} -location {31.536 293.76} -orientation R0
place_macro -macro_name {u_body.u_rb.g_sram.g_t\[5\].u_m} -location {31.536 345.6} -orientation R0
place_macro -macro_name {u_body.u_rb.g_sram.g_t\[6\].u_m} -location {31.536 397.44} -orientation R0
place_macro -macro_name {u_body.u_rb.g_sram.g_t\[7\].u_m} -location {31.536 449.28} -orientation R0

