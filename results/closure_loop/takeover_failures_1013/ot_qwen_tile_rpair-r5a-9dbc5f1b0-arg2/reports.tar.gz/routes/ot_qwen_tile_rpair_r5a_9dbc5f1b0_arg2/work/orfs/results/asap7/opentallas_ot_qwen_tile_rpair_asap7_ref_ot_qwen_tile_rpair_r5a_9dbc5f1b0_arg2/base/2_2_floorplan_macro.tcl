place_macro -macro_name {u_rom0} -location {22.464 32.4} -orientation R0
place_macro -macro_name {u_rom1} -location {165.888 32.4} -orientation R0

