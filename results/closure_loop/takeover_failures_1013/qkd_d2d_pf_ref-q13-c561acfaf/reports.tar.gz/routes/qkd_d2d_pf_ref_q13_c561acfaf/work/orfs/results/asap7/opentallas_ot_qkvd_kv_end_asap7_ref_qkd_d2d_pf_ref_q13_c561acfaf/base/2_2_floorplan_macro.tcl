place_macro -macro_name {u_d2d.g_rx\[0\].g_ht.g_f.u_rb} -location {648 345.624} -orientation MX
place_macro -macro_name {u_d2d.g_rx\[1\].g_ht.g_s.u_rb} -location {129.6 302.424} -orientation MX
place_macro -macro_name {u_d2d.g_rx\[2\].g_ht.g_f.u_rb} -location {648 216.024} -orientation MX
place_macro -macro_name {u_d2d.g_rx\[3\].g_ht.g_s.u_rb} -location {388.8 302.424} -orientation MX
place_macro -macro_name {u_d2d.g_tx\[0\].g_ht.g_s.u_ib} -location {129.6 43.2} -orientation R0
place_macro -macro_name {u_d2d.g_tx\[1\].g_ht.g_s.u_ib} -location {388.8 43.2} -orientation R0
place_macro -macro_name {u_d2d.g_tx\[2\].g_ht.g_f.u_ib} -location {648 43.2} -orientation R0

