read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7_tech_1x_201209.lef
read_lef /OpenROAD-flow-scripts/flow/platforms/asap7/lef/asap7sc7p5t_28_R_1x_220121a.lef
foreach f [glob $::env(LIBDIR)/*RVT_$::env(CORNER)_nldm*.lib*] { read_liberty $f }
read_verilog /work/clock/ctree.v
link_design ctree
initialize_floorplan -die_area {0 0 17521.92 17556.48} -core_area {0 0 17521.92 17556.48} -site asap7sc7p5t
source /work/clock/make_tracks.tcl
place_pin -pin_name root -layer M9 -location {8760.960 7740.440} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3_xw_o_shim__clk -layer M9 -location {8420.192 8599.968} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3_xw_o_shim__clk_t1 -layer M9 -location {8751.840 8599.968} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t22 -layer M9 -location {8855.520 8351.776} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t21 -layer M9 -location {9005.280 8321.952} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t23 -layer M9 -location {9005.280 8377.888} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t19 -layer M9 -location {9201.120 8087.072} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t18 -layer M9 -location {8852.192 8074.016} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t17 -layer M9 -location {9005.280 8005.152} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t20 -layer M9 -location {9005.280 8095.776} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t26 -layer M9 -location {8787.360 8569.248} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t30 -layer M9 -location {9183.456 8760.992} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t28 -layer M9 -location {8855.200 8760.992} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t29 -layer M9 -location {8992.352 8760.992} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3_xe_o_shim__clk -layer M9 -location {9374.880 8599.968} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t27 -layer M9 -location {9340.320 8629.728} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t24 -layer M9 -location {9164.512 8432.672} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t25 -layer M9 -location {9301.472 8432.672} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3_bw_i_shim__clk_t1 -layer M9 -location {8087.520 7563.168} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3_bw_i_shim__clk -layer M9 -location {8419.168 7563.168} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3_be_i_shim__clk -layer M9 -location {9434.400 7563.168} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t12 -layer M9 -location {9340.320 7575.840} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t8 -layer M9 -location {9107.872 7395.872} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t9 -layer M9 -location {9248.608 7395.872} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t15 -layer M9 -location {9205.344 7741.472} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t14 -layer M9 -location {9005.280 7698.848} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t16 -layer M9 -location {9005.280 7803.552} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t11 -layer M9 -location {8992.416 7528.160} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t13 -layer M9 -location {9095.776 7658.592} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t10 -layer M9 -location {8787.360 7526.880} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk -layer M9 -location {8852.192 7800.288} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t1 -layer M9 -location {8880.736 6721.952} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t2 -layer M9 -location {9088.800 6721.952} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t5 -layer M9 -location {9193.888 7050.272} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t4 -layer M9 -location {8855.520 6978.464} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t3 -layer M9 -location {9005.280 6978.464} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t7 -layer M9 -location {8855.520 7252.960} -pin_size {0.04 0.32}
place_pin -pin_name t_sp3__clk_t6 -layer M9 -location {9005.280 7252.960} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2_bw_i_shim__clk_t1 -layer M9 -location {8087.520 9636.768} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2_bw_i_shim__clk -layer M9 -location {8419.168 9636.768} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2_be_i_shim__clk -layer M9 -location {9434.400 9636.768} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t9 -layer M9 -location {9248.608 9469.472} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t12 -layer M9 -location {9340.320 9649.440} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t13 -layer M9 -location {9095.776 9732.192} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t15 -layer M9 -location {9205.344 9815.072} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t10 -layer M9 -location {8787.360 9600.480} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t11 -layer M9 -location {8992.416 9601.760} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk -layer M9 -location {8852.192 9873.888} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t14 -layer M9 -location {9005.280 9772.448} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t1 -layer M9 -location {8880.736 8795.552} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t2 -layer M9 -location {9088.800 8795.552} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t4 -layer M9 -location {8855.520 9052.064} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t3 -layer M9 -location {9005.280 9052.064} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t7 -layer M9 -location {8855.520 9326.560} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t6 -layer M9 -location {9005.280 9326.560} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t8 -layer M9 -location {9107.872 9469.472} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t5 -layer M9 -location {9193.888 9123.872} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t16 -layer M9 -location {9005.280 9877.152} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t17 -layer M9 -location {9005.280 10078.752} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t18 -layer M9 -location {8852.192 10147.616} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t19 -layer M9 -location {9201.120 10160.672} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t20 -layer M9 -location {9005.280 10169.376} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t21 -layer M9 -location {9005.280 10395.552} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t22 -layer M9 -location {8855.520 10425.376} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t23 -layer M9 -location {9005.280 10451.488} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t26 -layer M9 -location {8787.360 10642.848} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t24 -layer M9 -location {9164.512 10506.272} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t25 -layer M9 -location {9301.472 10506.272} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t27 -layer M9 -location {9340.320 10703.328} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t28 -layer M9 -location {8855.200 10834.592} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t29 -layer M9 -location {8992.352 10834.592} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2__clk_t30 -layer M9 -location {9183.456 10834.592} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2_xw_o_shim__clk -layer M9 -location {8420.192 10673.568} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2_xw_o_shim__clk_t1 -layer M9 -location {8751.840 10673.568} -pin_size {0.04 0.32}
place_pin -pin_name t_sp2_xe_o_shim__clk -layer M9 -location {9374.880 10673.568} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4_bw_i_shim__clk_t1 -layer M9 -location {8087.520 5489.568} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4_bw_i_shim__clk -layer M9 -location {8419.168 5489.568} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4_be_i_shim__clk -layer M9 -location {9434.400 5489.568} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t15 -layer M9 -location {9205.344 5667.872} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t12 -layer M9 -location {9340.320 5502.240} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk -layer M9 -location {8852.192 5726.688} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t10 -layer M9 -location {8787.360 5453.280} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t11 -layer M9 -location {8992.416 5454.560} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t13 -layer M9 -location {9095.776 5584.992} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t14 -layer M9 -location {9005.280 5625.248} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t16 -layer M9 -location {9005.280 5729.952} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t8 -layer M9 -location {9107.872 5322.272} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t9 -layer M9 -location {9248.608 5322.272} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t1 -layer M9 -location {8880.736 4648.352} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t2 -layer M9 -location {9088.800 4648.352} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t5 -layer M9 -location {9193.888 4976.672} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t4 -layer M9 -location {8855.520 4904.864} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t3 -layer M9 -location {9005.280 4904.864} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t7 -layer M9 -location {8855.520 5179.360} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t6 -layer M9 -location {9005.280 5179.360} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4_xw_o_shim__clk -layer M9 -location {8420.192 6526.368} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4_xw_o_shim__clk_t1 -layer M9 -location {8751.840 6526.368} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t22 -layer M9 -location {8855.520 6278.176} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t21 -layer M9 -location {9005.280 6248.352} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t23 -layer M9 -location {9005.280 6304.288} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t19 -layer M9 -location {9201.120 6013.472} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t18 -layer M9 -location {8852.192 6000.416} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t17 -layer M9 -location {9005.280 5931.552} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t20 -layer M9 -location {9005.280 6022.176} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t26 -layer M9 -location {8787.360 6495.648} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t30 -layer M9 -location {9183.456 6687.392} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t28 -layer M9 -location {8855.200 6687.392} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t29 -layer M9 -location {8992.352 6687.392} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4_xe_o_shim__clk -layer M9 -location {9374.880 6526.368} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t27 -layer M9 -location {9340.320 6556.128} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t24 -layer M9 -location {9164.512 6359.072} -pin_size {0.04 0.32}
place_pin -pin_name t_sp4__clk_t25 -layer M9 -location {9301.472 6359.072} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3o0__clk -layer M9 -location {9805.920 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3o0__clk -layer M9 -location {7716.000 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1_bw_i_shim__clk_t1 -layer M9 -location {8087.520 11710.368} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1_bw_i_shim__clk -layer M9 -location {8419.168 11710.368} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1_be_i_shim__clk -layer M9 -location {9434.400 11710.368} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t12 -layer M9 -location {9340.320 11723.040} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t8 -layer M9 -location {9107.872 11543.072} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t9 -layer M9 -location {9248.608 11543.072} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t15 -layer M9 -location {9205.344 11888.672} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t14 -layer M9 -location {9005.280 11846.048} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t16 -layer M9 -location {9005.280 11950.752} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t11 -layer M9 -location {8992.416 11675.360} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t13 -layer M9 -location {9095.776 11805.792} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t10 -layer M9 -location {8787.360 11674.080} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk -layer M9 -location {8852.192 11947.488} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t1 -layer M9 -location {8880.736 10869.152} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t2 -layer M9 -location {9088.800 10869.152} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t5 -layer M9 -location {9193.888 11197.472} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t4 -layer M9 -location {8855.520 11125.664} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t3 -layer M9 -location {9005.280 11125.664} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t7 -layer M9 -location {8855.520 11400.160} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t6 -layer M9 -location {9005.280 11400.160} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1_xw_o_shim__clk -layer M9 -location {8420.192 12747.168} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1_xw_o_shim__clk_t1 -layer M9 -location {8751.840 12747.168} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1_xe_o_shim__clk -layer M9 -location {9374.880 12747.168} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t27 -layer M9 -location {9340.320 12776.928} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t24 -layer M9 -location {9164.512 12579.872} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t25 -layer M9 -location {9301.472 12579.872} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t26 -layer M9 -location {8787.360 12716.448} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t30 -layer M9 -location {9183.456 12908.192} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t28 -layer M9 -location {8855.200 12908.192} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t29 -layer M9 -location {8992.352 12908.192} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t22 -layer M9 -location {8855.520 12498.976} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t21 -layer M9 -location {9005.280 12469.152} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t23 -layer M9 -location {9005.280 12525.088} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t19 -layer M9 -location {9201.120 12234.272} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t18 -layer M9 -location {8852.192 12221.216} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t17 -layer M9 -location {9005.280 12152.352} -pin_size {0.04 0.32}
place_pin -pin_name t_sp1__clk_t20 -layer M9 -location {9005.280 12242.976} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2o0__clk -layer M9 -location {9805.920 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2o0__clk -layer M9 -location {7716.000 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5_bw_i_shim__clk_t1 -layer M9 -location {8087.520 3415.968} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5_bw_i_shim__clk -layer M9 -location {8419.168 3415.968} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5_be_i_shim__clk -layer M9 -location {9434.400 3415.968} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t7 -layer M9 -location {9340.320 3429.728} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t4 -layer M9 -location {9263.072 3248.672} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t3 -layer M9 -location {9126.432 3248.672} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t6 -layer M9 -location {9061.600 3355.488} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t8 -layer M9 -location {8981.792 3510.496} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t10 -layer M9 -location {9005.280 3604.512} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t9 -layer M9 -location {9192.480 3594.272} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t5 -layer M9 -location {8787.360 3340.640} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk -layer M9 -location {8787.360 3490.144} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t1 -layer M9 -location {9134.944 2574.752} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t2 -layer M9 -location {9193.888 2903.072} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t11 -layer M9 -location {9005.280 3749.728} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t12 -layer M9 -location {9005.280 3869.088} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t14 -layer M9 -location {9005.280 4017.952} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t13 -layer M9 -location {9193.888 3939.872} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5_xe_o_shim__clk -layer M9 -location {9374.880 4452.768} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t19 -layer M9 -location {9340.320 4451.232} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t20 -layer M9 -location {9175.136 4464.224} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t24 -layer M9 -location {9200.864 4613.792} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t15 -layer M9 -location {9005.280 4195.552} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t16 -layer M9 -location {9176.480 4285.472} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t17 -layer M9 -location {8837.792 4349.728} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t21 -layer M9 -location {8787.360 4476.064} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t18 -layer M9 -location {8992.480 4419.872} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t22 -layer M9 -location {8855.520 4613.792} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5__clk_t23 -layer M9 -location {8980.704 4613.792} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5_xw_o_shim__clk -layer M9 -location {8420.192 4452.768} -pin_size {0.04 0.32}
place_pin -pin_name t_sp5_xw_o_shim__clk_t1 -layer M9 -location {8751.840 4452.768} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4o0__clk -layer M9 -location {9805.920 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4o0__clk -layer M9 -location {7716.000 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3b0__clk -layer M9 -location {9806.880 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3o1__clk -layer M9 -location {10514.400 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3b0__clk -layer M9 -location {7715.040 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3o1__clk -layer M9 -location {7007.520 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0_bw_i_shim__clk_t1 -layer M9 -location {8087.520 13783.968} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0_bw_i_shim__clk -layer M9 -location {8419.168 13783.968} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0_be_i_shim__clk -layer M9 -location {9434.400 13783.968} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t15 -layer M9 -location {9205.344 13962.272} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t12 -layer M9 -location {9340.320 13796.640} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk -layer M9 -location {8852.192 14021.088} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t10 -layer M9 -location {8787.360 13747.680} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t11 -layer M9 -location {8992.416 13748.960} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t13 -layer M9 -location {9095.776 13879.392} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t14 -layer M9 -location {9005.280 13919.648} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t16 -layer M9 -location {9005.280 14024.352} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t8 -layer M9 -location {9107.872 13616.672} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t9 -layer M9 -location {9248.608 13616.672} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t1 -layer M9 -location {8880.736 12942.752} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t2 -layer M9 -location {9088.800 12942.752} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t5 -layer M9 -location {9193.888 13271.072} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t4 -layer M9 -location {8855.520 13199.264} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t3 -layer M9 -location {9005.280 13199.264} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t7 -layer M9 -location {8855.520 13473.760} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t6 -layer M9 -location {9005.280 13473.760} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t22 -layer M9 -location {8855.520 14572.576} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t21 -layer M9 -location {9005.280 14542.752} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t23 -layer M9 -location {9005.280 14598.688} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t19 -layer M9 -location {9201.120 14307.872} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t18 -layer M9 -location {8852.192 14294.816} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t17 -layer M9 -location {9005.280 14225.952} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t20 -layer M9 -location {9005.280 14316.576} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t27 -layer M9 -location {9340.320 14850.528} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t24 -layer M9 -location {9164.512 14653.472} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t25 -layer M9 -location {9301.472 14653.472} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t26 -layer M9 -location {8787.360 14790.048} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t30 -layer M9 -location {9183.456 14981.792} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t28 -layer M9 -location {8855.200 14981.792} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0__clk_t29 -layer M9 -location {8992.352 14981.792} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0_xw_o_shim__clk -layer M9 -location {8420.192 14820.768} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0_xw_o_shim__clk_t1 -layer M9 -location {8751.840 14820.768} -pin_size {0.04 0.32}
place_pin -pin_name t_sp0_xe_o_shim__clk -layer M9 -location {9374.880 14820.768} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1o0__clk -layer M9 -location {9805.920 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1o0__clk -layer M9 -location {7716.000 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2b0__clk -layer M9 -location {9806.880 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2o1__clk -layer M9 -location {10514.400 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2b0__clk -layer M9 -location {7715.040 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2o1__clk -layer M9 -location {7007.520 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_host__clk_t2 -layer M9 -location {8778.720 1656.160} -pin_size {0.04 0.32}
place_pin -pin_name t_host__clk -layer M9 -location {9161.504 1883.552} -pin_size {0.04 0.32}
place_pin -pin_name t_host__clk_t1 -layer M9 -location {9838.240 1347.872} -pin_size {0.04 0.32}
place_pin -pin_name t_host_nstrip__clk_t4 -layer M9 -location {8778.720 2122.464} -pin_size {0.04 0.32}
place_pin -pin_name t_host_nstrip__clk_t5 -layer M9 -location {9064.864 2135.072} -pin_size {0.04 0.32}
place_pin -pin_name t_host_nstrip__clk_t1 -layer M9 -location {9118.624 1918.112} -pin_size {0.04 0.32}
place_pin -pin_name t_host_nstrip__clk_t6 -layer M9 -location {9144.928 2229.152} -pin_size {0.04 0.32}
place_pin -pin_name t_host_nstrip__clk_t8 -layer M9 -location {9211.872 2540.192} -pin_size {0.04 0.32}
place_pin -pin_name t_host_nstrip__clk_t7 -layer M9 -location {9271.200 2238.048} -pin_size {0.04 0.32}
place_pin -pin_name t_host_nstrip__clk -layer M9 -location {9525.088 2117.088} -pin_size {0.04 0.32}
place_pin -pin_name t_host_nstrip__clk_t3 -layer M9 -location {9864.608 2117.088} -pin_size {0.04 0.32}
place_pin -pin_name t_host_nstrip__clk_t2 -layer M9 -location {10186.080 2104.416} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5o0__clk -layer M9 -location {9805.920 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5o0__clk -layer M9 -location {7716.000 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4b0__clk -layer M9 -location {9806.880 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4o1__clk -layer M9 -location {10514.400 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4b0__clk -layer M9 -location {7715.040 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4o1__clk -layer M9 -location {7007.520 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3b1__clk -layer M9 -location {10515.360 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3o2__clk -layer M9 -location {11222.880 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3b1__clk -layer M9 -location {7006.560 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3o2__clk -layer M9 -location {6299.040 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl__clk_t3 -layer M9 -location {8778.720 15099.872} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl__clk -layer M9 -location {8778.720 15300.896} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl__clk_t5 -layer M9 -location {8778.720 15458.016} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl__clk_t1 -layer M9 -location {8922.272 15016.352} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl__clk_t2 -layer M9 -location {9180.512 15016.352} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl__clk_t4 -layer M9 -location {9331.680 15404.640} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl_estrip__clk_t1 -layer M9 -location {9366.240 15392.032} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl_estrip__clk -layer M9 -location {9633.120 15404.640} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl_estrip__clk_t2 -layer M9 -location {9919.200 15404.640} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl_estrip__clk_t3 -layer M9 -location {10186.080 15452.064} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl_nstrip__clk_t9 -layer M9 -location {9940.832 16208.672} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl_nstrip__clk_t6 -layer M9 -location {10040.160 15875.936} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl_nstrip__clk -layer M9 -location {9424.352 15644.256} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl_nstrip__clk_t2 -layer M9 -location {9747.040 15622.688} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl_nstrip__clk_t7 -layer M9 -location {9808.928 15892.320} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl_nstrip__clk_t8 -layer M9 -location {8778.720 16083.552} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl_nstrip__clk_t5 -layer M9 -location {8778.720 15839.776} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl_nstrip__clk_t4 -layer M9 -location {8843.552 15720.992} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl_nstrip__clk_t1 -layer M9 -location {8778.720 15571.936} -pin_size {0.04 0.32}
place_pin -pin_name t_ctl_nstrip__clk_t3 -layer M9 -location {9092.640 15644.256} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0o0__clk -layer M9 -location {9805.920 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0o0__clk -layer M9 -location {7716.000 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1b0__clk -layer M9 -location {9806.880 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1o1__clk -layer M9 -location {10514.400 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1b0__clk -layer M9 -location {7715.040 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1o1__clk -layer M9 -location {7007.520 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2b1__clk -layer M9 -location {10515.360 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2o2__clk -layer M9 -location {11222.880 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2b1__clk -layer M9 -location {7006.560 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2o2__clk -layer M9 -location {6299.040 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_lk_HOST1__clk -layer M9 -location {10203.360 1252.832} -pin_size {0.04 0.32}
place_pin -pin_name t_sst5__clk_t10 -layer M9 -location {8400.224 2135.072} -pin_size {0.04 0.32}
place_pin -pin_name t_sst5__clk_t11 -layer M9 -location {8743.200 2164.448} -pin_size {0.04 0.32}
place_pin -pin_name t_sst5__clk_t4 -layer M9 -location {8410.272 1656.160} -pin_size {0.04 0.32}
place_pin -pin_name t_sst5__clk_t7 -layer M9 -location {8743.200 1775.136} -pin_size {0.04 0.32}
place_pin -pin_name t_sst5__clk -layer M9 -location {8040.032 2122.464} -pin_size {0.04 0.32}
place_pin -pin_name t_sst5__clk_t8 -layer M9 -location {7335.840 2104.416} -pin_size {0.04 0.32}
place_pin -pin_name t_sst5__clk_t9 -layer M9 -location {7610.336 2117.088} -pin_size {0.04 0.32}
place_pin -pin_name t_sst5__clk_t1 -layer M9 -location {7581.088 1347.872} -pin_size {0.04 0.32}
place_pin -pin_name t_sst5__clk_t2 -layer M9 -location {7708.832 1553.568} -pin_size {0.04 0.32}
place_pin -pin_name t_sst5__clk_t5 -layer M9 -location {7802.656 1681.312} -pin_size {0.04 0.32}
place_pin -pin_name t_sst5__clk_t3 -layer M9 -location {8059.488 1553.568} -pin_size {0.04 0.32}
place_pin -pin_name t_sst5__clk_t6 -layer M9 -location {8059.488 1775.136} -pin_size {0.04 0.32}
place_pin -pin_name t_sst7__clk_t1 -layer M9 -location {10221.600 2164.448} -pin_size {0.04 0.32}
place_pin -pin_name t_sst7__clk_t2 -layer M9 -location {10496.096 2151.840} -pin_size {0.04 0.32}
place_pin -pin_name t_sst7__clk_t5 -layer M9 -location {10788.192 2104.416} -pin_size {0.04 0.32}
place_pin -pin_name t_sst7__clk -layer M9 -location {10925.792 2151.840} -pin_size {0.04 0.32}
place_pin -pin_name t_sst7__clk_t3 -layer M9 -location {11285.984 2151.840} -pin_size {0.04 0.32}
place_pin -pin_name t_sst7__clk_t4 -layer M9 -location {11628.960 2122.464} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5b0__clk -layer M9 -location {9806.880 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5o1__clk -layer M9 -location {10514.400 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5b0__clk -layer M9 -location {7715.040 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5o1__clk -layer M9 -location {7007.520 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4b1__clk -layer M9 -location {10515.360 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4o2__clk -layer M9 -location {11222.880 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4b1__clk -layer M9 -location {7006.560 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4o2__clk -layer M9 -location {6299.040 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3b2__clk -layer M9 -location {11223.840 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3o3__clk -layer M9 -location {11931.360 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3b2__clk -layer M9 -location {6298.080 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3o3__clk -layer M9 -location {5590.560 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_lep0N__clk -layer M9 -location {8043.360 15612.448} -pin_size {0.04 0.32}
place_pin -pin_name t_lk_WN3__clk -layer M9 -location {10203.360 16303.648} -pin_size {0.04 0.32}
place_pin -pin_name t_nst7__clk_t1 -layer M9 -location {10221.600 15392.032} -pin_size {0.04 0.32}
place_pin -pin_name t_nst7__clk_t2 -layer M9 -location {10496.096 15404.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst7__clk_t5 -layer M9 -location {10788.192 15452.064} -pin_size {0.04 0.32}
place_pin -pin_name t_nst7__clk -layer M9 -location {10925.792 15404.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst7__clk_t3 -layer M9 -location {11285.984 15404.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst7__clk_t4 -layer M9 -location {11628.960 15434.016} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0b0__clk -layer M9 -location {9806.880 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0o1__clk -layer M9 -location {10514.400 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0b0__clk -layer M9 -location {7715.040 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0o1__clk -layer M9 -location {7007.520 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1b1__clk -layer M9 -location {10515.360 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1o2__clk -layer M9 -location {11222.880 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1b1__clk -layer M9 -location {7006.560 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1o2__clk -layer M9 -location {6299.040 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2b2__clk -layer M9 -location {11223.840 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2o3__clk -layer M9 -location {11931.360 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2b2__clk -layer M9 -location {6298.080 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2o3__clk -layer M9 -location {5590.560 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_lk_HOST0__clk -layer M9 -location {7318.560 1252.832} -pin_size {0.04 0.32}
place_pin -pin_name t_sst4__clk_t4 -layer M9 -location {5892.960 2122.464} -pin_size {0.04 0.32}
place_pin -pin_name t_sst4__clk_t3 -layer M9 -location {6235.936 2151.840} -pin_size {0.04 0.32}
place_pin -pin_name t_sst4__clk -layer M9 -location {6596.128 2151.840} -pin_size {0.04 0.32}
place_pin -pin_name t_sst4__clk_t5 -layer M9 -location {6733.728 2104.416} -pin_size {0.04 0.32}
place_pin -pin_name t_sst4__clk_t2 -layer M9 -location {7025.824 2151.840} -pin_size {0.04 0.32}
place_pin -pin_name t_sst4__clk_t1 -layer M9 -location {7300.320 2164.448} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh7S_estrip__clk_t1 -layer M9 -location {11664.480 2164.448} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh7S_estrip__clk_t2 -layer M9 -location {11926.048 2151.840} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh7S_estrip__clk -layer M9 -location {12205.472 2151.840} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh7S_estrip__clk_t3 -layer M9 -location {12467.040 2122.464} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh7S__clk_t2 -layer M9 -location {12724.000 1347.808} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh7S__clk -layer M9 -location {12502.560 2151.840} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh7S__clk_t1 -layer M9 -location {13071.840 2231.840} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5b1__clk -layer M9 -location {10515.360 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5o2__clk -layer M9 -location {11222.880 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5b1__clk -layer M9 -location {7006.560 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5o2__clk -layer M9 -location {6299.040 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4b2__clk -layer M9 -location {11223.840 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4o3__clk -layer M9 -location {11931.360 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4b2__clk -layer M9 -location {6298.080 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4o3__clk -layer M9 -location {5590.560 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3b3__clk -layer M9 -location {11932.320 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3o4__clk -layer M9 -location {12639.840 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3b3__clk -layer M9 -location {5589.600 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3o4__clk -layer M9 -location {4882.080 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_lk_WN0__clk -layer M9 -location {7318.560 16303.648} -pin_size {0.04 0.32}
place_pin -pin_name t_nst4__clk_t1 -layer M9 -location {5892.960 15222.048} -pin_size {0.04 0.32}
place_pin -pin_name t_nst4__clk_t2 -layer M9 -location {6235.936 15228.000} -pin_size {0.04 0.32}
place_pin -pin_name t_nst4__clk_t6 -layer M9 -location {6235.936 15469.664} -pin_size {0.04 0.32}
place_pin -pin_name t_nst4__clk_t8 -layer M9 -location {5892.960 15742.048} -pin_size {0.04 0.32}
place_pin -pin_name t_nst4__clk_t9 -layer M9 -location {6235.936 15880.672} -pin_size {0.04 0.32}
place_pin -pin_name t_nst4__clk_t5 -layer M9 -location {7300.320 15443.616} -pin_size {0.04 0.32}
place_pin -pin_name t_nst4__clk_t11 -layer M9 -location {7300.320 15963.616} -pin_size {0.04 0.32}
place_pin -pin_name t_nst4__clk_t4 -layer M9 -location {6597.152 15324.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst4__clk_t3 -layer M9 -location {6957.344 15228.000} -pin_size {0.04 0.32}
place_pin -pin_name t_nst4__clk_t7 -layer M9 -location {6957.344 15469.664} -pin_size {0.04 0.32}
place_pin -pin_name t_nst4__clk -layer M9 -location {6597.152 15844.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst4__clk_t10 -layer M9 -location {6957.344 15880.672} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh7N_estrip__clk_t1 -layer M9 -location {11664.480 15392.032} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh7N_estrip__clk_t2 -layer M9 -location {11926.048 15404.640} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh7N_estrip__clk -layer M9 -location {12205.472 15404.640} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh7N_estrip__clk_t3 -layer M9 -location {12467.040 15434.016} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh7N__clk -layer M9 -location {12502.560 15404.640} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh7N__clk_t1 -layer M9 -location {13071.840 15324.640} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh7N__clk_t2 -layer M9 -location {12724.000 16208.672} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0b1__clk -layer M9 -location {10515.360 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0o2__clk -layer M9 -location {11222.880 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0b1__clk -layer M9 -location {7006.560 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0o2__clk -layer M9 -location {6299.040 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1b2__clk -layer M9 -location {11223.840 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1o3__clk -layer M9 -location {11931.360 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1b2__clk -layer M9 -location {6298.080 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1o3__clk -layer M9 -location {5590.560 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2b3__clk -layer M9 -location {11932.320 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2o4__clk -layer M9 -location {12639.840 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2b3__clk -layer M9 -location {5589.600 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2o4__clk -layer M9 -location {4882.080 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh0S__clk_t2 -layer M9 -location {4797.920 1347.808} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh0S__clk_t1 -layer M9 -location {4450.080 2231.840} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh0S__clk -layer M9 -location {5019.360 2151.840} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh0S_estrip__clk_t3 -layer M9 -location {5054.880 2122.464} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh0S_estrip__clk -layer M9 -location {5316.448 2151.840} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh0S_estrip__clk_t2 -layer M9 -location {5595.872 2151.840} -pin_size {0.04 0.32}
place_pin -pin_name t_mesh0S_estrip__clk_t1 -layer M9 -location {5857.440 2164.448} -pin_size {0.04 0.32}
place_pin -pin_name t_lk_ES0__clk -layer M9 -location {13089.120 1252.832} -pin_size {0.04 0.32}
place_pin -pin_name t_sst9__clk_t4 -layer M9 -location {13107.360 2112.864} -pin_size {0.04 0.32}
place_pin -pin_name t_sst9__clk_t3 -layer M9 -location {13450.336 2231.840} -pin_size {0.04 0.32}
place_pin -pin_name t_sst9__clk -layer M9 -location {13810.528 2231.840} -pin_size {0.04 0.32}
place_pin -pin_name t_sst9__clk_t2 -layer M9 -location {14171.744 2231.840} -pin_size {0.04 0.32}
place_pin -pin_name t_sst9__clk_t1 -layer M9 -location {14514.720 2334.432} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5b2__clk -layer M9 -location {11223.840 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5o3__clk -layer M9 -location {11931.360 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5b2__clk -layer M9 -location {6298.080 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5o3__clk -layer M9 -location {5590.560 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4b3__clk -layer M9 -location {11932.320 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4o4__clk -layer M9 -location {12639.840 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4b3__clk -layer M9 -location {5589.600 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4o4__clk -layer M9 -location {4882.080 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3b4__clk -layer M9 -location {12640.800 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3o5__clk -layer M9 -location {13348.320 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3b4__clk -layer M9 -location {4881.120 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3o5__clk -layer M9 -location {4173.600 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_transit__clk_t1 -layer M9 -location {4450.080 15222.048} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_transit__clk_t2 -layer M9 -location {4793.056 15324.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_transit__clk -layer M9 -location {5154.272 15324.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_transit__clk_t3 -layer M9 -location {5514.464 15324.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_transit__clk_t4 -layer M9 -location {5857.440 15443.616} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_turn__clk_t1 -layer M9 -location {4717.920 15705.888} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_turn__clk_t2 -layer M9 -location {5018.976 15717.664} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_turn__clk_t13 -layer M9 -location {4695.328 16208.608} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_turn__clk_t11 -layer M9 -location {5024.672 16006.752} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_turn__clk_t8 -layer M9 -location {4695.328 15948.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_turn__clk_t5 -layer M9 -location {4862.368 15872.928} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_turn__clk -layer M9 -location {5284.896 15688.608} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_turn__clk_t4 -layer M9 -location {5353.568 15791.264} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_turn__clk_t6 -layer M9 -location {5176.288 15875.040} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_turn__clk_t10 -layer M9 -location {5303.776 16002.528} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_turn__clk_t9 -layer M9 -location {5857.440 15963.616} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_turn__clk_t3 -layer M9 -location {5597.920 15742.048} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_turn__clk_t7 -layer M9 -location {5543.776 15911.136} -pin_size {0.04 0.32}
place_pin -pin_name t_nst3_turn__clk_t12 -layer M9 -location {5595.232 16013.920} -pin_size {0.04 0.32}
place_pin -pin_name t_lk_EN0__clk -layer M9 -location {13089.120 16303.648} -pin_size {0.04 0.32}
place_pin -pin_name t_nst9__clk_t4 -layer M9 -location {13107.360 15443.616} -pin_size {0.04 0.32}
place_pin -pin_name t_nst9__clk_t3 -layer M9 -location {13450.336 15324.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst9__clk -layer M9 -location {13810.528 15324.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst9__clk_t2 -layer M9 -location {14171.744 15324.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst9__clk_t1 -layer M9 -location {14514.720 15222.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0b2__clk -layer M9 -location {11223.840 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0o3__clk -layer M9 -location {11931.360 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0b2__clk -layer M9 -location {6298.080 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0o3__clk -layer M9 -location {5590.560 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1b3__clk -layer M9 -location {11932.320 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1o4__clk -layer M9 -location {12639.840 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1b3__clk -layer M9 -location {5589.600 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1o4__clk -layer M9 -location {4882.080 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2b4__clk -layer M9 -location {12640.800 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2o5__clk -layer M9 -location {13348.320 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2b4__clk -layer M9 -location {4881.120 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2o5__clk -layer M9 -location {4173.600 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_lk_WS0__clk -layer M9 -location {4432.800 1252.832} -pin_size {0.04 0.32}
place_pin -pin_name t_sst2__clk_t2 -layer M9 -location {3350.176 2231.840} -pin_size {0.04 0.32}
place_pin -pin_name t_sst2__clk -layer M9 -location {3711.392 2231.840} -pin_size {0.04 0.32}
place_pin -pin_name t_sst2__clk_t1 -layer M9 -location {3007.200 2334.432} -pin_size {0.04 0.32}
place_pin -pin_name t_sst2__clk_t3 -layer M9 -location {4071.584 2231.840} -pin_size {0.04 0.32}
place_pin -pin_name t_sst2__clk_t4 -layer M9 -location {4414.560 2112.864} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk -layer M9 -location {15438.048 1875.616} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t14 -layer M9 -location {15496.352 1618.848} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t15 -layer M9 -location {15712.352 1347.872} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t13 -layer M9 -location {15717.984 1644.256} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t9 -layer M9 -location {15382.496 2095.584} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t11 -layer M9 -location {15540.832 1944.096} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t12 -layer M9 -location {15659.488 1924.064} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t10 -layer M9 -location {15762.848 1983.328} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t8 -layer M9 -location {14550.240 2112.864} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t7 -layer M9 -location {14820.832 2118.048} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t2 -layer M9 -location {14845.920 2339.808} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t6 -layer M9 -location {15106.528 2120.800} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t1 -layer M9 -location {15167.008 2342.432} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t3 -layer M9 -location {15477.600 2317.152} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t5 -layer M9 -location {15662.688 2223.904} -pin_size {0.04 0.32}
place_pin -pin_name t_sst10__clk_t4 -layer M9 -location {15765.472 2311.968} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5b3__clk -layer M9 -location {11932.320 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5o4__clk -layer M9 -location {12639.840 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5b3__clk -layer M9 -location {5589.600 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5o4__clk -layer M9 -location {4882.080 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4b4__clk -layer M9 -location {12640.800 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4o5__clk -layer M9 -location {13348.320 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4b4__clk -layer M9 -location {4881.120 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4o5__clk -layer M9 -location {4173.600 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3b5__clk -layer M9 -location {13349.280 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3o6__clk -layer M9 -location {14056.800 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3b5__clk -layer M9 -location {4172.640 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3o6__clk -layer M9 -location {3465.120 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_nst2__clk_t1 -layer M9 -location {3007.200 15222.048} -pin_size {0.04 0.32}
place_pin -pin_name t_nst2__clk_t2 -layer M9 -location {3350.176 15324.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst2__clk -layer M9 -location {3711.392 15324.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst2__clk_t3 -layer M9 -location {4071.584 15324.640} -pin_size {0.04 0.32}
place_pin -pin_name t_nst2__clk_t4 -layer M9 -location {4414.560 15443.616} -pin_size {0.04 0.32}
place_pin -pin_name t_lk_WN1__clk -layer M9 -location {4432.800 16303.648} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t15 -layer M9 -location {15712.352 16208.608} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t14 -layer M9 -location {15496.352 15937.632} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t13 -layer M9 -location {15717.984 15912.224} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t10 -layer M9 -location {15762.848 15573.152} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t11 -layer M9 -location {15540.832 15612.384} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t12 -layer M9 -location {15659.488 15632.416} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t9 -layer M9 -location {15382.496 15460.896} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk -layer M9 -location {15438.048 15680.864} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t3 -layer M9 -location {15477.600 15239.328} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t5 -layer M9 -location {15662.688 15332.576} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t4 -layer M9 -location {15765.472 15244.512} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t8 -layer M9 -location {14550.240 15443.616} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t7 -layer M9 -location {14820.832 15438.432} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t2 -layer M9 -location {14845.920 15216.672} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t6 -layer M9 -location {15106.528 15435.680} -pin_size {0.04 0.32}
place_pin -pin_name t_nst10__clk_t1 -layer M9 -location {15167.008 15214.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0b3__clk -layer M9 -location {11932.320 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0o4__clk -layer M9 -location {12639.840 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0b3__clk -layer M9 -location {5589.600 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0o4__clk -layer M9 -location {4882.080 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1b4__clk -layer M9 -location {12640.800 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1o5__clk -layer M9 -location {13348.320 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1b4__clk -layer M9 -location {4881.120 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1o5__clk -layer M9 -location {4173.600 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2b5__clk -layer M9 -location {13349.280 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2o6__clk -layer M9 -location {14056.800 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2b5__clk -layer M9 -location {4172.640 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2o6__clk -layer M9 -location {3465.120 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t13 -layer M9 -location {1803.936 1644.256} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t15 -layer M9 -location {1809.568 1347.872} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t14 -layer M9 -location {2025.568 1618.848} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk -layer M9 -location {2083.872 1875.616} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t10 -layer M9 -location {1759.072 1983.328} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t12 -layer M9 -location {1862.432 1924.064} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t11 -layer M9 -location {1981.088 1944.096} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t9 -layer M9 -location {2139.424 2095.584} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t4 -layer M9 -location {1756.448 2311.968} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t5 -layer M9 -location {1859.232 2223.904} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t3 -layer M9 -location {2044.320 2317.152} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t1 -layer M9 -location {2354.912 2342.432} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t6 -layer M9 -location {2415.392 2120.800} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t2 -layer M9 -location {2676.000 2339.808} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t7 -layer M9 -location {2701.088 2118.048} -pin_size {0.04 0.32}
place_pin -pin_name t_sst1__clk_t8 -layer M9 -location {2971.680 2112.864} -pin_size {0.04 0.32}
place_pin -pin_name t_lk_ES1__clk -layer M9 -location {15974.880 1252.832} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5b4__clk -layer M9 -location {12640.800 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5o5__clk -layer M9 -location {13348.320 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5b4__clk -layer M9 -location {4881.120 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5o5__clk -layer M9 -location {4173.600 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4b5__clk -layer M9 -location {13349.280 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4o6__clk -layer M9 -location {14056.800 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4b5__clk -layer M9 -location {4172.640 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4o6__clk -layer M9 -location {3465.120 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3b6__clk -layer M9 -location {14057.760 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3o7__clk -layer M9 -location {14765.280 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3b6__clk -layer M9 -location {3464.160 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3o7__clk -layer M9 -location {2756.640 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t4 -layer M9 -location {1756.448 15244.512} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t5 -layer M9 -location {1859.232 15332.576} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t3 -layer M9 -location {2044.320 15239.328} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t1 -layer M9 -location {2354.912 15214.048} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t6 -layer M9 -location {2415.392 15435.680} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t2 -layer M9 -location {2676.000 15216.672} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t7 -layer M9 -location {2701.088 15438.432} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t8 -layer M9 -location {2971.680 15443.616} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t10 -layer M9 -location {1759.072 15573.152} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t12 -layer M9 -location {1862.432 15632.416} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t11 -layer M9 -location {1981.088 15612.384} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t9 -layer M9 -location {2139.424 15460.896} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t13 -layer M9 -location {1803.936 15912.224} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t15 -layer M9 -location {1809.568 16208.608} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk_t14 -layer M9 -location {2025.568 15937.632} -pin_size {0.04 0.32}
place_pin -pin_name t_nst1__clk -layer M9 -location {2083.872 15680.864} -pin_size {0.04 0.32}
place_pin -pin_name t_lk_EN1__clk -layer M9 -location {15974.880 16303.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0b4__clk -layer M9 -location {12640.800 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0o5__clk -layer M9 -location {13348.320 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0b4__clk -layer M9 -location {4881.120 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0o5__clk -layer M9 -location {4173.600 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1b5__clk -layer M9 -location {13349.280 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1o6__clk -layer M9 -location {14056.800 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1b5__clk -layer M9 -location {4172.640 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1o6__clk -layer M9 -location {3465.120 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2b6__clk -layer M9 -location {14057.760 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2o7__clk -layer M9 -location {14765.280 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2b6__clk -layer M9 -location {3464.160 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2o7__clk -layer M9 -location {2756.640 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_lk_WS1__clk -layer M9 -location {1547.040 1252.832} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5b5__clk -layer M9 -location {13349.280 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5o6__clk -layer M9 -location {14056.800 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5b5__clk -layer M9 -location {4172.640 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5o6__clk -layer M9 -location {3465.120 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4b6__clk -layer M9 -location {14057.760 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4o7__clk -layer M9 -location {14765.280 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4b6__clk -layer M9 -location {3464.160 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4o7__clk -layer M9 -location {2756.640 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3b7__clk -layer M9 -location {14766.240 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3o8__clk -layer M9 -location {15473.760 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3b7__clk -layer M9 -location {2755.680 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3o8__clk -layer M9 -location {2048.160 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_lk_WN2__clk -layer M9 -location {1547.040 16303.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0b5__clk -layer M9 -location {13349.280 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0o6__clk -layer M9 -location {14056.800 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0b5__clk -layer M9 -location {4172.640 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0o6__clk -layer M9 -location {3465.120 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1b6__clk -layer M9 -location {14057.760 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1o7__clk -layer M9 -location {14765.280 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1b6__clk -layer M9 -location {3464.160 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1o7__clk -layer M9 -location {2756.640 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2b7__clk -layer M9 -location {14766.240 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2o8__clk -layer M9 -location {15473.760 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2b7__clk -layer M9 -location {2755.680 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2o8__clk -layer M9 -location {2048.160 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5b6__clk -layer M9 -location {14057.760 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5o7__clk -layer M9 -location {14765.280 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5b6__clk -layer M9 -location {3464.160 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5o7__clk -layer M9 -location {2756.640 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4b7__clk -layer M9 -location {14766.240 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4o8__clk -layer M9 -location {15473.760 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4b7__clk -layer M9 -location {2755.680 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4o8__clk -layer M9 -location {2048.160 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3b8__clk -layer M9 -location {15474.720 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3o9__clk -layer M9 -location {16182.240 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3b8__clk -layer M9 -location {2047.200 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3o9__clk -layer M9 -location {1339.680 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0b6__clk -layer M9 -location {14057.760 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0o7__clk -layer M9 -location {14765.280 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0b6__clk -layer M9 -location {3464.160 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0o7__clk -layer M9 -location {2756.640 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1b7__clk -layer M9 -location {14766.240 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1o8__clk -layer M9 -location {15473.760 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1b7__clk -layer M9 -location {2755.680 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1o8__clk -layer M9 -location {2048.160 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2b8__clk -layer M9 -location {15474.720 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2o9__clk -layer M9 -location {16182.240 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2b8__clk -layer M9 -location {2047.200 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2o9__clk -layer M9 -location {1339.680 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5b7__clk -layer M9 -location {14766.240 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5o8__clk -layer M9 -location {15473.760 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5b7__clk -layer M9 -location {2755.680 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5o8__clk -layer M9 -location {2048.160 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4b8__clk -layer M9 -location {15474.720 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4o9__clk -layer M9 -location {16182.240 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4b8__clk -layer M9 -location {2047.200 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4o9__clk -layer M9 -location {1339.680 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3b9__clk -layer M9 -location {16183.200 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3o10__clk -layer M9 -location {16890.720 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3b9__clk -layer M9 -location {1338.720 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3o10__clk -layer M9 -location {631.200 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0b7__clk -layer M9 -location {14766.240 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0o8__clk -layer M9 -location {15473.760 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0b7__clk -layer M9 -location {2755.680 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0o8__clk -layer M9 -location {2048.160 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1b8__clk -layer M9 -location {15474.720 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1o9__clk -layer M9 -location {16182.240 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1b8__clk -layer M9 -location {2047.200 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1o9__clk -layer M9 -location {1339.680 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2b9__clk -layer M9 -location {16183.200 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2o10__clk -layer M9 -location {16890.720 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2b9__clk -layer M9 -location {1338.720 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2o10__clk -layer M9 -location {631.200 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5b8__clk -layer M9 -location {15474.720 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5o9__clk -layer M9 -location {16182.240 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5b8__clk -layer M9 -location {2047.200 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5o9__clk -layer M9 -location {1339.680 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4b9__clk -layer M9 -location {16183.200 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4o10__clk -layer M9 -location {16890.720 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4b9__clk -layer M9 -location {1338.720 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4o10__clk -layer M9 -location {631.200 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE3b10__clk -layer M9 -location {16891.680 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE3a__clk_t1 -layer M9 -location {17332.320 8056.480} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE3a__clk_t2 -layer M9 -location {17263.200 8587.232} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE3a__clk -layer M9 -location {17325.088 8358.432} -pin_size {0.04 0.32}
place_pin -pin_name t_tW3b10__clk -layer M9 -location {630.240 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW3a__clk_t1 -layer M9 -location {189.600 8056.480} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW3a__clk -layer M9 -location {196.832 8358.432} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW3a__clk_t2 -layer M9 -location {258.720 8587.232} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0b8__clk -layer M9 -location {15474.720 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0o9__clk -layer M9 -location {16182.240 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0b8__clk -layer M9 -location {2047.200 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0o9__clk -layer M9 -location {1339.680 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1b9__clk -layer M9 -location {16183.200 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1o10__clk -layer M9 -location {16890.720 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1b9__clk -layer M9 -location {1338.720 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1o10__clk -layer M9 -location {631.200 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_tE2b10__clk -layer M9 -location {16891.680 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE2a__clk_t1 -layer M9 -location {17332.320 10130.080} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE2a__clk_t2 -layer M9 -location {17263.200 10660.832} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE2a__clk -layer M9 -location {17325.088 10432.032} -pin_size {0.04 0.32}
place_pin -pin_name t_tW2b10__clk -layer M9 -location {630.240 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW2a__clk_t1 -layer M9 -location {189.600 10130.080} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW2a__clk -layer M9 -location {196.832 10432.032} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW2a__clk_t2 -layer M9 -location {258.720 10660.832} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5b9__clk -layer M9 -location {16183.200 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5o10__clk -layer M9 -location {16890.720 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5b9__clk -layer M9 -location {1338.720 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5o10__clk -layer M9 -location {631.200 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE4b10__clk -layer M9 -location {16891.680 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE4a__clk_t1 -layer M9 -location {17332.320 5982.880} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE4a__clk_t2 -layer M9 -location {17263.200 6513.632} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE4a__clk -layer M9 -location {17325.088 6284.832} -pin_size {0.04 0.32}
place_pin -pin_name t_tW4b10__clk -layer M9 -location {630.240 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW4a__clk_t1 -layer M9 -location {189.600 5982.880} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW4a__clk -layer M9 -location {196.832 6284.832} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW4a__clk_t2 -layer M9 -location {258.720 6513.632} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE3b__clk -layer M9 -location {17332.320 7712.608} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW3b__clk -layer M9 -location {189.600 7712.608} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0b9__clk -layer M9 -location {16183.200 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0o10__clk -layer M9 -location {16890.720 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0b9__clk -layer M9 -location {1338.720 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0o10__clk -layer M9 -location {631.200 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_tE1b10__clk -layer M9 -location {16891.680 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE1a__clk_t1 -layer M9 -location {17332.320 12203.680} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE1a__clk_t2 -layer M9 -location {17263.200 12734.432} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE1a__clk -layer M9 -location {17325.088 12505.632} -pin_size {0.04 0.32}
place_pin -pin_name t_tW1b10__clk -layer M9 -location {630.240 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW1a__clk_t1 -layer M9 -location {189.600 12203.680} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW1a__clk -layer M9 -location {196.832 12505.632} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW1a__clk_t2 -layer M9 -location {258.720 12734.432} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE2b__clk -layer M9 -location {17332.320 9786.208} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW2b__clk -layer M9 -location {189.600 9786.208} -pin_size {0.04 0.32}
place_pin -pin_name t_tE5b10__clk -layer M9 -location {16891.680 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE5a__clk_t1 -layer M9 -location {17332.320 3909.280} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE5a__clk_t2 -layer M9 -location {17263.200 4440.032} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE5a__clk -layer M9 -location {17325.088 4211.232} -pin_size {0.04 0.32}
place_pin -pin_name t_tW5b10__clk -layer M9 -location {630.240 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW5a__clk_t1 -layer M9 -location {189.600 3909.280} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW5a__clk -layer M9 -location {196.832 4211.232} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW5a__clk_t2 -layer M9 -location {258.720 4440.032} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE4b__clk -layer M9 -location {17332.320 5639.008} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW4b__clk -layer M9 -location {189.600 5639.008} -pin_size {0.04 0.32}
place_pin -pin_name t_tE0b10__clk -layer M9 -location {16891.680 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE0a__clk_t1 -layer M9 -location {17332.320 14277.280} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE0a__clk_t2 -layer M9 -location {17263.200 14808.032} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE0a__clk -layer M9 -location {17325.088 14579.232} -pin_size {0.04 0.32}
place_pin -pin_name t_tW0b10__clk -layer M9 -location {630.240 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW0a__clk_t1 -layer M9 -location {189.600 14277.280} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW0a__clk -layer M9 -location {196.832 14579.232} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW0a__clk_t2 -layer M9 -location {258.720 14808.032} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE1b__clk -layer M9 -location {17332.320 11859.808} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW1b__clk -layer M9 -location {189.600 11859.808} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE5b__clk -layer M9 -location {17332.320 3565.408} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW5b__clk -layer M9 -location {189.600 3565.408} -pin_size {0.04 0.32}
place_pin -pin_name t_turnE0b__clk -layer M9 -location {17332.320 13933.408} -pin_size {0.04 0.32}
place_pin -pin_name t_turnW0b__clk -layer M9 -location {189.600 13933.408} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b0__clk -layer M9 -location {8763.120 7740.440} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r11_1__clk -layer M9 -location {8486.240 7740.440} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1_1__clk -layer M9 -location {8763.120 8036.800} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r4_1__clk -layer M9 -location {8763.120 7444.651} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r7_1__clk -layer M9 -location {9060.930 7740.940} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1303__clk -layer M9 -location {8993.986 7817.279} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r11_3__clk -layer M9 -location {8209.360 7740.440} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1_3__clk -layer M9 -location {8763.120 8333.160} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r4_3__clk -layer M9 -location {8763.120 7148.863} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b7__clk -layer M9 -location {9351.720 7741.440} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1304_1__clk -layer M9 -location {8993.986 8117.227} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r12_0__clk -layer M9 -location {8071.035 7870.290} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1337__clk -layer M9 -location {8986.928 7487.704} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1_5__clk -layer M9 -location {8763.120 8629.520} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r4_5__clk -layer M9 -location {8763.120 6853.074} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r8_1__clk -layer M9 -location {9397.188 7948.800} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1304__clk -layer M9 -location {8993.986 8417.176} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1338_1__clk -layer M9 -location {8743.120 7512.859} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r2_0__clk -layer M9 -location {8876.803 8779.240} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r5_0__clk -layer M9 -location {8876.803 6705.640} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1305_1__clk -layer M9 -location {8791.081 8508.572} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1342__clk -layer M9 -location {9028.184 7592.949} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1330_1__clk -layer M9 -location {9227.915 8433.864} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1338_3__clk -layer M9 -location {8499.312 7538.013} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r3_0__clk -layer M9 -location {8990.487 8924.527} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r6_0__clk -layer M9 -location {8990.487 6574.594} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r13_1__clk -layer M9 -location {7960.908 8118.840} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1305__clk -layer M9 -location {8588.176 8599.968} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r9_1__clk -layer M9 -location {9569.292 8118.840} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1344_0__clk -layer M9 -location {9265.787 7531.979} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r3_2__clk -layer M9 -location {8990.487 9216.021} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r6_2__clk -layer M9 -location {8990.487 6315.581} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1332__clk -layer M9 -location {9377.040 8599.968} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1306__clk -layer M9 -location {8422.352 8599.968} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1362_0__clk -layer M9 -location {8854.352 7715.728} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1362__clk -layer M9 -location {8854.352 7800.288} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1344__clk -layer M9 -location {9436.560 7563.168} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1340__clk -layer M9 -location {8421.328 7563.168} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r3_4__clk -layer M9 -location {8990.487 9507.514} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r6_4__clk -layer M9 -location {8990.487 6056.568} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b14__clk -layer M9 -location {7718.160 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r3_6__clk -layer M9 -location {8990.487 9799.008} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b6__clk -layer M9 -location {8990.487 5797.555} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b10__clk -layer M9 -location {9808.080 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b3__clk -layer M9 -location {8990.487 9944.755} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1449__clk -layer M9 -location {8985.346 5602.814} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b27__clk -layer M9 -location {8763.120 5797.555} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r35_1__clk -layer M9 -location {8728.194 5797.555} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b51__clk -layer M9 -location {7363.981 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r23_1__clk -layer M9 -location {8728.194 9944.755} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r31_2__clk -layer M9 -location {9337.956 5797.555} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b43__clk -layer M9 -location {10162.259 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1376__clk -layer M9 -location {9056.500 9683.584} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r16_0__clk -layer M9 -location {8763.120 10074.261} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r19_2__clk -layer M9 -location {9337.956 9944.755} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1489_1__clk -layer M9 -location {8988.226 5851.169} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r28_1__clk -layer M9 -location {8763.120 5506.061} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r35_3__clk -layer M9 -location {8465.900 5797.555} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b49__clk -layer M9 -location {7717.200 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r23_3__clk -layer M9 -location {8465.900 9944.755} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1450__clk -layer M9 -location {9149.371 5410.199} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r32_0__clk -layer M9 -location {9453.320 5927.117} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b41__clk -layer M9 -location {9809.040 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1444_1__clk -layer M9 -location {9011.624 9931.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r16_2__clk -layer M9 -location {8763.120 10333.274} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r20_0__clk -layer M9 -location {9453.320 10074.317} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1489_3__clk -layer M9 -location {8991.106 6099.523} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r28_3__clk -layer M9 -location {8763.120 5214.568} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r35_5__clk -layer M9 -location {8203.607 5797.555} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r50_1__clk -layer M9 -location {7717.200 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1378__clk -layer M9 -location {9141.080 9471.646} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r23_5__clk -layer M9 -location {8203.607 9944.755} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1451_1__clk -layer M9 -location {8893.980 5432.876} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r42_1__clk -layer M9 -location {9809.040 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1444_3__clk -layer M9 -location {8966.747 10178.576} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r16_4__clk -layer M9 -location {8763.120 10592.287} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1489__clk -layer M9 -location {8993.986 6347.878} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r28_5__clk -layer M9 -location {8763.120 4923.074} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r36_0__clk -layer M9 -location {8072.920 5927.117} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r50_3__clk -layer M9 -location {7717.200 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1379_1__clk -layer M9 -location {8919.686 9512.927} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r24_0__clk -layer M9 -location {8072.920 10074.317} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1451_3__clk -layer M9 -location {8638.590 5455.553} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1455__clk -layer M9 -location {9153.691 5471.439} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r33_1__clk -layer M9 -location {9569.292 6045.240} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r42_3__clk -layer M9 -location {9809.040 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1444_5__clk -layer M9 -location {8921.871 10426.072} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b16__clk -layer M9 -location {8763.120 10851.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r21_1__clk -layer M9 -location {9569.292 10192.440} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1490_1__clk -layer M9 -location {8791.081 6437.123} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b28__clk -layer M9 -location {8763.120 4631.580} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1664__clk -layer M9 -location {7717.200 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1379_3__clk -layer M9 -location {8698.292 9554.207} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1515_1__clk -layer M9 -location {9227.915 6361.698} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1662__clk -layer M9 -location {9809.040 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b54__clk -layer M9 -location {7009.680 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1383__clk -layer M9 -location {9032.323 9538.439} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1444__clk -layer M9 -location {8876.995 10673.568} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b17__clk -layer M9 -location {8990.487 10852.380} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1463_0__clk -layer M9 -location {8956.411 5556.522} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1490__clk -layer M9 -location {8588.176 6526.368} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b29__clk -layer M9 -location {8999.715 4630.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b46__clk -layer M9 -location {10516.560 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r37_2__clk -layer M9 -location {7832.592 6045.240} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1445__clk -layer M9 -location {8588.176 10673.568} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1448_1__clk -layer M9 -location {9127.017 10673.568} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r18_1__clk -layer M9 -location {8990.487 11143.874} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r25_2__clk -layer M9 -location {7832.592 10192.440} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1453__clk -layer M9 -location {8421.328 5489.568} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1463__clk -layer M9 -location {8854.352 5726.688} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1517__clk -layer M9 -location {9377.040 6526.368} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1491__clk -layer M9 -location {8422.352 6526.368} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r30_1__clk -layer M9 -location {8999.715 4376.966} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b34__clk -layer M9 -location {9808.080 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b123__clk -layer M9 -location {6655.501 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1385__clk -layer M9 -location {9342.480 9534.119} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1397_0__clk -layer M9 -location {8981.616 9789.774} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b22__clk -layer M9 -location {9808.080 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b115__clk -layer M9 -location {10870.739 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1446__clk -layer M9 -location {8422.352 10673.568} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1448__clk -layer M9 -location {9377.040 10673.568} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r18_3__clk -layer M9 -location {8990.487 11435.368} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r30_3__clk -layer M9 -location {8999.715 4123.431} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b121__clk -layer M9 -location {7008.720 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1381__clk -layer M9 -location {8421.328 9636.768} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1386__clk -layer M9 -location {9436.560 9636.768} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1398__clk -layer M9 -location {8854.352 9873.888} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b99__clk -layer M9 -location {10162.259 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b38__clk -layer M9 -location {7718.160 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b113__clk -layer M9 -location {10517.520 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r18_5__clk -layer M9 -location {8990.487 11726.861} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b71__clk -layer M9 -location {10162.259 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b26__clk -layer M9 -location {7718.160 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b30__clk -layer M9 -location {8999.715 3869.897} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r122_1__clk -layer M9 -location {7008.720 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b97__clk -layer M9 -location {9809.040 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r114_1__clk -layer M9 -location {10517.520 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b18__clk -layer M9 -location {8990.487 12018.355} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b69__clk -layer M9 -location {9809.040 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r84_0__clk -layer M9 -location {9108.720 3724.128} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1599_1__clk -layer M9 -location {9013.270 3606.010} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r91_1__clk -layer M9 -location {8734.785 3869.897} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b107__clk -layer M9 -location {7363.981 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r122_3__clk -layer M9 -location {7008.720 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1524__clk -layer M9 -location {9026.695 11987.588} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b79__clk -layer M9 -location {7363.981 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1599__clk -layer M9 -location {9020.048 3474.066} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r87_2__clk -layer M9 -location {9340.263 3869.897} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r98_1__clk -layer M9 -location {9809.040 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r114_3__clk -layer M9 -location {10517.520 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r63_1__clk -layer M9 -location {8728.194 12018.355} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r70_1__clk -layer M9 -location {9809.040 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r84_2__clk -layer M9 -location {9108.720 3432.591} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1600__clk -layer M9 -location {9046.724 3465.426} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r91_3__clk -layer M9 -location {8469.855 3869.897} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b105__clk -layer M9 -location {7717.200 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1776__clk -layer M9 -location {7008.720 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1525_1__clk -layer M9 -location {8958.073 11762.739} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1564_1__clk -layer M9 -location {9026.695 12237.901} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r56_0__clk -layer M9 -location {8763.120 12147.861} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r59_2__clk -layer M9 -location {9337.956 12018.355} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b77__clk -layer M9 -location {7717.200 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1657_1__clk -layer M9 -location {8933.674 3669.806} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r98_3__clk -layer M9 -location {9809.040 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1774__clk -layer M9 -location {10517.520 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b126__clk -layer M9 -location {6301.200 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r63_3__clk -layer M9 -location {8465.900 12018.355} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r70_3__clk -layer M9 -location {9809.040 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r84_4__clk -layer M9 -location {9108.720 3141.054} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1601_1__clk -layer M9 -location {8971.505 3286.129} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1636_1__clk -layer M9 -location {9047.958 3737.341} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r91_5__clk -layer M9 -location {8204.925 3869.897} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r106_1__clk -layer M9 -location {7717.200 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b118__clk -layer M9 -location {11225.040 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1525__clk -layer M9 -location {8889.451 11537.891} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1564_3__clk -layer M9 -location {9026.695 12488.215} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r56_2__clk -layer M9 -location {8763.120 12406.874} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r60_0__clk -layer M9 -location {9453.320 12147.917} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r78_1__clk -layer M9 -location {7717.200 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1601__clk -layer M9 -location {8933.896 3196.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1657_3__clk -layer M9 -location {8847.299 3865.547} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1770__clk -layer M9 -location {9809.040 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r63_5__clk -layer M9 -location {8203.607 12018.355} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1741__clk -layer M9 -location {9809.040 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r84_6__clk -layer M9 -location {9108.720 2849.517} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1636_3__clk -layer M9 -location {9049.193 4009.257} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r89_1__clk -layer M9 -location {9569.292 3971.640} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b102__clk -layer M9 -location {10516.560 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r106_3__clk -layer M9 -location {7717.200 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b227__clk -layer M9 -location {5947.021 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1526_1__clk -layer M9 -location {8678.135 11595.383} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r56_4__clk -layer M9 -location {8763.120 12665.887} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b74__clk -layer M9 -location {10516.560 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r78_3__clk -layer M9 -location {7717.200 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1602_1__clk -layer M9 -location {8707.765 3269.643} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1657_5__clk -layer M9 -location {8760.925 4061.287} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b219__clk -layer M9 -location {11579.219 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1530__clk -layer M9 -location {9032.504 11740.148} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1565__clk -layer M9 -location {9078.205 12738.528} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r64_0__clk -layer M9 -location {8072.920 12147.917} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b84__clk -layer M9 -location {9108.720 2557.980} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1636_5__clk -layer M9 -location {9050.427 4281.172} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1772__clk -layer M9 -location {7717.200 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b225__clk -layer M9 -location {6300.240 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1526_3__clk -layer M9 -location {8466.820 11652.876} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b56__clk -layer M9 -location {8763.120 12924.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r61_1__clk -layer M9 -location {9569.292 12266.040} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1743__clk -layer M9 -location {7717.200 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1607__clk -layer M9 -location {9020.231 3420.140} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1602_3__clk -layer M9 -location {8481.635 3342.805} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1657_7__clk -layer M9 -location {8674.550 4257.028} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r93_1__clk -layer M9 -location {7960.908 3971.640} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b203__clk -layer M9 -location {10870.739 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b110__clk -layer M9 -location {7009.680 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b217__clk -layer M9 -location {11226.000 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1566_1__clk -layer M9 -location {8833.191 12742.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b159__clk -layer M9 -location {10870.739 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b82__clk -layer M9 -location {7009.680 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r226_1__clk -layer M9 -location {6300.240 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1532_0__clk -layer M9 -location {9265.787 11679.179} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b57__clk -layer M9 -location {8990.487 12925.980} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r86_0__clk -layer M9 -location {9330.864 2426.200} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1638__clk -layer M9 -location {9220.366 4460.328} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1657__clk -layer M9 -location {8588.176 4452.768} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b90__clk -layer M9 -location {9808.080 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b201__clk -layer M9 -location {10517.520 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r218_1__clk -layer M9 -location {11226.000 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1550_0__clk -layer M9 -location {8854.352 11862.928} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b157__clk -layer M9 -location {10517.520 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1609_0__clk -layer M9 -location {9355.216 3402.099} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b211__clk -layer M9 -location {6655.501 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r226_3__clk -layer M9 -location {6300.240 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1550__clk -layer M9 -location {8854.352 11947.488} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1532__clk -layer M9 -location {9436.560 11710.368} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1528__clk -layer M9 -location {8421.328 11710.368} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1567_0__clk -layer M9 -location {8505.264 12747.168} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r58_1__clk -layer M9 -location {8990.487 13217.474} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r65_2__clk -layer M9 -location {7832.592 12266.040} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b167__clk -layer M9 -location {6655.501 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r86_2__clk -layer M9 -location {9330.864 2164.801} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1609__clk -layer M9 -location {9436.560 3415.968} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1604__clk -layer M9 -location {8421.328 3415.968} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1640__clk -layer M9 -location {9377.040 4452.768} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1658__clk -layer M9 -location {8422.352 4452.768} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r202_1__clk -layer M9 -location {10517.520 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r218_3__clk -layer M9 -location {11226.000 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1567__clk -layer M9 -location {8422.352 12747.168} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b62__clk -layer M9 -location {9808.080 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r158_1__clk -layer M9 -location {10517.520 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b86__clk -layer M9 -location {9330.864 2034.101} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b187__clk -layer M9 -location {10162.259 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b94__clk -layer M9 -location {7718.160 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b209__clk -layer M9 -location {7008.720 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1872__clk -layer M9 -location {6300.240 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r58_3__clk -layer M9 -location {8990.487 13508.967} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b165__clk -layer M9 -location {7008.720 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r202_3__clk -layer M9 -location {10517.520 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1870__clk -layer M9 -location {11226.000 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b230__clk -layer M9 -location {5592.720 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r158_3__clk -layer M9 -location {10517.520 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1745__clk -layer M9 -location {9409.968 1961.795} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r175_1__clk -layer M9 -location {9047.262 2034.101} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r179_1__clk -layer M9 -location {9622.396 2034.101} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b185__clk -layer M9 -location {9809.040 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r210_1__clk -layer M9 -location {7008.720 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b222__clk -layer M9 -location {11933.520 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r58_5__clk -layer M9 -location {8990.487 13800.461} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b143__clk -layer M9 -location {10162.259 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b66__clk -layer M9 -location {7718.160 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r166_1__clk -layer M9 -location {7008.720 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r172_0__clk -layer M9 -location {9484.560 1893.501} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b195__clk -layer M9 -location {7363.981 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1866__clk -layer M9 -location {10517.520 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1823__clk -layer M9 -location {10517.520 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b175__clk -layer M9 -location {8763.660 2034.101} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r179_3__clk -layer M9 -location {9913.928 2034.101} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r186_1__clk -layer M9 -location {9809.040 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b206__clk -layer M9 -location {11225.040 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r210_3__clk -layer M9 -location {7008.720 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b347__clk -layer M9 -location {5238.541 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b58__clk -layer M9 -location {8990.487 14091.955} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b141__clk -layer M9 -location {9809.040 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b162__clk -layer M9 -location {11225.040 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r166_3__clk -layer M9 -location {7008.720 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r172_2__clk -layer M9 -location {9484.560 1612.300} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b193__clk -layer M9 -location {7717.200 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b339__clk -layer M9 -location {12287.699 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b151__clk -layer M9 -location {7363.981 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b176__clk -layer M9 -location {8762.580 1766.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b179__clk -layer M9 -location {10205.460 2034.101} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r186_3__clk -layer M9 -location {9809.040 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1868__clk -layer M9 -location {7008.720 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b345__clk -layer M9 -location {5591.760 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r128_0__clk -layer M9 -location {9108.720 14221.461} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r135_1__clk -layer M9 -location {8728.194 14091.955} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1666__clk -layer M9 -location {8969.007 13952.934} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r142_1__clk -layer M9 -location {9809.040 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1825__clk -layer M9 -location {7008.720 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b172__clk -layer M9 -location {9484.560 1331.100} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r194_1__clk -layer M9 -location {7717.200 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b323__clk -layer M9 -location {11579.219 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b214__clk -layer M9 -location {6301.200 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b337__clk -layer M9 -location {11934.480 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r131_2__clk -layer M9 -location {9337.956 14091.955} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b149__clk -layer M9 -location {7717.200 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b279__clk -layer M9 -location {11579.219 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b170__clk -layer M9 -location {6301.200 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r177_1__clk -layer M9 -location {8474.900 1766.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r181_0__clk -layer M9 -location {10343.885 2138.400} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1862__clk -layer M9 -location {9809.040 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r346_1__clk -layer M9 -location {5591.760 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r128_2__clk -layer M9 -location {9108.720 14480.474} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r135_3__clk -layer M9 -location {8465.900 14091.955} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1734_1__clk -layer M9 -location {8942.718 14200.887} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r142_3__clk -layer M9 -location {9809.040 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r173_1__clk -layer M9 -location {9772.944 1331.560} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b190__clk -layer M9 -location {10516.560 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r194_3__clk -layer M9 -location {7717.200 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b321__clk -layer M9 -location {11226.000 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r338_1__clk -layer M9 -location {11934.480 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r132_0__clk -layer M9 -location {9453.320 14221.517} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r150_1__clk -layer M9 -location {7717.200 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b277__clk -layer M9 -location {11226.000 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r177_3__clk -layer M9 -location {8187.221 1766.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r181_2__clk -layer M9 -location {10618.574 2138.400} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b331__clk -layer M9 -location {5947.021 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r346_3__clk -layer M9 -location {5591.760 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r128_4__clk -layer M9 -location {9108.720 14739.487} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r135_5__clk -layer M9 -location {8203.607 14091.955} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1734_3__clk -layer M9 -location {8916.429 14448.839} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1819__clk -layer M9 -location {9809.040 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b287__clk -layer M9 -location {5947.021 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r173_3__clk -layer M9 -location {10061.328 1329.560} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1864__clk -layer M9 -location {7717.200 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r322_1__clk -layer M9 -location {11226.000 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r338_3__clk -layer M9 -location {11934.480 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1669__clk -layer M9 -location {8934.182 13792.608} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b146__clk -layer M9 -location {10516.560 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r150_3__clk -layer M9 -location {7717.200 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r278_1__clk -layer M9 -location {11226.000 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b178__clk -layer M9 -location {8043.381 1832.187} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b307__clk -layer M9 -location {10870.739 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b198__clk -layer M9 -location {7009.680 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b329__clk -layer M9 -location {6300.240 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1934__clk -layer M9 -location {5591.760 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r136_0__clk -layer M9 -location {8072.920 14221.517} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1734_5__clk -layer M9 -location {8890.140 14696.792} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b285__clk -layer M9 -location {6300.240 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b182__clk -layer M9 -location {10893.264 2141.141} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r322_3__clk -layer M9 -location {11226.000 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1932__clk -layer M9 -location {11934.480 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b350__clk -layer M9 -location {4884.240 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r129_0__clk -layer M9 -location {9208.163 15000.040} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r133_1__clk -layer M9 -location {9569.292 14339.640} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1670_1__clk -layer M9 -location {8662.711 13789.152} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1673__clk -layer M9 -location {9007.440 13912.090} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1734__clk -layer M9 -location {8876.995 14820.768} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1821__clk -layer M9 -location {7717.200 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r278_3__clk -layer M9 -location {11226.000 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1827__clk -layer M9 -location {10205.520 1252.832} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r295_1__clk -layer M9 -location {7754.341 1832.187} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b305__clk -layer M9 -location {10517.520 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r330_1__clk -layer M9 -location {6300.240 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b342__clk -layer M9 -location {12642.000 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b263__clk -layer M9 -location {10870.739 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b154__clk -layer M9 -location {7009.680 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r286_1__clk -layer M9 -location {6300.240 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r292_1__clk -layer M9 -location {8041.680 1581.644} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r299_1__clk -layer M9 -location {11144.956 2141.141} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b315__clk -layer M9 -location {6655.501 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1928__clk -layer M9 -location {11226.000 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r130_0__clk -layer M9 -location {9307.606 15137.859} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1674_1__clk -layer M9 -location {9230.800 13929.613} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1735__clk -layer M9 -location {8588.176 14820.768} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1738_1__clk -layer M9 -location {9127.017 14820.768} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1895__clk -layer M9 -location {11226.000 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r295_3__clk -layer M9 -location {7465.300 1832.187} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r306_1__clk -layer M9 -location {10517.520 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b326__clk -layer M9 -location {11933.520 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r330_3__clk -layer M9 -location {6300.240 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b467__clk -layer M9 -location {4530.061 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b261__clk -layer M9 -location {10517.520 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b282__clk -layer M9 -location {11933.520 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r286_3__clk -layer M9 -location {6300.240 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b292__clk -layer M9 -location {8041.680 1331.101} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r299_3__clk -layer M9 -location {11396.648 2141.141} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b313__clk -layer M9 -location {7008.720 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b459__clk -layer M9 -location {12996.179 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r130_2__clk -layer M9 -location {9307.606 15414.415} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r137_2__clk -layer M9 -location {7832.592 14339.640} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1736__clk -layer M9 -location {8422.352 14820.768} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1738__clk -layer M9 -location {9377.040 14820.768} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b271__clk -layer M9 -location {6655.501 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r306_3__clk -layer M9 -location {10517.520 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1930__clk -layer M9 -location {6300.240 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b465__clk -layer M9 -location {4883.280 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b130__clk -layer M9 -location {9307.606 15552.694} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b134__clk -layer M9 -location {9808.080 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1672__clk -layer M9 -location {8421.328 13783.968} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1675__clk -layer M9 -location {9436.560 13783.968} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r262_1__clk -layer M9 -location {10517.520 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1897__clk -layer M9 -location {6300.240 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r293_1__clk -layer M9 -location {7753.296 1331.560} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r296_1__clk -layer M9 -location {7319.240 2036.329} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r314_1__clk -layer M9 -location {7008.720 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b443__clk -layer M9 -location {12287.699 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b334__clk -layer M9 -location {5592.720 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b457__clk -layer M9 -location {12642.960 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b269__clk -layer M9 -location {7008.720 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b399__clk -layer M9 -location {12287.699 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b290__clk -layer M9 -location {5592.720 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b300__clk -layer M9 -location {11649.420 2138.400} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1924__clk -layer M9 -location {10517.520 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r466_1__clk -layer M9 -location {4883.280 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r231_1__clk -layer M9 -location {9035.633 15552.694} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r239_1__clk -layer M9 -location {9606.891 15552.694} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r262_3__clk -layer M9 -location {10517.520 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r293_3__clk -layer M9 -location {7464.912 1329.560} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r297_0__clk -layer M9 -location {7182.355 2138.400} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b310__clk -layer M9 -location {11225.040 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r314_3__clk -layer M9 -location {7008.720 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b441__clk -layer M9 -location {11934.480 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r458_1__clk -layer M9 -location {12642.960 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1778__clk -layer M9 -location {9481.796 15691.023} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r236_0__clk -layer M9 -location {9484.560 15687.231} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b247__clk -layer M9 -location {10162.259 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b138__clk -layer M9 -location {7718.160 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r270_1__clk -layer M9 -location {7008.720 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b397__clk -layer M9 -location {11934.480 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r301_1__clk -layer M9 -location {11936.884 2138.400} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b451__clk -layer M9 -location {5238.541 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r466_3__clk -layer M9 -location {4883.280 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r239_3__clk -layer M9 -location {9906.175 15552.694} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1891__clk -layer M9 -location {10517.520 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b407__clk -layer M9 -location {5238.541 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r297_2__clk -layer M9 -location {6907.666 2138.400} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1926__clk -layer M9 -location {7008.720 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r442_1__clk -layer M9 -location {11934.480 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r458_3__clk -layer M9 -location {12642.960 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1779_1__clk -layer M9 -location {9481.796 15401.144} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b232__clk -layer M9 -location {8762.580 15612.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r236_2__clk -layer M9 -location {9484.560 15956.306} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b245__clk -layer M9 -location {9809.040 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b266__clk -layer M9 -location {11225.040 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r270_3__clk -layer M9 -location {7008.720 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r398_1__clk -layer M9 -location {11934.480 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1899__clk -layer M9 -location {7320.720 1252.832} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r301_3__clk -layer M9 -location {12224.348 2138.400} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b427__clk -layer M9 -location {11579.219 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b318__clk -layer M9 -location {6301.200 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b449__clk -layer M9 -location {5591.760 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2018__clk -layer M9 -location {4883.280 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1779__clk -layer M9 -location {9481.796 15256.204} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b239__clk -layer M9 -location {10205.460 15552.694} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b255__clk -layer M9 -location {7363.981 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b405__clk -layer M9 -location {5591.760 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r442_3__clk -layer M9 -location {11934.480 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2016__clk -layer M9 -location {12642.960 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b470__clk -layer M9 -location {4175.760 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r233_1__clk -layer M9 -location {8475.756 15612.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b236__clk -layer M9 -location {9484.560 16225.110} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r246_1__clk -layer M9 -location {9809.040 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1893__clk -layer M9 -location {7008.720 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r398_3__clk -layer M9 -location {11934.480 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b298__clk -layer M9 -location {6632.976 2141.141} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b302__clk -layer M9 -location {12361.060 2046.011} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b425__clk -layer M9 -location {11226.000 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r450_1__clk -layer M9 -location {5591.760 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b462__clk -layer M9 -location {13350.480 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r241_0__clk -layer M9 -location {10343.885 15418.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b253__clk -layer M9 -location {7717.200 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b383__clk -layer M9 -location {11579.219 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b274__clk -layer M9 -location {6301.200 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r406_1__clk -layer M9 -location {5591.760 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b435__clk -layer M9 -location {5947.021 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2012__clk -layer M9 -location {11934.480 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1781_0__clk -layer M9 -location {9122.718 15256.204} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r233_3__clk -layer M9 -location {8188.932 15612.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r237_1__clk -layer M9 -location {9772.944 16224.920} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r246_3__clk -layer M9 -location {9809.040 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1981__clk -layer M9 -location {11934.480 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r411_1__clk -layer M9 -location {6381.284 2141.141} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1911_1__clk -layer M9 -location {12569.397 2113.449} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r419_1__clk -layer M9 -location {12657.336 2046.011} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r426_1__clk -layer M9 -location {11226.000 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b446__clk -layer M9 -location {12642.000 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r450_3__clk -layer M9 -location {5591.760 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b591__clk -layer M9 -location {3821.581 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r241_2__clk -layer M9 -location {10618.574 15418.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r254_1__clk -layer M9 -location {7717.200 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b381__clk -layer M9 -location {11226.000 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b402__clk -layer M9 -location {12642.000 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r406_3__clk -layer M9 -location {5591.760 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r416_1__clk -layer M9 -location {12370.320 1760.047} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1911__clk -layer M9 -location {12670.056 2147.168} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b433__clk -layer M9 -location {6300.240 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b583__clk -layer M9 -location {13704.659 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b234__clk -layer M9 -location {8045.520 15612.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r237_3__clk -layer M9 -location {10061.328 16226.920} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1887__clk -layer M9 -location {9809.040 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b391__clk -layer M9 -location {5947.021 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r411_3__clk -layer M9 -location {6129.592 2141.141} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r419_3__clk -layer M9 -location {12964.920 2046.011} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r426_3__clk -layer M9 -location {11226.000 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2014__clk -layer M9 -location {5591.760 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b589__clk -layer M9 -location {4174.800 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1781__clk -layer M9 -location {8780.880 15256.204} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1804_0__clk -layer M9 -location {9652.099 15644.256} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b250__clk -layer M9 -location {10516.560 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r254_3__clk -layer M9 -location {7717.200 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r382_1__clk -layer M9 -location {11226.000 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1983__clk -layer M9 -location {5591.760 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r416_3__clk -layer M9 -location {12370.320 1474.082} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r434_1__clk -layer M9 -location {6300.240 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b567__clk -layer M9 -location {12996.179 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b454__clk -layer M9 -location {4884.240 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b581__clk -layer M9 -location {13351.440 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r355_1__clk -layer M9 -location {7755.624 15612.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b242__clk -layer M9 -location {10893.264 15415.339} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b389__clk -layer M9 -location {6300.240 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b523__clk -layer M9 -location {12996.179 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b410__clk -layer M9 -location {4884.240 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2008__clk -layer M9 -location {11226.000 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r590_1__clk -layer M9 -location {4174.800 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1784__clk -layer M9 -location {8780.880 15300.896} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1804__clk -layer M9 -location {9426.512 15644.256} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r352_1__clk -layer M9 -location {7926.918 15779.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1875__clk -layer M9 -location {10205.520 16303.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1889__clk -layer M9 -location {7717.200 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r382_3__clk -layer M9 -location {11226.000 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b412__clk -layer M9 -location {5876.820 2138.400} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r417_0__clk -layer M9 -location {12514.512 1331.560} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b420__clk -layer M9 -location {13092.300 2224.800} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b430__clk -layer M9 -location {11933.520 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r434_3__clk -layer M9 -location {6300.240 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b565__clk -layer M9 -location {12642.960 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r582_1__clk -layer M9 -location {13351.440 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r355_3__clk -layer M9 -location {7465.728 15612.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r359_1__clk -layer M9 -location {11144.956 15415.339} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b367__clk -layer M9 -location {10870.739 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b258__clk -layer M9 -location {7009.680 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r390_1__clk -layer M9 -location {6300.240 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b521__clk -layer M9 -location {12642.960 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b575__clk -layer M9 -location {4530.061 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r590_3__clk -layer M9 -location {4174.800 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r352_3__clk -layer M9 -location {7850.460 15991.373} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1977__clk -layer M9 -location {11226.000 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b531__clk -layer M9 -location {4530.061 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r413_1__clk -layer M9 -location {5589.356 2138.400} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r417_2__clk -layer M9 -location {12802.896 1329.560} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1916__clk -layer M9 -location {12344.464 2143.200} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r421_1__clk -layer M9 -location {13380.619 2224.800} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2010__clk -layer M9 -location {6300.240 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r566_1__clk -layer M9 -location {12642.960 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r582_3__clk -layer M9 -location {13351.440 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r359_3__clk -layer M9 -location {11396.648 15415.339} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b365__clk -layer M9 -location {10517.520 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b386__clk -layer M9 -location {11933.520 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r390_3__clk -layer M9 -location {6300.240 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r522_1__clk -layer M9 -location {12642.960 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1917__clk -layer M9 -location {12207.632 2151.840} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b551__clk -layer M9 -location {12287.699 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b438__clk -layer M9 -location {5592.720 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b573__clk -layer M9 -location {4883.280 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2129__clk -layer M9 -location {4174.800 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r357_0__clk -layer M9 -location {7175.537 15590.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b375__clk -layer M9 -location {6655.501 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b529__clk -layer M9 -location {4883.280 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r413_3__clk -layer M9 -location {5301.892 2138.400} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b417__clk -layer M9 -location {13091.280 1329.746} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r421_3__clk -layer M9 -location {13668.938 2224.800} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r566_3__clk -layer M9 -location {12642.960 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2127__clk -layer M9 -location {13351.440 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b594__clk -layer M9 -location {3467.280 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r366_1__clk -layer M9 -location {10517.520 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1979__clk -layer M9 -location {6300.240 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r522_3__clk -layer M9 -location {12642.960 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b549__clk -layer M9 -location {11934.480 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r574_1__clk -layer M9 -location {4883.280 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b586__clk -layer M9 -location {14058.960 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r357_2__clk -layer M9 -location {6887.211 15590.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b360__clk -layer M9 -location {11649.420 15418.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b373__clk -layer M9 -location {7008.720 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b507__clk -layer M9 -location {12287.699 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b394__clk -layer M9 -location {5592.720 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r530_1__clk -layer M9 -location {4883.280 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b414__clk -layer M9 -location {5158.160 2046.011} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1998__clk -layer M9 -location {13091.280 1252.832} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b422__clk -layer M9 -location {13813.098 2228.563} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b559__clk -layer M9 -location {5238.541 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2123__clk -layer M9 -location {12642.960 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r353_1__clk -layer M9 -location {7753.296 16224.920} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r366_3__clk -layer M9 -location {10517.520 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2074__clk -layer M9 -location {12642.960 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r550_1__clk -layer M9 -location {11934.480 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b570__clk -layer M9 -location {13350.480 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r574_3__clk -layer M9 -location {4883.280 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b707__clk -layer M9 -location {3113.101 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r361_1__clk -layer M9 -location {11936.884 15418.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r374_1__clk -layer M9 -location {7008.720 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b505__clk -layer M9 -location {11934.480 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b526__clk -layer M9 -location {13350.480 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r530_3__clk -layer M9 -location {4883.280 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r539_1__clk -layer M9 -location {4868.904 2046.011} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r543_1__clk -layer M9 -location {14101.499 2228.563} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b557__clk -layer M9 -location {5591.760 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b699__clk -layer M9 -location {14413.139 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r353_3__clk -layer M9 -location {7464.912 16226.920} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b358__clk -layer M9 -location {6598.885 15558.107} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1973__clk -layer M9 -location {10517.520 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b515__clk -layer M9 -location {5238.541 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r536_1__clk -layer M9 -location {5155.920 1760.047} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r550_3__clk -layer M9 -location {11934.480 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2125__clk -layer M9 -location {4883.280 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b705__clk -layer M9 -location {3466.320 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r361_3__clk -layer M9 -location {12224.348 15418.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b370__clk -layer M9 -location {11225.040 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r374_3__clk -layer M9 -location {7008.720 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r506_1__clk -layer M9 -location {11934.480 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2076__clk -layer M9 -location {4883.280 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r539_3__clk -layer M9 -location {4554.300 2046.011} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r543_3__clk -layer M9 -location {14389.900 2228.563} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r558_1__clk -layer M9 -location {5591.760 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b683__clk -layer M9 -location {13704.659 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b578__clk -layer M9 -location {4175.760 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b697__clk -layer M9 -location {14059.920 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r471_1__clk -layer M9 -location {6310.491 15558.107} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r475_1__clk -layer M9 -location {6303.471 15558.107} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b513__clk -layer M9 -location {5591.760 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b643__clk -layer M9 -location {13704.659 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b534__clk -layer M9 -location {4175.760 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r536_3__clk -layer M9 -location {5155.920 1474.082} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2119__clk -layer M9 -location {11934.480 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r706_1__clk -layer M9 -location {3466.320 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1936__clk -layer M9 -location {7320.720 16303.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b362__clk -layer M9 -location {12361.060 15510.469} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1975__clk -layer M9 -location {7008.720 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r506_3__clk -layer M9 -location {11934.480 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b554__clk -layer M9 -location {12642.000 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r558_3__clk -layer M9 -location {5591.760 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b681__clk -layer M9 -location {13351.440 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r698_1__clk -layer M9 -location {14059.920 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r471_3__clk -layer M9 -location {6022.097 15558.107} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r475_3__clk -layer M9 -location {6015.077 15558.107} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b491__clk -layer M9 -location {11579.219 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b378__clk -layer M9 -location {6301.200 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r514_1__clk -layer M9 -location {5591.760 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b641__clk -layer M9 -location {13351.440 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r537_0__clk -layer M9 -location {5011.728 1331.560} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b540__clk -layer M9 -location {4433.940 2224.800} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r545_0__clk -layer M9 -location {14676.621 2224.800} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b691__clk -layer M9 -location {3821.581 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r706_3__clk -layer M9 -location {3466.320 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1960_1__clk -layer M9 -location {12526.517 15428.631} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r483_1__clk -layer M9 -location {12657.336 15510.469} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2070__clk -layer M9 -location {11934.480 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b651__clk -layer M9 -location {3821.581 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2121__clk -layer M9 -location {5591.760 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r682_1__clk -layer M9 -location {13351.440 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r698_3__clk -layer M9 -location {14059.920 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r472_0__clk -layer M9 -location {5878.360 15444.894} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r476_0__clk -layer M9 -location {5876.360 15706.253} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r480_1__clk -layer M9 -location {12370.320 15796.433} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1960__clk -layer M9 -location {12605.736 15387.712} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b489__clk -layer M9 -location {11226.000 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b510__clk -layer M9 -location {12642.000 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r514_3__clk -layer M9 -location {5591.760 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r642_1__clk -layer M9 -location {13351.440 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r537_2__clk -layer M9 -location {4723.344 1329.560} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r541_1__clk -layer M9 -location {4145.621 2224.800} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r545_2__clk -layer M9 -location {14959.504 2224.800} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b667__clk -layer M9 -location {12996.179 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b562__clk -layer M9 -location {4884.240 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b689__clk -layer M9 -location {4174.800 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2226__clk -layer M9 -location {3466.320 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r483_3__clk -layer M9 -location {12964.920 15510.469} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b499__clk -layer M9 -location {5947.021 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b649__clk -layer M9 -location {4174.800 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r682_3__clk -layer M9 -location {13351.440 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2224__clk -layer M9 -location {14059.920 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b710__clk -layer M9 -location {2758.800 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1957_0__clk -layer M9 -location {6794.544 15647.332} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r473_0__clk -layer M9 -location {5732.660 15331.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r477_0__clk -layer M9 -location {5740.852 15854.400} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r480_3__clk -layer M9 -location {12370.320 16082.398} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r490_1__clk -layer M9 -location {11226.000 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2072__clk -layer M9 -location {5591.760 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r642_3__clk -layer M9 -location {13351.440 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b537__clk -layer M9 -location {4434.960 1329.746} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r541_3__clk -layer M9 -location {3857.302 2224.800} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r545_4__clk -layer M9 -location {15242.387 2224.800} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b665__clk -layer M9 -location {12642.960 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r690_1__clk -layer M9 -location {4174.800 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b702__clk -layer M9 -location {14767.440 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b497__clk -layer M9 -location {6300.240 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b627__clk -layer M9 -location {12996.179 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b518__clk -layer M9 -location {4884.240 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r650_1__clk -layer M9 -location {4174.800 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b675__clk -layer M9 -location {4530.061 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2220__clk -layer M9 -location {13351.440 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r473_2__clk -layer M9 -location {5444.341 15331.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r477_2__clk -layer M9 -location {5468.917 15854.400} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r481_0__clk -layer M9 -location {12514.512 16224.920} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b484__clk -layer M9 -location {13092.300 15331.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r490_3__clk -layer M9 -location {11226.000 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2180__clk -layer M9 -location {13351.440 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2078__clk -layer M9 -location {4434.960 1252.832} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b542__clk -layer M9 -location {3713.142 2228.563} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r666_1__clk -layer M9 -location {12642.960 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b686__clk -layer M9 -location {14058.960 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r690_3__clk -layer M9 -location {4174.800 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b815__clk -layer M9 -location {2404.621 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1958_0__clk -layer M9 -location {6698.368 15844.640} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r498_1__clk -layer M9 -location {6300.240 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b625__clk -layer M9 -location {12642.960 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b646__clk -layer M9 -location {14058.960 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r650_3__clk -layer M9 -location {4174.800 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b546__clk -layer M9 -location {15383.828 2020.040} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b673__clk -layer M9 -location {4883.280 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b807__clk -layer M9 -location {15121.619 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1958__clk -layer M9 -location {6599.312 15844.640} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r481_2__clk -layer M9 -location {12802.896 16226.920} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1965__clk -layer M9 -location {12353.104 15404.640} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r485_1__clk -layer M9 -location {13380.619 15331.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2066__clk -layer M9 -location {11226.000 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b635__clk -layer M9 -location {4530.061 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r655_1__clk -layer M9 -location {3424.741 2228.563} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r666_3__clk -layer M9 -location {12642.960 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2222__clk -layer M9 -location {4174.800 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b813__clk -layer M9 -location {2757.840 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b474__clk -layer M9 -location {5156.022 15327.917} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b478__clk -layer M9 -location {5196.981 15889.189} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1966__clk -layer M9 -location {12207.632 15404.640} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b494__clk -layer M9 -location {11933.520 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r498_3__clk -layer M9 -location {6300.240 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r626_1__clk -layer M9 -location {12642.960 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2182__clk -layer M9 -location {4174.800 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r674_1__clk -layer M9 -location {4883.280 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b791__clk -layer M9 -location {14413.139 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b694__clk -layer M9 -location {3467.280 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b805__clk -layer M9 -location {14768.400 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b481__clk -layer M9 -location {13091.280 16226.464} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r485_3__clk -layer M9 -location {13668.938 15331.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b633__clk -layer M9 -location {4883.280 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b755__clk -layer M9 -location {14413.139 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b654__clk -layer M9 -location {3467.280 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r655_3__clk -layer M9 -location {3136.340 2228.563} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r660_0__clk -layer M9 -location {15186.960 1882.252} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2216__clk -layer M9 -location {12642.960 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r814_1__clk -layer M9 -location {2757.840 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r595_1__clk -layer M9 -location {4867.621 15327.917} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2068__clk -layer M9 -location {6300.240 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r626_3__clk -layer M9 -location {12642.960 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b670__clk -layer M9 -location {13350.480 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r674_3__clk -layer M9 -location {4883.280 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b789__clk -layer M9 -location {14059.920 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r806_1__clk -layer M9 -location {14768.400 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r600_1__clk -layer M9 -location {5225.040 16113.316} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2056__clk -layer M9 -location {13091.280 16303.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b486__clk -layer M9 -location {13813.098 15327.917} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b611__clk -layer M9 -location {12287.699 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b502__clk -layer M9 -location {5592.720 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r634_1__clk -layer M9 -location {4883.280 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b753__clk -layer M9 -location {14059.920 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r660_2__clk -layer M9 -location {15186.960 1606.676} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b799__clk -layer M9 -location {3113.101 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r814_3__clk -layer M9 -location {2757.840 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r595_3__clk -layer M9 -location {4579.220 15327.917} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2176__clk -layer M9 -location {12642.960 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b763__clk -layer M9 -location {3113.101 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r657_0__clk -layer M9 -location {2849.619 2224.800} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r2089_3__clk -layer M9 -location {15574.385 1870.316} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2218__clk -layer M9 -location {4883.280 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r790_1__clk -layer M9 -location {14059.920 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r806_3__clk -layer M9 -location {14768.400 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r601_0__clk -layer M9 -location {5093.360 16224.920} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r603_1__clk -layer M9 -location {14101.499 15327.917} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b609__clk -layer M9 -location {11934.480 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b630__clk -layer M9 -location {13350.480 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r634_3__clk -layer M9 -location {4883.280 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r754_1__clk -layer M9 -location {14059.920 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b660__clk -layer M9 -location {15186.960 1331.100} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b775__clk -layer M9 -location {13704.659 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b678__clk -layer M9 -location {4175.760 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b797__clk -layer M9 -location {3466.320 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2283__clk -layer M9 -location {2757.840 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b619__clk -layer M9 -location {5238.541 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b761__clk -layer M9 -location {3466.320 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r657_2__clk -layer M9 -location {2566.736 2224.800} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r790_3__clk -layer M9 -location {14059.920 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2281__clk -layer M9 -location {14768.400 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b818__clk -layer M9 -location {2050.320 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r597_0__clk -layer M9 -location {4289.780 15331.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r601_2__clk -layer M9 -location {4830.000 16226.920} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r603_3__clk -layer M9 -location {14389.900 15327.917} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r610_1__clk -layer M9 -location {11934.480 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2178__clk -layer M9 -location {4883.280 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r754_3__clk -layer M9 -location {14059.920 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r661_1__clk -layer M9 -location {15450.320 1331.560} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b773__clk -layer M9 -location {13351.440 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r798_1__clk -layer M9 -location {3466.320 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b810__clk -layer M9 -location {15475.920 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b617__clk -layer M9 -location {5591.760 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b739__clk -layer M9 -location {13704.659 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b638__clk -layer M9 -location {4175.760 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r762_1__clk -layer M9 -location {3466.320 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r657_4__clk -layer M9 -location {2283.853 2224.800} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b783__clk -layer M9 -location {3821.581 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2277__clk -layer M9 -location {14059.920 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r597_2__clk -layer M9 -location {4001.461 15331.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r601_4__clk -layer M9 -location {4566.640 16226.920} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r610_3__clk -layer M9 -location {11934.480 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2268__clk -layer M9 -location {14059.920 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r661_3__clk -layer M9 -location {15713.680 1329.560} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r774_1__clk -layer M9 -location {13351.440 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b794__clk -layer M9 -location {14767.440 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r798_3__clk -layer M9 -location {3466.320 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b915__clk -layer M9 -location {1696.141 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r605_0__clk -layer M9 -location {14676.621 15331.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r618_1__clk -layer M9 -location {5591.760 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b737__clk -layer M9 -location {13351.440 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b758__clk -layer M9 -location {14767.440 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r762_3__clk -layer M9 -location {3466.320 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2092__clk -layer M9 -location {15440.208 1875.616} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b781__clk -layer M9 -location {4174.800 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b907__clk -layer M9 -location {15830.099 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2172__clk -layer M9 -location {11934.480 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b747__clk -layer M9 -location {3821.581 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b658__clk -layer M9 -location {2142.412 2020.040} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r774_3__clk -layer M9 -location {13351.440 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2279__clk -layer M9 -location {3466.320 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b913__clk -layer M9 -location {2049.360 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b598__clk -layer M9 -location {3713.142 15327.917} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2140__clk -layer M9 -location {4434.960 16303.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r605_2__clk -layer M9 -location {14959.504 15331.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b614__clk -layer M9 -location {12642.000 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r618_3__clk -layer M9 -location {5591.760 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r738_1__clk -layer M9 -location {13351.440 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2270__clk -layer M9 -location {3466.320 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r782_1__clk -layer M9 -location {4174.800 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b891__clk -layer M9 -location {15121.619 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b802__clk -layer M9 -location {2758.800 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b905__clk -layer M9 -location {15476.880 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b745__clk -layer M9 -location {4174.800 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b859__clk -layer M9 -location {15121.619 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b766__clk -layer M9 -location {2758.800 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2215__clk -layer M9 -location {15977.040 1252.832} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2273__clk -layer M9 -location {13351.440 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r914_1__clk -layer M9 -location {2049.360 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r711_1__clk -layer M9 -location {3424.741 15327.917} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r605_4__clk -layer M9 -location {15242.387 15331.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2174__clk -layer M9 -location {5591.760 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r738_3__clk -layer M9 -location {13351.440 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r768_0__clk -layer M9 -location {2339.280 1882.252} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b778__clk -layer M9 -location {14058.960 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r782_3__clk -layer M9 -location {4174.800 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b889__clk -layer M9 -location {14768.400 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r906_1__clk -layer M9 -location {15476.880 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b723__clk -layer M9 -location {12996.179 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b622__clk -layer M9 -location {4884.240 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r746_1__clk -layer M9 -location {4174.800 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b857__clk -layer M9 -location {14768.400 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b899__clk -layer M9 -location {2404.621 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r914_3__clk -layer M9 -location {2049.360 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r711_3__clk -layer M9 -location {3136.340 15327.917} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2264__clk -layer M9 -location {13351.440 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b867__clk -layer M9 -location {2404.621 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r768_2__clk -layer M9 -location {2339.280 1606.676} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2275__clk -layer M9 -location {4174.800 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r890_1__clk -layer M9 -location {14768.400 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r906_3__clk -layer M9 -location {15476.880 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b606__clk -layer M9 -location {15383.828 15536.440} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b721__clk -layer M9 -location {12642.960 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b742__clk -layer M9 -location {14058.960 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r746_3__clk -layer M9 -location {4174.800 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r858_1__clk -layer M9 -location {14768.400 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b875__clk -layer M9 -location {14413.139 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b786__clk -layer M9 -location {3467.280 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b897__clk -layer M9 -location {2757.840 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2308__clk -layer M9 -location {2049.360 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b731__clk -layer M9 -location {4530.061 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b865__clk -layer M9 -location {2757.840 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r2185_2__clk -layer M9 -location {2152.929 1720.278} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b768__clk -layer M9 -location {2339.280 1331.100} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r890_3__clk -layer M9 -location {14768.400 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2306__clk -layer M9 -location {15476.880 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b918__clk -layer M9 -location {1341.840 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r713_0__clk -layer M9 -location {2849.619 15331.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r722_1__clk -layer M9 -location {12642.960 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2266__clk -layer M9 -location {4174.800 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r858_3__clk -layer M9 -location {14768.400 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b873__clk -layer M9 -location {14059.920 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r898_1__clk -layer M9 -location {2757.840 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b910__clk -layer M9 -location {16184.400 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r716_0__clk -layer M9 -location {15186.960 15674.228} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b729__clk -layer M9 -location {4883.280 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b843__clk -layer M9 -location {14413.139 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b750__clk -layer M9 -location {3467.280 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r866_1__clk -layer M9 -location {2757.840 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r769_1__clk -layer M9 -location {2075.920 1331.560} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b883__clk -layer M9 -location {3113.101 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2302__clk -layer M9 -location {14768.400 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r713_2__clk -layer M9 -location {2566.736 15331.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r722_3__clk -layer M9 -location {12642.960 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2294__clk -layer M9 -location {14768.400 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r874_1__clk -layer M9 -location {14059.920 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b894__clk -layer M9 -location {15475.920 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r898_3__clk -layer M9 -location {2757.840 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1011__clk -layer M9 -location {987.661 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r716_2__clk -layer M9 -location {15186.960 15949.804} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r730_1__clk -layer M9 -location {4883.280 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b841__clk -layer M9 -location {14059.920 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b862__clk -layer M9 -location {15475.920 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r866_3__clk -layer M9 -location {2757.840 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r769_3__clk -layer M9 -location {1812.560 1329.560} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b881__clk -layer M9 -location {3466.320 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1003__clk -layer M9 -location {16538.579 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r713_4__clk -layer M9 -location {2283.853 15331.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2260__clk -layer M9 -location {12642.960 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b851__clk -layer M9 -location {3113.101 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r874_3__clk -layer M9 -location {14059.920 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2304__clk -layer M9 -location {2757.840 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1009__clk -layer M9 -location {1340.880 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b716__clk -layer M9 -location {15186.960 16225.110} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b726__clk -layer M9 -location {13350.480 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r730_3__clk -layer M9 -location {4883.280 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r842_1__clk -layer M9 -location {14059.920 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2296__clk -layer M9 -location {2757.840 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r882_1__clk -layer M9 -location {3466.320 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b987__clk -layer M9 -location {15830.099 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b902__clk -layer M9 -location {2050.320 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1001__clk -layer M9 -location {16185.360 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b849__clk -layer M9 -location {3466.320 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b955__clk -layer M9 -location {15830.099 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b870__clk -layer M9 -location {2050.320 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2192__clk -layer M9 -location {2086.032 1875.616} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2298__clk -layer M9 -location {14059.920 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1010_1__clk -layer M9 -location {1340.880 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b714__clk -layer M9 -location {2142.412 15536.440} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r717_1__clk -layer M9 -location {15450.320 16224.920} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2262__clk -layer M9 -location {4883.280 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r842_3__clk -layer M9 -location {14059.920 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2272__clk -layer M9 -location {1549.200 1252.832} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b878__clk -layer M9 -location {14767.440 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r882_3__clk -layer M9 -location {3466.320 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b985__clk -layer M9 -location {15476.880 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1002_1__clk -layer M9 -location {16185.360 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b827__clk -layer M9 -location {13704.659 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b734__clk -layer M9 -location {4175.760 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r850_1__clk -layer M9 -location {3466.320 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b953__clk -layer M9 -location {15476.880 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b995__clk -layer M9 -location {1696.141 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1010_3__clk -layer M9 -location {1340.880 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r717_3__clk -layer M9 -location {15713.680 16226.920} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2290__clk -layer M9 -location {14059.920 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b963__clk -layer M9 -location {1696.141 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2300__clk -layer M9 -location {3466.320 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r986_1__clk -layer M9 -location {15476.880 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1002_3__clk -layer M9 -location {16185.360 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r820_0__clk -layer M9 -location {2339.280 15674.228} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b825__clk -layer M9 -location {13351.440 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b846__clk -layer M9 -location {14767.440 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r850_3__clk -layer M9 -location {3466.320 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r954_1__clk -layer M9 -location {15476.880 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b971__clk -layer M9 -location {15121.619 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b886__clk -layer M9 -location {2758.800 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b993__clk -layer M9 -location {2049.360 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2332__clk -layer M9 -location {1340.880 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b835__clk -layer M9 -location {3821.581 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b961__clk -layer M9 -location {2049.360 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r986_3__clk -layer M9 -location {15476.880 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2330__clk -layer M9 -location {16185.360 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1014__clk -layer M9 -location {633.360 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r820_2__clk -layer M9 -location {2339.280 15949.804} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r826_1__clk -layer M9 -location {13351.440 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2292__clk -layer M9 -location {3466.320 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r954_3__clk -layer M9 -location {15476.880 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b969__clk -layer M9 -location {14768.400 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r994_1__clk -layer M9 -location {2049.360 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1006__clk -layer M9 -location {16892.880 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r2244_2__clk -layer M9 -location {2054.562 15734.029} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2259__clk -layer M9 -location {15977.040 16303.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b833__clk -layer M9 -location {4174.800 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b939__clk -layer M9 -location {15121.619 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b854__clk -layer M9 -location {2758.800 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r962_1__clk -layer M9 -location {2049.360 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b979__clk -layer M9 -location {2404.621 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2326__clk -layer M9 -location {15476.880 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b820__clk -layer M9 -location {2339.280 16225.110} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r826_3__clk -layer M9 -location {13351.440 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2318__clk -layer M9 -location {15476.880 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r970_1__clk -layer M9 -location {14768.400 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b990__clk -layer M9 -location {16184.400 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r994_3__clk -layer M9 -location {2049.360 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1107__clk -layer M9 -location {279.181 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r834_1__clk -layer M9 -location {4174.800 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b937__clk -layer M9 -location {14768.400 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b958__clk -layer M9 -location {16184.400 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r962_3__clk -layer M9 -location {2049.360 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b977__clk -layer M9 -location {2757.840 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1099__clk -layer M9 -location {17247.059 8095.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r821_1__clk -layer M9 -location {2075.920 16224.920} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2286__clk -layer M9 -location {13351.440 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b947__clk -layer M9 -location {2404.621 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r970_3__clk -layer M9 -location {14768.400 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2328__clk -layer M9 -location {2049.360 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1105__clk -layer M9 -location {632.400 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b830__clk -layer M9 -location {14058.960 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r834_3__clk -layer M9 -location {4174.800 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r938_1__clk -layer M9 -location {14768.400 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2320__clk -layer M9 -location {2049.360 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r978_1__clk -layer M9 -location {2757.840 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1083__clk -layer M9 -location {16538.579 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b998__clk -layer M9 -location {1341.840 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1097__clk -layer M9 -location {16893.840 7740.630} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r821_3__clk -layer M9 -location {1812.560 16226.920} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r941_2__clk -layer M9 -location {15365.448 12266.040} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b945__clk -layer M9 -location {2757.840 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1051__clk -layer M9 -location {16538.579 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b966__clk -layer M9 -location {1341.840 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2322__clk -layer M9 -location {14768.400 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1106_1__clk -layer M9 -location {632.400 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1110__clk -layer M9 -location {217.211 8334.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2288__clk -layer M9 -location {4174.800 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r938_3__clk -layer M9 -location {14768.400 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b974__clk -layer M9 -location {15475.920 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r978_3__clk -layer M9 -location {2757.840 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1081__clk -layer M9 -location {16185.360 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1098_1__clk -layer M9 -location {16893.840 7436.280} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1102__clk -layer M9 -location {17309.029 8334.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2258__clk -layer M9 -location {2086.032 15680.864} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b923__clk -layer M9 -location {14413.139 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b838__clk -layer M9 -location {3467.280 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r946_1__clk -layer M9 -location {2757.840 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1049__clk -layer M9 -location {16185.360 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1091__clk -layer M9 -location {987.661 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1106_3__clk -layer M9 -location {632.400 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2314__clk -layer M9 -location {14768.400 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1059__clk -layer M9 -location {987.661 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2324__clk -layer M9 -location {2757.840 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1082_1__clk -layer M9 -location {16185.360 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1098_3__clk -layer M9 -location {16893.840 7195.258} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1196_1__clk -layer M9 -location {192.240 8038.014} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2285__clk -layer M9 -location {1549.200 16303.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b921__clk -layer M9 -location {14059.920 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b942__clk -layer M9 -location {15475.920 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r946_3__clk -layer M9 -location {2757.840 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1050_1__clk -layer M9 -location {16185.360 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1067__clk -layer M9 -location {15830.099 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b982__clk -layer M9 -location {2050.320 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1085_2__clk -layer M9 -location {16782.408 6045.240} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1089__clk -layer M9 -location {1340.880 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1192_1__clk -layer M9 -location {17334.000 8038.014} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2360__clk -layer M9 -location {632.400 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b931__clk -layer M9 -location {3113.101 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1057__clk -layer M9 -location {1340.880 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1082_3__clk -layer M9 -location {16185.360 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2354__clk -layer M9 -location {16893.840 7058.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r922_1__clk -layer M9 -location {14059.920 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2316__clk -layer M9 -location {2757.840 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1050_3__clk -layer M9 -location {16185.360 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1065__clk -layer M9 -location {15476.880 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1090_1__clk -layer M9 -location {1340.880 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b929__clk -layer M9 -location {3466.320 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1035__clk -layer M9 -location {15830.099 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b950__clk -layer M9 -location {2050.320 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1058_1__clk -layer M9 -location {1340.880 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1075__clk -layer M9 -location {1696.141 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2350__clk -layer M9 -location {16185.360 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r922_3__clk -layer M9 -location {14059.920 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2342__clk -layer M9 -location {16185.360 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1066_1__clk -layer M9 -location {15476.880 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1086__clk -layer M9 -location {16892.880 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1090_3__clk -layer M9 -location {1340.880 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2403__clk -layer M9 -location {191.760 7712.608} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r930_1__clk -layer M9 -location {3466.320 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1033__clk -layer M9 -location {15476.880 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1054__clk -layer M9 -location {16892.880 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1058_3__clk -layer M9 -location {1340.880 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1073__clk -layer M9 -location {2049.360 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2402__clk -layer M9 -location {17334.480 7712.608} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2310__clk -layer M9 -location {14059.920 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1043__clk -layer M9 -location {1696.141 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1066_3__clk -layer M9 -location {15476.880 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2352__clk -layer M9 -location {1340.880 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b926__clk -layer M9 -location {14767.440 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r930_3__clk -layer M9 -location {3466.320 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1034_1__clk -layer M9 -location {15476.880 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2344__clk -layer M9 -location {1340.880 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1074_1__clk -layer M9 -location {2049.360 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1179__clk -layer M9 -location {17247.059 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1094__clk -layer M9 -location {633.360 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1041__clk -layer M9 -location {2049.360 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1147__clk -layer M9 -location {17247.059 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1062__clk -layer M9 -location {633.360 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2346__clk -layer M9 -location {15476.880 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1077_2__clk -layer M9 -location {1456.272 3971.640} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2312__clk -layer M9 -location {3466.320 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1034_3__clk -layer M9 -location {15476.880 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1070__clk -layer M9 -location {16184.400 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1074_3__clk -layer M9 -location {2049.360 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1177__clk -layer M9 -location {16893.840 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1019__clk -layer M9 -location {15121.619 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b934__clk -layer M9 -location {2758.800 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1042_1__clk -layer M9 -location {2049.360 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1145__clk -layer M9 -location {16893.840 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1187__clk -layer M9 -location {279.181 6022.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2338__clk -layer M9 -location {15476.880 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1155__clk -layer M9 -location {279.181 10169.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2348__clk -layer M9 -location {2049.360 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1178_1__clk -layer M9 -location {16893.840 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1182__clk -layer M9 -location {17309.029 6260.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1017__clk -layer M9 -location {14768.400 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1038__clk -layer M9 -location {16184.400 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1042_3__clk -layer M9 -location {2049.360 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1146_1__clk -layer M9 -location {16893.840 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1150__clk -layer M9 -location {17309.029 10407.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1163__clk -layer M9 -location {16538.579 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1078__clk -layer M9 -location {1341.840 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1185__clk -layer M9 -location {632.400 5667.030} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1027__clk -layer M9 -location {2404.621 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1153__clk -layer M9 -location {632.400 9814.230} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1178_3__clk -layer M9 -location {16893.840 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1018_1__clk -layer M9 -location {14768.400 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2340__clk -layer M9 -location {2049.360 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1146_3__clk -layer M9 -location {16893.840 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1161__clk -layer M9 -location {16185.360 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1256_1__clk -layer M9 -location {17334.000 5964.414} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1186_1__clk -layer M9 -location {632.400 5362.680} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1190__clk -layer M9 -location {217.211 6260.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1025__clk -layer M9 -location {2757.840 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1131__clk -layer M9 -location {16538.579 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1046__clk -layer M9 -location {1341.840 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1232_1__clk -layer M9 -location {17334.000 10111.614} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1154_1__clk -layer M9 -location {632.400 9509.880} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1158__clk -layer M9 -location {217.211 10407.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1171__clk -layer M9 -location {987.661 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2390__clk -layer M9 -location {16893.840 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1018_3__clk -layer M9 -location {14768.400 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2374__clk -layer M9 -location {16893.840 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1162_1__clk -layer M9 -location {16185.360 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1186_3__clk -layer M9 -location {632.400 5121.658} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1026_1__clk -layer M9 -location {2757.840 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1129__clk -layer M9 -location {16185.360 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1154_3__clk -layer M9 -location {632.400 9268.858} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1169__clk -layer M9 -location {1340.880 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1260_1__clk -layer M9 -location {192.240 5964.414} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2334__clk -layer M9 -location {14768.400 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1139__clk -layer M9 -location {987.661 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1236_1__clk -layer M9 -location {192.240 10111.614} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1162_3__clk -layer M9 -location {16185.360 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2396__clk -layer M9 -location {632.400 4985.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1022__clk -layer M9 -location {15475.920 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1026_3__clk -layer M9 -location {2757.840 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1130_1__clk -layer M9 -location {16185.360 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2380__clk -layer M9 -location {632.400 9132.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1170_1__clk -layer M9 -location {1340.880 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2434__clk -layer M9 -location {17334.480 5639.008} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1133_2__clk -layer M9 -location {16782.408 12266.040} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1137__clk -layer M9 -location {1340.880 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2420__clk -layer M9 -location {17334.480 9786.208} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2386__clk -layer M9 -location {16185.360 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2336__clk -layer M9 -location {2757.840 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1130_3__clk -layer M9 -location {16185.360 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1166__clk -layer M9 -location {16892.880 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1170_3__clk -layer M9 -location {1340.880 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1115__clk -layer M9 -location {15830.099 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1030__clk -layer M9 -location {2050.320 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1138_1__clk -layer M9 -location {1340.880 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2435__clk -layer M9 -location {191.760 5639.008} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2370__clk -layer M9 -location {16185.360 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2421__clk -layer M9 -location {191.760 9786.208} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2388__clk -layer M9 -location {1340.880 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1113__clk -layer M9 -location {15476.880 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1134__clk -layer M9 -location {16892.880 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1138_3__clk -layer M9 -location {1340.880 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1243__clk -layer M9 -location {17247.059 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1174__clk -layer M9 -location {633.360 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1123__clk -layer M9 -location {1696.141 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1114_1__clk -layer M9 -location {15476.880 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2372__clk -layer M9 -location {1340.880 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1241__clk -layer M9 -location {16893.840 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1121__clk -layer M9 -location {2049.360 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1219__clk -layer M9 -location {17247.059 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1142__clk -layer M9 -location {633.360 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1251__clk -layer M9 -location {279.181 3948.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1114_3__clk -layer M9 -location {15476.880 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1242_1__clk -layer M9 -location {16893.840 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1246__clk -layer M9 -location {17309.029 4186.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1122_1__clk -layer M9 -location {2049.360 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1217__clk -layer M9 -location {16893.840 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1249__clk -layer M9 -location {632.400 3593.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2366__clk -layer M9 -location {15476.880 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1125_2__clk -layer M9 -location {1456.272 14339.640} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1227__clk -layer M9 -location {279.181 12242.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1242_3__clk -layer M9 -location {16893.840 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1118__clk -layer M9 -location {16184.400 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1122_3__clk -layer M9 -location {2049.360 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1218_1__clk -layer M9 -location {16893.840 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1222__clk -layer M9 -location {17309.029 12481.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1288_1__clk -layer M9 -location {17334.000 3890.814} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1250_1__clk -layer M9 -location {632.400 3289.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1254__clk -layer M9 -location {217.211 4186.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1225__clk -layer M9 -location {632.400 11887.830} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2422__clk -layer M9 -location {16893.840 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2368__clk -layer M9 -location {2049.360 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1218_3__clk -layer M9 -location {16893.840 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1250_3__clk -layer M9 -location {632.400 3048.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1203__clk -layer M9 -location {16538.579 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1126__clk -layer M9 -location {1341.840 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1280_1__clk -layer M9 -location {17334.000 12185.214} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1226_1__clk -layer M9 -location {632.400 11583.480} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1230__clk -layer M9 -location {217.211 12481.248} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1292_1__clk -layer M9 -location {192.240 3890.814} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2408__clk -layer M9 -location {16893.840 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2428__clk -layer M9 -location {632.400 2911.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1201__clk -layer M9 -location {16185.360 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1226_3__clk -layer M9 -location {632.400 11342.458} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2450__clk -layer M9 -location {17334.480 3565.408} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1211__clk -layer M9 -location {987.661 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1284_1__clk -layer M9 -location {192.240 12185.214} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1202_1__clk -layer M9 -location {16185.360 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2414__clk -layer M9 -location {632.400 11206.048} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1209__clk -layer M9 -location {1340.880 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2448__clk -layer M9 -location {17334.480 11859.808} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2451__clk -layer M9 -location {191.760 3565.408} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1202_3__clk -layer M9 -location {16185.360 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1210_1__clk -layer M9 -location {1340.880 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2404__clk -layer M9 -location {16185.360 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1213_2__clk -layer M9 -location {747.792 14339.640} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2449__clk -layer M9 -location {191.760 11859.808} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1206__clk -layer M9 -location {16892.880 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1210_3__clk -layer M9 -location {1340.880 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2406__clk -layer M9 -location {1340.880 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1267__clk -layer M9 -location {17247.059 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1214__clk -layer M9 -location {633.360 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1265__clk -layer M9 -location {16893.840 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1275__clk -layer M9 -location {279.181 14316.448} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1266_1__clk -layer M9 -location {16893.840 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1270__clk -layer M9 -location {17309.029 14554.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1273__clk -layer M9 -location {632.400 13961.430} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1266_3__clk -layer M9 -location {16893.840 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1296_1__clk -layer M9 -location {17334.000 14258.814} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1274_1__clk -layer M9 -location {632.400 13657.080} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b1278__clk -layer M9 -location {217.211 14554.848} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2436__clk -layer M9 -location {16893.840 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1274_3__clk -layer M9 -location {632.400 13416.058} -pin_size {0.04 0.32}
place_pin -pin_name t_st_r1300_1__clk -layer M9 -location {192.240 14258.814} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2442__clk -layer M9 -location {632.400 13279.648} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2452__clk -layer M9 -location {17334.480 13933.408} -pin_size {0.04 0.32}
place_pin -pin_name t_st_b2453__clk -layer M9 -location {191.760 13933.408} -pin_size {0.04 0.32}
place_inst -name b0 -location {8760.960 7740.440} -status PLACED
place_inst -name r1_0 -location {8760.960 7888.620} -status PLACED
place_inst -name r1_1 -location {8760.960 8036.800} -status PLACED
place_inst -name r1_2 -location {8760.960 8184.980} -status PLACED
place_inst -name r1_3 -location {8760.960 8333.160} -status PLACED
place_inst -name r1_4 -location {8760.960 8481.340} -status PLACED
place_inst -name r1_5 -location {8760.960 8629.520} -status PLACED
place_inst -name b1 -location {8760.960 8777.700} -status PLACED
place_inst -name r2_0 -location {8874.643 8779.240} -status PLACED
place_inst -name b2 -location {8988.327 8778.780} -status PLACED
place_inst -name r3_0 -location {8988.327 8924.527} -status PLACED
place_inst -name r3_1 -location {8988.327 9070.274} -status PLACED
place_inst -name r3_2 -location {8988.327 9216.021} -status PLACED
place_inst -name r3_3 -location {8988.327 9361.767} -status PLACED
place_inst -name r3_4 -location {8988.327 9507.514} -status PLACED
place_inst -name r3_5 -location {8988.327 9653.261} -status PLACED
place_inst -name r3_6 -location {8988.327 9799.008} -status PLACED
place_inst -name b3 -location {8988.327 9944.755} -status PLACED
place_inst -name r4_0 -location {8760.960 7592.546} -status PLACED
place_inst -name r4_1 -location {8760.960 7444.651} -status PLACED
place_inst -name r4_2 -location {8760.960 7296.757} -status PLACED
place_inst -name r4_3 -location {8760.960 7148.863} -status PLACED
place_inst -name r4_4 -location {8760.960 7000.969} -status PLACED
place_inst -name r4_5 -location {8760.960 6853.074} -status PLACED
place_inst -name b4 -location {8760.960 6705.180} -status PLACED
place_inst -name r5_0 -location {8874.643 6705.640} -status PLACED
place_inst -name b5 -location {8988.327 6704.100} -status PLACED
place_inst -name r6_0 -location {8988.327 6574.594} -status PLACED
place_inst -name r6_1 -location {8988.327 6445.087} -status PLACED
place_inst -name r6_2 -location {8988.327 6315.581} -status PLACED
place_inst -name r6_3 -location {8988.327 6186.074} -status PLACED
place_inst -name r6_4 -location {8988.327 6056.568} -status PLACED
place_inst -name r6_5 -location {8988.327 5927.061} -status PLACED
place_inst -name b6 -location {8988.327 5797.555} -status PLACED
place_inst -name r7_0 -location {8909.865 7740.690} -status PLACED
place_inst -name r7_1 -location {9058.770 7740.940} -status PLACED
place_inst -name r7_2 -location {9207.675 7741.190} -status PLACED
place_inst -name b7 -location {9356.580 7741.440} -status PLACED
place_inst -name r8_0 -location {9375.804 7845.120} -status PLACED
place_inst -name r8_1 -location {9395.028 7948.800} -status PLACED
place_inst -name r8_2 -location {9414.252 8052.480} -status PLACED
place_inst -name r8_3 -location {9433.476 8156.160} -status PLACED
place_inst -name b8 -location {9452.700 8259.840} -status PLACED
place_inst -name r9_0 -location {9462.900 8142.924} -status PLACED
place_inst -name r9_1 -location {9567.132 8118.840} -status PLACED
place_inst -name r9_2 -location {9695.448 8118.840} -status PLACED
place_inst -name r9_3 -location {9808.500 8134.104} -status PLACED
place_inst -name b9 -location {9805.920 8259.840} -status PLACED
place_inst -name r10_0 -location {9805.920 8177.744} -status PLACED
place_inst -name b10 -location {9805.920 8095.648} -status PLACED
place_inst -name r11_0 -location {8622.520 7740.440} -status PLACED
place_inst -name r11_1 -location {8484.080 7740.440} -status PLACED
place_inst -name r11_2 -location {8345.640 7740.440} -status PLACED
place_inst -name r11_3 -location {8207.200 7740.440} -status PLACED
place_inst -name b11 -location {8068.760 7740.440} -status PLACED
place_inst -name r12_0 -location {8068.875 7870.290} -status PLACED
place_inst -name r12_1 -location {8068.990 8000.140} -status PLACED
place_inst -name r12_2 -location {8069.105 8129.990} -status PLACED
place_inst -name b12 -location {8069.220 8259.840} -status PLACED
place_inst -name r13_0 -location {8071.800 8134.104} -status PLACED
place_inst -name r13_1 -location {7958.748 8118.840} -status PLACED
place_inst -name r13_2 -location {7830.432 8118.840} -status PLACED
place_inst -name r13_3 -location {7715.400 8132.124} -status PLACED
place_inst -name b13 -location {7716.000 8259.840} -status PLACED
place_inst -name r14_0 -location {7716.000 8177.744} -status PLACED
place_inst -name b14 -location {7716.000 8095.648} -status PLACED
place_inst -name r15_0 -location {8874.643 9944.755} -status PLACED
place_inst -name b15 -location {8760.960 9944.755} -status PLACED
place_inst -name r16_0 -location {8760.960 10074.261} -status PLACED
place_inst -name r16_1 -location {8760.960 10203.768} -status PLACED
place_inst -name r16_2 -location {8760.960 10333.274} -status PLACED
place_inst -name r16_3 -location {8760.960 10462.781} -status PLACED
place_inst -name r16_4 -location {8760.960 10592.287} -status PLACED
place_inst -name r16_5 -location {8760.960 10721.794} -status PLACED
place_inst -name b16 -location {8760.960 10851.300} -status PLACED
place_inst -name r17_0 -location {8874.643 10852.840} -status PLACED
place_inst -name b17 -location {8988.327 10852.380} -status PLACED
place_inst -name r18_0 -location {8988.327 10998.127} -status PLACED
place_inst -name r18_1 -location {8988.327 11143.874} -status PLACED
place_inst -name r18_2 -location {8988.327 11289.621} -status PLACED
place_inst -name r18_3 -location {8988.327 11435.368} -status PLACED
place_inst -name r18_4 -location {8988.327 11581.114} -status PLACED
place_inst -name r18_5 -location {8988.327 11726.861} -status PLACED
place_inst -name r18_6 -location {8988.327 11872.608} -status PLACED
place_inst -name b18 -location {8988.327 12018.355} -status PLACED
place_inst -name r19_0 -location {9104.150 9944.755} -status PLACED
place_inst -name r19_1 -location {9219.973 9944.755} -status PLACED
place_inst -name r19_2 -location {9335.796 9944.755} -status PLACED
place_inst -name b19 -location {9451.619 9944.755} -status PLACED
place_inst -name r20_0 -location {9451.160 10074.317} -status PLACED
place_inst -name r20_1 -location {9453.160 10203.878} -status PLACED
place_inst -name b20 -location {9452.700 10333.440} -status PLACED
place_inst -name r21_0 -location {9462.900 10216.524} -status PLACED
place_inst -name r21_1 -location {9567.132 10192.440} -status PLACED
place_inst -name r21_2 -location {9695.448 10192.440} -status PLACED
place_inst -name r21_3 -location {9808.500 10207.704} -status PLACED
place_inst -name b21 -location {9805.920 10333.440} -status PLACED
place_inst -name r22_0 -location {9805.920 10251.344} -status PLACED
place_inst -name b22 -location {9805.920 10169.248} -status PLACED
place_inst -name r23_0 -location {8857.180 9944.755} -status PLACED
place_inst -name r23_1 -location {8726.034 9944.755} -status PLACED
place_inst -name r23_2 -location {8594.887 9944.755} -status PLACED
place_inst -name r23_3 -location {8463.740 9944.755} -status PLACED
place_inst -name r23_4 -location {8332.593 9944.755} -status PLACED
place_inst -name r23_5 -location {8201.447 9944.755} -status PLACED
place_inst -name b23 -location {8070.300 9944.755} -status PLACED
place_inst -name r24_0 -location {8070.760 10074.317} -status PLACED
place_inst -name r24_1 -location {8068.760 10203.878} -status PLACED
place_inst -name b24 -location {8069.220 10333.440} -status PLACED
place_inst -name r25_0 -location {8071.800 10207.704} -status PLACED
place_inst -name r25_1 -location {7958.748 10192.440} -status PLACED
place_inst -name r25_2 -location {7830.432 10192.440} -status PLACED
place_inst -name r25_3 -location {7715.400 10205.724} -status PLACED
place_inst -name b25 -location {7716.000 10333.440} -status PLACED
place_inst -name r26_0 -location {7716.000 10251.344} -status PLACED
place_inst -name b26 -location {7716.000 10169.248} -status PLACED
place_inst -name r27_0 -location {8874.643 5797.555} -status PLACED
place_inst -name b27 -location {8760.960 5797.555} -status PLACED
place_inst -name r28_0 -location {8760.960 5651.808} -status PLACED
place_inst -name r28_1 -location {8760.960 5506.061} -status PLACED
place_inst -name r28_2 -location {8760.960 5360.314} -status PLACED
place_inst -name r28_3 -location {8760.960 5214.568} -status PLACED
place_inst -name r28_4 -location {8760.960 5068.821} -status PLACED
place_inst -name r28_5 -location {8760.960 4923.074} -status PLACED
place_inst -name r28_6 -location {8760.960 4777.327} -status PLACED
place_inst -name b28 -location {8760.960 4631.580} -status PLACED
place_inst -name r29_0 -location {8879.257 4632.040} -status PLACED
place_inst -name b29 -location {8997.555 4630.500} -status PLACED
place_inst -name r30_0 -location {8997.555 4503.733} -status PLACED
place_inst -name r30_1 -location {8997.555 4376.966} -status PLACED
place_inst -name r30_2 -location {8997.555 4250.199} -status PLACED
place_inst -name r30_3 -location {8997.555 4123.431} -status PLACED
place_inst -name r30_4 -location {8997.555 3996.664} -status PLACED
place_inst -name b30 -location {8997.555 3869.897} -status PLACED
place_inst -name r31_0 -location {9104.150 5797.555} -status PLACED
place_inst -name r31_1 -location {9219.973 5797.555} -status PLACED
place_inst -name r31_2 -location {9335.796 5797.555} -status PLACED
place_inst -name b31 -location {9451.619 5797.555} -status PLACED
place_inst -name r32_0 -location {9451.160 5927.117} -status PLACED
place_inst -name r32_1 -location {9453.160 6056.678} -status PLACED
place_inst -name b32 -location {9452.700 6186.240} -status PLACED
place_inst -name r33_0 -location {9462.900 6069.324} -status PLACED
place_inst -name r33_1 -location {9567.132 6045.240} -status PLACED
place_inst -name r33_2 -location {9695.448 6045.240} -status PLACED
place_inst -name r33_3 -location {9808.500 6060.504} -status PLACED
place_inst -name b33 -location {9805.920 6186.240} -status PLACED
place_inst -name r34_0 -location {9805.920 6104.144} -status PLACED
place_inst -name b34 -location {9805.920 6022.048} -status PLACED
place_inst -name r35_0 -location {8857.180 5797.555} -status PLACED
place_inst -name r35_1 -location {8726.034 5797.555} -status PLACED
place_inst -name r35_2 -location {8594.887 5797.555} -status PLACED
place_inst -name r35_3 -location {8463.740 5797.555} -status PLACED
place_inst -name r35_4 -location {8332.593 5797.555} -status PLACED
place_inst -name r35_5 -location {8201.447 5797.555} -status PLACED
place_inst -name b35 -location {8070.300 5797.555} -status PLACED
place_inst -name r36_0 -location {8070.760 5927.117} -status PLACED
place_inst -name r36_1 -location {8068.760 6056.678} -status PLACED
place_inst -name b36 -location {8069.220 6186.240} -status PLACED
place_inst -name r37_0 -location {8071.800 6060.504} -status PLACED
place_inst -name r37_1 -location {7958.748 6045.240} -status PLACED
place_inst -name r37_2 -location {7830.432 6045.240} -status PLACED
place_inst -name r37_3 -location {7715.400 6058.524} -status PLACED
place_inst -name b37 -location {7716.000 6186.240} -status PLACED
place_inst -name r38_0 -location {7716.000 6104.144} -status PLACED
place_inst -name b38 -location {7716.000 6022.048} -status PLACED
place_inst -name b39 -location {9806.400 8095.648} -status PLACED
place_inst -name r40_0 -location {9806.400 7977.759} -status PLACED
place_inst -name r40_1 -location {9806.400 7859.870} -status PLACED
place_inst -name b40 -location {9806.400 7741.981} -status PLACED
place_inst -name b41 -location {9806.880 7740.900} -status PLACED
place_inst -name r42_0 -location {9806.880 7726.920} -status PLACED
place_inst -name r42_1 -location {9806.880 7436.280} -status PLACED
place_inst -name r42_2 -location {9806.880 7331.669} -status PLACED
place_inst -name r42_3 -location {9806.880 7195.258} -status PLACED
place_inst -name b42 -location {9806.880 7058.848} -status PLACED
place_inst -name r43_0 -location {9923.980 8095.648} -status PLACED
place_inst -name r43_1 -location {10042.039 8095.648} -status PLACED
place_inst -name b43 -location {10160.099 8095.648} -status PLACED
place_inst -name r44_0 -location {10159.640 8177.744} -status PLACED
place_inst -name b44 -location {10161.180 8259.840} -status PLACED
place_inst -name r45_0 -location {10171.380 8142.924} -status PLACED
place_inst -name r45_1 -location {10275.612 8118.840} -status PLACED
place_inst -name r45_2 -location {10403.928 8118.840} -status PLACED
place_inst -name r45_3 -location {10516.980 8134.104} -status PLACED
place_inst -name b45 -location {10514.400 8259.840} -status PLACED
place_inst -name r46_0 -location {10514.400 8177.744} -status PLACED
place_inst -name b46 -location {10514.400 8095.648} -status PLACED
place_inst -name b47 -location {7715.520 8095.648} -status PLACED
place_inst -name r48_0 -location {7715.520 7977.759} -status PLACED
place_inst -name r48_1 -location {7715.520 7859.870} -status PLACED
place_inst -name b48 -location {7715.520 7741.981} -status PLACED
place_inst -name b49 -location {7715.040 7740.900} -status PLACED
place_inst -name r50_0 -location {7715.040 7726.920} -status PLACED
place_inst -name r50_1 -location {7715.040 7436.280} -status PLACED
place_inst -name r50_2 -location {7715.040 7331.669} -status PLACED
place_inst -name r50_3 -location {7715.040 7195.258} -status PLACED
place_inst -name b50 -location {7715.040 7058.848} -status PLACED
place_inst -name r51_0 -location {7597.940 8095.648} -status PLACED
place_inst -name r51_1 -location {7479.881 8095.648} -status PLACED
place_inst -name b51 -location {7361.821 8095.648} -status PLACED
place_inst -name r52_0 -location {7362.280 8177.744} -status PLACED
place_inst -name b52 -location {7360.740 8259.840} -status PLACED
place_inst -name r53_0 -location {7363.320 8134.104} -status PLACED
place_inst -name r53_1 -location {7250.268 8118.840} -status PLACED
place_inst -name r53_2 -location {7121.952 8118.840} -status PLACED
place_inst -name r53_3 -location {7006.920 8132.124} -status PLACED
place_inst -name b53 -location {7007.520 8259.840} -status PLACED
place_inst -name r54_0 -location {7007.520 8177.744} -status PLACED
place_inst -name b54 -location {7007.520 8095.648} -status PLACED
place_inst -name r55_0 -location {8874.643 12018.355} -status PLACED
place_inst -name b55 -location {8760.960 12018.355} -status PLACED
place_inst -name r56_0 -location {8760.960 12147.861} -status PLACED
place_inst -name r56_1 -location {8760.960 12277.368} -status PLACED
place_inst -name r56_2 -location {8760.960 12406.874} -status PLACED
place_inst -name r56_3 -location {8760.960 12536.381} -status PLACED
place_inst -name r56_4 -location {8760.960 12665.887} -status PLACED
place_inst -name r56_5 -location {8760.960 12795.394} -status PLACED
place_inst -name b56 -location {8760.960 12924.900} -status PLACED
place_inst -name r57_0 -location {8874.643 12924.440} -status PLACED
place_inst -name b57 -location {8988.327 12925.980} -status PLACED
place_inst -name r58_0 -location {8988.327 13071.727} -status PLACED
place_inst -name r58_1 -location {8988.327 13217.474} -status PLACED
place_inst -name r58_2 -location {8988.327 13363.221} -status PLACED
place_inst -name r58_3 -location {8988.327 13508.967} -status PLACED
place_inst -name r58_4 -location {8988.327 13654.714} -status PLACED
place_inst -name r58_5 -location {8988.327 13800.461} -status PLACED
place_inst -name r58_6 -location {8988.327 13946.208} -status PLACED
place_inst -name b58 -location {8988.327 14091.955} -status PLACED
place_inst -name r59_0 -location {9104.150 12018.355} -status PLACED
place_inst -name r59_1 -location {9219.973 12018.355} -status PLACED
place_inst -name r59_2 -location {9335.796 12018.355} -status PLACED
place_inst -name b59 -location {9451.619 12018.355} -status PLACED
place_inst -name r60_0 -location {9451.160 12147.917} -status PLACED
place_inst -name r60_1 -location {9453.160 12277.478} -status PLACED
place_inst -name b60 -location {9452.700 12407.040} -status PLACED
place_inst -name r61_0 -location {9462.900 12290.124} -status PLACED
place_inst -name r61_1 -location {9567.132 12266.040} -status PLACED
place_inst -name r61_2 -location {9695.448 12266.040} -status PLACED
place_inst -name r61_3 -location {9808.500 12281.304} -status PLACED
place_inst -name b61 -location {9805.920 12407.040} -status PLACED
place_inst -name r62_0 -location {9805.920 12324.944} -status PLACED
place_inst -name b62 -location {9805.920 12242.848} -status PLACED
place_inst -name r63_0 -location {8857.180 12018.355} -status PLACED
place_inst -name r63_1 -location {8726.034 12018.355} -status PLACED
place_inst -name r63_2 -location {8594.887 12018.355} -status PLACED
place_inst -name r63_3 -location {8463.740 12018.355} -status PLACED
place_inst -name r63_4 -location {8332.593 12018.355} -status PLACED
place_inst -name r63_5 -location {8201.447 12018.355} -status PLACED
place_inst -name b63 -location {8070.300 12018.355} -status PLACED
place_inst -name r64_0 -location {8070.760 12147.917} -status PLACED
place_inst -name r64_1 -location {8068.760 12277.478} -status PLACED
place_inst -name b64 -location {8069.220 12407.040} -status PLACED
place_inst -name r65_0 -location {8071.800 12281.304} -status PLACED
place_inst -name r65_1 -location {7958.748 12266.040} -status PLACED
place_inst -name r65_2 -location {7830.432 12266.040} -status PLACED
place_inst -name r65_3 -location {7715.400 12279.324} -status PLACED
place_inst -name b65 -location {7716.000 12407.040} -status PLACED
place_inst -name r66_0 -location {7716.000 12324.944} -status PLACED
place_inst -name b66 -location {7716.000 12242.848} -status PLACED
place_inst -name b67 -location {9806.400 10169.248} -status PLACED
place_inst -name r68_0 -location {9806.400 10051.359} -status PLACED
place_inst -name r68_1 -location {9806.400 9933.470} -status PLACED
place_inst -name b68 -location {9806.400 9815.581} -status PLACED
place_inst -name b69 -location {9806.880 9814.500} -status PLACED
place_inst -name r70_0 -location {9806.880 9800.520} -status PLACED
place_inst -name r70_1 -location {9806.880 9509.880} -status PLACED
place_inst -name r70_2 -location {9806.880 9405.269} -status PLACED
place_inst -name r70_3 -location {9806.880 9268.858} -status PLACED
place_inst -name b70 -location {9806.880 9132.448} -status PLACED
place_inst -name r71_0 -location {9923.980 10169.248} -status PLACED
place_inst -name r71_1 -location {10042.039 10169.248} -status PLACED
place_inst -name b71 -location {10160.099 10169.248} -status PLACED
place_inst -name r72_0 -location {10159.640 10251.344} -status PLACED
place_inst -name b72 -location {10161.180 10333.440} -status PLACED
place_inst -name r73_0 -location {10171.380 10216.524} -status PLACED
place_inst -name r73_1 -location {10275.612 10192.440} -status PLACED
place_inst -name r73_2 -location {10403.928 10192.440} -status PLACED
place_inst -name r73_3 -location {10516.980 10207.704} -status PLACED
place_inst -name b73 -location {10514.400 10333.440} -status PLACED
place_inst -name r74_0 -location {10514.400 10251.344} -status PLACED
place_inst -name b74 -location {10514.400 10169.248} -status PLACED
place_inst -name b75 -location {7715.520 10169.248} -status PLACED
place_inst -name r76_0 -location {7715.520 10051.359} -status PLACED
place_inst -name r76_1 -location {7715.520 9933.470} -status PLACED
place_inst -name b76 -location {7715.520 9815.581} -status PLACED
place_inst -name b77 -location {7715.040 9814.500} -status PLACED
place_inst -name r78_0 -location {7715.040 9800.520} -status PLACED
place_inst -name r78_1 -location {7715.040 9509.880} -status PLACED
place_inst -name r78_2 -location {7715.040 9405.269} -status PLACED
place_inst -name r78_3 -location {7715.040 9268.858} -status PLACED
place_inst -name b78 -location {7715.040 9132.448} -status PLACED
place_inst -name r79_0 -location {7597.940 10169.248} -status PLACED
place_inst -name r79_1 -location {7479.881 10169.248} -status PLACED
place_inst -name b79 -location {7361.821 10169.248} -status PLACED
place_inst -name r80_0 -location {7362.280 10251.344} -status PLACED
place_inst -name b80 -location {7360.740 10333.440} -status PLACED
place_inst -name r81_0 -location {7363.320 10207.704} -status PLACED
place_inst -name r81_1 -location {7250.268 10192.440} -status PLACED
place_inst -name r81_2 -location {7121.952 10192.440} -status PLACED
place_inst -name r81_3 -location {7006.920 10205.724} -status PLACED
place_inst -name b81 -location {7007.520 10333.440} -status PLACED
place_inst -name r82_0 -location {7007.520 10251.344} -status PLACED
place_inst -name b82 -location {7007.520 10169.248} -status PLACED
place_inst -name b83 -location {9106.560 3869.897} -status PLACED
place_inst -name r84_0 -location {9106.560 3724.128} -status PLACED
place_inst -name r84_1 -location {9106.560 3578.360} -status PLACED
place_inst -name r84_2 -location {9106.560 3432.591} -status PLACED
place_inst -name r84_3 -location {9106.560 3286.823} -status PLACED
place_inst -name r84_4 -location {9106.560 3141.054} -status PLACED
place_inst -name r84_5 -location {9106.560 2995.286} -status PLACED
place_inst -name r84_6 -location {9106.560 2849.517} -status PLACED
place_inst -name r84_7 -location {9106.560 2703.749} -status PLACED
place_inst -name b84 -location {9106.560 2557.980} -status PLACED
place_inst -name r85_0 -location {9217.632 2558.440} -status PLACED
place_inst -name b85 -location {9328.704 2556.900} -status PLACED
place_inst -name r86_0 -location {9328.704 2426.200} -status PLACED
place_inst -name r86_1 -location {9328.704 2295.501} -status PLACED
place_inst -name r86_2 -location {9328.704 2164.801} -status PLACED
place_inst -name b86 -location {9328.704 2034.101} -status PLACED
place_inst -name r87_0 -location {9111.071 3869.897} -status PLACED
place_inst -name r87_1 -location {9224.587 3869.897} -status PLACED
place_inst -name r87_2 -location {9338.103 3869.897} -status PLACED
place_inst -name b87 -location {9451.619 3869.897} -status PLACED
place_inst -name r88_0 -location {9451.160 3991.269} -status PLACED
place_inst -name b88 -location {9452.700 4112.640} -status PLACED
place_inst -name r89_0 -location {9462.900 3995.724} -status PLACED
place_inst -name r89_1 -location {9567.132 3971.640} -status PLACED
place_inst -name r89_2 -location {9695.448 3971.640} -status PLACED
place_inst -name r89_3 -location {9808.500 3986.904} -status PLACED
place_inst -name b89 -location {9805.920 4112.640} -status PLACED
place_inst -name r90_0 -location {9805.920 4030.544} -status PLACED
place_inst -name b90 -location {9805.920 3948.448} -status PLACED
place_inst -name r91_0 -location {8865.090 3869.897} -status PLACED
place_inst -name r91_1 -location {8732.625 3869.897} -status PLACED
place_inst -name r91_2 -location {8600.160 3869.897} -status PLACED
place_inst -name r91_3 -location {8467.695 3869.897} -status PLACED
place_inst -name r91_4 -location {8335.230 3869.897} -status PLACED
place_inst -name r91_5 -location {8202.765 3869.897} -status PLACED
place_inst -name b91 -location {8070.300 3869.897} -status PLACED
place_inst -name r92_0 -location {8068.760 3991.269} -status PLACED
place_inst -name b92 -location {8069.220 4112.640} -status PLACED
place_inst -name r93_0 -location {8071.800 3986.904} -status PLACED
place_inst -name r93_1 -location {7958.748 3971.640} -status PLACED
place_inst -name r93_2 -location {7830.432 3971.640} -status PLACED
place_inst -name r93_3 -location {7715.400 3984.924} -status PLACED
place_inst -name b93 -location {7716.000 4112.640} -status PLACED
place_inst -name r94_0 -location {7716.000 4030.544} -status PLACED
place_inst -name b94 -location {7716.000 3948.448} -status PLACED
place_inst -name b95 -location {9806.400 6022.048} -status PLACED
place_inst -name r96_0 -location {9806.400 5904.159} -status PLACED
place_inst -name r96_1 -location {9806.400 5786.270} -status PLACED
place_inst -name b96 -location {9806.400 5668.381} -status PLACED
place_inst -name b97 -location {9806.880 5667.300} -status PLACED
place_inst -name r98_0 -location {9806.880 5653.320} -status PLACED
place_inst -name r98_1 -location {9806.880 5362.680} -status PLACED
place_inst -name r98_2 -location {9806.880 5258.069} -status PLACED
place_inst -name r98_3 -location {9806.880 5121.658} -status PLACED
place_inst -name b98 -location {9806.880 4985.248} -status PLACED
place_inst -name r99_0 -location {9923.980 6022.048} -status PLACED
place_inst -name r99_1 -location {10042.039 6022.048} -status PLACED
place_inst -name b99 -location {10160.099 6022.048} -status PLACED
place_inst -name r100_0 -location {10159.640 6104.144} -status PLACED
place_inst -name b100 -location {10161.180 6186.240} -status PLACED
place_inst -name r101_0 -location {10171.380 6069.324} -status PLACED
place_inst -name r101_1 -location {10275.612 6045.240} -status PLACED
place_inst -name r101_2 -location {10403.928 6045.240} -status PLACED
place_inst -name r101_3 -location {10516.980 6060.504} -status PLACED
place_inst -name b101 -location {10514.400 6186.240} -status PLACED
place_inst -name r102_0 -location {10514.400 6104.144} -status PLACED
place_inst -name b102 -location {10514.400 6022.048} -status PLACED
place_inst -name b103 -location {7715.520 6022.048} -status PLACED
place_inst -name r104_0 -location {7715.520 5904.159} -status PLACED
place_inst -name r104_1 -location {7715.520 5786.270} -status PLACED
place_inst -name b104 -location {7715.520 5668.381} -status PLACED
place_inst -name b105 -location {7715.040 5667.300} -status PLACED
place_inst -name r106_0 -location {7715.040 5653.320} -status PLACED
place_inst -name r106_1 -location {7715.040 5362.680} -status PLACED
place_inst -name r106_2 -location {7715.040 5258.069} -status PLACED
place_inst -name r106_3 -location {7715.040 5121.658} -status PLACED
place_inst -name b106 -location {7715.040 4985.248} -status PLACED
place_inst -name r107_0 -location {7597.940 6022.048} -status PLACED
place_inst -name r107_1 -location {7479.881 6022.048} -status PLACED
place_inst -name b107 -location {7361.821 6022.048} -status PLACED
place_inst -name r108_0 -location {7362.280 6104.144} -status PLACED
place_inst -name b108 -location {7360.740 6186.240} -status PLACED
place_inst -name r109_0 -location {7363.320 6060.504} -status PLACED
place_inst -name r109_1 -location {7250.268 6045.240} -status PLACED
place_inst -name r109_2 -location {7121.952 6045.240} -status PLACED
place_inst -name r109_3 -location {7006.920 6058.524} -status PLACED
place_inst -name b109 -location {7007.520 6186.240} -status PLACED
place_inst -name r110_0 -location {7007.520 6104.144} -status PLACED
place_inst -name b110 -location {7007.520 6022.048} -status PLACED
place_inst -name b111 -location {10514.880 8095.648} -status PLACED
place_inst -name r112_0 -location {10514.880 7977.759} -status PLACED
place_inst -name r112_1 -location {10514.880 7859.870} -status PLACED
place_inst -name b112 -location {10514.880 7741.981} -status PLACED
place_inst -name b113 -location {10515.360 7740.900} -status PLACED
place_inst -name r114_0 -location {10515.360 7726.920} -status PLACED
place_inst -name r114_1 -location {10515.360 7436.280} -status PLACED
place_inst -name r114_2 -location {10515.360 7331.669} -status PLACED
place_inst -name r114_3 -location {10515.360 7195.258} -status PLACED
place_inst -name b114 -location {10515.360 7058.848} -status PLACED
place_inst -name r115_0 -location {10632.460 8095.648} -status PLACED
place_inst -name r115_1 -location {10750.519 8095.648} -status PLACED
place_inst -name b115 -location {10868.579 8095.648} -status PLACED
place_inst -name r116_0 -location {10868.120 8177.744} -status PLACED
place_inst -name b116 -location {10869.660 8259.840} -status PLACED
place_inst -name r117_0 -location {10879.860 8142.924} -status PLACED
place_inst -name r117_1 -location {10984.092 8118.840} -status PLACED
place_inst -name r117_2 -location {11112.408 8118.840} -status PLACED
place_inst -name r117_3 -location {11225.460 8134.104} -status PLACED
place_inst -name b117 -location {11222.880 8259.840} -status PLACED
place_inst -name r118_0 -location {11222.880 8177.744} -status PLACED
place_inst -name b118 -location {11222.880 8095.648} -status PLACED
place_inst -name b119 -location {7007.040 8095.648} -status PLACED
place_inst -name r120_0 -location {7007.040 7977.759} -status PLACED
place_inst -name r120_1 -location {7007.040 7859.870} -status PLACED
place_inst -name b120 -location {7007.040 7741.981} -status PLACED
place_inst -name b121 -location {7006.560 7740.900} -status PLACED
place_inst -name r122_0 -location {7006.560 7726.920} -status PLACED
place_inst -name r122_1 -location {7006.560 7436.280} -status PLACED
place_inst -name r122_2 -location {7006.560 7331.669} -status PLACED
place_inst -name r122_3 -location {7006.560 7195.258} -status PLACED
place_inst -name b122 -location {7006.560 7058.848} -status PLACED
place_inst -name r123_0 -location {6889.460 8095.648} -status PLACED
place_inst -name r123_1 -location {6771.401 8095.648} -status PLACED
place_inst -name b123 -location {6653.341 8095.648} -status PLACED
place_inst -name r124_0 -location {6653.800 8177.744} -status PLACED
place_inst -name b124 -location {6652.260 8259.840} -status PLACED
place_inst -name r125_0 -location {6654.840 8134.104} -status PLACED
place_inst -name r125_1 -location {6541.788 8118.840} -status PLACED
place_inst -name r125_2 -location {6413.472 8118.840} -status PLACED
place_inst -name r125_3 -location {6298.440 8132.124} -status PLACED
place_inst -name b125 -location {6299.040 8259.840} -status PLACED
place_inst -name r126_0 -location {6299.040 8177.744} -status PLACED
place_inst -name b126 -location {6299.040 8095.648} -status PLACED
place_inst -name b127 -location {9106.560 14091.955} -status PLACED
place_inst -name r128_0 -location {9106.560 14221.461} -status PLACED
place_inst -name r128_1 -location {9106.560 14350.968} -status PLACED
place_inst -name r128_2 -location {9106.560 14480.474} -status PLACED
place_inst -name r128_3 -location {9106.560 14609.981} -status PLACED
place_inst -name r128_4 -location {9106.560 14739.487} -status PLACED
place_inst -name r128_5 -location {9106.560 14868.994} -status PLACED
place_inst -name b128 -location {9106.560 14998.500} -status PLACED
place_inst -name r129_0 -location {9206.003 15000.040} -status PLACED
place_inst -name b129 -location {9305.446 14999.580} -status PLACED
place_inst -name r130_0 -location {9305.446 15137.859} -status PLACED
place_inst -name r130_1 -location {9305.446 15276.137} -status PLACED
place_inst -name r130_2 -location {9305.446 15414.415} -status PLACED
place_inst -name b130 -location {9305.446 15552.694} -status PLACED
place_inst -name r131_0 -location {9104.150 14091.955} -status PLACED
place_inst -name r131_1 -location {9219.973 14091.955} -status PLACED
place_inst -name r131_2 -location {9335.796 14091.955} -status PLACED
place_inst -name b131 -location {9451.619 14091.955} -status PLACED
place_inst -name r132_0 -location {9451.160 14221.517} -status PLACED
place_inst -name r132_1 -location {9453.160 14351.078} -status PLACED
place_inst -name b132 -location {9452.700 14480.640} -status PLACED
place_inst -name r133_0 -location {9462.900 14363.724} -status PLACED
place_inst -name r133_1 -location {9567.132 14339.640} -status PLACED
place_inst -name r133_2 -location {9695.448 14339.640} -status PLACED
place_inst -name r133_3 -location {9808.500 14354.904} -status PLACED
place_inst -name b133 -location {9805.920 14480.640} -status PLACED
place_inst -name r134_0 -location {9805.920 14398.544} -status PLACED
place_inst -name b134 -location {9805.920 14316.448} -status PLACED
place_inst -name r135_0 -location {8857.180 14091.955} -status PLACED
place_inst -name r135_1 -location {8726.034 14091.955} -status PLACED
place_inst -name r135_2 -location {8594.887 14091.955} -status PLACED
place_inst -name r135_3 -location {8463.740 14091.955} -status PLACED
place_inst -name r135_4 -location {8332.593 14091.955} -status PLACED
place_inst -name r135_5 -location {8201.447 14091.955} -status PLACED
place_inst -name b135 -location {8070.300 14091.955} -status PLACED
place_inst -name r136_0 -location {8070.760 14221.517} -status PLACED
place_inst -name r136_1 -location {8068.760 14351.078} -status PLACED
place_inst -name b136 -location {8069.220 14480.640} -status PLACED
place_inst -name r137_0 -location {8071.800 14354.904} -status PLACED
place_inst -name r137_1 -location {7958.748 14339.640} -status PLACED
place_inst -name r137_2 -location {7830.432 14339.640} -status PLACED
place_inst -name r137_3 -location {7715.400 14352.924} -status PLACED
place_inst -name b137 -location {7716.000 14480.640} -status PLACED
place_inst -name r138_0 -location {7716.000 14398.544} -status PLACED
place_inst -name b138 -location {7716.000 14316.448} -status PLACED
place_inst -name b139 -location {9806.400 12242.848} -status PLACED
place_inst -name r140_0 -location {9806.400 12124.959} -status PLACED
place_inst -name r140_1 -location {9806.400 12007.070} -status PLACED
place_inst -name b140 -location {9806.400 11889.181} -status PLACED
place_inst -name b141 -location {9806.880 11888.100} -status PLACED
place_inst -name r142_0 -location {9806.880 11874.120} -status PLACED
place_inst -name r142_1 -location {9806.880 11583.480} -status PLACED
place_inst -name r142_2 -location {9806.880 11478.869} -status PLACED
place_inst -name r142_3 -location {9806.880 11342.458} -status PLACED
place_inst -name b142 -location {9806.880 11206.048} -status PLACED
place_inst -name r143_0 -location {9923.980 12242.848} -status PLACED
place_inst -name r143_1 -location {10042.039 12242.848} -status PLACED
place_inst -name b143 -location {10160.099 12242.848} -status PLACED
place_inst -name r144_0 -location {10159.640 12324.944} -status PLACED
place_inst -name b144 -location {10161.180 12407.040} -status PLACED
place_inst -name r145_0 -location {10171.380 12290.124} -status PLACED
place_inst -name r145_1 -location {10275.612 12266.040} -status PLACED
place_inst -name r145_2 -location {10403.928 12266.040} -status PLACED
place_inst -name r145_3 -location {10516.980 12281.304} -status PLACED
place_inst -name b145 -location {10514.400 12407.040} -status PLACED
place_inst -name r146_0 -location {10514.400 12324.944} -status PLACED
place_inst -name b146 -location {10514.400 12242.848} -status PLACED
place_inst -name b147 -location {7715.520 12242.848} -status PLACED
place_inst -name r148_0 -location {7715.520 12124.959} -status PLACED
place_inst -name r148_1 -location {7715.520 12007.070} -status PLACED
place_inst -name b148 -location {7715.520 11889.181} -status PLACED
place_inst -name b149 -location {7715.040 11888.100} -status PLACED
place_inst -name r150_0 -location {7715.040 11874.120} -status PLACED
place_inst -name r150_1 -location {7715.040 11583.480} -status PLACED
place_inst -name r150_2 -location {7715.040 11478.869} -status PLACED
place_inst -name r150_3 -location {7715.040 11342.458} -status PLACED
place_inst -name b150 -location {7715.040 11206.048} -status PLACED
place_inst -name r151_0 -location {7597.940 12242.848} -status PLACED
place_inst -name r151_1 -location {7479.881 12242.848} -status PLACED
place_inst -name b151 -location {7361.821 12242.848} -status PLACED
place_inst -name r152_0 -location {7362.280 12324.944} -status PLACED
place_inst -name b152 -location {7360.740 12407.040} -status PLACED
place_inst -name r153_0 -location {7363.320 12281.304} -status PLACED
place_inst -name r153_1 -location {7250.268 12266.040} -status PLACED
place_inst -name r153_2 -location {7121.952 12266.040} -status PLACED
place_inst -name r153_3 -location {7006.920 12279.324} -status PLACED
place_inst -name b153 -location {7007.520 12407.040} -status PLACED
place_inst -name r154_0 -location {7007.520 12324.944} -status PLACED
place_inst -name b154 -location {7007.520 12242.848} -status PLACED
place_inst -name b155 -location {10514.880 10169.248} -status PLACED
place_inst -name r156_0 -location {10514.880 10051.359} -status PLACED
place_inst -name r156_1 -location {10514.880 9933.470} -status PLACED
place_inst -name b156 -location {10514.880 9815.581} -status PLACED
place_inst -name b157 -location {10515.360 9814.500} -status PLACED
place_inst -name r158_0 -location {10515.360 9800.520} -status PLACED
place_inst -name r158_1 -location {10515.360 9509.880} -status PLACED
place_inst -name r158_2 -location {10515.360 9405.269} -status PLACED
place_inst -name r158_3 -location {10515.360 9268.858} -status PLACED
place_inst -name b158 -location {10515.360 9132.448} -status PLACED
place_inst -name r159_0 -location {10632.460 10169.248} -status PLACED
place_inst -name r159_1 -location {10750.519 10169.248} -status PLACED
place_inst -name b159 -location {10868.579 10169.248} -status PLACED
place_inst -name r160_0 -location {10868.120 10251.344} -status PLACED
place_inst -name b160 -location {10869.660 10333.440} -status PLACED
place_inst -name r161_0 -location {10879.860 10216.524} -status PLACED
place_inst -name r161_1 -location {10984.092 10192.440} -status PLACED
place_inst -name r161_2 -location {11112.408 10192.440} -status PLACED
place_inst -name r161_3 -location {11225.460 10207.704} -status PLACED
place_inst -name b161 -location {11222.880 10333.440} -status PLACED
place_inst -name r162_0 -location {11222.880 10251.344} -status PLACED
place_inst -name b162 -location {11222.880 10169.248} -status PLACED
place_inst -name b163 -location {7007.040 10169.248} -status PLACED
place_inst -name r164_0 -location {7007.040 10051.359} -status PLACED
place_inst -name r164_1 -location {7007.040 9933.470} -status PLACED
place_inst -name b164 -location {7007.040 9815.581} -status PLACED
place_inst -name b165 -location {7006.560 9814.500} -status PLACED
place_inst -name r166_0 -location {7006.560 9800.520} -status PLACED
place_inst -name r166_1 -location {7006.560 9509.880} -status PLACED
place_inst -name r166_2 -location {7006.560 9405.269} -status PLACED
place_inst -name r166_3 -location {7006.560 9268.858} -status PLACED
place_inst -name b166 -location {7006.560 9132.448} -status PLACED
place_inst -name r167_0 -location {6889.460 10169.248} -status PLACED
place_inst -name r167_1 -location {6771.401 10169.248} -status PLACED
place_inst -name b167 -location {6653.341 10169.248} -status PLACED
place_inst -name r168_0 -location {6653.800 10251.344} -status PLACED
place_inst -name b168 -location {6652.260 10333.440} -status PLACED
place_inst -name r169_0 -location {6654.840 10207.704} -status PLACED
place_inst -name r169_1 -location {6541.788 10192.440} -status PLACED
place_inst -name r169_2 -location {6413.472 10192.440} -status PLACED
place_inst -name r169_3 -location {6298.440 10205.724} -status PLACED
place_inst -name b169 -location {6299.040 10333.440} -status PLACED
place_inst -name r170_0 -location {6299.040 10251.344} -status PLACED
place_inst -name b170 -location {6299.040 10169.248} -status PLACED
place_inst -name r171_0 -location {9405.552 2034.101} -status PLACED
place_inst -name b171 -location {9482.400 2034.101} -status PLACED
place_inst -name r172_0 -location {9482.400 1893.501} -status PLACED
place_inst -name r172_1 -location {9482.400 1752.901} -status PLACED
place_inst -name r172_2 -location {9482.400 1612.300} -status PLACED
place_inst -name r172_3 -location {9482.400 1471.700} -status PLACED
place_inst -name b172 -location {9482.400 1331.100} -status PLACED
place_inst -name r173_0 -location {9626.592 1331.560} -status PLACED
place_inst -name r173_1 -location {9770.784 1331.560} -status PLACED
place_inst -name r173_2 -location {9914.976 1329.560} -status PLACED
place_inst -name r173_3 -location {10059.168 1329.560} -status PLACED
place_inst -name b173 -location {10203.360 1330.016} -status PLACED
place_inst -name b174 -location {10203.360 1252.832} -status PLACED
place_inst -name r175_0 -location {9186.903 2034.101} -status PLACED
place_inst -name r175_1 -location {9045.102 2034.101} -status PLACED
place_inst -name r175_2 -location {8903.301 2034.101} -status PLACED
place_inst -name b175 -location {8761.500 2034.101} -status PLACED
place_inst -name r176_0 -location {8759.960 1900.491} -status PLACED
place_inst -name b176 -location {8760.420 1766.880} -status PLACED
place_inst -name r177_0 -location {8616.580 1766.880} -status PLACED
place_inst -name r177_1 -location {8472.740 1766.880} -status PLACED
place_inst -name r177_2 -location {8328.901 1766.880} -status PLACED
place_inst -name r177_3 -location {8185.061 1766.880} -status PLACED
place_inst -name b177 -location {8041.221 1766.880} -status PLACED
place_inst -name b178 -location {8041.221 1832.187} -status PLACED
place_inst -name r179_0 -location {9474.470 2034.101} -status PLACED
place_inst -name r179_1 -location {9620.236 2034.101} -status PLACED
place_inst -name r179_2 -location {9766.002 2034.101} -status PLACED
place_inst -name r179_3 -location {9911.768 2034.101} -status PLACED
place_inst -name r179_4 -location {10057.534 2034.101} -status PLACED
place_inst -name b179 -location {10203.300 2034.101} -status PLACED
place_inst -name b180 -location {10204.380 2138.400} -status PLACED
place_inst -name r181_0 -location {10341.725 2138.400} -status PLACED
place_inst -name r181_1 -location {10479.070 2138.400} -status PLACED
place_inst -name r181_2 -location {10616.414 2138.400} -status PLACED
place_inst -name r181_3 -location {10753.759 2138.400} -status PLACED
place_inst -name b181 -location {10891.104 2138.400} -status PLACED
place_inst -name b182 -location {10891.104 2141.141} -status PLACED
place_inst -name b183 -location {9806.400 3948.448} -status PLACED
place_inst -name r184_0 -location {9806.400 3830.559} -status PLACED
place_inst -name r184_1 -location {9806.400 3712.670} -status PLACED
place_inst -name b184 -location {9806.400 3594.781} -status PLACED
place_inst -name b185 -location {9806.880 3593.700} -status PLACED
place_inst -name r186_0 -location {9806.880 3579.720} -status PLACED
place_inst -name r186_1 -location {9806.880 3289.080} -status PLACED
place_inst -name r186_2 -location {9806.880 3184.469} -status PLACED
place_inst -name r186_3 -location {9806.880 3048.058} -status PLACED
place_inst -name b186 -location {9806.880 2911.648} -status PLACED
place_inst -name r187_0 -location {9923.980 3948.448} -status PLACED
place_inst -name r187_1 -location {10042.039 3948.448} -status PLACED
place_inst -name b187 -location {10160.099 3948.448} -status PLACED
place_inst -name r188_0 -location {10159.640 4030.544} -status PLACED
place_inst -name b188 -location {10161.180 4112.640} -status PLACED
place_inst -name r189_0 -location {10171.380 3995.724} -status PLACED
place_inst -name r189_1 -location {10275.612 3971.640} -status PLACED
place_inst -name r189_2 -location {10403.928 3971.640} -status PLACED
place_inst -name r189_3 -location {10516.980 3986.904} -status PLACED
place_inst -name b189 -location {10514.400 4112.640} -status PLACED
place_inst -name r190_0 -location {10514.400 4030.544} -status PLACED
place_inst -name b190 -location {10514.400 3948.448} -status PLACED
place_inst -name b191 -location {7715.520 3948.448} -status PLACED
place_inst -name r192_0 -location {7715.520 3830.559} -status PLACED
place_inst -name r192_1 -location {7715.520 3712.670} -status PLACED
place_inst -name b192 -location {7715.520 3594.781} -status PLACED
place_inst -name b193 -location {7715.040 3593.700} -status PLACED
place_inst -name r194_0 -location {7715.040 3579.720} -status PLACED
place_inst -name r194_1 -location {7715.040 3289.080} -status PLACED
place_inst -name r194_2 -location {7715.040 3184.469} -status PLACED
place_inst -name r194_3 -location {7715.040 3048.058} -status PLACED
place_inst -name b194 -location {7715.040 2911.648} -status PLACED
place_inst -name r195_0 -location {7597.940 3948.448} -status PLACED
place_inst -name r195_1 -location {7479.881 3948.448} -status PLACED
place_inst -name b195 -location {7361.821 3948.448} -status PLACED
place_inst -name r196_0 -location {7362.280 4030.544} -status PLACED
place_inst -name b196 -location {7360.740 4112.640} -status PLACED
place_inst -name r197_0 -location {7363.320 3986.904} -status PLACED
place_inst -name r197_1 -location {7250.268 3971.640} -status PLACED
place_inst -name r197_2 -location {7121.952 3971.640} -status PLACED
place_inst -name r197_3 -location {7006.920 3984.924} -status PLACED
place_inst -name b197 -location {7007.520 4112.640} -status PLACED
place_inst -name r198_0 -location {7007.520 4030.544} -status PLACED
place_inst -name b198 -location {7007.520 3948.448} -status PLACED
place_inst -name b199 -location {10514.880 6022.048} -status PLACED
place_inst -name r200_0 -location {10514.880 5904.159} -status PLACED
place_inst -name r200_1 -location {10514.880 5786.270} -status PLACED
place_inst -name b200 -location {10514.880 5668.381} -status PLACED
place_inst -name b201 -location {10515.360 5667.300} -status PLACED
place_inst -name r202_0 -location {10515.360 5653.320} -status PLACED
place_inst -name r202_1 -location {10515.360 5362.680} -status PLACED
place_inst -name r202_2 -location {10515.360 5258.069} -status PLACED
place_inst -name r202_3 -location {10515.360 5121.658} -status PLACED
place_inst -name b202 -location {10515.360 4985.248} -status PLACED
place_inst -name r203_0 -location {10632.460 6022.048} -status PLACED
place_inst -name r203_1 -location {10750.519 6022.048} -status PLACED
place_inst -name b203 -location {10868.579 6022.048} -status PLACED
place_inst -name r204_0 -location {10868.120 6104.144} -status PLACED
place_inst -name b204 -location {10869.660 6186.240} -status PLACED
place_inst -name r205_0 -location {10879.860 6069.324} -status PLACED
place_inst -name r205_1 -location {10984.092 6045.240} -status PLACED
place_inst -name r205_2 -location {11112.408 6045.240} -status PLACED
place_inst -name r205_3 -location {11225.460 6060.504} -status PLACED
place_inst -name b205 -location {11222.880 6186.240} -status PLACED
place_inst -name r206_0 -location {11222.880 6104.144} -status PLACED
place_inst -name b206 -location {11222.880 6022.048} -status PLACED
place_inst -name b207 -location {7007.040 6022.048} -status PLACED
place_inst -name r208_0 -location {7007.040 5904.159} -status PLACED
place_inst -name r208_1 -location {7007.040 5786.270} -status PLACED
place_inst -name b208 -location {7007.040 5668.381} -status PLACED
place_inst -name b209 -location {7006.560 5667.300} -status PLACED
place_inst -name r210_0 -location {7006.560 5653.320} -status PLACED
place_inst -name r210_1 -location {7006.560 5362.680} -status PLACED
place_inst -name r210_2 -location {7006.560 5258.069} -status PLACED
place_inst -name r210_3 -location {7006.560 5121.658} -status PLACED
place_inst -name b210 -location {7006.560 4985.248} -status PLACED
place_inst -name r211_0 -location {6889.460 6022.048} -status PLACED
place_inst -name r211_1 -location {6771.401 6022.048} -status PLACED
place_inst -name b211 -location {6653.341 6022.048} -status PLACED
place_inst -name r212_0 -location {6653.800 6104.144} -status PLACED
place_inst -name b212 -location {6652.260 6186.240} -status PLACED
place_inst -name r213_0 -location {6654.840 6060.504} -status PLACED
place_inst -name r213_1 -location {6541.788 6045.240} -status PLACED
place_inst -name r213_2 -location {6413.472 6045.240} -status PLACED
place_inst -name r213_3 -location {6298.440 6058.524} -status PLACED
place_inst -name b213 -location {6299.040 6186.240} -status PLACED
place_inst -name r214_0 -location {6299.040 6104.144} -status PLACED
place_inst -name b214 -location {6299.040 6022.048} -status PLACED
place_inst -name b215 -location {11223.360 8095.648} -status PLACED
place_inst -name r216_0 -location {11223.360 7977.759} -status PLACED
place_inst -name r216_1 -location {11223.360 7859.870} -status PLACED
place_inst -name b216 -location {11223.360 7741.981} -status PLACED
place_inst -name b217 -location {11223.840 7740.900} -status PLACED
place_inst -name r218_0 -location {11223.840 7726.920} -status PLACED
place_inst -name r218_1 -location {11223.840 7436.280} -status PLACED
place_inst -name r218_2 -location {11223.840 7331.669} -status PLACED
place_inst -name r218_3 -location {11223.840 7195.258} -status PLACED
place_inst -name b218 -location {11223.840 7058.848} -status PLACED
place_inst -name r219_0 -location {11340.940 8095.648} -status PLACED
place_inst -name r219_1 -location {11458.999 8095.648} -status PLACED
place_inst -name b219 -location {11577.059 8095.648} -status PLACED
place_inst -name r220_0 -location {11576.600 8177.744} -status PLACED
place_inst -name b220 -location {11578.140 8259.840} -status PLACED
place_inst -name r221_0 -location {11588.340 8142.924} -status PLACED
place_inst -name r221_1 -location {11692.572 8118.840} -status PLACED
place_inst -name r221_2 -location {11820.888 8118.840} -status PLACED
place_inst -name r221_3 -location {11933.940 8134.104} -status PLACED
place_inst -name b221 -location {11931.360 8259.840} -status PLACED
place_inst -name r222_0 -location {11931.360 8177.744} -status PLACED
place_inst -name b222 -location {11931.360 8095.648} -status PLACED
place_inst -name b223 -location {6298.560 8095.648} -status PLACED
place_inst -name r224_0 -location {6298.560 7977.759} -status PLACED
place_inst -name r224_1 -location {6298.560 7859.870} -status PLACED
place_inst -name b224 -location {6298.560 7741.981} -status PLACED
place_inst -name b225 -location {6298.080 7740.900} -status PLACED
place_inst -name r226_0 -location {6298.080 7726.920} -status PLACED
place_inst -name r226_1 -location {6298.080 7436.280} -status PLACED
place_inst -name r226_2 -location {6298.080 7331.669} -status PLACED
place_inst -name r226_3 -location {6298.080 7195.258} -status PLACED
place_inst -name b226 -location {6298.080 7058.848} -status PLACED
place_inst -name r227_0 -location {6180.980 8095.648} -status PLACED
place_inst -name r227_1 -location {6062.921 8095.648} -status PLACED
place_inst -name b227 -location {5944.861 8095.648} -status PLACED
place_inst -name r228_0 -location {5945.320 8177.744} -status PLACED
place_inst -name b228 -location {5943.780 8259.840} -status PLACED
place_inst -name r229_0 -location {5946.360 8134.104} -status PLACED
place_inst -name r229_1 -location {5833.308 8118.840} -status PLACED
place_inst -name r229_2 -location {5704.992 8118.840} -status PLACED
place_inst -name r229_3 -location {5589.960 8132.124} -status PLACED
place_inst -name b229 -location {5590.560 8259.840} -status PLACED
place_inst -name r230_0 -location {5590.560 8177.744} -status PLACED
place_inst -name b230 -location {5590.560 8095.648} -status PLACED
place_inst -name r231_0 -location {9169.460 15552.694} -status PLACED
place_inst -name r231_1 -location {9033.473 15552.694} -status PLACED
place_inst -name r231_2 -location {8897.486 15552.694} -status PLACED
place_inst -name b231 -location {8761.500 15552.694} -status PLACED
place_inst -name b232 -location {8760.420 15612.480} -status PLACED
place_inst -name r233_0 -location {8617.008 15612.480} -status PLACED
place_inst -name r233_1 -location {8473.596 15612.480} -status PLACED
place_inst -name r233_2 -location {8330.184 15612.480} -status PLACED
place_inst -name r233_3 -location {8186.772 15612.480} -status PLACED
place_inst -name b233 -location {8043.360 15612.480} -status PLACED
place_inst -name b234 -location {8043.360 15612.448} -status PLACED
place_inst -name r235_0 -location {9393.923 15552.694} -status PLACED
place_inst -name b235 -location {9482.400 15552.694} -status PLACED
place_inst -name r236_0 -location {9482.400 15687.231} -status PLACED
place_inst -name r236_1 -location {9482.400 15821.768} -status PLACED
place_inst -name r236_2 -location {9482.400 15956.306} -status PLACED
place_inst -name r236_3 -location {9482.400 16090.843} -status PLACED
place_inst -name b236 -location {9482.400 16225.380} -status PLACED
place_inst -name r237_0 -location {9626.592 16224.920} -status PLACED
place_inst -name r237_1 -location {9770.784 16224.920} -status PLACED
place_inst -name r237_2 -location {9914.976 16226.920} -status PLACED
place_inst -name r237_3 -location {10059.168 16226.920} -status PLACED
place_inst -name b237 -location {10203.360 16226.464} -status PLACED
place_inst -name b238 -location {10203.360 16303.648} -status PLACED
place_inst -name r239_0 -location {9455.088 15552.694} -status PLACED
place_inst -name r239_1 -location {9604.731 15552.694} -status PLACED
place_inst -name r239_2 -location {9754.373 15552.694} -status PLACED
place_inst -name r239_3 -location {9904.015 15552.694} -status PLACED
place_inst -name r239_4 -location {10053.658 15552.694} -status PLACED
place_inst -name b239 -location {10203.300 15552.694} -status PLACED
place_inst -name b240 -location {10204.380 15418.080} -status PLACED
place_inst -name r241_0 -location {10341.725 15418.080} -status PLACED
place_inst -name r241_1 -location {10479.070 15418.080} -status PLACED
place_inst -name r241_2 -location {10616.414 15418.080} -status PLACED
place_inst -name r241_3 -location {10753.759 15418.080} -status PLACED
place_inst -name b241 -location {10891.104 15418.080} -status PLACED
place_inst -name b242 -location {10891.104 15415.339} -status PLACED
place_inst -name b243 -location {9806.400 14316.448} -status PLACED
place_inst -name r244_0 -location {9806.400 14198.559} -status PLACED
place_inst -name r244_1 -location {9806.400 14080.670} -status PLACED
place_inst -name b244 -location {9806.400 13962.781} -status PLACED
place_inst -name b245 -location {9806.880 13961.700} -status PLACED
place_inst -name r246_0 -location {9806.880 13947.720} -status PLACED
place_inst -name r246_1 -location {9806.880 13657.080} -status PLACED
place_inst -name r246_2 -location {9806.880 13552.469} -status PLACED
place_inst -name r246_3 -location {9806.880 13416.058} -status PLACED
place_inst -name b246 -location {9806.880 13279.648} -status PLACED
place_inst -name r247_0 -location {9923.980 14316.448} -status PLACED
place_inst -name r247_1 -location {10042.039 14316.448} -status PLACED
place_inst -name b247 -location {10160.099 14316.448} -status PLACED
place_inst -name r248_0 -location {10159.640 14398.544} -status PLACED
place_inst -name b248 -location {10161.180 14480.640} -status PLACED
place_inst -name r249_0 -location {10171.380 14363.724} -status PLACED
place_inst -name r249_1 -location {10275.612 14339.640} -status PLACED
place_inst -name r249_2 -location {10403.928 14339.640} -status PLACED
place_inst -name r249_3 -location {10516.980 14354.904} -status PLACED
place_inst -name b249 -location {10514.400 14480.640} -status PLACED
place_inst -name r250_0 -location {10514.400 14398.544} -status PLACED
place_inst -name b250 -location {10514.400 14316.448} -status PLACED
place_inst -name b251 -location {7715.520 14316.448} -status PLACED
place_inst -name r252_0 -location {7715.520 14198.559} -status PLACED
place_inst -name r252_1 -location {7715.520 14080.670} -status PLACED
place_inst -name b252 -location {7715.520 13962.781} -status PLACED
place_inst -name b253 -location {7715.040 13961.700} -status PLACED
place_inst -name r254_0 -location {7715.040 13947.720} -status PLACED
place_inst -name r254_1 -location {7715.040 13657.080} -status PLACED
place_inst -name r254_2 -location {7715.040 13552.469} -status PLACED
place_inst -name r254_3 -location {7715.040 13416.058} -status PLACED
place_inst -name b254 -location {7715.040 13279.648} -status PLACED
place_inst -name r255_0 -location {7597.940 14316.448} -status PLACED
place_inst -name r255_1 -location {7479.881 14316.448} -status PLACED
place_inst -name b255 -location {7361.821 14316.448} -status PLACED
place_inst -name r256_0 -location {7362.280 14398.544} -status PLACED
place_inst -name b256 -location {7360.740 14480.640} -status PLACED
place_inst -name r257_0 -location {7363.320 14354.904} -status PLACED
place_inst -name r257_1 -location {7250.268 14339.640} -status PLACED
place_inst -name r257_2 -location {7121.952 14339.640} -status PLACED
place_inst -name r257_3 -location {7006.920 14352.924} -status PLACED
place_inst -name b257 -location {7007.520 14480.640} -status PLACED
place_inst -name r258_0 -location {7007.520 14398.544} -status PLACED
place_inst -name b258 -location {7007.520 14316.448} -status PLACED
place_inst -name b259 -location {10514.880 12242.848} -status PLACED
place_inst -name r260_0 -location {10514.880 12124.959} -status PLACED
place_inst -name r260_1 -location {10514.880 12007.070} -status PLACED
place_inst -name b260 -location {10514.880 11889.181} -status PLACED
place_inst -name b261 -location {10515.360 11888.100} -status PLACED
place_inst -name r262_0 -location {10515.360 11874.120} -status PLACED
place_inst -name r262_1 -location {10515.360 11583.480} -status PLACED
place_inst -name r262_2 -location {10515.360 11478.869} -status PLACED
place_inst -name r262_3 -location {10515.360 11342.458} -status PLACED
place_inst -name b262 -location {10515.360 11206.048} -status PLACED
place_inst -name r263_0 -location {10632.460 12242.848} -status PLACED
place_inst -name r263_1 -location {10750.519 12242.848} -status PLACED
place_inst -name b263 -location {10868.579 12242.848} -status PLACED
place_inst -name r264_0 -location {10868.120 12324.944} -status PLACED
place_inst -name b264 -location {10869.660 12407.040} -status PLACED
place_inst -name r265_0 -location {10879.860 12290.124} -status PLACED
place_inst -name r265_1 -location {10984.092 12266.040} -status PLACED
place_inst -name r265_2 -location {11112.408 12266.040} -status PLACED
place_inst -name r265_3 -location {11225.460 12281.304} -status PLACED
place_inst -name b265 -location {11222.880 12407.040} -status PLACED
place_inst -name r266_0 -location {11222.880 12324.944} -status PLACED
place_inst -name b266 -location {11222.880 12242.848} -status PLACED
place_inst -name b267 -location {7007.040 12242.848} -status PLACED
place_inst -name r268_0 -location {7007.040 12124.959} -status PLACED
place_inst -name r268_1 -location {7007.040 12007.070} -status PLACED
place_inst -name b268 -location {7007.040 11889.181} -status PLACED
place_inst -name b269 -location {7006.560 11888.100} -status PLACED
place_inst -name r270_0 -location {7006.560 11874.120} -status PLACED
place_inst -name r270_1 -location {7006.560 11583.480} -status PLACED
place_inst -name r270_2 -location {7006.560 11478.869} -status PLACED
place_inst -name r270_3 -location {7006.560 11342.458} -status PLACED
place_inst -name b270 -location {7006.560 11206.048} -status PLACED
place_inst -name r271_0 -location {6889.460 12242.848} -status PLACED
place_inst -name r271_1 -location {6771.401 12242.848} -status PLACED
place_inst -name b271 -location {6653.341 12242.848} -status PLACED
place_inst -name r272_0 -location {6653.800 12324.944} -status PLACED
place_inst -name b272 -location {6652.260 12407.040} -status PLACED
place_inst -name r273_0 -location {6654.840 12281.304} -status PLACED
place_inst -name r273_1 -location {6541.788 12266.040} -status PLACED
place_inst -name r273_2 -location {6413.472 12266.040} -status PLACED
place_inst -name r273_3 -location {6298.440 12279.324} -status PLACED
place_inst -name b273 -location {6299.040 12407.040} -status PLACED
place_inst -name r274_0 -location {6299.040 12324.944} -status PLACED
place_inst -name b274 -location {6299.040 12242.848} -status PLACED
place_inst -name b275 -location {11223.360 10169.248} -status PLACED
place_inst -name r276_0 -location {11223.360 10051.359} -status PLACED
place_inst -name r276_1 -location {11223.360 9933.470} -status PLACED
place_inst -name b276 -location {11223.360 9815.581} -status PLACED
place_inst -name b277 -location {11223.840 9814.500} -status PLACED
place_inst -name r278_0 -location {11223.840 9800.520} -status PLACED
place_inst -name r278_1 -location {11223.840 9509.880} -status PLACED
place_inst -name r278_2 -location {11223.840 9405.269} -status PLACED
place_inst -name r278_3 -location {11223.840 9268.858} -status PLACED
place_inst -name b278 -location {11223.840 9132.448} -status PLACED
place_inst -name r279_0 -location {11340.940 10169.248} -status PLACED
place_inst -name r279_1 -location {11458.999 10169.248} -status PLACED
place_inst -name b279 -location {11577.059 10169.248} -status PLACED
place_inst -name r280_0 -location {11576.600 10251.344} -status PLACED
place_inst -name b280 -location {11578.140 10333.440} -status PLACED
place_inst -name r281_0 -location {11588.340 10216.524} -status PLACED
place_inst -name r281_1 -location {11692.572 10192.440} -status PLACED
place_inst -name r281_2 -location {11820.888 10192.440} -status PLACED
place_inst -name r281_3 -location {11933.940 10207.704} -status PLACED
place_inst -name b281 -location {11931.360 10333.440} -status PLACED
place_inst -name r282_0 -location {11931.360 10251.344} -status PLACED
place_inst -name b282 -location {11931.360 10169.248} -status PLACED
place_inst -name b283 -location {6298.560 10169.248} -status PLACED
place_inst -name r284_0 -location {6298.560 10051.359} -status PLACED
place_inst -name r284_1 -location {6298.560 9933.470} -status PLACED
place_inst -name b284 -location {6298.560 9815.581} -status PLACED
place_inst -name b285 -location {6298.080 9814.500} -status PLACED
place_inst -name r286_0 -location {6298.080 9800.520} -status PLACED
place_inst -name r286_1 -location {6298.080 9509.880} -status PLACED
place_inst -name r286_2 -location {6298.080 9405.269} -status PLACED
place_inst -name r286_3 -location {6298.080 9268.858} -status PLACED
place_inst -name b286 -location {6298.080 9132.448} -status PLACED
place_inst -name r287_0 -location {6180.980 10169.248} -status PLACED
place_inst -name r287_1 -location {6062.921 10169.248} -status PLACED
place_inst -name b287 -location {5944.861 10169.248} -status PLACED
place_inst -name r288_0 -location {5945.320 10251.344} -status PLACED
place_inst -name b288 -location {5943.780 10333.440} -status PLACED
place_inst -name r289_0 -location {5946.360 10207.704} -status PLACED
place_inst -name r289_1 -location {5833.308 10192.440} -status PLACED
place_inst -name r289_2 -location {5704.992 10192.440} -status PLACED
place_inst -name r289_3 -location {5589.960 10205.724} -status PLACED
place_inst -name b289 -location {5590.560 10333.440} -status PLACED
place_inst -name r290_0 -location {5590.560 10251.344} -status PLACED
place_inst -name b290 -location {5590.560 10169.248} -status PLACED
place_inst -name b291 -location {8039.520 1832.187} -status PLACED
place_inst -name r292_0 -location {8039.520 1706.916} -status PLACED
place_inst -name r292_1 -location {8039.520 1581.644} -status PLACED
place_inst -name r292_2 -location {8039.520 1456.372} -status PLACED
place_inst -name b292 -location {8039.520 1331.101} -status PLACED
place_inst -name r293_0 -location {7895.328 1331.560} -status PLACED
place_inst -name r293_1 -location {7751.136 1331.560} -status PLACED
place_inst -name r293_2 -location {7606.944 1329.560} -status PLACED
place_inst -name r293_3 -location {7462.752 1329.560} -status PLACED
place_inst -name b293 -location {7318.560 1330.016} -status PLACED
place_inst -name b294 -location {7318.560 1252.832} -status PLACED
place_inst -name r295_0 -location {7896.701 1832.187} -status PLACED
place_inst -name r295_1 -location {7752.181 1832.187} -status PLACED
place_inst -name r295_2 -location {7607.660 1832.187} -status PLACED
place_inst -name r295_3 -location {7463.140 1832.187} -status PLACED
place_inst -name b295 -location {7318.620 1832.187} -status PLACED
place_inst -name r296_0 -location {7319.080 1934.258} -status PLACED
place_inst -name r296_1 -location {7317.080 2036.329} -status PLACED
place_inst -name b296 -location {7317.540 2138.400} -status PLACED
place_inst -name r297_0 -location {7180.195 2138.400} -status PLACED
place_inst -name r297_1 -location {7042.850 2138.400} -status PLACED
place_inst -name r297_2 -location {6905.506 2138.400} -status PLACED
place_inst -name r297_3 -location {6768.161 2138.400} -status PLACED
place_inst -name b297 -location {6630.816 2138.400} -status PLACED
place_inst -name b298 -location {6630.816 2141.141} -status PLACED
place_inst -name r299_0 -location {11016.950 2141.141} -status PLACED
place_inst -name r299_1 -location {11142.796 2141.141} -status PLACED
place_inst -name r299_2 -location {11268.642 2141.141} -status PLACED
place_inst -name r299_3 -location {11394.488 2141.141} -status PLACED
place_inst -name r299_4 -location {11520.334 2141.141} -status PLACED
place_inst -name b299 -location {11646.180 2141.141} -status PLACED
place_inst -name b300 -location {11647.260 2138.400} -status PLACED
place_inst -name r301_0 -location {11790.992 2138.400} -status PLACED
place_inst -name r301_1 -location {11934.724 2138.400} -status PLACED
place_inst -name r301_2 -location {12078.456 2138.400} -status PLACED
place_inst -name r301_3 -location {12222.188 2138.400} -status PLACED
place_inst -name b301 -location {12365.920 2138.400} -status PLACED
place_inst -name b302 -location {12365.920 2046.011} -status PLACED
place_inst -name b303 -location {10514.880 3948.448} -status PLACED
place_inst -name r304_0 -location {10514.880 3830.559} -status PLACED
place_inst -name r304_1 -location {10514.880 3712.670} -status PLACED
place_inst -name b304 -location {10514.880 3594.781} -status PLACED
place_inst -name b305 -location {10515.360 3593.700} -status PLACED
place_inst -name r306_0 -location {10515.360 3579.720} -status PLACED
place_inst -name r306_1 -location {10515.360 3289.080} -status PLACED
place_inst -name r306_2 -location {10515.360 3184.469} -status PLACED
place_inst -name r306_3 -location {10515.360 3048.058} -status PLACED
place_inst -name b306 -location {10515.360 2911.648} -status PLACED
place_inst -name r307_0 -location {10632.460 3948.448} -status PLACED
place_inst -name r307_1 -location {10750.519 3948.448} -status PLACED
place_inst -name b307 -location {10868.579 3948.448} -status PLACED
place_inst -name r308_0 -location {10868.120 4030.544} -status PLACED
place_inst -name b308 -location {10869.660 4112.640} -status PLACED
place_inst -name r309_0 -location {10879.860 3995.724} -status PLACED
place_inst -name r309_1 -location {10984.092 3971.640} -status PLACED
place_inst -name r309_2 -location {11112.408 3971.640} -status PLACED
place_inst -name r309_3 -location {11225.460 3986.904} -status PLACED
place_inst -name b309 -location {11222.880 4112.640} -status PLACED
place_inst -name r310_0 -location {11222.880 4030.544} -status PLACED
place_inst -name b310 -location {11222.880 3948.448} -status PLACED
place_inst -name b311 -location {7007.040 3948.448} -status PLACED
place_inst -name r312_0 -location {7007.040 3830.559} -status PLACED
place_inst -name r312_1 -location {7007.040 3712.670} -status PLACED
place_inst -name b312 -location {7007.040 3594.781} -status PLACED
place_inst -name b313 -location {7006.560 3593.700} -status PLACED
place_inst -name r314_0 -location {7006.560 3579.720} -status PLACED
place_inst -name r314_1 -location {7006.560 3289.080} -status PLACED
place_inst -name r314_2 -location {7006.560 3184.469} -status PLACED
place_inst -name r314_3 -location {7006.560 3048.058} -status PLACED
place_inst -name b314 -location {7006.560 2911.648} -status PLACED
place_inst -name r315_0 -location {6889.460 3948.448} -status PLACED
place_inst -name r315_1 -location {6771.401 3948.448} -status PLACED
place_inst -name b315 -location {6653.341 3948.448} -status PLACED
place_inst -name r316_0 -location {6653.800 4030.544} -status PLACED
place_inst -name b316 -location {6652.260 4112.640} -status PLACED
place_inst -name r317_0 -location {6654.840 3986.904} -status PLACED
place_inst -name r317_1 -location {6541.788 3971.640} -status PLACED
place_inst -name r317_2 -location {6413.472 3971.640} -status PLACED
place_inst -name r317_3 -location {6298.440 3984.924} -status PLACED
place_inst -name b317 -location {6299.040 4112.640} -status PLACED
place_inst -name r318_0 -location {6299.040 4030.544} -status PLACED
place_inst -name b318 -location {6299.040 3948.448} -status PLACED
place_inst -name b319 -location {11223.360 6022.048} -status PLACED
place_inst -name r320_0 -location {11223.360 5904.159} -status PLACED
place_inst -name r320_1 -location {11223.360 5786.270} -status PLACED
place_inst -name b320 -location {11223.360 5668.381} -status PLACED
place_inst -name b321 -location {11223.840 5667.300} -status PLACED
place_inst -name r322_0 -location {11223.840 5653.320} -status PLACED
place_inst -name r322_1 -location {11223.840 5362.680} -status PLACED
place_inst -name r322_2 -location {11223.840 5258.069} -status PLACED
place_inst -name r322_3 -location {11223.840 5121.658} -status PLACED
place_inst -name b322 -location {11223.840 4985.248} -status PLACED
place_inst -name r323_0 -location {11340.940 6022.048} -status PLACED
place_inst -name r323_1 -location {11458.999 6022.048} -status PLACED
place_inst -name b323 -location {11577.059 6022.048} -status PLACED
place_inst -name r324_0 -location {11576.600 6104.144} -status PLACED
place_inst -name b324 -location {11578.140 6186.240} -status PLACED
place_inst -name r325_0 -location {11588.340 6069.324} -status PLACED
place_inst -name r325_1 -location {11692.572 6045.240} -status PLACED
place_inst -name r325_2 -location {11820.888 6045.240} -status PLACED
place_inst -name r325_3 -location {11933.940 6060.504} -status PLACED
place_inst -name b325 -location {11931.360 6186.240} -status PLACED
place_inst -name r326_0 -location {11931.360 6104.144} -status PLACED
place_inst -name b326 -location {11931.360 6022.048} -status PLACED
place_inst -name b327 -location {6298.560 6022.048} -status PLACED
place_inst -name r328_0 -location {6298.560 5904.159} -status PLACED
place_inst -name r328_1 -location {6298.560 5786.270} -status PLACED
place_inst -name b328 -location {6298.560 5668.381} -status PLACED
place_inst -name b329 -location {6298.080 5667.300} -status PLACED
place_inst -name r330_0 -location {6298.080 5653.320} -status PLACED
place_inst -name r330_1 -location {6298.080 5362.680} -status PLACED
place_inst -name r330_2 -location {6298.080 5258.069} -status PLACED
place_inst -name r330_3 -location {6298.080 5121.658} -status PLACED
place_inst -name b330 -location {6298.080 4985.248} -status PLACED
place_inst -name r331_0 -location {6180.980 6022.048} -status PLACED
place_inst -name r331_1 -location {6062.921 6022.048} -status PLACED
place_inst -name b331 -location {5944.861 6022.048} -status PLACED
place_inst -name r332_0 -location {5945.320 6104.144} -status PLACED
place_inst -name b332 -location {5943.780 6186.240} -status PLACED
place_inst -name r333_0 -location {5946.360 6060.504} -status PLACED
place_inst -name r333_1 -location {5833.308 6045.240} -status PLACED
place_inst -name r333_2 -location {5704.992 6045.240} -status PLACED
place_inst -name r333_3 -location {5589.960 6058.524} -status PLACED
place_inst -name b333 -location {5590.560 6186.240} -status PLACED
place_inst -name r334_0 -location {5590.560 6104.144} -status PLACED
place_inst -name b334 -location {5590.560 6022.048} -status PLACED
place_inst -name b335 -location {11931.840 8095.648} -status PLACED
place_inst -name r336_0 -location {11931.840 7977.759} -status PLACED
place_inst -name r336_1 -location {11931.840 7859.870} -status PLACED
place_inst -name b336 -location {11931.840 7741.981} -status PLACED
place_inst -name b337 -location {11932.320 7740.900} -status PLACED
place_inst -name r338_0 -location {11932.320 7726.920} -status PLACED
place_inst -name r338_1 -location {11932.320 7436.280} -status PLACED
place_inst -name r338_2 -location {11932.320 7331.669} -status PLACED
place_inst -name r338_3 -location {11932.320 7195.258} -status PLACED
place_inst -name b338 -location {11932.320 7058.848} -status PLACED
place_inst -name r339_0 -location {12049.420 8095.648} -status PLACED
place_inst -name r339_1 -location {12167.479 8095.648} -status PLACED
place_inst -name b339 -location {12285.539 8095.648} -status PLACED
place_inst -name r340_0 -location {12285.080 8177.744} -status PLACED
place_inst -name b340 -location {12286.620 8259.840} -status PLACED
place_inst -name r341_0 -location {12296.820 8142.924} -status PLACED
place_inst -name r341_1 -location {12401.052 8118.840} -status PLACED
place_inst -name r341_2 -location {12529.368 8118.840} -status PLACED
place_inst -name r341_3 -location {12642.420 8134.104} -status PLACED
place_inst -name b341 -location {12639.840 8259.840} -status PLACED
place_inst -name r342_0 -location {12639.840 8177.744} -status PLACED
place_inst -name b342 -location {12639.840 8095.648} -status PLACED
place_inst -name b343 -location {5590.080 8095.648} -status PLACED
place_inst -name r344_0 -location {5590.080 7977.759} -status PLACED
place_inst -name r344_1 -location {5590.080 7859.870} -status PLACED
place_inst -name b344 -location {5590.080 7741.981} -status PLACED
place_inst -name b345 -location {5589.600 7740.900} -status PLACED
place_inst -name r346_0 -location {5589.600 7726.920} -status PLACED
place_inst -name r346_1 -location {5589.600 7436.280} -status PLACED
place_inst -name r346_2 -location {5589.600 7331.669} -status PLACED
place_inst -name r346_3 -location {5589.600 7195.258} -status PLACED
place_inst -name b346 -location {5589.600 7058.848} -status PLACED
place_inst -name r347_0 -location {5472.500 8095.648} -status PLACED
place_inst -name r347_1 -location {5354.441 8095.648} -status PLACED
place_inst -name b347 -location {5236.381 8095.648} -status PLACED
place_inst -name r348_0 -location {5236.840 8177.744} -status PLACED
place_inst -name b348 -location {5235.300 8259.840} -status PLACED
place_inst -name r349_0 -location {5237.880 8134.104} -status PLACED
place_inst -name r349_1 -location {5124.828 8118.840} -status PLACED
place_inst -name r349_2 -location {4996.512 8118.840} -status PLACED
place_inst -name r349_3 -location {4881.480 8132.124} -status PLACED
place_inst -name b349 -location {4882.080 8259.840} -status PLACED
place_inst -name r350_0 -location {4882.080 8177.744} -status PLACED
place_inst -name b350 -location {4882.080 8095.648} -status PLACED
place_inst -name b351 -location {8039.520 15612.448} -status PLACED
place_inst -name r352_0 -location {8038.920 15752.629} -status PLACED
place_inst -name r352_1 -location {7924.758 15779.248} -status PLACED
place_inst -name r352_2 -location {7855.320 15850.591} -status PLACED
place_inst -name r352_3 -location {7855.320 15991.373} -status PLACED
place_inst -name r352_4 -location {7855.320 16132.154} -status PLACED
place_inst -name r352_5 -location {7900.807 16227.448} -status PLACED
place_inst -name b352 -location {8039.520 16225.380} -status PLACED
place_inst -name r353_0 -location {7895.328 16224.920} -status PLACED
place_inst -name r353_1 -location {7751.136 16224.920} -status PLACED
place_inst -name r353_2 -location {7606.944 16226.920} -status PLACED
place_inst -name r353_3 -location {7462.752 16226.920} -status PLACED
place_inst -name b353 -location {7318.560 16226.464} -status PLACED
place_inst -name b354 -location {7318.560 16303.648} -status PLACED
place_inst -name r355_0 -location {7898.412 15612.448} -status PLACED
place_inst -name r355_1 -location {7753.464 15612.448} -status PLACED
place_inst -name r355_2 -location {7608.516 15612.448} -status PLACED
place_inst -name r355_3 -location {7463.568 15612.448} -status PLACED
place_inst -name b355 -location {7318.620 15612.448} -status PLACED
place_inst -name b356 -location {7317.540 15590.880} -status PLACED
place_inst -name r357_0 -location {7173.377 15590.880} -status PLACED
place_inst -name r357_1 -location {7029.214 15590.880} -status PLACED
place_inst -name r357_2 -location {6885.051 15590.880} -status PLACED
place_inst -name r357_3 -location {6740.888 15590.880} -status PLACED
place_inst -name b357 -location {6596.725 15590.880} -status PLACED
place_inst -name b358 -location {6596.725 15558.107} -status PLACED
place_inst -name r359_0 -location {11016.950 15415.339} -status PLACED
place_inst -name r359_1 -location {11142.796 15415.339} -status PLACED
place_inst -name r359_2 -location {11268.642 15415.339} -status PLACED
place_inst -name r359_3 -location {11394.488 15415.339} -status PLACED
place_inst -name r359_4 -location {11520.334 15415.339} -status PLACED
place_inst -name b359 -location {11646.180 15415.339} -status PLACED
place_inst -name b360 -location {11647.260 15418.080} -status PLACED
place_inst -name r361_0 -location {11790.992 15418.080} -status PLACED
place_inst -name r361_1 -location {11934.724 15418.080} -status PLACED
place_inst -name r361_2 -location {12078.456 15418.080} -status PLACED
place_inst -name r361_3 -location {12222.188 15418.080} -status PLACED
place_inst -name b361 -location {12365.920 15418.080} -status PLACED
place_inst -name b362 -location {12365.920 15510.469} -status PLACED
place_inst -name b363 -location {10514.880 14316.448} -status PLACED
place_inst -name r364_0 -location {10514.880 14198.559} -status PLACED
place_inst -name r364_1 -location {10514.880 14080.670} -status PLACED
place_inst -name b364 -location {10514.880 13962.781} -status PLACED
place_inst -name b365 -location {10515.360 13961.700} -status PLACED
place_inst -name r366_0 -location {10515.360 13947.720} -status PLACED
place_inst -name r366_1 -location {10515.360 13657.080} -status PLACED
place_inst -name r366_2 -location {10515.360 13552.469} -status PLACED
place_inst -name r366_3 -location {10515.360 13416.058} -status PLACED
place_inst -name b366 -location {10515.360 13279.648} -status PLACED
place_inst -name r367_0 -location {10632.460 14316.448} -status PLACED
place_inst -name r367_1 -location {10750.519 14316.448} -status PLACED
place_inst -name b367 -location {10868.579 14316.448} -status PLACED
place_inst -name r368_0 -location {10868.120 14398.544} -status PLACED
place_inst -name b368 -location {10869.660 14480.640} -status PLACED
place_inst -name r369_0 -location {10879.860 14363.724} -status PLACED
place_inst -name r369_1 -location {10984.092 14339.640} -status PLACED
place_inst -name r369_2 -location {11112.408 14339.640} -status PLACED
place_inst -name r369_3 -location {11225.460 14354.904} -status PLACED
place_inst -name b369 -location {11222.880 14480.640} -status PLACED
place_inst -name r370_0 -location {11222.880 14398.544} -status PLACED
place_inst -name b370 -location {11222.880 14316.448} -status PLACED
place_inst -name b371 -location {7007.040 14316.448} -status PLACED
place_inst -name r372_0 -location {7007.040 14198.559} -status PLACED
place_inst -name r372_1 -location {7007.040 14080.670} -status PLACED
place_inst -name b372 -location {7007.040 13962.781} -status PLACED
place_inst -name b373 -location {7006.560 13961.700} -status PLACED
place_inst -name r374_0 -location {7006.560 13947.720} -status PLACED
place_inst -name r374_1 -location {7006.560 13657.080} -status PLACED
place_inst -name r374_2 -location {7006.560 13552.469} -status PLACED
place_inst -name r374_3 -location {7006.560 13416.058} -status PLACED
place_inst -name b374 -location {7006.560 13279.648} -status PLACED
place_inst -name r375_0 -location {6889.460 14316.448} -status PLACED
place_inst -name r375_1 -location {6771.401 14316.448} -status PLACED
place_inst -name b375 -location {6653.341 14316.448} -status PLACED
place_inst -name r376_0 -location {6653.800 14398.544} -status PLACED
place_inst -name b376 -location {6652.260 14480.640} -status PLACED
place_inst -name r377_0 -location {6654.840 14354.904} -status PLACED
place_inst -name r377_1 -location {6541.788 14339.640} -status PLACED
place_inst -name r377_2 -location {6413.472 14339.640} -status PLACED
place_inst -name r377_3 -location {6298.440 14352.924} -status PLACED
place_inst -name b377 -location {6299.040 14480.640} -status PLACED
place_inst -name r378_0 -location {6299.040 14398.544} -status PLACED
place_inst -name b378 -location {6299.040 14316.448} -status PLACED
place_inst -name b379 -location {11223.360 12242.848} -status PLACED
place_inst -name r380_0 -location {11223.360 12124.959} -status PLACED
place_inst -name r380_1 -location {11223.360 12007.070} -status PLACED
place_inst -name b380 -location {11223.360 11889.181} -status PLACED
place_inst -name b381 -location {11223.840 11888.100} -status PLACED
place_inst -name r382_0 -location {11223.840 11874.120} -status PLACED
place_inst -name r382_1 -location {11223.840 11583.480} -status PLACED
place_inst -name r382_2 -location {11223.840 11478.869} -status PLACED
place_inst -name r382_3 -location {11223.840 11342.458} -status PLACED
place_inst -name b382 -location {11223.840 11206.048} -status PLACED
place_inst -name r383_0 -location {11340.940 12242.848} -status PLACED
place_inst -name r383_1 -location {11458.999 12242.848} -status PLACED
place_inst -name b383 -location {11577.059 12242.848} -status PLACED
place_inst -name r384_0 -location {11576.600 12324.944} -status PLACED
place_inst -name b384 -location {11578.140 12407.040} -status PLACED
place_inst -name r385_0 -location {11588.340 12290.124} -status PLACED
place_inst -name r385_1 -location {11692.572 12266.040} -status PLACED
place_inst -name r385_2 -location {11820.888 12266.040} -status PLACED
place_inst -name r385_3 -location {11933.940 12281.304} -status PLACED
place_inst -name b385 -location {11931.360 12407.040} -status PLACED
place_inst -name r386_0 -location {11931.360 12324.944} -status PLACED
place_inst -name b386 -location {11931.360 12242.848} -status PLACED
place_inst -name b387 -location {6298.560 12242.848} -status PLACED
place_inst -name r388_0 -location {6298.560 12124.959} -status PLACED
place_inst -name r388_1 -location {6298.560 12007.070} -status PLACED
place_inst -name b388 -location {6298.560 11889.181} -status PLACED
place_inst -name b389 -location {6298.080 11888.100} -status PLACED
place_inst -name r390_0 -location {6298.080 11874.120} -status PLACED
place_inst -name r390_1 -location {6298.080 11583.480} -status PLACED
place_inst -name r390_2 -location {6298.080 11478.869} -status PLACED
place_inst -name r390_3 -location {6298.080 11342.458} -status PLACED
place_inst -name b390 -location {6298.080 11206.048} -status PLACED
place_inst -name r391_0 -location {6180.980 12242.848} -status PLACED
place_inst -name r391_1 -location {6062.921 12242.848} -status PLACED
place_inst -name b391 -location {5944.861 12242.848} -status PLACED
place_inst -name r392_0 -location {5945.320 12324.944} -status PLACED
place_inst -name b392 -location {5943.780 12407.040} -status PLACED
place_inst -name r393_0 -location {5946.360 12281.304} -status PLACED
place_inst -name r393_1 -location {5833.308 12266.040} -status PLACED
place_inst -name r393_2 -location {5704.992 12266.040} -status PLACED
place_inst -name r393_3 -location {5589.960 12279.324} -status PLACED
place_inst -name b393 -location {5590.560 12407.040} -status PLACED
place_inst -name r394_0 -location {5590.560 12324.944} -status PLACED
place_inst -name b394 -location {5590.560 12242.848} -status PLACED
place_inst -name b395 -location {11931.840 10169.248} -status PLACED
place_inst -name r396_0 -location {11931.840 10051.359} -status PLACED
place_inst -name r396_1 -location {11931.840 9933.470} -status PLACED
place_inst -name b396 -location {11931.840 9815.581} -status PLACED
place_inst -name b397 -location {11932.320 9814.500} -status PLACED
place_inst -name r398_0 -location {11932.320 9800.520} -status PLACED
place_inst -name r398_1 -location {11932.320 9509.880} -status PLACED
place_inst -name r398_2 -location {11932.320 9405.269} -status PLACED
place_inst -name r398_3 -location {11932.320 9268.858} -status PLACED
place_inst -name b398 -location {11932.320 9132.448} -status PLACED
place_inst -name r399_0 -location {12049.420 10169.248} -status PLACED
place_inst -name r399_1 -location {12167.479 10169.248} -status PLACED
place_inst -name b399 -location {12285.539 10169.248} -status PLACED
place_inst -name r400_0 -location {12285.080 10251.344} -status PLACED
place_inst -name b400 -location {12286.620 10333.440} -status PLACED
place_inst -name r401_0 -location {12296.820 10216.524} -status PLACED
place_inst -name r401_1 -location {12401.052 10192.440} -status PLACED
place_inst -name r401_2 -location {12529.368 10192.440} -status PLACED
place_inst -name r401_3 -location {12642.420 10207.704} -status PLACED
place_inst -name b401 -location {12639.840 10333.440} -status PLACED
place_inst -name r402_0 -location {12639.840 10251.344} -status PLACED
place_inst -name b402 -location {12639.840 10169.248} -status PLACED
place_inst -name b403 -location {5590.080 10169.248} -status PLACED
place_inst -name r404_0 -location {5590.080 10051.359} -status PLACED
place_inst -name r404_1 -location {5590.080 9933.470} -status PLACED
place_inst -name b404 -location {5590.080 9815.581} -status PLACED
place_inst -name b405 -location {5589.600 9814.500} -status PLACED
place_inst -name r406_0 -location {5589.600 9800.520} -status PLACED
place_inst -name r406_1 -location {5589.600 9509.880} -status PLACED
place_inst -name r406_2 -location {5589.600 9405.269} -status PLACED
place_inst -name r406_3 -location {5589.600 9268.858} -status PLACED
place_inst -name b406 -location {5589.600 9132.448} -status PLACED
place_inst -name r407_0 -location {5472.500 10169.248} -status PLACED
place_inst -name r407_1 -location {5354.441 10169.248} -status PLACED
place_inst -name b407 -location {5236.381 10169.248} -status PLACED
place_inst -name r408_0 -location {5236.840 10251.344} -status PLACED
place_inst -name b408 -location {5235.300 10333.440} -status PLACED
place_inst -name r409_0 -location {5237.880 10207.704} -status PLACED
place_inst -name r409_1 -location {5124.828 10192.440} -status PLACED
place_inst -name r409_2 -location {4996.512 10192.440} -status PLACED
place_inst -name r409_3 -location {4881.480 10205.724} -status PLACED
place_inst -name b409 -location {4882.080 10333.440} -status PLACED
place_inst -name r410_0 -location {4882.080 10251.344} -status PLACED
place_inst -name b410 -location {4882.080 10169.248} -status PLACED
place_inst -name r411_0 -location {6504.970 2141.141} -status PLACED
place_inst -name r411_1 -location {6379.124 2141.141} -status PLACED
place_inst -name r411_2 -location {6253.278 2141.141} -status PLACED
place_inst -name r411_3 -location {6127.432 2141.141} -status PLACED
place_inst -name r411_4 -location {6001.586 2141.141} -status PLACED
place_inst -name b411 -location {5875.740 2141.141} -status PLACED
place_inst -name b412 -location {5874.660 2138.400} -status PLACED
place_inst -name r413_0 -location {5730.928 2138.400} -status PLACED
place_inst -name r413_1 -location {5587.196 2138.400} -status PLACED
place_inst -name r413_2 -location {5443.464 2138.400} -status PLACED
place_inst -name r413_3 -location {5299.732 2138.400} -status PLACED
place_inst -name b413 -location {5156.000 2138.400} -status PLACED
place_inst -name b414 -location {5156.000 2046.011} -status PLACED
place_inst -name b415 -location {12368.160 2046.011} -status PLACED
place_inst -name r416_0 -location {12368.160 1903.029} -status PLACED
place_inst -name r416_1 -location {12368.160 1760.047} -status PLACED
place_inst -name r416_2 -location {12368.160 1617.064} -status PLACED
place_inst -name r416_3 -location {12368.160 1474.082} -status PLACED
place_inst -name b416 -location {12368.160 1331.100} -status PLACED
place_inst -name r417_0 -location {12512.352 1331.560} -status PLACED
place_inst -name r417_1 -location {12656.544 1331.560} -status PLACED
place_inst -name r417_2 -location {12800.736 1329.560} -status PLACED
place_inst -name r417_3 -location {12944.928 1329.560} -status PLACED
place_inst -name b417 -location {13089.120 1330.016} -status PLACED
place_inst -name b418 -location {13089.120 1252.832} -status PLACED
place_inst -name r419_0 -location {12510.548 2046.011} -status PLACED
place_inst -name r419_1 -location {12655.176 2046.011} -status PLACED
place_inst -name r419_2 -location {12807.240 2046.011} -status PLACED
place_inst -name r419_3 -location {12962.760 2046.011} -status PLACED
place_inst -name b419 -location {13089.060 2046.011} -status PLACED
place_inst -name r420_0 -location {13088.600 2135.405} -status PLACED
place_inst -name b420 -location {13090.140 2224.800} -status PLACED
place_inst -name r421_0 -location {13234.300 2224.800} -status PLACED
place_inst -name r421_1 -location {13378.459 2224.800} -status PLACED
place_inst -name r421_2 -location {13522.619 2224.800} -status PLACED
place_inst -name r421_3 -location {13666.778 2224.800} -status PLACED
place_inst -name b421 -location {13810.938 2224.800} -status PLACED
place_inst -name b422 -location {13810.938 2228.563} -status PLACED
place_inst -name b423 -location {11223.360 3948.448} -status PLACED
place_inst -name r424_0 -location {11223.360 3830.559} -status PLACED
place_inst -name r424_1 -location {11223.360 3712.670} -status PLACED
place_inst -name b424 -location {11223.360 3594.781} -status PLACED
place_inst -name b425 -location {11223.840 3593.700} -status PLACED
place_inst -name r426_0 -location {11223.840 3579.720} -status PLACED
place_inst -name r426_1 -location {11223.840 3289.080} -status PLACED
place_inst -name r426_2 -location {11223.840 3184.469} -status PLACED
place_inst -name r426_3 -location {11223.840 3048.058} -status PLACED
place_inst -name b426 -location {11223.840 2911.648} -status PLACED
place_inst -name r427_0 -location {11340.940 3948.448} -status PLACED
place_inst -name r427_1 -location {11458.999 3948.448} -status PLACED
place_inst -name b427 -location {11577.059 3948.448} -status PLACED
place_inst -name r428_0 -location {11576.600 4030.544} -status PLACED
place_inst -name b428 -location {11578.140 4112.640} -status PLACED
place_inst -name r429_0 -location {11588.340 3995.724} -status PLACED
place_inst -name r429_1 -location {11692.572 3971.640} -status PLACED
place_inst -name r429_2 -location {11820.888 3971.640} -status PLACED
place_inst -name r429_3 -location {11933.940 3986.904} -status PLACED
place_inst -name b429 -location {11931.360 4112.640} -status PLACED
place_inst -name r430_0 -location {11931.360 4030.544} -status PLACED
place_inst -name b430 -location {11931.360 3948.448} -status PLACED
place_inst -name b431 -location {6298.560 3948.448} -status PLACED
place_inst -name r432_0 -location {6298.560 3830.559} -status PLACED
place_inst -name r432_1 -location {6298.560 3712.670} -status PLACED
place_inst -name b432 -location {6298.560 3594.781} -status PLACED
place_inst -name b433 -location {6298.080 3593.700} -status PLACED
place_inst -name r434_0 -location {6298.080 3579.720} -status PLACED
place_inst -name r434_1 -location {6298.080 3289.080} -status PLACED
place_inst -name r434_2 -location {6298.080 3184.469} -status PLACED
place_inst -name r434_3 -location {6298.080 3048.058} -status PLACED
place_inst -name b434 -location {6298.080 2911.648} -status PLACED
place_inst -name r435_0 -location {6180.980 3948.448} -status PLACED
place_inst -name r435_1 -location {6062.921 3948.448} -status PLACED
place_inst -name b435 -location {5944.861 3948.448} -status PLACED
place_inst -name r436_0 -location {5945.320 4030.544} -status PLACED
place_inst -name b436 -location {5943.780 4112.640} -status PLACED
place_inst -name r437_0 -location {5946.360 3986.904} -status PLACED
place_inst -name r437_1 -location {5833.308 3971.640} -status PLACED
place_inst -name r437_2 -location {5704.992 3971.640} -status PLACED
place_inst -name r437_3 -location {5589.960 3984.924} -status PLACED
place_inst -name b437 -location {5590.560 4112.640} -status PLACED
place_inst -name r438_0 -location {5590.560 4030.544} -status PLACED
place_inst -name b438 -location {5590.560 3948.448} -status PLACED
place_inst -name b439 -location {11931.840 6022.048} -status PLACED
place_inst -name r440_0 -location {11931.840 5904.159} -status PLACED
place_inst -name r440_1 -location {11931.840 5786.270} -status PLACED
place_inst -name b440 -location {11931.840 5668.381} -status PLACED
place_inst -name b441 -location {11932.320 5667.300} -status PLACED
place_inst -name r442_0 -location {11932.320 5653.320} -status PLACED
place_inst -name r442_1 -location {11932.320 5362.680} -status PLACED
place_inst -name r442_2 -location {11932.320 5258.069} -status PLACED
place_inst -name r442_3 -location {11932.320 5121.658} -status PLACED
place_inst -name b442 -location {11932.320 4985.248} -status PLACED
place_inst -name r443_0 -location {12049.420 6022.048} -status PLACED
place_inst -name r443_1 -location {12167.479 6022.048} -status PLACED
place_inst -name b443 -location {12285.539 6022.048} -status PLACED
place_inst -name r444_0 -location {12285.080 6104.144} -status PLACED
place_inst -name b444 -location {12286.620 6186.240} -status PLACED
place_inst -name r445_0 -location {12296.820 6069.324} -status PLACED
place_inst -name r445_1 -location {12401.052 6045.240} -status PLACED
place_inst -name r445_2 -location {12529.368 6045.240} -status PLACED
place_inst -name r445_3 -location {12642.420 6060.504} -status PLACED
place_inst -name b445 -location {12639.840 6186.240} -status PLACED
place_inst -name r446_0 -location {12639.840 6104.144} -status PLACED
place_inst -name b446 -location {12639.840 6022.048} -status PLACED
place_inst -name b447 -location {5590.080 6022.048} -status PLACED
place_inst -name r448_0 -location {5590.080 5904.159} -status PLACED
place_inst -name r448_1 -location {5590.080 5786.270} -status PLACED
place_inst -name b448 -location {5590.080 5668.381} -status PLACED
place_inst -name b449 -location {5589.600 5667.300} -status PLACED
place_inst -name r450_0 -location {5589.600 5653.320} -status PLACED
place_inst -name r450_1 -location {5589.600 5362.680} -status PLACED
place_inst -name r450_2 -location {5589.600 5258.069} -status PLACED
place_inst -name r450_3 -location {5589.600 5121.658} -status PLACED
place_inst -name b450 -location {5589.600 4985.248} -status PLACED
place_inst -name r451_0 -location {5472.500 6022.048} -status PLACED
place_inst -name r451_1 -location {5354.441 6022.048} -status PLACED
place_inst -name b451 -location {5236.381 6022.048} -status PLACED
place_inst -name r452_0 -location {5236.840 6104.144} -status PLACED
place_inst -name b452 -location {5235.300 6186.240} -status PLACED
place_inst -name r453_0 -location {5237.880 6060.504} -status PLACED
place_inst -name r453_1 -location {5124.828 6045.240} -status PLACED
place_inst -name r453_2 -location {4996.512 6045.240} -status PLACED
place_inst -name r453_3 -location {4881.480 6058.524} -status PLACED
place_inst -name b453 -location {4882.080 6186.240} -status PLACED
place_inst -name r454_0 -location {4882.080 6104.144} -status PLACED
place_inst -name b454 -location {4882.080 6022.048} -status PLACED
place_inst -name b455 -location {12640.320 8095.648} -status PLACED
place_inst -name r456_0 -location {12640.320 7977.759} -status PLACED
place_inst -name r456_1 -location {12640.320 7859.870} -status PLACED
place_inst -name b456 -location {12640.320 7741.981} -status PLACED
place_inst -name b457 -location {12640.800 7740.900} -status PLACED
place_inst -name r458_0 -location {12640.800 7726.920} -status PLACED
place_inst -name r458_1 -location {12640.800 7436.280} -status PLACED
place_inst -name r458_2 -location {12640.800 7331.669} -status PLACED
place_inst -name r458_3 -location {12640.800 7195.258} -status PLACED
place_inst -name b458 -location {12640.800 7058.848} -status PLACED
place_inst -name r459_0 -location {12757.900 8095.648} -status PLACED
place_inst -name r459_1 -location {12875.959 8095.648} -status PLACED
place_inst -name b459 -location {12994.019 8095.648} -status PLACED
place_inst -name r460_0 -location {12993.560 8177.744} -status PLACED
place_inst -name b460 -location {12995.100 8259.840} -status PLACED
place_inst -name r461_0 -location {13005.300 8142.924} -status PLACED
place_inst -name r461_1 -location {13109.532 8118.840} -status PLACED
place_inst -name r461_2 -location {13237.848 8118.840} -status PLACED
place_inst -name r461_3 -location {13350.900 8134.104} -status PLACED
place_inst -name b461 -location {13348.320 8259.840} -status PLACED
place_inst -name r462_0 -location {13348.320 8177.744} -status PLACED
place_inst -name b462 -location {13348.320 8095.648} -status PLACED
place_inst -name b463 -location {4881.600 8095.648} -status PLACED
place_inst -name r464_0 -location {4881.600 7977.759} -status PLACED
place_inst -name r464_1 -location {4881.600 7859.870} -status PLACED
place_inst -name b464 -location {4881.600 7741.981} -status PLACED
place_inst -name b465 -location {4881.120 7740.900} -status PLACED
place_inst -name r466_0 -location {4881.120 7726.920} -status PLACED
place_inst -name r466_1 -location {4881.120 7436.280} -status PLACED
place_inst -name r466_2 -location {4881.120 7331.669} -status PLACED
place_inst -name r466_3 -location {4881.120 7195.258} -status PLACED
place_inst -name b466 -location {4881.120 7058.848} -status PLACED
place_inst -name r467_0 -location {4764.020 8095.648} -status PLACED
place_inst -name r467_1 -location {4645.961 8095.648} -status PLACED
place_inst -name b467 -location {4527.901 8095.648} -status PLACED
place_inst -name r468_0 -location {4528.360 8177.744} -status PLACED
place_inst -name b468 -location {4526.820 8259.840} -status PLACED
place_inst -name r469_0 -location {4529.400 8134.104} -status PLACED
place_inst -name r469_1 -location {4416.348 8118.840} -status PLACED
place_inst -name r469_2 -location {4288.032 8118.840} -status PLACED
place_inst -name r469_3 -location {4173.000 8132.124} -status PLACED
place_inst -name b469 -location {4173.600 8259.840} -status PLACED
place_inst -name r470_0 -location {4173.600 8177.744} -status PLACED
place_inst -name b470 -location {4173.600 8095.648} -status PLACED
place_inst -name r471_0 -location {6452.528 15558.107} -status PLACED
place_inst -name r471_1 -location {6308.331 15558.107} -status PLACED
place_inst -name r471_2 -location {6164.134 15558.107} -status PLACED
place_inst -name r471_3 -location {6019.937 15558.107} -status PLACED
place_inst -name b471 -location {5875.740 15558.107} -status PLACED
place_inst -name r472_0 -location {5876.200 15444.894} -status PLACED
place_inst -name b472 -location {5874.660 15331.680} -status PLACED
place_inst -name r473_0 -location {5730.500 15331.680} -status PLACED
place_inst -name r473_1 -location {5586.341 15331.680} -status PLACED
place_inst -name r473_2 -location {5442.181 15331.680} -status PLACED
place_inst -name r473_3 -location {5298.022 15331.680} -status PLACED
place_inst -name b473 -location {5153.862 15331.680} -status PLACED
place_inst -name b474 -location {5153.862 15327.917} -status PLACED
place_inst -name r475_0 -location {6452.528 15558.107} -status PLACED
place_inst -name r475_1 -location {6308.331 15558.107} -status PLACED
place_inst -name r475_2 -location {6164.134 15558.107} -status PLACED
place_inst -name r475_3 -location {6019.937 15558.107} -status PLACED
place_inst -name b475 -location {5875.740 15558.107} -status PLACED
place_inst -name r476_0 -location {5874.200 15706.253} -status PLACED
place_inst -name b476 -location {5874.660 15854.400} -status PLACED
place_inst -name r477_0 -location {5738.692 15854.400} -status PLACED
place_inst -name r477_1 -location {5602.724 15854.400} -status PLACED
place_inst -name r477_2 -location {5466.757 15854.400} -status PLACED
place_inst -name r477_3 -location {5330.789 15854.400} -status PLACED
place_inst -name b477 -location {5194.821 15854.400} -status PLACED
place_inst -name b478 -location {5194.821 15889.189} -status PLACED
place_inst -name b479 -location {12368.160 15510.469} -status PLACED
place_inst -name r480_0 -location {12368.160 15653.451} -status PLACED
place_inst -name r480_1 -location {12368.160 15796.433} -status PLACED
place_inst -name r480_2 -location {12368.160 15939.416} -status PLACED
place_inst -name r480_3 -location {12368.160 16082.398} -status PLACED
place_inst -name b480 -location {12368.160 16225.380} -status PLACED
place_inst -name r481_0 -location {12512.352 16224.920} -status PLACED
place_inst -name r481_1 -location {12656.544 16224.920} -status PLACED
place_inst -name r481_2 -location {12800.736 16226.920} -status PLACED
place_inst -name r481_3 -location {12944.928 16226.920} -status PLACED
place_inst -name b481 -location {13089.120 16226.464} -status PLACED
place_inst -name b482 -location {13089.120 16303.648} -status PLACED
place_inst -name r483_0 -location {12510.548 15510.469} -status PLACED
place_inst -name r483_1 -location {12655.176 15510.469} -status PLACED
place_inst -name r483_2 -location {12807.240 15510.469} -status PLACED
place_inst -name r483_3 -location {12962.760 15510.469} -status PLACED
place_inst -name b483 -location {13089.060 15510.469} -status PLACED
place_inst -name r484_0 -location {13088.600 15421.074} -status PLACED
place_inst -name b484 -location {13090.140 15331.680} -status PLACED
place_inst -name r485_0 -location {13234.300 15331.680} -status PLACED
place_inst -name r485_1 -location {13378.459 15331.680} -status PLACED
place_inst -name r485_2 -location {13522.619 15331.680} -status PLACED
place_inst -name r485_3 -location {13666.778 15331.680} -status PLACED
place_inst -name b485 -location {13810.938 15331.680} -status PLACED
place_inst -name b486 -location {13810.938 15327.917} -status PLACED
place_inst -name b487 -location {11223.360 14316.448} -status PLACED
place_inst -name r488_0 -location {11223.360 14198.559} -status PLACED
place_inst -name r488_1 -location {11223.360 14080.670} -status PLACED
place_inst -name b488 -location {11223.360 13962.781} -status PLACED
place_inst -name b489 -location {11223.840 13961.700} -status PLACED
place_inst -name r490_0 -location {11223.840 13947.720} -status PLACED
place_inst -name r490_1 -location {11223.840 13657.080} -status PLACED
place_inst -name r490_2 -location {11223.840 13552.469} -status PLACED
place_inst -name r490_3 -location {11223.840 13416.058} -status PLACED
place_inst -name b490 -location {11223.840 13279.648} -status PLACED
place_inst -name r491_0 -location {11340.940 14316.448} -status PLACED
place_inst -name r491_1 -location {11458.999 14316.448} -status PLACED
place_inst -name b491 -location {11577.059 14316.448} -status PLACED
place_inst -name r492_0 -location {11576.600 14398.544} -status PLACED
place_inst -name b492 -location {11578.140 14480.640} -status PLACED
place_inst -name r493_0 -location {11588.340 14363.724} -status PLACED
place_inst -name r493_1 -location {11692.572 14339.640} -status PLACED
place_inst -name r493_2 -location {11820.888 14339.640} -status PLACED
place_inst -name r493_3 -location {11933.940 14354.904} -status PLACED
place_inst -name b493 -location {11931.360 14480.640} -status PLACED
place_inst -name r494_0 -location {11931.360 14398.544} -status PLACED
place_inst -name b494 -location {11931.360 14316.448} -status PLACED
place_inst -name b495 -location {6298.560 14316.448} -status PLACED
place_inst -name r496_0 -location {6298.560 14198.559} -status PLACED
place_inst -name r496_1 -location {6298.560 14080.670} -status PLACED
place_inst -name b496 -location {6298.560 13962.781} -status PLACED
place_inst -name b497 -location {6298.080 13961.700} -status PLACED
place_inst -name r498_0 -location {6298.080 13947.720} -status PLACED
place_inst -name r498_1 -location {6298.080 13657.080} -status PLACED
place_inst -name r498_2 -location {6298.080 13552.469} -status PLACED
place_inst -name r498_3 -location {6298.080 13416.058} -status PLACED
place_inst -name b498 -location {6298.080 13279.648} -status PLACED
place_inst -name r499_0 -location {6180.980 14316.448} -status PLACED
place_inst -name r499_1 -location {6062.921 14316.448} -status PLACED
place_inst -name b499 -location {5944.861 14316.448} -status PLACED
place_inst -name r500_0 -location {5945.320 14398.544} -status PLACED
place_inst -name b500 -location {5943.780 14480.640} -status PLACED
place_inst -name r501_0 -location {5946.360 14354.904} -status PLACED
place_inst -name r501_1 -location {5833.308 14339.640} -status PLACED
place_inst -name r501_2 -location {5704.992 14339.640} -status PLACED
place_inst -name r501_3 -location {5589.960 14352.924} -status PLACED
place_inst -name b501 -location {5590.560 14480.640} -status PLACED
place_inst -name r502_0 -location {5590.560 14398.544} -status PLACED
place_inst -name b502 -location {5590.560 14316.448} -status PLACED
place_inst -name b503 -location {11931.840 12242.848} -status PLACED
place_inst -name r504_0 -location {11931.840 12124.959} -status PLACED
place_inst -name r504_1 -location {11931.840 12007.070} -status PLACED
place_inst -name b504 -location {11931.840 11889.181} -status PLACED
place_inst -name b505 -location {11932.320 11888.100} -status PLACED
place_inst -name r506_0 -location {11932.320 11874.120} -status PLACED
place_inst -name r506_1 -location {11932.320 11583.480} -status PLACED
place_inst -name r506_2 -location {11932.320 11478.869} -status PLACED
place_inst -name r506_3 -location {11932.320 11342.458} -status PLACED
place_inst -name b506 -location {11932.320 11206.048} -status PLACED
place_inst -name r507_0 -location {12049.420 12242.848} -status PLACED
place_inst -name r507_1 -location {12167.479 12242.848} -status PLACED
place_inst -name b507 -location {12285.539 12242.848} -status PLACED
place_inst -name r508_0 -location {12285.080 12324.944} -status PLACED
place_inst -name b508 -location {12286.620 12407.040} -status PLACED
place_inst -name r509_0 -location {12296.820 12290.124} -status PLACED
place_inst -name r509_1 -location {12401.052 12266.040} -status PLACED
place_inst -name r509_2 -location {12529.368 12266.040} -status PLACED
place_inst -name r509_3 -location {12642.420 12281.304} -status PLACED
place_inst -name b509 -location {12639.840 12407.040} -status PLACED
place_inst -name r510_0 -location {12639.840 12324.944} -status PLACED
place_inst -name b510 -location {12639.840 12242.848} -status PLACED
place_inst -name b511 -location {5590.080 12242.848} -status PLACED
place_inst -name r512_0 -location {5590.080 12124.959} -status PLACED
place_inst -name r512_1 -location {5590.080 12007.070} -status PLACED
place_inst -name b512 -location {5590.080 11889.181} -status PLACED
place_inst -name b513 -location {5589.600 11888.100} -status PLACED
place_inst -name r514_0 -location {5589.600 11874.120} -status PLACED
place_inst -name r514_1 -location {5589.600 11583.480} -status PLACED
place_inst -name r514_2 -location {5589.600 11478.869} -status PLACED
place_inst -name r514_3 -location {5589.600 11342.458} -status PLACED
place_inst -name b514 -location {5589.600 11206.048} -status PLACED
place_inst -name r515_0 -location {5472.500 12242.848} -status PLACED
place_inst -name r515_1 -location {5354.441 12242.848} -status PLACED
place_inst -name b515 -location {5236.381 12242.848} -status PLACED
place_inst -name r516_0 -location {5236.840 12324.944} -status PLACED
place_inst -name b516 -location {5235.300 12407.040} -status PLACED
place_inst -name r517_0 -location {5237.880 12281.304} -status PLACED
place_inst -name r517_1 -location {5124.828 12266.040} -status PLACED
place_inst -name r517_2 -location {4996.512 12266.040} -status PLACED
place_inst -name r517_3 -location {4881.480 12279.324} -status PLACED
place_inst -name b517 -location {4882.080 12407.040} -status PLACED
place_inst -name r518_0 -location {4882.080 12324.944} -status PLACED
place_inst -name b518 -location {4882.080 12242.848} -status PLACED
place_inst -name b519 -location {12640.320 10169.248} -status PLACED
place_inst -name r520_0 -location {12640.320 10051.359} -status PLACED
place_inst -name r520_1 -location {12640.320 9933.470} -status PLACED
place_inst -name b520 -location {12640.320 9815.581} -status PLACED
place_inst -name b521 -location {12640.800 9814.500} -status PLACED
place_inst -name r522_0 -location {12640.800 9800.520} -status PLACED
place_inst -name r522_1 -location {12640.800 9509.880} -status PLACED
place_inst -name r522_2 -location {12640.800 9405.269} -status PLACED
place_inst -name r522_3 -location {12640.800 9268.858} -status PLACED
place_inst -name b522 -location {12640.800 9132.448} -status PLACED
place_inst -name r523_0 -location {12757.900 10169.248} -status PLACED
place_inst -name r523_1 -location {12875.959 10169.248} -status PLACED
place_inst -name b523 -location {12994.019 10169.248} -status PLACED
place_inst -name r524_0 -location {12993.560 10251.344} -status PLACED
place_inst -name b524 -location {12995.100 10333.440} -status PLACED
place_inst -name r525_0 -location {13005.300 10216.524} -status PLACED
place_inst -name r525_1 -location {13109.532 10192.440} -status PLACED
place_inst -name r525_2 -location {13237.848 10192.440} -status PLACED
place_inst -name r525_3 -location {13350.900 10207.704} -status PLACED
place_inst -name b525 -location {13348.320 10333.440} -status PLACED
place_inst -name r526_0 -location {13348.320 10251.344} -status PLACED
place_inst -name b526 -location {13348.320 10169.248} -status PLACED
place_inst -name b527 -location {4881.600 10169.248} -status PLACED
place_inst -name r528_0 -location {4881.600 10051.359} -status PLACED
place_inst -name r528_1 -location {4881.600 9933.470} -status PLACED
place_inst -name b528 -location {4881.600 9815.581} -status PLACED
place_inst -name b529 -location {4881.120 9814.500} -status PLACED
place_inst -name r530_0 -location {4881.120 9800.520} -status PLACED
place_inst -name r530_1 -location {4881.120 9509.880} -status PLACED
place_inst -name r530_2 -location {4881.120 9405.269} -status PLACED
place_inst -name r530_3 -location {4881.120 9268.858} -status PLACED
place_inst -name b530 -location {4881.120 9132.448} -status PLACED
place_inst -name r531_0 -location {4764.020 10169.248} -status PLACED
place_inst -name r531_1 -location {4645.961 10169.248} -status PLACED
place_inst -name b531 -location {4527.901 10169.248} -status PLACED
place_inst -name r532_0 -location {4528.360 10251.344} -status PLACED
place_inst -name b532 -location {4526.820 10333.440} -status PLACED
place_inst -name r533_0 -location {4529.400 10207.704} -status PLACED
place_inst -name r533_1 -location {4416.348 10192.440} -status PLACED
place_inst -name r533_2 -location {4288.032 10192.440} -status PLACED
place_inst -name r533_3 -location {4173.000 10205.724} -status PLACED
place_inst -name b533 -location {4173.600 10333.440} -status PLACED
place_inst -name r534_0 -location {4173.600 10251.344} -status PLACED
place_inst -name b534 -location {4173.600 10169.248} -status PLACED
place_inst -name b535 -location {5153.760 2046.011} -status PLACED
place_inst -name r536_0 -location {5153.760 1903.029} -status PLACED
place_inst -name r536_1 -location {5153.760 1760.047} -status PLACED
place_inst -name r536_2 -location {5153.760 1617.064} -status PLACED
place_inst -name r536_3 -location {5153.760 1474.082} -status PLACED
place_inst -name b536 -location {5153.760 1331.100} -status PLACED
place_inst -name r537_0 -location {5009.568 1331.560} -status PLACED
place_inst -name r537_1 -location {4865.376 1331.560} -status PLACED
place_inst -name r537_2 -location {4721.184 1329.560} -status PLACED
place_inst -name r537_3 -location {4576.992 1329.560} -status PLACED
place_inst -name b537 -location {4432.800 1330.016} -status PLACED
place_inst -name b538 -location {4432.800 1252.832} -status PLACED
place_inst -name r539_0 -location {5011.372 2046.011} -status PLACED
place_inst -name r539_1 -location {4866.744 2046.011} -status PLACED
place_inst -name r539_2 -location {4714.680 2046.011} -status PLACED
place_inst -name r539_3 -location {4559.160 2046.011} -status PLACED
place_inst -name b539 -location {4432.860 2046.011} -status PLACED
place_inst -name r540_0 -location {4431.320 2135.405} -status PLACED
place_inst -name b540 -location {4431.780 2224.800} -status PLACED
place_inst -name r541_0 -location {4287.620 2224.800} -status PLACED
place_inst -name r541_1 -location {4143.461 2224.800} -status PLACED
place_inst -name r541_2 -location {3999.301 2224.800} -status PLACED
place_inst -name r541_3 -location {3855.142 2224.800} -status PLACED
place_inst -name b541 -location {3710.982 2224.800} -status PLACED
place_inst -name b542 -location {3710.982 2228.563} -status PLACED
place_inst -name r543_0 -location {13955.138 2228.563} -status PLACED
place_inst -name r543_1 -location {14099.339 2228.563} -status PLACED
place_inst -name r543_2 -location {14243.539 2228.563} -status PLACED
place_inst -name r543_3 -location {14387.740 2228.563} -status PLACED
place_inst -name b543 -location {14531.940 2228.563} -status PLACED
place_inst -name b544 -location {14533.020 2224.800} -status PLACED
place_inst -name r545_0 -location {14674.461 2224.800} -status PLACED
place_inst -name r545_1 -location {14815.903 2224.800} -status PLACED
place_inst -name r545_2 -location {14957.344 2224.800} -status PLACED
place_inst -name r545_3 -location {15098.785 2224.800} -status PLACED
place_inst -name r545_4 -location {15240.227 2224.800} -status PLACED
place_inst -name b545 -location {15381.668 2224.800} -status PLACED
place_inst -name r546_0 -location {15381.668 2122.420} -status PLACED
place_inst -name b546 -location {15381.668 2020.040} -status PLACED
place_inst -name b547 -location {11931.840 3948.448} -status PLACED
place_inst -name r548_0 -location {11931.840 3830.559} -status PLACED
place_inst -name r548_1 -location {11931.840 3712.670} -status PLACED
place_inst -name b548 -location {11931.840 3594.781} -status PLACED
place_inst -name b549 -location {11932.320 3593.700} -status PLACED
place_inst -name r550_0 -location {11932.320 3579.720} -status PLACED
place_inst -name r550_1 -location {11932.320 3289.080} -status PLACED
place_inst -name r550_2 -location {11932.320 3184.469} -status PLACED
place_inst -name r550_3 -location {11932.320 3048.058} -status PLACED
place_inst -name b550 -location {11932.320 2911.648} -status PLACED
place_inst -name r551_0 -location {12049.420 3948.448} -status PLACED
place_inst -name r551_1 -location {12167.479 3948.448} -status PLACED
place_inst -name b551 -location {12285.539 3948.448} -status PLACED
place_inst -name r552_0 -location {12285.080 4030.544} -status PLACED
place_inst -name b552 -location {12286.620 4112.640} -status PLACED
place_inst -name r553_0 -location {12296.820 3995.724} -status PLACED
place_inst -name r553_1 -location {12401.052 3971.640} -status PLACED
place_inst -name r553_2 -location {12529.368 3971.640} -status PLACED
place_inst -name r553_3 -location {12642.420 3986.904} -status PLACED
place_inst -name b553 -location {12639.840 4112.640} -status PLACED
place_inst -name r554_0 -location {12639.840 4030.544} -status PLACED
place_inst -name b554 -location {12639.840 3948.448} -status PLACED
place_inst -name b555 -location {5590.080 3948.448} -status PLACED
place_inst -name r556_0 -location {5590.080 3830.559} -status PLACED
place_inst -name r556_1 -location {5590.080 3712.670} -status PLACED
place_inst -name b556 -location {5590.080 3594.781} -status PLACED
place_inst -name b557 -location {5589.600 3593.700} -status PLACED
place_inst -name r558_0 -location {5589.600 3579.720} -status PLACED
place_inst -name r558_1 -location {5589.600 3289.080} -status PLACED
place_inst -name r558_2 -location {5589.600 3184.469} -status PLACED
place_inst -name r558_3 -location {5589.600 3048.058} -status PLACED
place_inst -name b558 -location {5589.600 2911.648} -status PLACED
place_inst -name r559_0 -location {5472.500 3948.448} -status PLACED
place_inst -name r559_1 -location {5354.441 3948.448} -status PLACED
place_inst -name b559 -location {5236.381 3948.448} -status PLACED
place_inst -name r560_0 -location {5236.840 4030.544} -status PLACED
place_inst -name b560 -location {5235.300 4112.640} -status PLACED
place_inst -name r561_0 -location {5237.880 3986.904} -status PLACED
place_inst -name r561_1 -location {5124.828 3971.640} -status PLACED
place_inst -name r561_2 -location {4996.512 3971.640} -status PLACED
place_inst -name r561_3 -location {4881.480 3984.924} -status PLACED
place_inst -name b561 -location {4882.080 4112.640} -status PLACED
place_inst -name r562_0 -location {4882.080 4030.544} -status PLACED
place_inst -name b562 -location {4882.080 3948.448} -status PLACED
place_inst -name b563 -location {12640.320 6022.048} -status PLACED
place_inst -name r564_0 -location {12640.320 5904.159} -status PLACED
place_inst -name r564_1 -location {12640.320 5786.270} -status PLACED
place_inst -name b564 -location {12640.320 5668.381} -status PLACED
place_inst -name b565 -location {12640.800 5667.300} -status PLACED
place_inst -name r566_0 -location {12640.800 5653.320} -status PLACED
place_inst -name r566_1 -location {12640.800 5362.680} -status PLACED
place_inst -name r566_2 -location {12640.800 5258.069} -status PLACED
place_inst -name r566_3 -location {12640.800 5121.658} -status PLACED
place_inst -name b566 -location {12640.800 4985.248} -status PLACED
place_inst -name r567_0 -location {12757.900 6022.048} -status PLACED
place_inst -name r567_1 -location {12875.959 6022.048} -status PLACED
place_inst -name b567 -location {12994.019 6022.048} -status PLACED
place_inst -name r568_0 -location {12993.560 6104.144} -status PLACED
place_inst -name b568 -location {12995.100 6186.240} -status PLACED
place_inst -name r569_0 -location {13005.300 6069.324} -status PLACED
place_inst -name r569_1 -location {13109.532 6045.240} -status PLACED
place_inst -name r569_2 -location {13237.848 6045.240} -status PLACED
place_inst -name r569_3 -location {13350.900 6060.504} -status PLACED
place_inst -name b569 -location {13348.320 6186.240} -status PLACED
place_inst -name r570_0 -location {13348.320 6104.144} -status PLACED
place_inst -name b570 -location {13348.320 6022.048} -status PLACED
place_inst -name b571 -location {4881.600 6022.048} -status PLACED
place_inst -name r572_0 -location {4881.600 5904.159} -status PLACED
place_inst -name r572_1 -location {4881.600 5786.270} -status PLACED
place_inst -name b572 -location {4881.600 5668.381} -status PLACED
place_inst -name b573 -location {4881.120 5667.300} -status PLACED
place_inst -name r574_0 -location {4881.120 5653.320} -status PLACED
place_inst -name r574_1 -location {4881.120 5362.680} -status PLACED
place_inst -name r574_2 -location {4881.120 5258.069} -status PLACED
place_inst -name r574_3 -location {4881.120 5121.658} -status PLACED
place_inst -name b574 -location {4881.120 4985.248} -status PLACED
place_inst -name r575_0 -location {4764.020 6022.048} -status PLACED
place_inst -name r575_1 -location {4645.961 6022.048} -status PLACED
place_inst -name b575 -location {4527.901 6022.048} -status PLACED
place_inst -name r576_0 -location {4528.360 6104.144} -status PLACED
place_inst -name b576 -location {4526.820 6186.240} -status PLACED
place_inst -name r577_0 -location {4529.400 6060.504} -status PLACED
place_inst -name r577_1 -location {4416.348 6045.240} -status PLACED
place_inst -name r577_2 -location {4288.032 6045.240} -status PLACED
place_inst -name r577_3 -location {4173.000 6058.524} -status PLACED
place_inst -name b577 -location {4173.600 6186.240} -status PLACED
place_inst -name r578_0 -location {4173.600 6104.144} -status PLACED
place_inst -name b578 -location {4173.600 6022.048} -status PLACED
place_inst -name b579 -location {13348.800 8095.648} -status PLACED
place_inst -name r580_0 -location {13348.800 7977.759} -status PLACED
place_inst -name r580_1 -location {13348.800 7859.870} -status PLACED
place_inst -name b580 -location {13348.800 7741.981} -status PLACED
place_inst -name b581 -location {13349.280 7740.900} -status PLACED
place_inst -name r582_0 -location {13349.280 7726.920} -status PLACED
place_inst -name r582_1 -location {13349.280 7436.280} -status PLACED
place_inst -name r582_2 -location {13349.280 7331.669} -status PLACED
place_inst -name r582_3 -location {13349.280 7195.258} -status PLACED
place_inst -name b582 -location {13349.280 7058.848} -status PLACED
place_inst -name r583_0 -location {13466.380 8095.648} -status PLACED
place_inst -name r583_1 -location {13584.439 8095.648} -status PLACED
place_inst -name b583 -location {13702.499 8095.648} -status PLACED
place_inst -name r584_0 -location {13702.040 8177.744} -status PLACED
place_inst -name b584 -location {13703.580 8259.840} -status PLACED
place_inst -name r585_0 -location {13713.780 8142.924} -status PLACED
place_inst -name r585_1 -location {13818.012 8118.840} -status PLACED
place_inst -name r585_2 -location {13946.328 8118.840} -status PLACED
place_inst -name r585_3 -location {14059.380 8134.104} -status PLACED
place_inst -name b585 -location {14056.800 8259.840} -status PLACED
place_inst -name r586_0 -location {14056.800 8177.744} -status PLACED
place_inst -name b586 -location {14056.800 8095.648} -status PLACED
place_inst -name b587 -location {4173.120 8095.648} -status PLACED
place_inst -name r588_0 -location {4173.120 7977.759} -status PLACED
place_inst -name r588_1 -location {4173.120 7859.870} -status PLACED
place_inst -name b588 -location {4173.120 7741.981} -status PLACED
place_inst -name b589 -location {4172.640 7740.900} -status PLACED
place_inst -name r590_0 -location {4172.640 7726.920} -status PLACED
place_inst -name r590_1 -location {4172.640 7436.280} -status PLACED
place_inst -name r590_2 -location {4172.640 7331.669} -status PLACED
place_inst -name r590_3 -location {4172.640 7195.258} -status PLACED
place_inst -name b590 -location {4172.640 7058.848} -status PLACED
place_inst -name r591_0 -location {4055.540 8095.648} -status PLACED
place_inst -name r591_1 -location {3937.481 8095.648} -status PLACED
place_inst -name b591 -location {3819.421 8095.648} -status PLACED
place_inst -name r592_0 -location {3819.880 8177.744} -status PLACED
place_inst -name b592 -location {3818.340 8259.840} -status PLACED
place_inst -name r593_0 -location {3820.920 8134.104} -status PLACED
place_inst -name r593_1 -location {3707.868 8118.840} -status PLACED
place_inst -name r593_2 -location {3579.552 8118.840} -status PLACED
place_inst -name r593_3 -location {3464.520 8132.124} -status PLACED
place_inst -name b593 -location {3465.120 8259.840} -status PLACED
place_inst -name r594_0 -location {3465.120 8177.744} -status PLACED
place_inst -name b594 -location {3465.120 8095.648} -status PLACED
place_inst -name r595_0 -location {5009.662 15327.917} -status PLACED
place_inst -name r595_1 -location {4865.461 15327.917} -status PLACED
place_inst -name r595_2 -location {4721.261 15327.917} -status PLACED
place_inst -name r595_3 -location {4577.060 15327.917} -status PLACED
place_inst -name b595 -location {4432.860 15327.917} -status PLACED
place_inst -name b596 -location {4431.780 15331.680} -status PLACED
place_inst -name r597_0 -location {4287.620 15331.680} -status PLACED
place_inst -name r597_1 -location {4143.461 15331.680} -status PLACED
place_inst -name r597_2 -location {3999.301 15331.680} -status PLACED
place_inst -name r597_3 -location {3855.142 15331.680} -status PLACED
place_inst -name b597 -location {3710.982 15331.680} -status PLACED
place_inst -name b598 -location {3710.982 15327.917} -status PLACED
place_inst -name b599 -location {5222.880 15889.189} -status PLACED
place_inst -name r600_0 -location {5222.880 16001.253} -status PLACED
place_inst -name r600_1 -location {5222.880 16113.316} -status PLACED
place_inst -name b600 -location {5222.880 16225.380} -status PLACED
place_inst -name r601_0 -location {5091.200 16224.920} -status PLACED
place_inst -name r601_1 -location {4959.520 16224.920} -status PLACED
place_inst -name r601_2 -location {4827.840 16226.920} -status PLACED
place_inst -name r601_3 -location {4696.160 16226.920} -status PLACED
place_inst -name r601_4 -location {4564.480 16226.920} -status PLACED
place_inst -name b601 -location {4432.800 16226.464} -status PLACED
place_inst -name b602 -location {4432.800 16303.648} -status PLACED
place_inst -name r603_0 -location {13955.138 15327.917} -status PLACED
place_inst -name r603_1 -location {14099.339 15327.917} -status PLACED
place_inst -name r603_2 -location {14243.539 15327.917} -status PLACED
place_inst -name r603_3 -location {14387.740 15327.917} -status PLACED
place_inst -name b603 -location {14531.940 15327.917} -status PLACED
place_inst -name b604 -location {14533.020 15331.680} -status PLACED
place_inst -name r605_0 -location {14674.461 15331.680} -status PLACED
place_inst -name r605_1 -location {14815.903 15331.680} -status PLACED
place_inst -name r605_2 -location {14957.344 15331.680} -status PLACED
place_inst -name r605_3 -location {15098.785 15331.680} -status PLACED
place_inst -name r605_4 -location {15240.227 15331.680} -status PLACED
place_inst -name b605 -location {15381.668 15331.680} -status PLACED
place_inst -name r606_0 -location {15381.668 15434.060} -status PLACED
place_inst -name b606 -location {15381.668 15536.440} -status PLACED
place_inst -name b607 -location {11931.840 14316.448} -status PLACED
place_inst -name r608_0 -location {11931.840 14198.559} -status PLACED
place_inst -name r608_1 -location {11931.840 14080.670} -status PLACED
place_inst -name b608 -location {11931.840 13962.781} -status PLACED
place_inst -name b609 -location {11932.320 13961.700} -status PLACED
place_inst -name r610_0 -location {11932.320 13947.720} -status PLACED
place_inst -name r610_1 -location {11932.320 13657.080} -status PLACED
place_inst -name r610_2 -location {11932.320 13552.469} -status PLACED
place_inst -name r610_3 -location {11932.320 13416.058} -status PLACED
place_inst -name b610 -location {11932.320 13279.648} -status PLACED
place_inst -name r611_0 -location {12049.420 14316.448} -status PLACED
place_inst -name r611_1 -location {12167.479 14316.448} -status PLACED
place_inst -name b611 -location {12285.539 14316.448} -status PLACED
place_inst -name r612_0 -location {12285.080 14398.544} -status PLACED
place_inst -name b612 -location {12286.620 14480.640} -status PLACED
place_inst -name r613_0 -location {12296.820 14363.724} -status PLACED
place_inst -name r613_1 -location {12401.052 14339.640} -status PLACED
place_inst -name r613_2 -location {12529.368 14339.640} -status PLACED
place_inst -name r613_3 -location {12642.420 14354.904} -status PLACED
place_inst -name b613 -location {12639.840 14480.640} -status PLACED
place_inst -name r614_0 -location {12639.840 14398.544} -status PLACED
place_inst -name b614 -location {12639.840 14316.448} -status PLACED
place_inst -name b615 -location {5590.080 14316.448} -status PLACED
place_inst -name r616_0 -location {5590.080 14198.559} -status PLACED
place_inst -name r616_1 -location {5590.080 14080.670} -status PLACED
place_inst -name b616 -location {5590.080 13962.781} -status PLACED
place_inst -name b617 -location {5589.600 13961.700} -status PLACED
place_inst -name r618_0 -location {5589.600 13947.720} -status PLACED
place_inst -name r618_1 -location {5589.600 13657.080} -status PLACED
place_inst -name r618_2 -location {5589.600 13552.469} -status PLACED
place_inst -name r618_3 -location {5589.600 13416.058} -status PLACED
place_inst -name b618 -location {5589.600 13279.648} -status PLACED
place_inst -name r619_0 -location {5472.500 14316.448} -status PLACED
place_inst -name r619_1 -location {5354.441 14316.448} -status PLACED
place_inst -name b619 -location {5236.381 14316.448} -status PLACED
place_inst -name r620_0 -location {5236.840 14398.544} -status PLACED
place_inst -name b620 -location {5235.300 14480.640} -status PLACED
place_inst -name r621_0 -location {5237.880 14354.904} -status PLACED
place_inst -name r621_1 -location {5124.828 14339.640} -status PLACED
place_inst -name r621_2 -location {4996.512 14339.640} -status PLACED
place_inst -name r621_3 -location {4881.480 14352.924} -status PLACED
place_inst -name b621 -location {4882.080 14480.640} -status PLACED
place_inst -name r622_0 -location {4882.080 14398.544} -status PLACED
place_inst -name b622 -location {4882.080 14316.448} -status PLACED
place_inst -name b623 -location {12640.320 12242.848} -status PLACED
place_inst -name r624_0 -location {12640.320 12124.959} -status PLACED
place_inst -name r624_1 -location {12640.320 12007.070} -status PLACED
place_inst -name b624 -location {12640.320 11889.181} -status PLACED
place_inst -name b625 -location {12640.800 11888.100} -status PLACED
place_inst -name r626_0 -location {12640.800 11874.120} -status PLACED
place_inst -name r626_1 -location {12640.800 11583.480} -status PLACED
place_inst -name r626_2 -location {12640.800 11478.869} -status PLACED
place_inst -name r626_3 -location {12640.800 11342.458} -status PLACED
place_inst -name b626 -location {12640.800 11206.048} -status PLACED
place_inst -name r627_0 -location {12757.900 12242.848} -status PLACED
place_inst -name r627_1 -location {12875.959 12242.848} -status PLACED
place_inst -name b627 -location {12994.019 12242.848} -status PLACED
place_inst -name r628_0 -location {12993.560 12324.944} -status PLACED
place_inst -name b628 -location {12995.100 12407.040} -status PLACED
place_inst -name r629_0 -location {13005.300 12290.124} -status PLACED
place_inst -name r629_1 -location {13109.532 12266.040} -status PLACED
place_inst -name r629_2 -location {13237.848 12266.040} -status PLACED
place_inst -name r629_3 -location {13350.900 12281.304} -status PLACED
place_inst -name b629 -location {13348.320 12407.040} -status PLACED
place_inst -name r630_0 -location {13348.320 12324.944} -status PLACED
place_inst -name b630 -location {13348.320 12242.848} -status PLACED
place_inst -name b631 -location {4881.600 12242.848} -status PLACED
place_inst -name r632_0 -location {4881.600 12124.959} -status PLACED
place_inst -name r632_1 -location {4881.600 12007.070} -status PLACED
place_inst -name b632 -location {4881.600 11889.181} -status PLACED
place_inst -name b633 -location {4881.120 11888.100} -status PLACED
place_inst -name r634_0 -location {4881.120 11874.120} -status PLACED
place_inst -name r634_1 -location {4881.120 11583.480} -status PLACED
place_inst -name r634_2 -location {4881.120 11478.869} -status PLACED
place_inst -name r634_3 -location {4881.120 11342.458} -status PLACED
place_inst -name b634 -location {4881.120 11206.048} -status PLACED
place_inst -name r635_0 -location {4764.020 12242.848} -status PLACED
place_inst -name r635_1 -location {4645.961 12242.848} -status PLACED
place_inst -name b635 -location {4527.901 12242.848} -status PLACED
place_inst -name r636_0 -location {4528.360 12324.944} -status PLACED
place_inst -name b636 -location {4526.820 12407.040} -status PLACED
place_inst -name r637_0 -location {4529.400 12281.304} -status PLACED
place_inst -name r637_1 -location {4416.348 12266.040} -status PLACED
place_inst -name r637_2 -location {4288.032 12266.040} -status PLACED
place_inst -name r637_3 -location {4173.000 12279.324} -status PLACED
place_inst -name b637 -location {4173.600 12407.040} -status PLACED
place_inst -name r638_0 -location {4173.600 12324.944} -status PLACED
place_inst -name b638 -location {4173.600 12242.848} -status PLACED
place_inst -name b639 -location {13348.800 10169.248} -status PLACED
place_inst -name r640_0 -location {13348.800 10051.359} -status PLACED
place_inst -name r640_1 -location {13348.800 9933.470} -status PLACED
place_inst -name b640 -location {13348.800 9815.581} -status PLACED
place_inst -name b641 -location {13349.280 9814.500} -status PLACED
place_inst -name r642_0 -location {13349.280 9800.520} -status PLACED
place_inst -name r642_1 -location {13349.280 9509.880} -status PLACED
place_inst -name r642_2 -location {13349.280 9405.269} -status PLACED
place_inst -name r642_3 -location {13349.280 9268.858} -status PLACED
place_inst -name b642 -location {13349.280 9132.448} -status PLACED
place_inst -name r643_0 -location {13466.380 10169.248} -status PLACED
place_inst -name r643_1 -location {13584.439 10169.248} -status PLACED
place_inst -name b643 -location {13702.499 10169.248} -status PLACED
place_inst -name r644_0 -location {13702.040 10251.344} -status PLACED
place_inst -name b644 -location {13703.580 10333.440} -status PLACED
place_inst -name r645_0 -location {13713.780 10216.524} -status PLACED
place_inst -name r645_1 -location {13818.012 10192.440} -status PLACED
place_inst -name r645_2 -location {13946.328 10192.440} -status PLACED
place_inst -name r645_3 -location {14059.380 10207.704} -status PLACED
place_inst -name b645 -location {14056.800 10333.440} -status PLACED
place_inst -name r646_0 -location {14056.800 10251.344} -status PLACED
place_inst -name b646 -location {14056.800 10169.248} -status PLACED
place_inst -name b647 -location {4173.120 10169.248} -status PLACED
place_inst -name r648_0 -location {4173.120 10051.359} -status PLACED
place_inst -name r648_1 -location {4173.120 9933.470} -status PLACED
place_inst -name b648 -location {4173.120 9815.581} -status PLACED
place_inst -name b649 -location {4172.640 9814.500} -status PLACED
place_inst -name r650_0 -location {4172.640 9800.520} -status PLACED
place_inst -name r650_1 -location {4172.640 9509.880} -status PLACED
place_inst -name r650_2 -location {4172.640 9405.269} -status PLACED
place_inst -name r650_3 -location {4172.640 9268.858} -status PLACED
place_inst -name b650 -location {4172.640 9132.448} -status PLACED
place_inst -name r651_0 -location {4055.540 10169.248} -status PLACED
place_inst -name r651_1 -location {3937.481 10169.248} -status PLACED
place_inst -name b651 -location {3819.421 10169.248} -status PLACED
place_inst -name r652_0 -location {3819.880 10251.344} -status PLACED
place_inst -name b652 -location {3818.340 10333.440} -status PLACED
place_inst -name r653_0 -location {3820.920 10207.704} -status PLACED
place_inst -name r653_1 -location {3707.868 10192.440} -status PLACED
place_inst -name r653_2 -location {3579.552 10192.440} -status PLACED
place_inst -name r653_3 -location {3464.520 10205.724} -status PLACED
place_inst -name b653 -location {3465.120 10333.440} -status PLACED
place_inst -name r654_0 -location {3465.120 10251.344} -status PLACED
place_inst -name b654 -location {3465.120 10169.248} -status PLACED
place_inst -name r655_0 -location {3566.782 2228.563} -status PLACED
place_inst -name r655_1 -location {3422.581 2228.563} -status PLACED
place_inst -name r655_2 -location {3278.381 2228.563} -status PLACED
place_inst -name r655_3 -location {3134.180 2228.563} -status PLACED
place_inst -name b655 -location {2989.980 2228.563} -status PLACED
place_inst -name b656 -location {2988.900 2224.800} -status PLACED
place_inst -name r657_0 -location {2847.459 2224.800} -status PLACED
place_inst -name r657_1 -location {2706.017 2224.800} -status PLACED
place_inst -name r657_2 -location {2564.576 2224.800} -status PLACED
place_inst -name r657_3 -location {2423.135 2224.800} -status PLACED
place_inst -name r657_4 -location {2281.693 2224.800} -status PLACED
place_inst -name b657 -location {2140.252 2224.800} -status PLACED
place_inst -name r658_0 -location {2140.252 2122.420} -status PLACED
place_inst -name b658 -location {2140.252 2020.040} -status PLACED
place_inst -name r659_0 -location {15283.234 2020.040} -status PLACED
place_inst -name b659 -location {15184.800 2020.040} -status PLACED
place_inst -name r660_0 -location {15184.800 1882.252} -status PLACED
place_inst -name r660_1 -location {15184.800 1744.464} -status PLACED
place_inst -name r660_2 -location {15184.800 1606.676} -status PLACED
place_inst -name r660_3 -location {15184.800 1468.888} -status PLACED
place_inst -name b660 -location {15184.800 1331.100} -status PLACED
place_inst -name r661_0 -location {15316.480 1331.560} -status PLACED
place_inst -name r661_1 -location {15448.160 1331.560} -status PLACED
place_inst -name r661_2 -location {15579.840 1329.560} -status PLACED
place_inst -name r661_3 -location {15711.520 1329.560} -status PLACED
place_inst -name r661_4 -location {15843.200 1329.560} -status PLACED
place_inst -name b661 -location {15974.880 1330.016} -status PLACED
place_inst -name b662 -location {15974.880 1252.832} -status PLACED
place_inst -name b663 -location {12640.320 3948.448} -status PLACED
place_inst -name r664_0 -location {12640.320 3830.559} -status PLACED
place_inst -name r664_1 -location {12640.320 3712.670} -status PLACED
place_inst -name b664 -location {12640.320 3594.781} -status PLACED
place_inst -name b665 -location {12640.800 3593.700} -status PLACED
place_inst -name r666_0 -location {12640.800 3579.720} -status PLACED
place_inst -name r666_1 -location {12640.800 3289.080} -status PLACED
place_inst -name r666_2 -location {12640.800 3184.469} -status PLACED
place_inst -name r666_3 -location {12640.800 3048.058} -status PLACED
place_inst -name b666 -location {12640.800 2911.648} -status PLACED
place_inst -name r667_0 -location {12757.900 3948.448} -status PLACED
place_inst -name r667_1 -location {12875.959 3948.448} -status PLACED
place_inst -name b667 -location {12994.019 3948.448} -status PLACED
place_inst -name r668_0 -location {12993.560 4030.544} -status PLACED
place_inst -name b668 -location {12995.100 4112.640} -status PLACED
place_inst -name r669_0 -location {13005.300 3995.724} -status PLACED
place_inst -name r669_1 -location {13109.532 3971.640} -status PLACED
place_inst -name r669_2 -location {13237.848 3971.640} -status PLACED
place_inst -name r669_3 -location {13350.900 3986.904} -status PLACED
place_inst -name b669 -location {13348.320 4112.640} -status PLACED
place_inst -name r670_0 -location {13348.320 4030.544} -status PLACED
place_inst -name b670 -location {13348.320 3948.448} -status PLACED
place_inst -name b671 -location {4881.600 3948.448} -status PLACED
place_inst -name r672_0 -location {4881.600 3830.559} -status PLACED
place_inst -name r672_1 -location {4881.600 3712.670} -status PLACED
place_inst -name b672 -location {4881.600 3594.781} -status PLACED
place_inst -name b673 -location {4881.120 3593.700} -status PLACED
place_inst -name r674_0 -location {4881.120 3579.720} -status PLACED
place_inst -name r674_1 -location {4881.120 3289.080} -status PLACED
place_inst -name r674_2 -location {4881.120 3184.469} -status PLACED
place_inst -name r674_3 -location {4881.120 3048.058} -status PLACED
place_inst -name b674 -location {4881.120 2911.648} -status PLACED
place_inst -name r675_0 -location {4764.020 3948.448} -status PLACED
place_inst -name r675_1 -location {4645.961 3948.448} -status PLACED
place_inst -name b675 -location {4527.901 3948.448} -status PLACED
place_inst -name r676_0 -location {4528.360 4030.544} -status PLACED
place_inst -name b676 -location {4526.820 4112.640} -status PLACED
place_inst -name r677_0 -location {4529.400 3986.904} -status PLACED
place_inst -name r677_1 -location {4416.348 3971.640} -status PLACED
place_inst -name r677_2 -location {4288.032 3971.640} -status PLACED
place_inst -name r677_3 -location {4173.000 3984.924} -status PLACED
place_inst -name b677 -location {4173.600 4112.640} -status PLACED
place_inst -name r678_0 -location {4173.600 4030.544} -status PLACED
place_inst -name b678 -location {4173.600 3948.448} -status PLACED
place_inst -name b679 -location {13348.800 6022.048} -status PLACED
place_inst -name r680_0 -location {13348.800 5904.159} -status PLACED
place_inst -name r680_1 -location {13348.800 5786.270} -status PLACED
place_inst -name b680 -location {13348.800 5668.381} -status PLACED
place_inst -name b681 -location {13349.280 5667.300} -status PLACED
place_inst -name r682_0 -location {13349.280 5653.320} -status PLACED
place_inst -name r682_1 -location {13349.280 5362.680} -status PLACED
place_inst -name r682_2 -location {13349.280 5258.069} -status PLACED
place_inst -name r682_3 -location {13349.280 5121.658} -status PLACED
place_inst -name b682 -location {13349.280 4985.248} -status PLACED
place_inst -name r683_0 -location {13466.380 6022.048} -status PLACED
place_inst -name r683_1 -location {13584.439 6022.048} -status PLACED
place_inst -name b683 -location {13702.499 6022.048} -status PLACED
place_inst -name r684_0 -location {13702.040 6104.144} -status PLACED
place_inst -name b684 -location {13703.580 6186.240} -status PLACED
place_inst -name r685_0 -location {13713.780 6069.324} -status PLACED
place_inst -name r685_1 -location {13818.012 6045.240} -status PLACED
place_inst -name r685_2 -location {13946.328 6045.240} -status PLACED
place_inst -name r685_3 -location {14059.380 6060.504} -status PLACED
place_inst -name b685 -location {14056.800 6186.240} -status PLACED
place_inst -name r686_0 -location {14056.800 6104.144} -status PLACED
place_inst -name b686 -location {14056.800 6022.048} -status PLACED
place_inst -name b687 -location {4173.120 6022.048} -status PLACED
place_inst -name r688_0 -location {4173.120 5904.159} -status PLACED
place_inst -name r688_1 -location {4173.120 5786.270} -status PLACED
place_inst -name b688 -location {4173.120 5668.381} -status PLACED
place_inst -name b689 -location {4172.640 5667.300} -status PLACED
place_inst -name r690_0 -location {4172.640 5653.320} -status PLACED
place_inst -name r690_1 -location {4172.640 5362.680} -status PLACED
place_inst -name r690_2 -location {4172.640 5258.069} -status PLACED
place_inst -name r690_3 -location {4172.640 5121.658} -status PLACED
place_inst -name b690 -location {4172.640 4985.248} -status PLACED
place_inst -name r691_0 -location {4055.540 6022.048} -status PLACED
place_inst -name r691_1 -location {3937.481 6022.048} -status PLACED
place_inst -name b691 -location {3819.421 6022.048} -status PLACED
place_inst -name r692_0 -location {3819.880 6104.144} -status PLACED
place_inst -name b692 -location {3818.340 6186.240} -status PLACED
place_inst -name r693_0 -location {3820.920 6060.504} -status PLACED
place_inst -name r693_1 -location {3707.868 6045.240} -status PLACED
place_inst -name r693_2 -location {3579.552 6045.240} -status PLACED
place_inst -name r693_3 -location {3464.520 6058.524} -status PLACED
place_inst -name b693 -location {3465.120 6186.240} -status PLACED
place_inst -name r694_0 -location {3465.120 6104.144} -status PLACED
place_inst -name b694 -location {3465.120 6022.048} -status PLACED
place_inst -name b695 -location {14057.280 8095.648} -status PLACED
place_inst -name r696_0 -location {14057.280 7977.759} -status PLACED
place_inst -name r696_1 -location {14057.280 7859.870} -status PLACED
place_inst -name b696 -location {14057.280 7741.981} -status PLACED
place_inst -name b697 -location {14057.760 7740.900} -status PLACED
place_inst -name r698_0 -location {14057.760 7726.920} -status PLACED
place_inst -name r698_1 -location {14057.760 7436.280} -status PLACED
place_inst -name r698_2 -location {14057.760 7331.669} -status PLACED
place_inst -name r698_3 -location {14057.760 7195.258} -status PLACED
place_inst -name b698 -location {14057.760 7058.848} -status PLACED
place_inst -name r699_0 -location {14174.860 8095.648} -status PLACED
place_inst -name r699_1 -location {14292.919 8095.648} -status PLACED
place_inst -name b699 -location {14410.979 8095.648} -status PLACED
place_inst -name r700_0 -location {14410.520 8177.744} -status PLACED
place_inst -name b700 -location {14412.060 8259.840} -status PLACED
place_inst -name r701_0 -location {14422.260 8142.924} -status PLACED
place_inst -name r701_1 -location {14526.492 8118.840} -status PLACED
place_inst -name r701_2 -location {14654.808 8118.840} -status PLACED
place_inst -name r701_3 -location {14767.860 8134.104} -status PLACED
place_inst -name b701 -location {14765.280 8259.840} -status PLACED
place_inst -name r702_0 -location {14765.280 8177.744} -status PLACED
place_inst -name b702 -location {14765.280 8095.648} -status PLACED
place_inst -name b703 -location {3464.640 8095.648} -status PLACED
place_inst -name r704_0 -location {3464.640 7977.759} -status PLACED
place_inst -name r704_1 -location {3464.640 7859.870} -status PLACED
place_inst -name b704 -location {3464.640 7741.981} -status PLACED
place_inst -name b705 -location {3464.160 7740.900} -status PLACED
place_inst -name r706_0 -location {3464.160 7726.920} -status PLACED
place_inst -name r706_1 -location {3464.160 7436.280} -status PLACED
place_inst -name r706_2 -location {3464.160 7331.669} -status PLACED
place_inst -name r706_3 -location {3464.160 7195.258} -status PLACED
place_inst -name b706 -location {3464.160 7058.848} -status PLACED
place_inst -name r707_0 -location {3347.060 8095.648} -status PLACED
place_inst -name r707_1 -location {3229.001 8095.648} -status PLACED
place_inst -name b707 -location {3110.941 8095.648} -status PLACED
place_inst -name r708_0 -location {3111.400 8177.744} -status PLACED
place_inst -name b708 -location {3109.860 8259.840} -status PLACED
place_inst -name r709_0 -location {3112.440 8134.104} -status PLACED
place_inst -name r709_1 -location {2999.388 8118.840} -status PLACED
place_inst -name r709_2 -location {2871.072 8118.840} -status PLACED
place_inst -name r709_3 -location {2756.040 8132.124} -status PLACED
place_inst -name b709 -location {2756.640 8259.840} -status PLACED
place_inst -name r710_0 -location {2756.640 8177.744} -status PLACED
place_inst -name b710 -location {2756.640 8095.648} -status PLACED
place_inst -name r711_0 -location {3566.782 15327.917} -status PLACED
place_inst -name r711_1 -location {3422.581 15327.917} -status PLACED
place_inst -name r711_2 -location {3278.381 15327.917} -status PLACED
place_inst -name r711_3 -location {3134.180 15327.917} -status PLACED
place_inst -name b711 -location {2989.980 15327.917} -status PLACED
place_inst -name b712 -location {2988.900 15331.680} -status PLACED
place_inst -name r713_0 -location {2847.459 15331.680} -status PLACED
place_inst -name r713_1 -location {2706.017 15331.680} -status PLACED
place_inst -name r713_2 -location {2564.576 15331.680} -status PLACED
place_inst -name r713_3 -location {2423.135 15331.680} -status PLACED
place_inst -name r713_4 -location {2281.693 15331.680} -status PLACED
place_inst -name b713 -location {2140.252 15331.680} -status PLACED
place_inst -name r714_0 -location {2140.252 15434.060} -status PLACED
place_inst -name b714 -location {2140.252 15536.440} -status PLACED
place_inst -name r715_0 -location {15283.234 15536.440} -status PLACED
place_inst -name b715 -location {15184.800 15536.440} -status PLACED
place_inst -name r716_0 -location {15184.800 15674.228} -status PLACED
place_inst -name r716_1 -location {15184.800 15812.016} -status PLACED
place_inst -name r716_2 -location {15184.800 15949.804} -status PLACED
place_inst -name r716_3 -location {15184.800 16087.592} -status PLACED
place_inst -name b716 -location {15184.800 16225.380} -status PLACED
place_inst -name r717_0 -location {15316.480 16224.920} -status PLACED
place_inst -name r717_1 -location {15448.160 16224.920} -status PLACED
place_inst -name r717_2 -location {15579.840 16226.920} -status PLACED
place_inst -name r717_3 -location {15711.520 16226.920} -status PLACED
place_inst -name r717_4 -location {15843.200 16226.920} -status PLACED
place_inst -name b717 -location {15974.880 16226.464} -status PLACED
place_inst -name b718 -location {15974.880 16303.648} -status PLACED
place_inst -name b719 -location {12640.320 14316.448} -status PLACED
place_inst -name r720_0 -location {12640.320 14198.559} -status PLACED
place_inst -name r720_1 -location {12640.320 14080.670} -status PLACED
place_inst -name b720 -location {12640.320 13962.781} -status PLACED
place_inst -name b721 -location {12640.800 13961.700} -status PLACED
place_inst -name r722_0 -location {12640.800 13947.720} -status PLACED
place_inst -name r722_1 -location {12640.800 13657.080} -status PLACED
place_inst -name r722_2 -location {12640.800 13552.469} -status PLACED
place_inst -name r722_3 -location {12640.800 13416.058} -status PLACED
place_inst -name b722 -location {12640.800 13279.648} -status PLACED
place_inst -name r723_0 -location {12757.900 14316.448} -status PLACED
place_inst -name r723_1 -location {12875.959 14316.448} -status PLACED
place_inst -name b723 -location {12994.019 14316.448} -status PLACED
place_inst -name r724_0 -location {12993.560 14398.544} -status PLACED
place_inst -name b724 -location {12995.100 14480.640} -status PLACED
place_inst -name r725_0 -location {13005.300 14363.724} -status PLACED
place_inst -name r725_1 -location {13109.532 14339.640} -status PLACED
place_inst -name r725_2 -location {13237.848 14339.640} -status PLACED
place_inst -name r725_3 -location {13350.900 14354.904} -status PLACED
place_inst -name b725 -location {13348.320 14480.640} -status PLACED
place_inst -name r726_0 -location {13348.320 14398.544} -status PLACED
place_inst -name b726 -location {13348.320 14316.448} -status PLACED
place_inst -name b727 -location {4881.600 14316.448} -status PLACED
place_inst -name r728_0 -location {4881.600 14198.559} -status PLACED
place_inst -name r728_1 -location {4881.600 14080.670} -status PLACED
place_inst -name b728 -location {4881.600 13962.781} -status PLACED
place_inst -name b729 -location {4881.120 13961.700} -status PLACED
place_inst -name r730_0 -location {4881.120 13947.720} -status PLACED
place_inst -name r730_1 -location {4881.120 13657.080} -status PLACED
place_inst -name r730_2 -location {4881.120 13552.469} -status PLACED
place_inst -name r730_3 -location {4881.120 13416.058} -status PLACED
place_inst -name b730 -location {4881.120 13279.648} -status PLACED
place_inst -name r731_0 -location {4764.020 14316.448} -status PLACED
place_inst -name r731_1 -location {4645.961 14316.448} -status PLACED
place_inst -name b731 -location {4527.901 14316.448} -status PLACED
place_inst -name r732_0 -location {4528.360 14398.544} -status PLACED
place_inst -name b732 -location {4526.820 14480.640} -status PLACED
place_inst -name r733_0 -location {4529.400 14354.904} -status PLACED
place_inst -name r733_1 -location {4416.348 14339.640} -status PLACED
place_inst -name r733_2 -location {4288.032 14339.640} -status PLACED
place_inst -name r733_3 -location {4173.000 14352.924} -status PLACED
place_inst -name b733 -location {4173.600 14480.640} -status PLACED
place_inst -name r734_0 -location {4173.600 14398.544} -status PLACED
place_inst -name b734 -location {4173.600 14316.448} -status PLACED
place_inst -name b735 -location {13348.800 12242.848} -status PLACED
place_inst -name r736_0 -location {13348.800 12124.959} -status PLACED
place_inst -name r736_1 -location {13348.800 12007.070} -status PLACED
place_inst -name b736 -location {13348.800 11889.181} -status PLACED
place_inst -name b737 -location {13349.280 11888.100} -status PLACED
place_inst -name r738_0 -location {13349.280 11874.120} -status PLACED
place_inst -name r738_1 -location {13349.280 11583.480} -status PLACED
place_inst -name r738_2 -location {13349.280 11478.869} -status PLACED
place_inst -name r738_3 -location {13349.280 11342.458} -status PLACED
place_inst -name b738 -location {13349.280 11206.048} -status PLACED
place_inst -name r739_0 -location {13466.380 12242.848} -status PLACED
place_inst -name r739_1 -location {13584.439 12242.848} -status PLACED
place_inst -name b739 -location {13702.499 12242.848} -status PLACED
place_inst -name r740_0 -location {13702.040 12324.944} -status PLACED
place_inst -name b740 -location {13703.580 12407.040} -status PLACED
place_inst -name r741_0 -location {13713.780 12290.124} -status PLACED
place_inst -name r741_1 -location {13818.012 12266.040} -status PLACED
place_inst -name r741_2 -location {13946.328 12266.040} -status PLACED
place_inst -name r741_3 -location {14059.380 12281.304} -status PLACED
place_inst -name b741 -location {14056.800 12407.040} -status PLACED
place_inst -name r742_0 -location {14056.800 12324.944} -status PLACED
place_inst -name b742 -location {14056.800 12242.848} -status PLACED
place_inst -name b743 -location {4173.120 12242.848} -status PLACED
place_inst -name r744_0 -location {4173.120 12124.959} -status PLACED
place_inst -name r744_1 -location {4173.120 12007.070} -status PLACED
place_inst -name b744 -location {4173.120 11889.181} -status PLACED
place_inst -name b745 -location {4172.640 11888.100} -status PLACED
place_inst -name r746_0 -location {4172.640 11874.120} -status PLACED
place_inst -name r746_1 -location {4172.640 11583.480} -status PLACED
place_inst -name r746_2 -location {4172.640 11478.869} -status PLACED
place_inst -name r746_3 -location {4172.640 11342.458} -status PLACED
place_inst -name b746 -location {4172.640 11206.048} -status PLACED
place_inst -name r747_0 -location {4055.540 12242.848} -status PLACED
place_inst -name r747_1 -location {3937.481 12242.848} -status PLACED
place_inst -name b747 -location {3819.421 12242.848} -status PLACED
place_inst -name r748_0 -location {3819.880 12324.944} -status PLACED
place_inst -name b748 -location {3818.340 12407.040} -status PLACED
place_inst -name r749_0 -location {3820.920 12281.304} -status PLACED
place_inst -name r749_1 -location {3707.868 12266.040} -status PLACED
place_inst -name r749_2 -location {3579.552 12266.040} -status PLACED
place_inst -name r749_3 -location {3464.520 12279.324} -status PLACED
place_inst -name b749 -location {3465.120 12407.040} -status PLACED
place_inst -name r750_0 -location {3465.120 12324.944} -status PLACED
place_inst -name b750 -location {3465.120 12242.848} -status PLACED
place_inst -name b751 -location {14057.280 10169.248} -status PLACED
place_inst -name r752_0 -location {14057.280 10051.359} -status PLACED
place_inst -name r752_1 -location {14057.280 9933.470} -status PLACED
place_inst -name b752 -location {14057.280 9815.581} -status PLACED
place_inst -name b753 -location {14057.760 9814.500} -status PLACED
place_inst -name r754_0 -location {14057.760 9800.520} -status PLACED
place_inst -name r754_1 -location {14057.760 9509.880} -status PLACED
place_inst -name r754_2 -location {14057.760 9405.269} -status PLACED
place_inst -name r754_3 -location {14057.760 9268.858} -status PLACED
place_inst -name b754 -location {14057.760 9132.448} -status PLACED
place_inst -name r755_0 -location {14174.860 10169.248} -status PLACED
place_inst -name r755_1 -location {14292.919 10169.248} -status PLACED
place_inst -name b755 -location {14410.979 10169.248} -status PLACED
place_inst -name r756_0 -location {14410.520 10251.344} -status PLACED
place_inst -name b756 -location {14412.060 10333.440} -status PLACED
place_inst -name r757_0 -location {14422.260 10216.524} -status PLACED
place_inst -name r757_1 -location {14526.492 10192.440} -status PLACED
place_inst -name r757_2 -location {14654.808 10192.440} -status PLACED
place_inst -name r757_3 -location {14767.860 10207.704} -status PLACED
place_inst -name b757 -location {14765.280 10333.440} -status PLACED
place_inst -name r758_0 -location {14765.280 10251.344} -status PLACED
place_inst -name b758 -location {14765.280 10169.248} -status PLACED
place_inst -name b759 -location {3464.640 10169.248} -status PLACED
place_inst -name r760_0 -location {3464.640 10051.359} -status PLACED
place_inst -name r760_1 -location {3464.640 9933.470} -status PLACED
place_inst -name b760 -location {3464.640 9815.581} -status PLACED
place_inst -name b761 -location {3464.160 9814.500} -status PLACED
place_inst -name r762_0 -location {3464.160 9800.520} -status PLACED
place_inst -name r762_1 -location {3464.160 9509.880} -status PLACED
place_inst -name r762_2 -location {3464.160 9405.269} -status PLACED
place_inst -name r762_3 -location {3464.160 9268.858} -status PLACED
place_inst -name b762 -location {3464.160 9132.448} -status PLACED
place_inst -name r763_0 -location {3347.060 10169.248} -status PLACED
place_inst -name r763_1 -location {3229.001 10169.248} -status PLACED
place_inst -name b763 -location {3110.941 10169.248} -status PLACED
place_inst -name r764_0 -location {3111.400 10251.344} -status PLACED
place_inst -name b764 -location {3109.860 10333.440} -status PLACED
place_inst -name r765_0 -location {3112.440 10207.704} -status PLACED
place_inst -name r765_1 -location {2999.388 10192.440} -status PLACED
place_inst -name r765_2 -location {2871.072 10192.440} -status PLACED
place_inst -name r765_3 -location {2756.040 10205.724} -status PLACED
place_inst -name b765 -location {2756.640 10333.440} -status PLACED
place_inst -name r766_0 -location {2756.640 10251.344} -status PLACED
place_inst -name b766 -location {2756.640 10169.248} -status PLACED
place_inst -name r767_0 -location {2238.686 2020.040} -status PLACED
place_inst -name b767 -location {2337.120 2020.040} -status PLACED
place_inst -name r768_0 -location {2337.120 1882.252} -status PLACED
place_inst -name r768_1 -location {2337.120 1744.464} -status PLACED
place_inst -name r768_2 -location {2337.120 1606.676} -status PLACED
place_inst -name r768_3 -location {2337.120 1468.888} -status PLACED
place_inst -name b768 -location {2337.120 1331.100} -status PLACED
place_inst -name r769_0 -location {2205.440 1331.560} -status PLACED
place_inst -name r769_1 -location {2073.760 1331.560} -status PLACED
place_inst -name r769_2 -location {1942.080 1329.560} -status PLACED
place_inst -name r769_3 -location {1810.400 1329.560} -status PLACED
place_inst -name r769_4 -location {1678.720 1329.560} -status PLACED
place_inst -name b769 -location {1547.040 1330.016} -status PLACED
place_inst -name b770 -location {1547.040 1252.832} -status PLACED
place_inst -name b771 -location {13348.800 3948.448} -status PLACED
place_inst -name r772_0 -location {13348.800 3830.559} -status PLACED
place_inst -name r772_1 -location {13348.800 3712.670} -status PLACED
place_inst -name b772 -location {13348.800 3594.781} -status PLACED
place_inst -name b773 -location {13349.280 3593.700} -status PLACED
place_inst -name r774_0 -location {13349.280 3579.720} -status PLACED
place_inst -name r774_1 -location {13349.280 3289.080} -status PLACED
place_inst -name r774_2 -location {13349.280 3184.469} -status PLACED
place_inst -name r774_3 -location {13349.280 3048.058} -status PLACED
place_inst -name b774 -location {13349.280 2911.648} -status PLACED
place_inst -name r775_0 -location {13466.380 3948.448} -status PLACED
place_inst -name r775_1 -location {13584.439 3948.448} -status PLACED
place_inst -name b775 -location {13702.499 3948.448} -status PLACED
place_inst -name r776_0 -location {13702.040 4030.544} -status PLACED
place_inst -name b776 -location {13703.580 4112.640} -status PLACED
place_inst -name r777_0 -location {13713.780 3995.724} -status PLACED
place_inst -name r777_1 -location {13818.012 3971.640} -status PLACED
place_inst -name r777_2 -location {13946.328 3971.640} -status PLACED
place_inst -name r777_3 -location {14059.380 3986.904} -status PLACED
place_inst -name b777 -location {14056.800 4112.640} -status PLACED
place_inst -name r778_0 -location {14056.800 4030.544} -status PLACED
place_inst -name b778 -location {14056.800 3948.448} -status PLACED
place_inst -name b779 -location {4173.120 3948.448} -status PLACED
place_inst -name r780_0 -location {4173.120 3830.559} -status PLACED
place_inst -name r780_1 -location {4173.120 3712.670} -status PLACED
place_inst -name b780 -location {4173.120 3594.781} -status PLACED
place_inst -name b781 -location {4172.640 3593.700} -status PLACED
place_inst -name r782_0 -location {4172.640 3579.720} -status PLACED
place_inst -name r782_1 -location {4172.640 3289.080} -status PLACED
place_inst -name r782_2 -location {4172.640 3184.469} -status PLACED
place_inst -name r782_3 -location {4172.640 3048.058} -status PLACED
place_inst -name b782 -location {4172.640 2911.648} -status PLACED
place_inst -name r783_0 -location {4055.540 3948.448} -status PLACED
place_inst -name r783_1 -location {3937.481 3948.448} -status PLACED
place_inst -name b783 -location {3819.421 3948.448} -status PLACED
place_inst -name r784_0 -location {3819.880 4030.544} -status PLACED
place_inst -name b784 -location {3818.340 4112.640} -status PLACED
place_inst -name r785_0 -location {3820.920 3986.904} -status PLACED
place_inst -name r785_1 -location {3707.868 3971.640} -status PLACED
place_inst -name r785_2 -location {3579.552 3971.640} -status PLACED
place_inst -name r785_3 -location {3464.520 3984.924} -status PLACED
place_inst -name b785 -location {3465.120 4112.640} -status PLACED
place_inst -name r786_0 -location {3465.120 4030.544} -status PLACED
place_inst -name b786 -location {3465.120 3948.448} -status PLACED
place_inst -name b787 -location {14057.280 6022.048} -status PLACED
place_inst -name r788_0 -location {14057.280 5904.159} -status PLACED
place_inst -name r788_1 -location {14057.280 5786.270} -status PLACED
place_inst -name b788 -location {14057.280 5668.381} -status PLACED
place_inst -name b789 -location {14057.760 5667.300} -status PLACED
place_inst -name r790_0 -location {14057.760 5653.320} -status PLACED
place_inst -name r790_1 -location {14057.760 5362.680} -status PLACED
place_inst -name r790_2 -location {14057.760 5258.069} -status PLACED
place_inst -name r790_3 -location {14057.760 5121.658} -status PLACED
place_inst -name b790 -location {14057.760 4985.248} -status PLACED
place_inst -name r791_0 -location {14174.860 6022.048} -status PLACED
place_inst -name r791_1 -location {14292.919 6022.048} -status PLACED
place_inst -name b791 -location {14410.979 6022.048} -status PLACED
place_inst -name r792_0 -location {14410.520 6104.144} -status PLACED
place_inst -name b792 -location {14412.060 6186.240} -status PLACED
place_inst -name r793_0 -location {14422.260 6069.324} -status PLACED
place_inst -name r793_1 -location {14526.492 6045.240} -status PLACED
place_inst -name r793_2 -location {14654.808 6045.240} -status PLACED
place_inst -name r793_3 -location {14767.860 6060.504} -status PLACED
place_inst -name b793 -location {14765.280 6186.240} -status PLACED
place_inst -name r794_0 -location {14765.280 6104.144} -status PLACED
place_inst -name b794 -location {14765.280 6022.048} -status PLACED
place_inst -name b795 -location {3464.640 6022.048} -status PLACED
place_inst -name r796_0 -location {3464.640 5904.159} -status PLACED
place_inst -name r796_1 -location {3464.640 5786.270} -status PLACED
place_inst -name b796 -location {3464.640 5668.381} -status PLACED
place_inst -name b797 -location {3464.160 5667.300} -status PLACED
place_inst -name r798_0 -location {3464.160 5653.320} -status PLACED
place_inst -name r798_1 -location {3464.160 5362.680} -status PLACED
place_inst -name r798_2 -location {3464.160 5258.069} -status PLACED
place_inst -name r798_3 -location {3464.160 5121.658} -status PLACED
place_inst -name b798 -location {3464.160 4985.248} -status PLACED
place_inst -name r799_0 -location {3347.060 6022.048} -status PLACED
place_inst -name r799_1 -location {3229.001 6022.048} -status PLACED
place_inst -name b799 -location {3110.941 6022.048} -status PLACED
place_inst -name r800_0 -location {3111.400 6104.144} -status PLACED
place_inst -name b800 -location {3109.860 6186.240} -status PLACED
place_inst -name r801_0 -location {3112.440 6060.504} -status PLACED
place_inst -name r801_1 -location {2999.388 6045.240} -status PLACED
place_inst -name r801_2 -location {2871.072 6045.240} -status PLACED
place_inst -name r801_3 -location {2756.040 6058.524} -status PLACED
place_inst -name b801 -location {2756.640 6186.240} -status PLACED
place_inst -name r802_0 -location {2756.640 6104.144} -status PLACED
place_inst -name b802 -location {2756.640 6022.048} -status PLACED
place_inst -name b803 -location {14765.760 8095.648} -status PLACED
place_inst -name r804_0 -location {14765.760 7977.759} -status PLACED
place_inst -name r804_1 -location {14765.760 7859.870} -status PLACED
place_inst -name b804 -location {14765.760 7741.981} -status PLACED
place_inst -name b805 -location {14766.240 7740.900} -status PLACED
place_inst -name r806_0 -location {14766.240 7726.920} -status PLACED
place_inst -name r806_1 -location {14766.240 7436.280} -status PLACED
place_inst -name r806_2 -location {14766.240 7331.669} -status PLACED
place_inst -name r806_3 -location {14766.240 7195.258} -status PLACED
place_inst -name b806 -location {14766.240 7058.848} -status PLACED
place_inst -name r807_0 -location {14883.340 8095.648} -status PLACED
place_inst -name r807_1 -location {15001.399 8095.648} -status PLACED
place_inst -name b807 -location {15119.459 8095.648} -status PLACED
place_inst -name r808_0 -location {15119.000 8177.744} -status PLACED
place_inst -name b808 -location {15120.540 8259.840} -status PLACED
place_inst -name r809_0 -location {15130.740 8142.924} -status PLACED
place_inst -name r809_1 -location {15234.972 8118.840} -status PLACED
place_inst -name r809_2 -location {15363.288 8118.840} -status PLACED
place_inst -name r809_3 -location {15476.340 8134.104} -status PLACED
place_inst -name b809 -location {15473.760 8259.840} -status PLACED
place_inst -name r810_0 -location {15473.760 8177.744} -status PLACED
place_inst -name b810 -location {15473.760 8095.648} -status PLACED
place_inst -name b811 -location {2756.160 8095.648} -status PLACED
place_inst -name r812_0 -location {2756.160 7977.759} -status PLACED
place_inst -name r812_1 -location {2756.160 7859.870} -status PLACED
place_inst -name b812 -location {2756.160 7741.981} -status PLACED
place_inst -name b813 -location {2755.680 7740.900} -status PLACED
place_inst -name r814_0 -location {2755.680 7726.920} -status PLACED
place_inst -name r814_1 -location {2755.680 7436.280} -status PLACED
place_inst -name r814_2 -location {2755.680 7331.669} -status PLACED
place_inst -name r814_3 -location {2755.680 7195.258} -status PLACED
place_inst -name b814 -location {2755.680 7058.848} -status PLACED
place_inst -name r815_0 -location {2638.580 8095.648} -status PLACED
place_inst -name r815_1 -location {2520.521 8095.648} -status PLACED
place_inst -name b815 -location {2402.461 8095.648} -status PLACED
place_inst -name r816_0 -location {2402.920 8177.744} -status PLACED
place_inst -name b816 -location {2401.380 8259.840} -status PLACED
place_inst -name r817_0 -location {2403.960 8134.104} -status PLACED
place_inst -name r817_1 -location {2290.908 8118.840} -status PLACED
place_inst -name r817_2 -location {2162.592 8118.840} -status PLACED
place_inst -name r817_3 -location {2047.560 8132.124} -status PLACED
place_inst -name b817 -location {2048.160 8259.840} -status PLACED
place_inst -name r818_0 -location {2048.160 8177.744} -status PLACED
place_inst -name b818 -location {2048.160 8095.648} -status PLACED
place_inst -name r819_0 -location {2238.686 15536.440} -status PLACED
place_inst -name b819 -location {2337.120 15536.440} -status PLACED
place_inst -name r820_0 -location {2337.120 15674.228} -status PLACED
place_inst -name r820_1 -location {2337.120 15812.016} -status PLACED
place_inst -name r820_2 -location {2337.120 15949.804} -status PLACED
place_inst -name r820_3 -location {2337.120 16087.592} -status PLACED
place_inst -name b820 -location {2337.120 16225.380} -status PLACED
place_inst -name r821_0 -location {2205.440 16224.920} -status PLACED
place_inst -name r821_1 -location {2073.760 16224.920} -status PLACED
place_inst -name r821_2 -location {1942.080 16226.920} -status PLACED
place_inst -name r821_3 -location {1810.400 16226.920} -status PLACED
place_inst -name r821_4 -location {1678.720 16226.920} -status PLACED
place_inst -name b821 -location {1547.040 16226.464} -status PLACED
place_inst -name b822 -location {1547.040 16303.648} -status PLACED
place_inst -name b823 -location {13348.800 14316.448} -status PLACED
place_inst -name r824_0 -location {13348.800 14198.559} -status PLACED
place_inst -name r824_1 -location {13348.800 14080.670} -status PLACED
place_inst -name b824 -location {13348.800 13962.781} -status PLACED
place_inst -name b825 -location {13349.280 13961.700} -status PLACED
place_inst -name r826_0 -location {13349.280 13947.720} -status PLACED
place_inst -name r826_1 -location {13349.280 13657.080} -status PLACED
place_inst -name r826_2 -location {13349.280 13552.469} -status PLACED
place_inst -name r826_3 -location {13349.280 13416.058} -status PLACED
place_inst -name b826 -location {13349.280 13279.648} -status PLACED
place_inst -name r827_0 -location {13466.380 14316.448} -status PLACED
place_inst -name r827_1 -location {13584.439 14316.448} -status PLACED
place_inst -name b827 -location {13702.499 14316.448} -status PLACED
place_inst -name r828_0 -location {13702.040 14398.544} -status PLACED
place_inst -name b828 -location {13703.580 14480.640} -status PLACED
place_inst -name r829_0 -location {13713.780 14363.724} -status PLACED
place_inst -name r829_1 -location {13818.012 14339.640} -status PLACED
place_inst -name r829_2 -location {13946.328 14339.640} -status PLACED
place_inst -name r829_3 -location {14059.380 14354.904} -status PLACED
place_inst -name b829 -location {14056.800 14480.640} -status PLACED
place_inst -name r830_0 -location {14056.800 14398.544} -status PLACED
place_inst -name b830 -location {14056.800 14316.448} -status PLACED
place_inst -name b831 -location {4173.120 14316.448} -status PLACED
place_inst -name r832_0 -location {4173.120 14198.559} -status PLACED
place_inst -name r832_1 -location {4173.120 14080.670} -status PLACED
place_inst -name b832 -location {4173.120 13962.781} -status PLACED
place_inst -name b833 -location {4172.640 13961.700} -status PLACED
place_inst -name r834_0 -location {4172.640 13947.720} -status PLACED
place_inst -name r834_1 -location {4172.640 13657.080} -status PLACED
place_inst -name r834_2 -location {4172.640 13552.469} -status PLACED
place_inst -name r834_3 -location {4172.640 13416.058} -status PLACED
place_inst -name b834 -location {4172.640 13279.648} -status PLACED
place_inst -name r835_0 -location {4055.540 14316.448} -status PLACED
place_inst -name r835_1 -location {3937.481 14316.448} -status PLACED
place_inst -name b835 -location {3819.421 14316.448} -status PLACED
place_inst -name r836_0 -location {3819.880 14398.544} -status PLACED
place_inst -name b836 -location {3818.340 14480.640} -status PLACED
place_inst -name r837_0 -location {3820.920 14354.904} -status PLACED
place_inst -name r837_1 -location {3707.868 14339.640} -status PLACED
place_inst -name r837_2 -location {3579.552 14339.640} -status PLACED
place_inst -name r837_3 -location {3464.520 14352.924} -status PLACED
place_inst -name b837 -location {3465.120 14480.640} -status PLACED
place_inst -name r838_0 -location {3465.120 14398.544} -status PLACED
place_inst -name b838 -location {3465.120 14316.448} -status PLACED
place_inst -name b839 -location {14057.280 12242.848} -status PLACED
place_inst -name r840_0 -location {14057.280 12124.959} -status PLACED
place_inst -name r840_1 -location {14057.280 12007.070} -status PLACED
place_inst -name b840 -location {14057.280 11889.181} -status PLACED
place_inst -name b841 -location {14057.760 11888.100} -status PLACED
place_inst -name r842_0 -location {14057.760 11874.120} -status PLACED
place_inst -name r842_1 -location {14057.760 11583.480} -status PLACED
place_inst -name r842_2 -location {14057.760 11478.869} -status PLACED
place_inst -name r842_3 -location {14057.760 11342.458} -status PLACED
place_inst -name b842 -location {14057.760 11206.048} -status PLACED
place_inst -name r843_0 -location {14174.860 12242.848} -status PLACED
place_inst -name r843_1 -location {14292.919 12242.848} -status PLACED
place_inst -name b843 -location {14410.979 12242.848} -status PLACED
place_inst -name r844_0 -location {14410.520 12324.944} -status PLACED
place_inst -name b844 -location {14412.060 12407.040} -status PLACED
place_inst -name r845_0 -location {14422.260 12290.124} -status PLACED
place_inst -name r845_1 -location {14526.492 12266.040} -status PLACED
place_inst -name r845_2 -location {14654.808 12266.040} -status PLACED
place_inst -name r845_3 -location {14767.860 12281.304} -status PLACED
place_inst -name b845 -location {14765.280 12407.040} -status PLACED
place_inst -name r846_0 -location {14765.280 12324.944} -status PLACED
place_inst -name b846 -location {14765.280 12242.848} -status PLACED
place_inst -name b847 -location {3464.640 12242.848} -status PLACED
place_inst -name r848_0 -location {3464.640 12124.959} -status PLACED
place_inst -name r848_1 -location {3464.640 12007.070} -status PLACED
place_inst -name b848 -location {3464.640 11889.181} -status PLACED
place_inst -name b849 -location {3464.160 11888.100} -status PLACED
place_inst -name r850_0 -location {3464.160 11874.120} -status PLACED
place_inst -name r850_1 -location {3464.160 11583.480} -status PLACED
place_inst -name r850_2 -location {3464.160 11478.869} -status PLACED
place_inst -name r850_3 -location {3464.160 11342.458} -status PLACED
place_inst -name b850 -location {3464.160 11206.048} -status PLACED
place_inst -name r851_0 -location {3347.060 12242.848} -status PLACED
place_inst -name r851_1 -location {3229.001 12242.848} -status PLACED
place_inst -name b851 -location {3110.941 12242.848} -status PLACED
place_inst -name r852_0 -location {3111.400 12324.944} -status PLACED
place_inst -name b852 -location {3109.860 12407.040} -status PLACED
place_inst -name r853_0 -location {3112.440 12281.304} -status PLACED
place_inst -name r853_1 -location {2999.388 12266.040} -status PLACED
place_inst -name r853_2 -location {2871.072 12266.040} -status PLACED
place_inst -name r853_3 -location {2756.040 12279.324} -status PLACED
place_inst -name b853 -location {2756.640 12407.040} -status PLACED
place_inst -name r854_0 -location {2756.640 12324.944} -status PLACED
place_inst -name b854 -location {2756.640 12242.848} -status PLACED
place_inst -name b855 -location {14765.760 10169.248} -status PLACED
place_inst -name r856_0 -location {14765.760 10051.359} -status PLACED
place_inst -name r856_1 -location {14765.760 9933.470} -status PLACED
place_inst -name b856 -location {14765.760 9815.581} -status PLACED
place_inst -name b857 -location {14766.240 9814.500} -status PLACED
place_inst -name r858_0 -location {14766.240 9800.520} -status PLACED
place_inst -name r858_1 -location {14766.240 9509.880} -status PLACED
place_inst -name r858_2 -location {14766.240 9405.269} -status PLACED
place_inst -name r858_3 -location {14766.240 9268.858} -status PLACED
place_inst -name b858 -location {14766.240 9132.448} -status PLACED
place_inst -name r859_0 -location {14883.340 10169.248} -status PLACED
place_inst -name r859_1 -location {15001.399 10169.248} -status PLACED
place_inst -name b859 -location {15119.459 10169.248} -status PLACED
place_inst -name r860_0 -location {15119.000 10251.344} -status PLACED
place_inst -name b860 -location {15120.540 10333.440} -status PLACED
place_inst -name r861_0 -location {15130.740 10216.524} -status PLACED
place_inst -name r861_1 -location {15234.972 10192.440} -status PLACED
place_inst -name r861_2 -location {15363.288 10192.440} -status PLACED
place_inst -name r861_3 -location {15476.340 10207.704} -status PLACED
place_inst -name b861 -location {15473.760 10333.440} -status PLACED
place_inst -name r862_0 -location {15473.760 10251.344} -status PLACED
place_inst -name b862 -location {15473.760 10169.248} -status PLACED
place_inst -name b863 -location {2756.160 10169.248} -status PLACED
place_inst -name r864_0 -location {2756.160 10051.359} -status PLACED
place_inst -name r864_1 -location {2756.160 9933.470} -status PLACED
place_inst -name b864 -location {2756.160 9815.581} -status PLACED
place_inst -name b865 -location {2755.680 9814.500} -status PLACED
place_inst -name r866_0 -location {2755.680 9800.520} -status PLACED
place_inst -name r866_1 -location {2755.680 9509.880} -status PLACED
place_inst -name r866_2 -location {2755.680 9405.269} -status PLACED
place_inst -name r866_3 -location {2755.680 9268.858} -status PLACED
place_inst -name b866 -location {2755.680 9132.448} -status PLACED
place_inst -name r867_0 -location {2638.580 10169.248} -status PLACED
place_inst -name r867_1 -location {2520.521 10169.248} -status PLACED
place_inst -name b867 -location {2402.461 10169.248} -status PLACED
place_inst -name r868_0 -location {2402.920 10251.344} -status PLACED
place_inst -name b868 -location {2401.380 10333.440} -status PLACED
place_inst -name r869_0 -location {2403.960 10207.704} -status PLACED
place_inst -name r869_1 -location {2290.908 10192.440} -status PLACED
place_inst -name r869_2 -location {2162.592 10192.440} -status PLACED
place_inst -name r869_3 -location {2047.560 10205.724} -status PLACED
place_inst -name b869 -location {2048.160 10333.440} -status PLACED
place_inst -name r870_0 -location {2048.160 10251.344} -status PLACED
place_inst -name b870 -location {2048.160 10169.248} -status PLACED
place_inst -name b871 -location {14057.280 3948.448} -status PLACED
place_inst -name r872_0 -location {14057.280 3830.559} -status PLACED
place_inst -name r872_1 -location {14057.280 3712.670} -status PLACED
place_inst -name b872 -location {14057.280 3594.781} -status PLACED
place_inst -name b873 -location {14057.760 3593.700} -status PLACED
place_inst -name r874_0 -location {14057.760 3579.720} -status PLACED
place_inst -name r874_1 -location {14057.760 3289.080} -status PLACED
place_inst -name r874_2 -location {14057.760 3184.469} -status PLACED
place_inst -name r874_3 -location {14057.760 3048.058} -status PLACED
place_inst -name b874 -location {14057.760 2911.648} -status PLACED
place_inst -name r875_0 -location {14174.860 3948.448} -status PLACED
place_inst -name r875_1 -location {14292.919 3948.448} -status PLACED
place_inst -name b875 -location {14410.979 3948.448} -status PLACED
place_inst -name r876_0 -location {14410.520 4030.544} -status PLACED
place_inst -name b876 -location {14412.060 4112.640} -status PLACED
place_inst -name r877_0 -location {14422.260 3995.724} -status PLACED
place_inst -name r877_1 -location {14526.492 3971.640} -status PLACED
place_inst -name r877_2 -location {14654.808 3971.640} -status PLACED
place_inst -name r877_3 -location {14767.860 3986.904} -status PLACED
place_inst -name b877 -location {14765.280 4112.640} -status PLACED
place_inst -name r878_0 -location {14765.280 4030.544} -status PLACED
place_inst -name b878 -location {14765.280 3948.448} -status PLACED
place_inst -name b879 -location {3464.640 3948.448} -status PLACED
place_inst -name r880_0 -location {3464.640 3830.559} -status PLACED
place_inst -name r880_1 -location {3464.640 3712.670} -status PLACED
place_inst -name b880 -location {3464.640 3594.781} -status PLACED
place_inst -name b881 -location {3464.160 3593.700} -status PLACED
place_inst -name r882_0 -location {3464.160 3579.720} -status PLACED
place_inst -name r882_1 -location {3464.160 3289.080} -status PLACED
place_inst -name r882_2 -location {3464.160 3184.469} -status PLACED
place_inst -name r882_3 -location {3464.160 3048.058} -status PLACED
place_inst -name b882 -location {3464.160 2911.648} -status PLACED
place_inst -name r883_0 -location {3347.060 3948.448} -status PLACED
place_inst -name r883_1 -location {3229.001 3948.448} -status PLACED
place_inst -name b883 -location {3110.941 3948.448} -status PLACED
place_inst -name r884_0 -location {3111.400 4030.544} -status PLACED
place_inst -name b884 -location {3109.860 4112.640} -status PLACED
place_inst -name r885_0 -location {3112.440 3986.904} -status PLACED
place_inst -name r885_1 -location {2999.388 3971.640} -status PLACED
place_inst -name r885_2 -location {2871.072 3971.640} -status PLACED
place_inst -name r885_3 -location {2756.040 3984.924} -status PLACED
place_inst -name b885 -location {2756.640 4112.640} -status PLACED
place_inst -name r886_0 -location {2756.640 4030.544} -status PLACED
place_inst -name b886 -location {2756.640 3948.448} -status PLACED
place_inst -name b887 -location {14765.760 6022.048} -status PLACED
place_inst -name r888_0 -location {14765.760 5904.159} -status PLACED
place_inst -name r888_1 -location {14765.760 5786.270} -status PLACED
place_inst -name b888 -location {14765.760 5668.381} -status PLACED
place_inst -name b889 -location {14766.240 5667.300} -status PLACED
place_inst -name r890_0 -location {14766.240 5653.320} -status PLACED
place_inst -name r890_1 -location {14766.240 5362.680} -status PLACED
place_inst -name r890_2 -location {14766.240 5258.069} -status PLACED
place_inst -name r890_3 -location {14766.240 5121.658} -status PLACED
place_inst -name b890 -location {14766.240 4985.248} -status PLACED
place_inst -name r891_0 -location {14883.340 6022.048} -status PLACED
place_inst -name r891_1 -location {15001.399 6022.048} -status PLACED
place_inst -name b891 -location {15119.459 6022.048} -status PLACED
place_inst -name r892_0 -location {15119.000 6104.144} -status PLACED
place_inst -name b892 -location {15120.540 6186.240} -status PLACED
place_inst -name r893_0 -location {15130.740 6069.324} -status PLACED
place_inst -name r893_1 -location {15234.972 6045.240} -status PLACED
place_inst -name r893_2 -location {15363.288 6045.240} -status PLACED
place_inst -name r893_3 -location {15476.340 6060.504} -status PLACED
place_inst -name b893 -location {15473.760 6186.240} -status PLACED
place_inst -name r894_0 -location {15473.760 6104.144} -status PLACED
place_inst -name b894 -location {15473.760 6022.048} -status PLACED
place_inst -name b895 -location {2756.160 6022.048} -status PLACED
place_inst -name r896_0 -location {2756.160 5904.159} -status PLACED
place_inst -name r896_1 -location {2756.160 5786.270} -status PLACED
place_inst -name b896 -location {2756.160 5668.381} -status PLACED
place_inst -name b897 -location {2755.680 5667.300} -status PLACED
place_inst -name r898_0 -location {2755.680 5653.320} -status PLACED
place_inst -name r898_1 -location {2755.680 5362.680} -status PLACED
place_inst -name r898_2 -location {2755.680 5258.069} -status PLACED
place_inst -name r898_3 -location {2755.680 5121.658} -status PLACED
place_inst -name b898 -location {2755.680 4985.248} -status PLACED
place_inst -name r899_0 -location {2638.580 6022.048} -status PLACED
place_inst -name r899_1 -location {2520.521 6022.048} -status PLACED
place_inst -name b899 -location {2402.461 6022.048} -status PLACED
place_inst -name r900_0 -location {2402.920 6104.144} -status PLACED
place_inst -name b900 -location {2401.380 6186.240} -status PLACED
place_inst -name r901_0 -location {2403.960 6060.504} -status PLACED
place_inst -name r901_1 -location {2290.908 6045.240} -status PLACED
place_inst -name r901_2 -location {2162.592 6045.240} -status PLACED
place_inst -name r901_3 -location {2047.560 6058.524} -status PLACED
place_inst -name b901 -location {2048.160 6186.240} -status PLACED
place_inst -name r902_0 -location {2048.160 6104.144} -status PLACED
place_inst -name b902 -location {2048.160 6022.048} -status PLACED
place_inst -name b903 -location {15474.240 8095.648} -status PLACED
place_inst -name r904_0 -location {15474.240 7977.759} -status PLACED
place_inst -name r904_1 -location {15474.240 7859.870} -status PLACED
place_inst -name b904 -location {15474.240 7741.981} -status PLACED
place_inst -name b905 -location {15474.720 7740.900} -status PLACED
place_inst -name r906_0 -location {15474.720 7726.920} -status PLACED
place_inst -name r906_1 -location {15474.720 7436.280} -status PLACED
place_inst -name r906_2 -location {15474.720 7331.669} -status PLACED
place_inst -name r906_3 -location {15474.720 7195.258} -status PLACED
place_inst -name b906 -location {15474.720 7058.848} -status PLACED
place_inst -name r907_0 -location {15591.820 8095.648} -status PLACED
place_inst -name r907_1 -location {15709.879 8095.648} -status PLACED
place_inst -name b907 -location {15827.939 8095.648} -status PLACED
place_inst -name r908_0 -location {15827.480 8177.744} -status PLACED
place_inst -name b908 -location {15829.020 8259.840} -status PLACED
place_inst -name r909_0 -location {15839.220 8142.924} -status PLACED
place_inst -name r909_1 -location {15943.452 8118.840} -status PLACED
place_inst -name r909_2 -location {16071.768 8118.840} -status PLACED
place_inst -name r909_3 -location {16184.820 8134.104} -status PLACED
place_inst -name b909 -location {16182.240 8259.840} -status PLACED
place_inst -name r910_0 -location {16182.240 8177.744} -status PLACED
place_inst -name b910 -location {16182.240 8095.648} -status PLACED
place_inst -name b911 -location {2047.680 8095.648} -status PLACED
place_inst -name r912_0 -location {2047.680 7977.759} -status PLACED
place_inst -name r912_1 -location {2047.680 7859.870} -status PLACED
place_inst -name b912 -location {2047.680 7741.981} -status PLACED
place_inst -name b913 -location {2047.200 7740.900} -status PLACED
place_inst -name r914_0 -location {2047.200 7726.920} -status PLACED
place_inst -name r914_1 -location {2047.200 7436.280} -status PLACED
place_inst -name r914_2 -location {2047.200 7331.669} -status PLACED
place_inst -name r914_3 -location {2047.200 7195.258} -status PLACED
place_inst -name b914 -location {2047.200 7058.848} -status PLACED
place_inst -name r915_0 -location {1930.100 8095.648} -status PLACED
place_inst -name r915_1 -location {1812.041 8095.648} -status PLACED
place_inst -name b915 -location {1693.981 8095.648} -status PLACED
place_inst -name r916_0 -location {1694.440 8177.744} -status PLACED
place_inst -name b916 -location {1692.900 8259.840} -status PLACED
place_inst -name r917_0 -location {1695.480 8134.104} -status PLACED
place_inst -name r917_1 -location {1582.428 8118.840} -status PLACED
place_inst -name r917_2 -location {1454.112 8118.840} -status PLACED
place_inst -name r917_3 -location {1339.080 8132.124} -status PLACED
place_inst -name b917 -location {1339.680 8259.840} -status PLACED
place_inst -name r918_0 -location {1339.680 8177.744} -status PLACED
place_inst -name b918 -location {1339.680 8095.648} -status PLACED
place_inst -name b919 -location {14057.280 14316.448} -status PLACED
place_inst -name r920_0 -location {14057.280 14198.559} -status PLACED
place_inst -name r920_1 -location {14057.280 14080.670} -status PLACED
place_inst -name b920 -location {14057.280 13962.781} -status PLACED
place_inst -name b921 -location {14057.760 13961.700} -status PLACED
place_inst -name r922_0 -location {14057.760 13947.720} -status PLACED
place_inst -name r922_1 -location {14057.760 13657.080} -status PLACED
place_inst -name r922_2 -location {14057.760 13552.469} -status PLACED
place_inst -name r922_3 -location {14057.760 13416.058} -status PLACED
place_inst -name b922 -location {14057.760 13279.648} -status PLACED
place_inst -name r923_0 -location {14174.860 14316.448} -status PLACED
place_inst -name r923_1 -location {14292.919 14316.448} -status PLACED
place_inst -name b923 -location {14410.979 14316.448} -status PLACED
place_inst -name r924_0 -location {14410.520 14398.544} -status PLACED
place_inst -name b924 -location {14412.060 14480.640} -status PLACED
place_inst -name r925_0 -location {14422.260 14363.724} -status PLACED
place_inst -name r925_1 -location {14526.492 14339.640} -status PLACED
place_inst -name r925_2 -location {14654.808 14339.640} -status PLACED
place_inst -name r925_3 -location {14767.860 14354.904} -status PLACED
place_inst -name b925 -location {14765.280 14480.640} -status PLACED
place_inst -name r926_0 -location {14765.280 14398.544} -status PLACED
place_inst -name b926 -location {14765.280 14316.448} -status PLACED
place_inst -name b927 -location {3464.640 14316.448} -status PLACED
place_inst -name r928_0 -location {3464.640 14198.559} -status PLACED
place_inst -name r928_1 -location {3464.640 14080.670} -status PLACED
place_inst -name b928 -location {3464.640 13962.781} -status PLACED
place_inst -name b929 -location {3464.160 13961.700} -status PLACED
place_inst -name r930_0 -location {3464.160 13947.720} -status PLACED
place_inst -name r930_1 -location {3464.160 13657.080} -status PLACED
place_inst -name r930_2 -location {3464.160 13552.469} -status PLACED
place_inst -name r930_3 -location {3464.160 13416.058} -status PLACED
place_inst -name b930 -location {3464.160 13279.648} -status PLACED
place_inst -name r931_0 -location {3347.060 14316.448} -status PLACED
place_inst -name r931_1 -location {3229.001 14316.448} -status PLACED
place_inst -name b931 -location {3110.941 14316.448} -status PLACED
place_inst -name r932_0 -location {3111.400 14398.544} -status PLACED
place_inst -name b932 -location {3109.860 14480.640} -status PLACED
place_inst -name r933_0 -location {3112.440 14354.904} -status PLACED
place_inst -name r933_1 -location {2999.388 14339.640} -status PLACED
place_inst -name r933_2 -location {2871.072 14339.640} -status PLACED
place_inst -name r933_3 -location {2756.040 14352.924} -status PLACED
place_inst -name b933 -location {2756.640 14480.640} -status PLACED
place_inst -name r934_0 -location {2756.640 14398.544} -status PLACED
place_inst -name b934 -location {2756.640 14316.448} -status PLACED
place_inst -name b935 -location {14765.760 12242.848} -status PLACED
place_inst -name r936_0 -location {14765.760 12124.959} -status PLACED
place_inst -name r936_1 -location {14765.760 12007.070} -status PLACED
place_inst -name b936 -location {14765.760 11889.181} -status PLACED
place_inst -name b937 -location {14766.240 11888.100} -status PLACED
place_inst -name r938_0 -location {14766.240 11874.120} -status PLACED
place_inst -name r938_1 -location {14766.240 11583.480} -status PLACED
place_inst -name r938_2 -location {14766.240 11478.869} -status PLACED
place_inst -name r938_3 -location {14766.240 11342.458} -status PLACED
place_inst -name b938 -location {14766.240 11206.048} -status PLACED
place_inst -name r939_0 -location {14883.340 12242.848} -status PLACED
place_inst -name r939_1 -location {15001.399 12242.848} -status PLACED
place_inst -name b939 -location {15119.459 12242.848} -status PLACED
place_inst -name r940_0 -location {15119.000 12324.944} -status PLACED
place_inst -name b940 -location {15120.540 12407.040} -status PLACED
place_inst -name r941_0 -location {15130.740 12290.124} -status PLACED
place_inst -name r941_1 -location {15234.972 12266.040} -status PLACED
place_inst -name r941_2 -location {15363.288 12266.040} -status PLACED
place_inst -name r941_3 -location {15476.340 12281.304} -status PLACED
place_inst -name b941 -location {15473.760 12407.040} -status PLACED
place_inst -name r942_0 -location {15473.760 12324.944} -status PLACED
place_inst -name b942 -location {15473.760 12242.848} -status PLACED
place_inst -name b943 -location {2756.160 12242.848} -status PLACED
place_inst -name r944_0 -location {2756.160 12124.959} -status PLACED
place_inst -name r944_1 -location {2756.160 12007.070} -status PLACED
place_inst -name b944 -location {2756.160 11889.181} -status PLACED
place_inst -name b945 -location {2755.680 11888.100} -status PLACED
place_inst -name r946_0 -location {2755.680 11874.120} -status PLACED
place_inst -name r946_1 -location {2755.680 11583.480} -status PLACED
place_inst -name r946_2 -location {2755.680 11478.869} -status PLACED
place_inst -name r946_3 -location {2755.680 11342.458} -status PLACED
place_inst -name b946 -location {2755.680 11206.048} -status PLACED
place_inst -name r947_0 -location {2638.580 12242.848} -status PLACED
place_inst -name r947_1 -location {2520.521 12242.848} -status PLACED
place_inst -name b947 -location {2402.461 12242.848} -status PLACED
place_inst -name r948_0 -location {2402.920 12324.944} -status PLACED
place_inst -name b948 -location {2401.380 12407.040} -status PLACED
place_inst -name r949_0 -location {2403.960 12281.304} -status PLACED
place_inst -name r949_1 -location {2290.908 12266.040} -status PLACED
place_inst -name r949_2 -location {2162.592 12266.040} -status PLACED
place_inst -name r949_3 -location {2047.560 12279.324} -status PLACED
place_inst -name b949 -location {2048.160 12407.040} -status PLACED
place_inst -name r950_0 -location {2048.160 12324.944} -status PLACED
place_inst -name b950 -location {2048.160 12242.848} -status PLACED
place_inst -name b951 -location {15474.240 10169.248} -status PLACED
place_inst -name r952_0 -location {15474.240 10051.359} -status PLACED
place_inst -name r952_1 -location {15474.240 9933.470} -status PLACED
place_inst -name b952 -location {15474.240 9815.581} -status PLACED
place_inst -name b953 -location {15474.720 9814.500} -status PLACED
place_inst -name r954_0 -location {15474.720 9800.520} -status PLACED
place_inst -name r954_1 -location {15474.720 9509.880} -status PLACED
place_inst -name r954_2 -location {15474.720 9405.269} -status PLACED
place_inst -name r954_3 -location {15474.720 9268.858} -status PLACED
place_inst -name b954 -location {15474.720 9132.448} -status PLACED
place_inst -name r955_0 -location {15591.820 10169.248} -status PLACED
place_inst -name r955_1 -location {15709.879 10169.248} -status PLACED
place_inst -name b955 -location {15827.939 10169.248} -status PLACED
place_inst -name r956_0 -location {15827.480 10251.344} -status PLACED
place_inst -name b956 -location {15829.020 10333.440} -status PLACED
place_inst -name r957_0 -location {15839.220 10216.524} -status PLACED
place_inst -name r957_1 -location {15943.452 10192.440} -status PLACED
place_inst -name r957_2 -location {16071.768 10192.440} -status PLACED
place_inst -name r957_3 -location {16184.820 10207.704} -status PLACED
place_inst -name b957 -location {16182.240 10333.440} -status PLACED
place_inst -name r958_0 -location {16182.240 10251.344} -status PLACED
place_inst -name b958 -location {16182.240 10169.248} -status PLACED
place_inst -name b959 -location {2047.680 10169.248} -status PLACED
place_inst -name r960_0 -location {2047.680 10051.359} -status PLACED
place_inst -name r960_1 -location {2047.680 9933.470} -status PLACED
place_inst -name b960 -location {2047.680 9815.581} -status PLACED
place_inst -name b961 -location {2047.200 9814.500} -status PLACED
place_inst -name r962_0 -location {2047.200 9800.520} -status PLACED
place_inst -name r962_1 -location {2047.200 9509.880} -status PLACED
place_inst -name r962_2 -location {2047.200 9405.269} -status PLACED
place_inst -name r962_3 -location {2047.200 9268.858} -status PLACED
place_inst -name b962 -location {2047.200 9132.448} -status PLACED
place_inst -name r963_0 -location {1930.100 10169.248} -status PLACED
place_inst -name r963_1 -location {1812.041 10169.248} -status PLACED
place_inst -name b963 -location {1693.981 10169.248} -status PLACED
place_inst -name r964_0 -location {1694.440 10251.344} -status PLACED
place_inst -name b964 -location {1692.900 10333.440} -status PLACED
place_inst -name r965_0 -location {1695.480 10207.704} -status PLACED
place_inst -name r965_1 -location {1582.428 10192.440} -status PLACED
place_inst -name r965_2 -location {1454.112 10192.440} -status PLACED
place_inst -name r965_3 -location {1339.080 10205.724} -status PLACED
place_inst -name b965 -location {1339.680 10333.440} -status PLACED
place_inst -name r966_0 -location {1339.680 10251.344} -status PLACED
place_inst -name b966 -location {1339.680 10169.248} -status PLACED
place_inst -name b967 -location {14765.760 3948.448} -status PLACED
place_inst -name r968_0 -location {14765.760 3830.559} -status PLACED
place_inst -name r968_1 -location {14765.760 3712.670} -status PLACED
place_inst -name b968 -location {14765.760 3594.781} -status PLACED
place_inst -name b969 -location {14766.240 3593.700} -status PLACED
place_inst -name r970_0 -location {14766.240 3579.720} -status PLACED
place_inst -name r970_1 -location {14766.240 3289.080} -status PLACED
place_inst -name r970_2 -location {14766.240 3184.469} -status PLACED
place_inst -name r970_3 -location {14766.240 3048.058} -status PLACED
place_inst -name b970 -location {14766.240 2911.648} -status PLACED
place_inst -name r971_0 -location {14883.340 3948.448} -status PLACED
place_inst -name r971_1 -location {15001.399 3948.448} -status PLACED
place_inst -name b971 -location {15119.459 3948.448} -status PLACED
place_inst -name r972_0 -location {15119.000 4030.544} -status PLACED
place_inst -name b972 -location {15120.540 4112.640} -status PLACED
place_inst -name r973_0 -location {15130.740 3995.724} -status PLACED
place_inst -name r973_1 -location {15234.972 3971.640} -status PLACED
place_inst -name r973_2 -location {15363.288 3971.640} -status PLACED
place_inst -name r973_3 -location {15476.340 3986.904} -status PLACED
place_inst -name b973 -location {15473.760 4112.640} -status PLACED
place_inst -name r974_0 -location {15473.760 4030.544} -status PLACED
place_inst -name b974 -location {15473.760 3948.448} -status PLACED
place_inst -name b975 -location {2756.160 3948.448} -status PLACED
place_inst -name r976_0 -location {2756.160 3830.559} -status PLACED
place_inst -name r976_1 -location {2756.160 3712.670} -status PLACED
place_inst -name b976 -location {2756.160 3594.781} -status PLACED
place_inst -name b977 -location {2755.680 3593.700} -status PLACED
place_inst -name r978_0 -location {2755.680 3579.720} -status PLACED
place_inst -name r978_1 -location {2755.680 3289.080} -status PLACED
place_inst -name r978_2 -location {2755.680 3184.469} -status PLACED
place_inst -name r978_3 -location {2755.680 3048.058} -status PLACED
place_inst -name b978 -location {2755.680 2911.648} -status PLACED
place_inst -name r979_0 -location {2638.580 3948.448} -status PLACED
place_inst -name r979_1 -location {2520.521 3948.448} -status PLACED
place_inst -name b979 -location {2402.461 3948.448} -status PLACED
place_inst -name r980_0 -location {2402.920 4030.544} -status PLACED
place_inst -name b980 -location {2401.380 4112.640} -status PLACED
place_inst -name r981_0 -location {2403.960 3986.904} -status PLACED
place_inst -name r981_1 -location {2290.908 3971.640} -status PLACED
place_inst -name r981_2 -location {2162.592 3971.640} -status PLACED
place_inst -name r981_3 -location {2047.560 3984.924} -status PLACED
place_inst -name b981 -location {2048.160 4112.640} -status PLACED
place_inst -name r982_0 -location {2048.160 4030.544} -status PLACED
place_inst -name b982 -location {2048.160 3948.448} -status PLACED
place_inst -name b983 -location {15474.240 6022.048} -status PLACED
place_inst -name r984_0 -location {15474.240 5904.159} -status PLACED
place_inst -name r984_1 -location {15474.240 5786.270} -status PLACED
place_inst -name b984 -location {15474.240 5668.381} -status PLACED
place_inst -name b985 -location {15474.720 5667.300} -status PLACED
place_inst -name r986_0 -location {15474.720 5653.320} -status PLACED
place_inst -name r986_1 -location {15474.720 5362.680} -status PLACED
place_inst -name r986_2 -location {15474.720 5258.069} -status PLACED
place_inst -name r986_3 -location {15474.720 5121.658} -status PLACED
place_inst -name b986 -location {15474.720 4985.248} -status PLACED
place_inst -name r987_0 -location {15591.820 6022.048} -status PLACED
place_inst -name r987_1 -location {15709.879 6022.048} -status PLACED
place_inst -name b987 -location {15827.939 6022.048} -status PLACED
place_inst -name r988_0 -location {15827.480 6104.144} -status PLACED
place_inst -name b988 -location {15829.020 6186.240} -status PLACED
place_inst -name r989_0 -location {15839.220 6069.324} -status PLACED
place_inst -name r989_1 -location {15943.452 6045.240} -status PLACED
place_inst -name r989_2 -location {16071.768 6045.240} -status PLACED
place_inst -name r989_3 -location {16184.820 6060.504} -status PLACED
place_inst -name b989 -location {16182.240 6186.240} -status PLACED
place_inst -name r990_0 -location {16182.240 6104.144} -status PLACED
place_inst -name b990 -location {16182.240 6022.048} -status PLACED
place_inst -name b991 -location {2047.680 6022.048} -status PLACED
place_inst -name r992_0 -location {2047.680 5904.159} -status PLACED
place_inst -name r992_1 -location {2047.680 5786.270} -status PLACED
place_inst -name b992 -location {2047.680 5668.381} -status PLACED
place_inst -name b993 -location {2047.200 5667.300} -status PLACED
place_inst -name r994_0 -location {2047.200 5653.320} -status PLACED
place_inst -name r994_1 -location {2047.200 5362.680} -status PLACED
place_inst -name r994_2 -location {2047.200 5258.069} -status PLACED
place_inst -name r994_3 -location {2047.200 5121.658} -status PLACED
place_inst -name b994 -location {2047.200 4985.248} -status PLACED
place_inst -name r995_0 -location {1930.100 6022.048} -status PLACED
place_inst -name r995_1 -location {1812.041 6022.048} -status PLACED
place_inst -name b995 -location {1693.981 6022.048} -status PLACED
place_inst -name r996_0 -location {1694.440 6104.144} -status PLACED
place_inst -name b996 -location {1692.900 6186.240} -status PLACED
place_inst -name r997_0 -location {1695.480 6060.504} -status PLACED
place_inst -name r997_1 -location {1582.428 6045.240} -status PLACED
place_inst -name r997_2 -location {1454.112 6045.240} -status PLACED
place_inst -name r997_3 -location {1339.080 6058.524} -status PLACED
place_inst -name b997 -location {1339.680 6186.240} -status PLACED
place_inst -name r998_0 -location {1339.680 6104.144} -status PLACED
place_inst -name b998 -location {1339.680 6022.048} -status PLACED
place_inst -name b999 -location {16182.720 8095.648} -status PLACED
place_inst -name r1000_0 -location {16182.720 7977.759} -status PLACED
place_inst -name r1000_1 -location {16182.720 7859.870} -status PLACED
place_inst -name b1000 -location {16182.720 7741.981} -status PLACED
place_inst -name b1001 -location {16183.200 7740.900} -status PLACED
place_inst -name r1002_0 -location {16183.200 7726.920} -status PLACED
place_inst -name r1002_1 -location {16183.200 7436.280} -status PLACED
place_inst -name r1002_2 -location {16183.200 7331.669} -status PLACED
place_inst -name r1002_3 -location {16183.200 7195.258} -status PLACED
place_inst -name b1002 -location {16183.200 7058.848} -status PLACED
place_inst -name r1003_0 -location {16300.300 8095.648} -status PLACED
place_inst -name r1003_1 -location {16418.359 8095.648} -status PLACED
place_inst -name b1003 -location {16536.419 8095.648} -status PLACED
place_inst -name r1004_0 -location {16535.960 8177.744} -status PLACED
place_inst -name b1004 -location {16537.500 8259.840} -status PLACED
place_inst -name r1005_0 -location {16547.700 8142.924} -status PLACED
place_inst -name r1005_1 -location {16651.932 8118.840} -status PLACED
place_inst -name r1005_2 -location {16780.248 8118.840} -status PLACED
place_inst -name r1005_3 -location {16893.300 8134.104} -status PLACED
place_inst -name b1005 -location {16890.720 8259.840} -status PLACED
place_inst -name r1006_0 -location {16890.720 8177.744} -status PLACED
place_inst -name b1006 -location {16890.720 8095.648} -status PLACED
place_inst -name b1007 -location {1339.200 8095.648} -status PLACED
place_inst -name r1008_0 -location {1339.200 7977.759} -status PLACED
place_inst -name r1008_1 -location {1339.200 7859.870} -status PLACED
place_inst -name b1008 -location {1339.200 7741.981} -status PLACED
place_inst -name b1009 -location {1338.720 7740.900} -status PLACED
place_inst -name r1010_0 -location {1338.720 7726.920} -status PLACED
place_inst -name r1010_1 -location {1338.720 7436.280} -status PLACED
place_inst -name r1010_2 -location {1338.720 7331.669} -status PLACED
place_inst -name r1010_3 -location {1338.720 7195.258} -status PLACED
place_inst -name b1010 -location {1338.720 7058.848} -status PLACED
place_inst -name r1011_0 -location {1221.620 8095.648} -status PLACED
place_inst -name r1011_1 -location {1103.561 8095.648} -status PLACED
place_inst -name b1011 -location {985.501 8095.648} -status PLACED
place_inst -name r1012_0 -location {985.960 8177.744} -status PLACED
place_inst -name b1012 -location {984.420 8259.840} -status PLACED
place_inst -name r1013_0 -location {987.000 8134.104} -status PLACED
place_inst -name r1013_1 -location {873.948 8118.840} -status PLACED
place_inst -name r1013_2 -location {745.632 8118.840} -status PLACED
place_inst -name r1013_3 -location {630.600 8132.124} -status PLACED
place_inst -name b1013 -location {631.200 8259.840} -status PLACED
place_inst -name r1014_0 -location {631.200 8177.744} -status PLACED
place_inst -name b1014 -location {631.200 8095.648} -status PLACED
place_inst -name b1015 -location {14765.760 14316.448} -status PLACED
place_inst -name r1016_0 -location {14765.760 14198.559} -status PLACED
place_inst -name r1016_1 -location {14765.760 14080.670} -status PLACED
place_inst -name b1016 -location {14765.760 13962.781} -status PLACED
place_inst -name b1017 -location {14766.240 13961.700} -status PLACED
place_inst -name r1018_0 -location {14766.240 13947.720} -status PLACED
place_inst -name r1018_1 -location {14766.240 13657.080} -status PLACED
place_inst -name r1018_2 -location {14766.240 13552.469} -status PLACED
place_inst -name r1018_3 -location {14766.240 13416.058} -status PLACED
place_inst -name b1018 -location {14766.240 13279.648} -status PLACED
place_inst -name r1019_0 -location {14883.340 14316.448} -status PLACED
place_inst -name r1019_1 -location {15001.399 14316.448} -status PLACED
place_inst -name b1019 -location {15119.459 14316.448} -status PLACED
place_inst -name r1020_0 -location {15119.000 14398.544} -status PLACED
place_inst -name b1020 -location {15120.540 14480.640} -status PLACED
place_inst -name r1021_0 -location {15130.740 14363.724} -status PLACED
place_inst -name r1021_1 -location {15234.972 14339.640} -status PLACED
place_inst -name r1021_2 -location {15363.288 14339.640} -status PLACED
place_inst -name r1021_3 -location {15476.340 14354.904} -status PLACED
place_inst -name b1021 -location {15473.760 14480.640} -status PLACED
place_inst -name r1022_0 -location {15473.760 14398.544} -status PLACED
place_inst -name b1022 -location {15473.760 14316.448} -status PLACED
place_inst -name b1023 -location {2756.160 14316.448} -status PLACED
place_inst -name r1024_0 -location {2756.160 14198.559} -status PLACED
place_inst -name r1024_1 -location {2756.160 14080.670} -status PLACED
place_inst -name b1024 -location {2756.160 13962.781} -status PLACED
place_inst -name b1025 -location {2755.680 13961.700} -status PLACED
place_inst -name r1026_0 -location {2755.680 13947.720} -status PLACED
place_inst -name r1026_1 -location {2755.680 13657.080} -status PLACED
place_inst -name r1026_2 -location {2755.680 13552.469} -status PLACED
place_inst -name r1026_3 -location {2755.680 13416.058} -status PLACED
place_inst -name b1026 -location {2755.680 13279.648} -status PLACED
place_inst -name r1027_0 -location {2638.580 14316.448} -status PLACED
place_inst -name r1027_1 -location {2520.521 14316.448} -status PLACED
place_inst -name b1027 -location {2402.461 14316.448} -status PLACED
place_inst -name r1028_0 -location {2402.920 14398.544} -status PLACED
place_inst -name b1028 -location {2401.380 14480.640} -status PLACED
place_inst -name r1029_0 -location {2403.960 14354.904} -status PLACED
place_inst -name r1029_1 -location {2290.908 14339.640} -status PLACED
place_inst -name r1029_2 -location {2162.592 14339.640} -status PLACED
place_inst -name r1029_3 -location {2047.560 14352.924} -status PLACED
place_inst -name b1029 -location {2048.160 14480.640} -status PLACED
place_inst -name r1030_0 -location {2048.160 14398.544} -status PLACED
place_inst -name b1030 -location {2048.160 14316.448} -status PLACED
place_inst -name b1031 -location {15474.240 12242.848} -status PLACED
place_inst -name r1032_0 -location {15474.240 12124.959} -status PLACED
place_inst -name r1032_1 -location {15474.240 12007.070} -status PLACED
place_inst -name b1032 -location {15474.240 11889.181} -status PLACED
place_inst -name b1033 -location {15474.720 11888.100} -status PLACED
place_inst -name r1034_0 -location {15474.720 11874.120} -status PLACED
place_inst -name r1034_1 -location {15474.720 11583.480} -status PLACED
place_inst -name r1034_2 -location {15474.720 11478.869} -status PLACED
place_inst -name r1034_3 -location {15474.720 11342.458} -status PLACED
place_inst -name b1034 -location {15474.720 11206.048} -status PLACED
place_inst -name r1035_0 -location {15591.820 12242.848} -status PLACED
place_inst -name r1035_1 -location {15709.879 12242.848} -status PLACED
place_inst -name b1035 -location {15827.939 12242.848} -status PLACED
place_inst -name r1036_0 -location {15827.480 12324.944} -status PLACED
place_inst -name b1036 -location {15829.020 12407.040} -status PLACED
place_inst -name r1037_0 -location {15839.220 12290.124} -status PLACED
place_inst -name r1037_1 -location {15943.452 12266.040} -status PLACED
place_inst -name r1037_2 -location {16071.768 12266.040} -status PLACED
place_inst -name r1037_3 -location {16184.820 12281.304} -status PLACED
place_inst -name b1037 -location {16182.240 12407.040} -status PLACED
place_inst -name r1038_0 -location {16182.240 12324.944} -status PLACED
place_inst -name b1038 -location {16182.240 12242.848} -status PLACED
place_inst -name b1039 -location {2047.680 12242.848} -status PLACED
place_inst -name r1040_0 -location {2047.680 12124.959} -status PLACED
place_inst -name r1040_1 -location {2047.680 12007.070} -status PLACED
place_inst -name b1040 -location {2047.680 11889.181} -status PLACED
place_inst -name b1041 -location {2047.200 11888.100} -status PLACED
place_inst -name r1042_0 -location {2047.200 11874.120} -status PLACED
place_inst -name r1042_1 -location {2047.200 11583.480} -status PLACED
place_inst -name r1042_2 -location {2047.200 11478.869} -status PLACED
place_inst -name r1042_3 -location {2047.200 11342.458} -status PLACED
place_inst -name b1042 -location {2047.200 11206.048} -status PLACED
place_inst -name r1043_0 -location {1930.100 12242.848} -status PLACED
place_inst -name r1043_1 -location {1812.041 12242.848} -status PLACED
place_inst -name b1043 -location {1693.981 12242.848} -status PLACED
place_inst -name r1044_0 -location {1694.440 12324.944} -status PLACED
place_inst -name b1044 -location {1692.900 12407.040} -status PLACED
place_inst -name r1045_0 -location {1695.480 12281.304} -status PLACED
place_inst -name r1045_1 -location {1582.428 12266.040} -status PLACED
place_inst -name r1045_2 -location {1454.112 12266.040} -status PLACED
place_inst -name r1045_3 -location {1339.080 12279.324} -status PLACED
place_inst -name b1045 -location {1339.680 12407.040} -status PLACED
place_inst -name r1046_0 -location {1339.680 12324.944} -status PLACED
place_inst -name b1046 -location {1339.680 12242.848} -status PLACED
place_inst -name b1047 -location {16182.720 10169.248} -status PLACED
place_inst -name r1048_0 -location {16182.720 10051.359} -status PLACED
place_inst -name r1048_1 -location {16182.720 9933.470} -status PLACED
place_inst -name b1048 -location {16182.720 9815.581} -status PLACED
place_inst -name b1049 -location {16183.200 9814.500} -status PLACED
place_inst -name r1050_0 -location {16183.200 9800.520} -status PLACED
place_inst -name r1050_1 -location {16183.200 9509.880} -status PLACED
place_inst -name r1050_2 -location {16183.200 9405.269} -status PLACED
place_inst -name r1050_3 -location {16183.200 9268.858} -status PLACED
place_inst -name b1050 -location {16183.200 9132.448} -status PLACED
place_inst -name r1051_0 -location {16300.300 10169.248} -status PLACED
place_inst -name r1051_1 -location {16418.359 10169.248} -status PLACED
place_inst -name b1051 -location {16536.419 10169.248} -status PLACED
place_inst -name r1052_0 -location {16535.960 10251.344} -status PLACED
place_inst -name b1052 -location {16537.500 10333.440} -status PLACED
place_inst -name r1053_0 -location {16547.700 10216.524} -status PLACED
place_inst -name r1053_1 -location {16651.932 10192.440} -status PLACED
place_inst -name r1053_2 -location {16780.248 10192.440} -status PLACED
place_inst -name r1053_3 -location {16893.300 10207.704} -status PLACED
place_inst -name b1053 -location {16890.720 10333.440} -status PLACED
place_inst -name r1054_0 -location {16890.720 10251.344} -status PLACED
place_inst -name b1054 -location {16890.720 10169.248} -status PLACED
place_inst -name b1055 -location {1339.200 10169.248} -status PLACED
place_inst -name r1056_0 -location {1339.200 10051.359} -status PLACED
place_inst -name r1056_1 -location {1339.200 9933.470} -status PLACED
place_inst -name b1056 -location {1339.200 9815.581} -status PLACED
place_inst -name b1057 -location {1338.720 9814.500} -status PLACED
place_inst -name r1058_0 -location {1338.720 9800.520} -status PLACED
place_inst -name r1058_1 -location {1338.720 9509.880} -status PLACED
place_inst -name r1058_2 -location {1338.720 9405.269} -status PLACED
place_inst -name r1058_3 -location {1338.720 9268.858} -status PLACED
place_inst -name b1058 -location {1338.720 9132.448} -status PLACED
place_inst -name r1059_0 -location {1221.620 10169.248} -status PLACED
place_inst -name r1059_1 -location {1103.561 10169.248} -status PLACED
place_inst -name b1059 -location {985.501 10169.248} -status PLACED
place_inst -name r1060_0 -location {985.960 10251.344} -status PLACED
place_inst -name b1060 -location {984.420 10333.440} -status PLACED
place_inst -name r1061_0 -location {987.000 10207.704} -status PLACED
place_inst -name r1061_1 -location {873.948 10192.440} -status PLACED
place_inst -name r1061_2 -location {745.632 10192.440} -status PLACED
place_inst -name r1061_3 -location {630.600 10205.724} -status PLACED
place_inst -name b1061 -location {631.200 10333.440} -status PLACED
place_inst -name r1062_0 -location {631.200 10251.344} -status PLACED
place_inst -name b1062 -location {631.200 10169.248} -status PLACED
place_inst -name b1063 -location {15474.240 3948.448} -status PLACED
place_inst -name r1064_0 -location {15474.240 3830.559} -status PLACED
place_inst -name r1064_1 -location {15474.240 3712.670} -status PLACED
place_inst -name b1064 -location {15474.240 3594.781} -status PLACED
place_inst -name b1065 -location {15474.720 3593.700} -status PLACED
place_inst -name r1066_0 -location {15474.720 3579.720} -status PLACED
place_inst -name r1066_1 -location {15474.720 3289.080} -status PLACED
place_inst -name r1066_2 -location {15474.720 3184.469} -status PLACED
place_inst -name r1066_3 -location {15474.720 3048.058} -status PLACED
place_inst -name b1066 -location {15474.720 2911.648} -status PLACED
place_inst -name r1067_0 -location {15591.820 3948.448} -status PLACED
place_inst -name r1067_1 -location {15709.879 3948.448} -status PLACED
place_inst -name b1067 -location {15827.939 3948.448} -status PLACED
place_inst -name r1068_0 -location {15827.480 4030.544} -status PLACED
place_inst -name b1068 -location {15829.020 4112.640} -status PLACED
place_inst -name r1069_0 -location {15839.220 3995.724} -status PLACED
place_inst -name r1069_1 -location {15943.452 3971.640} -status PLACED
place_inst -name r1069_2 -location {16071.768 3971.640} -status PLACED
place_inst -name r1069_3 -location {16184.820 3986.904} -status PLACED
place_inst -name b1069 -location {16182.240 4112.640} -status PLACED
place_inst -name r1070_0 -location {16182.240 4030.544} -status PLACED
place_inst -name b1070 -location {16182.240 3948.448} -status PLACED
place_inst -name b1071 -location {2047.680 3948.448} -status PLACED
place_inst -name r1072_0 -location {2047.680 3830.559} -status PLACED
place_inst -name r1072_1 -location {2047.680 3712.670} -status PLACED
place_inst -name b1072 -location {2047.680 3594.781} -status PLACED
place_inst -name b1073 -location {2047.200 3593.700} -status PLACED
place_inst -name r1074_0 -location {2047.200 3579.720} -status PLACED
place_inst -name r1074_1 -location {2047.200 3289.080} -status PLACED
place_inst -name r1074_2 -location {2047.200 3184.469} -status PLACED
place_inst -name r1074_3 -location {2047.200 3048.058} -status PLACED
place_inst -name b1074 -location {2047.200 2911.648} -status PLACED
place_inst -name r1075_0 -location {1930.100 3948.448} -status PLACED
place_inst -name r1075_1 -location {1812.041 3948.448} -status PLACED
place_inst -name b1075 -location {1693.981 3948.448} -status PLACED
place_inst -name r1076_0 -location {1694.440 4030.544} -status PLACED
place_inst -name b1076 -location {1692.900 4112.640} -status PLACED
place_inst -name r1077_0 -location {1695.480 3986.904} -status PLACED
place_inst -name r1077_1 -location {1582.428 3971.640} -status PLACED
place_inst -name r1077_2 -location {1454.112 3971.640} -status PLACED
place_inst -name r1077_3 -location {1339.080 3984.924} -status PLACED
place_inst -name b1077 -location {1339.680 4112.640} -status PLACED
place_inst -name r1078_0 -location {1339.680 4030.544} -status PLACED
place_inst -name b1078 -location {1339.680 3948.448} -status PLACED
place_inst -name b1079 -location {16182.720 6022.048} -status PLACED
place_inst -name r1080_0 -location {16182.720 5904.159} -status PLACED
place_inst -name r1080_1 -location {16182.720 5786.270} -status PLACED
place_inst -name b1080 -location {16182.720 5668.381} -status PLACED
place_inst -name b1081 -location {16183.200 5667.300} -status PLACED
place_inst -name r1082_0 -location {16183.200 5653.320} -status PLACED
place_inst -name r1082_1 -location {16183.200 5362.680} -status PLACED
place_inst -name r1082_2 -location {16183.200 5258.069} -status PLACED
place_inst -name r1082_3 -location {16183.200 5121.658} -status PLACED
place_inst -name b1082 -location {16183.200 4985.248} -status PLACED
place_inst -name r1083_0 -location {16300.300 6022.048} -status PLACED
place_inst -name r1083_1 -location {16418.359 6022.048} -status PLACED
place_inst -name b1083 -location {16536.419 6022.048} -status PLACED
place_inst -name r1084_0 -location {16535.960 6104.144} -status PLACED
place_inst -name b1084 -location {16537.500 6186.240} -status PLACED
place_inst -name r1085_0 -location {16547.700 6069.324} -status PLACED
place_inst -name r1085_1 -location {16651.932 6045.240} -status PLACED
place_inst -name r1085_2 -location {16780.248 6045.240} -status PLACED
place_inst -name r1085_3 -location {16893.300 6060.504} -status PLACED
place_inst -name b1085 -location {16890.720 6186.240} -status PLACED
place_inst -name r1086_0 -location {16890.720 6104.144} -status PLACED
place_inst -name b1086 -location {16890.720 6022.048} -status PLACED
place_inst -name b1087 -location {1339.200 6022.048} -status PLACED
place_inst -name r1088_0 -location {1339.200 5904.159} -status PLACED
place_inst -name r1088_1 -location {1339.200 5786.270} -status PLACED
place_inst -name b1088 -location {1339.200 5668.381} -status PLACED
place_inst -name b1089 -location {1338.720 5667.300} -status PLACED
place_inst -name r1090_0 -location {1338.720 5653.320} -status PLACED
place_inst -name r1090_1 -location {1338.720 5362.680} -status PLACED
place_inst -name r1090_2 -location {1338.720 5258.069} -status PLACED
place_inst -name r1090_3 -location {1338.720 5121.658} -status PLACED
place_inst -name b1090 -location {1338.720 4985.248} -status PLACED
place_inst -name r1091_0 -location {1221.620 6022.048} -status PLACED
place_inst -name r1091_1 -location {1103.561 6022.048} -status PLACED
place_inst -name b1091 -location {985.501 6022.048} -status PLACED
place_inst -name r1092_0 -location {985.960 6104.144} -status PLACED
place_inst -name b1092 -location {984.420 6186.240} -status PLACED
place_inst -name r1093_0 -location {987.000 6060.504} -status PLACED
place_inst -name r1093_1 -location {873.948 6045.240} -status PLACED
place_inst -name r1093_2 -location {745.632 6045.240} -status PLACED
place_inst -name r1093_3 -location {630.600 6058.524} -status PLACED
place_inst -name b1093 -location {631.200 6186.240} -status PLACED
place_inst -name r1094_0 -location {631.200 6104.144} -status PLACED
place_inst -name b1094 -location {631.200 6022.048} -status PLACED
place_inst -name b1095 -location {16891.200 8095.648} -status PLACED
place_inst -name r1096_0 -location {16891.200 7977.759} -status PLACED
place_inst -name r1096_1 -location {16891.200 7859.870} -status PLACED
place_inst -name b1096 -location {16891.200 7741.981} -status PLACED
place_inst -name b1097 -location {16891.680 7740.900} -status PLACED
place_inst -name r1098_0 -location {16891.680 7726.920} -status PLACED
place_inst -name r1098_1 -location {16891.680 7436.280} -status PLACED
place_inst -name r1098_2 -location {16891.680 7331.669} -status PLACED
place_inst -name r1098_3 -location {16891.680 7195.258} -status PLACED
place_inst -name b1098 -location {16891.680 7058.848} -status PLACED
place_inst -name r1099_0 -location {17008.780 8095.648} -status PLACED
place_inst -name r1099_1 -location {17126.839 8095.648} -status PLACED
place_inst -name b1099 -location {17244.899 8095.648} -status PLACED
place_inst -name b1100 -location {17245.984 8078.400} -status PLACED
place_inst -name b1101 -location {17306.869 8078.400} -status PLACED
place_inst -name r1102_0 -location {17306.869 8206.224} -status PLACED
place_inst -name b1102 -location {17306.869 8334.048} -status PLACED
place_inst -name b1103 -location {630.720 8095.648} -status PLACED
place_inst -name r1104_0 -location {630.720 7977.759} -status PLACED
place_inst -name r1104_1 -location {630.720 7859.870} -status PLACED
place_inst -name b1104 -location {630.720 7741.981} -status PLACED
place_inst -name b1105 -location {630.240 7740.900} -status PLACED
place_inst -name r1106_0 -location {630.240 7726.920} -status PLACED
place_inst -name r1106_1 -location {630.240 7436.280} -status PLACED
place_inst -name r1106_2 -location {630.240 7331.669} -status PLACED
place_inst -name r1106_3 -location {630.240 7195.258} -status PLACED
place_inst -name b1106 -location {630.240 7058.848} -status PLACED
place_inst -name r1107_0 -location {513.140 8095.648} -status PLACED
place_inst -name r1107_1 -location {395.081 8095.648} -status PLACED
place_inst -name b1107 -location {277.021 8095.648} -status PLACED
place_inst -name b1108 -location {275.936 8078.400} -status PLACED
place_inst -name b1109 -location {215.051 8078.400} -status PLACED
place_inst -name r1110_0 -location {215.051 8206.224} -status PLACED
place_inst -name b1110 -location {215.051 8334.048} -status PLACED
place_inst -name b1111 -location {15474.240 14316.448} -status PLACED
place_inst -name r1112_0 -location {15474.240 14198.559} -status PLACED
place_inst -name r1112_1 -location {15474.240 14080.670} -status PLACED
place_inst -name b1112 -location {15474.240 13962.781} -status PLACED
place_inst -name b1113 -location {15474.720 13961.700} -status PLACED
place_inst -name r1114_0 -location {15474.720 13947.720} -status PLACED
place_inst -name r1114_1 -location {15474.720 13657.080} -status PLACED
place_inst -name r1114_2 -location {15474.720 13552.469} -status PLACED
place_inst -name r1114_3 -location {15474.720 13416.058} -status PLACED
place_inst -name b1114 -location {15474.720 13279.648} -status PLACED
place_inst -name r1115_0 -location {15591.820 14316.448} -status PLACED
place_inst -name r1115_1 -location {15709.879 14316.448} -status PLACED
place_inst -name b1115 -location {15827.939 14316.448} -status PLACED
place_inst -name r1116_0 -location {15827.480 14398.544} -status PLACED
place_inst -name b1116 -location {15829.020 14480.640} -status PLACED
place_inst -name r1117_0 -location {15839.220 14363.724} -status PLACED
place_inst -name r1117_1 -location {15943.452 14339.640} -status PLACED
place_inst -name r1117_2 -location {16071.768 14339.640} -status PLACED
place_inst -name r1117_3 -location {16184.820 14354.904} -status PLACED
place_inst -name b1117 -location {16182.240 14480.640} -status PLACED
place_inst -name r1118_0 -location {16182.240 14398.544} -status PLACED
place_inst -name b1118 -location {16182.240 14316.448} -status PLACED
place_inst -name b1119 -location {2047.680 14316.448} -status PLACED
place_inst -name r1120_0 -location {2047.680 14198.559} -status PLACED
place_inst -name r1120_1 -location {2047.680 14080.670} -status PLACED
place_inst -name b1120 -location {2047.680 13962.781} -status PLACED
place_inst -name b1121 -location {2047.200 13961.700} -status PLACED
place_inst -name r1122_0 -location {2047.200 13947.720} -status PLACED
place_inst -name r1122_1 -location {2047.200 13657.080} -status PLACED
place_inst -name r1122_2 -location {2047.200 13552.469} -status PLACED
place_inst -name r1122_3 -location {2047.200 13416.058} -status PLACED
place_inst -name b1122 -location {2047.200 13279.648} -status PLACED
place_inst -name r1123_0 -location {1930.100 14316.448} -status PLACED
place_inst -name r1123_1 -location {1812.041 14316.448} -status PLACED
place_inst -name b1123 -location {1693.981 14316.448} -status PLACED
place_inst -name r1124_0 -location {1694.440 14398.544} -status PLACED
place_inst -name b1124 -location {1692.900 14480.640} -status PLACED
place_inst -name r1125_0 -location {1695.480 14354.904} -status PLACED
place_inst -name r1125_1 -location {1582.428 14339.640} -status PLACED
place_inst -name r1125_2 -location {1454.112 14339.640} -status PLACED
place_inst -name r1125_3 -location {1339.080 14352.924} -status PLACED
place_inst -name b1125 -location {1339.680 14480.640} -status PLACED
place_inst -name r1126_0 -location {1339.680 14398.544} -status PLACED
place_inst -name b1126 -location {1339.680 14316.448} -status PLACED
place_inst -name b1127 -location {16182.720 12242.848} -status PLACED
place_inst -name r1128_0 -location {16182.720 12124.959} -status PLACED
place_inst -name r1128_1 -location {16182.720 12007.070} -status PLACED
place_inst -name b1128 -location {16182.720 11889.181} -status PLACED
place_inst -name b1129 -location {16183.200 11888.100} -status PLACED
place_inst -name r1130_0 -location {16183.200 11874.120} -status PLACED
place_inst -name r1130_1 -location {16183.200 11583.480} -status PLACED
place_inst -name r1130_2 -location {16183.200 11478.869} -status PLACED
place_inst -name r1130_3 -location {16183.200 11342.458} -status PLACED
place_inst -name b1130 -location {16183.200 11206.048} -status PLACED
place_inst -name r1131_0 -location {16300.300 12242.848} -status PLACED
place_inst -name r1131_1 -location {16418.359 12242.848} -status PLACED
place_inst -name b1131 -location {16536.419 12242.848} -status PLACED
place_inst -name r1132_0 -location {16535.960 12324.944} -status PLACED
place_inst -name b1132 -location {16537.500 12407.040} -status PLACED
place_inst -name r1133_0 -location {16547.700 12290.124} -status PLACED
place_inst -name r1133_1 -location {16651.932 12266.040} -status PLACED
place_inst -name r1133_2 -location {16780.248 12266.040} -status PLACED
place_inst -name r1133_3 -location {16893.300 12281.304} -status PLACED
place_inst -name b1133 -location {16890.720 12407.040} -status PLACED
place_inst -name r1134_0 -location {16890.720 12324.944} -status PLACED
place_inst -name b1134 -location {16890.720 12242.848} -status PLACED
place_inst -name b1135 -location {1339.200 12242.848} -status PLACED
place_inst -name r1136_0 -location {1339.200 12124.959} -status PLACED
place_inst -name r1136_1 -location {1339.200 12007.070} -status PLACED
place_inst -name b1136 -location {1339.200 11889.181} -status PLACED
place_inst -name b1137 -location {1338.720 11888.100} -status PLACED
place_inst -name r1138_0 -location {1338.720 11874.120} -status PLACED
place_inst -name r1138_1 -location {1338.720 11583.480} -status PLACED
place_inst -name r1138_2 -location {1338.720 11478.869} -status PLACED
place_inst -name r1138_3 -location {1338.720 11342.458} -status PLACED
place_inst -name b1138 -location {1338.720 11206.048} -status PLACED
place_inst -name r1139_0 -location {1221.620 12242.848} -status PLACED
place_inst -name r1139_1 -location {1103.561 12242.848} -status PLACED
place_inst -name b1139 -location {985.501 12242.848} -status PLACED
place_inst -name r1140_0 -location {985.960 12324.944} -status PLACED
place_inst -name b1140 -location {984.420 12407.040} -status PLACED
place_inst -name r1141_0 -location {987.000 12281.304} -status PLACED
place_inst -name r1141_1 -location {873.948 12266.040} -status PLACED
place_inst -name r1141_2 -location {745.632 12266.040} -status PLACED
place_inst -name r1141_3 -location {630.600 12279.324} -status PLACED
place_inst -name b1141 -location {631.200 12407.040} -status PLACED
place_inst -name r1142_0 -location {631.200 12324.944} -status PLACED
place_inst -name b1142 -location {631.200 12242.848} -status PLACED
place_inst -name b1143 -location {16891.200 10169.248} -status PLACED
place_inst -name r1144_0 -location {16891.200 10051.359} -status PLACED
place_inst -name r1144_1 -location {16891.200 9933.470} -status PLACED
place_inst -name b1144 -location {16891.200 9815.581} -status PLACED
place_inst -name b1145 -location {16891.680 9814.500} -status PLACED
place_inst -name r1146_0 -location {16891.680 9800.520} -status PLACED
place_inst -name r1146_1 -location {16891.680 9509.880} -status PLACED
place_inst -name r1146_2 -location {16891.680 9405.269} -status PLACED
place_inst -name r1146_3 -location {16891.680 9268.858} -status PLACED
place_inst -name b1146 -location {16891.680 9132.448} -status PLACED
place_inst -name r1147_0 -location {17008.780 10169.248} -status PLACED
place_inst -name r1147_1 -location {17126.839 10169.248} -status PLACED
place_inst -name b1147 -location {17244.899 10169.248} -status PLACED
place_inst -name b1148 -location {17245.984 10152.000} -status PLACED
place_inst -name b1149 -location {17306.869 10152.000} -status PLACED
place_inst -name r1150_0 -location {17306.869 10279.824} -status PLACED
place_inst -name b1150 -location {17306.869 10407.648} -status PLACED
place_inst -name b1151 -location {630.720 10169.248} -status PLACED
place_inst -name r1152_0 -location {630.720 10051.359} -status PLACED
place_inst -name r1152_1 -location {630.720 9933.470} -status PLACED
place_inst -name b1152 -location {630.720 9815.581} -status PLACED
place_inst -name b1153 -location {630.240 9814.500} -status PLACED
place_inst -name r1154_0 -location {630.240 9800.520} -status PLACED
place_inst -name r1154_1 -location {630.240 9509.880} -status PLACED
place_inst -name r1154_2 -location {630.240 9405.269} -status PLACED
place_inst -name r1154_3 -location {630.240 9268.858} -status PLACED
place_inst -name b1154 -location {630.240 9132.448} -status PLACED
place_inst -name r1155_0 -location {513.140 10169.248} -status PLACED
place_inst -name r1155_1 -location {395.081 10169.248} -status PLACED
place_inst -name b1155 -location {277.021 10169.248} -status PLACED
place_inst -name b1156 -location {275.936 10152.000} -status PLACED
place_inst -name b1157 -location {215.051 10152.000} -status PLACED
place_inst -name r1158_0 -location {215.051 10279.824} -status PLACED
place_inst -name b1158 -location {215.051 10407.648} -status PLACED
place_inst -name b1159 -location {16182.720 3948.448} -status PLACED
place_inst -name r1160_0 -location {16182.720 3830.559} -status PLACED
place_inst -name r1160_1 -location {16182.720 3712.670} -status PLACED
place_inst -name b1160 -location {16182.720 3594.781} -status PLACED
place_inst -name b1161 -location {16183.200 3593.700} -status PLACED
place_inst -name r1162_0 -location {16183.200 3579.720} -status PLACED
place_inst -name r1162_1 -location {16183.200 3289.080} -status PLACED
place_inst -name r1162_2 -location {16183.200 3184.469} -status PLACED
place_inst -name r1162_3 -location {16183.200 3048.058} -status PLACED
place_inst -name b1162 -location {16183.200 2911.648} -status PLACED
place_inst -name r1163_0 -location {16300.300 3948.448} -status PLACED
place_inst -name r1163_1 -location {16418.359 3948.448} -status PLACED
place_inst -name b1163 -location {16536.419 3948.448} -status PLACED
place_inst -name r1164_0 -location {16535.960 4030.544} -status PLACED
place_inst -name b1164 -location {16537.500 4112.640} -status PLACED
place_inst -name r1165_0 -location {16547.700 3995.724} -status PLACED
place_inst -name r1165_1 -location {16651.932 3971.640} -status PLACED
place_inst -name r1165_2 -location {16780.248 3971.640} -status PLACED
place_inst -name r1165_3 -location {16893.300 3986.904} -status PLACED
place_inst -name b1165 -location {16890.720 4112.640} -status PLACED
place_inst -name r1166_0 -location {16890.720 4030.544} -status PLACED
place_inst -name b1166 -location {16890.720 3948.448} -status PLACED
place_inst -name b1167 -location {1339.200 3948.448} -status PLACED
place_inst -name r1168_0 -location {1339.200 3830.559} -status PLACED
place_inst -name r1168_1 -location {1339.200 3712.670} -status PLACED
place_inst -name b1168 -location {1339.200 3594.781} -status PLACED
place_inst -name b1169 -location {1338.720 3593.700} -status PLACED
place_inst -name r1170_0 -location {1338.720 3579.720} -status PLACED
place_inst -name r1170_1 -location {1338.720 3289.080} -status PLACED
place_inst -name r1170_2 -location {1338.720 3184.469} -status PLACED
place_inst -name r1170_3 -location {1338.720 3048.058} -status PLACED
place_inst -name b1170 -location {1338.720 2911.648} -status PLACED
place_inst -name r1171_0 -location {1221.620 3948.448} -status PLACED
place_inst -name r1171_1 -location {1103.561 3948.448} -status PLACED
place_inst -name b1171 -location {985.501 3948.448} -status PLACED
place_inst -name r1172_0 -location {985.960 4030.544} -status PLACED
place_inst -name b1172 -location {984.420 4112.640} -status PLACED
place_inst -name r1173_0 -location {987.000 3986.904} -status PLACED
place_inst -name r1173_1 -location {873.948 3971.640} -status PLACED
place_inst -name r1173_2 -location {745.632 3971.640} -status PLACED
place_inst -name r1173_3 -location {630.600 3984.924} -status PLACED
place_inst -name b1173 -location {631.200 4112.640} -status PLACED
place_inst -name r1174_0 -location {631.200 4030.544} -status PLACED
place_inst -name b1174 -location {631.200 3948.448} -status PLACED
place_inst -name b1175 -location {16891.200 6022.048} -status PLACED
place_inst -name r1176_0 -location {16891.200 5904.159} -status PLACED
place_inst -name r1176_1 -location {16891.200 5786.270} -status PLACED
place_inst -name b1176 -location {16891.200 5668.381} -status PLACED
place_inst -name b1177 -location {16891.680 5667.300} -status PLACED
place_inst -name r1178_0 -location {16891.680 5653.320} -status PLACED
place_inst -name r1178_1 -location {16891.680 5362.680} -status PLACED
place_inst -name r1178_2 -location {16891.680 5258.069} -status PLACED
place_inst -name r1178_3 -location {16891.680 5121.658} -status PLACED
place_inst -name b1178 -location {16891.680 4985.248} -status PLACED
place_inst -name r1179_0 -location {17008.780 6022.048} -status PLACED
place_inst -name r1179_1 -location {17126.839 6022.048} -status PLACED
place_inst -name b1179 -location {17244.899 6022.048} -status PLACED
place_inst -name b1180 -location {17245.984 6004.800} -status PLACED
place_inst -name b1181 -location {17306.869 6004.800} -status PLACED
place_inst -name r1182_0 -location {17306.869 6132.624} -status PLACED
place_inst -name b1182 -location {17306.869 6260.448} -status PLACED
place_inst -name b1183 -location {630.720 6022.048} -status PLACED
place_inst -name r1184_0 -location {630.720 5904.159} -status PLACED
place_inst -name r1184_1 -location {630.720 5786.270} -status PLACED
place_inst -name b1184 -location {630.720 5668.381} -status PLACED
place_inst -name b1185 -location {630.240 5667.300} -status PLACED
place_inst -name r1186_0 -location {630.240 5653.320} -status PLACED
place_inst -name r1186_1 -location {630.240 5362.680} -status PLACED
place_inst -name r1186_2 -location {630.240 5258.069} -status PLACED
place_inst -name r1186_3 -location {630.240 5121.658} -status PLACED
place_inst -name b1186 -location {630.240 4985.248} -status PLACED
place_inst -name r1187_0 -location {513.140 6022.048} -status PLACED
place_inst -name r1187_1 -location {395.081 6022.048} -status PLACED
place_inst -name b1187 -location {277.021 6022.048} -status PLACED
place_inst -name b1188 -location {275.936 6004.800} -status PLACED
place_inst -name b1189 -location {215.051 6004.800} -status PLACED
place_inst -name r1190_0 -location {215.051 6132.624} -status PLACED
place_inst -name b1190 -location {215.051 6260.448} -status PLACED
place_inst -name b1191 -location {17331.840 8334.048} -status PLACED
place_inst -name r1192_0 -location {17331.840 8186.031} -status PLACED
place_inst -name r1192_1 -location {17331.840 8038.014} -status PLACED
place_inst -name r1192_2 -location {17331.840 7889.997} -status PLACED
place_inst -name b1192 -location {17331.840 7741.980} -status PLACED
place_inst -name b1193 -location {17332.320 7740.896} -status PLACED
place_inst -name b1194 -location {17332.320 7712.608} -status PLACED
place_inst -name b1195 -location {190.080 8334.048} -status PLACED
place_inst -name r1196_0 -location {190.080 8186.031} -status PLACED
place_inst -name r1196_1 -location {190.080 8038.014} -status PLACED
place_inst -name r1196_2 -location {190.080 7889.997} -status PLACED
place_inst -name b1196 -location {190.080 7741.980} -status PLACED
place_inst -name b1197 -location {189.600 7740.896} -status PLACED
place_inst -name b1198 -location {189.600 7712.608} -status PLACED
place_inst -name b1199 -location {16182.720 14316.448} -status PLACED
place_inst -name r1200_0 -location {16182.720 14198.559} -status PLACED
place_inst -name r1200_1 -location {16182.720 14080.670} -status PLACED
place_inst -name b1200 -location {16182.720 13962.781} -status PLACED
place_inst -name b1201 -location {16183.200 13961.700} -status PLACED
place_inst -name r1202_0 -location {16183.200 13947.720} -status PLACED
place_inst -name r1202_1 -location {16183.200 13657.080} -status PLACED
place_inst -name r1202_2 -location {16183.200 13552.469} -status PLACED
place_inst -name r1202_3 -location {16183.200 13416.058} -status PLACED
place_inst -name b1202 -location {16183.200 13279.648} -status PLACED
place_inst -name r1203_0 -location {16300.300 14316.448} -status PLACED
place_inst -name r1203_1 -location {16418.359 14316.448} -status PLACED
place_inst -name b1203 -location {16536.419 14316.448} -status PLACED
place_inst -name r1204_0 -location {16535.960 14398.544} -status PLACED
place_inst -name b1204 -location {16537.500 14480.640} -status PLACED
place_inst -name r1205_0 -location {16547.700 14363.724} -status PLACED
place_inst -name r1205_1 -location {16651.932 14339.640} -status PLACED
place_inst -name r1205_2 -location {16780.248 14339.640} -status PLACED
place_inst -name r1205_3 -location {16893.300 14354.904} -status PLACED
place_inst -name b1205 -location {16890.720 14480.640} -status PLACED
place_inst -name r1206_0 -location {16890.720 14398.544} -status PLACED
place_inst -name b1206 -location {16890.720 14316.448} -status PLACED
place_inst -name b1207 -location {1339.200 14316.448} -status PLACED
place_inst -name r1208_0 -location {1339.200 14198.559} -status PLACED
place_inst -name r1208_1 -location {1339.200 14080.670} -status PLACED
place_inst -name b1208 -location {1339.200 13962.781} -status PLACED
place_inst -name b1209 -location {1338.720 13961.700} -status PLACED
place_inst -name r1210_0 -location {1338.720 13947.720} -status PLACED
place_inst -name r1210_1 -location {1338.720 13657.080} -status PLACED
place_inst -name r1210_2 -location {1338.720 13552.469} -status PLACED
place_inst -name r1210_3 -location {1338.720 13416.058} -status PLACED
place_inst -name b1210 -location {1338.720 13279.648} -status PLACED
place_inst -name r1211_0 -location {1221.620 14316.448} -status PLACED
place_inst -name r1211_1 -location {1103.561 14316.448} -status PLACED
place_inst -name b1211 -location {985.501 14316.448} -status PLACED
place_inst -name r1212_0 -location {985.960 14398.544} -status PLACED
place_inst -name b1212 -location {984.420 14480.640} -status PLACED
place_inst -name r1213_0 -location {987.000 14354.904} -status PLACED
place_inst -name r1213_1 -location {873.948 14339.640} -status PLACED
place_inst -name r1213_2 -location {745.632 14339.640} -status PLACED
place_inst -name r1213_3 -location {630.600 14352.924} -status PLACED
place_inst -name b1213 -location {631.200 14480.640} -status PLACED
place_inst -name r1214_0 -location {631.200 14398.544} -status PLACED
place_inst -name b1214 -location {631.200 14316.448} -status PLACED
place_inst -name b1215 -location {16891.200 12242.848} -status PLACED
place_inst -name r1216_0 -location {16891.200 12124.959} -status PLACED
place_inst -name r1216_1 -location {16891.200 12007.070} -status PLACED
place_inst -name b1216 -location {16891.200 11889.181} -status PLACED
place_inst -name b1217 -location {16891.680 11888.100} -status PLACED
place_inst -name r1218_0 -location {16891.680 11874.120} -status PLACED
place_inst -name r1218_1 -location {16891.680 11583.480} -status PLACED
place_inst -name r1218_2 -location {16891.680 11478.869} -status PLACED
place_inst -name r1218_3 -location {16891.680 11342.458} -status PLACED
place_inst -name b1218 -location {16891.680 11206.048} -status PLACED
place_inst -name r1219_0 -location {17008.780 12242.848} -status PLACED
place_inst -name r1219_1 -location {17126.839 12242.848} -status PLACED
place_inst -name b1219 -location {17244.899 12242.848} -status PLACED
place_inst -name b1220 -location {17245.984 12225.600} -status PLACED
place_inst -name b1221 -location {17306.869 12225.600} -status PLACED
place_inst -name r1222_0 -location {17306.869 12353.424} -status PLACED
place_inst -name b1222 -location {17306.869 12481.248} -status PLACED
place_inst -name b1223 -location {630.720 12242.848} -status PLACED
place_inst -name r1224_0 -location {630.720 12124.959} -status PLACED
place_inst -name r1224_1 -location {630.720 12007.070} -status PLACED
place_inst -name b1224 -location {630.720 11889.181} -status PLACED
place_inst -name b1225 -location {630.240 11888.100} -status PLACED
place_inst -name r1226_0 -location {630.240 11874.120} -status PLACED
place_inst -name r1226_1 -location {630.240 11583.480} -status PLACED
place_inst -name r1226_2 -location {630.240 11478.869} -status PLACED
place_inst -name r1226_3 -location {630.240 11342.458} -status PLACED
place_inst -name b1226 -location {630.240 11206.048} -status PLACED
place_inst -name r1227_0 -location {513.140 12242.848} -status PLACED
place_inst -name r1227_1 -location {395.081 12242.848} -status PLACED
place_inst -name b1227 -location {277.021 12242.848} -status PLACED
place_inst -name b1228 -location {275.936 12225.600} -status PLACED
place_inst -name b1229 -location {215.051 12225.600} -status PLACED
place_inst -name r1230_0 -location {215.051 12353.424} -status PLACED
place_inst -name b1230 -location {215.051 12481.248} -status PLACED
place_inst -name b1231 -location {17331.840 10407.648} -status PLACED
place_inst -name r1232_0 -location {17331.840 10259.631} -status PLACED
place_inst -name r1232_1 -location {17331.840 10111.614} -status PLACED
place_inst -name r1232_2 -location {17331.840 9963.597} -status PLACED
place_inst -name b1232 -location {17331.840 9815.580} -status PLACED
place_inst -name b1233 -location {17332.320 9814.496} -status PLACED
place_inst -name b1234 -location {17332.320 9786.208} -status PLACED
place_inst -name b1235 -location {190.080 10407.648} -status PLACED
place_inst -name r1236_0 -location {190.080 10259.631} -status PLACED
place_inst -name r1236_1 -location {190.080 10111.614} -status PLACED
place_inst -name r1236_2 -location {190.080 9963.597} -status PLACED
place_inst -name b1236 -location {190.080 9815.580} -status PLACED
place_inst -name b1237 -location {189.600 9814.496} -status PLACED
place_inst -name b1238 -location {189.600 9786.208} -status PLACED
place_inst -name b1239 -location {16891.200 3948.448} -status PLACED
place_inst -name r1240_0 -location {16891.200 3830.559} -status PLACED
place_inst -name r1240_1 -location {16891.200 3712.670} -status PLACED
place_inst -name b1240 -location {16891.200 3594.781} -status PLACED
place_inst -name b1241 -location {16891.680 3593.700} -status PLACED
place_inst -name r1242_0 -location {16891.680 3579.720} -status PLACED
place_inst -name r1242_1 -location {16891.680 3289.080} -status PLACED
place_inst -name r1242_2 -location {16891.680 3184.469} -status PLACED
place_inst -name r1242_3 -location {16891.680 3048.058} -status PLACED
place_inst -name b1242 -location {16891.680 2911.648} -status PLACED
place_inst -name r1243_0 -location {17008.780 3948.448} -status PLACED
place_inst -name r1243_1 -location {17126.839 3948.448} -status PLACED
place_inst -name b1243 -location {17244.899 3948.448} -status PLACED
place_inst -name b1244 -location {17245.984 3931.200} -status PLACED
place_inst -name b1245 -location {17306.869 3931.200} -status PLACED
place_inst -name r1246_0 -location {17306.869 4059.024} -status PLACED
place_inst -name b1246 -location {17306.869 4186.848} -status PLACED
place_inst -name b1247 -location {630.720 3948.448} -status PLACED
place_inst -name r1248_0 -location {630.720 3830.559} -status PLACED
place_inst -name r1248_1 -location {630.720 3712.670} -status PLACED
place_inst -name b1248 -location {630.720 3594.781} -status PLACED
place_inst -name b1249 -location {630.240 3593.700} -status PLACED
place_inst -name r1250_0 -location {630.240 3579.720} -status PLACED
place_inst -name r1250_1 -location {630.240 3289.080} -status PLACED
place_inst -name r1250_2 -location {630.240 3184.469} -status PLACED
place_inst -name r1250_3 -location {630.240 3048.058} -status PLACED
place_inst -name b1250 -location {630.240 2911.648} -status PLACED
place_inst -name r1251_0 -location {513.140 3948.448} -status PLACED
place_inst -name r1251_1 -location {395.081 3948.448} -status PLACED
place_inst -name b1251 -location {277.021 3948.448} -status PLACED
place_inst -name b1252 -location {275.936 3931.200} -status PLACED
place_inst -name b1253 -location {215.051 3931.200} -status PLACED
place_inst -name r1254_0 -location {215.051 4059.024} -status PLACED
place_inst -name b1254 -location {215.051 4186.848} -status PLACED
place_inst -name b1255 -location {17331.840 6260.448} -status PLACED
place_inst -name r1256_0 -location {17331.840 6112.431} -status PLACED
place_inst -name r1256_1 -location {17331.840 5964.414} -status PLACED
place_inst -name r1256_2 -location {17331.840 5816.397} -status PLACED
place_inst -name b1256 -location {17331.840 5668.380} -status PLACED
place_inst -name b1257 -location {17332.320 5667.296} -status PLACED
place_inst -name b1258 -location {17332.320 5639.008} -status PLACED
place_inst -name b1259 -location {190.080 6260.448} -status PLACED
place_inst -name r1260_0 -location {190.080 6112.431} -status PLACED
place_inst -name r1260_1 -location {190.080 5964.414} -status PLACED
place_inst -name r1260_2 -location {190.080 5816.397} -status PLACED
place_inst -name b1260 -location {190.080 5668.380} -status PLACED
place_inst -name b1261 -location {189.600 5667.296} -status PLACED
place_inst -name b1262 -location {189.600 5639.008} -status PLACED
place_inst -name b1263 -location {16891.200 14316.448} -status PLACED
place_inst -name r1264_0 -location {16891.200 14198.559} -status PLACED
place_inst -name r1264_1 -location {16891.200 14080.670} -status PLACED
place_inst -name b1264 -location {16891.200 13962.781} -status PLACED
place_inst -name b1265 -location {16891.680 13961.700} -status PLACED
place_inst -name r1266_0 -location {16891.680 13947.720} -status PLACED
place_inst -name r1266_1 -location {16891.680 13657.080} -status PLACED
place_inst -name r1266_2 -location {16891.680 13552.469} -status PLACED
place_inst -name r1266_3 -location {16891.680 13416.058} -status PLACED
place_inst -name b1266 -location {16891.680 13279.648} -status PLACED
place_inst -name r1267_0 -location {17008.780 14316.448} -status PLACED
place_inst -name r1267_1 -location {17126.839 14316.448} -status PLACED
place_inst -name b1267 -location {17244.899 14316.448} -status PLACED
place_inst -name b1268 -location {17245.984 14299.200} -status PLACED
place_inst -name b1269 -location {17306.869 14299.200} -status PLACED
place_inst -name r1270_0 -location {17306.869 14427.024} -status PLACED
place_inst -name b1270 -location {17306.869 14554.848} -status PLACED
place_inst -name b1271 -location {630.720 14316.448} -status PLACED
place_inst -name r1272_0 -location {630.720 14198.559} -status PLACED
place_inst -name r1272_1 -location {630.720 14080.670} -status PLACED
place_inst -name b1272 -location {630.720 13962.781} -status PLACED
place_inst -name b1273 -location {630.240 13961.700} -status PLACED
place_inst -name r1274_0 -location {630.240 13947.720} -status PLACED
place_inst -name r1274_1 -location {630.240 13657.080} -status PLACED
place_inst -name r1274_2 -location {630.240 13552.469} -status PLACED
place_inst -name r1274_3 -location {630.240 13416.058} -status PLACED
place_inst -name b1274 -location {630.240 13279.648} -status PLACED
place_inst -name r1275_0 -location {513.140 14316.448} -status PLACED
place_inst -name r1275_1 -location {395.081 14316.448} -status PLACED
place_inst -name b1275 -location {277.021 14316.448} -status PLACED
place_inst -name b1276 -location {275.936 14299.200} -status PLACED
place_inst -name b1277 -location {215.051 14299.200} -status PLACED
place_inst -name r1278_0 -location {215.051 14427.024} -status PLACED
place_inst -name b1278 -location {215.051 14554.848} -status PLACED
place_inst -name b1279 -location {17331.840 12481.248} -status PLACED
place_inst -name r1280_0 -location {17331.840 12333.231} -status PLACED
place_inst -name r1280_1 -location {17331.840 12185.214} -status PLACED
place_inst -name r1280_2 -location {17331.840 12037.197} -status PLACED
place_inst -name b1280 -location {17331.840 11889.180} -status PLACED
place_inst -name b1281 -location {17332.320 11888.096} -status PLACED
place_inst -name b1282 -location {17332.320 11859.808} -status PLACED
place_inst -name b1283 -location {190.080 12481.248} -status PLACED
place_inst -name r1284_0 -location {190.080 12333.231} -status PLACED
place_inst -name r1284_1 -location {190.080 12185.214} -status PLACED
place_inst -name r1284_2 -location {190.080 12037.197} -status PLACED
place_inst -name b1284 -location {190.080 11889.180} -status PLACED
place_inst -name b1285 -location {189.600 11888.096} -status PLACED
place_inst -name b1286 -location {189.600 11859.808} -status PLACED
place_inst -name b1287 -location {17331.840 4186.848} -status PLACED
place_inst -name r1288_0 -location {17331.840 4038.831} -status PLACED
place_inst -name r1288_1 -location {17331.840 3890.814} -status PLACED
place_inst -name r1288_2 -location {17331.840 3742.797} -status PLACED
place_inst -name b1288 -location {17331.840 3594.780} -status PLACED
place_inst -name b1289 -location {17332.320 3593.696} -status PLACED
place_inst -name b1290 -location {17332.320 3565.408} -status PLACED
place_inst -name b1291 -location {190.080 4186.848} -status PLACED
place_inst -name r1292_0 -location {190.080 4038.831} -status PLACED
place_inst -name r1292_1 -location {190.080 3890.814} -status PLACED
place_inst -name r1292_2 -location {190.080 3742.797} -status PLACED
place_inst -name b1292 -location {190.080 3594.780} -status PLACED
place_inst -name b1293 -location {189.600 3593.696} -status PLACED
place_inst -name b1294 -location {189.600 3565.408} -status PLACED
place_inst -name b1295 -location {17331.840 14554.848} -status PLACED
place_inst -name r1296_0 -location {17331.840 14406.831} -status PLACED
place_inst -name r1296_1 -location {17331.840 14258.814} -status PLACED
place_inst -name r1296_2 -location {17331.840 14110.797} -status PLACED
place_inst -name b1296 -location {17331.840 13962.780} -status PLACED
place_inst -name b1297 -location {17332.320 13961.696} -status PLACED
place_inst -name b1298 -location {17332.320 13933.408} -status PLACED
place_inst -name b1299 -location {190.080 14554.848} -status PLACED
place_inst -name r1300_0 -location {190.080 14406.831} -status PLACED
place_inst -name r1300_1 -location {190.080 14258.814} -status PLACED
place_inst -name r1300_2 -location {190.080 14110.797} -status PLACED
place_inst -name b1300 -location {190.080 13962.780} -status PLACED
place_inst -name b1301 -location {189.600 13961.696} -status PLACED
place_inst -name b1302 -location {189.600 13933.408} -status PLACED
place_inst -name r1303_0 -location {8837.915 7766.053} -status PLACED
place_inst -name r1303_1 -location {8914.871 7791.666} -status PLACED
place_inst -name b1303 -location {8991.826 7817.279} -status PLACED
place_inst -name r1304_0 -location {8991.826 7967.253} -status PLACED
place_inst -name r1304_1 -location {8991.826 8117.227} -status PLACED
place_inst -name r1304_2 -location {8991.826 8267.202} -status PLACED
place_inst -name b1304 -location {8991.826 8417.176} -status PLACED
place_inst -name r1305_0 -location {8890.373 8462.874} -status PLACED
place_inst -name r1305_1 -location {8788.921 8508.572} -status PLACED
place_inst -name r1305_2 -location {8687.468 8554.270} -status PLACED
place_inst -name b1305 -location {8586.016 8599.968} -status PLACED
place_inst -name r1306_0 -location {8503.104 8599.968} -status PLACED
place_inst -name b1306 -location {8420.192 8599.968} -status PLACED
place_inst -name r1307_0 -location {8668.928 8599.968} -status PLACED
place_inst -name b1307 -location {8751.840 8599.968} -status PLACED
place_inst -name b1308 -location {8991.826 8399.991} -status PLACED
place_inst -name b1309 -location {8991.826 8399.991} -status PLACED
place_inst -name r1310_0 -location {8995.245 8287.540} -status PLACED
place_inst -name b1310 -location {8998.664 8175.090} -status PLACED
place_inst -name r1311_0 -location {8993.549 8262.505} -status PLACED
place_inst -name b1311 -location {8988.434 8349.920} -status PLACED
place_inst -name b1312 -location {8855.520 8351.776} -status PLACED
place_inst -name b1313 -location {9005.280 8349.920} -status PLACED
place_inst -name b1314 -location {9005.280 8321.952} -status PLACED
place_inst -name b1315 -location {9005.280 8377.888} -status PLACED
place_inst -name b1316 -location {9002.984 8074.016} -status PLACED
place_inst -name r1317_0 -location {9102.052 8080.544} -status PLACED
place_inst -name b1317 -location {9201.120 8087.072} -status PLACED
place_inst -name b1318 -location {8998.674 8074.016} -status PLACED
place_inst -name b1319 -location {8852.192 8074.016} -status PLACED
place_inst -name b1320 -location {9005.280 8050.464} -status PLACED
place_inst -name b1321 -location {9005.280 8005.152} -status PLACED
place_inst -name b1322 -location {9005.280 8095.776} -status PLACED
place_inst -name r1323_0 -location {8991.826 8541.609} -status PLACED
place_inst -name b1323 -location {8991.826 8683.228} -status PLACED
place_inst -name r1324_0 -location {8923.671 8645.235} -status PLACED
place_inst -name r1324_1 -location {8855.515 8607.241} -status PLACED
place_inst -name b1324 -location {8787.360 8569.248} -status PLACED
place_inst -name b1325 -location {8996.146 8760.992} -status PLACED
place_inst -name r1326_0 -location {9089.801 8760.992} -status PLACED
place_inst -name b1326 -location {9183.456 8760.992} -status PLACED
place_inst -name b1327 -location {8923.776 8760.992} -status PLACED
place_inst -name b1328 -location {8855.200 8760.992} -status PLACED
place_inst -name b1329 -location {8992.352 8760.992} -status PLACED
place_inst -name r1330_0 -location {9108.791 8416.928} -status PLACED
place_inst -name r1330_1 -location {9225.755 8433.864} -status PLACED
place_inst -name b1330 -location {9342.720 8450.801} -status PLACED
place_inst -name b1331 -location {9342.720 8599.968} -status PLACED
place_inst -name b1332 -location {9374.880 8599.968} -status PLACED
place_inst -name b1333 -location {9340.320 8629.728} -status PLACED
place_inst -name b1334 -location {9232.992 8432.672} -status PLACED
place_inst -name b1335 -location {9164.512 8432.672} -status PLACED
place_inst -name b1336 -location {9301.472 8432.672} -status PLACED
place_inst -name r1337_0 -location {8989.473 7707.421} -status PLACED
place_inst -name r1337_1 -location {8987.121 7597.562} -status PLACED
place_inst -name b1337 -location {8984.768 7487.704} -status PLACED
place_inst -name r1338_0 -location {8862.864 7500.281} -status PLACED
place_inst -name r1338_1 -location {8740.960 7512.859} -status PLACED
place_inst -name r1338_2 -location {8619.056 7525.436} -status PLACED
place_inst -name r1338_3 -location {8497.152 7538.013} -status PLACED
place_inst -name r1338_4 -location {8375.248 7550.591} -status PLACED
place_inst -name b1338 -location {8253.344 7563.168} -status PLACED
place_inst -name r1339_0 -location {8170.432 7563.168} -status PLACED
place_inst -name b1339 -location {8087.520 7563.168} -status PLACED
place_inst -name r1340_0 -location {8336.256 7563.168} -status PLACED
place_inst -name b1340 -location {8419.168 7563.168} -status PLACED
place_inst -name b1341 -location {8984.768 7392.776} -status PLACED
place_inst -name r1342_0 -location {9005.396 7492.862} -status PLACED
place_inst -name b1342 -location {9026.024 7592.949} -status PLACED
place_inst -name r1343_0 -location {9102.132 7554.667} -status PLACED
place_inst -name b1343 -location {9178.240 7516.385} -status PLACED
place_inst -name r1344_0 -location {9263.627 7531.979} -status PLACED
place_inst -name r1344_1 -location {9349.013 7547.574} -status PLACED
place_inst -name b1344 -location {9434.400 7563.168} -status PLACED
place_inst -name b1345 -location {9186.880 7499.206} -status PLACED
place_inst -name r1346_0 -location {9263.600 7537.523} -status PLACED
place_inst -name b1346 -location {9340.320 7575.840} -status PLACED
place_inst -name b1347 -location {9178.240 7395.872} -status PLACED
place_inst -name b1348 -location {9107.872 7395.872} -status PLACED
place_inst -name b1349 -location {9248.608 7395.872} -status PLACED
place_inst -name b1350 -location {9026.024 7683.598} -status PLACED
place_inst -name b1351 -location {9100.096 7687.918} -status PLACED
place_inst -name b1352 -location {9060.939 7751.200} -status PLACED
place_inst -name r1353_0 -location {9133.141 7746.336} -status PLACED
place_inst -name b1353 -location {9205.344 7741.472} -status PLACED
place_inst -name b1354 -location {9005.280 7751.200} -status PLACED
place_inst -name b1355 -location {9005.280 7698.848} -status PLACED
place_inst -name b1356 -location {9005.280 7803.552} -status PLACED
place_inst -name r1357_0 -location {9097.936 7614.807} -status PLACED
place_inst -name b1357 -location {9095.776 7541.696} -status PLACED
place_inst -name b1358 -location {8992.416 7528.160} -status PLACED
place_inst -name b1359 -location {9095.776 7658.592} -status PLACED
place_inst -name r1360_0 -location {8939.108 7657.383} -status PLACED
place_inst -name b1360 -location {8852.192 7631.168} -status PLACED
place_inst -name r1361_0 -location {8819.776 7579.024} -status PLACED
place_inst -name b1361 -location {8787.360 7526.880} -status PLACED
place_inst -name r1362_0 -location {8852.192 7715.728} -status PLACED
place_inst -name b1362 -location {8852.192 7800.288} -status PLACED
place_inst -name r1363_0 -location {8984.768 7276.373} -status PLACED
place_inst -name r1363_1 -location {8984.768 7159.969} -status PLACED
place_inst -name b1363 -location {8984.768 7043.566} -status PLACED
place_inst -name r1364_0 -location {8984.768 6936.361} -status PLACED
place_inst -name r1364_1 -location {8984.768 6829.157} -status PLACED
place_inst -name b1364 -location {8984.768 6721.952} -status PLACED
place_inst -name b1365 -location {8880.736 6721.952} -status PLACED
place_inst -name b1366 -location {9088.800 6721.952} -status PLACED
place_inst -name b1367 -location {8939.040 7109.331} -status PLACED
place_inst -name r1368_0 -location {9023.989 7089.645} -status PLACED
place_inst -name r1368_1 -location {9108.939 7069.958} -status PLACED
place_inst -name b1368 -location {9193.888 7050.272} -status PLACED
place_inst -name b1369 -location {8930.400 7115.712} -status PLACED
place_inst -name b1370 -location {8930.400 6978.464} -status PLACED
place_inst -name b1371 -location {8855.520 6978.464} -status PLACED
place_inst -name b1372 -location {9005.280 6978.464} -status PLACED
place_inst -name b1373 -location {8930.400 7252.960} -status PLACED
place_inst -name b1374 -location {8855.520 7252.960} -status PLACED
place_inst -name b1375 -location {9005.280 7252.960} -status PLACED
place_inst -name r1376_0 -location {9010.331 9857.698} -status PLACED
place_inst -name r1376_1 -location {9032.336 9770.641} -status PLACED
place_inst -name b1376 -location {9054.340 9683.584} -status PLACED
place_inst -name b1377 -location {9087.617 9687.904} -status PLACED
place_inst -name r1378_0 -location {9113.269 9579.775} -status PLACED
place_inst -name b1378 -location {9138.920 9471.646} -status PLACED
place_inst -name r1379_0 -location {9028.223 9492.286} -status PLACED
place_inst -name r1379_1 -location {8917.526 9512.927} -status PLACED
place_inst -name r1379_2 -location {8806.829 9533.567} -status PLACED
place_inst -name r1379_3 -location {8696.132 9554.207} -status PLACED
place_inst -name r1379_4 -location {8585.435 9574.847} -status PLACED
place_inst -name r1379_5 -location {8474.738 9595.487} -status PLACED
place_inst -name r1379_6 -location {8364.041 9616.128} -status PLACED
place_inst -name b1379 -location {8253.344 9636.768} -status PLACED
place_inst -name r1380_0 -location {8170.432 9636.768} -status PLACED
place_inst -name b1380 -location {8087.520 9636.768} -status PLACED
place_inst -name r1381_0 -location {8336.256 9636.768} -status PLACED
place_inst -name b1381 -location {8419.168 9636.768} -status PLACED
place_inst -name r1382_0 -location {9134.600 9379.284} -status PLACED
place_inst -name b1382 -location {9130.280 9286.922} -status PLACED
place_inst -name r1383_0 -location {9096.908 9370.761} -status PLACED
place_inst -name r1383_1 -location {9063.535 9454.600} -status PLACED
place_inst -name b1383 -location {9030.163 9538.439} -status PLACED
place_inst -name r1384_0 -location {9123.233 9536.279} -status PLACED
place_inst -name b1384 -location {9216.303 9534.119} -status PLACED
place_inst -name b1385 -location {9340.320 9534.119} -status PLACED
place_inst -name r1386_0 -location {9387.360 9585.444} -status PLACED
place_inst -name b1386 -location {9434.400 9636.768} -status PLACED
place_inst -name b1387 -location {9340.320 9513.600} -status PLACED
place_inst -name b1388 -location {9248.608 9469.472} -status PLACED
place_inst -name b1389 -location {9340.320 9649.440} -status PLACED
place_inst -name r1390_0 -location {9204.151 9633.156} -status PLACED
place_inst -name b1390 -location {9192.000 9732.192} -status PLACED
place_inst -name b1391 -location {9095.776 9732.192} -status PLACED
place_inst -name b1392 -location {9205.344 9815.072} -status PLACED
place_inst -name r1393_0 -location {9004.809 9622.050} -status PLACED
place_inst -name b1393 -location {8979.456 9705.661} -status PLACED
place_inst -name r1394_0 -location {8934.992 9653.070} -status PLACED
place_inst -name b1394 -location {8890.528 9600.480} -status PLACED
place_inst -name b1395 -location {8787.360 9600.480} -status PLACED
place_inst -name b1396 -location {8992.416 9601.760} -status PLACED
place_inst -name r1397_0 -location {8979.456 9789.774} -status PLACED
place_inst -name b1397 -location {8979.456 9873.888} -status PLACED
place_inst -name b1398 -location {8852.192 9873.888} -status PLACED
place_inst -name b1399 -location {9005.280 9772.448} -status PLACED
place_inst -name r1400_0 -location {9132.440 9153.764} -status PLACED
place_inst -name b1400 -location {9134.600 9020.605} -status PLACED
place_inst -name r1401_0 -location {9065.093 8976.972} -status PLACED
place_inst -name r1401_1 -location {8995.587 8933.338} -status PLACED
place_inst -name b1401 -location {8926.080 8889.705} -status PLACED
place_inst -name r1402_0 -location {8955.424 8842.628} -status PLACED
place_inst -name b1402 -location {8984.768 8795.552} -status PLACED
place_inst -name b1403 -location {8880.736 8795.552} -status PLACED
place_inst -name b1404 -location {9088.800 8795.552} -status PLACED
place_inst -name r1405_0 -location {8928.240 8970.885} -status PLACED
place_inst -name b1405 -location {8930.400 9052.064} -status PLACED
place_inst -name b1406 -location {8855.520 9052.064} -status PLACED
place_inst -name b1407 -location {9005.280 9052.064} -status PLACED
place_inst -name r1408_0 -location {9136.040 9122.590} -status PLACED
place_inst -name r1408_1 -location {9137.480 9224.575} -status PLACED
place_inst -name b1408 -location {9138.920 9326.560} -status PLACED
place_inst -name r1409_0 -location {9034.660 9326.560} -status PLACED
place_inst -name b1409 -location {8930.400 9326.560} -status PLACED
place_inst -name b1410 -location {8855.520 9326.560} -status PLACED
place_inst -name b1411 -location {9005.280 9326.560} -status PLACED
place_inst -name b1412 -location {9193.888 9339.680} -status PLACED
place_inst -name r1413_0 -location {9150.880 9404.576} -status PLACED
place_inst -name b1413 -location {9107.872 9469.472} -status PLACED
place_inst -name r1414_0 -location {9193.888 9231.776} -status PLACED
place_inst -name b1414 -location {9193.888 9123.872} -status PLACED
place_inst -name r1415_0 -location {9087.617 9817.369} -status PLACED
place_inst -name r1415_1 -location {9087.617 9946.834} -status PLACED
place_inst -name r1415_2 -location {9087.617 10076.298} -status PLACED
place_inst -name r1415_3 -location {9087.617 10205.763} -status PLACED
place_inst -name b1415 -location {9087.617 10335.228} -status PLACED
place_inst -name r1416_0 -location {9039.563 10266.496} -status PLACED
place_inst -name r1416_1 -location {8991.510 10197.765} -status PLACED
place_inst -name b1416 -location {8943.456 10129.033} -status PLACED
place_inst -name b1417 -location {9041.824 10093.673} -status PLACED
place_inst -name r1418_0 -location {9023.552 10035.812} -status PLACED
place_inst -name b1418 -location {9005.280 9977.952} -status PLACED
place_inst -name b1419 -location {9005.280 9877.152} -status PLACED
place_inst -name b1420 -location {9005.280 10078.752} -status PLACED
place_inst -name b1421 -location {9033.184 10147.616} -status PLACED
place_inst -name r1422_0 -location {8942.688 10147.616} -status PLACED
place_inst -name b1422 -location {8852.192 10147.616} -status PLACED
place_inst -name r1423_0 -location {9117.152 10154.144} -status PLACED
place_inst -name b1423 -location {9201.120 10160.672} -status PLACED
place_inst -name r1424_0 -location {8943.456 10219.622} -status PLACED
place_inst -name b1424 -location {8943.456 10310.212} -status PLACED
place_inst -name b1425 -location {9005.280 10282.464} -status PLACED
place_inst -name b1426 -location {9005.280 10169.376} -status PLACED
place_inst -name b1427 -location {9005.280 10395.552} -status PLACED
place_inst -name b1428 -location {8943.456 10425.376} -status PLACED
place_inst -name b1429 -location {8855.520 10425.376} -status PLACED
place_inst -name b1430 -location {9005.280 10451.488} -status PLACED
place_inst -name r1431_0 -location {9089.057 10437.768} -status PLACED
place_inst -name r1431_1 -location {9090.497 10540.308} -status PLACED
place_inst -name b1431 -location {9091.937 10642.848} -status PLACED
place_inst -name b1432 -location {9152.019 10642.848} -status PLACED
place_inst -name b1433 -location {9044.224 10642.848} -status PLACED
place_inst -name r1434_0 -location {8915.792 10642.848} -status PLACED
place_inst -name b1434 -location {8787.360 10642.848} -status PLACED
place_inst -name r1435_0 -location {9104.368 10574.560} -status PLACED
place_inst -name b1435 -location {9164.512 10506.272} -status PLACED
place_inst -name r1436_0 -location {9246.169 10614.112} -status PLACED
place_inst -name b1436 -location {9340.320 10585.376} -status PLACED
place_inst -name b1437 -location {9301.472 10506.272} -status PLACED
place_inst -name b1438 -location {9340.320 10703.328} -status PLACED
place_inst -name r1439_0 -location {9044.041 10738.720} -status PLACED
place_inst -name b1439 -location {8996.146 10834.592} -status PLACED
place_inst -name b1440 -location {8923.776 10834.592} -status PLACED
place_inst -name b1441 -location {8855.200 10834.592} -status PLACED
place_inst -name b1442 -location {8992.352 10834.592} -status PLACED
place_inst -name r1443_0 -location {9089.801 10834.592} -status PLACED
place_inst -name b1443 -location {9183.456 10834.592} -status PLACED
place_inst -name r1444_0 -location {9031.902 9807.332} -status PLACED
place_inst -name r1444_1 -location {9009.464 9931.080} -status PLACED
place_inst -name r1444_2 -location {8987.026 10054.828} -status PLACED
place_inst -name r1444_3 -location {8964.587 10178.576} -status PLACED
place_inst -name r1444_4 -location {8942.149 10302.324} -status PLACED
place_inst -name r1444_5 -location {8919.711 10426.072} -status PLACED
place_inst -name r1444_6 -location {8897.273 10549.820} -status PLACED
place_inst -name b1444 -location {8874.835 10673.568} -status PLACED
place_inst -name r1445_0 -location {8730.425 10673.568} -status PLACED
place_inst -name b1445 -location {8586.016 10673.568} -status PLACED
place_inst -name r1446_0 -location {8503.104 10673.568} -status PLACED
place_inst -name b1446 -location {8420.192 10673.568} -status PLACED
place_inst -name r1447_0 -location {8668.928 10673.568} -status PLACED
place_inst -name b1447 -location {8751.840 10673.568} -status PLACED
place_inst -name r1448_0 -location {8999.846 10673.568} -status PLACED
place_inst -name r1448_1 -location {9124.857 10673.568} -status PLACED
place_inst -name r1448_2 -location {9249.869 10673.568} -status PLACED
place_inst -name b1448 -location {9374.880 10673.568} -status PLACED
place_inst -name r1449_0 -location {8985.756 5700.185} -status PLACED
place_inst -name b1449 -location {8983.186 5602.814} -status PLACED
place_inst -name r1450_0 -location {9037.861 5538.609} -status PLACED
place_inst -name r1450_1 -location {9092.536 5474.404} -status PLACED
place_inst -name b1450 -location {9147.211 5410.199} -status PLACED
place_inst -name r1451_0 -location {9019.516 5421.537} -status PLACED
place_inst -name r1451_1 -location {8891.820 5432.876} -status PLACED
place_inst -name r1451_2 -location {8764.125 5444.214} -status PLACED
place_inst -name r1451_3 -location {8636.430 5455.553} -status PLACED
place_inst -name r1451_4 -location {8508.735 5466.891} -status PLACED
place_inst -name r1451_5 -location {8381.039 5478.230} -status PLACED
place_inst -name b1451 -location {8253.344 5489.568} -status PLACED
place_inst -name r1452_0 -location {8170.432 5489.568} -status PLACED
place_inst -name b1452 -location {8087.520 5489.568} -status PLACED
place_inst -name r1453_0 -location {8336.256 5489.568} -status PLACED
place_inst -name b1453 -location {8419.168 5489.568} -status PLACED
place_inst -name r1454_0 -location {9149.371 5320.105} -status PLACED
place_inst -name b1454 -location {9151.531 5230.012} -status PLACED
place_inst -name r1455_0 -location {9151.531 5350.726} -status PLACED
place_inst -name b1455 -location {9151.531 5471.439} -status PLACED
place_inst -name r1456_0 -location {9214.461 5528.951} -status PLACED
place_inst -name r1456_1 -location {9277.390 5586.463} -status PLACED
place_inst -name b1456 -location {9340.320 5643.975} -status PLACED
place_inst -name r1457_0 -location {9387.360 5566.772} -status PLACED
place_inst -name b1457 -location {9434.400 5489.568} -status PLACED
place_inst -name b1458 -location {9340.320 5652.544} -status PLACED
place_inst -name r1459_0 -location {9272.832 5660.208} -status PLACED
place_inst -name b1459 -location {9205.344 5667.872} -status PLACED
place_inst -name r1460_0 -location {9340.320 5577.392} -status PLACED
place_inst -name b1460 -location {9340.320 5502.240} -status PLACED
place_inst -name b1461 -location {9005.280 5471.439} -status PLACED
place_inst -name b1462 -location {9005.280 5471.439} -status PLACED
place_inst -name r1463_0 -location {8954.251 5556.522} -status PLACED
place_inst -name r1463_1 -location {8903.221 5641.605} -status PLACED
place_inst -name b1463 -location {8852.192 5726.688} -status PLACED
place_inst -name b1464 -location {9005.280 5467.141} -status PLACED
place_inst -name b1465 -location {9021.534 5461.920} -status PLACED
place_inst -name r1466_0 -location {8904.447 5457.600} -status PLACED
place_inst -name b1466 -location {8787.360 5453.280} -status PLACED
place_inst -name b1467 -location {9095.776 5468.096} -status PLACED
place_inst -name b1468 -location {8992.416 5454.560} -status PLACED
place_inst -name b1469 -location {9095.776 5584.992} -status PLACED
place_inst -name r1470_0 -location {9005.280 5572.370} -status PLACED
place_inst -name b1470 -location {9005.280 5677.600} -status PLACED
place_inst -name b1471 -location {9005.280 5625.248} -status PLACED
place_inst -name b1472 -location {9005.280 5729.952} -status PLACED
place_inst -name r1473_0 -location {9062.933 5421.717} -status PLACED
place_inst -name r1473_1 -location {9120.587 5371.994} -status PLACED
place_inst -name b1473 -location {9178.240 5322.272} -status PLACED
place_inst -name b1474 -location {9107.872 5322.272} -status PLACED
place_inst -name b1475 -location {9248.608 5322.272} -status PLACED
place_inst -name r1476_0 -location {9095.943 5143.330} -status PLACED
place_inst -name r1476_1 -location {9040.356 5056.648} -status PLACED
place_inst -name b1476 -location {8984.768 4969.966} -status PLACED
place_inst -name r1477_0 -location {8984.768 4862.761} -status PLACED
place_inst -name r1477_1 -location {8984.768 4755.557} -status PLACED
place_inst -name b1477 -location {8984.768 4648.352} -status PLACED
place_inst -name b1478 -location {8880.736 4648.352} -status PLACED
place_inst -name b1479 -location {9088.800 4648.352} -status PLACED
place_inst -name b1480 -location {8939.040 5035.731} -status PLACED
place_inst -name r1481_0 -location {9023.989 5016.045} -status PLACED
place_inst -name r1481_1 -location {9108.939 4996.358} -status PLACED
place_inst -name b1481 -location {9193.888 4976.672} -status PLACED
place_inst -name b1482 -location {8930.400 5042.112} -status PLACED
place_inst -name b1483 -location {8930.400 4904.864} -status PLACED
place_inst -name b1484 -location {8855.520 4904.864} -status PLACED
place_inst -name b1485 -location {9005.280 4904.864} -status PLACED
place_inst -name b1486 -location {8930.400 5179.360} -status PLACED
place_inst -name b1487 -location {8855.520 5179.360} -status PLACED
place_inst -name b1488 -location {9005.280 5179.360} -status PLACED
place_inst -name r1489_0 -location {8984.626 5726.991} -status PLACED
place_inst -name r1489_1 -location {8986.066 5851.169} -status PLACED
place_inst -name r1489_2 -location {8987.506 5975.346} -status PLACED
place_inst -name r1489_3 -location {8988.946 6099.523} -status PLACED
place_inst -name r1489_4 -location {8990.386 6223.701} -status PLACED
place_inst -name b1489 -location {8991.826 6347.878} -status PLACED
place_inst -name r1490_0 -location {8890.373 6392.501} -status PLACED
place_inst -name r1490_1 -location {8788.921 6437.123} -status PLACED
place_inst -name r1490_2 -location {8687.468 6481.745} -status PLACED
place_inst -name b1490 -location {8586.016 6526.368} -status PLACED
place_inst -name r1491_0 -location {8503.104 6526.368} -status PLACED
place_inst -name b1491 -location {8420.192 6526.368} -status PLACED
place_inst -name r1492_0 -location {8668.928 6526.368} -status PLACED
place_inst -name b1492 -location {8751.840 6526.368} -status PLACED
place_inst -name b1493 -location {8991.826 6330.693} -status PLACED
place_inst -name b1494 -location {8991.826 6330.693} -status PLACED
place_inst -name r1495_0 -location {8993.090 6216.092} -status PLACED
place_inst -name b1495 -location {8994.354 6101.490} -status PLACED
place_inst -name r1496_0 -location {8991.394 6188.905} -status PLACED
place_inst -name b1496 -location {8988.434 6276.320} -status PLACED
place_inst -name b1497 -location {8855.520 6278.176} -status PLACED
place_inst -name b1498 -location {9005.280 6276.320} -status PLACED
place_inst -name b1499 -location {9005.280 6248.352} -status PLACED
place_inst -name b1500 -location {9005.280 6304.288} -status PLACED
place_inst -name b1501 -location {8998.674 6004.726} -status PLACED
place_inst -name r1502_0 -location {9099.897 6009.099} -status PLACED
place_inst -name b1502 -location {9201.120 6013.472} -status PLACED
place_inst -name b1503 -location {8998.674 6000.416} -status PLACED
place_inst -name b1504 -location {8852.192 6000.416} -status PLACED
place_inst -name b1505 -location {9005.280 5976.864} -status PLACED
place_inst -name b1506 -location {9005.280 5931.552} -status PLACED
place_inst -name b1507 -location {9005.280 6022.176} -status PLACED
place_inst -name r1508_0 -location {8991.826 6470.160} -status PLACED
place_inst -name b1508 -location {8991.826 6609.628} -status PLACED
place_inst -name r1509_0 -location {8923.671 6571.635} -status PLACED
place_inst -name r1509_1 -location {8855.515 6533.641} -status PLACED
place_inst -name b1509 -location {8787.360 6495.648} -status PLACED
place_inst -name b1510 -location {8996.146 6687.392} -status PLACED
place_inst -name r1511_0 -location {9089.801 6687.392} -status PLACED
place_inst -name b1511 -location {9183.456 6687.392} -status PLACED
place_inst -name b1512 -location {8923.776 6687.392} -status PLACED
place_inst -name b1513 -location {8855.200 6687.392} -status PLACED
place_inst -name b1514 -location {8992.352 6687.392} -status PLACED
place_inst -name r1515_0 -location {9108.791 6346.196} -status PLACED
place_inst -name r1515_1 -location {9225.755 6361.698} -status PLACED
place_inst -name b1515 -location {9342.720 6377.201} -status PLACED
place_inst -name b1516 -location {9342.720 6526.368} -status PLACED
place_inst -name b1517 -location {9374.880 6526.368} -status PLACED
place_inst -name b1518 -location {9340.320 6556.128} -status PLACED
place_inst -name b1519 -location {9232.992 6359.072} -status PLACED
place_inst -name b1520 -location {9164.512 6359.072} -status PLACED
place_inst -name b1521 -location {9301.472 6359.072} -status PLACED
place_inst -name b1522 -location {9805.920 8095.648} -status PLACED
place_inst -name b1523 -location {7716.000 8095.648} -status PLACED
place_inst -name b1524 -location {9024.535 11987.588} -status PLACED
place_inst -name r1525_0 -location {8990.224 11875.164} -status PLACED
place_inst -name r1525_1 -location {8955.913 11762.739} -status PLACED
place_inst -name r1525_2 -location {8921.602 11650.315} -status PLACED
place_inst -name b1525 -location {8887.291 11537.891} -status PLACED
place_inst -name r1526_0 -location {8781.633 11566.637} -status PLACED
place_inst -name r1526_1 -location {8675.975 11595.383} -status PLACED
place_inst -name r1526_2 -location {8570.317 11624.129} -status PLACED
place_inst -name r1526_3 -location {8464.660 11652.876} -status PLACED
place_inst -name r1526_4 -location {8359.002 11681.622} -status PLACED
place_inst -name b1526 -location {8253.344 11710.368} -status PLACED
place_inst -name r1527_0 -location {8170.432 11710.368} -status PLACED
place_inst -name b1527 -location {8087.520 11710.368} -status PLACED
place_inst -name r1528_0 -location {8336.256 11710.368} -status PLACED
place_inst -name b1528 -location {8419.168 11710.368} -status PLACED
place_inst -name b1529 -location {8939.040 11537.891} -status PLACED
place_inst -name r1530_0 -location {8984.692 11639.019} -status PLACED
place_inst -name b1530 -location {9030.344 11740.148} -status PLACED
place_inst -name r1531_0 -location {9104.292 11701.867} -status PLACED
place_inst -name b1531 -location {9178.240 11663.585} -status PLACED
place_inst -name r1532_0 -location {9263.627 11679.179} -status PLACED
place_inst -name r1532_1 -location {9349.013 11694.774} -status PLACED
place_inst -name b1532 -location {9434.400 11710.368} -status PLACED
place_inst -name b1533 -location {9186.880 11646.406} -status PLACED
place_inst -name r1534_0 -location {9263.600 11684.723} -status PLACED
place_inst -name b1534 -location {9340.320 11723.040} -status PLACED
place_inst -name b1535 -location {9178.240 11543.072} -status PLACED
place_inst -name b1536 -location {9107.872 11543.072} -status PLACED
place_inst -name b1537 -location {9248.608 11543.072} -status PLACED
place_inst -name b1538 -location {9030.344 11826.478} -status PLACED
place_inst -name b1539 -location {9100.096 11835.118} -status PLACED
place_inst -name b1540 -location {9060.939 11898.400} -status PLACED
place_inst -name r1541_0 -location {9133.141 11893.536} -status PLACED
place_inst -name b1541 -location {9205.344 11888.672} -status PLACED
place_inst -name b1542 -location {9005.280 11898.400} -status PLACED
place_inst -name b1543 -location {9005.280 11846.048} -status PLACED
place_inst -name b1544 -location {9005.280 11950.752} -status PLACED
place_inst -name r1545_0 -location {9097.936 11762.007} -status PLACED
place_inst -name b1545 -location {9095.776 11688.896} -status PLACED
place_inst -name b1546 -location {8992.416 11675.360} -status PLACED
place_inst -name b1547 -location {9095.776 11805.792} -status PLACED
place_inst -name r1548_0 -location {8941.268 11802.423} -status PLACED
place_inst -name b1548 -location {8852.192 11778.368} -status PLACED
place_inst -name r1549_0 -location {8819.776 11726.224} -status PLACED
place_inst -name b1549 -location {8787.360 11674.080} -status PLACED
place_inst -name r1550_0 -location {8852.192 11862.928} -status PLACED
place_inst -name b1550 -location {8852.192 11947.488} -status PLACED
place_inst -name r1551_0 -location {8939.040 11406.940} -status PLACED
place_inst -name r1551_1 -location {8939.040 11275.989} -status PLACED
place_inst -name b1551 -location {8939.040 11145.038} -status PLACED
place_inst -name r1552_0 -location {8954.283 11053.076} -status PLACED
place_inst -name r1552_1 -location {8969.525 10961.114} -status PLACED
place_inst -name b1552 -location {8984.768 10869.152} -status PLACED
place_inst -name b1553 -location {8880.736 10869.152} -status PLACED
place_inst -name b1554 -location {9088.800 10869.152} -status PLACED
place_inst -name b1555 -location {8939.040 11256.531} -status PLACED
place_inst -name r1556_0 -location {9023.989 11236.845} -status PLACED
place_inst -name r1556_1 -location {9108.939 11217.158} -status PLACED
place_inst -name b1556 -location {9193.888 11197.472} -status PLACED
place_inst -name b1557 -location {8930.400 11262.912} -status PLACED
place_inst -name b1558 -location {8930.400 11125.664} -status PLACED
place_inst -name b1559 -location {8855.520 11125.664} -status PLACED
place_inst -name b1560 -location {9005.280 11125.664} -status PLACED
place_inst -name b1561 -location {8930.400 11400.160} -status PLACED
place_inst -name b1562 -location {8855.520 11400.160} -status PLACED
place_inst -name b1563 -location {9005.280 11400.160} -status PLACED
place_inst -name r1564_0 -location {9024.535 12112.745} -status PLACED
place_inst -name r1564_1 -location {9024.535 12237.901} -status PLACED
place_inst -name r1564_2 -location {9024.535 12363.058} -status PLACED
place_inst -name r1564_3 -location {9024.535 12488.215} -status PLACED
place_inst -name r1564_4 -location {9024.535 12613.371} -status PLACED
place_inst -name b1564 -location {9024.535 12738.528} -status PLACED
place_inst -name b1565 -location {9076.045 12738.528} -status PLACED
place_inst -name r1566_0 -location {8953.538 12740.688} -status PLACED
place_inst -name r1566_1 -location {8831.031 12742.848} -status PLACED
place_inst -name r1566_2 -location {8708.523 12745.008} -status PLACED
place_inst -name b1566 -location {8586.016 12747.168} -status PLACED
place_inst -name r1567_0 -location {8503.104 12747.168} -status PLACED
place_inst -name b1567 -location {8420.192 12747.168} -status PLACED
place_inst -name r1568_0 -location {8668.928 12747.168} -status PLACED
place_inst -name b1568 -location {8751.840 12747.168} -status PLACED
place_inst -name r1569_0 -location {9106.709 12784.478} -status PLACED
place_inst -name b1569 -location {9137.372 12830.428} -status PLACED
place_inst -name r1570_0 -location {9185.182 12769.078} -status PLACED
place_inst -name b1570 -location {9232.992 12707.729} -status PLACED
place_inst -name b1571 -location {9342.720 12747.168} -status PLACED
place_inst -name b1572 -location {9374.880 12747.168} -status PLACED
place_inst -name b1573 -location {9340.320 12776.928} -status PLACED
place_inst -name b1574 -location {9232.992 12579.872} -status PLACED
place_inst -name b1575 -location {9164.512 12579.872} -status PLACED
place_inst -name b1576 -location {9301.472 12579.872} -status PLACED
place_inst -name b1577 -location {8991.826 12830.428} -status PLACED
place_inst -name r1578_0 -location {8923.671 12792.435} -status PLACED
place_inst -name r1578_1 -location {8855.515 12754.441} -status PLACED
place_inst -name b1578 -location {8787.360 12716.448} -status PLACED
place_inst -name b1579 -location {8996.146 12908.192} -status PLACED
place_inst -name r1580_0 -location {9089.801 12908.192} -status PLACED
place_inst -name b1580 -location {9183.456 12908.192} -status PLACED
place_inst -name b1581 -location {8923.776 12908.192} -status PLACED
place_inst -name b1582 -location {8855.200 12908.192} -status PLACED
place_inst -name b1583 -location {8992.352 12908.192} -status PLACED
place_inst -name r1584_0 -location {9014.475 12599.782} -status PLACED
place_inst -name r1584_1 -location {9004.414 12461.036} -status PLACED
place_inst -name b1584 -location {8994.354 12322.290} -status PLACED
place_inst -name r1585_0 -location {8991.394 12409.705} -status PLACED
place_inst -name b1585 -location {8988.434 12497.120} -status PLACED
place_inst -name b1586 -location {8855.520 12498.976} -status PLACED
place_inst -name b1587 -location {9005.280 12497.120} -status PLACED
place_inst -name b1588 -location {9005.280 12469.152} -status PLACED
place_inst -name b1589 -location {9005.280 12525.088} -status PLACED
place_inst -name b1590 -location {8998.674 12225.526} -status PLACED
place_inst -name r1591_0 -location {9099.897 12229.899} -status PLACED
place_inst -name b1591 -location {9201.120 12234.272} -status PLACED
place_inst -name b1592 -location {8998.674 12221.216} -status PLACED
place_inst -name b1593 -location {8852.192 12221.216} -status PLACED
place_inst -name b1594 -location {9005.280 12197.664} -status PLACED
place_inst -name b1595 -location {9005.280 12152.352} -status PLACED
place_inst -name b1596 -location {9005.280 12242.976} -status PLACED
place_inst -name b1597 -location {9805.920 10169.248} -status PLACED
place_inst -name b1598 -location {7716.000 10169.248} -status PLACED
place_inst -name r1599_0 -location {9004.333 3737.953} -status PLACED
place_inst -name r1599_1 -location {9011.110 3606.010} -status PLACED
place_inst -name b1599 -location {9017.888 3474.066} -status PLACED
place_inst -name b1600 -location {9044.564 3465.426} -status PLACED
place_inst -name r1601_0 -location {9006.955 3375.777} -status PLACED
place_inst -name r1601_1 -location {8969.345 3286.129} -status PLACED
place_inst -name b1601 -location {8931.736 3196.480} -status PLACED
place_inst -name r1602_0 -location {8818.671 3233.061} -status PLACED
place_inst -name r1602_1 -location {8705.605 3269.643} -status PLACED
place_inst -name r1602_2 -location {8592.540 3306.224} -status PLACED
place_inst -name r1602_3 -location {8479.475 3342.805} -status PLACED
place_inst -name r1602_4 -location {8366.409 3379.387} -status PLACED
place_inst -name b1602 -location {8253.344 3415.968} -status PLACED
place_inst -name r1603_0 -location {8170.432 3415.968} -status PLACED
place_inst -name b1603 -location {8087.520 3415.968} -status PLACED
place_inst -name r1604_0 -location {8336.256 3415.968} -status PLACED
place_inst -name b1604 -location {8419.168 3415.968} -status PLACED
place_inst -name b1605 -location {9018.071 3196.480} -status PLACED
place_inst -name b1606 -location {9018.071 3131.807} -status PLACED
place_inst -name r1607_0 -location {9018.071 3275.974} -status PLACED
place_inst -name b1607 -location {9018.071 3420.140} -status PLACED
place_inst -name r1608_0 -location {9144.891 3404.185} -status PLACED
place_inst -name b1608 -location {9271.712 3388.230} -status PLACED
place_inst -name r1609_0 -location {9353.056 3402.099} -status PLACED
place_inst -name b1609 -location {9434.400 3415.968} -status PLACED
place_inst -name b1610 -location {9263.072 3377.824} -status PLACED
place_inst -name b1611 -location {9340.320 3429.728} -status PLACED
place_inst -name b1612 -location {9263.072 3248.672} -status PLACED
place_inst -name b1613 -location {9022.391 3473.483} -status PLACED
place_inst -name b1614 -location {9022.391 3473.483} -status PLACED
place_inst -name r1615_0 -location {9057.071 3398.546} -status PLACED
place_inst -name r1615_1 -location {9091.752 3323.609} -status PLACED
place_inst -name b1615 -location {9126.432 3248.672} -status PLACED
place_inst -name b1616 -location {9022.391 3473.483} -status PLACED
place_inst -name b1617 -location {9005.280 3473.483} -status PLACED
place_inst -name r1618_0 -location {9033.440 3414.485} -status PLACED
place_inst -name b1618 -location {9061.600 3355.488} -status PLACED
place_inst -name b1619 -location {9005.280 3545.760} -status PLACED
place_inst -name b1620 -location {8981.792 3510.496} -status PLACED
place_inst -name b1621 -location {9005.280 3604.512} -status PLACED
place_inst -name r1622_0 -location {9107.435 3533.878} -status PLACED
place_inst -name b1622 -location {9192.480 3594.272} -status PLACED
place_inst -name r1623_0 -location {8904.876 3444.438} -status PLACED
place_inst -name b1623 -location {8787.360 3415.392} -status PLACED
place_inst -name b1624 -location {8787.360 3340.640} -status PLACED
place_inst -name b1625 -location {8787.360 3490.144} -status PLACED
place_inst -name r1626_0 -location {9062.025 3026.215} -status PLACED
place_inst -name r1626_1 -location {9105.980 2920.623} -status PLACED
place_inst -name r1626_2 -location {9149.934 2815.032} -status PLACED
place_inst -name b1626 -location {9193.888 2709.440} -status PLACED
place_inst -name r1627_0 -location {9164.416 2642.096} -status PLACED
place_inst -name b1627 -location {9134.944 2574.752} -status PLACED
place_inst -name r1628_0 -location {9193.888 2806.256} -status PLACED
place_inst -name b1628 -location {9193.888 2903.072} -status PLACED
place_inst -name r1629_0 -location {9017.214 3329.280} -status PLACED
place_inst -name r1629_1 -location {9016.358 3462.080} -status PLACED
place_inst -name r1629_2 -location {9015.501 3594.880} -status PLACED
place_inst -name r1629_3 -location {9014.645 3727.680} -status PLACED
place_inst -name b1629 -location {9013.788 3860.480} -status PLACED
place_inst -name b1630 -location {9005.280 3860.480} -status PLACED
place_inst -name b1631 -location {9005.280 3809.408} -status PLACED
place_inst -name b1632 -location {9005.280 3749.728} -status PLACED
place_inst -name b1633 -location {9005.280 3869.088} -status PLACED
place_inst -name r1634_0 -location {9005.280 3939.216} -status PLACED
place_inst -name b1634 -location {9005.280 4017.952} -status PLACED
place_inst -name r1635_0 -location {9103.838 3900.176} -status PLACED
place_inst -name b1635 -location {9193.888 3939.872} -status PLACED
place_inst -name r1636_0 -location {9045.181 3601.384} -status PLACED
place_inst -name r1636_1 -location {9045.798 3737.341} -status PLACED
place_inst -name r1636_2 -location {9046.415 3873.299} -status PLACED
place_inst -name r1636_3 -location {9047.033 4009.257} -status PLACED
place_inst -name r1636_4 -location {9047.650 4145.215} -status PLACED
place_inst -name r1636_5 -location {9048.267 4281.172} -status PLACED
place_inst -name b1636 -location {9048.884 4417.130} -status PLACED
place_inst -name b1637 -location {9131.520 4412.810} -status PLACED
place_inst -name b1638 -location {9218.206 4460.328} -status PLACED
place_inst -name b1639 -location {9357.912 4451.688} -status PLACED
place_inst -name b1640 -location {9374.880 4452.768} -status PLACED
place_inst -name b1641 -location {9340.320 4451.232} -status PLACED
place_inst -name b1642 -location {9200.864 4526.144} -status PLACED
place_inst -name b1643 -location {9175.136 4464.224} -status PLACED
place_inst -name b1644 -location {9200.864 4613.792} -status PLACED
place_inst -name r1645_0 -location {9133.680 4304.181} -status PLACED
place_inst -name b1645 -location {9135.840 4195.552} -status PLACED
place_inst -name b1646 -location {9005.280 4195.552} -status PLACED
place_inst -name b1647 -location {9176.480 4285.472} -status PLACED
place_inst -name r1648_0 -location {8985.658 4440.886} -status PLACED
place_inst -name b1648 -location {8922.432 4464.641} -status PLACED
place_inst -name b1649 -location {8918.016 4459.019} -status PLACED
place_inst -name r1650_0 -location {8877.904 4404.373} -status PLACED
place_inst -name b1650 -location {8837.792 4349.728} -status PLACED
place_inst -name b1651 -location {8918.016 4476.064} -status PLACED
place_inst -name b1652 -location {8787.360 4476.064} -status PLACED
place_inst -name b1653 -location {8992.480 4419.872} -status PLACED
place_inst -name r1654_0 -location {8920.272 4539.217} -status PLACED
place_inst -name b1654 -location {8918.112 4613.792} -status PLACED
place_inst -name b1655 -location {8855.520 4613.792} -status PLACED
place_inst -name b1656 -location {8980.704 4613.792} -status PLACED
place_inst -name r1657_0 -location {8974.701 3571.936} -status PLACED
place_inst -name r1657_1 -location {8931.514 3669.806} -status PLACED
place_inst -name r1657_2 -location {8888.326 3767.677} -status PLACED
place_inst -name r1657_3 -location {8845.139 3865.547} -status PLACED
place_inst -name r1657_4 -location {8801.952 3963.417} -status PLACED
place_inst -name r1657_5 -location {8758.765 4061.287} -status PLACED
place_inst -name r1657_6 -location {8715.578 4159.157} -status PLACED
place_inst -name r1657_7 -location {8672.390 4257.028} -status PLACED
place_inst -name r1657_8 -location {8629.203 4354.898} -status PLACED
place_inst -name b1657 -location {8586.016 4452.768} -status PLACED
place_inst -name r1658_0 -location {8503.104 4452.768} -status PLACED
place_inst -name b1658 -location {8420.192 4452.768} -status PLACED
place_inst -name r1659_0 -location {8668.928 4452.768} -status PLACED
place_inst -name b1659 -location {8751.840 4452.768} -status PLACED
place_inst -name b1660 -location {9805.920 6022.048} -status PLACED
place_inst -name b1661 -location {7716.000 6022.048} -status PLACED
place_inst -name b1662 -location {9806.880 7058.848} -status PLACED
place_inst -name b1663 -location {10514.400 8095.648} -status PLACED
place_inst -name b1664 -location {7715.040 7058.848} -status PLACED
place_inst -name b1665 -location {7007.520 8095.648} -status PLACED
place_inst -name r1666_0 -location {8977.587 14022.444} -status PLACED
place_inst -name b1666 -location {8966.847 13952.934} -status PLACED
place_inst -name b1667 -location {9000.466 13952.934} -status PLACED
place_inst -name r1668_0 -location {8978.551 13874.366} -status PLACED
place_inst -name r1668_1 -location {8956.635 13795.798} -status PLACED
place_inst -name b1668 -location {8934.720 13717.230} -status PLACED
place_inst -name b1669 -location {8932.022 13792.608} -status PLACED
place_inst -name r1670_0 -location {8796.286 13790.880} -status PLACED
place_inst -name r1670_1 -location {8660.551 13789.152} -status PLACED
place_inst -name r1670_2 -location {8524.815 13787.424} -status PLACED
place_inst -name r1670_3 -location {8389.080 13785.696} -status PLACED
place_inst -name b1670 -location {8253.344 13783.968} -status PLACED
place_inst -name r1671_0 -location {8170.432 13783.968} -status PLACED
place_inst -name b1671 -location {8087.520 13783.968} -status PLACED
place_inst -name r1672_0 -location {8336.256 13783.968} -status PLACED
place_inst -name b1672 -location {8419.168 13783.968} -status PLACED
place_inst -name r1673_0 -location {8968.651 13852.349} -status PLACED
place_inst -name b1673 -location {9005.280 13912.090} -status PLACED
place_inst -name r1674_0 -location {9116.960 13920.852} -status PLACED
place_inst -name r1674_1 -location {9228.640 13929.613} -status PLACED
place_inst -name b1674 -location {9340.320 13938.375} -status PLACED
place_inst -name r1675_0 -location {9387.360 13861.172} -status PLACED
place_inst -name b1675 -location {9434.400 13783.968} -status PLACED
place_inst -name b1676 -location {9340.320 13946.944} -status PLACED
place_inst -name r1677_0 -location {9272.832 13954.608} -status PLACED
place_inst -name b1677 -location {9205.344 13962.272} -status PLACED
place_inst -name r1678_0 -location {9340.320 13871.792} -status PLACED
place_inst -name b1678 -location {9340.320 13796.640} -status PLACED
place_inst -name b1679 -location {9005.280 13765.839} -status PLACED
place_inst -name b1680 -location {9005.280 13765.839} -status PLACED
place_inst -name r1681_0 -location {8954.251 13850.922} -status PLACED
place_inst -name r1681_1 -location {8903.221 13936.005} -status PLACED
place_inst -name b1681 -location {8852.192 14021.088} -status PLACED
place_inst -name b1682 -location {9005.280 13761.541} -status PLACED
place_inst -name b1683 -location {9021.534 13756.320} -status PLACED
place_inst -name r1684_0 -location {8904.447 13752.000} -status PLACED
place_inst -name b1684 -location {8787.360 13747.680} -status PLACED
place_inst -name b1685 -location {9095.776 13762.496} -status PLACED
place_inst -name b1686 -location {8992.416 13748.960} -status PLACED
place_inst -name b1687 -location {9095.776 13879.392} -status PLACED
place_inst -name r1688_0 -location {9005.280 13866.770} -status PLACED
place_inst -name b1688 -location {9005.280 13972.000} -status PLACED
place_inst -name b1689 -location {9005.280 13919.648} -status PLACED
place_inst -name b1690 -location {9005.280 14024.352} -status PLACED
place_inst -name r1691_0 -location {9062.933 13716.117} -status PLACED
place_inst -name r1691_1 -location {9120.587 13666.394} -status PLACED
place_inst -name b1691 -location {9178.240 13616.672} -status PLACED
place_inst -name b1692 -location {9107.872 13616.672} -status PLACED
place_inst -name b1693 -location {9248.608 13616.672} -status PLACED
place_inst -name r1694_0 -location {8935.800 13592.582} -status PLACED
place_inst -name r1694_1 -location {8936.880 13467.934} -status PLACED
place_inst -name r1694_2 -location {8937.960 13343.286} -status PLACED
place_inst -name b1694 -location {8939.040 13218.638} -status PLACED
place_inst -name r1695_0 -location {8954.283 13126.676} -status PLACED
place_inst -name r1695_1 -location {8969.525 13034.714} -status PLACED
place_inst -name b1695 -location {8984.768 12942.752} -status PLACED
place_inst -name b1696 -location {8880.736 12942.752} -status PLACED
place_inst -name b1697 -location {9088.800 12942.752} -status PLACED
place_inst -name b1698 -location {8939.040 13330.131} -status PLACED
place_inst -name r1699_0 -location {9023.989 13310.445} -status PLACED
place_inst -name r1699_1 -location {9108.939 13290.758} -status PLACED
place_inst -name b1699 -location {9193.888 13271.072} -status PLACED
place_inst -name b1700 -location {8930.400 13336.512} -status PLACED
place_inst -name b1701 -location {8930.400 13199.264} -status PLACED
place_inst -name b1702 -location {8855.520 13199.264} -status PLACED
place_inst -name b1703 -location {9005.280 13199.264} -status PLACED
place_inst -name b1704 -location {8930.400 13473.760} -status PLACED
place_inst -name b1705 -location {8855.520 13473.760} -status PLACED
place_inst -name b1706 -location {9005.280 13473.760} -status PLACED
place_inst -name r1707_0 -location {9000.466 14093.324} -status PLACED
place_inst -name r1707_1 -location {9000.466 14233.713} -status PLACED
place_inst -name r1707_2 -location {9000.466 14374.103} -status PLACED
place_inst -name r1707_3 -location {9000.466 14514.492} -status PLACED
place_inst -name b1707 -location {9000.466 14654.882} -status PLACED
place_inst -name r1708_0 -location {8997.410 14525.386} -status PLACED
place_inst -name b1708 -location {8994.354 14395.890} -status PLACED
place_inst -name r1709_0 -location {8991.394 14483.305} -status PLACED
place_inst -name b1709 -location {8988.434 14570.720} -status PLACED
place_inst -name b1710 -location {8855.520 14572.576} -status PLACED
place_inst -name b1711 -location {9005.280 14570.720} -status PLACED
place_inst -name b1712 -location {9005.280 14542.752} -status PLACED
place_inst -name b1713 -location {9005.280 14598.688} -status PLACED
place_inst -name b1714 -location {8998.674 14299.126} -status PLACED
place_inst -name r1715_0 -location {9099.897 14303.499} -status PLACED
place_inst -name b1715 -location {9201.120 14307.872} -status PLACED
place_inst -name b1716 -location {8998.674 14294.816} -status PLACED
place_inst -name b1717 -location {8852.192 14294.816} -status PLACED
place_inst -name b1718 -location {9005.280 14271.264} -status PLACED
place_inst -name b1719 -location {9005.280 14225.952} -status PLACED
place_inst -name b1720 -location {9005.280 14316.576} -status PLACED
place_inst -name b1721 -location {9000.466 14769.537} -status PLACED
place_inst -name r1722_0 -location {9116.729 14758.663} -status PLACED
place_inst -name b1722 -location {9232.992 14747.788} -status PLACED
place_inst -name r1723_0 -location {9286.656 14799.158} -status PLACED
place_inst -name b1723 -location {9340.320 14850.528} -status PLACED
place_inst -name b1724 -location {9232.992 14653.472} -status PLACED
place_inst -name b1725 -location {9164.512 14653.472} -status PLACED
place_inst -name b1726 -location {9301.472 14653.472} -status PLACED
place_inst -name b1727 -location {8991.826 14904.028} -status PLACED
place_inst -name r1728_0 -location {8923.671 14866.035} -status PLACED
place_inst -name r1728_1 -location {8855.515 14828.041} -status PLACED
place_inst -name b1728 -location {8787.360 14790.048} -status PLACED
place_inst -name b1729 -location {8996.146 14981.792} -status PLACED
place_inst -name r1730_0 -location {9089.801 14981.792} -status PLACED
place_inst -name b1730 -location {9183.456 14981.792} -status PLACED
place_inst -name b1731 -location {8923.776 14981.792} -status PLACED
place_inst -name b1732 -location {8855.200 14981.792} -status PLACED
place_inst -name b1733 -location {8992.352 14981.792} -status PLACED
place_inst -name r1734_0 -location {8953.702 14076.910} -status PLACED
place_inst -name r1734_1 -location {8940.558 14200.887} -status PLACED
place_inst -name r1734_2 -location {8927.413 14324.863} -status PLACED
place_inst -name r1734_3 -location {8914.269 14448.839} -status PLACED
place_inst -name r1734_4 -location {8901.124 14572.815} -status PLACED
place_inst -name r1734_5 -location {8887.980 14696.792} -status PLACED
place_inst -name b1734 -location {8874.835 14820.768} -status PLACED
place_inst -name r1735_0 -location {8730.425 14820.768} -status PLACED
place_inst -name b1735 -location {8586.016 14820.768} -status PLACED
place_inst -name r1736_0 -location {8503.104 14820.768} -status PLACED
place_inst -name b1736 -location {8420.192 14820.768} -status PLACED
place_inst -name r1737_0 -location {8668.928 14820.768} -status PLACED
place_inst -name b1737 -location {8751.840 14820.768} -status PLACED
place_inst -name r1738_0 -location {8999.846 14820.768} -status PLACED
place_inst -name r1738_1 -location {9124.857 14820.768} -status PLACED
place_inst -name r1738_2 -location {9249.869 14820.768} -status PLACED
place_inst -name b1738 -location {9374.880 14820.768} -status PLACED
place_inst -name b1739 -location {9805.920 12242.848} -status PLACED
place_inst -name b1740 -location {7716.000 12242.848} -status PLACED
place_inst -name b1741 -location {9806.880 9132.448} -status PLACED
place_inst -name b1742 -location {10514.400 10169.248} -status PLACED
place_inst -name b1743 -location {7715.040 9132.448} -status PLACED
place_inst -name b1744 -location {7007.520 10169.248} -status PLACED
place_inst -name r1745_0 -location {9368.256 1997.948} -status PLACED
place_inst -name b1745 -location {9407.808 1961.795} -status PLACED
place_inst -name r1746_0 -location {9407.808 1859.917} -status PLACED
place_inst -name r1746_1 -location {9407.808 1758.038} -status PLACED
place_inst -name b1746 -location {9407.808 1656.160} -status PLACED
place_inst -name r1747_0 -location {9299.808 1656.160} -status PLACED
place_inst -name r1747_1 -location {9191.808 1656.160} -status PLACED
place_inst -name b1747 -location {9083.808 1656.160} -status PLACED
place_inst -name r1748_0 -location {8982.112 1656.160} -status PLACED
place_inst -name r1748_1 -location {8880.416 1656.160} -status PLACED
place_inst -name b1748 -location {8778.720 1656.160} -status PLACED
place_inst -name r1749_0 -location {9161.504 1680.160} -status PLACED
place_inst -name r1749_1 -location {9161.504 1781.856} -status PLACED
place_inst -name b1749 -location {9161.504 1883.552} -status PLACED
place_inst -name r1750_0 -location {9407.808 1508.416} -status PLACED
place_inst -name r1750_1 -location {9407.808 1360.672} -status PLACED
place_inst -name r1750_2 -location {9542.752 1347.872} -status PLACED
place_inst -name r1750_3 -location {9690.496 1347.872} -status PLACED
place_inst -name b1750 -location {9838.240 1347.872} -status PLACED
place_inst -name b1751 -location {9470.634 2041.024} -status PLACED
place_inst -name r1752_0 -location {9334.385 2036.704} -status PLACED
place_inst -name b1752 -location {9198.136 2032.384} -status PLACED
place_inst -name r1753_0 -location {9063.116 2028.064} -status PLACED
place_inst -name b1753 -location {8928.096 2023.744} -status PLACED
place_inst -name b1754 -location {8928.096 2122.464} -status PLACED
place_inst -name b1755 -location {8778.720 2122.464} -status PLACED
place_inst -name b1756 -location {9064.864 2135.072} -status PLACED
place_inst -name r1757_0 -location {9023.360 1970.928} -status PLACED
place_inst -name b1757 -location {9118.624 1918.112} -status PLACED
place_inst -name r1758_0 -location {9202.715 2138.656} -status PLACED
place_inst -name r1758_1 -location {9207.293 2244.928} -status PLACED
place_inst -name b1758 -location {9211.872 2351.200} -status PLACED
place_inst -name r1759_0 -location {9178.400 2290.176} -status PLACED
place_inst -name b1759 -location {9144.928 2229.152} -status PLACED
place_inst -name r1760_0 -location {9211.872 2445.696} -status PLACED
place_inst -name b1760 -location {9211.872 2540.192} -status PLACED
place_inst -name r1761_0 -location {9572.265 2079.056} -status PLACED
place_inst -name b1761 -location {9673.895 2117.088} -status PLACED
place_inst -name r1762_0 -location {9602.138 2157.408} -status PLACED
place_inst -name r1762_1 -location {9530.381 2197.728} -status PLACED
place_inst -name b1762 -location {9458.624 2238.048} -status PLACED
place_inst -name r1763_0 -location {9364.912 2238.048} -status PLACED
place_inst -name b1763 -location {9271.200 2238.048} -status PLACED
place_inst -name r1764_0 -location {9491.856 2177.568} -status PLACED
place_inst -name b1764 -location {9525.088 2117.088} -status PLACED
place_inst -name r1765_0 -location {9793.157 2117.088} -status PLACED
place_inst -name r1765_1 -location {9912.418 2117.088} -status PLACED
place_inst -name b1765 -location {10031.680 2117.088} -status PLACED
place_inst -name r1766_0 -location {9948.144 2117.088} -status PLACED
place_inst -name b1766 -location {9864.608 2117.088} -status PLACED
place_inst -name r1767_0 -location {10108.880 2110.752} -status PLACED
place_inst -name b1767 -location {10186.080 2104.416} -status PLACED
place_inst -name b1768 -location {9805.920 3948.448} -status PLACED
place_inst -name b1769 -location {7716.000 3948.448} -status PLACED
place_inst -name b1770 -location {9806.880 4985.248} -status PLACED
place_inst -name b1771 -location {10514.400 6022.048} -status PLACED
place_inst -name b1772 -location {7715.040 4985.248} -status PLACED
place_inst -name b1773 -location {7007.520 6022.048} -status PLACED
place_inst -name b1774 -location {10515.360 7058.848} -status PLACED
place_inst -name b1775 -location {11222.880 8095.648} -status PLACED
place_inst -name b1776 -location {7006.560 7058.848} -status PLACED
place_inst -name b1777 -location {6299.040 8095.648} -status PLACED
place_inst -name r1778_0 -location {9363.509 15598.804} -status PLACED
place_inst -name r1778_1 -location {9421.573 15644.913} -status PLACED
place_inst -name b1778 -location {9479.636 15691.023} -status PLACED
place_inst -name r1779_0 -location {9479.636 15546.083} -status PLACED
place_inst -name r1779_1 -location {9479.636 15401.144} -status PLACED
place_inst -name b1779 -location {9479.636 15256.204} -status PLACED
place_inst -name r1780_0 -location {9357.070 15256.204} -status PLACED
place_inst -name b1780 -location {9234.504 15256.204} -status PLACED
place_inst -name r1781_0 -location {9120.558 15256.204} -status PLACED
place_inst -name r1781_1 -location {9038.688 15256.204} -status PLACED
place_inst -name r1781_2 -location {8861.880 15256.204} -status PLACED
place_inst -name b1781 -location {8778.720 15256.204} -status PLACED
place_inst -name b1782 -location {8778.720 15200.384} -status PLACED
place_inst -name b1783 -location {8778.720 15099.872} -status PLACED
place_inst -name b1784 -location {8778.720 15300.896} -status PLACED
place_inst -name r1785_0 -location {8778.720 15357.110} -status PLACED
place_inst -name b1785 -location {8778.720 15458.016} -status PLACED
place_inst -name r1786_0 -location {9262.933 15138.438} -status PLACED
place_inst -name b1786 -location {9291.362 15020.672} -status PLACED
place_inst -name r1787_0 -location {9171.377 15018.512} -status PLACED
place_inst -name b1787 -location {9051.392 15016.352} -status PLACED
place_inst -name b1788 -location {8922.272 15016.352} -status PLACED
place_inst -name b1789 -location {9180.512 15016.352} -status PLACED
place_inst -name r1790_0 -location {9304.801 15148.661} -status PLACED
place_inst -name r1790_1 -location {9318.241 15276.651} -status PLACED
place_inst -name b1790 -location {9331.680 15404.640} -status PLACED
place_inst -name r1791_0 -location {9561.794 15290.161} -status PLACED
place_inst -name r1791_1 -location {9643.952 15324.118} -status PLACED
place_inst -name r1791_2 -location {9726.110 15358.075} -status PLACED
place_inst -name b1791 -location {9808.268 15392.032} -status PLACED
place_inst -name r1792_0 -location {9707.507 15392.032} -status PLACED
place_inst -name r1792_1 -location {9606.745 15392.032} -status PLACED
place_inst -name b1792 -location {9505.984 15392.032} -status PLACED
place_inst -name b1793 -location {9366.240 15392.032} -status PLACED
place_inst -name b1794 -location {9633.120 15404.640} -status PLACED
place_inst -name r1795_0 -location {9942.310 15398.336} -status PLACED
place_inst -name b1795 -location {10076.352 15404.640} -status PLACED
place_inst -name r1796_0 -location {9997.776 15404.640} -status PLACED
place_inst -name b1796 -location {9919.200 15404.640} -status PLACED
place_inst -name r1797_0 -location {10131.216 15428.352} -status PLACED
place_inst -name b1797 -location {10186.080 15452.064} -status PLACED
place_inst -name r1798_0 -location {9454.263 15776.149} -status PLACED
place_inst -name r1798_1 -location {9428.891 15861.275} -status PLACED
place_inst -name b1798 -location {9403.518 15946.401} -status PLACED
place_inst -name r1799_0 -location {9523.256 15944.961} -status PLACED
place_inst -name r1799_1 -location {9642.995 15943.521} -status PLACED
place_inst -name b1799 -location {9762.733 15942.081} -status PLACED
place_inst -name r1800_0 -location {9855.209 15992.043} -status PLACED
place_inst -name r1800_1 -location {9947.684 16042.006} -status PLACED
place_inst -name b1800 -location {10040.160 16091.968} -status PLACED
place_inst -name r1801_0 -location {9990.496 16150.320} -status PLACED
place_inst -name b1801 -location {9940.832 16208.672} -status PLACED
place_inst -name r1802_0 -location {10040.160 15983.952} -status PLACED
place_inst -name b1802 -location {10040.160 15875.936} -status PLACED
place_inst -name r1803_0 -location {9762.733 15793.168} -status PLACED
place_inst -name b1803 -location {9762.733 15644.256} -status PLACED
place_inst -name r1804_0 -location {9649.939 15644.256} -status PLACED
place_inst -name r1804_1 -location {9537.146 15644.256} -status PLACED
place_inst -name b1804 -location {9424.352 15644.256} -status PLACED
place_inst -name b1805 -location {9808.928 15726.560} -status PLACED
place_inst -name r1806_0 -location {9777.984 15674.624} -status PLACED
place_inst -name b1806 -location {9747.040 15622.688} -status PLACED
place_inst -name r1807_0 -location {9808.928 15809.440} -status PLACED
place_inst -name b1807 -location {9808.928 15892.320} -status PLACED
place_inst -name r1808_0 -location {9270.261 15936.659} -status PLACED
place_inst -name r1808_1 -location {9137.003 15926.917} -status PLACED
place_inst -name r1808_2 -location {9003.745 15917.176} -status PLACED
place_inst -name b1808 -location {8870.488 15907.434} -status PLACED
place_inst -name b1809 -location {8783.285 15911.754} -status PLACED
place_inst -name b1810 -location {8843.552 15911.754} -status PLACED
place_inst -name r1811_0 -location {8811.136 15997.653} -status PLACED
place_inst -name b1811 -location {8778.720 16083.552} -status PLACED
place_inst -name b1812 -location {8843.552 15812.800} -status PLACED
place_inst -name b1813 -location {8778.720 15839.776} -status PLACED
place_inst -name b1814 -location {8843.552 15720.992} -status PLACED
place_inst -name r1815_0 -location {8781.763 15798.481} -status PLACED
place_inst -name r1815_1 -location {8780.242 15685.209} -status PLACED
place_inst -name b1815 -location {8778.720 15571.936} -status PLACED
place_inst -name r1816_0 -location {8926.026 15841.639} -status PLACED
place_inst -name r1816_1 -location {8981.564 15775.845} -status PLACED
place_inst -name r1816_2 -location {9037.102 15710.050} -status PLACED
place_inst -name b1816 -location {9092.640 15644.256} -status PLACED
place_inst -name b1817 -location {9805.920 14316.448} -status PLACED
place_inst -name b1818 -location {7716.000 14316.448} -status PLACED
place_inst -name b1819 -location {9806.880 11206.048} -status PLACED
place_inst -name b1820 -location {10514.400 12242.848} -status PLACED
place_inst -name b1821 -location {7715.040 11206.048} -status PLACED
place_inst -name b1822 -location {7007.520 12242.848} -status PLACED
place_inst -name b1823 -location {10515.360 9132.448} -status PLACED
place_inst -name b1824 -location {11222.880 10169.248} -status PLACED
place_inst -name b1825 -location {7006.560 9132.448} -status PLACED
place_inst -name b1826 -location {6299.040 10169.248} -status PLACED
place_inst -name b1827 -location {10203.360 1252.832} -status PLACED
place_inst -name b1828 -location {8081.548 1873.226} -status PLACED
place_inst -name r1829_0 -location {8216.977 1881.294} -status PLACED
place_inst -name r1829_1 -location {8352.406 1889.363} -status PLACED
place_inst -name r1829_2 -location {8487.835 1897.431} -status PLACED
place_inst -name b1829 -location {8623.264 1905.499} -status PLACED
place_inst -name r1830_0 -location {8600.512 2024.606} -status PLACED
place_inst -name b1830 -location {8577.760 2143.712} -status PLACED
place_inst -name r1831_0 -location {8488.992 2139.392} -status PLACED
place_inst -name b1831 -location {8400.224 2135.072} -status PLACED
place_inst -name r1832_0 -location {8660.480 2154.080} -status PLACED
place_inst -name b1832 -location {8743.200 2164.448} -status PLACED
place_inst -name r1833_0 -location {8625.424 1785.149} -status PLACED
place_inst -name b1833 -location {8627.584 1664.800} -status PLACED
place_inst -name r1834_0 -location {8518.928 1660.480} -status PLACED
place_inst -name b1834 -location {8410.272 1656.160} -status PLACED
place_inst -name r1835_0 -location {8685.392 1719.968} -status PLACED
place_inst -name b1835 -location {8743.200 1775.136} -status PLACED
place_inst -name b1836 -location {7965.024 1873.226} -status PLACED
place_inst -name r1837_0 -location {7889.807 1933.376} -status PLACED
place_inst -name r1837_1 -location {7814.589 1993.525} -status PLACED
place_inst -name r1837_2 -location {7739.372 2053.675} -status PLACED
place_inst -name b1837 -location {7664.154 2113.824} -status PLACED
place_inst -name r1838_0 -location {7789.447 2116.704} -status PLACED
place_inst -name r1838_1 -location {7914.739 2119.584} -status PLACED
place_inst -name b1838 -location {8040.032 2122.464} -status PLACED
place_inst -name r1839_0 -location {7571.789 2109.120} -status PLACED
place_inst -name b1839 -location {7479.424 2104.416} -status PLACED
place_inst -name b1840 -location {7335.840 2104.416} -status PLACED
place_inst -name b1841 -location {7610.336 2117.088} -status PLACED
place_inst -name r1842_0 -location {7967.904 1734.652} -status PLACED
place_inst -name r1842_1 -location {7970.784 1596.077} -status PLACED
place_inst -name b1842 -location {7973.664 1457.503} -status PLACED
place_inst -name r1843_0 -location {7875.520 1430.095} -status PLACED
place_inst -name r1843_1 -location {7777.376 1402.688} -status PLACED
place_inst -name r1843_2 -location {7679.232 1375.280} -status PLACED
place_inst -name b1843 -location {7581.088 1347.872} -status PLACED
place_inst -name b1844 -location {7977.984 1570.528} -status PLACED
place_inst -name r1845_0 -location {7890.320 1570.528} -status PLACED
place_inst -name b1845 -location {7802.656 1570.528} -status PLACED
place_inst -name b1846 -location {7708.832 1553.568} -status PLACED
place_inst -name b1847 -location {7802.656 1681.312} -status PLACED
place_inst -name r1848_0 -location {8018.736 1617.440} -status PLACED
place_inst -name b1848 -location {8059.488 1664.352} -status PLACED
place_inst -name b1849 -location {8059.488 1553.568} -status PLACED
place_inst -name b1850 -location {8059.488 1775.136} -status PLACED
place_inst -name b1851 -location {10929.936 2168.768} -status PLACED
place_inst -name r1852_0 -location {10790.460 2168.768} -status PLACED
place_inst -name r1852_1 -location {10650.985 2168.768} -status PLACED
place_inst -name b1852 -location {10511.509 2168.768} -status PLACED
place_inst -name r1853_0 -location {10438.331 2166.608} -status PLACED
place_inst -name b1853 -location {10365.152 2164.448} -status PLACED
place_inst -name b1854 -location {10221.600 2164.448} -status PLACED
place_inst -name b1855 -location {10496.096 2151.840} -status PLACED
place_inst -name r1856_0 -location {10603.737 2147.317} -status PLACED
place_inst -name r1856_1 -location {10695.964 2125.867} -status PLACED
place_inst -name b1856 -location {10788.192 2104.416} -status PLACED
place_inst -name r1857_0 -location {11036.453 2166.005} -status PLACED
place_inst -name r1857_1 -location {11142.970 2163.243} -status PLACED
place_inst -name b1857 -location {11249.487 2160.480} -status PLACED
place_inst -name r1858_0 -location {11177.688 2156.160} -status PLACED
place_inst -name b1858 -location {11105.888 2151.840} -status PLACED
place_inst -name r1859_0 -location {11015.840 2151.840} -status PLACED
place_inst -name b1859 -location {10925.792 2151.840} -status PLACED
place_inst -name r1860_0 -location {11195.936 2151.840} -status PLACED
place_inst -name b1860 -location {11285.984 2151.840} -status PLACED
place_inst -name r1861_0 -location {11375.978 2147.808} -status PLACED
place_inst -name r1861_1 -location {11502.469 2135.136} -status PLACED
place_inst -name b1861 -location {11628.960 2122.464} -status PLACED
place_inst -name b1862 -location {9806.880 2911.648} -status PLACED
place_inst -name b1863 -location {10514.400 3948.448} -status PLACED
place_inst -name b1864 -location {7715.040 2911.648} -status PLACED
place_inst -name b1865 -location {7007.520 3948.448} -status PLACED
place_inst -name b1866 -location {10515.360 4985.248} -status PLACED
place_inst -name b1867 -location {11222.880 6022.048} -status PLACED
place_inst -name b1868 -location {7006.560 4985.248} -status PLACED
place_inst -name b1869 -location {6299.040 6022.048} -status PLACED
place_inst -name b1870 -location {11223.840 7058.848} -status PLACED
place_inst -name b1871 -location {11931.360 8095.648} -status PLACED
place_inst -name b1872 -location {6298.080 7058.848} -status PLACED
place_inst -name b1873 -location {5590.560 8095.648} -status PLACED
place_inst -name b1874 -location {8043.360 15612.448} -status PLACED
place_inst -name b1875 -location {10203.360 16303.648} -status PLACED
place_inst -name b1876 -location {10929.936 15387.712} -status PLACED
place_inst -name r1877_0 -location {10790.460 15387.712} -status PLACED
place_inst -name r1877_1 -location {10650.985 15387.712} -status PLACED
place_inst -name b1877 -location {10511.509 15387.712} -status PLACED
place_inst -name r1878_0 -location {10438.331 15389.872} -status PLACED
place_inst -name b1878 -location {10365.152 15392.032} -status PLACED
place_inst -name b1879 -location {10221.600 15392.032} -status PLACED
place_inst -name b1880 -location {10496.096 15404.640} -status PLACED
place_inst -name r1881_0 -location {10603.737 15409.163} -status PLACED
place_inst -name r1881_1 -location {10695.964 15430.613} -status PLACED
place_inst -name b1881 -location {10788.192 15452.064} -status PLACED
place_inst -name r1882_0 -location {11036.453 15390.475} -status PLACED
place_inst -name r1882_1 -location {11142.970 15393.237} -status PLACED
place_inst -name b1882 -location {11249.487 15396.000} -status PLACED
place_inst -name r1883_0 -location {11177.688 15400.320} -status PLACED
place_inst -name b1883 -location {11105.888 15404.640} -status PLACED
place_inst -name r1884_0 -location {11015.840 15404.640} -status PLACED
place_inst -name b1884 -location {10925.792 15404.640} -status PLACED
place_inst -name r1885_0 -location {11195.936 15404.640} -status PLACED
place_inst -name b1885 -location {11285.984 15404.640} -status PLACED
place_inst -name r1886_0 -location {11375.978 15408.672} -status PLACED
place_inst -name r1886_1 -location {11502.469 15421.344} -status PLACED
place_inst -name b1886 -location {11628.960 15434.016} -status PLACED
place_inst -name b1887 -location {9806.880 13279.648} -status PLACED
place_inst -name b1888 -location {10514.400 14316.448} -status PLACED
place_inst -name b1889 -location {7715.040 13279.648} -status PLACED
place_inst -name b1890 -location {7007.520 14316.448} -status PLACED
place_inst -name b1891 -location {10515.360 11206.048} -status PLACED
place_inst -name b1892 -location {11222.880 12242.848} -status PLACED
place_inst -name b1893 -location {7006.560 11206.048} -status PLACED
place_inst -name b1894 -location {6299.040 12242.848} -status PLACED
place_inst -name b1895 -location {11223.840 9132.448} -status PLACED
place_inst -name b1896 -location {11931.360 10169.248} -status PLACED
place_inst -name b1897 -location {6298.080 9132.448} -status PLACED
place_inst -name b1898 -location {5590.560 10169.248} -status PLACED
place_inst -name b1899 -location {7318.560 1252.832} -status PLACED
place_inst -name b1900 -location {6635.040 2131.104} -status PLACED
place_inst -name r1901_0 -location {6493.904 2131.104} -status PLACED
place_inst -name r1901_1 -location {6352.768 2131.104} -status PLACED
place_inst -name r1901_2 -location {6211.632 2131.104} -status PLACED
place_inst -name b1901 -location {6070.496 2131.104} -status PLACED
place_inst -name r1902_0 -location {5981.728 2126.784} -status PLACED
place_inst -name b1902 -location {5892.960 2122.464} -status PLACED
place_inst -name r1903_0 -location {6153.216 2141.472} -status PLACED
place_inst -name b1903 -location {6235.936 2151.840} -status PLACED
place_inst -name r1904_0 -location {6740.175 2138.016} -status PLACED
place_inst -name r1904_1 -location {6845.310 2144.928} -status PLACED
place_inst -name b1904 -location {6950.445 2151.840} -status PLACED
place_inst -name r1905_0 -location {6817.382 2149.680} -status PLACED
place_inst -name b1905 -location {6684.320 2147.520} -status PLACED
place_inst -name b1906 -location {6596.128 2151.840} -status PLACED
place_inst -name b1907 -location {6733.728 2104.416} -status PLACED
place_inst -name r1908_0 -location {7059.910 2151.840} -status PLACED
place_inst -name b1908 -location {7169.376 2151.840} -status PLACED
place_inst -name b1909 -location {7025.824 2151.840} -status PLACED
place_inst -name b1910 -location {7300.320 2164.448} -status PLACED
place_inst -name r1911_0 -location {12466.579 2079.730} -status PLACED
place_inst -name r1911_1 -location {12567.237 2113.449} -status PLACED
place_inst -name b1911 -location {12667.896 2147.168} -status PLACED
place_inst -name r1912_0 -location {12520.149 2149.328} -status PLACED
place_inst -name r1912_1 -location {12372.401 2151.488} -status PLACED
place_inst -name r1912_2 -location {12224.654 2153.648} -status PLACED
place_inst -name b1912 -location {12076.906 2155.808} -status PLACED
place_inst -name r1913_0 -location {11934.917 2155.808} -status PLACED
place_inst -name b1913 -location {11792.928 2155.808} -status PLACED
place_inst -name b1914 -location {11664.480 2164.448} -status PLACED
place_inst -name b1915 -location {11926.048 2151.840} -status PLACED
place_inst -name r1916_0 -location {12209.605 2149.504} -status PLACED
place_inst -name b1916 -location {12342.304 2143.200} -status PLACED
place_inst -name b1917 -location {12205.472 2151.840} -status PLACED
place_inst -name b1918 -location {12467.040 2122.464} -status PLACED
place_inst -name r1919_0 -location {12715.237 2065.625} -status PLACED
place_inst -name r1919_1 -location {12762.579 1984.083} -status PLACED
place_inst -name b1919 -location {12809.920 1902.540} -status PLACED
place_inst -name r1920_0 -location {12724.000 1860.330} -status PLACED
place_inst -name r1920_1 -location {12724.000 1732.199} -status PLACED
place_inst -name r1920_2 -location {12724.000 1604.069} -status PLACED
place_inst -name r1920_3 -location {12724.000 1475.938} -status PLACED
place_inst -name b1920 -location {12724.000 1347.808} -status PLACED
place_inst -name r1921_0 -location {12809.920 2035.830} -status PLACED
place_inst -name b1921 -location {12809.920 2169.120} -status PLACED
place_inst -name r1922_0 -location {12701.707 2169.120} -status PLACED
place_inst -name r1922_1 -location {12593.493 2169.120} -status PLACED
place_inst -name b1922 -location {12502.560 2151.840} -status PLACED
place_inst -name r1923_0 -location {12855.413 2231.840} -status PLACED
place_inst -name r1923_1 -location {12963.627 2231.840} -status PLACED
place_inst -name b1923 -location {13071.840 2231.840} -status PLACED
place_inst -name b1924 -location {10515.360 2911.648} -status PLACED
place_inst -name b1925 -location {11222.880 3948.448} -status PLACED
place_inst -name b1926 -location {7006.560 2911.648} -status PLACED
place_inst -name b1927 -location {6299.040 3948.448} -status PLACED
place_inst -name b1928 -location {11223.840 4985.248} -status PLACED
place_inst -name b1929 -location {11931.360 6022.048} -status PLACED
place_inst -name b1930 -location {6298.080 4985.248} -status PLACED
place_inst -name b1931 -location {5590.560 6022.048} -status PLACED
place_inst -name b1932 -location {11932.320 7058.848} -status PLACED
place_inst -name b1933 -location {12639.840 8095.648} -status PLACED
place_inst -name b1934 -location {5589.600 7058.848} -status PLACED
place_inst -name b1935 -location {4882.080 8095.648} -status PLACED
place_inst -name b1936 -location {7318.560 16303.648} -status PLACED
place_inst -name r1937_0 -location {6660.247 15510.974} -status PLACED
place_inst -name b1937 -location {6723.769 15463.841} -status PLACED
place_inst -name r1938_0 -location {6574.107 15463.841} -status PLACED
place_inst -name r1938_1 -location {6424.444 15463.841} -status PLACED
place_inst -name r1938_2 -location {6274.782 15463.841} -status PLACED
place_inst -name b1938 -location {6125.120 15463.841} -status PLACED
place_inst -name r1939_0 -location {6105.108 15406.337} -status PLACED
place_inst -name b1939 -location {6085.096 15348.832} -status PLACED
place_inst -name r1940_0 -location {6021.051 15306.571} -status PLACED
place_inst -name r1940_1 -location {5957.005 15264.309} -status PLACED
place_inst -name b1940 -location {5892.960 15222.048} -status PLACED
place_inst -name r1941_0 -location {6160.516 15348.832} -status PLACED
place_inst -name b1941 -location {6235.936 15348.832} -status PLACED
place_inst -name b1942 -location {6235.936 15228.000} -status PLACED
place_inst -name b1943 -location {6235.936 15469.664} -status PLACED
place_inst -name r1944_0 -location {6129.440 15602.945} -status PLACED
place_inst -name b1944 -location {6133.760 15742.048} -status PLACED
place_inst -name r1945_0 -location {6013.360 15742.048} -status PLACED
place_inst -name b1945 -location {5892.960 15742.048} -status PLACED
place_inst -name r1946_0 -location {6184.848 15811.360} -status PLACED
place_inst -name b1946 -location {6235.936 15880.672} -status PLACED
place_inst -name r1947_0 -location {6751.523 15540.886} -status PLACED
place_inst -name r1947_1 -location {6779.278 15617.931} -status PLACED
place_inst -name b1947 -location {6807.032 15694.976} -status PLACED
place_inst -name r1948_0 -location {6930.354 15697.136} -status PLACED
place_inst -name r1948_1 -location {7053.676 15699.296} -status PLACED
place_inst -name r1948_2 -location {7176.998 15701.456} -status PLACED
place_inst -name b1948 -location {7300.320 15703.616} -status PLACED
place_inst -name r1949_0 -location {7300.320 15573.616} -status PLACED
place_inst -name b1949 -location {7300.320 15443.616} -status PLACED
place_inst -name r1950_0 -location {7300.320 15833.616} -status PLACED
place_inst -name b1950 -location {7300.320 15963.616} -status PLACED
place_inst -name r1951_0 -location {6798.988 15621.827} -status PLACED
place_inst -name b1951 -location {6790.944 15548.678} -status PLACED
place_inst -name r1952_0 -location {6820.158 15448.755} -status PLACED
place_inst -name b1952 -location {6849.371 15348.832} -status PLACED
place_inst -name r1953_0 -location {6723.262 15336.736} -status PLACED
place_inst -name b1953 -location {6597.152 15324.640} -status PLACED
place_inst -name b1954 -location {6957.344 15348.832} -status PLACED
place_inst -name b1955 -location {6957.344 15228.000} -status PLACED
place_inst -name b1956 -location {6957.344 15469.664} -status PLACED
place_inst -name r1957_0 -location {6792.384 15647.332} -status PLACED
place_inst -name r1957_1 -location {6793.824 15745.986} -status PLACED
place_inst -name b1957 -location {6795.264 15844.640} -status PLACED
place_inst -name r1958_0 -location {6696.208 15844.640} -status PLACED
place_inst -name b1958 -location {6597.152 15844.640} -status PLACED
place_inst -name r1959_0 -location {6876.304 15862.656} -status PLACED
place_inst -name b1959 -location {6957.344 15880.672} -status PLACED
place_inst -name r1960_0 -location {12445.139 15469.550} -status PLACED
place_inst -name r1960_1 -location {12524.357 15428.631} -status PLACED
place_inst -name b1960 -location {12603.576 15387.712} -status PLACED
place_inst -name r1961_0 -location {12474.068 15388.792} -status PLACED
place_inst -name r1961_1 -location {12344.561 15389.872} -status PLACED
place_inst -name r1961_2 -location {12215.053 15390.952} -status PLACED
place_inst -name b1961 -location {12085.546 15392.032} -status PLACED
place_inst -name r1962_0 -location {11943.557 15392.032} -status PLACED
place_inst -name b1962 -location {11801.568 15392.032} -status PLACED
place_inst -name b1963 -location {11664.480 15392.032} -status PLACED
place_inst -name b1964 -location {11926.048 15404.640} -status PLACED
place_inst -name r1965_0 -location {12218.245 15398.336} -status PLACED
place_inst -name b1965 -location {12350.944 15404.640} -status PLACED
place_inst -name b1966 -location {12205.472 15404.640} -status PLACED
place_inst -name b1967 -location {12467.040 15434.016} -status PLACED
place_inst -name r1968_0 -location {12643.717 15447.815} -status PLACED
place_inst -name r1968_1 -location {12683.859 15507.917} -status PLACED
place_inst -name b1968 -location {12724.000 15568.020} -status PLACED
place_inst -name r1969_0 -location {12818.560 15529.290} -status PLACED
place_inst -name b1969 -location {12818.560 15396.000} -status PLACED
place_inst -name r1970_0 -location {12710.347 15396.000} -status PLACED
place_inst -name r1970_1 -location {12602.133 15396.000} -status PLACED
place_inst -name b1970 -location {12502.560 15404.640} -status PLACED
place_inst -name r1971_0 -location {12855.413 15324.640} -status PLACED
place_inst -name r1971_1 -location {12963.627 15324.640} -status PLACED
place_inst -name b1971 -location {13071.840 15324.640} -status PLACED
place_inst -name r1972_0 -location {12724.000 15696.150} -status PLACED
place_inst -name r1972_1 -location {12724.000 15824.281} -status PLACED
place_inst -name r1972_2 -location {12724.000 15952.411} -status PLACED
place_inst -name r1972_3 -location {12724.000 16080.542} -status PLACED
place_inst -name b1972 -location {12724.000 16208.672} -status PLACED
place_inst -name b1973 -location {10515.360 13279.648} -status PLACED
place_inst -name b1974 -location {11222.880 14316.448} -status PLACED
place_inst -name b1975 -location {7006.560 13279.648} -status PLACED
place_inst -name b1976 -location {6299.040 14316.448} -status PLACED
place_inst -name b1977 -location {11223.840 11206.048} -status PLACED
place_inst -name b1978 -location {11931.360 12242.848} -status PLACED
place_inst -name b1979 -location {6298.080 11206.048} -status PLACED
place_inst -name b1980 -location {5590.560 12242.848} -status PLACED
place_inst -name b1981 -location {11932.320 9132.448} -status PLACED
place_inst -name b1982 -location {12639.840 10169.248} -status PLACED
place_inst -name b1983 -location {5589.600 9132.448} -status PLACED
place_inst -name b1984 -location {4882.080 10169.248} -status PLACED
place_inst -name b1985 -location {5093.232 1965.260} -status PLACED
place_inst -name r1986_0 -location {4987.061 1965.260} -status PLACED
place_inst -name r1986_1 -location {4880.891 1965.260} -status PLACED
place_inst -name b1986 -location {4774.720 1965.260} -status PLACED
place_inst -name r1987_0 -location {4797.920 1860.330} -status PLACED
place_inst -name r1987_1 -location {4797.920 1732.199} -status PLACED
place_inst -name r1987_2 -location {4797.920 1604.069} -status PLACED
place_inst -name r1987_3 -location {4797.920 1475.938} -status PLACED
place_inst -name b1987 -location {4797.920 1347.808} -status PLACED
place_inst -name r1988_0 -location {4774.720 2098.550} -status PLACED
place_inst -name b1988 -location {4774.720 2231.840} -status PLACED
place_inst -name r1989_0 -location {4666.507 2231.840} -status PLACED
place_inst -name r1989_1 -location {4558.293 2231.840} -status PLACED
place_inst -name b1989 -location {4450.080 2231.840} -status PLACED
place_inst -name r1990_0 -location {4882.933 2231.840} -status PLACED
place_inst -name r1990_1 -location {4991.147 2231.840} -status PLACED
place_inst -name b1990 -location {5019.360 2151.840} -status PLACED
place_inst -name r1991_0 -location {5187.354 2006.721} -status PLACED
place_inst -name r1991_1 -location {5281.475 2048.182} -status PLACED
place_inst -name r1991_2 -location {5375.596 2089.643} -status PLACED
place_inst -name b1991 -location {5469.718 2131.104} -status PLACED
place_inst -name r1992_0 -location {5330.715 2131.104} -status PLACED
place_inst -name b1992 -location {5191.712 2131.104} -status PLACED
place_inst -name b1993 -location {5054.880 2122.464} -status PLACED
place_inst -name b1994 -location {5316.448 2151.840} -status PLACED
place_inst -name r1995_0 -location {5601.339 2141.472} -status PLACED
place_inst -name b1995 -location {5732.960 2151.840} -status PLACED
place_inst -name b1996 -location {5595.872 2151.840} -status PLACED
place_inst -name b1997 -location {5857.440 2164.448} -status PLACED
place_inst -name b1998 -location {13089.120 1252.832} -status PLACED
place_inst -name b1999 -location {13828.776 2231.840} -status PLACED
place_inst -name r2000_0 -location {13708.540 2212.011} -status PLACED
place_inst -name r2000_1 -location {13588.304 2192.181} -status PLACED
place_inst -name r2000_2 -location {13468.068 2172.352} -status PLACED
place_inst -name r2000_3 -location {13347.832 2152.523} -status PLACED
place_inst -name r2000_4 -location {13227.596 2132.693} -status PLACED
place_inst -name b2000 -location {13107.360 2112.864} -status PLACED
place_inst -name b2001 -location {13975.306 2231.840} -status PLACED
place_inst -name r2002_0 -location {13876.204 2231.840} -status PLACED
place_inst -name b2002 -location {13777.103 2231.840} -status PLACED
place_inst -name b2003 -location {13630.432 2231.840} -status PLACED
place_inst -name r2004_0 -location {13540.384 2231.840} -status PLACED
place_inst -name b2004 -location {13450.336 2231.840} -status PLACED
place_inst -name r2005_0 -location {13720.480 2231.840} -status PLACED
place_inst -name b2005 -location {13810.528 2231.840} -status PLACED
place_inst -name r2006_0 -location {13908.650 2231.840} -status PLACED
place_inst -name r2006_1 -location {14040.197 2231.840} -status PLACED
place_inst -name b2006 -location {14171.744 2231.840} -status PLACED
place_inst -name r2007_0 -location {14083.189 2252.358} -status PLACED
place_inst -name r2007_1 -location {14191.072 2272.877} -status PLACED
place_inst -name r2007_2 -location {14298.954 2293.395} -status PLACED
place_inst -name r2007_3 -location {14406.837 2313.914} -status PLACED
place_inst -name b2007 -location {14514.720 2334.432} -status PLACED
place_inst -name b2008 -location {11223.840 2911.648} -status PLACED
place_inst -name b2009 -location {11931.360 3948.448} -status PLACED
place_inst -name b2010 -location {6298.080 2911.648} -status PLACED
place_inst -name b2011 -location {5590.560 3948.448} -status PLACED
place_inst -name b2012 -location {11932.320 4985.248} -status PLACED
place_inst -name b2013 -location {12639.840 6022.048} -status PLACED
place_inst -name b2014 -location {5589.600 4985.248} -status PLACED
place_inst -name b2015 -location {4882.080 6022.048} -status PLACED
place_inst -name b2016 -location {12640.800 7058.848} -status PLACED
place_inst -name b2017 -location {13348.320 8095.648} -status PLACED
place_inst -name b2018 -location {4881.120 7058.848} -status PLACED
place_inst -name b2019 -location {4173.600 8095.648} -status PLACED
place_inst -name b2020 -location {5132.733 15328.960} -status PLACED
place_inst -name b2021 -location {4989.494 15324.640} -status PLACED
place_inst -name r2022_0 -location {4881.611 15304.122} -status PLACED
place_inst -name r2022_1 -location {4773.728 15283.603} -status PLACED
place_inst -name r2022_2 -location {4665.846 15263.085} -status PLACED
place_inst -name r2022_3 -location {4557.963 15242.566} -status PLACED
place_inst -name b2022 -location {4450.080 15222.048} -status PLACED
place_inst -name r2023_0 -location {5088.595 15324.640} -status PLACED
place_inst -name b2023 -location {5187.697 15324.640} -status PLACED
place_inst -name r2024_0 -location {5056.150 15324.640} -status PLACED
place_inst -name r2024_1 -location {4924.603 15324.640} -status PLACED
place_inst -name b2024 -location {4793.056 15324.640} -status PLACED
place_inst -name b2025 -location {5334.368 15324.640} -status PLACED
place_inst -name r2026_0 -location {5244.320 15324.640} -status PLACED
place_inst -name b2026 -location {5154.272 15324.640} -status PLACED
place_inst -name r2027_0 -location {5424.416 15324.640} -status PLACED
place_inst -name b2027 -location {5514.464 15324.640} -status PLACED
place_inst -name r2028_0 -location {5253.517 15348.069} -status PLACED
place_inst -name r2028_1 -location {5374.302 15367.179} -status PLACED
place_inst -name r2028_2 -location {5495.086 15386.288} -status PLACED
place_inst -name r2028_3 -location {5615.871 15405.397} -status PLACED
place_inst -name r2028_4 -location {5736.655 15424.507} -status PLACED
place_inst -name b2028 -location {5857.440 15443.616} -status PLACED
place_inst -name b2029 -location {5233.616 15886.779} -status PLACED
place_inst -name r2030_0 -location {5086.062 15886.779} -status PLACED
place_inst -name r2030_1 -location {4938.507 15886.779} -status PLACED
place_inst -name b2030 -location {4790.953 15886.779} -status PLACED
place_inst -name r2031_0 -location {4832.645 15796.334} -status PLACED
place_inst -name b2031 -location {4874.336 15705.888} -status PLACED
place_inst -name r2032_0 -location {4796.128 15705.888} -status PLACED
place_inst -name b2032 -location {4717.920 15705.888} -status PLACED
place_inst -name r2033_0 -location {4946.656 15711.776} -status PLACED
place_inst -name b2033 -location {5018.976 15717.664} -status PLACED
place_inst -name b2034 -location {4782.313 15994.510} -status PLACED
place_inst -name r2035_0 -location {4753.318 16065.876} -status PLACED
place_inst -name r2035_1 -location {4724.323 16137.242} -status PLACED
place_inst -name b2035 -location {4695.328 16208.608} -status PLACED
place_inst -name b2036 -location {4821.024 15994.510} -status PLACED
place_inst -name r2037_0 -location {4922.848 16000.631} -status PLACED
place_inst -name b2037 -location {5024.672 16006.752} -status PLACED
place_inst -name b2038 -location {4816.704 15948.640} -status PLACED
place_inst -name b2039 -location {4695.328 15948.640} -status PLACED
place_inst -name b2040 -location {4862.368 15872.928} -status PLACED
place_inst -name r2041_0 -location {5331.677 15860.207} -status PLACED
place_inst -name r2041_1 -location {5429.738 15833.635} -status PLACED
place_inst -name b2041 -location {5527.799 15807.063} -status PLACED
place_inst -name r2042_0 -location {5417.948 15802.743} -status PLACED
place_inst -name b2042 -location {5308.096 15798.423} -status PLACED
place_inst -name b2043 -location {5344.928 15714.240} -status PLACED
place_inst -name b2044 -location {5284.896 15688.608} -status PLACED
place_inst -name b2045 -location {5353.568 15791.264} -status PLACED
place_inst -name b2046 -location {5303.776 15875.040} -status PLACED
place_inst -name b2047 -location {5176.288 15875.040} -status PLACED
place_inst -name b2048 -location {5303.776 16002.528} -status PLACED
place_inst -name r2049_0 -location {5574.382 15857.748} -status PLACED
place_inst -name b2049 -location {5620.966 15908.433} -status PLACED
place_inst -name r2050_0 -location {5739.203 15936.024} -status PLACED
place_inst -name b2050 -location {5857.440 15963.616} -status PLACED
place_inst -name b2051 -location {5595.232 15908.433} -status PLACED
place_inst -name r2052_0 -location {5596.576 15825.240} -status PLACED
place_inst -name b2052 -location {5597.920 15742.048} -status PLACED
place_inst -name b2053 -location {5586.592 15945.440} -status PLACED
place_inst -name b2054 -location {5543.776 15911.136} -status PLACED
place_inst -name b2055 -location {5595.232 16013.920} -status PLACED
place_inst -name b2056 -location {13089.120 16303.648} -status PLACED
place_inst -name r2057_0 -location {13879.345 15385.766} -status PLACED
place_inst -name b2057 -location {13947.752 15443.616} -status PLACED
place_inst -name r2058_0 -location {13807.687 15443.616} -status PLACED
place_inst -name r2058_1 -location {13667.621 15443.616} -status PLACED
place_inst -name r2058_2 -location {13527.556 15443.616} -status PLACED
place_inst -name r2058_3 -location {13387.491 15443.616} -status PLACED
place_inst -name r2058_4 -location {13247.425 15443.616} -status PLACED
place_inst -name b2058 -location {13107.360 15443.616} -status PLACED
place_inst -name b2059 -location {13975.306 15324.640} -status PLACED
place_inst -name r2060_0 -location {13876.204 15324.640} -status PLACED
place_inst -name b2060 -location {13777.103 15324.640} -status PLACED
place_inst -name b2061 -location {13630.432 15324.640} -status PLACED
place_inst -name r2062_0 -location {13540.384 15324.640} -status PLACED
place_inst -name b2062 -location {13450.336 15324.640} -status PLACED
place_inst -name r2063_0 -location {13720.480 15324.640} -status PLACED
place_inst -name b2063 -location {13810.528 15324.640} -status PLACED
place_inst -name r2064_0 -location {13908.650 15324.640} -status PLACED
place_inst -name r2064_1 -location {14040.197 15324.640} -status PLACED
place_inst -name b2064 -location {14171.744 15324.640} -status PLACED
place_inst -name r2065_0 -location {14083.189 15304.122} -status PLACED
place_inst -name r2065_1 -location {14191.072 15283.603} -status PLACED
place_inst -name r2065_2 -location {14298.954 15263.085} -status PLACED
place_inst -name r2065_3 -location {14406.837 15242.566} -status PLACED
place_inst -name b2065 -location {14514.720 15222.048} -status PLACED
place_inst -name b2066 -location {11223.840 13279.648} -status PLACED
place_inst -name b2067 -location {11931.360 14316.448} -status PLACED
place_inst -name b2068 -location {6298.080 13279.648} -status PLACED
place_inst -name b2069 -location {5590.560 14316.448} -status PLACED
place_inst -name b2070 -location {11932.320 11206.048} -status PLACED
place_inst -name b2071 -location {12639.840 12242.848} -status PLACED
place_inst -name b2072 -location {5589.600 11206.048} -status PLACED
place_inst -name b2073 -location {4882.080 12242.848} -status PLACED
place_inst -name b2074 -location {12640.800 9132.448} -status PLACED
place_inst -name b2075 -location {13348.320 10169.248} -status PLACED
place_inst -name b2076 -location {4881.120 9132.448} -status PLACED
place_inst -name b2077 -location {4173.600 10169.248} -status PLACED
place_inst -name b2078 -location {4432.800 1252.832} -status PLACED
place_inst -name r2079_0 -location {3762.635 2281.497} -status PLACED
place_inst -name b2079 -location {3814.288 2334.432} -status PLACED
place_inst -name r2080_0 -location {3694.965 2334.432} -status PLACED
place_inst -name r2080_1 -location {3575.642 2334.432} -status PLACED
place_inst -name b2080 -location {3456.319 2334.432} -status PLACED
place_inst -name r2081_0 -location {3493.552 2283.136} -status PLACED
place_inst -name b2081 -location {3530.784 2231.840} -status PLACED
place_inst -name r2082_0 -location {3440.480 2231.840} -status PLACED
place_inst -name b2082 -location {3350.176 2231.840} -status PLACED
place_inst -name r2083_0 -location {3621.088 2231.840} -status PLACED
place_inst -name b2083 -location {3711.392 2231.840} -status PLACED
place_inst -name r2084_0 -location {3306.613 2334.432} -status PLACED
place_inst -name r2084_1 -location {3156.906 2334.432} -status PLACED
place_inst -name b2084 -location {3007.200 2334.432} -status PLACED
place_inst -name r2085_0 -location {3936.356 2308.784} -status PLACED
place_inst -name r2085_1 -location {4058.424 2283.136} -status PLACED
place_inst -name r2085_2 -location {4180.492 2257.488} -status PLACED
place_inst -name b2085 -location {4302.560 2231.840} -status PLACED
place_inst -name r2086_0 -location {4187.072 2231.840} -status PLACED
place_inst -name b2086 -location {4071.584 2231.840} -status PLACED
place_inst -name r2087_0 -location {4358.560 2172.352} -status PLACED
place_inst -name b2087 -location {4414.560 2112.864} -status PLACED
place_inst -name r2088_0 -location {15262.199 1991.865} -status PLACED
place_inst -name b2088 -location {15142.731 1963.690} -status PLACED
place_inst -name r2089_0 -location {15250.105 1940.347} -status PLACED
place_inst -name r2089_1 -location {15357.478 1917.003} -status PLACED
place_inst -name r2089_2 -location {15464.852 1893.660} -status PLACED
place_inst -name r2089_3 -location {15572.225 1870.316} -status PLACED
place_inst -name b2089 -location {15679.599 1846.973} -status PLACED
place_inst -name b2090 -location {15717.984 1748.194} -status PLACED
place_inst -name r2091_0 -location {15607.168 1762.289} -status PLACED
place_inst -name b2091 -location {15496.352 1776.384} -status PLACED
place_inst -name r2092_0 -location {15467.200 1826.000} -status PLACED
place_inst -name b2092 -location {15438.048 1875.616} -status PLACED
place_inst -name r2093_0 -location {15496.352 1697.616} -status PLACED
place_inst -name b2093 -location {15496.352 1618.848} -status PLACED
place_inst -name r2094_0 -location {15717.984 1620.721} -status PLACED
place_inst -name b2094 -location {15717.984 1493.248} -status PLACED
place_inst -name r2095_0 -location {15715.168 1420.560} -status PLACED
place_inst -name b2095 -location {15712.352 1347.872} -status PLACED
place_inst -name r2096_0 -location {15717.984 1568.752} -status PLACED
place_inst -name b2096 -location {15717.984 1644.256} -status PLACED
place_inst -name r2097_0 -location {15679.599 1971.278} -status PLACED
place_inst -name b2097 -location {15679.599 2095.584} -status PLACED
place_inst -name b2098 -location {15537.408 2095.584} -status PLACED
place_inst -name r2099_0 -location {15459.952 2095.584} -status PLACED
place_inst -name b2099 -location {15382.496 2095.584} -status PLACED
place_inst -name r2100_0 -location {15539.120 2019.840} -status PLACED
place_inst -name b2100 -location {15540.832 1944.096} -status PLACED
place_inst -name r2101_0 -location {15705.879 2014.144} -status PLACED
place_inst -name b2101 -location {15732.160 1932.704} -status PLACED
place_inst -name b2102 -location {15659.488 1924.064} -status PLACED
place_inst -name b2103 -location {15762.848 1983.328} -status PLACED
place_inst -name r2104_0 -location {15139.851 2088.497} -status PLACED
place_inst -name r2104_1 -location {15136.971 2213.305} -status PLACED
place_inst -name b2104 -location {15134.091 2338.112} -status PLACED
place_inst -name r2105_0 -location {15103.157 2263.029} -status PLACED
place_inst -name r2105_1 -location {15072.223 2187.947} -status PLACED
place_inst -name b2105 -location {15041.289 2112.864} -status PLACED
place_inst -name r2106_0 -location {14923.569 2112.864} -status PLACED
place_inst -name r2106_1 -location {14805.848 2112.864} -status PLACED
place_inst -name b2106 -location {14688.128 2112.864} -status PLACED
place_inst -name b2107 -location {14550.240 2112.864} -status PLACED
place_inst -name b2108 -location {14820.832 2118.048} -status PLACED
place_inst -name r2109_0 -location {15059.189 2222.016} -status PLACED
place_inst -name b2109 -location {15077.088 2331.168} -status PLACED
place_inst -name r2110_0 -location {14961.504 2335.488} -status PLACED
place_inst -name b2110 -location {14845.920 2339.808} -status PLACED
place_inst -name r2111_0 -location {15091.808 2225.984} -status PLACED
place_inst -name b2111 -location {15106.528 2120.800} -status PLACED
place_inst -name r2112_0 -location {15273.059 2338.112} -status PLACED
place_inst -name r2112_1 -location {15412.027 2338.112} -status PLACED
place_inst -name b2112 -location {15550.995 2338.112} -status PLACED
place_inst -name r2113_0 -location {15438.649 2335.952} -status PLACED
place_inst -name b2113 -location {15326.304 2333.792} -status PLACED
place_inst -name r2114_0 -location {15246.656 2338.112} -status PLACED
place_inst -name b2114 -location {15167.008 2342.432} -status PLACED
place_inst -name r2115_0 -location {15401.952 2325.472} -status PLACED
place_inst -name b2115 -location {15477.600 2317.152} -status PLACED
place_inst -name r2116_0 -location {15617.154 2302.923} -status PLACED
place_inst -name r2116_1 -location {15683.313 2267.733} -status PLACED
place_inst -name b2116 -location {15749.472 2232.544} -status PLACED
place_inst -name b2117 -location {15662.688 2223.904} -status PLACED
place_inst -name b2118 -location {15765.472 2311.968} -status PLACED
place_inst -name b2119 -location {11932.320 2911.648} -status PLACED
place_inst -name b2120 -location {12639.840 3948.448} -status PLACED
place_inst -name b2121 -location {5589.600 2911.648} -status PLACED
place_inst -name b2122 -location {4882.080 3948.448} -status PLACED
place_inst -name b2123 -location {12640.800 4985.248} -status PLACED
place_inst -name b2124 -location {13348.320 6022.048} -status PLACED
place_inst -name b2125 -location {4881.120 4985.248} -status PLACED
place_inst -name b2126 -location {4173.600 6022.048} -status PLACED
place_inst -name b2127 -location {13349.280 7058.848} -status PLACED
place_inst -name b2128 -location {14056.800 8095.648} -status PLACED
place_inst -name b2129 -location {4172.640 7058.848} -status PLACED
place_inst -name b2130 -location {3465.120 8095.648} -status PLACED
place_inst -name b2131 -location {3689.853 15328.960} -status PLACED
place_inst -name b2132 -location {3546.614 15324.640} -status PLACED
place_inst -name r2133_0 -location {3438.731 15304.122} -status PLACED
place_inst -name r2133_1 -location {3330.848 15283.603} -status PLACED
place_inst -name r2133_2 -location {3222.966 15263.085} -status PLACED
place_inst -name r2133_3 -location {3115.083 15242.566} -status PLACED
place_inst -name b2133 -location {3007.200 15222.048} -status PLACED
place_inst -name r2134_0 -location {3645.716 15324.640} -status PLACED
place_inst -name b2134 -location {3744.817 15324.640} -status PLACED
place_inst -name r2135_0 -location {3613.270 15324.640} -status PLACED
place_inst -name r2135_1 -location {3481.723 15324.640} -status PLACED
place_inst -name b2135 -location {3350.176 15324.640} -status PLACED
place_inst -name b2136 -location {3891.488 15324.640} -status PLACED
place_inst -name r2137_0 -location {3801.440 15324.640} -status PLACED
place_inst -name b2137 -location {3711.392 15324.640} -status PLACED
place_inst -name r2138_0 -location {3981.536 15324.640} -status PLACED
place_inst -name b2138 -location {4071.584 15324.640} -status PLACED
place_inst -name r2139_0 -location {3810.638 15348.069} -status PLACED
place_inst -name r2139_1 -location {3931.422 15367.179} -status PLACED
place_inst -name r2139_2 -location {4052.207 15386.288} -status PLACED
place_inst -name r2139_3 -location {4172.991 15405.397} -status PLACED
place_inst -name r2139_4 -location {4293.776 15424.507} -status PLACED
place_inst -name b2139 -location {4414.560 15443.616} -status PLACED
place_inst -name b2140 -location {4432.800 16303.648} -status PLACED
place_inst -name b2141 -location {15410.079 15577.198} -status PLACED
place_inst -name r2142_0 -location {15516.374 15577.198} -status PLACED
place_inst -name r2142_1 -location {15622.668 15577.198} -status PLACED
place_inst -name b2142 -location {15728.963 15577.198} -status PLACED
place_inst -name r2143_0 -location {15723.426 15697.873} -status PLACED
place_inst -name r2143_1 -location {15717.889 15818.548} -status PLACED
place_inst -name b2143 -location {15712.352 15939.223} -status PLACED
place_inst -name r2144_0 -location {15712.352 16073.915} -status PLACED
place_inst -name b2144 -location {15712.352 16208.608} -status PLACED
place_inst -name b2145 -location {15619.872 15937.632} -status PLACED
place_inst -name b2146 -location {15496.352 15937.632} -status PLACED
place_inst -name b2147 -location {15717.984 15912.224} -status PLACED
place_inst -name b2148 -location {15728.963 15521.761} -status PLACED
place_inst -name r2149_0 -location {15658.834 15532.432} -status PLACED
place_inst -name b2149 -location {15588.704 15543.104} -status PLACED
place_inst -name b2150 -location {15648.557 15612.384} -status PLACED
place_inst -name r2151_0 -location {15705.702 15592.768} -status PLACED
place_inst -name b2151 -location {15762.848 15573.152} -status PLACED
place_inst -name b2152 -location {15610.176 15612.384} -status PLACED
place_inst -name b2153 -location {15540.832 15612.384} -status PLACED
place_inst -name b2154 -location {15659.488 15632.416} -status PLACED
place_inst -name r2155_0 -location {15513.376 15543.104} -status PLACED
place_inst -name b2155 -location {15438.048 15543.104} -status PLACED
place_inst -name b2156 -location {15382.496 15460.896} -status PLACED
place_inst -name b2157 -location {15438.048 15680.864} -status PLACED
place_inst -name r2158_0 -location {15733.283 15380.544} -status PLACED
place_inst -name b2158 -location {15737.603 15239.328} -status PLACED
place_inst -name r2159_0 -location {15607.602 15239.328} -status PLACED
place_inst -name b2159 -location {15477.600 15239.328} -status PLACED
place_inst -name b2160 -location {15758.112 15332.576} -status PLACED
place_inst -name b2161 -location {15662.688 15332.576} -status PLACED
place_inst -name b2162 -location {15765.472 15244.512} -status PLACED
place_inst -name r2163_0 -location {15313.206 15540.485} -status PLACED
place_inst -name r2163_1 -location {15216.333 15503.771} -status PLACED
place_inst -name r2163_2 -location {15119.459 15467.057} -status PLACED
place_inst -name b2163 -location {15022.586 15430.344} -status PLACED
place_inst -name r2164_0 -location {14904.499 15433.662} -status PLACED
place_inst -name r2164_1 -location {14786.413 15436.980} -status PLACED
place_inst -name r2164_2 -location {14668.326 15440.298} -status PLACED
place_inst -name b2164 -location {14550.240 15443.616} -status PLACED
place_inst -name b2165 -location {15022.586 15340.096} -status PLACED
place_inst -name r2166_0 -location {14934.253 15340.096} -status PLACED
place_inst -name b2166 -location {14845.920 15340.096} -status PLACED
place_inst -name b2167 -location {14820.832 15438.432} -status PLACED
place_inst -name b2168 -location {14845.920 15216.672} -status PLACED
place_inst -name r2169_0 -location {15094.797 15347.600} -status PLACED
place_inst -name b2169 -location {15167.008 15355.104} -status PLACED
place_inst -name b2170 -location {15106.528 15435.680} -status PLACED
place_inst -name b2171 -location {15167.008 15214.048} -status PLACED
place_inst -name b2172 -location {11932.320 13279.648} -status PLACED
place_inst -name b2173 -location {12639.840 14316.448} -status PLACED
place_inst -name b2174 -location {5589.600 13279.648} -status PLACED
place_inst -name b2175 -location {4882.080 14316.448} -status PLACED
place_inst -name b2176 -location {12640.800 11206.048} -status PLACED
place_inst -name b2177 -location {13348.320 12242.848} -status PLACED
place_inst -name b2178 -location {4881.120 11206.048} -status PLACED
place_inst -name b2179 -location {4173.600 12242.848} -status PLACED
place_inst -name b2180 -location {13349.280 9132.448} -status PLACED
place_inst -name b2181 -location {14056.800 10169.248} -status PLACED
place_inst -name b2182 -location {4172.640 9132.448} -status PLACED
place_inst -name b2183 -location {3465.120 10169.248} -status PLACED
place_inst -name r2184_0 -location {2221.105 1975.781} -status PLACED
place_inst -name r2184_1 -location {2301.958 1931.522} -status PLACED
place_inst -name r2184_2 -location {2382.811 1887.263} -status PLACED
place_inst -name b2184 -location {2463.664 1843.004} -status PLACED
place_inst -name r2185_0 -location {2359.366 1802.095} -status PLACED
place_inst -name r2185_1 -location {2255.068 1761.187} -status PLACED
place_inst -name r2185_2 -location {2150.769 1720.278} -status PLACED
place_inst -name b2185 -location {2046.471 1679.370} -status PLACED
place_inst -name r2186_0 -location {2052.677 1589.125} -status PLACED
place_inst -name b2186 -location {2058.882 1498.880} -status PLACED
place_inst -name r2187_0 -location {1934.225 1498.880} -status PLACED
place_inst -name b2187 -location {1809.568 1498.880} -status PLACED
place_inst -name r2188_0 -location {1806.752 1571.568} -status PLACED
place_inst -name b2188 -location {1803.936 1644.256} -status PLACED
place_inst -name r2189_0 -location {1809.568 1423.376} -status PLACED
place_inst -name b2189 -location {1809.568 1347.872} -status PLACED
place_inst -name r2190_0 -location {2071.377 1608.480} -status PLACED
place_inst -name b2190 -location {2083.872 1718.080} -status PLACED
place_inst -name r2191_0 -location {2054.720 1668.464} -status PLACED
place_inst -name b2191 -location {2025.568 1618.848} -status PLACED
place_inst -name r2192_0 -location {2083.872 1796.848} -status PLACED
place_inst -name b2192 -location {2083.872 1875.616} -status PLACED
place_inst -name r2193_0 -location {2045.031 1780.689} -status PLACED
place_inst -name r2193_1 -location {2043.591 1882.009} -status PLACED
place_inst -name b2193 -location {2042.151 1983.328} -status PLACED
place_inst -name r2194_0 -location {1941.267 1983.328} -status PLACED
place_inst -name b2194 -location {1840.384 1983.328} -status PLACED
place_inst -name b2195 -location {1759.072 1983.328} -status PLACED
place_inst -name b2196 -location {1862.432 1924.064} -status PLACED
place_inst -name b2197 -location {2136.000 1944.096} -status PLACED
place_inst -name r2198_0 -location {2058.544 1944.096} -status PLACED
place_inst -name b2198 -location {1981.088 1944.096} -status PLACED
place_inst -name r2199_0 -location {2137.712 2019.840} -status PLACED
place_inst -name b2199 -location {2139.424 2095.584} -status PLACED
place_inst -name r2200_0 -location {2463.664 1960.245} -status PLACED
place_inst -name r2200_1 -location {2463.664 2077.486} -status PLACED
place_inst -name r2200_2 -location {2463.664 2194.727} -status PLACED
place_inst -name b2200 -location {2463.664 2311.968} -status PLACED
place_inst -name r2201_0 -location {2332.847 2311.968} -status PLACED
place_inst -name r2201_1 -location {2202.030 2311.968} -status PLACED
place_inst -name b2201 -location {2071.213 2311.968} -status PLACED
place_inst -name r2202_0 -location {1961.543 2311.968} -status PLACED
place_inst -name b2202 -location {1851.872 2311.968} -status PLACED
place_inst -name b2203 -location {1756.448 2311.968} -status PLACED
place_inst -name b2204 -location {1859.232 2223.904} -status PLACED
place_inst -name b2205 -location {2212.256 2317.152} -status PLACED
place_inst -name r2206_0 -location {2128.288 2317.152} -status PLACED
place_inst -name b2206 -location {2044.320 2317.152} -status PLACED
place_inst -name r2207_0 -location {2283.584 2329.792} -status PLACED
place_inst -name b2207 -location {2354.912 2342.432} -status PLACED
place_inst -name r2208_0 -location {2542.264 2251.125} -status PLACED
place_inst -name r2208_1 -location {2620.863 2190.283} -status PLACED
place_inst -name b2208 -location {2699.463 2129.440} -status PLACED
place_inst -name b2209 -location {2655.200 2120.800} -status PLACED
place_inst -name r2210_0 -location {2535.296 2120.800} -status PLACED
place_inst -name b2210 -location {2415.392 2120.800} -status PLACED
place_inst -name r2211_0 -location {2665.600 2230.304} -status PLACED
place_inst -name b2211 -location {2676.000 2339.808} -status PLACED
place_inst -name r2212_0 -location {2769.220 2123.744} -status PLACED
place_inst -name b2212 -location {2838.976 2118.048} -status PLACED
place_inst -name b2213 -location {2701.088 2118.048} -status PLACED
place_inst -name b2214 -location {2971.680 2112.864} -status PLACED
place_inst -name b2215 -location {15974.880 1252.832} -status PLACED
place_inst -name b2216 -location {12640.800 2911.648} -status PLACED
place_inst -name b2217 -location {13348.320 3948.448} -status PLACED
place_inst -name b2218 -location {4881.120 2911.648} -status PLACED
place_inst -name b2219 -location {4173.600 3948.448} -status PLACED
place_inst -name b2220 -location {13349.280 4985.248} -status PLACED
place_inst -name b2221 -location {14056.800 6022.048} -status PLACED
place_inst -name b2222 -location {4172.640 4985.248} -status PLACED
place_inst -name b2223 -location {3465.120 6022.048} -status PLACED
place_inst -name b2224 -location {14057.760 7058.848} -status PLACED
place_inst -name b2225 -location {14765.280 8095.648} -status PLACED
place_inst -name b2226 -location {3464.160 7058.848} -status PLACED
place_inst -name b2227 -location {2756.640 8095.648} -status PLACED
place_inst -name r2228_0 -location {2113.129 15459.249} -status PLACED
place_inst -name r2228_1 -location {2086.005 15382.059} -status PLACED
place_inst -name b2228 -location {2058.882 15304.868} -status PLACED
place_inst -name r2229_0 -location {2160.078 15289.779} -status PLACED
place_inst -name r2229_1 -location {2261.273 15274.690} -status PLACED
place_inst -name r2229_2 -location {2362.468 15259.601} -status PLACED
place_inst -name b2229 -location {2463.664 15244.512} -status PLACED
place_inst -name r2230_0 -location {2332.847 15244.512} -status PLACED
place_inst -name r2230_1 -location {2202.030 15244.512} -status PLACED
place_inst -name b2230 -location {2071.213 15244.512} -status PLACED
place_inst -name r2231_0 -location {1961.543 15244.512} -status PLACED
place_inst -name b2231 -location {1851.872 15244.512} -status PLACED
place_inst -name b2232 -location {1756.448 15244.512} -status PLACED
place_inst -name b2233 -location {1859.232 15332.576} -status PLACED
place_inst -name b2234 -location {2212.256 15239.328} -status PLACED
place_inst -name r2235_0 -location {2128.288 15239.328} -status PLACED
place_inst -name b2235 -location {2044.320 15239.328} -status PLACED
place_inst -name r2236_0 -location {2283.584 15226.688} -status PLACED
place_inst -name b2236 -location {2354.912 15214.048} -status PLACED
place_inst -name r2237_0 -location {2542.264 15305.355} -status PLACED
place_inst -name r2237_1 -location {2620.863 15366.197} -status PLACED
place_inst -name b2237 -location {2699.463 15427.040} -status PLACED
place_inst -name b2238 -location {2655.200 15435.680} -status PLACED
place_inst -name r2239_0 -location {2535.296 15435.680} -status PLACED
place_inst -name b2239 -location {2415.392 15435.680} -status PLACED
place_inst -name r2240_0 -location {2665.600 15326.176} -status PLACED
place_inst -name b2240 -location {2676.000 15216.672} -status PLACED
place_inst -name r2241_0 -location {2769.220 15432.736} -status PLACED
place_inst -name b2241 -location {2838.976 15438.432} -status PLACED
place_inst -name b2242 -location {2701.088 15438.432} -status PLACED
place_inst -name b2243 -location {2971.680 15443.616} -status PLACED
place_inst -name r2244_0 -location {2056.722 15447.922} -status PLACED
place_inst -name r2244_1 -location {2054.562 15590.975} -status PLACED
place_inst -name r2244_2 -location {2052.402 15734.029} -status PLACED
place_inst -name b2244 -location {2050.242 15877.082} -status PLACED
place_inst -name r2245_0 -location {2047.545 15775.772} -status PLACED
place_inst -name r2245_1 -location {2044.848 15674.462} -status PLACED
place_inst -name b2245 -location {2042.151 15573.152} -status PLACED
place_inst -name r2246_0 -location {1941.267 15573.152} -status PLACED
place_inst -name b2246 -location {1840.384 15573.152} -status PLACED
place_inst -name b2247 -location {1759.072 15573.152} -status PLACED
place_inst -name b2248 -location {1862.432 15632.416} -status PLACED
place_inst -name b2249 -location {2136.000 15612.384} -status PLACED
place_inst -name r2250_0 -location {2058.544 15612.384} -status PLACED
place_inst -name b2250 -location {1981.088 15612.384} -status PLACED
place_inst -name r2251_0 -location {2137.712 15536.640} -status PLACED
place_inst -name b2251 -location {2139.424 15460.896} -status PLACED
place_inst -name r2252_0 -location {2054.562 15969.501} -status PLACED
place_inst -name b2252 -location {2058.882 16061.920} -status PLACED
place_inst -name r2253_0 -location {1932.065 16061.920} -status PLACED
place_inst -name b2253 -location {1805.248 16061.920} -status PLACED
place_inst -name r2254_0 -location {1804.592 15987.072} -status PLACED
place_inst -name b2254 -location {1803.936 15912.224} -status PLACED
place_inst -name r2255_0 -location {1807.408 16135.264} -status PLACED
place_inst -name b2255 -location {1809.568 16208.608} -status PLACED
place_inst -name r2256_0 -location {2071.377 15950.160} -status PLACED
place_inst -name b2256 -location {2083.872 15838.400} -status PLACED
place_inst -name r2257_0 -location {2054.720 15888.016} -status PLACED
place_inst -name b2257 -location {2025.568 15937.632} -status PLACED
place_inst -name r2258_0 -location {2083.872 15759.632} -status PLACED
place_inst -name b2258 -location {2083.872 15680.864} -status PLACED
place_inst -name b2259 -location {15974.880 16303.648} -status PLACED
place_inst -name b2260 -location {12640.800 13279.648} -status PLACED
place_inst -name b2261 -location {13348.320 14316.448} -status PLACED
place_inst -name b2262 -location {4881.120 13279.648} -status PLACED
place_inst -name b2263 -location {4173.600 14316.448} -status PLACED
place_inst -name b2264 -location {13349.280 11206.048} -status PLACED
place_inst -name b2265 -location {14056.800 12242.848} -status PLACED
place_inst -name b2266 -location {4172.640 11206.048} -status PLACED
place_inst -name b2267 -location {3465.120 12242.848} -status PLACED
place_inst -name b2268 -location {14057.760 9132.448} -status PLACED
place_inst -name b2269 -location {14765.280 10169.248} -status PLACED
place_inst -name b2270 -location {3464.160 9132.448} -status PLACED
place_inst -name b2271 -location {2756.640 10169.248} -status PLACED
place_inst -name b2272 -location {1547.040 1252.832} -status PLACED
place_inst -name b2273 -location {13349.280 2911.648} -status PLACED
place_inst -name b2274 -location {14056.800 3948.448} -status PLACED
place_inst -name b2275 -location {4172.640 2911.648} -status PLACED
place_inst -name b2276 -location {3465.120 3948.448} -status PLACED
place_inst -name b2277 -location {14057.760 4985.248} -status PLACED
place_inst -name b2278 -location {14765.280 6022.048} -status PLACED
place_inst -name b2279 -location {3464.160 4985.248} -status PLACED
place_inst -name b2280 -location {2756.640 6022.048} -status PLACED
place_inst -name b2281 -location {14766.240 7058.848} -status PLACED
place_inst -name b2282 -location {15473.760 8095.648} -status PLACED
place_inst -name b2283 -location {2755.680 7058.848} -status PLACED
place_inst -name b2284 -location {2048.160 8095.648} -status PLACED
place_inst -name b2285 -location {1547.040 16303.648} -status PLACED
place_inst -name b2286 -location {13349.280 13279.648} -status PLACED
place_inst -name b2287 -location {14056.800 14316.448} -status PLACED
place_inst -name b2288 -location {4172.640 13279.648} -status PLACED
place_inst -name b2289 -location {3465.120 14316.448} -status PLACED
place_inst -name b2290 -location {14057.760 11206.048} -status PLACED
place_inst -name b2291 -location {14765.280 12242.848} -status PLACED
place_inst -name b2292 -location {3464.160 11206.048} -status PLACED
place_inst -name b2293 -location {2756.640 12242.848} -status PLACED
place_inst -name b2294 -location {14766.240 9132.448} -status PLACED
place_inst -name b2295 -location {15473.760 10169.248} -status PLACED
place_inst -name b2296 -location {2755.680 9132.448} -status PLACED
place_inst -name b2297 -location {2048.160 10169.248} -status PLACED
place_inst -name b2298 -location {14057.760 2911.648} -status PLACED
place_inst -name b2299 -location {14765.280 3948.448} -status PLACED
place_inst -name b2300 -location {3464.160 2911.648} -status PLACED
place_inst -name b2301 -location {2756.640 3948.448} -status PLACED
place_inst -name b2302 -location {14766.240 4985.248} -status PLACED
place_inst -name b2303 -location {15473.760 6022.048} -status PLACED
place_inst -name b2304 -location {2755.680 4985.248} -status PLACED
place_inst -name b2305 -location {2048.160 6022.048} -status PLACED
place_inst -name b2306 -location {15474.720 7058.848} -status PLACED
place_inst -name b2307 -location {16182.240 8095.648} -status PLACED
place_inst -name b2308 -location {2047.200 7058.848} -status PLACED
place_inst -name b2309 -location {1339.680 8095.648} -status PLACED
place_inst -name b2310 -location {14057.760 13279.648} -status PLACED
place_inst -name b2311 -location {14765.280 14316.448} -status PLACED
place_inst -name b2312 -location {3464.160 13279.648} -status PLACED
place_inst -name b2313 -location {2756.640 14316.448} -status PLACED
place_inst -name b2314 -location {14766.240 11206.048} -status PLACED
place_inst -name b2315 -location {15473.760 12242.848} -status PLACED
place_inst -name b2316 -location {2755.680 11206.048} -status PLACED
place_inst -name b2317 -location {2048.160 12242.848} -status PLACED
place_inst -name b2318 -location {15474.720 9132.448} -status PLACED
place_inst -name b2319 -location {16182.240 10169.248} -status PLACED
place_inst -name b2320 -location {2047.200 9132.448} -status PLACED
place_inst -name b2321 -location {1339.680 10169.248} -status PLACED
place_inst -name b2322 -location {14766.240 2911.648} -status PLACED
place_inst -name b2323 -location {15473.760 3948.448} -status PLACED
place_inst -name b2324 -location {2755.680 2911.648} -status PLACED
place_inst -name b2325 -location {2048.160 3948.448} -status PLACED
place_inst -name b2326 -location {15474.720 4985.248} -status PLACED
place_inst -name b2327 -location {16182.240 6022.048} -status PLACED
place_inst -name b2328 -location {2047.200 4985.248} -status PLACED
place_inst -name b2329 -location {1339.680 6022.048} -status PLACED
place_inst -name b2330 -location {16183.200 7058.848} -status PLACED
place_inst -name b2331 -location {16890.720 8095.648} -status PLACED
place_inst -name b2332 -location {1338.720 7058.848} -status PLACED
place_inst -name b2333 -location {631.200 8095.648} -status PLACED
place_inst -name b2334 -location {14766.240 13279.648} -status PLACED
place_inst -name b2335 -location {15473.760 14316.448} -status PLACED
place_inst -name b2336 -location {2755.680 13279.648} -status PLACED
place_inst -name b2337 -location {2048.160 14316.448} -status PLACED
place_inst -name b2338 -location {15474.720 11206.048} -status PLACED
place_inst -name b2339 -location {16182.240 12242.848} -status PLACED
place_inst -name b2340 -location {2047.200 11206.048} -status PLACED
place_inst -name b2341 -location {1339.680 12242.848} -status PLACED
place_inst -name b2342 -location {16183.200 9132.448} -status PLACED
place_inst -name b2343 -location {16890.720 10169.248} -status PLACED
place_inst -name b2344 -location {1338.720 9132.448} -status PLACED
place_inst -name b2345 -location {631.200 10169.248} -status PLACED
place_inst -name b2346 -location {15474.720 2911.648} -status PLACED
place_inst -name b2347 -location {16182.240 3948.448} -status PLACED
place_inst -name b2348 -location {2047.200 2911.648} -status PLACED
place_inst -name b2349 -location {1339.680 3948.448} -status PLACED
place_inst -name b2350 -location {16183.200 4985.248} -status PLACED
place_inst -name b2351 -location {16890.720 6022.048} -status PLACED
place_inst -name b2352 -location {1338.720 4985.248} -status PLACED
place_inst -name b2353 -location {631.200 6022.048} -status PLACED
place_inst -name b2354 -location {16891.680 7058.848} -status PLACED
place_inst -name b2355 -location {17329.408 8359.366} -status PLACED
place_inst -name r2356_0 -location {17330.379 8258.404} -status PLACED
place_inst -name r2356_1 -location {17331.349 8157.442} -status PLACED
place_inst -name b2356 -location {17332.320 8056.480} -status PLACED
place_inst -name b2357 -location {17325.088 8503.776} -status PLACED
place_inst -name b2358 -location {17263.200 8587.232} -status PLACED
place_inst -name b2359 -location {17325.088 8358.432} -status PLACED
place_inst -name b2360 -location {630.240 7058.848} -status PLACED
place_inst -name b2361 -location {196.832 8323.723} -status PLACED
place_inst -name b2362 -location {196.832 8203.840} -status PLACED
place_inst -name r2363_0 -location {193.216 8130.160} -status PLACED
place_inst -name b2363 -location {189.600 8056.480} -status PLACED
place_inst -name r2364_0 -location {196.832 8281.136} -status PLACED
place_inst -name b2364 -location {196.832 8358.432} -status PLACED
place_inst -name r2365_0 -location {217.461 8411.559} -status PLACED
place_inst -name r2365_1 -location {238.091 8499.396} -status PLACED
place_inst -name b2365 -location {258.720 8587.232} -status PLACED
place_inst -name b2366 -location {15474.720 13279.648} -status PLACED
place_inst -name b2367 -location {16182.240 14316.448} -status PLACED
place_inst -name b2368 -location {2047.200 13279.648} -status PLACED
place_inst -name b2369 -location {1339.680 14316.448} -status PLACED
place_inst -name b2370 -location {16183.200 11206.048} -status PLACED
place_inst -name b2371 -location {16890.720 12242.848} -status PLACED
place_inst -name b2372 -location {1338.720 11206.048} -status PLACED
place_inst -name b2373 -location {631.200 12242.848} -status PLACED
place_inst -name b2374 -location {16891.680 9132.448} -status PLACED
place_inst -name b2375 -location {17329.408 10432.966} -status PLACED
place_inst -name r2376_0 -location {17330.379 10332.004} -status PLACED
place_inst -name r2376_1 -location {17331.349 10231.042} -status PLACED
place_inst -name b2376 -location {17332.320 10130.080} -status PLACED
place_inst -name b2377 -location {17325.088 10577.376} -status PLACED
place_inst -name b2378 -location {17263.200 10660.832} -status PLACED
place_inst -name b2379 -location {17325.088 10432.032} -status PLACED
place_inst -name b2380 -location {630.240 9132.448} -status PLACED
place_inst -name b2381 -location {192.512 10401.643} -status PLACED
place_inst -name b2382 -location {192.512 10281.760} -status PLACED
place_inst -name r2383_0 -location {191.056 10205.920} -status PLACED
place_inst -name b2383 -location {189.600 10130.080} -status PLACED
place_inst -name r2384_0 -location {194.672 10356.896} -status PLACED
place_inst -name b2384 -location {196.832 10432.032} -status PLACED
place_inst -name r2385_0 -location {214.581 10488.039} -status PLACED
place_inst -name r2385_1 -location {236.651 10574.436} -status PLACED
place_inst -name b2385 -location {258.720 10660.832} -status PLACED
place_inst -name b2386 -location {16183.200 2911.648} -status PLACED
place_inst -name b2387 -location {16890.720 3948.448} -status PLACED
place_inst -name b2388 -location {1338.720 2911.648} -status PLACED
place_inst -name b2389 -location {631.200 3948.448} -status PLACED
place_inst -name b2390 -location {16891.680 4985.248} -status PLACED
place_inst -name b2391 -location {17329.408 6285.766} -status PLACED
place_inst -name r2392_0 -location {17330.379 6184.804} -status PLACED
place_inst -name r2392_1 -location {17331.349 6083.842} -status PLACED
place_inst -name b2392 -location {17332.320 5982.880} -status PLACED
place_inst -name b2393 -location {17325.088 6430.176} -status PLACED
place_inst -name b2394 -location {17263.200 6513.632} -status PLACED
place_inst -name b2395 -location {17325.088 6284.832} -status PLACED
place_inst -name b2396 -location {630.240 4985.248} -status PLACED
place_inst -name b2397 -location {192.512 6254.443} -status PLACED
place_inst -name b2398 -location {192.512 6134.560} -status PLACED
place_inst -name r2399_0 -location {191.056 6058.720} -status PLACED
place_inst -name b2399 -location {189.600 5982.880} -status PLACED
place_inst -name r2400_0 -location {194.672 6209.696} -status PLACED
place_inst -name b2400 -location {196.832 6284.832} -status PLACED
place_inst -name r2401_0 -location {214.581 6340.839} -status PLACED
place_inst -name r2401_1 -location {236.651 6427.236} -status PLACED
place_inst -name b2401 -location {258.720 6513.632} -status PLACED
place_inst -name b2402 -location {17332.320 7712.608} -status PLACED
place_inst -name b2403 -location {189.600 7712.608} -status PLACED
place_inst -name b2404 -location {16183.200 13279.648} -status PLACED
place_inst -name b2405 -location {16890.720 14316.448} -status PLACED
place_inst -name b2406 -location {1338.720 13279.648} -status PLACED
place_inst -name b2407 -location {631.200 14316.448} -status PLACED
place_inst -name b2408 -location {16891.680 11206.048} -status PLACED
place_inst -name b2409 -location {17329.408 12506.566} -status PLACED
place_inst -name r2410_0 -location {17330.379 12405.604} -status PLACED
place_inst -name r2410_1 -location {17331.349 12304.642} -status PLACED
place_inst -name b2410 -location {17332.320 12203.680} -status PLACED
place_inst -name b2411 -location {17325.088 12650.976} -status PLACED
place_inst -name b2412 -location {17263.200 12734.432} -status PLACED
place_inst -name b2413 -location {17325.088 12505.632} -status PLACED
place_inst -name b2414 -location {630.240 11206.048} -status PLACED
place_inst -name b2415 -location {192.512 12475.243} -status PLACED
place_inst -name b2416 -location {192.512 12355.360} -status PLACED
place_inst -name r2417_0 -location {191.056 12279.520} -status PLACED
place_inst -name b2417 -location {189.600 12203.680} -status PLACED
place_inst -name r2418_0 -location {194.672 12430.496} -status PLACED
place_inst -name b2418 -location {196.832 12505.632} -status PLACED
place_inst -name r2419_0 -location {214.581 12561.639} -status PLACED
place_inst -name r2419_1 -location {236.651 12648.036} -status PLACED
place_inst -name b2419 -location {258.720 12734.432} -status PLACED
place_inst -name b2420 -location {17332.320 9786.208} -status PLACED
place_inst -name b2421 -location {189.600 9786.208} -status PLACED
place_inst -name b2422 -location {16891.680 2911.648} -status PLACED
place_inst -name b2423 -location {17329.408 4212.166} -status PLACED
place_inst -name r2424_0 -location {17330.379 4111.204} -status PLACED
place_inst -name r2424_1 -location {17331.349 4010.242} -status PLACED
place_inst -name b2424 -location {17332.320 3909.280} -status PLACED
place_inst -name b2425 -location {17325.088 4356.576} -status PLACED
place_inst -name b2426 -location {17263.200 4440.032} -status PLACED
place_inst -name b2427 -location {17325.088 4211.232} -status PLACED
place_inst -name b2428 -location {630.240 2911.648} -status PLACED
place_inst -name b2429 -location {258.720 4114.635} -status PLACED
place_inst -name b2430 -location {192.512 4060.960} -status PLACED
place_inst -name r2431_0 -location {191.056 3985.120} -status PLACED
place_inst -name b2431 -location {189.600 3909.280} -status PLACED
place_inst -name r2432_0 -location {194.672 4136.096} -status PLACED
place_inst -name b2432 -location {196.832 4211.232} -status PLACED
place_inst -name r2433_0 -location {258.720 4223.101} -status PLACED
place_inst -name r2433_1 -location {258.720 4331.566} -status PLACED
place_inst -name b2433 -location {258.720 4440.032} -status PLACED
place_inst -name b2434 -location {17332.320 5639.008} -status PLACED
place_inst -name b2435 -location {189.600 5639.008} -status PLACED
place_inst -name b2436 -location {16891.680 13279.648} -status PLACED
place_inst -name b2437 -location {17329.408 14580.166} -status PLACED
place_inst -name r2438_0 -location {17330.379 14479.204} -status PLACED
place_inst -name r2438_1 -location {17331.349 14378.242} -status PLACED
place_inst -name b2438 -location {17332.320 14277.280} -status PLACED
place_inst -name b2439 -location {17325.088 14724.576} -status PLACED
place_inst -name b2440 -location {17263.200 14808.032} -status PLACED
place_inst -name b2441 -location {17325.088 14579.232} -status PLACED
place_inst -name b2442 -location {630.240 13279.648} -status PLACED
place_inst -name b2443 -location {258.720 14482.635} -status PLACED
place_inst -name b2444 -location {196.832 14424.640} -status PLACED
place_inst -name r2445_0 -location {193.216 14350.960} -status PLACED
place_inst -name b2445 -location {189.600 14277.280} -status PLACED
place_inst -name r2446_0 -location {196.832 14501.936} -status PLACED
place_inst -name b2446 -location {196.832 14579.232} -status PLACED
place_inst -name r2447_0 -location {258.720 14591.101} -status PLACED
place_inst -name r2447_1 -location {258.720 14699.566} -status PLACED
place_inst -name b2447 -location {258.720 14808.032} -status PLACED
place_inst -name b2448 -location {17332.320 11859.808} -status PLACED
place_inst -name b2449 -location {189.600 11859.808} -status PLACED
place_inst -name b2450 -location {17332.320 3565.408} -status PLACED
place_inst -name b2451 -location {189.600 3565.408} -status PLACED
place_inst -name b2452 -location {17332.320 13933.408} -status PLACED
place_inst -name b2453 -location {189.600 13933.408} -status PLACED
place_inst -name q1312_t_sp3__clk_t22 -location {8856.060 8351.776} -status PLACED
place_inst -name q1317_t_sp3__clk_t19 -location {9201.660 8087.072} -status PLACED
place_inst -name q1319_t_sp3__clk_t18 -location {8852.732 8074.016} -status PLACED
place_inst -name q1324_t_sp3__clk_t26 -location {8787.900 8569.248} -status PLACED
place_inst -name q1326_t_sp3__clk_t30 -location {9183.996 8760.992} -status PLACED
place_inst -name q1328_t_sp3__clk_t28 -location {8855.740 8760.992} -status PLACED
place_inst -name q1329_t_sp3__clk_t29 -location {8992.892 8760.992} -status PLACED
place_inst -name q1339_t_sp3_bw_i_shim__clk_t1 -location {8088.060 7563.168} -status PLACED
place_inst -name q1340_t_sp3_bw_i_shim__clk -location {8419.708 7563.168} -status PLACED
place_inst -name q1344_t_sp3_be_i_shim__clk -location {9434.940 7563.168} -status PLACED
place_inst -name q1346_t_sp3__clk_t12 -location {9340.860 7575.840} -status PLACED
place_inst -name q1348_t_sp3__clk_t8 -location {9108.412 7395.872} -status PLACED
place_inst -name q1349_t_sp3__clk_t9 -location {9249.148 7395.872} -status PLACED
place_inst -name q1353_t_sp3__clk_t15 -location {9205.884 7741.472} -status PLACED
place_inst -name q1355_t_sp3__clk_t14 -location {9005.820 7698.848} -status PLACED
place_inst -name q1356_t_sp3__clk_t16 -location {9005.820 7803.552} -status PLACED
place_inst -name q1358_t_sp3__clk_t11 -location {8992.956 7528.160} -status PLACED
place_inst -name q1359_t_sp3__clk_t13 -location {9096.316 7658.592} -status PLACED
place_inst -name q1361_t_sp3__clk_t10 -location {8787.900 7526.880} -status PLACED
place_inst -name q1362_t_sp3__clk -location {8852.732 7800.288} -status PLACED
place_inst -name q1365_t_sp3__clk_t1 -location {8881.276 6721.952} -status PLACED
place_inst -name q1366_t_sp3__clk_t2 -location {9089.340 6721.952} -status PLACED
place_inst -name q1368_t_sp3__clk_t5 -location {9194.428 7050.272} -status PLACED
place_inst -name q1371_t_sp3__clk_t4 -location {8856.060 6978.464} -status PLACED
place_inst -name q1372_t_sp3__clk_t3 -location {9005.820 6978.464} -status PLACED
place_inst -name q1374_t_sp3__clk_t7 -location {8856.060 7252.960} -status PLACED
place_inst -name q1375_t_sp3__clk_t6 -location {9005.820 7252.960} -status PLACED
place_inst -name q1446_t_sp2_xw_o_shim__clk -location {8420.732 10673.568} -status PLACED
place_inst -name q1447_t_sp2_xw_o_shim__clk_t1 -location {8752.380 10673.568} -status PLACED
place_inst -name q1448_t_sp2_xe_o_shim__clk -location {9375.420 10673.568} -status PLACED
place_inst -name q1452_t_sp4_bw_i_shim__clk_t1 -location {8088.060 5489.568} -status PLACED
place_inst -name q1453_t_sp4_bw_i_shim__clk -location {8419.708 5489.568} -status PLACED
place_inst -name q1457_t_sp4_be_i_shim__clk -location {9434.940 5489.568} -status PLACED
place_inst -name q1463_t_sp4__clk -location {8852.732 5726.688} -status PLACED
place_inst -name q1474_t_sp4__clk_t8 -location {9108.412 5322.272} -status PLACED
place_inst -name q1475_t_sp4__clk_t9 -location {9249.148 5322.272} -status PLACED
place_inst -name q1478_t_sp4__clk_t1 -location {8881.276 4648.352} -status PLACED
place_inst -name q1479_t_sp4__clk_t2 -location {9089.340 4648.352} -status PLACED
place_inst -name q1481_t_sp4__clk_t5 -location {9194.428 4976.672} -status PLACED
place_inst -name q1484_t_sp4__clk_t4 -location {8856.060 4904.864} -status PLACED
place_inst -name q1485_t_sp4__clk_t3 -location {9005.820 4904.864} -status PLACED
place_inst -name q1487_t_sp4__clk_t7 -location {8856.060 5179.360} -status PLACED
place_inst -name q1488_t_sp4__clk_t6 -location {9005.820 5179.360} -status PLACED
place_inst -name q1491_t_sp4_xw_o_shim__clk -location {8420.732 6526.368} -status PLACED
place_inst -name q1492_t_sp4_xw_o_shim__clk_t1 -location {8752.380 6526.368} -status PLACED
place_inst -name q1499_t_sp4__clk_t21 -location {9005.820 6248.352} -status PLACED
place_inst -name q1500_t_sp4__clk_t23 -location {9005.820 6304.288} -status PLACED
place_inst -name q1506_t_sp4__clk_t17 -location {9005.820 5931.552} -status PLACED
place_inst -name q1507_t_sp4__clk_t20 -location {9005.820 6022.176} -status PLACED
place_inst -name q1517_t_sp4_xe_o_shim__clk -location {9375.420 6526.368} -status PLACED
place_inst -name q1518_t_sp4__clk_t27 -location {9340.860 6556.128} -status PLACED
place_inst -name q1520_t_sp4__clk_t24 -location {9165.052 6359.072} -status PLACED
place_inst -name q1521_t_sp4__clk_t25 -location {9302.012 6359.072} -status PLACED
place_inst -name q1567_t_sp1_xw_o_shim__clk -location {8420.732 12747.168} -status PLACED
place_inst -name q1568_t_sp1_xw_o_shim__clk_t1 -location {8752.380 12747.168} -status PLACED
place_inst -name q1572_t_sp1_xe_o_shim__clk -location {9375.420 12747.168} -status PLACED
place_inst -name q1573_t_sp1__clk_t27 -location {9340.860 12776.928} -status PLACED
place_inst -name q1575_t_sp1__clk_t24 -location {9165.052 12579.872} -status PLACED
place_inst -name q1576_t_sp1__clk_t25 -location {9302.012 12579.872} -status PLACED
place_inst -name q1578_t_sp1__clk_t26 -location {8787.900 12716.448} -status PLACED
place_inst -name q1580_t_sp1__clk_t30 -location {9183.996 12908.192} -status PLACED
place_inst -name q1582_t_sp1__clk_t28 -location {8855.740 12908.192} -status PLACED
place_inst -name q1583_t_sp1__clk_t29 -location {8992.892 12908.192} -status PLACED
place_inst -name q1588_t_sp1__clk_t21 -location {9005.820 12469.152} -status PLACED
place_inst -name q1589_t_sp1__clk_t23 -location {9005.820 12525.088} -status PLACED
place_inst -name q1595_t_sp1__clk_t17 -location {9005.820 12152.352} -status PLACED
place_inst -name q1596_t_sp1__clk_t20 -location {9005.820 12242.976} -status PLACED
place_inst -name q1597_t_tE2o0__clk -location {9806.460 10169.248} -status PLACED
place_inst -name q1615_t_sp5__clk_t3 -location {9126.972 3248.672} -status PLACED
place_inst -name q1622_t_sp5__clk_t9 -location {9193.020 3594.272} -status PLACED
place_inst -name q1632_t_sp5__clk_t11 -location {9005.820 3749.728} -status PLACED
place_inst -name q1633_t_sp5__clk_t12 -location {9005.820 3869.088} -status PLACED
place_inst -name q1634_t_sp5__clk_t14 -location {9005.820 4017.952} -status PLACED
place_inst -name q1650_t_sp5__clk_t17 -location {8838.332 4349.728} -status PLACED
place_inst -name q1652_t_sp5__clk_t21 -location {8787.900 4476.064} -status PLACED
place_inst -name q1653_t_sp5__clk_t18 -location {8993.020 4419.872} -status PLACED
place_inst -name q1655_t_sp5__clk_t22 -location {8856.060 4613.792} -status PLACED
place_inst -name q1656_t_sp5__clk_t23 -location {8981.244 4613.792} -status PLACED
place_inst -name q1661_t_tW4o0__clk -location {7716.540 6022.048} -status PLACED
place_inst -name q1677_t_sp0__clk_t15 -location {9205.884 13962.272} -status PLACED
place_inst -name q1678_t_sp0__clk_t12 -location {9340.860 13796.640} -status PLACED
place_inst -name q1684_t_sp0__clk_t10 -location {8787.900 13747.680} -status PLACED
place_inst -name q1686_t_sp0__clk_t11 -location {8992.956 13748.960} -status PLACED
place_inst -name q1687_t_sp0__clk_t13 -location {9096.316 13879.392} -status PLACED
place_inst -name q1689_t_sp0__clk_t14 -location {9005.820 13919.648} -status PLACED
place_inst -name q1690_t_sp0__clk_t16 -location {9005.820 14024.352} -status PLACED
place_inst -name q1710_t_sp0__clk_t22 -location {8856.060 14572.576} -status PLACED
place_inst -name q1715_t_sp0__clk_t19 -location {9201.660 14307.872} -status PLACED
place_inst -name q1717_t_sp0__clk_t18 -location {8852.732 14294.816} -status PLACED
place_inst -name q1723_t_sp0__clk_t27 -location {9340.860 14850.528} -status PLACED
place_inst -name q1725_t_sp0__clk_t24 -location {9165.052 14653.472} -status PLACED
place_inst -name q1726_t_sp0__clk_t25 -location {9302.012 14653.472} -status PLACED
place_inst -name q1728_t_sp0__clk_t26 -location {8787.900 14790.048} -status PLACED
place_inst -name q1730_t_sp0__clk_t30 -location {9183.996 14981.792} -status PLACED
place_inst -name q1732_t_sp0__clk_t28 -location {8855.740 14981.792} -status PLACED
place_inst -name q1733_t_sp0__clk_t29 -location {8992.892 14981.792} -status PLACED
place_inst -name q1736_t_sp0_xw_o_shim__clk -location {8420.732 14820.768} -status PLACED
place_inst -name q1737_t_sp0_xw_o_shim__clk_t1 -location {8752.380 14820.768} -status PLACED
place_inst -name q1738_t_sp0_xe_o_shim__clk -location {9375.420 14820.768} -status PLACED
place_inst -name q1740_t_tW1o0__clk -location {7716.540 12242.848} -status PLACED
place_inst -name q1741_t_tE2b0__clk -location {9807.420 9132.448} -status PLACED
place_inst -name q1742_t_tE2o1__clk -location {10514.940 10169.248} -status PLACED
place_inst -name q1750_t_host__clk_t1 -location {9838.780 1347.872} -status PLACED
place_inst -name q1759_t_host_nstrip__clk_t6 -location {9145.468 2229.152} -status PLACED
place_inst -name q1760_t_host_nstrip__clk_t8 -location {9212.412 2540.192} -status PLACED
place_inst -name q1763_t_host_nstrip__clk_t7 -location {9271.740 2238.048} -status PLACED
place_inst -name q1764_t_host_nstrip__clk -location {9525.628 2117.088} -status PLACED
place_inst -name q1766_t_host_nstrip__clk_t3 -location {9865.148 2117.088} -status PLACED
place_inst -name q1767_t_host_nstrip__clk_t2 -location {10186.620 2104.416} -status PLACED
place_inst -name q1768_t_tE5o0__clk -location {9806.460 3948.448} -status PLACED
place_inst -name q1772_t_tW4b0__clk -location {7715.580 4985.248} -status PLACED
place_inst -name q1773_t_tW4o1__clk -location {7008.060 6022.048} -status PLACED
place_inst -name q1788_t_ctl__clk_t1 -location {8922.812 15016.352} -status PLACED
place_inst -name q1789_t_ctl__clk_t2 -location {9181.052 15016.352} -status PLACED
place_inst -name q1790_t_ctl__clk_t4 -location {9332.220 15404.640} -status PLACED
place_inst -name q1817_t_tE0o0__clk -location {9806.460 14316.448} -status PLACED
place_inst -name q1821_t_tW1b0__clk -location {7715.580 11206.048} -status PLACED
place_inst -name q1822_t_tW1o1__clk -location {7008.060 12242.848} -status PLACED
place_inst -name q1823_t_tE2b1__clk -location {10515.900 9132.448} -status PLACED
place_inst -name q1824_t_tE2o2__clk -location {11223.420 10169.248} -status PLACED
place_inst -name q1827_t_lk_HOST1__clk -location {10203.900 1252.832} -status PLACED
place_inst -name q1854_t_sst7__clk_t1 -location {10222.140 2164.448} -status PLACED
place_inst -name q1855_t_sst7__clk_t2 -location {10496.636 2151.840} -status PLACED
place_inst -name q1856_t_sst7__clk_t5 -location {10788.732 2104.416} -status PLACED
place_inst -name q1861_t_sst7__clk_t4 -location {11629.500 2122.464} -status PLACED
place_inst -name q1862_t_tE5b0__clk -location {9807.420 2911.648} -status PLACED
place_inst -name q1863_t_tE5o1__clk -location {10514.940 3948.448} -status PLACED
place_inst -name q1868_t_tW4b1__clk -location {7007.100 4985.248} -status PLACED
place_inst -name q1869_t_tW4o2__clk -location {6299.580 6022.048} -status PLACED
place_inst -name q1884_t_nst7__clk -location {10926.332 15404.640} -status PLACED
place_inst -name q1885_t_nst7__clk_t3 -location {11286.524 15404.640} -status PLACED
place_inst -name q1887_t_tE0b0__clk -location {9807.420 13279.648} -status PLACED
place_inst -name q1888_t_tE0o1__clk -location {10514.940 14316.448} -status PLACED
place_inst -name q1893_t_tW1b1__clk -location {7007.100 11206.048} -status PLACED
place_inst -name q1894_t_tW1o2__clk -location {6299.580 12242.848} -status PLACED
place_inst -name q1895_t_tE2b2__clk -location {11224.380 9132.448} -status PLACED
place_inst -name q1896_t_tE2o3__clk -location {11931.900 10169.248} -status PLACED
place_inst -name q1899_t_lk_HOST0__clk -location {7319.100 1252.832} -status PLACED
place_inst -name q1914_t_mesh7S_estrip__clk_t1 -location {11665.020 2164.448} -status PLACED
place_inst -name q1915_t_mesh7S_estrip__clk_t2 -location {11926.588 2151.840} -status PLACED
place_inst -name q1917_t_mesh7S_estrip__clk -location {12206.012 2151.840} -status PLACED
place_inst -name q1918_t_mesh7S_estrip__clk_t3 -location {12467.580 2122.464} -status PLACED
place_inst -name q1924_t_tE5b1__clk -location {10515.900 2911.648} -status PLACED
place_inst -name q1925_t_tE5o2__clk -location {11223.420 3948.448} -status PLACED
place_inst -name q1930_t_tW4b2__clk -location {6298.620 4985.248} -status PLACED
place_inst -name q1931_t_tW4o3__clk -location {5591.100 6022.048} -status PLACED
place_inst -name q1945_t_nst4__clk_t8 -location {5893.500 15742.048} -status PLACED
place_inst -name q1946_t_nst4__clk_t9 -location {6236.476 15880.672} -status PLACED
place_inst -name q1958_t_nst4__clk -location {6597.692 15844.640} -status PLACED
place_inst -name q1959_t_nst4__clk_t10 -location {6957.884 15880.672} -status PLACED
place_inst -name q1970_t_mesh7N__clk -location {12503.100 15404.640} -status PLACED
place_inst -name q1971_t_mesh7N__clk_t1 -location {13072.380 15324.640} -status PLACED
place_inst -name q1972_t_mesh7N__clk_t2 -location {12724.540 16208.672} -status PLACED
place_inst -name q1973_t_tE0b1__clk -location {10515.900 13279.648} -status PLACED
place_inst -name q1974_t_tE0o2__clk -location {11223.420 14316.448} -status PLACED
place_inst -name q1979_t_tW1b2__clk -location {6298.620 11206.048} -status PLACED
place_inst -name q1980_t_tW1o3__clk -location {5591.100 12242.848} -status PLACED
place_inst -name q1981_t_tE2b3__clk -location {11932.860 9132.448} -status PLACED
place_inst -name q1982_t_tE2o4__clk -location {12640.380 10169.248} -status PLACED
place_inst -name q1987_t_mesh0S__clk_t2 -location {4798.460 1347.808} -status PLACED
place_inst -name q1989_t_mesh0S__clk_t1 -location {4450.620 2231.840} -status PLACED
place_inst -name q1990_t_mesh0S__clk -location {5019.900 2151.840} -status PLACED
place_inst -name q2000_t_sst9__clk_t4 -location {13107.900 2112.864} -status PLACED
place_inst -name q2004_t_sst9__clk_t3 -location {13450.876 2231.840} -status PLACED
place_inst -name q2005_t_sst9__clk -location {13811.068 2231.840} -status PLACED
place_inst -name q2006_t_sst9__clk_t2 -location {14172.284 2231.840} -status PLACED
place_inst -name q2007_t_sst9__clk_t1 -location {14515.260 2334.432} -status PLACED
place_inst -name q2008_t_tE5b2__clk -location {11224.380 2911.648} -status PLACED
place_inst -name q2009_t_tE5o3__clk -location {11931.900 3948.448} -status PLACED
place_inst -name q2014_t_tW4b3__clk -location {5590.140 4985.248} -status PLACED
place_inst -name q2015_t_tW4o4__clk -location {4882.620 6022.048} -status PLACED
place_inst -name q2022_t_nst3_transit__clk_t1 -location {4450.620 15222.048} -status PLACED
place_inst -name q2024_t_nst3_transit__clk_t2 -location {4793.596 15324.640} -status PLACED
place_inst -name q2026_t_nst3_transit__clk -location {5154.812 15324.640} -status PLACED
place_inst -name q2027_t_nst3_transit__clk_t3 -location {5515.004 15324.640} -status PLACED
place_inst -name q2028_t_nst3_transit__clk_t4 -location {5857.980 15443.616} -status PLACED
place_inst -name q2052_t_nst3_turn__clk_t3 -location {5598.460 15742.048} -status PLACED
place_inst -name q2054_t_nst3_turn__clk_t7 -location {5544.316 15911.136} -status PLACED
place_inst -name q2055_t_nst3_turn__clk_t12 -location {5595.772 16013.920} -status PLACED
place_inst -name q2056_t_lk_EN0__clk -location {13089.660 16303.648} -status PLACED
place_inst -name q2058_t_nst9__clk_t4 -location {13107.900 15443.616} -status PLACED
place_inst -name q2062_t_nst9__clk_t3 -location {13450.876 15324.640} -status PLACED
place_inst -name q2063_t_nst9__clk -location {13811.068 15324.640} -status PLACED
place_inst -name q2064_t_nst9__clk_t2 -location {14172.284 15324.640} -status PLACED
place_inst -name q2065_t_nst9__clk_t1 -location {14515.260 15222.048} -status PLACED
place_inst -name q2066_t_tE0b2__clk -location {11224.380 13279.648} -status PLACED
place_inst -name q2067_t_tE0o3__clk -location {11931.900 14316.448} -status PLACED
place_inst -name q2072_t_tW1b3__clk -location {5590.140 11206.048} -status PLACED
place_inst -name q2073_t_tW1o4__clk -location {4882.620 12242.848} -status PLACED
place_inst -name q2074_t_tE2b4__clk -location {12641.340 9132.448} -status PLACED
place_inst -name q2075_t_tE2o5__clk -location {13348.860 10169.248} -status PLACED
place_inst -name q2078_t_lk_WS0__clk -location {4433.340 1252.832} -status PLACED
place_inst -name q2084_t_sst2__clk_t1 -location {3007.740 2334.432} -status PLACED
place_inst -name q2086_t_sst2__clk_t3 -location {4072.124 2231.840} -status PLACED
place_inst -name q2087_t_sst2__clk_t4 -location {4415.100 2112.864} -status PLACED
place_inst -name q2119_t_tE5b3__clk -location {11932.860 2911.648} -status PLACED
place_inst -name q2120_t_tE5o4__clk -location {12640.380 3948.448} -status PLACED
place_inst -name q2125_t_tW4b4__clk -location {4881.660 4985.248} -status PLACED
place_inst -name q2126_t_tW4o5__clk -location {4174.140 6022.048} -status PLACED
place_inst -name q2133_t_nst2__clk_t1 -location {3007.740 15222.048} -status PLACED
place_inst -name q2135_t_nst2__clk_t2 -location {3350.716 15324.640} -status PLACED
place_inst -name q2137_t_nst2__clk -location {3711.932 15324.640} -status PLACED
place_inst -name q2138_t_nst2__clk_t3 -location {4072.124 15324.640} -status PLACED
place_inst -name q2139_t_nst2__clk_t4 -location {4415.100 15443.616} -status PLACED
place_inst -name q2151_t_nst10__clk_t10 -location {15763.388 15573.152} -status PLACED
place_inst -name q2153_t_nst10__clk_t11 -location {15541.372 15612.384} -status PLACED
place_inst -name q2154_t_nst10__clk_t12 -location {15660.028 15632.416} -status PLACED
place_inst -name q2156_t_nst10__clk_t9 -location {15383.036 15460.896} -status PLACED
place_inst -name q2157_t_nst10__clk -location {15438.588 15680.864} -status PLACED
place_inst -name q2172_t_tE0b3__clk -location {11932.860 13279.648} -status PLACED
place_inst -name q2173_t_tE0o4__clk -location {12640.380 14316.448} -status PLACED
place_inst -name q2178_t_tW1b4__clk -location {4881.660 11206.048} -status PLACED
place_inst -name q2179_t_tW1o5__clk -location {4174.140 12242.848} -status PLACED
place_inst -name q2180_t_tE2b5__clk -location {13349.820 9132.448} -status PLACED
place_inst -name q2181_t_tE2o6__clk -location {14057.340 10169.248} -status PLACED
place_inst -name q2188_t_sst1__clk_t13 -location {1804.476 1644.256} -status PLACED
place_inst -name q2189_t_sst1__clk_t15 -location {1810.108 1347.872} -status PLACED
place_inst -name q2191_t_sst1__clk_t14 -location {2026.108 1618.848} -status PLACED
place_inst -name q2192_t_sst1__clk -location {2084.412 1875.616} -status PLACED
place_inst -name q2195_t_sst1__clk_t10 -location {1759.612 1983.328} -status PLACED
place_inst -name q2196_t_sst1__clk_t12 -location {1862.972 1924.064} -status PLACED
place_inst -name q2198_t_sst1__clk_t11 -location {1981.628 1944.096} -status PLACED
place_inst -name q2199_t_sst1__clk_t9 -location {2139.964 2095.584} -status PLACED
place_inst -name q2203_t_sst1__clk_t4 -location {1756.988 2311.968} -status PLACED
place_inst -name q2204_t_sst1__clk_t5 -location {1859.772 2223.904} -status PLACED
place_inst -name q2206_t_sst1__clk_t3 -location {2044.860 2317.152} -status PLACED
place_inst -name q2207_t_sst1__clk_t1 -location {2355.452 2342.432} -status PLACED
place_inst -name q2210_t_sst1__clk_t6 -location {2415.932 2120.800} -status PLACED
place_inst -name q2211_t_sst1__clk_t2 -location {2676.540 2339.808} -status PLACED
place_inst -name q2213_t_sst1__clk_t7 -location {2701.628 2118.048} -status PLACED
place_inst -name q2214_t_sst1__clk_t8 -location {2972.220 2112.864} -status PLACED
place_inst -name q2215_t_lk_ES1__clk -location {15975.420 1252.832} -status PLACED
place_inst -name q2216_t_tE5b4__clk -location {12641.340 2911.648} -status PLACED
place_inst -name q2217_t_tE5o5__clk -location {13348.860 3948.448} -status PLACED
place_inst -name q2222_t_tW4b5__clk -location {4173.180 4985.248} -status PLACED
place_inst -name q2223_t_tW4o6__clk -location {3465.660 6022.048} -status PLACED
place_inst -name q2232_t_nst1__clk_t4 -location {1756.988 15244.512} -status PLACED
place_inst -name q2233_t_nst1__clk_t5 -location {1859.772 15332.576} -status PLACED
place_inst -name q2235_t_nst1__clk_t3 -location {2044.860 15239.328} -status PLACED
place_inst -name q2236_t_nst1__clk_t1 -location {2355.452 15214.048} -status PLACED
place_inst -name q2239_t_nst1__clk_t6 -location {2415.932 15435.680} -status PLACED
place_inst -name q2240_t_nst1__clk_t2 -location {2676.540 15216.672} -status PLACED
place_inst -name q2242_t_nst1__clk_t7 -location {2701.628 15438.432} -status PLACED
place_inst -name q2243_t_nst1__clk_t8 -location {2972.220 15443.616} -status PLACED
place_inst -name q2247_t_nst1__clk_t10 -location {1759.612 15573.152} -status PLACED
place_inst -name q2248_t_nst1__clk_t12 -location {1862.972 15632.416} -status PLACED
place_inst -name q2250_t_nst1__clk_t11 -location {1981.628 15612.384} -status PLACED
place_inst -name q2251_t_nst1__clk_t9 -location {2139.964 15460.896} -status PLACED
place_inst -name q2254_t_nst1__clk_t13 -location {1804.476 15912.224} -status PLACED
place_inst -name q2255_t_nst1__clk_t15 -location {1810.108 16208.608} -status PLACED
place_inst -name q2257_t_nst1__clk_t14 -location {2026.108 15937.632} -status PLACED
place_inst -name q2258_t_nst1__clk -location {2084.412 15680.864} -status PLACED
place_inst -name q2260_t_tE0b4__clk -location {12641.340 13279.648} -status PLACED
place_inst -name q2261_t_tE0o5__clk -location {13348.860 14316.448} -status PLACED
place_inst -name q2266_t_tW1b5__clk -location {4173.180 11206.048} -status PLACED
place_inst -name q2267_t_tW1o6__clk -location {3465.660 12242.848} -status PLACED
place_inst -name q2268_t_tE2b6__clk -location {14058.300 9132.448} -status PLACED
place_inst -name q2269_t_tE2o7__clk -location {14765.820 10169.248} -status PLACED
place_inst -name q2273_t_tE5b5__clk -location {13349.820 2911.648} -status PLACED
place_inst -name q2274_t_tE5o6__clk -location {14057.340 3948.448} -status PLACED
place_inst -name q2279_t_tW4b6__clk -location {3464.700 4985.248} -status PLACED
place_inst -name q2280_t_tW4o7__clk -location {2757.180 6022.048} -status PLACED
place_inst -name q2285_t_lk_WN2__clk -location {1547.580 16303.648} -status PLACED
place_inst -name q2286_t_tE0b5__clk -location {13349.820 13279.648} -status PLACED
place_inst -name q2287_t_tE0o6__clk -location {14057.340 14316.448} -status PLACED
place_inst -name q2292_t_tW1b6__clk -location {3464.700 11206.048} -status PLACED
place_inst -name q2293_t_tW1o7__clk -location {2757.180 12242.848} -status PLACED
place_inst -name q2294_t_tE2b7__clk -location {14766.780 9132.448} -status PLACED
place_inst -name q2295_t_tE2o8__clk -location {15474.300 10169.248} -status PLACED
place_inst -name q2298_t_tE5b6__clk -location {14058.300 2911.648} -status PLACED
place_inst -name q2299_t_tE5o7__clk -location {14765.820 3948.448} -status PLACED
place_inst -name q2304_t_tW4b7__clk -location {2756.220 4985.248} -status PLACED
place_inst -name q2305_t_tW4o8__clk -location {2048.700 6022.048} -status PLACED
place_inst -name q2310_t_tE0b6__clk -location {14058.300 13279.648} -status PLACED
place_inst -name q2311_t_tE0o7__clk -location {14765.820 14316.448} -status PLACED
place_inst -name q2316_t_tW1b7__clk -location {2756.220 11206.048} -status PLACED
place_inst -name q2317_t_tW1o8__clk -location {2048.700 12242.848} -status PLACED
place_inst -name q2318_t_tE2b8__clk -location {15475.260 9132.448} -status PLACED
place_inst -name q2319_t_tE2o9__clk -location {16182.780 10169.248} -status PLACED
place_inst -name q2322_t_tE5b7__clk -location {14766.780 2911.648} -status PLACED
place_inst -name q2323_t_tE5o8__clk -location {15474.300 3948.448} -status PLACED
place_inst -name q2328_t_tW4b8__clk -location {2047.740 4985.248} -status PLACED
place_inst -name q2329_t_tW4o9__clk -location {1340.220 6022.048} -status PLACED
place_inst -name q2334_t_tE0b7__clk -location {14766.780 13279.648} -status PLACED
place_inst -name q2335_t_tE0o8__clk -location {15474.300 14316.448} -status PLACED
place_inst -name q2340_t_tW1b8__clk -location {2047.740 11206.048} -status PLACED
place_inst -name q2341_t_tW1o9__clk -location {1340.220 12242.848} -status PLACED
place_inst -name q2342_t_tE2b9__clk -location {16183.740 9132.448} -status PLACED
place_inst -name q2343_t_tE2o10__clk -location {16891.260 10169.248} -status PLACED
place_inst -name q2346_t_tE5b8__clk -location {15475.260 2911.648} -status PLACED
place_inst -name q2347_t_tE5o9__clk -location {16182.780 3948.448} -status PLACED
place_inst -name q2352_t_tW4b9__clk -location {1339.260 4985.248} -status PLACED
place_inst -name q2353_t_tW4o10__clk -location {631.740 6022.048} -status PLACED
place_inst -name q2358_t_turnE3a__clk_t2 -location {17263.740 8587.232} -status PLACED
place_inst -name q2359_t_turnE3a__clk -location {17325.628 8358.432} -status PLACED
place_inst -name q2366_t_tE0b8__clk -location {15475.260 13279.648} -status PLACED
place_inst -name q2367_t_tE0o9__clk -location {16182.780 14316.448} -status PLACED
place_inst -name q2372_t_tW1b9__clk -location {1339.260 11206.048} -status PLACED
place_inst -name q2373_t_tW1o10__clk -location {631.740 12242.848} -status PLACED
place_inst -name q2374_t_tE2b10__clk -location {16892.220 9132.448} -status PLACED
place_inst -name q2376_t_turnE2a__clk_t1 -location {17332.860 10130.080} -status PLACED
place_inst -name q2386_t_tE5b9__clk -location {16183.740 2911.648} -status PLACED
place_inst -name q2387_t_tE5o10__clk -location {16891.260 3948.448} -status PLACED
place_inst -name q2394_t_turnE4a__clk_t2 -location {17263.740 6513.632} -status PLACED
place_inst -name q2395_t_turnE4a__clk -location {17325.628 6284.832} -status PLACED
place_inst -name q2396_t_tW4b10__clk -location {630.780 4985.248} -status PLACED
place_inst -name q2399_t_turnW4a__clk_t1 -location {190.140 5982.880} -status PLACED
place_inst -name q2400_t_turnW4a__clk -location {197.372 6284.832} -status PLACED
place_inst -name q2401_t_turnW4a__clk_t2 -location {259.260 6513.632} -status PLACED
place_inst -name q2404_t_tE0b9__clk -location {16183.740 13279.648} -status PLACED
place_inst -name q2405_t_tE0o10__clk -location {16891.260 14316.448} -status PLACED
place_inst -name q2412_t_turnE1a__clk_t2 -location {17263.740 12734.432} -status PLACED
place_inst -name q2413_t_turnE1a__clk -location {17325.628 12505.632} -status PLACED
place_inst -name q2414_t_tW1b10__clk -location {630.780 11206.048} -status PLACED
place_inst -name q2417_t_turnW1a__clk_t1 -location {190.140 12203.680} -status PLACED
place_inst -name q2418_t_turnW1a__clk -location {197.372 12505.632} -status PLACED
place_inst -name q2419_t_turnW1a__clk_t2 -location {259.260 12734.432} -status PLACED
place_inst -name q2420_t_turnE2b__clk -location {17332.860 9786.208} -status PLACED
place_inst -name q2422_t_tE5b10__clk -location {16892.220 2911.648} -status PLACED
place_inst -name q2424_t_turnE5a__clk_t1 -location {17332.860 3909.280} -status PLACED
place_inst -name q2435_t_turnW4b__clk -location {190.140 5639.008} -status PLACED
place_inst -name q2436_t_tE0b10__clk -location {16892.220 13279.648} -status PLACED
place_inst -name q2438_t_turnE0a__clk_t1 -location {17332.860 14277.280} -status PLACED
place_inst -name q2449_t_turnW1b__clk -location {190.140 11859.808} -status PLACED
place_inst -name q2450_t_turnE5b__clk -location {17332.860 3565.408} -status PLACED
place_inst -name q2452_t_turnE0b__clk -location {17332.860 13933.408} -status PLACED
set_wire_rc -signal -resistance 4.335802e-03 -capacitance 1.082436e-01
set_wire_rc -clock -resistance 4.335802e-03 -capacitance 1.082436e-01
estimate_parasitics -placement
create_clock -name vclk -period 833.333
set_driving_cell -lib_cell BUFx24_ASAP7_75t_R -pin Y [get_ports root]
set_input_delay 0 -clock vclk [get_ports root]
set_load 3.0 [all_outputs]
set_output_delay 0 -clock vclk [all_outputs]
set ot_odd [dict create b0 1 b10 1 b1000 1 b1002 1 b1005 1 b1006 1 b1008 1 b101 1 b1010 1 b1013 1 b1014 1 b1015 1 b1017 1 b1019 1 b102 1 b1020 1 b1024 1 b1026 1 b1029 1 b103 1 b1030 1 b1032 1 b1034 1 b1037 1 b1038 1 b1039 1 b1041 1 b1043 1 b1044 1 b1047 1 b1049 1 b105 1 b1051 1 b1052 1 b1056 1 b1058 1 b1061 1 b1062 1 b1063 1 b1065 1 b1067 1 b1068 1 b107 1 b1072 1 b1074 1 b1077 1 b1078 1 b108 1 b1080 1 b1082 1 b1085 1 b1086 1 b1087 1 b1089 1 b1091 1 b1092 1 b1096 1 b1098 1 b1100 1 b1104 1 b1106 1 b1108 1 b1111 1 b1113 1 b1115 1 b1116 1 b112 1 b1120 1 b1122 1 b1125 1 b1126 1 b1128 1 b1130 1 b1133 1 b1134 1 b1135 1 b1137 1 b1139 1 b114 1 b1140 1 b1143 1 b1145 1 b1147 1 b1149 1 b1150 1 b1152 1 b1154 1 b1156 1 b1159 1 b1161 1 b1163 1 b1164 1 b1168 1 b117 1 b1170 1 b1173 1 b1174 1 b1176 1 b1178 1 b118 1 b1180 1 b1183 1 b1185 1 b1187 1 b1189 1 b1190 1 b1191 1 b1192 1 b1194 1 b1195 1 b1196 1 b1198 1 b1199 1 b120 1 b1201 1 b1203 1 b1204 1 b1208 1 b1210 1 b1213 1 b1214 1 b1216 1 b1218 1 b122 1 b1220 1 b1223 1 b1225 1 b1227 1 b1229 1 b1230 1 b1233 1 b1235 1 b1236 1 b1238 1 b1239 1 b1241 1 b1243 1 b1245 1 b1246 1 b1248 1 b125 1 b1250 1 b1252 1 b1255 1 b1256 1 b1258 1 b126 1 b1261 1 b1263 1 b1265 1 b1267 1 b1269 1 b127 1 b1270 1 b1272 1 b1274 1 b1276 1 b1279 1 b1280 1 b1282 1 b1285 1 b1289 1 b1291 1 b1292 1 b1294 1 b1297 1 b1299 1 b13 1 b1300 1 b1302 1 b1308 1 b1312 1 b1313 1 b1316 1 b1317 1 b1319 1 b132 1 b1320 1 b1324 1 b1325 1 b1326 1 b1328 1 b1329 1 b1331 1 b1334 1 b1337 1 b1338 1 b1339 1 b1340 1 b1344 1 b1345 1 b1346 1 b1348 1 b1349 1 b135 1 b1350 1 b1352 1 b1353 1 b1355 1 b1356 1 b1358 1 b1359 1 b1360 1 b1361 1 b1362 1 b1363 1 b1365 1 b1366 1 b1368 1 b1369 1 b137 1 b1371 1 b1372 1 b1374 1 b1375 1 b1376 1 b138 1 b1383 1 b1384 1 b1387 1 b1390 1 b1393 1 b1394 1 b1397 1 b14 1 b140 1 b1401 1 b1402 1 b1405 1 b1408 1 b1409 1 b1415 1 b1417 1 b1418 1 b142 1 b1425 1 b1428 1 b1432 1 b1436 1 b1440 1 b1444 1 b1445 1 b1446 1 b1447 1 b1448 1 b1449 1 b145 1 b1451 1 b1452 1 b1453 1 b1456 1 b1457 1 b146 1 b1461 1 b1463 1 b1464 1 b1467 1 b147 1 b1470 1 b1474 1 b1475 1 b1476 1 b1478 1 b1479 1 b1481 1 b1482 1 b1484 1 b1485 1 b1487 1 b1488 1 b1489 1 b149 1 b1490 1 b1491 1 b1492 1 b1494 1 b1495 1 b1496 1 b1499 1 b1500 1 b1503 1 b1506 1 b1507 1 b1508 1 b151 1 b1512 1 b1515 1 b1517 1 b1518 1 b152 1 b1520 1 b1521 1 b1529 1 b1530 1 b1531 1 b1535 1 b1539 1 b1542 1 b1545 1 b155 1 b1552 1 b1555 1 b1558 1 b1561 1 b1565 1 b1566 1 b1567 1 b1568 1 b1569 1 b157 1 b1570 1 b1572 1 b1573 1 b1575 1 b1576 1 b1578 1 b1579 1 b1580 1 b1582 1 b1583 1 b1584 1 b1585 1 b1588 1 b1589 1 b159 1 b1592 1 b1595 1 b1596 1 b1597 1 b16 1 b160 1 b1600 1 b1605 1 b1610 1 b1613 1 b1615 1 b1616 1 b1619 1 b1622 1 b1623 1 b1630 1 b1632 1 b1633 1 b1634 1 b1637 1 b1639 1 b164 1 b1642 1 b1645 1 b1649 1 b1650 1 b1652 1 b1653 1 b1655 1 b1656 1 b166 1 b1661 1 b1667 1 b1669 1 b1673 1 b1676 1 b1677 1 b1678 1 b1680 1 b1683 1 b1684 1 b1686 1 b1687 1 b1689 1 b169 1 b1690 1 b1691 1 b1695 1 b1698 1 b17 1 b170 1 b1701 1 b1704 1 b171 1 b1710 1 b1711 1 b1714 1 b1715 1 b1717 1 b1718 1 b1721 1 b1722 1 b1723 1 b1725 1 b1726 1 b1728 1 b1729 1 b173 1 b1730 1 b1732 1 b1733 1 b1734 1 b1735 1 b1736 1 b1737 1 b1738 1 b1740 1 b1741 1 b1742 1 b1745 1 b1747 1 b175 1 b1750 1 b1754 1 b1758 1 b1759 1 b176 1 b1760 1 b1762 1 b1763 1 b1764 1 b1765 1 b1766 1 b1767 1 b1768 1 b1772 1 b1773 1 b1778 1 b178 1 b1782 1 b1788 1 b1789 1 b179 1 b1790 1 b1792 1 b1799 1 b18 1 b1803 1 b1809 1 b181 1 b1812 1 b1817 1 b1821 1 b1822 1 b1823 1 b1824 1 b1827 1 b183 1 b1836 1 b1837 1 b1839 1 b1844 1 b1845 1 b1848 1 b185 1 b1851 1 b1854 1 b1855 1 b1856 1 b1861 1 b1862 1 b1863 1 b1868 1 b1869 1 b187 1 b1877 1 b1878 1 b188 1 b1882 1 b1883 1 b1884 1 b1885 1 b1887 1 b1888 1 b1893 1 b1894 1 b1895 1 b1896 1 b1899 1 b1904 1 b1905 1 b1908 1 b1914 1 b1915 1 b1917 1 b1918 1 b1919 1 b192 1 b1921 1 b1924 1 b1925 1 b1930 1 b1931 1 b1937 1 b1938 1 b1939 1 b194 1 b1941 1 b1944 1 b1945 1 b1946 1 b1954 1 b1957 1 b1958 1 b1959 1 b1960 1 b1961 1 b1962 1 b1965 1 b197 1 b1970 1 b1971 1 b1972 1 b1973 1 b1974 1 b1979 1 b198 1 b1980 1 b1981 1 b1982 1 b1985 1 b1987 1 b1989 1 b1990 1 b1991 1 b1992 1 b1995 1 b1999 1 b20 1 b200 1 b2000 1 b2003 1 b2004 1 b2005 1 b2006 1 b2007 1 b2008 1 b2009 1 b2014 1 b2015 1 b202 1 b2020 1 b2022 1 b2024 1 b2025 1 b2026 1 b2027 1 b2028 1 b2029 1 b2034 1 b2038 1 b2043 1 b2046 1 b205 1 b2051 1 b2052 1 b2054 1 b2055 1 b2056 1 b2057 1 b2058 1 b206 1 b2061 1 b2062 1 b2063 1 b2064 1 b2065 1 b2066 1 b2067 1 b207 1 b2072 1 b2073 1 b2074 1 b2075 1 b2078 1 b2079 1 b2084 1 b2085 1 b2086 1 b2087 1 b2089 1 b209 1 b2097 1 b2101 1 b2104 1 b2106 1 b211 1 b2116 1 b2119 1 b212 1 b2120 1 b2125 1 b2126 1 b2131 1 b2133 1 b2135 1 b2136 1 b2137 1 b2138 1 b2139 1 b2142 1 b2145 1 b2150 1 b2151 1 b2153 1 b2154 1 b2156 1 b2157 1 b216 1 b2160 1 b2165 1 b2166 1 b2169 1 b2172 1 b2173 1 b2178 1 b2179 1 b218 1 b2180 1 b2181 1 b2184 1 b2185 1 b2186 1 b2187 1 b2188 1 b2189 1 b2190 1 b2191 1 b2192 1 b2195 1 b2196 1 b2197 1 b2198 1 b2199 1 b2200 1 b2203 1 b2204 1 b2205 1 b2206 1 b2207 1 b2209 1 b221 1 b2210 1 b2211 1 b2213 1 b2214 1 b2215 1 b2216 1 b2217 1 b222 1 b2222 1 b2223 1 b2228 1 b2229 1 b2232 1 b2233 1 b2234 1 b2235 1 b2236 1 b2238 1 b2239 1 b224 1 b2240 1 b2242 1 b2243 1 b2244 1 b2247 1 b2248 1 b2249 1 b2250 1 b2251 1 b2252 1 b2253 1 b2254 1 b2255 1 b2256 1 b2257 1 b2258 1 b226 1 b2260 1 b2261 1 b2266 1 b2267 1 b2268 1 b2269 1 b2273 1 b2274 1 b2279 1 b2280 1 b2285 1 b2286 1 b2287 1 b229 1 b2292 1 b2293 1 b2294 1 b2295 1 b2298 1 b2299 1 b23 1 b230 1 b2304 1 b2305 1 b2310 1 b2311 1 b2316 1 b2317 1 b2318 1 b2319 1 b232 1 b2322 1 b2323 1 b2328 1 b2329 1 b2334 1 b2335 1 b234 1 b2340 1 b2341 1 b2342 1 b2343 1 b2346 1 b2347 1 b2352 1 b2353 1 b2355 1 b2358 1 b2359 1 b236 1 b2361 1 b2366 1 b2367 1 b2372 1 b2373 1 b2374 1 b2376 1 b2377 1 b238 1 b2381 1 b2386 1 b2387 1 b2391 1 b2394 1 b2395 1 b2396 1 b2398 1 b2399 1 b240 1 b2400 1 b2401 1 b2404 1 b2405 1 b2409 1 b2412 1 b2413 1 b2414 1 b2416 1 b2417 1 b2418 1 b2419 1 b242 1 b2420 1 b2422 1 b2424 1 b2425 1 b2429 1 b243 1 b2435 1 b2436 1 b2438 1 b2439 1 b2443 1 b2449 1 b245 1 b2450 1 b2452 1 b247 1 b248 1 b25 1 b252 1 b254 1 b257 1 b258 1 b26 1 b260 1 b262 1 b265 1 b266 1 b267 1 b269 1 b27 1 b271 1 b272 1 b275 1 b277 1 b279 1 b28 1 b280 1 b284 1 b286 1 b289 1 b29 1 b290 1 b293 1 b296 1 b298 1 b30 1 b300 1 b302 1 b303 1 b305 1 b307 1 b308 1 b31 1 b312 1 b314 1 b317 1 b318 1 b320 1 b322 1 b325 1 b326 1 b327 1 b329 1 b33 1 b331 1 b332 1 b336 1 b338 1 b34 1 b341 1 b342 1 b344 1 b346 1 b349 1 b350 1 b352 1 b354 1 b356 1 b358 1 b359 1 b36 1 b361 1 b363 1 b365 1 b367 1 b368 1 b372 1 b374 1 b377 1 b378 1 b380 1 b382 1 b385 1 b386 1 b387 1 b389 1 b391 1 b392 1 b395 1 b397 1 b399 1 b40 1 b400 1 b404 1 b406 1 b409 1 b410 1 b411 1 b413 1 b416 1 b418 1 b42 1 b421 1 b423 1 b425 1 b427 1 b428 1 b432 1 b434 1 b437 1 b438 1 b440 1 b442 1 b445 1 b446 1 b447 1 b449 1 b45 1 b451 1 b452 1 b456 1 b458 1 b46 1 b461 1 b462 1 b464 1 b466 1 b469 1 b470 1 b473 1 b477 1 b479 1 b48 1 b481 1 b483 1 b484 1 b486 1 b487 1 b489 1 b491 1 b492 1 b496 1 b498 1 b50 1 b501 1 b502 1 b504 1 b506 1 b509 1 b510 1 b511 1 b513 1 b515 1 b516 1 b519 1 b521 1 b523 1 b524 1 b528 1 b53 1 b530 1 b533 1 b534 1 b535 1 b537 1 b539 1 b54 1 b540 1 b542 1 b543 1 b547 1 b549 1 b55 1 b551 1 b552 1 b556 1 b558 1 b561 1 b562 1 b564 1 b566 1 b569 1 b570 1 b571 1 b573 1 b575 1 b576 1 b580 1 b582 1 b585 1 b586 1 b588 1 b59 1 b590 1 b593 1 b594 1 b595 1 b597 1 b599 1 b6 1 b602 1 b604 1 b605 1 b606 1 b607 1 b609 1 b61 1 b611 1 b612 1 b616 1 b618 1 b62 1 b621 1 b622 1 b624 1 b626 1 b629 1 b630 1 b631 1 b633 1 b635 1 b636 1 b639 1 b64 1 b641 1 b643 1 b644 1 b648 1 b650 1 b653 1 b654 1 b656 1 b657 1 b658 1 b660 1 b661 1 b663 1 b665 1 b667 1 b668 1 b67 1 b672 1 b674 1 b677 1 b678 1 b680 1 b682 1 b685 1 b686 1 b687 1 b689 1 b69 1 b691 1 b692 1 b696 1 b698 1 b7 1 b701 1 b702 1 b704 1 b706 1 b709 1 b71 1 b710 1 b711 1 b715 1 b718 1 b719 1 b72 1 b721 1 b723 1 b724 1 b728 1 b730 1 b733 1 b734 1 b736 1 b738 1 b741 1 b742 1 b743 1 b745 1 b747 1 b748 1 b751 1 b753 1 b755 1 b756 1 b76 1 b760 1 b762 1 b765 1 b766 1 b767 1 b770 1 b771 1 b773 1 b775 1 b776 1 b78 1 b780 1 b782 1 b785 1 b786 1 b788 1 b790 1 b793 1 b794 1 b795 1 b797 1 b799 1 b800 1 b804 1 b806 1 b809 1 b81 1 b810 1 b812 1 b814 1 b817 1 b818 1 b82 1 b820 1 b821 1 b823 1 b825 1 b827 1 b828 1 b832 1 b834 1 b837 1 b838 1 b84 1 b840 1 b842 1 b845 1 b846 1 b847 1 b849 1 b85 1 b851 1 b852 1 b855 1 b857 1 b859 1 b86 1 b860 1 b864 1 b866 1 b869 1 b87 1 b870 1 b871 1 b873 1 b875 1 b876 1 b88 1 b880 1 b882 1 b885 1 b886 1 b888 1 b890 1 b893 1 b894 1 b895 1 b897 1 b899 1 b9 1 b900 1 b904 1 b906 1 b909 1 b910 1 b912 1 b914 1 b917 1 b918 1 b919 1 b921 1 b923 1 b924 1 b928 1 b93 1 b930 1 b933 1 b934 1 b936 1 b938 1 b94 1 b941 1 b942 1 b943 1 b945 1 b947 1 b948 1 b951 1 b953 1 b955 1 b956 1 b96 1 b960 1 b962 1 b965 1 b966 1 b967 1 b969 1 b971 1 b972 1 b976 1 b978 1 b98 1 b981 1 b982 1 b984 1 b986 1 b989 1 b990 1 b991 1 b993 1 b995 1 b996 1 r1000_0 1 r1002_0 1 r1002_2 1 r1003_1 1 r1004_0 1 r1005_0 1 r1005_2 1 r1008_0 1 r100_0 1 r1010_0 1 r1010_2 1 r1011_1 1 r1012_0 1 r1013_0 1 r1013_2 1 r1016_1 1 r1018_1 1 r1018_3 1 r1019_0 1 r101_0 1 r101_2 1 r1021_1 1 r1021_3 1 r1022_0 1 r1024_0 1 r1026_0 1 r1026_2 1 r1027_1 1 r1028_0 1 r1029_0 1 r1029_2 1 r1032_0 1 r1034_0 1 r1034_2 1 r1035_1 1 r1036_0 1 r1037_0 1 r1037_2 1 r1040_1 1 r1042_1 1 r1042_3 1 r1043_0 1 r1045_1 1 r1045_3 1 r1046_0 1 r1048_1 1 r104_1 1 r1050_1 1 r1050_3 1 r1051_0 1 r1053_1 1 r1053_3 1 r1054_0 1 r1056_0 1 r1058_0 1 r1058_2 1 r1059_1 1 r1060_0 1 r1061_0 1 r1061_2 1 r1064_1 1 r1066_1 1 r1066_3 1 r1067_0 1 r1069_1 1 r1069_3 1 r106_1 1 r106_3 1 r1070_0 1 r1072_0 1 r1074_0 1 r1074_2 1 r1075_1 1 r1076_0 1 r1077_0 1 r1077_2 1 r107_0 1 r1080_0 1 r1082_0 1 r1082_2 1 r1083_1 1 r1084_0 1 r1085_0 1 r1085_2 1 r1088_1 1 r1090_1 1 r1090_3 1 r1091_0 1 r1093_1 1 r1093_3 1 r1094_0 1 r1096_0 1 r1098_0 1 r1098_2 1 r1099_1 1 r109_1 1 r109_3 1 r1102_0 1 r1104_0 1 r1106_0 1 r1106_2 1 r1107_1 1 r110_0 1 r1110_0 1 r1112_1 1 r1114_1 1 r1114_3 1 r1115_0 1 r1117_1 1 r1117_3 1 r1118_0 1 r1120_0 1 r1122_0 1 r1122_2 1 r1123_1 1 r1124_0 1 r1125_0 1 r1125_2 1 r1128_0 1 r112_0 1 r1130_0 1 r1130_2 1 r1131_1 1 r1132_0 1 r1133_0 1 r1133_2 1 r1136_1 1 r1138_1 1 r1138_3 1 r1139_0 1 r1141_1 1 r1141_3 1 r1142_0 1 r1144_1 1 r1146_1 1 r1146_3 1 r1147_0 1 r114_0 1 r114_2 1 r1152_0 1 r1154_0 1 r1154_2 1 r1155_1 1 r1158_0 1 r115_1 1 r1160_1 1 r1162_1 1 r1162_3 1 r1163_0 1 r1165_1 1 r1165_3 1 r1166_0 1 r1168_0 1 r116_0 1 r1170_0 1 r1170_2 1 r1171_1 1 r1172_0 1 r1173_0 1 r1173_2 1 r1176_0 1 r1178_0 1 r1178_2 1 r1179_1 1 r117_0 1 r117_2 1 r1182_0 1 r1184_1 1 r1186_1 1 r1186_3 1 r1187_0 1 r1192_1 1 r1196_1 1 r11_1 1 r11_3 1 r1200_1 1 r1202_1 1 r1202_3 1 r1203_0 1 r1205_1 1 r1205_3 1 r1206_0 1 r1208_0 1 r120_0 1 r1210_0 1 r1210_2 1 r1211_1 1 r1212_0 1 r1213_0 1 r1213_2 1 r1216_0 1 r1218_0 1 r1218_2 1 r1219_1 1 r1222_0 1 r1224_1 1 r1226_1 1 r1226_3 1 r1227_0 1 r122_0 1 r122_2 1 r1232_0 1 r1232_2 1 r1236_1 1 r123_1 1 r1240_1 1 r1242_1 1 r1242_3 1 r1243_0 1 r1248_0 1 r124_0 1 r1250_0 1 r1250_2 1 r1251_1 1 r1254_0 1 r1256_1 1 r125_0 1 r125_2 1 r1260_0 1 r1260_2 1 r1264_1 1 r1266_1 1 r1266_3 1 r1267_0 1 r1272_0 1 r1274_0 1 r1274_2 1 r1275_1 1 r1278_0 1 r1280_1 1 r1284_0 1 r1284_2 1 r1288_0 1 r1288_2 1 r128_1 1 r128_3 1 r128_5 1 r1292_1 1 r1296_0 1 r1296_2 1 r129_0 1 r12_0 1 r12_2 1 r1300_1 1 r1303_1 1 r1304_0 1 r1304_2 1 r1305_0 1 r1305_2 1 r1306_0 1 r1307_0 1 r130_0 1 r130_2 1 r1310_0 1 r1311_0 1 r131_0 1 r131_2 1 r1323_0 1 r1324_0 1 r132_0 1 r1330_1 1 r1337_0 1 r1338_1 1 r1338_3 1 r133_1 1 r133_3 1 r1342_0 1 r1343_0 1 r1344_0 1 r134_0 1 r1357_0 1 r135_0 1 r135_2 1 r135_4 1 r1363_0 1 r1364_1 1 r1368_0 1 r136_1 1 r1376_0 1 r1378_0 1 r1379_0 1 r1379_2 1 r1379_4 1 r1379_6 1 r137_0 1 r137_2 1 r1380_0 1 r1381_0 1 r1382_0 1 r1383_0 1 r1386_0 1 r13_0 1 r13_2 1 r1400_0 1 r1401_0 1 r1408_0 1 r140_0 1 r1413_0 1 r1414_0 1 r1415_0 1 r1415_2 1 r1416_1 1 r1422_0 1 r1423_0 1 r1424_0 1 r142_0 1 r142_2 1 r1431_1 1 r1434_0 1 r1435_0 1 r1439_0 1 r143_1 1 r1443_0 1 r1444_1 1 r1444_3 1 r1444_5 1 r1448_1 1 r144_0 1 r1450_1 1 r1451_0 1 r1451_2 1 r1451_4 1 r1454_0 1 r1455_0 1 r1456_0 1 r1459_0 1 r145_0 1 r145_2 1 r1460_0 1 r1463_0 1 r1466_0 1 r1473_1 1 r1476_0 1 r1477_1 1 r1481_0 1 r1489_1 1 r1489_3 1 r148_1 1 r1490_1 1 r1502_0 1 r1509_1 1 r150_1 1 r150_3 1 r1511_0 1 r1515_0 1 r151_0 1 r1525_0 1 r1525_2 1 r1526_0 1 r1526_2 1 r1526_4 1 r1527_0 1 r1528_0 1 r1532_1 1 r1534_0 1 r153_1 1 r153_3 1 r1541_0 1 r1548_0 1 r1549_0 1 r154_0 1 r1550_0 1 r1551_1 1 r1552_0 1 r1556_1 1 r1564_0 1 r1564_2 1 r1564_4 1 r1566_1 1 r156_1 1 r1578_0 1 r1584_0 1 r158_1 1 r158_3 1 r1591_0 1 r1599_1 1 r159_0 1 r15_0 1 r1601_1 1 r1602_0 1 r1602_2 1 r1602_4 1 r1603_0 1 r1604_0 1 r1607_0 1 r1608_0 1 r1609_0 1 r1615_0 1 r1618_0 1 r161_1 1 r161_3 1 r1626_0 1 r1626_2 1 r1627_0 1 r1628_0 1 r1629_1 1 r1629_3 1 r162_0 1 r1635_0 1 r1636_1 1 r1636_3 1 r1636_5 1 r1648_0 1 r164_0 1 r1654_0 1 r1657_0 1 r1657_2 1 r1657_4 1 r1657_6 1 r1657_8 1 r1658_0 1 r1659_0 1 r1666_0 1 r1668_1 1 r166_0 1 r166_2 1 r1670_1 1 r1670_3 1 r1671_0 1 r1672_0 1 r1674_1 1 r1675_0 1 r167_1 1 r1681_1 1 r1688_0 1 r168_0 1 r1691_0 1 r1694_0 1 r1694_2 1 r1695_0 1 r1699_1 1 r169_0 1 r169_2 1 r16_0 1 r16_2 1 r16_4 1 r1707_1 1 r1707_3 1 r1708_0 1 r1709_0 1 r1728_0 1 r172_1 1 r172_3 1 r1734_0 1 r1734_2 1 r1734_4 1 r1738_1 1 r173_0 1 r173_2 1 r1746_1 1 r1747_0 1 r1748_1 1 r1749_1 1 r1750_0 1 r1750_2 1 r1752_0 1 r1753_0 1 r1757_0 1 r1758_0 1 r175_1 1 r1761_0 1 r1762_0 1 r1765_0 1 r1778_0 1 r1779_1 1 r177_1 1 r177_3 1 r1780_0 1 r1781_0 1 r1781_2 1 r1785_0 1 r1786_0 1 r1787_0 1 r1790_0 1 r1791_0 1 r1791_2 1 r1792_0 1 r1795_0 1 r1796_0 1 r1797_0 1 r1798_1 1 r1799_0 1 r179_1 1 r179_3 1 r1800_1 1 r1801_0 1 r1802_0 1 r1804_1 1 r1806_0 1 r1807_0 1 r1808_0 1 r1808_2 1 r1811_0 1 r1815_1 1 r1816_0 1 r1816_2 1 r181_0 1 r181_2 1 r1829_0 1 r1829_2 1 r1830_0 1 r1831_0 1 r1832_0 1 r1833_0 1 r1834_0 1 r1835_0 1 r1837_1 1 r1838_1 1 r1842_1 1 r1843_0 1 r1843_2 1 r184_1 1 r1852_1 1 r1853_0 1 r1856_0 1 r1857_1 1 r1858_0 1 r1859_0 1 r1860_0 1 r1861_0 1 r186_1 1 r186_3 1 r1877_0 1 r187_0 1 r1881_1 1 r1882_0 1 r1886_1 1 r189_1 1 r189_3 1 r18_1 1 r18_3 1 r18_5 1 r1901_0 1 r1901_2 1 r1902_0 1 r1903_0 1 r1904_0 1 r190_0 1 r1911_1 1 r1912_0 1 r1912_2 1 r1913_0 1 r1916_0 1 r1919_0 1 r1920_1 1 r1920_3 1 r1922_1 1 r1923_1 1 r192_0 1 r1938_1 1 r1940_1 1 r1947_1 1 r1948_0 1 r1948_2 1 r1949_0 1 r194_0 1 r194_2 1 r1950_0 1 r1951_0 1 r1952_0 1 r1953_0 1 r1957_0 1 r195_1 1 r1960_0 1 r1961_1 1 r1968_1 1 r1969_0 1 r196_0 1 r1970_0 1 r1971_0 1 r1972_0 1 r1972_2 1 r197_0 1 r197_2 1 r1986_1 1 r1987_0 1 r1987_2 1 r1988_0 1 r1989_0 1 r1990_0 1 r1991_1 1 r19_0 1 r19_2 1 r1_1 1 r1_3 1 r1_5 1 r2000_1 1 r2000_3 1 r2002_0 1 r2006_0 1 r2007_0 1 r2007_2 1 r200_0 1 r2022_0 1 r2022_2 1 r2023_0 1 r2024_0 1 r2028_1 1 r2028_3 1 r202_0 1 r202_2 1 r2030_1 1 r2031_0 1 r2032_0 1 r2033_0 1 r2035_1 1 r2037_0 1 r203_1 1 r2041_1 1 r2042_0 1 r2049_0 1 r204_0 1 r2050_0 1 r2058_1 1 r2058_3 1 r205_0 1 r205_2 1 r2060_0 1 r2064_0 1 r2065_0 1 r2065_2 1 r2080_1 1 r2081_0 1 r2082_0 1 r2083_0 1 r2084_0 1 r2085_1 1 r2088_0 1 r2089_0 1 r2089_2 1 r208_1 1 r2091_0 1 r2092_0 1 r2093_0 1 r2094_0 1 r2095_0 1 r2096_0 1 r2099_0 1 r20_0 1 r2100_0 1 r2104_0 1 r2105_1 1 r2106_0 1 r2109_0 1 r210_1 1 r210_3 1 r2110_0 1 r2111_0 1 r2112_1 1 r2113_0 1 r2114_0 1 r2115_0 1 r2116_0 1 r211_0 1 r2133_0 1 r2133_2 1 r2134_0 1 r2135_0 1 r2139_1 1 r2139_3 1 r213_1 1 r213_3 1 r2142_0 1 r2143_1 1 r2144_0 1 r2149_0 1 r214_0 1 r2155_0 1 r2158_0 1 r2159_0 1 r2163_0 1 r2163_2 1 r2164_0 1 r2164_2 1 r216_0 1 r2184_1 1 r2185_1 1 r218_0 1 r218_2 1 r2193_1 1 r2194_0 1 r219_1 1 r21_1 1 r21_3 1 r2200_1 1 r2201_1 1 r2202_0 1 r2208_1 1 r220_0 1 r2212_0 1 r221_0 1 r221_2 1 r2228_0 1 r2229_1 1 r2230_1 1 r2231_0 1 r2237_1 1 r2241_0 1 r2244_1 1 r2245_1 1 r2246_0 1 r224_0 1 r226_0 1 r226_2 1 r227_1 1 r228_0 1 r229_0 1 r229_2 1 r22_0 1 r231_0 1 r231_2 1 r233_1 1 r233_3 1 r2356_1 1 r235_0 1 r2363_0 1 r2364_0 1 r2365_1 1 r236_0 1 r236_2 1 r2376_0 1 r237_1 1 r237_3 1 r2383_0 1 r2384_0 1 r2385_1 1 r2392_1 1 r239_0 1 r239_2 1 r239_4 1 r23_0 1 r23_2 1 r23_4 1 r2401_0 1 r2410_1 1 r2419_0 1 r241_1 1 r241_3 1 r2424_0 1 r2431_0 1 r2432_0 1 r2433_1 1 r2438_0 1 r2445_0 1 r2446_0 1 r2447_1 1 r244_1 1 r246_1 1 r246_3 1 r247_0 1 r249_1 1 r249_3 1 r24_1 1 r250_0 1 r252_0 1 r254_0 1 r254_2 1 r255_1 1 r256_0 1 r257_0 1 r257_2 1 r25_0 1 r25_2 1 r260_0 1 r262_0 1 r262_2 1 r263_1 1 r264_0 1 r265_0 1 r265_2 1 r268_1 1 r270_1 1 r270_3 1 r271_0 1 r273_1 1 r273_3 1 r274_0 1 r276_1 1 r278_1 1 r278_3 1 r279_0 1 r281_1 1 r281_3 1 r282_0 1 r284_0 1 r286_0 1 r286_2 1 r287_1 1 r288_0 1 r289_0 1 r289_2 1 r28_1 1 r28_3 1 r28_5 1 r292_0 1 r292_2 1 r293_0 1 r293_2 1 r295_1 1 r295_3 1 r296_0 1 r297_1 1 r297_3 1 r299_0 1 r299_2 1 r299_4 1 r2_0 1 r301_1 1 r301_3 1 r304_1 1 r306_1 1 r306_3 1 r307_0 1 r309_1 1 r309_3 1 r30_1 1 r30_3 1 r310_0 1 r312_0 1 r314_0 1 r314_2 1 r315_1 1 r316_0 1 r317_0 1 r317_2 1 r31_1 1 r320_0 1 r322_0 1 r322_2 1 r323_1 1 r324_0 1 r325_0 1 r325_2 1 r328_1 1 r32_1 1 r330_1 1 r330_3 1 r331_0 1 r333_1 1 r333_3 1 r334_0 1 r336_0 1 r338_0 1 r338_2 1 r339_1 1 r33_0 1 r33_2 1 r340_0 1 r341_0 1 r341_2 1 r344_0 1 r346_0 1 r346_2 1 r347_1 1 r348_0 1 r349_0 1 r349_2 1 r352_0 1 r352_2 1 r352_4 1 r353_1 1 r353_3 1 r355_1 1 r355_3 1 r357_1 1 r357_3 1 r359_1 1 r359_3 1 r35_1 1 r35_3 1 r35_5 1 r361_0 1 r361_2 1 r364_1 1 r366_1 1 r366_3 1 r367_0 1 r369_1 1 r369_3 1 r36_0 1 r370_0 1 r372_0 1 r374_0 1 r374_2 1 r375_1 1 r376_0 1 r377_0 1 r377_2 1 r37_1 1 r37_3 1 r380_0 1 r382_0 1 r382_2 1 r383_1 1 r384_0 1 r385_0 1 r385_2 1 r388_1 1 r38_0 1 r390_1 1 r390_3 1 r391_0 1 r393_1 1 r393_3 1 r394_0 1 r396_1 1 r398_1 1 r398_3 1 r399_0 1 r3_0 1 r3_2 1 r3_4 1 r3_6 1 r401_1 1 r401_3 1 r402_0 1 r404_0 1 r406_0 1 r406_2 1 r407_1 1 r408_0 1 r409_0 1 r409_2 1 r40_0 1 r411_1 1 r411_3 1 r413_0 1 r413_2 1 r416_0 1 r416_2 1 r417_1 1 r417_3 1 r419_1 1 r419_3 1 r420_0 1 r421_0 1 r421_2 1 r424_1 1 r426_1 1 r426_3 1 r427_0 1 r429_1 1 r429_3 1 r42_0 1 r42_2 1 r430_0 1 r432_0 1 r434_0 1 r434_2 1 r435_1 1 r436_0 1 r437_0 1 r437_2 1 r43_1 1 r440_0 1 r442_0 1 r442_2 1 r443_1 1 r444_0 1 r445_0 1 r445_2 1 r448_1 1 r44_0 1 r450_1 1 r450_3 1 r451_0 1 r453_1 1 r453_3 1 r454_0 1 r456_0 1 r458_0 1 r458_2 1 r459_1 1 r45_0 1 r45_2 1 r460_0 1 r461_0 1 r461_2 1 r464_0 1 r466_0 1 r466_2 1 r467_1 1 r468_0 1 r469_0 1 r469_2 1 r471_1 1 r471_3 1 r472_0 1 r473_0 1 r473_2 1 r475_1 1 r475_3 1 r476_0 1 r477_0 1 r477_2 1 r480_1 1 r480_3 1 r481_0 1 r481_2 1 r483_0 1 r483_2 1 r485_1 1 r485_3 1 r488_1 1 r48_0 1 r490_1 1 r490_3 1 r491_0 1 r493_1 1 r493_3 1 r494_0 1 r496_0 1 r498_0 1 r498_2 1 r499_1 1 r4_1 1 r4_3 1 r4_5 1 r500_0 1 r501_0 1 r501_2 1 r504_0 1 r506_0 1 r506_2 1 r507_1 1 r508_0 1 r509_0 1 r509_2 1 r50_0 1 r50_2 1 r512_1 1 r514_1 1 r514_3 1 r515_0 1 r517_1 1 r517_3 1 r518_0 1 r51_1 1 r520_1 1 r522_1 1 r522_3 1 r523_0 1 r525_1 1 r525_3 1 r526_0 1 r528_0 1 r52_0 1 r530_0 1 r530_2 1 r531_1 1 r532_0 1 r533_0 1 r533_2 1 r536_1 1 r536_3 1 r537_0 1 r537_2 1 r539_0 1 r539_2 1 r53_0 1 r53_2 1 r541_1 1 r541_3 1 r543_0 1 r543_2 1 r545_0 1 r545_2 1 r545_4 1 r546_0 1 r548_1 1 r550_1 1 r550_3 1 r551_0 1 r553_1 1 r553_3 1 r554_0 1 r556_0 1 r558_0 1 r558_2 1 r559_1 1 r560_0 1 r561_0 1 r561_2 1 r564_0 1 r566_0 1 r566_2 1 r567_1 1 r568_0 1 r569_0 1 r569_2 1 r56_1 1 r56_3 1 r56_5 1 r572_1 1 r574_1 1 r574_3 1 r575_0 1 r577_1 1 r577_3 1 r578_0 1 r57_0 1 r580_0 1 r582_0 1 r582_2 1 r583_1 1 r584_0 1 r585_0 1 r585_2 1 r588_0 1 r58_0 1 r58_2 1 r58_4 1 r58_6 1 r590_0 1 r590_2 1 r591_1 1 r592_0 1 r593_0 1 r593_2 1 r595_0 1 r595_2 1 r597_0 1 r597_2 1 r59_1 1 r5_0 1 r600_1 1 r601_0 1 r601_2 1 r601_4 1 r603_1 1 r603_3 1 r605_1 1 r605_3 1 r608_1 1 r60_1 1 r610_1 1 r610_3 1 r611_0 1 r613_1 1 r613_3 1 r614_0 1 r616_0 1 r618_0 1 r618_2 1 r619_1 1 r61_0 1 r61_2 1 r620_0 1 r621_0 1 r621_2 1 r624_0 1 r626_0 1 r626_2 1 r627_1 1 r628_0 1 r629_0 1 r629_2 1 r632_1 1 r634_1 1 r634_3 1 r635_0 1 r637_1 1 r637_3 1 r638_0 1 r63_1 1 r63_3 1 r63_5 1 r640_1 1 r642_1 1 r642_3 1 r643_0 1 r645_1 1 r645_3 1 r646_0 1 r648_0 1 r64_0 1 r650_0 1 r650_2 1 r651_1 1 r652_0 1 r653_0 1 r653_2 1 r655_1 1 r655_3 1 r657_1 1 r657_3 1 r659_0 1 r65_1 1 r65_3 1 r660_0 1 r660_2 1 r661_1 1 r661_3 1 r664_1 1 r666_1 1 r666_3 1 r667_0 1 r669_1 1 r669_3 1 r66_0 1 r670_0 1 r672_0 1 r674_0 1 r674_2 1 r675_1 1 r676_0 1 r677_0 1 r677_2 1 r680_0 1 r682_0 1 r682_2 1 r683_1 1 r684_0 1 r685_0 1 r685_2 1 r688_1 1 r68_1 1 r690_1 1 r690_3 1 r691_0 1 r693_1 1 r693_3 1 r694_0 1 r696_0 1 r698_0 1 r698_2 1 r699_1 1 r6_0 1 r6_2 1 r6_4 1 r700_0 1 r701_0 1 r701_2 1 r704_0 1 r706_0 1 r706_2 1 r707_1 1 r708_0 1 r709_0 1 r709_2 1 r70_1 1 r70_3 1 r711_0 1 r711_2 1 r713_0 1 r713_2 1 r713_4 1 r714_0 1 r716_1 1 r716_3 1 r717_0 1 r717_2 1 r717_4 1 r71_0 1 r720_1 1 r722_1 1 r722_3 1 r723_0 1 r725_1 1 r725_3 1 r726_0 1 r728_0 1 r730_0 1 r730_2 1 r731_1 1 r732_0 1 r733_0 1 r733_2 1 r736_0 1 r738_0 1 r738_2 1 r739_1 1 r73_1 1 r73_3 1 r740_0 1 r741_0 1 r741_2 1 r744_1 1 r746_1 1 r746_3 1 r747_0 1 r749_1 1 r749_3 1 r74_0 1 r750_0 1 r752_1 1 r754_1 1 r754_3 1 r755_0 1 r757_1 1 r757_3 1 r758_0 1 r760_0 1 r762_0 1 r762_2 1 r763_1 1 r764_0 1 r765_0 1 r765_2 1 r768_1 1 r768_3 1 r769_0 1 r769_2 1 r769_4 1 r76_0 1 r772_1 1 r774_1 1 r774_3 1 r775_0 1 r777_1 1 r777_3 1 r778_0 1 r780_0 1 r782_0 1 r782_2 1 r783_1 1 r784_0 1 r785_0 1 r785_2 1 r788_0 1 r78_0 1 r78_2 1 r790_0 1 r790_2 1 r791_1 1 r792_0 1 r793_0 1 r793_2 1 r796_1 1 r798_1 1 r798_3 1 r799_0 1 r79_1 1 r7_1 1 r801_1 1 r801_3 1 r802_0 1 r804_0 1 r806_0 1 r806_2 1 r807_1 1 r808_0 1 r809_0 1 r809_2 1 r80_0 1 r812_0 1 r814_0 1 r814_2 1 r815_1 1 r816_0 1 r817_0 1 r817_2 1 r819_0 1 r81_0 1 r81_2 1 r820_0 1 r820_2 1 r821_1 1 r821_3 1 r824_1 1 r826_1 1 r826_3 1 r827_0 1 r829_1 1 r829_3 1 r830_0 1 r832_0 1 r834_0 1 r834_2 1 r835_1 1 r836_0 1 r837_0 1 r837_2 1 r840_0 1 r842_0 1 r842_2 1 r843_1 1 r844_0 1 r845_0 1 r845_2 1 r848_1 1 r84_0 1 r84_2 1 r84_4 1 r84_6 1 r850_1 1 r850_3 1 r851_0 1 r853_1 1 r853_3 1 r854_0 1 r856_1 1 r858_1 1 r858_3 1 r859_0 1 r861_1 1 r861_3 1 r862_0 1 r864_0 1 r866_0 1 r866_2 1 r867_1 1 r868_0 1 r869_0 1 r869_2 1 r86_1 1 r872_1 1 r874_1 1 r874_3 1 r875_0 1 r877_1 1 r877_3 1 r878_0 1 r87_1 1 r880_0 1 r882_0 1 r882_2 1 r883_1 1 r884_0 1 r885_0 1 r885_2 1 r888_0 1 r890_0 1 r890_2 1 r891_1 1 r892_0 1 r893_0 1 r893_2 1 r896_1 1 r898_1 1 r898_3 1 r899_0 1 r89_1 1 r89_3 1 r8_1 1 r8_3 1 r901_1 1 r901_3 1 r902_0 1 r904_0 1 r906_0 1 r906_2 1 r907_1 1 r908_0 1 r909_0 1 r909_2 1 r90_0 1 r912_0 1 r914_0 1 r914_2 1 r915_1 1 r916_0 1 r917_0 1 r917_2 1 r91_1 1 r91_3 1 r91_5 1 r920_1 1 r922_1 1 r922_3 1 r923_0 1 r925_1 1 r925_3 1 r926_0 1 r928_0 1 r92_0 1 r930_0 1 r930_2 1 r931_1 1 r932_0 1 r933_0 1 r933_2 1 r936_0 1 r938_0 1 r938_2 1 r939_1 1 r93_0 1 r93_2 1 r940_0 1 r941_0 1 r941_2 1 r944_1 1 r946_1 1 r946_3 1 r947_0 1 r949_1 1 r949_3 1 r950_0 1 r952_1 1 r954_1 1 r954_3 1 r955_0 1 r957_1 1 r957_3 1 r958_0 1 r960_0 1 r962_0 1 r962_2 1 r963_1 1 r964_0 1 r965_0 1 r965_2 1 r968_1 1 r96_0 1 r970_1 1 r970_3 1 r971_0 1 r973_1 1 r973_3 1 r974_0 1 r976_0 1 r978_0 1 r978_2 1 r979_1 1 r980_0 1 r981_0 1 r981_2 1 r984_0 1 r986_0 1 r986_2 1 r987_1 1 r988_0 1 r989_0 1 r989_2 1 r98_0 1 r98_2 1 r992_1 1 r994_1 1 r994_3 1 r995_0 1 r997_1 1 r997_3 1 r998_0 1 r99_1 1 r9_0 1 r9_2 1]
set fh [open /work/clock/arr_$::env(CORNER).txt w]
puts $fh "# OT_EDGES v1 T/N=source rise F/M=source fall (late early), polarity-resolved"
foreach p [get_ports t_*] { set n [get_full_name $p]; set smx [get_property $p slack_max_rise]; set smn [get_property $p slack_min_rise]; puts $fh "T $n [expr {833.333 - $smx}] [expr {$smn}]" }
foreach p [get_ports t_*] { puts $fh "F [get_full_name $p] [expr {833.333 - [get_property $p slack_max_fall]}] [get_property $p slack_min_fall]" }
foreach i [get_cells b*] { set q [get_pins [get_full_name $i]/Y]; if {[dict exists $ot_odd [get_full_name $i]]} { set e fall; set g rise } else { set e rise; set g fall }; puts $fh "N [get_full_name $i] [get_property $q arrival_max_$e] [get_property $q arrival_min_$e]"; puts $fh "M [get_full_name $i] [get_property $q arrival_max_$g] [get_property $q arrival_min_$g]" }
close $fh
report_checks -path_delay max -group_path_count 1 -format full -fields {cap slew fanout}
puts OT_DONE
