#!/bin/bash
set -eu
export PATH=$HOME/.local/opentallas-tools/bin:$PATH
verilator --binary --timing --top-module tb -Wno-fatal -j 2 -f sources.f --Mdir obj > build.log 2>&1
obj/Vtb > run.log 2>&1
cat run.log
