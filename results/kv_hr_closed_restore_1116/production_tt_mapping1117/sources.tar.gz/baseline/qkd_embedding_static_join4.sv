`timescale 1ns/1ps
// KVJ-C2 2026-10-17 (kv_static_join_plan.md N2): the four per-stack static embedding return trains end here, beside the
// d2d KV end, in front of qkd_embedding_row_tx.  Each train root word up<s> = {record 298, v} (qkd_embedding_static_
// return_hop / _head upo; record = {epoch16, scale, half, word6, token18, data256}) is captured at a pin flop, the
// compiler makes the four trains' delivery edges disjoint, so the four captured words meet in a ONE-HOT select (never an
// arbitration: two valid on one edge latch fault), and the selected beat enters the unchanged qkd_embedding_static_join
// (its beat_slot = the compiled slot, captured on the same edge as the trains).  Added edge: +1 (the pin capture) on the
// train root -> join path; the join's own +1 is unchanged.  No credit, ready or wait.
// Proof: rtl/test/qwen_static_kv/tb_qkd_embedding_static_join4.sv (lock-step vs qkd_embedding_static_join fed the same
// beats one edge earlier).  MUT (bench only): 1 = no conflict fault; 2 = train 3 ignored.
module qkd_embedding_static_join4 #(parameter integer MUT = 0, parameter integer NATIVE32 = 0, parameter integer PIPE_JOIN = 0) (
    input wire ck,rst_n,
    input wire [298:0] up0,up1,up2,up3,
    input wire beat_slot,
    output wire word_v,output wire [511:0] word_data,
    output wire [17:0] word_token,output wire [5:0] word_index,
    output wire word_scale,output wire [15:0] word_epoch,
    output reg fault
);
    wire [10:0] reset_region;
    generate if(NATIVE32)begin:g_reset
        ot_rst_relay #(.REGIONS(11)) u_reset(.clk(ck),.rst_n_in(rst_n),.rst_n(reset_region));
    end else begin:g_legacy_reset
        assign reset_region={11{rst_n}};
    end endgenerate
    reg [298:0] u0,u1,u2,u3;
    reg slot_q;
    always @(posedge ck) begin u0[298:1]<=up0[298:1];u1[298:1]<=up1[298:1];u2[298:1]<=up2[298:1];u3[298:1]<=up3[298:1];end
    always @(posedge ck or negedge reset_region[10])
        if(!reset_region[10]) begin u0[0]<=0;u1[0]<=0;u2[0]<=0;u3[0]<=0;slot_q<=0;end
        else begin u0[0]<=up0[0];u1[0]<=up1[0];u2[0]<=up2[0];u3[0]<=up3[0];slot_q<=beat_slot;end
    wire v3=(MUT==2)?1'b0:u3[0];
    wire [3:0] hot={v3,u2[0],u1[0],u0[0]};
    // NATIVE32 captures valid copies on the SAME existing face edge. Each copy
    // selects at most 30 payload bits; keep prevents equality merging in Yosys.
    // No extra data/schedule edge. Legacy path remains the default.
    wire [297:0] rec;
    generate if (NATIVE32) begin : g_native32
        for (genvar slice = 0; slice < 10; slice = slice + 1) begin : g_slice
            localparam integer LO = slice * 30;
            localparam integer WIDTH = (298 - LO < 30) ? 298 - LO : 30;
            (* keep = 1, dont_touch = 1 *) reg [3:0] valid_q;
            always @(posedge ck or negedge reset_region[slice])
                if (!reset_region[slice]) valid_q <= 4'b0;
                else valid_q <= {(MUT == 2 ? 1'b0 : up3[0]), up2[0], up1[0], up0[0]};
            assign rec[LO +: WIDTH] =
                ({WIDTH{valid_q[0]}} & u0[LO+1 +: WIDTH]) |
                ({WIDTH{valid_q[1]}} & u1[LO+1 +: WIDTH]) |
                ({WIDTH{valid_q[2]}} & u2[LO+1 +: WIDTH]) |
                ({WIDTH{valid_q[3]}} & u3[LO+1 +: WIDTH]);
        end
    end else begin : g_legacy_select
        assign rec=({298{u0[0]}}&u0[298:1])|({298{u1[0]}}&u1[298:1])|({298{u2[0]}}&u2[298:1])|({298{v3}}&u3[298:1]);
    end endgenerate
    wire bv=|hot;
    wire multi=(MUT==1)?1'b0:((hot&(hot-4'd1))!=4'd0);
    wire jf;
    generate if (PIPE_JOIN) begin : g_pipelined_join
    qkd_embedding_static_join_fan32 u_join(.ck(ck),.rst_n(reset_region[10]),.beat_slot(slot_q),.beat_v(bv),
        .beat_data(rec[255:0]),.beat_token(rec[273:256]),.beat_word(rec[279:274]),
        .beat_half(rec[280]),.beat_scale(rec[281]),.beat_epoch(rec[297:282]),
        .word_v(word_v),.word_data(word_data),.word_token(word_token),.word_index(word_index),
        .word_scale(word_scale),.word_epoch(word_epoch),.fault(jf));
    end else begin : g_legacy_join
    qkd_embedding_static_join u_join(.ck(ck),.rst_n(reset_region[10]),.beat_slot(slot_q),.beat_v(bv),
        .beat_data(rec[255:0]),.beat_token(rec[273:256]),.beat_word(rec[279:274]),
        .beat_half(rec[280]),.beat_scale(rec[281]),.beat_epoch(rec[297:282]),
        .word_v(word_v),.word_data(word_data),.word_token(word_token),.word_index(word_index),
        .word_scale(word_scale),.word_epoch(word_epoch),.fault(jf));
    end endgenerate
    reg mf;
    reg mf_q,multi_q;
    always @(posedge ck or negedge reset_region[10])
        if(!reset_region[10])begin mf_q<=0;multi_q<=0;end
        else begin mf_q<=mf;multi_q<=multi;end
    always @(posedge ck or negedge reset_region[10])
        if(!reset_region[10]) begin mf<=0;fault<=0;end
        else begin if(multi)mf<=1;fault<=(PIPE_JOIN?mf_q:mf)|jf|(PIPE_JOIN?multi_q:multi);end
endmodule
