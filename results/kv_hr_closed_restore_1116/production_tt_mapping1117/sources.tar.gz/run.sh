#!/bin/bash
set -eu
export PATH=$HOME/.local/opentallas-tools/bin:$PATH
yosys -V > tool_version.txt
for shape in context baseline; do
 (cd "$shape"; yosys -Q -T -l synth.log synth.ys > stdout.log 2>&1)
done
