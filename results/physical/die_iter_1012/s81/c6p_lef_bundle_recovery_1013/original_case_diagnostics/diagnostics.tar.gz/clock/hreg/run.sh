#!/bin/bash
# clock-only die CTS case c6p_hreg (hreg); docker on the compute host, admission guard if present
set -o pipefail
D=$(cd "$(dirname "$0")" && pwd)
IMG=${IMG:-openroad/orfs:latest}
CPUS=${CPUS:-8}
TO=${CTS_TIMEOUT:-300}
run() { docker run --rm --name ckplan_c6p_hreg_$1 --cpus=$CPUS -v $D:/work -w /work $IMG bash -lc \
  "timeout -k 60 $TO /OpenROAD-flow-scripts/tools/install/OpenROAD/bin/openroad -threads $CPUS -no_init -exit /work/$1.tcl > /work/$1.log 2>&1; rc=\$?; chmod -R a+rwX /work; exit \$rc"; }
date -u +%FT%TZ > $D/start
# qwendie-1011: TritonCTS H-tree loops forever on some sparse ~60-sink region nets (r22ko4 e7: hangs after the
# 2-sinks-per-sub-region level with or without clustering / any buffer distance).  Each CTS that does not finish inside
# the timeout is retried with the next H-tree variant: -num_static_layers 1, -num_static_layers 3, -wire_unit 50.
{ run cts || { echo "cts rc=$? -> sl1" >> $D/retry; run cts_sl1; } || { echo "sl1 rc=$? -> sl3" >> $D/retry; run cts_sl3; } || { echo "sl3 rc=$? -> wu50" >> $D/retry; run cts_wu50; }; } && run meas_SS && run meas_FF
echo $? > $D/exit
date -u +%FT%TZ > $D/end
