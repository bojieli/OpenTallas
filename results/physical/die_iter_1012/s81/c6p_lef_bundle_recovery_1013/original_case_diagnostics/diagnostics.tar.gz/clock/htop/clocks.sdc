create_clock -name clk_stream -period 833.333000000 [get_pins root_clk_stream/Y]
create_clock -name clk_serial -period 1111.111000000 [get_pins root_clk_serial/Y]
create_clock -name clk_hbm -period 1024.000000000 [get_pins root_clk_hbm/Y]
