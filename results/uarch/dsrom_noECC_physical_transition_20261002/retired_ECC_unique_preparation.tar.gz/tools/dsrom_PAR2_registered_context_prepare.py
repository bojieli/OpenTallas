#!/usr/bin/env python3
"""Concrete capture/clock/ACK model join; no engine RTL or physical job."""
import collections,gzip,json,math,re
from pathlib import Path
from dsrom_secded_fullwidth_characterize import ROOT,merged,input_pins,block,sha
B=ROOT/'results/uarch/dsrom_PAR2_registered_context_prepare_20261002'
C=ROOT/'results/uarch/dsrom_secded_clean_checker_20261002'
def pin(cell,name):
    m=re.search(r'\bpin\s*\('+re.escape(name)+r'\)',cell)
    if not m:raise ValueError('pin absent '+name)
    return block(cell,m.start())
def attr(body,name):return float(re.search(r'\b'+name+r'\s*:\s*([-\d.]+)',body)[1])
def consume_edge(accepted,capture_delay=2,detector_delay=2):
    # Visible post-NBA flag cannot qualify same-edge preedge arithmetic.
    return accepted+capture_delay+detector_delay+1
def safe_clock_enable(original_enable,read_debt,check_debt,error_debt,delivery_debt,ack_debt):
    return bool(original_enable or read_debt or check_debt or error_debt or delivery_debt or ack_debt)
def build():
    receipts=json.loads((B/'inputs/receipt.json').read_text())
    for item in receipts:assert sha(B/'inputs'/item['copy'])==item['sha256']
    s=(B/'inputs/element.sv').read_text();a=json.loads((B/'inputs/adapter.json').read_text());d=json.loads((B/'inputs/deadline.json').read_text());m=json.loads((C/'terminal_r1/record.json').read_text())
    for clause in ['if (i2x_v && !i2x_bk) cap0 <= rd0;','if (i2x_v && i2x_bk) cap1 <= rd1;','assign i2_v = i3_v;','wire cg_en = !rst_n || go || go_e || walk_busy || drain != 8\'d0;','parameter integer DRAIN = 127','localparam integer TW = HW + 3 + TRW + 6;']:
        if clause not in s:raise ValueError('source changed '+clause)
    units=[];clocks={}
    for corner in ('ss','ff'):
        _,cells=merged(corner);clkcap=attr(pin(cells['DFFHQNx1_ASAP7_75t_R'],'CLK'),'capacitance');limit=attr(pin(cells['ICGx1_ASAP7_75t_R'],'GCLK'),'max_capacitance')
        rom=(B/f'inputs/ROM_{corner}.lib').read_text();romclk=attr(pin(rom,'clk'),'capacitance')
        clocks[corner]=dict(DFF_CLK_fF=clkcap,ICG_GCLK_max_cap_fF=limit,ROM_CLK_fF=romclk,
          existing_main_pair_PP_capture_bits=2*2*274,
          existing_main_pair_PP_capture_plus4ROM_clock_fF=1096*clkcap+4*romclk,
          minimum_46p08fF_load_groups_before_wires_or_other_element_logic=math.ceil((1096*clkcap+4*romclk)/limit),
          single_ICG_unbuffered_load_fits=False,
          actual_inserted_clock_buffers_skew_and_pulse_width_unbound=True)
        for k,replicas,heldbits in ((256,412,274),(272,256,282)):
            state=heldbits+74+12;net=json.loads(gzip.decompress((C/f'terminal_r1/K{k}/mapped.json.gz').read_bytes()))['modules']['ot_rom_secded_clean_checker'];loads=collections.Counter()
            directions={name:input_pins(cells[name]) for name in {v['type'] for v in net['cells'].values()}}
            for cell in net['cells'].values():
                for pname,bits in cell['connections'].items():
                    if pname in directions[cell['type']]:
                        cap=attr(pin(cells[cell['type']],pname),'capacitance')
                        for bit in bits:loads[bit]+=cap
            cwloads=[loads[bit] for bit in net['ports']['cw']['bits']]
            clocks[corner][f'K{k}']=dict(reference_registered_state_bits=state,reference_added_CLK_load_per_instance_fF=state*clkcap,
              reference_added_CLK_load_all_replicas_fF=state*clkcap*replicas,
              minimum_load_groups_before_wires=math.ceil(state*clkcap/limit),
              checker_only_CW_sink_cap_fF_min=min(cwloads),checker_only_CW_sink_cap_fF_max=max(cwloads),
              extra_normal_payload_sink_and_held_error_capture_pin_load_requires_actual_connection=True)
    for k,replicas in ((256,412),(272,256)):
        v=m['results'][str(k)];units.append(dict(K=k,N=k+10,replicas=replicas,
          SS_measured_checker_delay_ps=v['ss']['clean_max_delay_ps'],
          residual_for_launchFF_CLKQ_setup_wire_relative_skew_ps=833.333333-60-v['ss']['clean_max_delay_ps'],
          output_sink='actualDFFHQNx1 Dpin .524726fF SS/.62135fF FF',
          no_full_corrector_load_on_normal_checker=True,
          input_driver_must_use_actual_CW_sink_caps=clocks['ss'][f'K{k}'],
          actual_registered_setup_hold_pass=False,
          source_representation='No checker registers exist in retained source; these are priced proposed held-word/status registers, not installed source instances.'))
    return dict(schema='opentallas.dsrom.PAR2.registered-context-prepare.v1',candidate=d['input_sha256'] and m['model']['candidate'],generator_sha256=sha(Path(__file__)),input_receipt_sha256=sha(B/'inputs/receipt.json'),
      checker_measurement_sha256=sha(C/'terminal_r1/record.json'),source_element_sha256=sha(B/'inputs/element.sv'),
      provisional_checker_cycles=2,provisional_held_II=2,checker_primitive_units=units,actual_clock_pin_loads=clocks,
      source_edges=dict(accepted_gclk=0,PP_capture_postNBA=2,old_lane_preedge_sample=3,
        prospective_registered_clean_postNBA=4,earliest_matching_registered_consume_preedge=5,
        mandatory_alignment_added_cycles=2,source_has_no_checked_ready_gate=True,
        required_alignment='Weights, bothMB activationq256/exponent10, bank, format, tag, valid and both checker identities must move together. No dropped/replayed MAC or altered rounding/reduction order.',
        added_alignment_state_per_pair_per_cycle_formula='532 activation+exponent +2bank/format +1valid +TW =535+TW; TW=clog2(NCH)+clog2(NSEG)+(MTP!=0)+9. Actual compiler parameters must select the value.',
        assigned_controller_common_plus2_remains_separate=True,
        no_added_cycle_alternative='Only separately proven preedge combinational clean/fence gating stable before original n+3 lane edge; current source lacks it. Not selected here.'),
      held_service=dict(raw_replicas=412,main_replicas=256,paired_request_seats=128,raw_leaf_read_credit=1,
        main_two_word_capture_bits=548,header_bits=74,nonce_bits=16,full_owner_identity_bits=a['price']['proposed_identity_bits_with_nonce'],
        clean_release='matched accepted identity AND valid AND both mainCLEAN AND matching authenticated raw/gather terminal',
        error_release='source corrected-good terminal replaces held payload before consume; poison/fault/cancel drain preserves accepted debt; no timer-only completion',
        no_error_frequency_assumption=True,
        II2_is_detector_budget_not_leaf_credit_guarantee=True,
        bank_II_inequality='I_leaf >= max(source portII, accepted->safe leaf release). If credit held through delivery, include actual gather/ACK/reversecredit. Earlier release requires separately reserved transfer state.',
        slow_corrector4raw3main_are_optimistic_unbuffered_interval_diagnostics_NOT_upper_bounds=True,
        fault_state_blocks_new_admission_but_matching_inflight_returns_must_drain=True),
      source_clock_repair=dict(source_ICG='ot_hdc_cg uses realICGx1; exact SS/FF stockcell inspected',
        existing_DRAIN127_has_no_ECC_or_ACK_debt=True,
        required_enable='existing_cg_en OR accepted_read_debt OR check_pending OR held_error/corrector_debt OR delivery_debt OR ACK/reversecredit_debt',
        clock_can_stop_only_after_all_matching_debts_drain=True,
        no_fixed_DRAIN_bound_claim=True,clock_domains='1.2GHz streaming; gated source gclk vs service clk needs exact parent timebase/phase and handshake binding, not presumed free-running'),
      routes=dict(full_reply_packet_bits_per_lane=90,reply_lanes=128,full_reply_demand_bits=11520,
        old_33lane_representative_cut_data_bits=528,full74header_plus16data_same_cut_bits=2970,
        additional_header_tracks_on_that_cut_if_unshared=2442,
        no_phase_header_sharing_or50pctPG_reserve_credit=True,
        actual_translated_pin_OBS_PG_via_clock_capacity_still_required=True),
      area_union=dict(existing_PPmain_capture_registers_in_field=128*1096,proposed_active_main_hold_bits=128*548,
        active_hold_may_not_alias_existing_PPbanks_without_lifetime_proof=True,
        source_adapter_state_delta_bits=a['price']['state_delta_bits'],source_adapter_comparebit_debit=a['price']['bank_compare_delta_gate_bit_equivalents'],
        standalone_nonce_exception_overlays_do_not_sum_into_adapter_without_disjoint_instance_map=True,
        full_corrector_floor_mm2=.7996465152+.5279219712,measured_isolated_checkers_mm2=.05513502816,
        planned_registered_state_bits=242528,embedding_or_area_credit=0,
        physical_fit_proven=False),
      next_ready_gate=dict(scope='Source/model pre-preview of one complete PP mainpair with four4096x274 macro ports, bothMB read/capture/activation/tag, twoK272 checkers, and one complete rawleaf K256+hold/error/ACK context; no reduced word widths or constant producer.',
        loaded_registered_STA_can_be_prepared_independently_of_fulltoken=True,
        requires_before_source_optin_copy=['Parent/Nash freeze actual accepted main/sidecar identities and nonce echo, terminal/ACK signals','Bind source checked-ready at irreversible lane edge and aligned activation/tag/bank delay','Bind clock-enable debt predicate and reserved correction/transfer seats without hidden reuse','Named local FF/control/buffer/pin/clock placement with real load/layer capacity; source-class independent model review'],
        engine_RTL_or_PR_admitted=False,no_new_job=True),
      four_targets={'DS_ROM':'samePAR2 protectedweight source','DS_HBM':'no transfer','Qwen_ROM':'separate source model needed','Qwen_HBM':'no transfer'},
      old_fullcorrector_failures_unchanged=True)
if __name__=='__main__':
    out=B/'model.json';data=(json.dumps(build(),indent=2,sort_keys=True)+'\n').encode()
    if out.exists() and out.read_bytes()!=data:raise ValueError('fresh successor required')
    out.write_bytes(data);print(sha(out))
