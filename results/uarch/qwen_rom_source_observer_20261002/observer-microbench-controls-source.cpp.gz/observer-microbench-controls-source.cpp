#define QROM_OBSERVER 1
#include "/tmp/opentallas-qrom-image-journal-current-20261002/rtl/test/qwen_rom_runtime/observer/qwen_rom_observer.hpp"
#include <chrono>
#include <cstdio>
struct Vdie{Root* rootp;unsigned prog_base=0;unsigned long long desc_q=0;};
#if QROM_OBSERVER
static void qrom_pre(QromObserver& obs, Vdie& t,long edge,size_t stage,int rank) {
 if(stage>=36)return;
 auto* r=t.rootp;
 obs.control(edge,stage,rank,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_idle | (r->ot_qwen_rom_rt_die__DOT__core__DOT__su_idle<<1) | (r->ot_qwen_rom_rt_die__DOT__core__DOT__su_ready<<2));
 const unsigned seg=r->ot_qwen_rom_rt_die__DOT__seq__DOT__seg,base=t.prog_base;
 const bool start=r->ot_qwen_rom_rt_die__DOT__seq__DOT__st==3; // exact captured assign core_start = st==S_RUN
 if(start) {if(obs.active[rank])throw std::runtime_error("overlapping source core_start");obs.active[rank]=true;obs.dispatch('S',edge,stage,rank,seg,base,t.desc_q);}
 else if(obs.active[rank] && r->ot_qwen_rom_rt_die__DOT__core_done){obs.dispatch('D',edge,stage,rank,seg,base,t.desc_q);obs.active[rank]=false;}
 if(r->ot_qwen_rom_rt_die__DOT__core__DOT__issue) {
  if(!obs.active[rank])throw std::runtime_error("accepted issue without dispatch");
  unsigned fields[24]={r->ot_qwen_rom_rt_die__DOT__core__DOT__me_nout,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_tiles,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_k,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_wsrc,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_wbase,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_ts,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_ks,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_js,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_xbase,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_xks,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_xjs,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_xcs,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_jsh,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_split,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_wcs,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_round,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_obase,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_ots,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_ojs,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_mmode,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_oen,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_amax,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_rmax,r->ot_qwen_rom_rt_die__DOT__core__DOT__me_mbase};
  const unsigned unit=r->ot_qwen_rom_rt_die__DOT__core__DOT__d_unit;
  if(bool(r->ot_qwen_rom_rt_die__DOT__core__DOT__me_go)!=(unit==1))throw std::runtime_error("actual ME go mismatch");
  obs.issue(edge,stage,rank,seg,base,r->ot_qwen_rom_rt_die__DOT__core__DOT__pc,unit,fields);
 }
}
#endif
struct Values{unsigned at(unsigned)const{return 0;}};
int main(){QromObserver o;Root r;Vdie d{&r};unsigned f[24]={};
auto a=std::chrono::steady_clock::now();for(int i=0;i<1000000;++i)qrom_pre(o,d,i,0,0);auto b=std::chrono::steady_clock::now();
for(int i=0;i<3744;++i)o.issue(i,0,0,0,0,i,1,f);
for(int i=0;i<73728;++i)o.write(i,0,0,i,0);
for(int i=0;i<144;++i)o.snapshot(i,0,0,Values{});
auto c=std::chrono::steady_clock::now();std::printf("%.9f %.9f\n",std::chrono::duration<double>(b-a).count(),std::chrono::duration<double>(c-b).count());}
