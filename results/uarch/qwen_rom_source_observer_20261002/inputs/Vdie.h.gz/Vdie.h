// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Primary model header
//
// This header should be included by all source files instantiating the design.
// The class here is then constructed to instantiate the design.
// See the Verilator manual for examples.

#ifndef VERILATED_VDIE_H_
#define VERILATED_VDIE_H_  // guard

#include "verilated.h"
#include "svdpi.h"

class Vdie__Syms;
class Vdie___024root;

// This class is the main interface to the Verilated model
class alignas(VL_CACHE_LINE_BYTES) Vdie VL_NOT_FINAL : public VerilatedModel {
  private:
    // Symbol table holding complete model state (owned by this class)
    Vdie__Syms* const vlSymsp;

  public:

    // CONSTEXPR CAPABILITIES
    // Verilated with --trace?
    static constexpr bool traceCapable = false;

    // PORTS
    // The application code writes and reads these signals to
    // propagate new values into/out from the Verilated model.
    VL_IN8(&clk,0,0);
    VL_OUT8(&rt_rst_n,0,0);
    VL_OUT8(&me_clk_en,0,0);
    VL_OUT8(&start,0,0);
    VL_IN8(&h_start,0,0);
    VL_OUT8(&s_done,0,0);
    VL_OUT8(&s_fault,0,0);
    VL_OUT8(&core_fault,0,0);
    VL_OUT8(&c_valid,0,0);
    VL_IN8(&c_ready,0,0);
    VL_OUT8(&c_last,0,0);
    VL_OUT8(&c_mode,0,0);
    VL_IN8(&r_valid,0,0);
    VL_IN8(&r_last,0,0);
    VL_IN8(&r_rank,1,0);
    VL_IN8(&r_err,0,0);
    VL_OUT8(&prog_re,0,0);
    VL_OUT8(&desc_re,0,0);
    VL_OUT8(&desc_addr,5,0);
    VL_OUT8(&s_vre,0,0);
    VL_OUT8(&s_vraddr,7,0);
    VL_OUT8(&s_vwe,0,0);
    VL_OUT8(&s_vwaddr,7,0);
    VL_OUT8(&wrom_re,0,0);
    VL_OUT8(&int8_wrom_re,0,0);
    VL_OUT8(&scale_re,0,0);
    VL_OUT8(&kv_re,0,0);
    VL_OUT8(&vw_rd_we,0,0);
    VL_OUT8(&vw_mx_we,0,0);
    VL_OUT8(&me_ov,0,0);
    VL_OUT8(&tgo,0,0);
    VL_IN8(&fab_fault,0,0);
    VL_OUT16(&prog_base,11,0);
    VL_OUT16(&prog_addr,11,0);
    VL_OUT16(&vw_mx_mask,15,0);
    VL_OUT(&cyc,31,0);
    VL_IN(&tp_token,17,0);
    VL_IN(&tp_pos,17,0);
    VL_OUT(&seq_ntok,17,0);
    VL_OUT(&seq_nval,31,0);
    VL_OUT(&core_cycles,31,0);
    VL_OUTW(&c_data,511,0,16);
    VL_OUT(&c_tag,31,0);
    VL_INW(&r_data,511,0,16);
    VL_INW(&prog_q,1023,0,32);
    VL_INW(&s_vrq,511,0,16);
    VL_OUTW(&s_vwdata,511,0,16);
    VL_OUT(&int8_wrom_addr,23,0);
    VL_OUTW(&scale_addr,1151,0,36);
    VL_INW(&scale_q,12287,0,384);
    VL_OUTW(&crom_addr,1535,0,48);
    VL_INW(&crom_q,4095,0,128);
    VL_OUTW(&kv_waddr,1535,0,48);
    VL_OUTW(&kv_wdata,2047,0,64);
    VL_OUTW(&va_addr,1535,0,48);
    VL_OUTW(&vb_addr,1535,0,48);
    VL_OUTW(&vc_addr,1535,0,48);
    VL_INW(&va_q,2047,0,64);
    VL_INW(&vb_q,2047,0,64);
    VL_INW(&vc_q,2047,0,64);
    VL_OUTW(&vw_su_addr,1535,0,48);
    VL_OUTW(&vw_su_data,2047,0,64);
    VL_OUT(&vw_rd_addr,23,0);
    VL_OUT(&vw_rd_data,31,0);
    VL_OUT(&vw_mx_addr,23,0);
    VL_OUTW(&vw_mx_data,511,0,16);
    VL_OUTW(&vw_me_addr,1151,0,36);
    VL_OUTW(&vw_me_mask,767,0,24);
    VL_OUTW(&vw_me_data,24575,0,768);
    VL_OUTW(&vx_re,2047,0,64);
    VL_OUTW(&vx_addr,49151,0,1536);
    VL_INW(&vx_q,65535,0,2048);
    VL_OUTW(&tb,378,0,12);
    VL_OUTW(&xl_d,65535,0,2048);
    VL_INW(&t_lvl,24575,0,768);
    VL_IN64(&desc_q,63,0);
    VL_OUT64(&scale_gre,47,0);
    VL_OUT64(&crom_re,63,0);
    VL_OUT64(&kv_we,63,0);
    VL_OUT64(&va_re,63,0);
    VL_OUT64(&vb_re,63,0);
    VL_OUT64(&vc_re,63,0);
    VL_OUT64(&vw_su_we,63,0);
    VL_OUT64(&vw_me_we,47,0);

    // CELLS
    // Public to allow access to /* verilator public */ items.
    // Otherwise the application code can consider these internals.

    // Root instance pointer to allow access to model internals,
    // including inlined /* verilator public_flat_* */ items.
    Vdie___024root* const rootp;

    // CONSTRUCTORS
    /// Construct the model; called by application code
    /// If contextp is null, then the model will use the default global context
    /// If name is "", then makes a wrapper with a
    /// single model invisible with respect to DPI scope names.
    explicit Vdie(VerilatedContext* contextp, const char* name = "TOP");
    explicit Vdie(const char* name = "TOP");
    /// Destroy the model; called (often implicitly) by application code
    virtual ~Vdie();
  private:
    VL_UNCOPYABLE(Vdie);  ///< Copying not allowed

  public:
    // API METHODS
    /// Evaluate the model.  Application must call when inputs change.
    void eval() { eval_step(); }
    /// Evaluate when calling multiple units/models per time step.
    void eval_step();
    /// Evaluate at end of a timestep for tracing, when using eval_step().
    /// Application must call after all eval() and before time changes.
    void eval_end_step() {}
    /// Simulation complete, run final blocks.  Application must call on completion.
    void final();
    /// Are there scheduled events to handle?
    bool eventsPending();
    /// Returns time at next time slot. Aborts if !eventsPending()
    uint64_t nextTimeSlot();
    /// Trace signals in the model; called by application code
    void trace(VerilatedTraceBaseC* tfp, int levels, int options = 0) { contextp()->trace(tfp, levels, options); }
    /// Retrieve name of this model instance (as passed to constructor).
    const char* name() const;

    // Abstract methods from VerilatedModel
    const char* hierName() const override final;
    const char* modelName() const override final;
    unsigned threads() const override final;
    /// Prepare for cloning the model at the process level (e.g. fork in Linux)
    /// Release necessary resources. Called before cloning.
    void prepareClone() const;
    /// Re-init after cloning the model at the process level (e.g. fork in Linux)
    /// Re-allocate necessary resources. Called after cloning.
    void atClone() const;
  private:
    // Internal functions - trace registration
    void traceBaseModel(VerilatedTraceBaseC* tfp, int levels, int options);
};

#endif  // guard
