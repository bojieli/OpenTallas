#define QROM_OBSERVER 1
#include "/tmp/opentallas-qrom-image-journal-current-20261002/rtl/test/qwen_rom_runtime/observer/qwen_rom_observer_serialized_r1.hpp"
#include <thread>
#include <atomic>
#include <vector>
int main(){QromObserver o;std::atomic<unsigned> ready{0};std::vector<std::thread> ts;
for(unsigned t=0;t<16;++t)ts.emplace_back([&,t]{ready.fetch_add(1);while(ready.load()!=16)std::this_thread::yield();
for(unsigned i=0;i<512;++i){unsigned a=t*1024+i,v[16];for(unsigned l=0;l<16;++l)v[l]=a*16+l;o.read(i,0,0,t,i%4,a,v);}});
for(auto& t:ts)t.join();}
