read_liberty /tmp/dsrom-secded-612f450ae-timing-r3/ao_ff.lib
read_liberty /tmp/dsrom-secded-612f450ae-timing-r3/invbuf_ff.lib
read_liberty /tmp/dsrom-secded-612f450ae-timing-r3/oa_ff.lib
read_liberty /tmp/dsrom-secded-612f450ae-timing-r3/simple_ff.lib
read_liberty /tmp/dsrom-secded-612f450ae-timing-r3/seq_ff.lib
read_verilog /tmp/dsrom-secded-612f450ae-timing-r3/K272/mapped.v
link_design ot_rom_secded_dec
create_clock -name virtual -period 833.333333
set_clock_uncertainty -setup 60 [get_clocks virtual]
set_clock_uncertainty -hold 25 [get_clocks virtual]
set_input_delay -max 0 -clock virtual [all_inputs]
set_input_delay -min 0 -clock virtual [all_inputs]
set_output_delay -max 0 -clock virtual [all_outputs]
set_output_delay -min 0 -clock virtual [all_outputs]
set_input_transition 20 [all_inputs]
set_load 0.62135 [all_outputs]
report_units
report_checks -path_delay max -group_count 3 -format full_clock_expanded -digits 6 -fields {slew capacitance input_pin net}
report_checks -path_delay min -group_count 3 -format full_clock_expanded -digits 6 -fields {slew capacitance input_pin net}
report_check_types -max_slew -max_capacitance
exit
