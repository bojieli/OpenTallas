#!/bin/bash
cd /home/ubuntu/dsrom-c-w1-r1
/home/ubuntu/bin/admit.sh 1 -- python3 tools/dsrom_credit_return_gate.py --out /home/ubuntu/dsrom-c-w1-r1/run > run.log 2>&1
rc=$?
printf "%s\n" "$rc" > run.exit
exit "$rc"
