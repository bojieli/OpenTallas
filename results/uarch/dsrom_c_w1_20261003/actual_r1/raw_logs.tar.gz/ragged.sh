#!/bin/bash
cd /home/ubuntu/dsrom-c-w1-r1
mkdir ragged-golden
iverilog -g2012 -s tb_dsrom_credit_ragged -o ragged-golden/test rtl/ot_fp32_rne_pkg.sv rtl/v41rom/ot_v41_ret.sv rtl/v41rom/ot_v41_ret_credit.sv rtl/v41die/ot_v41_retn_credit.sv rtl/proto/ot_fp32_add_rne_pipe.sv rtl/hdc/ot_hdc_delay.sv run/ragged5.sv rtl/test/tb_dsrom_credit_ragged.sv > ragged-golden/compile.log 2>&1
rc=$?
if [ $rc -eq 0 ]; then /usr/bin/time -v vvp ragged-golden/test > ragged-golden/run.log 2> ragged-golden/resources.log; rc=$?; fi
printf "%s\n" "$rc" > ragged.exit
exit "$rc"
