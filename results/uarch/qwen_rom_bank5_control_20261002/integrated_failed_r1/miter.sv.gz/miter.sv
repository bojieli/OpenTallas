module bank5_formal(input clk,rst_n,wrom_re,input [23:0] wrom_addr,input [2659:0] payload);
reg [2659:0] rom_rd;
wire [511:0] a_out,b_out,c_out;
wire [4:0] a_ce,b_ce,c_ce,aq,aq2,bq,bq2,cq,cq2,banks;
wire [11:0] a_addr,b_addr,c_addr;
wire a_s,b_s,c_s;
wire [79:0] a_mask,b_mask,c_mask;
wire [2559:0] a_cap,b_cap,c_cap;wire [119:0] actual_macro_addr;
qwen_prior_capture #(.ROM_HOLD_DIRECT_CAPTURE(1)) a(.clk(clk),.rst_n(rst_n),.wrom_re(wrom_re),.wrom_addr(wrom_addr),.rom_rd(rom_rd),.wrom_q(a_out),.rom_ce(a_ce),.rom_addr(a_addr),.f_q(aq),.f_q2(aq2),.f_s(a_s),.f_mask(a_mask),.f_cap(a_cap));
qwen_optin_capture_logic #(.ROM_HOLD_DIRECT_CAPTURE(1)) b(.clk(clk),.rst_n(rst_n),.wrom_re(wrom_re),.wrom_addr(wrom_addr),.rom_rd(rom_rd),.wrom_q(b_out),.rom_ce(b_ce),.rom_addr(b_addr),.f_q(bq),.f_q2(bq2),.f_s(b_s),.f_mask(b_mask),.f_cap(b_cap));
qwen_optin_capture_logic #(.ROM_HOLD_DIRECT_CAPTURE(1),.ROM_BANK5_CONTROL(1),.ROM_CONTROL_DISTRIBUTION(1)) c(.clk(clk),.rst_n(rst_n),.wrom_re(wrom_re),.wrom_addr(wrom_addr),.rom_rd(rom_rd),.wrom_q(c_out),.rom_ce(c_ce),.rom_addr(c_addr),.f_q(cq),.f_q2(cq2),.f_s(c_s),.f_mask(c_mask),.f_cap(c_cap),.f_bank(banks),.rom_distributed_addr(actual_macro_addr));
always @* if ($initstate) assume(!rst_n);
integer p,i;
always @(posedge clk) for(p=0;p<2;p=p+1) for(i=0;i<5;i=i+1)
 if(a_ce[i]) rom_rd[(p*5+i)*266+:266] <= payload[(p*5+i)*266+:266];
always @* if (!$initstate) begin
 assert(banks=={5{a_s}});assert(actual_macro_addr=={10{a_addr}});
 assert(a_out==b_out);assert(a_out==c_out);
 assert(a_ce==b_ce);assert(a_ce==c_ce);assert(a_addr==b_addr);assert(a_addr==c_addr);
 assert(aq==bq);assert(aq==cq);assert(aq2==bq2);assert(aq2==cq2);
 assert(a_s==b_s);assert(a_s==c_s);assert(a_mask==b_mask);assert(a_mask==c_mask);
end
endmodule
