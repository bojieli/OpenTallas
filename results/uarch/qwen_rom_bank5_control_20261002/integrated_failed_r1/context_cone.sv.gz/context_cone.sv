module qwen_optin_capture_logic #(
 parameter integer W=16,AW=24,TG=4,CODE_BANKS=5,MEM_EXTRA=1,ROM_HOLD_DIRECT_CAPTURE=0,ROM_BANK5_CONTROL=0,ROM_CONTROL_DISTRIBUTION=0
)(input wire clk,rst_n,wrom_re,input wire [AW-1:0] wrom_addr,
 input wire [2*CODE_BANKS*266-1:0] rom_rd,
 output wire [2*W*8*TG/2-1:0] wrom_q,
 output wire [CODE_BANKS-1:0] rom_ce,output wire [11:0] rom_addr,output wire [119:0] rom_distributed_addr);
    reg  [CODE_BANKS-1:0] code_sel_q;
    genvar b, p;
    generate
        for (b = 0; b < CODE_BANKS; b = b + 1) begin : g_ce
            assign rom_ce[b] = wrom_re && (wrom_addr[AW-1:12] == b);
        end
    endgenerate
    assign rom_addr = wrom_addr[11:0];
    wire [84:0] distributed_strobe_n;
    wire [79:0] distributed_hold_term;
    wire [89:0] distributed_metadata_reset_n;
    wire [4:0] bank_hold_term;
    generate if (ROM_CONTROL_DISTRIBUTION != 0) begin : g_distribution
        genvar db;
        for (db=0; db<5; db=db+1) begin : g_term
            assign bank_hold_term[db] = code_sel_q[db] & ~distributed_strobe_n[17*db];
        end
        ot_qwen_rom_bank5_control_distribution u_tree (
            .bank_read_n(~code_rd_bank), .bank_hold_term(bank_hold_term),
            .low_address(rom_addr), .reset_n(rst_n),
            .strobe_sink_n(distributed_strobe_n), .hold_term_sink(distributed_hold_term),
            .macro_address(rom_distributed_addr), .metadata_reset_n(distributed_metadata_reset_n));
        for (db=0;db<5;db=db+1) begin : g_early_select
            always @(posedge clk or negedge distributed_metadata_reset_n[db])
                if (!distributed_metadata_reset_n[db]) code_sel_q[db] <= 1'b0;
                else if (wrom_re) code_sel_q[db] <= rom_ce[db];
        end
    end else begin : g_undistributed
        always @(posedge clk or negedge rst_n) begin
            if (!rst_n) code_sel_q <= {CODE_BANKS{1'b0}};
            else if (wrom_re) code_sel_q <= rom_ce;
        end
        assign rom_distributed_addr = {10{rom_addr}};
        assign distributed_strobe_n = 85'b0;
        assign distributed_hold_term = 80'b0;
        assign distributed_metadata_reset_n = {90{rst_n}};
        assign bank_hold_term = 5'b0;
    end endgenerate
    //: MEM_EXTRA: the read strobe and bank select one more cycle, for the captured banks' OR
    wire code_rd_q;
    wire [CODE_BANKS-1:0] code_rd_bank;
    reg [CODE_BANKS-1:0] code_sel_q2;
    generate if (ROM_CONTROL_DISTRIBUTION != 0 &&
        (ROM_BANK5_CONTROL == 0 || ROM_HOLD_DIRECT_CAPTURE == 0 || W != 16 || TG != 4 || CODE_BANKS != 5 || MEM_EXTRA != 1)) begin : g_unpriced_distribution
        initial $error("ROM_CONTROL_DISTRIBUTION requires priced bank5/direct W16/TG4/CB5/MEM_EXTRA1");
    end endgenerate
    generate if (ROM_BANK5_CONTROL != 0) begin : g_bank_control
        genvar rb;
        for (rb = 0; rb < CODE_BANKS; rb = rb + 1) begin : g_bank
            (* keep = 1, dont_touch = 1 *) reg read_q;
            wire bank_reset_n = (ROM_CONTROL_DISTRIBUTION != 0) ? distributed_metadata_reset_n[5+rb] : rst_n;
            always @(posedge clk or negedge bank_reset_n)
                if (!bank_reset_n) read_q <= 1'b0;
                else read_q <= wrom_re;
            assign code_rd_bank[rb] = read_q;
            always @(posedge clk or negedge rst_n)
                if (!rst_n) code_sel_q2[rb] <= 1'b0;
                else if (read_q) code_sel_q2[rb] <= code_sel_q[rb];
        end
        assign code_rd_q = code_rd_bank[0];
    end else begin : g_shared_control
        reg read_q;
        always @(posedge clk or negedge rst_n) begin
            if (!rst_n) begin read_q <= 1'b0; code_sel_q2 <= {CODE_BANKS{1'b0}}; end
            else begin
                read_q <= wrom_re;
                if (read_q) code_sel_q2 <= code_sel_q;
            end
        end
        assign code_rd_q = read_q;
        assign code_rd_bank = {CODE_BANKS{read_q}};
    end endgenerate
    generate if (ROM_BANK5_CONTROL != 0 &&
        (ROM_HOLD_DIRECT_CAPTURE == 0 || W != 16 || TG != 4 || CODE_BANKS != 5 || MEM_EXTRA != 1)) begin : g_unpriced_bank5
        initial $error("ROM_BANK5_CONTROL requires priced directcapture W16/TG4/CB5/MEM_EXTRA1");
    end endgenerate
    generate if (ROM_HOLD_DIRECT_CAPTURE != 0 &&
        (W != 16 || TG != 4 || CODE_BANKS != 5 || MEM_EXTRA != 1)) begin : g_unpriced_shape
        initial $error("ROM_HOLD_DIRECT_CAPTURE requires Maxwell-priced W16/TG4/CB5/MEM_EXTRA1");
    end endgenerate
    localparam integer PWB = 2 * W * 8;      // a group pair's slice of the code word (256 of the macro's 266 bits)
    generate
        for (p = 0; p < TG / 2; p = p + 1) begin : g_pair
            wire [PWB-1:0] or_q [0:CODE_BANKS];
            assign or_q[0] = {PWB{1'b0}};
            for (b = 0; b < CODE_BANKS; b = b + 1) begin : g_bank
                wire [PWB-1:0] rd = rom_rd[(p*CODE_BANKS + b)*266 +: PWB];
                if (MEM_EXTRA != 0) begin : g_cap
                    if (ROM_HOLD_DIRECT_CAPTURE != 0) begin : g_direct
                        // CE-idle holds rd in the source ROM. Observability is
                        // still qualified by identical delayed bank metadata.
                        reg [PWB-1:0] cap;
                        always @(posedge clk) cap <= rd;
                        genvar chunk;
                        for (chunk = 0; chunk < PWB / 32; chunk = chunk + 1) begin : g_mask
                            // Eight32-bit chunks per column,16 per bank:
                            // exactly80 reset/hold selectorFFs. Keep replicas
                            // for physical locality; mapped preservation gates.
                            (* keep = 1, dont_touch = 1 *) reg local_sel;
                            wire mask_reset_n = (ROM_CONTROL_DISTRIBUTION != 0) ?
                                distributed_metadata_reset_n[10+16*b+8*p+chunk] : rst_n;
                            always @(posedge clk or negedge mask_reset_n) begin
                                if (!mask_reset_n) local_sel <= 1'b0;
                                else if (ROM_CONTROL_DISTRIBUTION != 0) begin
                                    if (!distributed_strobe_n[17*b+1+8*p+chunk])
                                        local_sel <= distributed_hold_term[16*b+8*p+chunk];
                                end else if (code_rd_bank[b]) local_sel <= code_sel_q[b];
                            end
                            assign or_q[b+1][32*chunk +: 32] = or_q[b][32*chunk +: 32] |
                                (cap[32*chunk +: 32] & {32{local_sel}});
                        end
                    end else begin : g_original
                        // Original source behavior, defaultoff.
                        reg [PWB-1:0] cap;
                        always @(posedge clk) if (code_sel_q[b] && code_rd_q) cap <= rd;
                        assign or_q[b+1] = or_q[b] | (cap & {PWB{code_sel_q2[b]}});
                    end
                end else begin : g_nocap
                    assign or_q[b+1] = or_q[b] | (rd & {PWB{code_sel_q[b]}});
                end
            end
            assign wrom_q[PWB*p +: PWB] = or_q[CODE_BANKS];
        end
    endgenerate

endmodule
