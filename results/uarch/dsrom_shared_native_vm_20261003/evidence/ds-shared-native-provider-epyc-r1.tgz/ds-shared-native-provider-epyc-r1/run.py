import pathlib,subprocess,json,time,os
r=pathlib.Path(__file__).resolve().parent
rec={'pid':os.getpid(),'host':os.uname().nodename,'status':'RUNNING','scope':'raw actual single full2MiB provider,8client service functional; no physical/protected/fullparent adoption','threads':1}
def save():(r/'record.json').write_text(json.dumps(rec,indent=2)+'\n')
save()
cmd=['iverilog','-g2012','-Wall','-DOT_MEM_NO_INIT','-s','tb','-o',str(r/'gate.vvp')]+[str(r/x['copy']) for x in json.loads((r/'sources.json').read_text())['snapshot']]
for n,c in [('compile',cmd),('simulation',['vvp',str(r/'gate.vvp')])]:
 t=time.time()
 with (r/(n+'.log')).open('w') as log:code=subprocess.run(['/usr/bin/time','-v','-o',str(r/(n+'.resources'))]+c,stdout=log,stderr=subprocess.STDOUT).returncode
 rec[n]={'command':c,'exit_code':code,'elapsed_s':time.time()-t};save()
 if code:break
rec['status']='TERMINAL';rec['terminal']=(r/'simulation.log').read_text() if (r/'simulation.log').exists() else (r/'compile.log').read_text();save()
