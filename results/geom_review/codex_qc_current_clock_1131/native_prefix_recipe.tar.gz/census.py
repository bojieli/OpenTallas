"""Read-only actual native clock graph/body/access census; never legalizes/routes/analyzes."""
import argparse,json,math
from collections import defaultdict
from pathlib import Path
import odb
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import producer
p=argparse.ArgumentParser();p.add_argument('--odb',required=True);p.add_argument('--tree',required=True);p.add_argument('--ctree',required=True);p.add_argument('--out',required=True);a=p.parse_args()
t=json.loads(Path(a.tree).read_text());g=producer.clock_graph(Path(a.ctree).read_text(),t)
db=odb.dbDatabase.create();odb.read_db(db,a.odb);b=db.getChip().getBlock();u=b.getDbUnitsPerMicron();errors=[];samples=[];sizes=set();pins=set();pg_unbound=0
expected={r['inst'] for r in g['cells'].values()};found={i.getName() for i in b.getInsts() if i.getName().startswith('ck_')}
if found!=expected:errors.append('clock instance name set differs')
body_index=defaultdict(list);ob_index=defaultdict(list);bucket=64*u

def keys(r):
 return ((x,y) for x in range(math.floor(r[0]/bucket),math.floor(r[2]/bucket)+1) for y in range(math.floor(r[1]/bucket),math.floor(r[3]/bucket)+1))
def hit(a,b):return a[0]<b[2] and b[0]<a[2] and a[1]<b[3] and b[1]<a[3]
for i in b.getInsts():
 if not i.getMaster().isBlock():continue
 for ob in i.getMaster().getObstructions():
  layer=ob.getTechLayer()
  if layer and layer.getRoutingLevel() in (1,2,3):
   r=producer.physical_rect(i,ob)
   for k in keys(r):ob_index[k].append((r,'OBS:'+i.getName()+':'+layer.getName()))
 for mt in i.getMaster().getMTerms():
  if str(mt.getSigType()) not in ('POWER','GROUND'):continue
  for mp in mt.getMPins():
   for sh in mp.getGeometry():
    layer=sh.getTechLayer()
    if layer and layer.getName()=='M7':
     r=producer.physical_rect(i,sh)
     for k in keys(r):ob_index[k].append((r,'PG7:'+i.getName()+':'+mt.getName()))
body_collisions=access_collisions=0
for raw,r in g['cells'].items():
 i=b.findInst(r['inst'])
 if not i:continue
 m=i.getMaster();loc=i.getLocation();xy=[round(v*u) for v in r['xy_um']]
 if m.getName()!=r['master'] or list(loc)!=xy or str(i.getOrient())!='R0' or str(i.getPlacementStatus())!='FIRM':errors.append('master/home/orient/status:'+r['inst'])
 sizes.add((m.getName(),m.getWidth()/u,m.getHeight()/u))
 for pn,net in r['ports'].items():
  it=i.findITerm(pn)
  if not it or not it.getNet() or it.getNet().getName()!='ck_'+net:errors.append('primitive connection:'+r['inst']+'.'+pn)
 for pn in ('A','Y'):
  mt=m.findMTerm(pn);shapes=[sh for mp in mt.getMPins() for sh in mp.getGeometry() if sh.getTechLayer() and sh.getTechLayer().getRoutingLevel()>0] if mt else []
  if not shapes:errors.append('no actual routing pin:'+r['inst']+'.'+pn)
  pins.update((m.getName(),pn,sh.getTechLayer().getName()) for sh in shapes)
 for it in i.getITerms():
  if str(it.getMTerm().getSigType()) in ('POWER','GROUND') and not it.getNet():pg_unbound+=1
 bb=i.getBBox();rect=[bb.xMin(),bb.yMin(),bb.xMax(),bb.yMax()];near=set()
 for k in keys(rect):
  for other,name in body_index[k]:
   if name not in near and hit(rect,other):
    near.add(name);body_collisions+=1
    if len(samples)<20:samples.append(['clock_body_overlap',r['inst'],name])
  body_index[k].append((rect,r['inst']))
 grown=[rect[0]-.25*u,rect[1]-.25*u,rect[2]+.25*u,rect[3]+.25*u];seen=set()
 for k in keys(grown):
  for ob,name in ob_index[k]:
   key=(tuple(ob),name)
   if key not in seen and hit(grown,ob):
    seen.add(key);access_collisions+=1
    if len(samples)<20:samples.append(['M1-M3_or_PG7_access',r['inst'],name])
endpoint_delta=0.;consumed=0
for port,raw in g['aliases'].items():
 t0=g['taps'][port];i=b.findInst(t0['part']);it=i.findITerm(t0['tap']) if i else None
 if not it or not it.getNet() or it.getNet().getName()!='ck_'+raw:errors.append('native endpoint connection:'+port);continue
 shapes=[sh for mp in it.getMTerm().getMPins() for sh in mp.getGeometry() if sh.getTechLayer() and sh.getTechLayer().getRoutingLevel()>0]
 if len(shapes)!=1 or shapes[0].getTechLayer().getName()!='M7':errors.append('native endpoint metal:'+port);continue
 rr=producer.physical_rect(i,shapes[0]);xy=[(rr[0]+rr[2])/(2*u),(rr[1]+rr[3])/(2*u)];endpoint_delta=max(endpoint_delta,abs(xy[0]-t0['xy'][0])+abs(xy[1]-t0['xy'][1]));consumed+=1
r={'scope':'Actual native graph/body/M1-M3 and PG7 access only; plan-abstract clock-only target; no routing/STA/START freeze/closed child view claim.','status':'FAIL_IMPORT_CENSUS' if errors or body_collisions or access_collisions else 'CONNECTED_UNROUTED_BODY_CENSUS','clock_cells_expected':len(expected),'clock_cells_found':len(found),'consumed_native_clock_ports':consumed,'exact_connection_errors':len(errors),'errors':errors[:30],'master_body_um':sorted(sizes),'actual_routing_pin_layers':sorted(pins),'body_overlap_pairs':body_collisions,'body_access_collisions':access_collisions,'samples':samples,'max_native_M7_vs_planned_endpoint_manhattan_um':endpoint_delta,'unconnected_clock_PG_pins':pg_unbound,'pending':'PG binding/top mesh, actual root/port access routing, RC, all-view contracts, related clock/START and timing qualification remain mandatory.'}
Path(a.out).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(1 if errors or body_collisions or access_collisions else 0)
