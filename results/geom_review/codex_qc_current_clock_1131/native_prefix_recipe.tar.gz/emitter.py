#!/usr/bin/env python3
"""Current pre-D13 d90 plan-abstract clock-only native target.
Re-derive every island from the NEW frozen clock tree. No closed child view,
old clock IDs/provider maps, routing, STA or whole-die qualification is imported.
usage: emitter.py FROZEN_DIE_PLAN_TOOLS EXACT_PLAN COMPLETED_KIT OUT
"""
import sys, json, hashlib, re, shutil
from pathlib import Path
from collections import defaultdict
tools, plan, kit, out = sys.argv[1:5]
sys.path.insert(0, tools)
import schema as S, die_trial as D, gen_phys as G
kit, out = Path(kit), Path(out)
(out / "abstracts").mkdir(parents=True, exist_ok=True); (out / "grt").mkdir(exist_ok=True)
tree = json.loads((kit / "clock" / "tree.json").read_text())
sites = dict(schema="ot_clock_sites/1", sites=[dict(name=n, xy_um=list(xy), kind="partition") for n, xy in sorted(tree["sites"].items())])
(out / "clock_sites_current.json").write_text(json.dumps(sites) + "\n")
P = S.Plan(S.load(Path(plan)), Path(plan))
iw, irec = D.island_windows(P, D.load_island_sites([out / "clock_sites_current.json"]))
smod = D.standin_module_names(P); bits = {}; stats = {}
for tn, t in sorted(P.types.items()):
    text, st = D.abstract_lef(P, tn, islands=iw.get(tn), module_name=smod[tn], landing_infra=True, reset_infra=True)
    (out / "abstracts" / (smod[tn] + ".lef")).write_text(text); stats[tn] = st
    b = defaultdict(int)
    for bus, bit, *_ in G.type_pins(P, tn):
        b[bus] = max(b[bus], bit + 1)
    bits[tn] = dict(b)
text, ft = D.route_netlist(P, bits, landing_infra=True, reset_infra=True); (out / "grt/route.v").write_text(text)
for name in ("obs.tcl", "tracks.tcl"):
    shutil.copy2(kit / "grt" / name, out / "grt" / name)
g = (kit / "grt" / "grt.tcl").read_text()
k = g.index("\nglobal_route ") + 1
g = g[:k] + "write_db /work/native_target.odb\nputs EXACT_ABUTMENT_NATIVE_TARGET_EXPORTED\n"
(out / "grt" / "grt.tcl").write_text(g)
in_core = sum(1 for r in irec for h in r["parts"] if h["in_core"])
rec = dict(schema="opentallas.native_target_infra.v1+islands", plan=plan, plan_sha256=hashlib.sha256(Path(plan).read_bytes()).hexdigest(),
           kit=str(kit), tree_sites=len(sites["sites"]), island_types=len(iw), island_windows=sum(len(v) for v in iw.values()),
           island_in_core=in_core, sites_outside=sum(1 for r in irec if not r["parts"]), types=len(stats), parts=len(P.parts))
(out / "emit_receipt.json").write_text(json.dumps(rec, indent=1) + "\n"); print(json.dumps(rec))
