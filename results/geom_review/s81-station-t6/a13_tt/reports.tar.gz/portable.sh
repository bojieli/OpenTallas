#!/bin/bash
set -eu
base=$PWD/input
docker run --rm -u "$(id -u):$(id -g)" -v "$base:/work:ro" -v "$PWD:/out" -e ODB=/work/5_1_grt_pre_tt.odb -e OT_TT_SETUP_RC=grt -e OT_GRT_TRANSITION_MODE=edge_outline opentallas/orfs:asap7lock-grtoff bash -lc 'source /OpenROAD-flow-scripts/env.sh >/dev/null 2>&1; exec openroad -threads 8 -exit /out/read.tcl' > sta.log 2>&1
