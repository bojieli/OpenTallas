# PRIVATE CTS lifecycle proposal. Original source, MM and flags unchanged.
source /work/pg_cts_canary.tcl
unset -nocomplain ::ot_pg_cts_canary_reached_POST
set ot_pg_cts_body_code [catch {source [file join $::env(SCRIPTS_DIR) cts_private_native_pg_body.tcl]} ot_pg_cts_body_result ot_pg_cts_body_options]
set ot_pg_cts_end_code [catch {ot_pg_cts_canary_finish cts} ot_pg_cts_end_result ot_pg_cts_end_options]
if {$ot_pg_cts_body_code == 1} {
 if {$ot_pg_cts_end_code} {puts stderr "OT_PG_CTS_CLEANUP_REFUSED $ot_pg_cts_end_result"}
 return -options $ot_pg_cts_body_options $ot_pg_cts_body_result
}
if {$ot_pg_cts_end_code == 1} {return -options $ot_pg_cts_end_options $ot_pg_cts_end_result}
if {$ot_pg_cts_end_code != 0} {error "OT_PG_CTS_NONLOCAL_CLEANUP_REFUSED code=$ot_pg_cts_end_code result=$ot_pg_cts_end_result"}
if {$ot_pg_cts_body_code != 0} {error "OT_PG_CTS_NONLOCAL_BODY_REFUSED code=$ot_pg_cts_body_code result=$ot_pg_cts_body_result"}
if {![info exists ::ot_pg_cts_canary_reached_POST] || !$::ot_pg_cts_canary_reached_POST} {error OT_PG_CTS_POST_NOT_REACHED}
