`timescale 1ns/1ps
// ---------------------------------------------------------------------------------------------------------------------
// Qwen KV die, RTL-BUILD-KV/BOOT 2026-10-18 (results/arch/qwen_kv_boot_path_1018/note.md): qkd_kv_pc_chain_station with
// the embedding BOOT tap.  Chain 780 b (F_BT = 779, qkd_kv_es_fan_stack_b): a boot word rides lane 0's pc / data /
// address fields; the station whose pc strap matches emits it, registered, on land_es -> its HOST slice
// (qkd_host_pc_slice_die land_es: the slice's landing source, whose launches the slice's ownership ledger retires as
// land_ack -> slice status chain -> the HOST commit-order ledger, as the legacy strip's boot writes were).
// Writer tap / intake context / embedding player: UNCHANGED (d[778:0] and every PC-face output equal
// qkd_kv_pc_chain_station's bit for bit, tb_kv_boot_chain lockstep).  Size +290 flops (land_es) +8.
// MUT (bench only): as qkd_kv_pc_chain_station, plus 6 = boot tap compares pc[3:0] only.
// ---------------------------------------------------------------------------------------------------------------------
module qkd_kv_pc_chain_station_b #(parameter integer MUT = 0) (
    input  wire          ck,
    input  wire          rst_n,
    input  wire [4:0]    pc,
    input  wire [1:0]    cfg_stack,
    input  wire [779:0]  di,
    output wire [779:0]  dout,
    // BOOT: this PC's HOST slice landing face (qkd_host_pc_slice_die land_es / land_er, unchanged slice)
    output reg  [287:0]  land_es,
    input  wire [260:0]  land_er,
    // PC face: writer word + intake context / expected descriptor
    output reg  [287:0]  wes,
    output wire [317:0]  es_context,
    output reg           es_expected_valid,
    output reg  [60:0]   es_expected_identity,
    output reg  [28:0]   es_expected_address,
    output reg  [4:0]    es_expected_pc,
    output reg  [1:0]    es_expected_stack,
    // PC face: embedding read issue (qkd_static_kv_pc_es_merge)
    output reg           emb_issue_v,
    output reg  [17:0]   emb_token,
    output reg  [5:0]    emb_word_index,
    output reg           emb_half,
    output reg           emb_scale,
    output reg  [15:0]   emb_epoch,
    output reg           emb_return_slot,
    // the PC's return station
    output reg           capture_slot,
    output reg           transfer_slot,
    output reg           fault
);
    localparam integer F_V = 0, F_PC0 = 2, F_PC1 = 7, F_D0 = 12, F_D1 = 268, F_AD = 524, F_SV = 553, F_CTX = 554,
                       F_EV = 615, F_EPC0 = 617, F_EPC1 = 622, F_EST = 627, F_EID = 629, F_EAD = 690,
                       F_SS = 719, F_TOK = 720, F_EP = 738, F_CV = 754, F_CPC = 755, F_CRG = 760, F_CVL = 763, F_BT = 779,
                       W = 780;
    (* keep *) reg rs_q;
    always @(posedge ck) rs_q <= rst_n;
    // ---- the hop register (pin flop) ----
    reg [W-1:0] c;
    always @(posedge ck) c[W-1:F_V+2] <= di[W-1:F_V+2];
    always @(posedge ck or negedge rs_q)
        if (!rs_q) c[F_V +: 2] <= 2'd0; else c[F_V +: 2] <= di[F_V +: 2];
    // valid-type control bits that are not data-qualified: register with reset
    reg ev0, ev1, ss, cv, bt;
    always @(posedge ck or negedge rs_q)
        if (!rs_q) begin ev0 <= 1'b0; ev1 <= 1'b0; ss <= 1'b0; cv <= 1'b0; bt <= 1'b0; end
        else begin ev0 <= di[F_EV]; ev1 <= di[F_EV + 1]; ss <= di[F_SS]; cv <= di[F_CV]; bt <= di[F_BT]; end
    assign dout = {bt, c[F_BT-1:F_CV+1], cv, c[F_CV-1:F_SS+1], ss, c[F_SS-1:F_EV+2], ev1, ev0, c[F_EV-1:0]};
    // ---- identity strap registers (HKV-PCH 2026-10-19) ----
    // pc / cfg_stack are die-top identity straps (kv_static_die cls strap: constants on the die).  Unregistered they
    // reached ~1,100 tap enables (wes / land_es / ctx / eid / r[] / emb_*) straight from the tile pins inside the
    // 0.2 T input budget (qkd_kvs_pc_h_k1 route eb7cbd435: TT -50.35, 1,131 input->register endpoints, all strap).
    // Registered here, every tap compare starts at a local flop.  Constant straps: identical behaviour from the first
    // edge (reset is held far longer); no edge age, calendar slot or die relay stage changes.
    (* keep *) reg [4:0] spc;
    (* keep *) reg [1:0] sst;
    always @(posedge ck) begin spc <= pc; sst <= cfg_stack; end
    // ---- (1) fan-out tap ----
    wire [4:0] pm = (MUT == 1) ? 5'h0f : 5'h1f;
    wire h0 = c[F_V]     && ((c[F_PC0 +: 5] & pm) == (spc & pm));
    wire h1 = c[F_V + 1] && ((c[F_PC1 +: 5] & pm) == (spc & pm));
    wire x0 = ev0 && c[F_EPC0 +: 5] == spc;
    wire x1 = ev1 && c[F_EPC1 +: 5] == spc;
    reg        hit;                       // context valid (bit 317), lagged
    reg [60:0] ctx_id;
    // lag stage (CTX_LAG = 1): context / expected computed from the hop register one edge later than wes
    reg        hit_a, x_a; reg [60:0] ctx_a, eid_a; reg [28:0] ead_a; reg [4:0] epc_a; reg [1:0] est_a;
    always @(posedge ck) begin
        if (h0 | h1) wes[287:1] <= {c[F_SV], c[F_SV], c[F_AD +: 29], h0 ? c[F_D0 +: 256] : c[F_D1 +: 256]};
        if (h0 | h1) ctx_a <= c[F_CTX +: 61];
        if (x0 | x1) begin eid_a <= c[F_EID +: 61]; ead_a <= c[F_EAD +: 29]; epc_a <= x0 ? c[F_EPC0 +: 5] : c[F_EPC1 +: 5];
                           est_a <= c[F_EST +: 2]; end
    end
    always @(posedge ck or negedge rs_q)
        if (!rs_q) begin wes[0] <= 1'b0; hit_a <= 1'b0; x_a <= 1'b0; end
        else begin wes[0] <= h0 | h1; hit_a <= h0 | h1; x_a <= x0 | x1; end
    generate
        if (MUT == 5) begin : g_nolag
            always @(*) begin hit = hit_a; ctx_id = ctx_a; es_expected_valid = x_a; es_expected_identity = eid_a;
                              es_expected_address = ead_a; es_expected_pc = epc_a; es_expected_stack = est_a; end
        end else begin : g_lag
            always @(posedge ck) begin
                ctx_id <= ctx_a; es_expected_identity <= eid_a; es_expected_address <= ead_a;
                es_expected_pc <= epc_a; es_expected_stack <= est_a;
            end
            always @(posedge ck or negedge rs_q)
                if (!rs_q) begin hit <= 1'b0; es_expected_valid <= 1'b0; end
                else begin hit <= hit_a; es_expected_valid <= x_a; end
        end
    endgenerate
    assign es_context = {hit, ctx_id, {256{hit}}};
    // ---- (3) BOOT tap: the embedding boot word for this PC -> the HOST slice landing source (registered, +1), as the
    //      HOST static ABI word {we-data 1, we 1, bank, col, row, data 256, v} (= qkd_host_ingest_station host_es).
    //      land_er (the slice's landing return) lands on pin flops and is CHECKED, never waited on: the slice returns
    //      one credit (er[259]) per landing word it launches; a credit with none outstanding, a landing read return
    //      (no landing reads exist on the static die), the slice's fault bit (er[260]: its landing queue overflow is
    //      flagged there, exactly) or a counter overflow latch fault.  Static: no ready / wait (the gateway paces the
    //      boot stream; note.md).
    wire [4:0] bpm = (MUT == 6) ? 5'h0f : 5'h1f;
    wire bh = bt && ((c[F_PC0 +: 5] & bpm) == (spc & bpm));
    always @(posedge ck) if (bh) land_es[287:1] <= {1'b1, 1'b1, c[F_AD +: 29], c[F_D0 +: 256]};
    always @(posedge ck or negedge rs_q) if (!rs_q) land_es[0] <= 1'b0; else land_es[0] <= bh;
    (* keep *) reg ler_v, ler_cr, ler_f;
    always @(posedge ck or negedge rs_q)
        if (!rs_q) begin ler_v <= 1'b0; ler_cr <= 1'b0; ler_f <= 1'b0; end
        else begin ler_v <= land_er[0]; ler_cr <= land_er[259]; ler_f <= land_er[260]; end
    reg [2:0] bo;                         // boot words outstanding in the slice's landing queue
    reg       bfault;
    always @(posedge ck or negedge rs_q)
        if (!rs_q) begin bo <= 3'd0; bfault <= 1'b0; end
        else begin
            bo <= bo + {2'd0, land_es[0]} - {2'd0, ler_cr};
            if ((ler_cr && bo == 3'd0 && !land_es[0]) || (land_es[0] && !ler_cr && bo == 3'd7) || ler_v || ler_f)
                bfault <= 1'b1;
        end
    // ---- (2) embedding slot player ----
    reg [15:0] r [0:7];
    reg [15:0] cnt, last; reg act; reg [17:0] tok; reg [15:0] ep;
    wire home = tok<18'd151936 && tok[8:4] == spc && (MUT == 4 || tok[10:9] == sst);
    wire [15:0] trn = (MUT == 3 && spc == 5'd5) ? r[3] + 16'd1 : r[3];
    integer k;
    always @(posedge ck) if (ss) begin tok <= c[F_TOK +: 18]; ep <= c[F_EP +: 16]; end
    always @(posedge ck or negedge rs_q)
        if (!rs_q) begin
            for (k = 0; k < 8; k = k + 1) r[k] <= 16'hffff;
            cnt <= 16'd0; last <= 16'd0; act <= 1'b0; fault <= 1'b0;
            emb_issue_v <= 1'b0; emb_return_slot <= 1'b0; capture_slot <= 1'b0; transfer_slot <= 1'b0;
            emb_token <= 18'd0; emb_epoch <= 16'd0; emb_word_index <= 6'd0; emb_half <= 1'b0; emb_scale <= 1'b0;
        end else begin
            if (cv && c[F_CPC +: 5] == spc) begin
                r[c[F_CRG +: 3]] <= c[F_CVL +: 16];
                if (c[F_CVL +: 16] != 16'hffff && c[F_CVL +: 16] > last) last <= c[F_CVL +: 16];
                if (act) fault <= 1'b1;
            end
            if (ss) begin
                if (act) fault <= 1'b1;
                act <= 1'b1; cnt <= 16'd0;
            end else if (act) begin
                cnt <= cnt + 16'd1;
                if (cnt == last) act <= 1'b0;      // the calendar ends on its last configured event
            end
            emb_token <= tok; emb_epoch <= ep;
            emb_issue_v     <= act && (cnt == r[0] || (home && cnt == r[4]));
            emb_return_slot <= act && (cnt == r[1] || (home && cnt == r[5]));
            capture_slot    <= act && (cnt == r[2] || (home && cnt == r[6]));
            transfer_slot   <= act && (cnt == trn  || (home && cnt == r[7]));
            if (act && cnt == r[0]) begin emb_word_index <= {sst, spc[4:1]}; emb_half <= spc[0]; emb_scale <= 1'b0; end
            else if (act && home && cnt == r[4]) begin emb_word_index <= 6'd0; emb_half <= 1'b0; emb_scale <= 1'b1; end
            if ((h0 && h1) || (x0 && x1) || bfault || (bh && (h0 || h1))) fault <= 1'b1;
        end
endmodule
