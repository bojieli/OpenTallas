// DIE-HBM-92-SU-IDX 11-08: staged copy of the d44v part-6 plan glue (results/die_hbm_1103/reform/split_p6/
// ot_hbm_idx_score_hcol_h0__p6glue.sv, SPLIT c4237519789) under its own top name ot_hbm_idx_score_hcol_h0__p6glue, with the as-built ot_hbm_idx_score_hcol_h0 ports (the composition
// never had cs_in/cf_in: the as-built h0 ties them 0).  The sub-cores are the signed masters ot_hbm_idx_score_hcol_h0_ra / _rb (not the
// bench face-shell models __fs).  Wires only.  The ra -> rb running sum crosses two face flops inside the signed macros
// (ra out + rb in); ra pays them back inside (SEAM = 2), so the composition is cycle-exact with ot_hbm_idx_score_hcol_h0 through them.
`default_nettype none
module ot_hbm_idx_score_hcol_h0__p6glue (
    input wire [1:0] clk_pair, input wire rst_col, input wire qv_b, input wire [567:0] q_b, input wire [543:0] key,
    input wire [31:0] hid4, output wire [31:0] cs_out, output wire cf_out, output wire [1:0] prdy);
    ot_hbm_idx_score_hcol_h0__p6glue__fcore u_fcore (.clk_pair(clk_pair), .rst_col(rst_col), .qv_b(qv_b), .q_b(q_b), .key(key), .hid4(hid4), .cs_out(cs_out), .cf_out(cf_out), .prdy(prdy));
endmodule

module ot_hbm_idx_score_hcol_h0__p6glue__fcore (
    input wire [1:0] clk_pair, input wire rst_col, input wire qv_b, input wire [567:0] q_b, input wire [543:0] key,
    input wire [31:0] hid4, output wire [31:0] cs_out, output wire cf_out, output wire [1:0] prdy);
    ot_hbm_idx_score_hcol_h0__p6glue__split u_core (.clk_pair(clk_pair), .rst_col(rst_col), .qv_b(qv_b), .q_b(q_b), .key(key), .hid4(hid4), .cs_out(cs_out), .cf_out(cf_out), .prdy(prdy));
endmodule

module ot_hbm_idx_score_hcol_h0__p6glue__split (
    input wire [1:0] clk_pair, input wire rst_col, input wire qv_b, input wire [567:0] q_b, input wire [543:0] key,
    input wire [31:0] hid4, output wire [31:0] cs_out, output wire cf_out, output wire [1:0] prdy);
    wire [31:0] cs2; wire cf2;
    ot_hbm_idx_score_hcol_h0_ra u_ra (.clk(clk_pair[0]), .rst_col(rst_col), .qv_b(qv_b), .q_b(q_b), .key(key),
        .hid2(hid4[15:0]), .cs_out(cs2), .cf_out(cf2), .prdy(prdy[0]));
    ot_hbm_idx_score_hcol_h0_rb u_rb (.clk(clk_pair[1]), .rst_col(rst_col), .qv_b(qv_b), .q_b(q_b), .key(key),
        .hid2(hid4[31:16]), .cs_in(cs2), .cf_in(cf2), .cs_out(cs_out), .cf_out(cf_out), .prdy(prdy[1]));
endmodule
`default_nettype wire
